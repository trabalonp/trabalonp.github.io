#!/usr/bin/env python3
"""Regenera archivos-corregidos.zip con los ficheros listados en lista-archivos-corregidos.txt.

Uso: python3 build-archivos-corregidos.py
Cuando se editen nuevos archivos del proyecto, añadir su ruta relativa
(desde la raíz de mi-app-entrenos) a lista-archivos-corregidos.txt.
"""
import os
import zipfile

BASE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(BASE, 'proyecto', 'mi-app-entrenos')
OUT = os.path.join(BASE, 'archivos-corregidos.zip')
LISTA = os.path.join(BASE, 'lista-archivos-corregidos.txt')

with open(LISTA) as f:
    files = [l.strip() for l in f if l.strip() and not l.startswith('#')]

missing = [n for n in files if not os.path.exists(os.path.join(SRC, n))]
if missing:
    raise SystemExit('FALTAN archivos en el proyecto: ' + ', '.join(missing))

with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for n in files:
        z.write(os.path.join(SRC, n), n)

print('OK -> %s (%d archivos, %d bytes)' % (OUT, len(files), os.path.getsize(OUT)))
