#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Corrección del ESFUERZO (TSS) en la app.

Causa raíz nº2: computeEsfuerzo() usaba `perfil.umbralFC` como umbral de FC
(LTHR), pero en esta app ese campo es la FC MÁXIMA (pantalla Zonas → "FC
máxima"). Con LTHR ≈ FCmáx el denominador del TRIMP se inflaba (~260 en vez de
~135) y el hrTSS salía a la mitad; y si la FC máxima de la sesión era menor que
la del perfil, la rama se descartaba entera y se caía al Training Effect ×20.
Resultado: 27 donde TrainingPeaks marca 83.

Se añade además rTSS por ritmo (como hace TrainingPeaks en carrera) y se guarda
`esfuerzoFuente` para saber siempre de dónde sale el número.
"""
import io
import os

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(BASE, 'proyecto', 'mi-app-entrenos')


def load(rel):
    with io.open(os.path.join(ROOT, rel), 'r', encoding='utf-8', newline='') as f:
        s = f.read()
    nl = '\r\n' if '\r\n' in s else '\n'
    return s.replace(nl, '\n'), nl


def save(rel, text, nl):
    with io.open(os.path.join(ROOT, rel), 'w', encoding='utf-8', newline='') as f:
        f.write(text.replace('\n', nl))


def rep(text, old, new, tag):
    n = text.count(old)
    if n != 1:
        raise SystemExit('ERROR [%s]: esperadas 1 coincidencia, encontradas %d' % (tag, n))
    return text.replace(old, new, 1)


# ══════════════════════════════════════════════════════════════════════
# services/SyncService.js
# ══════════════════════════════════════════════════════════════════════
p = 'services/SyncService.js'
s, nl = load(p)

s = rep(
    s,
    """  // Perfil del atleta y wellness: se usan para calcular el esfuerzo (TSS/hrTSS)
  // cuando el archivo FIT no trae el dato directamente (umbral de potencia,
  // umbral de FC, fecha de nacimiento y FC en reposo del día).""",
    """  // Perfil del atleta y wellness: se usan para calcular el esfuerzo (TSS/rTSS/
  // hrTSS) cuando el archivo FIT no trae el dato directamente (umbral de
  // potencia, ritmo umbral, FC máxima, umbral de FC, fecha de nacimiento y FC en
  // reposo del día). OJO: en el perfil, `umbralFC` es la FC MÁXIMA y el umbral
  // de FC de verdad va en `fcUmbral` (ver computeEsfuerzo).""",
    'sync.comment',
)

s = rep(
    s,
    """        cadencia: parsed.cadencia || 0,
        esfuerzo: parsed.esfuerzo ?? 0,
      });""",
    """        cadencia: parsed.cadencia || 0,
        esfuerzo: parsed.esfuerzo ?? 0,
        esfuerzoFuente: parsed.esfuerzoFuente || null,
      });""",
    'sync.maindoc',
)

s = rep(
    s,
    """        esfuerzo: parsed.esfuerzo ?? 0,
        tss: parsed.esfuerzo ?? 0,
        notas: '',""",
    """        esfuerzo: parsed.esfuerzo ?? 0,
        tss: parsed.esfuerzo ?? 0,
        esfuerzoFuente: parsed.esfuerzoFuente || null,
        notas: '',""",
    'sync.detalles',
)

s = rep(
    s,
    """        avgSpeed, ritmo, cadencia, desnivelPos, desnivelNeg, temperatura, nombre, sport, esfuerzo, potenciaMedia;""",
    """        avgSpeed, ritmo, cadencia, desnivelPos, desnivelNeg, temperatura, nombre, sport, esfuerzo, esfuerzoFuente, potenciaMedia;""",
    'sync.vars',
)

s = rep(
    s,
    """      // OJO: `activityTrainingLoad` no existe en el formato FIT y
      // `totalTrainingEffect` es el Training Effect de Garmin (0–5), no un TSS.
      // El esfuerzo real (tipo TrainingPeaks: 83, 55, 101…) se calcula en
      // computeEsfuerzo() con los datos disponibles.
      esfuerzo = computeEsfuerzo(session, startTime, perfil, wellnessDays);""",
    """      // OJO: `activityTrainingLoad` no existe en el formato FIT y
      // `totalTrainingEffect` es el Training Effect de Garmin (0–5), no un TSS.
      // El esfuerzo real (tipo TrainingPeaks: 83, 55, 101…) se calcula en
      // computeEsfuerzo(), que devuelve { valor, fuente }.
      const esfCalc = computeEsfuerzo(session, startTime, perfil, wellnessDays);
      esfuerzo = esfCalc.valor;
      esfuerzoFuente = esfCalc.fuente;""",
    'sync.call',
)

s = rep(
    s,
    """      nombre = ''; sport = 'generic'; esfuerzo = 0; potenciaMedia = 0;""",
    """      nombre = ''; sport = 'generic'; esfuerzo = 0; esfuerzoFuente = null; potenciaMedia = 0;""",
    'sync.recordsonly',
)

s = rep(
    s,
    """      esfuerzo: esfuerzo ?? 0,
      potenciaMedia,""",
    """      esfuerzo: esfuerzo ?? 0,
      esfuerzoFuente: esfuerzoFuente || null,
      potenciaMedia,""",
    'sync.return',
)

# ── computeEsfuerzo nuevo ──
ini = s.index('// ─────────────────────────────────────────────────────────────────\n// ESFUERZO (equivalente TSS')
fin = s.index('export async function resetSyncFolder() {')
nuevo = r'''// ─────────────────────────────────────────────────────────────────
// ESFUERZO (equivalente TSS, estilo TrainingPeaks: 83, 55, 101, 91…)
//
// Los archivos FIT de Garmin NO incluyen TSS, así que se calcula con la mejor
// fuente disponible y en el mismo orden de preferencia que usa TrainingPeaks:
//   1) session.trainingStressScore, si el archivo ya lo trae (Wahoo,
//      TrainingPeaks, Golden Cheetah…).
//   2) TSS por potencia:  TSS = (segundos × NP × IF) / (FTP × 3600) × 100,
//      con IF = NP / FTP.
//   3) rTSS por ritmo (carrera a pie con ritmo umbral en el perfil):
//      rTSS = horas × IF² × 100,  con IF = ritmoUmbral / ritmoMedio.
//   4) hrTSS por frecuencia cardíaca: TRIMP de Banister normalizado para que
//      1 hora al umbral de FC ≈ 100 (misma escala que TSS).
//   5) Último recurso: Training Effect de Garmin (0–5) escalado ×20.
//
// Devuelve { valor, fuente } para que la app pueda mostrar de dónde sale el
// número y se pueda comparar con TrainingPeaks sin dudas.
//
// ⚠ CAMBIO IMPORTANTE: en esta app `perfil.umbralFC` es la FC MÁXIMA (es el
// campo "FC máxima" de la pantalla Zonas), NO el umbral de FC. Antes se usaba
// como si fuera el umbral: el denominador del TRIMP salía ~260 en vez de ~135 y
// el hrTSS quedaba a la mitad —o se descartaba entero cuando la FC máxima de la
// sesión era menor que la del perfil, cayendo al Training Effect ×20—. Por eso
// la app podía mostrar 27 en un entreno que en TrainingPeaks era 83.
// ─────────────────────────────────────────────────────────────────
function computeEsfuerzo(session, startDate, perfil, wellnessDays) {
  const num = (v) => (v != null && Number.isFinite(Number(v)) ? Number(v) : null);
  const out = (valor, fuente) => ({ valor: Math.max(0, Math.round(valor)), fuente });

  // 1) TSS grabado en el propio archivo FIT
  const tssFit = num(session.trainingStressScore);
  if (tssFit != null && tssFit > 0) return out(tssFit, 'archivo');

  const durSec = num(session.totalTimerTime) ?? num(session.totalElapsedTime) ?? 0;
  const durMin = durSec / 60;
  const tipoSesion = mapSport(session.sport);

  // 2) TSS por potencia (NP + FTP)
  const np = num(session.normalizedPower);
  const ftp = num(session.thresholdPower) ?? num(perfil?.umbralPotencia);
  if (np != null && np > 0 && ftp != null && ftp > 0 && durSec > 0) {
    return out(((durSec * np * (np / ftp)) / (ftp * 3600)) * 100, 'potencia');
  }

  // 3) rTSS por ritmo (carrera a pie). Es lo que hace TrainingPeaks cuando el
  //    atleta tiene configurado el ritmo umbral: 1 h al ritmo umbral = 100.
  if (tipoSesion === 'Running' && durSec > 0) {
    const ritmoUmbral = parseRitmoMinKm(perfil?.umbralRitmo);
    const distM = num(session.totalDistance);
    if (ritmoUmbral != null && distM != null && distM > 200) {
      const ritmoMedio = durSec / (distM / 1000); // s/km
      if (ritmoMedio > 0) {
        const ifRitmo = ritmoUmbral / ritmoMedio; // >1 = más rápido que el umbral
        if (ifRitmo > 0.3 && ifRitmo < 2) {
          return out((durSec / 3600) * ifRitmo * ifRitmo * 100, 'ritmo');
        }
      }
    }
  }

  // 4) hrTSS: TRIMP de Banister normalizado al umbral de FC
  const avgHr = num(session.avgHeartRate);
  if (avgHr != null && avgHr > 0 && durMin >= 5) {
    // FC máxima: manda la del perfil (campo "FC máxima" de Zonas); si no está o
    // no es creíble, fórmula de Tanaka con la fecha de nacimiento.
    let hrMax = num(perfil?.umbralFC);
    if (hrMax == null || hrMax < 100 || hrMax > 230) {
      hrMax = null;
      const fnRaw = perfil?.fechaNac;
      if (fnRaw) {
        const fn = fnRaw.toDate ? fnRaw.toDate() : new Date(fnRaw);
        const edad = (startDate.getTime() - fn.getTime()) / (365.25 * 24 * 3600 * 1000);
        if (edad > 5 && edad < 100) hrMax = 208 - 0.7 * edad;
      }
      if (hrMax == null) hrMax = 190;
    }
    const maxSesion = num(session.maxHeartRate);
    if (maxSesion != null && maxSesion > hrMax) hrMax = maxSesion;

    // FC en reposo: wellness del día de la actividad, si no, 60
    const dayKey = `${startDate.getFullYear()}-${String(startDate.getMonth() + 1).padStart(2, '0')}-${String(startDate.getDate()).padStart(2, '0')}`;
    const hrRest = num(wellnessDays?.[dayKey]?.rhr) ?? 60;

    // Umbral de FC (LTHR): campo explícito del perfil → zona de umbral de las
    // zonas de FC → 90 % de la FC máxima. NUNCA `umbralFC`, que es la máxima.
    const lthr = num(perfil?.fcUmbral) ?? lthrDesdeZonas(perfil?.zonasFC, hrMax) ?? Math.round(hrMax * 0.90);

    if (hrRest > 0 && hrMax > lthr && lthr > hrRest) {
      const f = (r) => r * 0.64 * Math.exp(1.92 * r); // factor TRIMP
      const ratio = Math.min(1, Math.max(0, (avgHr - hrRest) / (hrMax - hrRest)));
      const denom = 60 * f((lthr - hrRest) / (hrMax - hrRest)); // TRIMP de 1 h al umbral
      if (ratio > 0 && denom > 0) return out((durMin * f(ratio)) * (100 / denom), 'fc');
    }
  }

  // 5) Último recurso: Training Effect de Garmin (0–5) → escala aproximada
  const te = num(session.totalTrainingEffect);
  if (te != null && te > 0) return out(te * 20, 'training-effect');

  return { valor: 0, fuente: null };
}

// "04:35" / "4:35" / "4.5" / 4.58  →  segundos por km
function parseRitmoMinKm(v) {
  if (v == null || v === '') return null;
  if (typeof v === 'number') return Number.isFinite(v) && v > 0 ? Math.round(v * 60) : null;
  const s = String(v).trim().replace(',', '.');
  const m = s.match(/^(\d{1,3}):(\d{1,2})$/);
  if (m) {
    const seg = Number(m[1]) * 60 + Number(m[2]);
    return seg > 0 ? seg : null;
  }
  const n = Number(s);
  return Number.isFinite(n) && n > 0 ? Math.round(n * 60) : null;
}

// Umbral de FC a partir de las zonas configuradas: el límite inferior de la
// zona de umbral. En esta app las zonas de FC se generan desde la FC máxima y
// la zona "SuperUmbral" empieza en el 90 %, así que se acepta cualquier límite
// entre el 84 % y el 96 % de la máxima y se descarta el resto.
function lthrDesdeZonas(zonas, hrMax) {
  if (!Array.isArray(zonas) || zonas.length === 0 || !(hrMax > 0)) return null;
  const mins = zonas
    .map((z) => Number(z && z.min))
    .filter((n) => Number.isFinite(n) && n >= hrMax * 0.84 && n <= hrMax * 0.96)
    .sort((a, b) => a - b);
  return mins.length ? Math.round(mins[0]) : null;
}

'''
s = s[:ini] + nuevo + s[fin:]

save(p, s, nl)
print('OK services/SyncService.js')


# ══════════════════════════════════════════════════════════════════════
# screens/WorkoutDetailModal.js
# ══════════════════════════════════════════════════════════════════════
p = 'screens/WorkoutDetailModal.js'
s, nl = load(p)

s = rep(
    s,
    """  const [esfuerzo, setEsfuerzo] = useState('');""",
    """  const [esfuerzo, setEsfuerzo] = useState('');
  const [esfuerzoFuente, setEsfuerzoFuente] = useState(null); // de dónde sale el número
  const [esfuerzoOriginal, setEsfuerzoOriginal] = useState(''); // para detectar edición manual""",
    'wdm.state',
)

s = rep(
    s,
    """    setCarga(workout.cargaPercibida ?? null); setEsfuerzo(Number(workout.esfuerzo) > 0 ? workout.esfuerzo.toString() : '');""",
    """    setCarga(workout.cargaPercibida ?? null);
    const esfIni = Number(workout.esfuerzo) > 0 ? workout.esfuerzo.toString() : '';
    setEsfuerzo(esfIni); setEsfuerzoOriginal(esfIni);
    setEsfuerzoFuente(workout.esfuerzoFuente ?? (workout.esfuerzoManual ? 'manual' : null));""",
    'wdm.load',
)

s = rep(
    s,
    """          if (d.cargaPercibida) setCarga(d.cargaPercibida); if (d.esfuerzo != null && Number(d.esfuerzo) > 0) setEsfuerzo(String(d.esfuerzo)); if (d.enlace) setEnlace(d.enlace);""",
    """          if (d.cargaPercibida) setCarga(d.cargaPercibida); if (d.enlace) setEnlace(d.enlace);
          if (d.esfuerzo != null && Number(d.esfuerzo) > 0) {
            const esfDet = String(d.esfuerzo);
            setEsfuerzo(esfDet); setEsfuerzoOriginal(esfDet);
          }
          if (d.esfuerzoManual === true) setEsfuerzoFuente('manual');
          else if (d.esfuerzoFuente) setEsfuerzoFuente(d.esfuerzoFuente);""",
    'wdm.detalles',
)

s = rep(
    s,
    """        if (dd && dd.intervalsDetailSynced && dd.hasRuta === true && Number(dd.esfuerzo) > 0) return;""",
    """        if (dd && dd.intervalsDetailSynced && dd.hasRuta === true && Number(dd.esfuerzo) > 0 && dd.esfuerzoFuente) return;""",
    'wdm.skipdetail',
)

s = rep(
    s,
    """        if (d2s.exists()) { const d2 = d2s.data(); setVueltas(d2.vueltas ?? []); if (d2.elevacionMin != null) setElevMin(d2.elevacionMin.toString()); if (d2.elevacionMax != null) setElevMax(d2.elevacionMax.toString()); if (Number(d2.esfuerzo) > 0) setEsfuerzo(String(d2.esfuerzo)); }""",
    """        if (d2s.exists()) { const d2 = d2s.data(); setVueltas(d2.vueltas ?? []); if (d2.elevacionMin != null) setElevMin(d2.elevacionMin.toString()); if (d2.elevacionMax != null) setElevMax(d2.elevacionMax.toString()); if (Number(d2.esfuerzo) > 0) { setEsfuerzo(String(d2.esfuerzo)); setEsfuerzoOriginal(String(d2.esfuerzo)); } if (d2.esfuerzoManual === true) setEsfuerzoFuente('manual'); else if (d2.esfuerzoFuente) setEsfuerzoFuente(d2.esfuerzoFuente); }""",
    'wdm.afterrefresh',
)

# handleSaveSession: marcar esfuerzoManual solo si el usuario cambió el valor
s = rep(
    s,
    """      const secs = parseDuration(durText);
      await updateDoc(doc(db,'entrenamientos',workout.id), { estado, duracion: secs ?? null, distancia: distancia ? parseFloat(distancia) : null, 'fc-media': fc ? parseInt(fc) : null, esfuerzo: esfuerzo ? parseInt(esfuerzo) : null });""",
    """      const secs = parseDuration(durText);
      // Si el usuario ha tocado el esfuerzo, se marca como manual para que el
      // servidor no lo vuelva a sobrescribir con el valor de intervals.icu.
      const esfManual = esfuerzo !== esfuerzoOriginal;
      const esfExtra = esfManual
        ? { esfuerzoManual: true, esfuerzoFuente: 'manual' }
        : (esfuerzoFuente && esfuerzoFuente !== 'manual' ? { esfuerzoManual: false, esfuerzoFuente } : { esfuerzoManual: false });
      await updateDoc(doc(db,'entrenamientos',workout.id), { estado, duracion: secs ?? null, distancia: distancia ? parseFloat(distancia) : null, 'fc-media': fc ? parseInt(fc) : null, esfuerzo: esfuerzo ? parseInt(esfuerzo) : null, ...esfExtra });""",
    'wdm.save1',
)

s = rep(
    s,
    """cargaPercibida: carga, esfuerzo: esfuerzo?parseInt(esfuerzo):null, enlace, sensacion, comentarios,""",
    """cargaPercibida: carga, esfuerzo: esfuerzo?parseInt(esfuerzo):null, ...esfExtra, enlace, sensacion, comentarios,""",
    'wdm.save2',
)

# UI: chivato del origen del esfuerzo bajo el campo
s = rep(
    s,
    """                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Esfuerzo','Effort')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border }]}><TextInput style={[s.inputInner, { color: theme.text }]} value={esfuerzo} onChangeText={setEsfuerzo} placeholder="0" placeholderTextColor="#4A6080" keyboardType="numeric" /></View>""",
    """                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Esfuerzo','Effort')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border }]}><TextInput style={[s.inputInner, { color: theme.text }]} value={esfuerzo} onChangeText={setEsfuerzo} placeholder="0" placeholderTextColor="#4A6080" keyboardType="numeric" /></View>
                          <Text style={[s.fieldLabel, { color: theme.muted, fontSize: 10, marginTop: 3, opacity: 0.85 }]} numberOfLines={2}>
                            {L('Fuente','Source')}: {fuenteEsfuerzoTexto(esfuerzo !== esfuerzoOriginal ? 'manual' : esfuerzoFuente)}
                          </Text>""",
    'wdm.ui',
)

# helper de textos a nivel de módulo
s = rep(
    s,
    """function ritmoForDisplay(tipo, rit) {""",
    """// Texto legible del origen del esfuerzo (TSS), para poder compararlo con
// TrainingPeaks / intervals.icu y saber si el número es fiable.
function fuenteEsfuerzoTexto(f) {
  switch (f) {
    case 'manual': return 'Manual (no se sobrescribirá al sincronizar)';
    case 'intervals.icu': return 'intervals.icu (TSS)';
    case 'archivo': return 'Archivo FIT';
    case 'potencia': return 'Potencia (TSS)';
    case 'ritmo': return 'Ritmo (rTSS)';
    case 'fc': return 'Frecuencia cardíaca (hrTSS)';
    case 'training-effect': return 'Training Effect de Garmin (aprox.)';
    default: return 'Sin calcular';
  }
}

function ritmoForDisplay(tipo, rit) {""",
    'wdm.helper',
)

save(p, s, nl)
print('OK screens/WorkoutDetailModal.js')


# ══════════════════════════════════════════════════════════════════════
# screens/ZonesScreen.js  →  campo explícito de umbral de FC (LTHR)
# ══════════════════════════════════════════════════════════════════════
p = 'screens/ZonesScreen.js'
s, nl = load(p)

s = rep(
    s,
    """  const [umbralFC, setUmbralFC] = useState('');       // FC máxima""",
    """  const [umbralFC, setUmbralFC] = useState('');       // FC máxima (¡no es el umbral!)
  const [fcUmbral, setFcUmbral] = useState('');       // FC umbral (LTHR), para el esfuerzo/hrTSS""",
    'zones.state',
)

s = rep(
    s,
    """        setUmbralFC(cached.umbralFC || '');
        setUmbralPotencia(cached.umbralPotencia || '');""",
    """        setUmbralFC(cached.umbralFC || '');
        setFcUmbral(cached.fcUmbral || '');
        setUmbralPotencia(cached.umbralPotencia || '');""",
    'zones.cache',
)

s = rep(
    s,
    """          setUmbralFC(data.umbralFC || '');
          setUmbralPotencia(data.umbralPotencia || '');""",
    """          setUmbralFC(data.umbralFC || '');
          setFcUmbral(data.fcUmbral || '');
          setUmbralPotencia(data.umbralPotencia || '');""",
    'zones.fs',
)

s = rep(
    s,
    """        umbralRitmo,
        umbralFC,
        umbralPotencia,
      };""",
    """        umbralRitmo,
        umbralFC,
        fcUmbral,
        umbralPotencia,
      };""",
    'zones.save',
)

s = rep(
    s,
    """            <Text style={[styles.label, { color: theme.muted }]}>FC máxima</Text>
            <TextInput style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={umbralFC} onChangeText={setUmbralFC} placeholder="190" keyboardType="numeric" />""",
    """            <Text style={[styles.label, { color: theme.muted }]}>FC máxima</Text>
            <TextInput style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={umbralFC} onChangeText={setUmbralFC} placeholder="190" keyboardType="numeric" />
            <Text style={[styles.label, { color: theme.muted, marginTop: 10 }]}>FC umbral (LTHR) — opcional</Text>
            <TextInput style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={fcUmbral} onChangeText={setFcUmbral} placeholder="170" keyboardType="numeric" />
            <Text style={[styles.label, { color: theme.muted, fontSize: 11, marginTop: 4, opacity: 0.8 }]}>
              La FC que aguantas 1 hora a ritmo fuerte. Se usa para calcular el esfuerzo (hrTSS) de los entrenos importados desde el móvil; si la dejas vacía se estima como el 90 % de tu FC máxima.
            </Text>""",
    'zones.ui',
)

save(p, s, nl)
print('OK screens/ZonesScreen.js')

print('\nApp actualizada.')
