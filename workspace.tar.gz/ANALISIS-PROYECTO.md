# 📱 Análisis del proyecto: Team Jorge App (`mi-app-entrenos`)

> Informe generado el 18/09/2026 tras leer el código completo del repositorio.

---

## 1. ¿Qué es?

Una **app móvil de entrenamiento deportivo** (Android/iOS) estilo *TrainingPeaks / Intervals.icu*, pensada para **atletas y entrenadores**. Permite:

- Sincronizar actividades desde **Garmin** (vía Intervals.icu o importando archivos `.fit` locales).
- Planificar entrenamientos estructurados (por pasos, estilo Garmin).
- Ver análisis avanzados: zonas de FC/ritmo/potencia, curvas de mejores esfuerzos, récords, métricas corporales (sueño, VFC, VO2max, FTP…).
- Gráfica de **Condición/Fatiga/Forma (CTL/ATL/TSB)**.
- Calendario semanal con **drag & drop** para mover entrenos.
- Relación **entrenador ↔ atleta**: solicitudes, vista de los datos del atleta y comentarios con notificaciones push.

**Nombre de la app:** "Team Jorge App" (`com.teamjorge.app`), dueño Expo `team-jorge-app`, v1.0.0.

---

## 2. Stack tecnológico

| Capa | Tecnología |
|---|---|
| Framework | **Expo SDK 57** + React Native 0.86 + React 19.2 (New Architecture y React Compiler activados) |
| Navegación | React Navigation 7 (stack nativo + bottom tabs). *No* usa expo-router |
| Backend principal | **Firebase**: Auth (email/contraseña), **Firestore** (datos), Realtime Database (config remota de la URL de API), Push (Expo Notifications + `google-services.json`) |
| Backend API #1 | **Vercel** → `https://mi-app-entrenos.vercel.app/api`: sync con Intervals.icu, cálculo de fitness (CTL/ATL), notificaciones push al atleta |
| Backend API #2 | **Render** → `https://garmin-fit-server.onrender.com`: relación entrenador-atleta (plan gratuito, se "despierta" con un ping al arrancar) |
| Datos de reloj | **@garmin/fitsdk** — parseo de archivos FIT **en el propio móvil** |
| Gráficas | **Victory Native + Skia** (render nativo de alto rendimiento) |
| Mapa GPS | WebView + **Leaflet** + teselas OpenStreetMap |
| Persistencia local | AsyncStorage (cachés de perfil, coach y análisis) |
| Builds / OTA | **EAS Build** (perfiles development/preview/production) + **expo-updates** (actualizaciones OTA por canal) |
| i18n | Sistema propio bilingüe **ES/EN** (diccionario central `t()` + helper inline `L()`) |
| Tema | Claro/Oscuro/Dispositivo + unidades métricas/imperiales + 4 formatos de fecha |

---

## 3. Arquitectura y modelo de datos (Firestore)

```
perfiles/{uid}            → nombre, apellidos, foto (base64), expoPushToken,
                            zonasFC, zonasRitmo, zonasPotencia, umbrales
entrenamientos/{id}       → userId, id_archivo, fecha, tipo, titulo, distancia,
                            duracion, fc-media, estado, elevacion, potenciaMedia…
   ├── detalles/data      → calorias, fcMax, ritmo, vueltas/laps, cargaPercibida (RPE),
   │                        sensacion (ánimo), comentarios[], pasos[] (estructura), notas
   └── registros/data     → puntos segundo a segundo (HR, velocidad, potencia, cadencia,
                            GPS) decimados a ≤1000 puntos
wellness/{uid}.days       → mapa día→ {load, kcal, steps, sleep, rhr, hrv, vo2, weight,
                            spo2, score, ftp, lthr, umbral…} (lo escribe el backend)
fitness/{uid}.days        → serie CTL/ATL/Forma (la calcula el backend de Vercel)
intervals_connections/{uid} → conexión con Intervals.icu
analysis/{uid}            → layout de gráficas configurado por el usuario
libreria/{id}             → plantillas de entreno reutilizables (contador timesUsed)
soporte/{id}              → tickets de soporte
RTDB: config/serverUrl    → permite cambiar la URL del backend en remoto sin actualizar la app
```

**Flujo de sincronización principal (Intervals.icu):**
1. El usuario conecta su cuenta (Athlete ID + API key) → el backend de Vercel valida y guarda en `intervals_connections`.
2. Al sincronizar, la app llama a `POST /sync-intervals` (últimos 30 días) con el token de Firebase Auth.
3. El backend descarga las actividades de Intervals.icu (que a su vez las baja de Garmin Connect) y las escribe en Firestore.
4. `POST /sync-fitness` recalcula CTL/ATL/Forma y lo guarda en `fitness/{uid}`.

**Plan B (sin Intervals):** en Android, el usuario elige una carpeta con archivos `.fit` (Storage Access Framework) y la app los **parsea localmente** con el FIT SDK de Garmin: extrae sesión, vueltas y registros, detecta duplicados por nombre de archivo y los sube a Firestore.

---

## 4. Estructura de navegación

```
¿Sesión iniciada?
├─ NO  → LoginScreen
└─ SÍ  → Main (Bottom Tabs)
   ├─ Dashboard (HomeScreen)
   ├─ Calendar (CalendarScreen)
   ├─ Análisis (AnalysisScreen)
   ├─ Messages → ⚠️ EmptyScreen (placeholder, sin desarrollar)
   └─ Settings (SettingsScreen)
        ├─ Profile          ├─ Coach (Mi Entrenador)
        ├─ SyncSettings     ├─ Zones
        ├─ AppSettings      ├─ Donaciones (Ko-fi)
        └─ Support
Pantallas extra en el stack: GarminLogin (legacy, en desuso)
Modales: AddWorkoutModal, WorkoutDetailModal
```

---

## 5. Pantalla a pantalla

### 🔐 LoginScreen
Firebase Auth: iniciar sesión, registro y recuperación de contraseña, con tabla de errores traducidos a español (`auth/invalid-credential`, `auth/too-many-requests`, etc.).

### 🏠 HomeScreen (Dashboard)
- Cabecera con avatar (foto en base64 del perfil), nombre y fecha formateada según ajustes.
- **Pager deslizable de 3 páginas**: (0) gráfica Condición/Fatiga/Forma, (1) resumen semanal actual, (2) semana pasada. Si no hay datos de fitness, muestra banner invitando a conectar Intervals.icu.
- Secciones **"Entrenamiento de hoy" / "Mañana" / "Próximos eventos"** con estado por color (verde=completo, rojo=incompleto, gris=planificado).
- Botón de **sync manual** (Intervals, últimos 30 días, timeout 120 s) y pull-to-refresh.
- **Modo entrenador**: si hay un `currentAthleteId` en AsyncStorage, toda la app muestra los datos de ese atleta, con botón para volver a "yo".
- Perfil con **caché instantánea + suscripción en tiempo real (onSnapshot) + reintento con backoff**.
- Registro de push notifications (token Expo guardado en `perfiles/{uid}`).

### 📅 CalendarScreen
- Calendario semanal con navegación entre semanas e indicadores de wellness por día.
- **Drag & drop real**: pulsación larga y arrastre de un entreno a otro día (con auto-scroll en los bordes y snapshot del layout), que actualiza `fecha`/`fechaStr` en Firestore.
- Caché de 5 minutos para no reconsultar en cada cambio de pestaña.

### 📊 AnalysisScreen
- **Dashboard de gráficas 100 % personalizable**: catálogo de 25+ tipos en 5 secciones:
  - *Entrenamiento*: rendimiento, distancia, duración, esfuerzo/carga, FC media, elevación, potencia.
  - *Zonas*: tiempo en zonas de FC, ritmo y potencia.
  - *Curvas*: mejores esfuerzos de ritmo, FC, potencia y cadencia en 9 duraciones (1m→2h).
  - *Récords*: mayor distancia, entreno más largo, mejor ritmo medio, mayor carga semanal.
  - *Métricas corporales*: sueño y su puntuación, FC máx/reposo, VO2max, FTP, LTHR, ritmo umbral, calorías, VFC, SpO2, pasos.
- Agrupación **Diario/Semanal/Mensual/Año** y periodos de 30 días a "Todo".
- **Reordenación de gráficas** con persistencia del layout en `analysis/{uid}`.
- Bilingüe (etiquetas ES/EN).

### 🧠 analyticsEngine.js (el "cerebro", 1.345 líneas)
- Construye el historial por día fusionando entrenamientos reales + planificados (convierte los pasos estructurados en km/segundos planificados, con repeticiones y unidades km/m/mi/yd) + wellness.
- `getStreamsStats`: recorre los puntos segundo a segundo de cada actividad para calcular tiempo en zonas (FC y ritmo, con zona "Fuera") y las curvas de mejores esfuerzos.
- `buildSeries`: agrega todo en buckets por día/semana/mes/año con promedios ponderados.
- **Sistema de caché en 3 niveles**: memoria (TTL 5 min) + AsyncStorage versionado (`CACHE_V=3`, invalidación automática) + ventana incremental de 60 días (solo re-consulta lo reciente; el historial viejo se calcula una vez).

### 👥 CoachScreen (Mi Entrenador)
- **Atleta**: introduce el email de su entrenador → `POST /solicitar-entrenador` (backend de Render).
- **Entrenador**: ve solicitudes pendientes, acepta (`/gestionar-solicitud`) y obtiene su lista de atletas (`/coach-screen-data/{uid}`).
- Al pulsar un atleta, guarda `currentAthleteId` y navega al Dashboard → **toda la app pasa a mostrar los datos de ese atleta**.
- Ping de "calentamiento" al servidor Render (plan gratuito) al arrancar la app.
- Caché de 5 min en AsyncStorage (`coachCache`).

### ❤️ ZonesScreen
Editor de zonas guardado en `perfiles/{uid}`:
- **FC**: 5 zonas según FC máxima o LTHR.
- **Ritmo**: R0–R6 a partir del ritmo umbral.
- **Potencia**: Z1–Z6 (modelo Coggan) según umbral de potencia.

### 📋 AddWorkoutModal (crear entreno)
- Tipo de actividad (Running, Ciclismo, Natación, Fuerza, Triatlón, Evento, Descanso, Otro) con icono y color.
- Título, fecha, descripción.
- **StepEditor**: editor de entrenamiento estructurado estilo Garmin — pasos (Calentamiento, Extensivo, Intensivo, Variable, Recuperación, Técnico, Enfriarse…) con duración por distancia/tiempo/botón de vuelta, repeticiones, objetivos (ritmo, FC, potencia, zonas, cadencia, elevación…) y **sub-pasos anidados**.
- **Librería**: guardar el entreno como plantilla, reutilizarla (conta `timesUsed`), buscar y ordenar.

### 🔍 WorkoutDetailModal (803 líneas, la más completa)
- **Gráficas de la actividad** (ActivityChart en Skia: FC, ritmo, potencia, cadencia, elevación) con modal a pantalla completa y giro horizontal.
- **Mapa GPS** (GpsMap: Leaflet en WebView, ruta decimada a ≤5000 puntos, control de vueltas).
- Marcar estado (completo/incompleto/planificado), editar datos de la sesión (duración, distancia, FC, ritmo, cadencia, desnivel, temperatura…).
- **RPE** (carga percibida: Muy baja→Muy alta), **sensación** (emojis 😫→😁), notas y enlace.
- **Comentarios entrenador↔atleta** con **notificación push** al atleta (`POST /notify-athlete` vía backend de Vercel).
- Editar la estructura de pasos, guardar en librería, borrar entreno.

### ⚙️ SettingsScreen
Menú (Perfil, Sincronización, Zonas, Donaciones, Mi Entrenador, Ajustes, Soporte), toggle de notificaciones, selector de contraste/tema y **tarjeta compartible** de la app (ViewShot oculto → imagen → expo-sharing).

### 🔧 AppSettingsScreen
Idioma (ES/EN), unidades (métrica/imperial), formato de fecha (4 opciones) y tema (día/noche/dispositivo). Todo en un store propio con `useSyncExternalStore` que re-renderiza la app al vuelo.

### 🔗 SyncSettingsScreen
Guías paso a paso + conexión de **Intervals.icu** (Athlete ID + API key, validar, desconectar) y **carpeta .fit local** (selección de carpeta SAF, sync ahora, reset).

### 🆘 SupportScreen y 💝 DonationScreen
Soporte: formulario que guarda en `soporte` **y** envía email vía **Web3Forms**. Donaciones: enlace a Ko-fi (`ko-fi.com/pablotrabalon`).

### 👤 ProfileScreen
Foto de perfil (galería + compresión con expo-image-manipulator → base64 en Firestore), datos personales, cerrar sesión y **eliminar cuenta** (borra datos y relación con entrenador vía backend, con requisito de sesión reciente de Firebase).

---

## 6. Componentes propios

| Componente | Qué hace |
|---|---|
| **FitnessChart** | CTL (Condición) / ATL (Fatiga) / Forma — Victory+Skia, diezmado inteligente (160-400 pts, tope 365 días), modal horizontal con tooltip |
| **WeeklyKmChart** | Barras por día de la semana; métricas: distancia, duración, carga y "resumen" (zona de ritmo del día, kcal, altura…); planificado vs completado con % |
| **ActivityChart** | Gráfica multiserie pura Skia de los registros de una actividad (ejes con "nice step", diezmado a 400 pts, pantalla completa) |
| **GpsMap** | WebView + Leaflet/OSM con la ruta GPS, decimación a 5000 pts y selector de vueltas |
| **StepEditor** | Editor de pasos estructurados con hijos, repeticiones, objetivos y unidades |

---

## 7. Build y despliegue

- **EAS Build**: `development` (APK dev-client), `preview` (APK distribución interna), `production` (auto-incremento de versión).
- **EAS Update / expo-updates**: OTA configurado (`runtimeVersion: appVersion`, canales por perfil de build) — puedes actualizar JS sin pasar por tienda.
- La carpeta `dist/` del ZIP (41 MB) es la salida de `npx expo export` (bundles `.hbc` de Android/iOS/web) — **es generable, no hace falta versionarla**.
- Android: `google-services.json` presente (push FCM). iOS: bundle `com.teamjorge.app`.

---

## 8. Estado actual: lo que está hecho ✅

1. Autenticación completa (login/registro/reset) con persistencia real en AsyncStorage.
2. Doble vía de importación de actividades: Intervals.icu (automática) y archivos FIT locales (parseo on-device).
3. Dashboard con gráfica de condición física y resúmenes semanales.
4. Calendario semanal con drag & drop entre días.
5. Motor de análisis completo con 25+ gráficas configurables, zonas, curvas de mejores esfuerzos y récords.
6. Entrenamientos estructurados por pasos + librería de plantillas.
7. Detalle de actividad con gráficas Skia, mapa GPS, RPE, sensación y notas.
8. Sistema entrenador-atleta: solicitudes, vista de atleta y comentarios con push.
9. Zonas de FC/ritmo/potencia editables con umbrales.
10. i18n ES/EN, temas claro/oscuro, unidades y formatos de fecha.
11. Cachés agresivas en 3 niveles para que la app vuele y ahorre lecturas de Firestore.
12. Soporte (Web3Forms) y donaciones (Ko-fi).
13. Perfil con foto, cierre de sesión y eliminación de cuenta.
14. Pipeline de release completo (EAS Build + OTA updates).

## 9. Pendientes / limpieza sugerida 🧹

1. **Pestaña "Messages"**: es un `EmptyScreen` — el chat entrenador-atleta está sin desarrollar (hoy la comunicación va por comentarios en cada entreno).
2. **Pantallas legacy**: `GarminLoginScreen` guarda credenciales Garmin que la propia Home borra al arrancar; `GarminUploadService` está desactivado a propósito. Se pueden eliminar.
3. **Restos de la plantilla de Expo** (sin usar, se pueden borrar): carpeta `app/`, `components/*.tsx` (hello-wave, haptic-tab, themed-*…), `hooks/`, `constants/theme.ts`, `scripts/reset-project.js`, README por defecto.
4. **Dependencias muertas en package.json** (no se importan en ningún sitio): `@supabase/supabase-js`, `expo-background-fetch`, `expo-task-manager`, `expo-document-picker`, `expo-auth-session`, `fit-decoder`, `fit-file-parser`, `react-native-chart-kit`, `react-native-graph`. Quitarlas aligera el build.
5. **`dist/` y `.expo/` en el ZIP/repo**: son generables; añádelos a `.gitignore` (junto a `node_modules`).
6. **Seguridad**:
   - La API key de Firebase en el cliente es normal, pero **protege Firestore con reglas** (que un atleta no pueda leer/reescribir datos de otro) y activa **App Check**.
   - La clave de Web3Forms va embebida (es el uso previsto del servicio, pero cualquiera puede extraerla del bundle).
   - Ojo con subir `google-services.json` y `firebaseConfig.js` a repos públicos (ya está en GitHub ahora mismo).
7. **README**: sigue siendo el de la plantilla; convendría documentar la app, los backends (Vercel/Render) y el flujo de release.
8. **Sin tests**: no hay ningún test automatizado.
9. Los dos backends (Vercel y Render) **no están en este repo** — son piezas críticas que convendría versionar también.

---

## 10. Resumen en una frase

Tienes una app de entrenamiento **muy completa y bien pensada** (nivel producto real, no prototipo): Expo + Firebase + dos micro-backends, con sync Garmin vía Intervals.icu o FIT local, análisis deportivos avanzados calculados en el móvil con cachés en 3 niveles, entrenador-atleta con push, i18n, temas y pipeline de release con OTA — y como pendientes principales: la pestaña de mensajes, limpiar código legacy/plantilla y endurecer las reglas de seguridad de Firestore.

---

## 11. Esfuerzo (TSS): por qué la app daba 27 y TrainingPeaks 83  🔎 (2026-09-19)

**Síntoma:** el mismo entreno marcaba TSS 83 en TrainingPeaks y 27 en la app.

**Causa raíz A — app (importación .fit), `services/SyncService.js`:**
`computeEsfuerzo()` usaba `perfil.umbralFC` como *umbral de FC* (LTHR), pero en
esta app ese campo es la **FC máxima** (pantalla Zonas → "FC máxima"). Con
`lthr == FCmáx` la guarda `hrMax > lthr` no se cumple nunca ⇒ la rama hrTSS se
descartaba SIEMPRE y se caía al último recurso `totalTrainingEffect × 20`.
`1.35 × 20 = 27`. Reproducido y verificado con un test.

**Causa raíz B — servidor (sync intervals.icu):**
`strain_score ?? suffer_score ?? load ?? training_load`. `strain_score` es el
**Xert Strain Score (xSS)** y `suffer_score` el **Suffer Score de Strava**: NO son
TSS. Además, una vez guardado un valor > 0 el código no lo rectificaba nunca, así
que el error se quedaba fijo en Firestore.

**Causa raíz C:** no se calculaba **rTSS** (por ritmo), que es lo que usa
TrainingPeaks en carrera a pie. Con ritmo umbral 5:30/km, el entreno de 47:54 y
8,8 km da rTSS **82** vs **83** de TrainingPeaks. ✅

**Correcciones aplicadas:**
- `lib/intervals.js`: helpers compartidos `pickTrainingLoad()` (sólo
  `icu_training_load` / `training_load`, escala TSS) y `effortNeedsUpdate()`
  (rectifica lo guardado salvo `esfuerzoManual === true`).
- `api/sync-intervals.js`: corrige el esfuerzo en cada sync + pasada histórica
  única (`esfuerzoFixDone`, ≤400 inspecciones / ≤80 escrituras). Devuelve
  `esfuerzoCorregidos`.
- `lib/intervalsDetail.js` y `lib/fitness.js`: mismo criterio TSS (la curva
  Fitness/Fatigue ya no mezcla baremos).
- `services/SyncService.js`: `computeEsfuerzo()` reescrito → devuelve
  `{ valor, fuente }`; FC máxima real (perfil `umbralFC` → Tanaka), LTHR desde
  `perfil.fcUmbral` → zonas de FC → 90 % FCmáx; **rTSS** por ritmo umbral;
  hrTSS con TRIMP de Banister normalizado; TE×20 sólo como último recurso.
  Nuevos exports `calcularEsfuerzoDesdeResumen()` y `recalcularEsfuerzos()`.
- `screens/ZonesScreen.js`: nuevo campo **"FC umbral (LTHR)"** (`perfil.fcUmbral`).
- `screens/WorkoutDetailModal.js`: botón **"⟳ Recalcular"** + texto
  **"Fuente: …"**, y marca `esfuerzoManual` cuando el usuario edita a mano.
- `screens/SyncSettingsScreen.js`: botón **"Recalcular esfuerzo de mis entrenos"**
  (corrige el histórico importado por .fit sin reimportar).

**Nuevo campo en Firestore:** `esfuerzoFuente` (`'intervals.icu' | 'archivo' |
'potencia' | 'ritmo' | 'fc' | 'training-effect' | 'manual'`) y `esfuerzoManual`.
