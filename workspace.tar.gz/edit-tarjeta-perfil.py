# -*- coding: utf-8 -*-
# Rediseña la tarjeta de perfil compartible de SettingsScreen.js:
#  - ViewShot captura EXACTAMENTE el tamaño de la tarjeta (sin bordes negros laterales)
#  - Artwork 4:5 con SVG de fondo (degradado, halo, carriles de pista, puntos,
#    líneas de velocidad, texto fantasma, esquinas enmarcadas, viñeta)
#  - Logo de la app en pegatina, foto con anillo doble + aro punteado,
#    nombre a dos tintas con subrayado a mano (Kalam-Bold) y píldora de email.
import io, os, re, sys

WS = os.environ.get("ARENA_WORKSPACE", "/home/user")
PATH = os.path.join(WS, "proyecto/mi-app-entrenos/screens/SettingsScreen.js")

src = open(PATH, "rb").read().decode("utf-8")
CRLF = "\r\n" in src
if CRLF:
    src = src.replace("\r\n", "\n")

def rep(old, new, count=1):
    global src
    assert old in src, "NO ENCONTRADO: " + old[:80]
    src = src.replace(old, new, count)

# ── 1) Imports: react-native-svg + expo-font ────────────────────────────────
rep(
"""import ViewShot from 'react-native-view-shot';
import { auth, db } from '../firebaseConfig';""",
"""import ViewShot from 'react-native-view-shot';
import Svg, {
  Circle, Defs, G, LinearGradient, Path, RadialGradient, Rect, Stop,
  Text as SvgText,
} from 'react-native-svg';
import { useFonts } from 'expo-font';
import { auth, db } from '../firebaseConfig';""")

# ── 2) Constantes de marca + dimensiones de la tarjeta ─────────────────────
rep(
"""const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';""",
"""const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';

/* ── Tarjeta compartible: formato artwork 4:5 y paleta de marca (logo) ── */
const APP_ICON  = require('../assets/images/icon.png');
const CARD_W    = 400;   // puntos; se captura con pixelRatio 3 → 1200×1560 px
const CARD_H    = 520;
const GREEN     = '#7BC86C';  // verde claro del logo (tema noche)
const GREEN_DK  = '#2F6B3A';  // verde oscuro del logo
const GREEN_LT  = '#8FE08A';  // verde vivo para el anillo
const INK       = '#0C1310';  // carbón del fondo de la tarjeta""")

# ── 3) Carga de la fuente manuscrita del logo también en esta pantalla ─────
rep(
"""  const theme = getThemeColors(appSettings.themeMode, useColorScheme());""",
"""  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  useFonts({ 'Kalam-Bold': require('../assets/fonts/Kalam-Bold.ttf') });""")

# ── 4) Captura nítida y al tamaño exacto de la tarjeta ─────────────────────
rep(
"""        const uri = await shareCardRef.current.capture({
          format: 'png',
          quality: 1,
        });""",
"""        const uri = await shareCardRef.current.capture({
          format: 'png',
          quality: 1,
          pixelRatio: 3,   // 400×520 pt → PNG de 1200×1560 px, nítido al compartir
        });""")

# ── 5) JSX de la tarjeta: sustitución completa ──────────────────────────────
old_jsx = src[src.index("      {/* ── TARJETA OCULTA PARA COMPARTIR"):src.index("      </ViewShot>") + len("      </ViewShot>")]
new_jsx = """      {/* ── TARJETA OCULTA PARA COMPARTIR ──
          El ViewShot mide EXACTAMENTE lo que mide la tarjeta (CARD_W×CARD_H):
          así el PNG sale recortado al arte y sin franjas negras laterales. */}
      <ViewShot
        ref={shareCardRef}
        options={{ format: 'png', quality: 1, pixelRatio: 3 }}
        style={styles.shareCardWrapper}
      >
        <View style={styles.shareCard}>
          {/* ══ FONDO ARTÍSTICO (SVG): degradado carbón→verde, halo bajo la
               foto, carriles de pista, líneas de velocidad, rejilla de
               puntos, rúbrica fantasma vertical, esquinas y viñeta ══ */}
          <Svg width={CARD_W} height={CARD_H} style={styles.shareArt}>
            <Defs>
              <LinearGradient id="tjBg" x1="0" y1="0" x2="1" y2="1">
                <Stop offset="0" stopColor="#12211A" />
                <Stop offset="0.5" stopColor={INK} />
                <Stop offset="1" stopColor="#070B09" />
              </LinearGradient>
              <RadialGradient id="tjGlow" cx="0.5" cy="0.5" r="0.5">
                <Stop offset="0" stopColor="#5FCE73" stopOpacity="0.32" />
                <Stop offset="0.6" stopColor="#3E9B52" stopOpacity="0.12" />
                <Stop offset="1" stopColor="#3E9B52" stopOpacity="0" />
              </RadialGradient>
              <RadialGradient id="tjVig" cx="0.5" cy="0.45" r="0.78">
                <Stop offset="0.55" stopColor="#000000" stopOpacity="0" />
                <Stop offset="1" stopColor="#000000" stopOpacity="0.48" />
              </RadialGradient>
            </Defs>

            <Rect width={CARD_W} height={CARD_H} fill="url(#tjBg)" />
            <Circle cx={CARD_W / 2} cy={210} r={190} fill="url(#tjGlow)" />

            {/* Carriles de pista concéntricos asomando por abajo-derecha */}
            {[70, 102, 134, 166, 198, 230].map((r, i) => (
              <Circle
                key={`pista-${r}`}
                cx={CARD_W + 34} cy={CARD_H + 26} r={r}
                fill="none" stroke={GREEN}
                strokeWidth={i === 2 ? 2 : 1.2}
                strokeOpacity={0.17 - i * 0.02}
                strokeDasharray={i === 4 ? '5 9' : undefined}
              />
            ))}
            {/* Ecos de la misma curva, arriba-izquierda, casi imperceptibles */}
            {[120, 152, 184].map((r, i) => (
              <Circle
                key={`eco-${r}`}
                cx={-34} cy={-24} r={r}
                fill="none" stroke={GREEN} strokeWidth={1}
                strokeOpacity={0.06 + i * 0.02}
              />
            ))}

            {/* Líneas de velocidad diagonales arriba-derecha */}
            <Path d={`M${CARD_W - 96} -8 L${CARD_W - 150} 120`} stroke={GREEN} strokeWidth={2} strokeOpacity={0.30} />
            <Path d={`M${CARD_W - 72} -8 L${CARD_W - 126} 120`} stroke={GREEN} strokeWidth={2} strokeOpacity={0.18} />
            <Path d={`M${CARD_W - 48} -8 L${CARD_W - 102} 120`} stroke={GREEN} strokeWidth={2} strokeOpacity={0.10} />

            {/* Rejilla de puntos (textura) abajo-izquierda */}
            {Array.from({ length: 5 }).map((_, row) =>
              Array.from({ length: 7 }).map((__, col) => (
                <Circle
                  key={`dot-${row}-${col}`}
                  cx={26 + col * 14} cy={CARD_H - 100 + row * 14} r={1.5}
                  fill={GREEN} fillOpacity={0.16}
                />
              ))
            )}

            {/* Rúbrica fantasma vertical con la fuente manuscrita del logo */}
            <G transform={`rotate(-90 36 ${CARD_H / 2})`}>
              <SvgText
                x={36} y={CARD_H / 2}
                fill="#FFFFFF" fillOpacity={0.05}
                fontSize={54} fontFamily="Kalam-Bold" textAnchor="middle"
              >
                TEAM JORGE
              </SvgText>
            </G>

            {/* Esquinas enmarcadas, como passe-partout de galería */}
            <Path d="M16 46 L16 16 L46 16" fill="none" stroke={GREEN} strokeWidth={2.5} strokeOpacity={0.85} />
            <Path
              d={`M${CARD_W - 16} ${CARD_H - 46} L${CARD_W - 16} ${CARD_H - 16} L${CARD_W - 46} ${CARD_H - 16}`}
              fill="none" stroke={GREEN} strokeWidth={2.5} strokeOpacity={0.85}
            />

            <Rect width={CARD_W} height={CARD_H} fill="url(#tjVig)" />
          </Svg>

          {/* ══ CABECERA: pegatina con el logo + firma manuscrita ══ */}
          <View style={styles.shareHeader}>
            <View style={styles.shareLogoSticker}>
              <Image source={APP_ICON} style={styles.shareLogoImg} resizeMode="contain" />
            </View>
            <View>
              <Text style={styles.shareBrand}>TEAM JORGE</Text>
              <View style={styles.shareBrandUnder} />
            </View>
          </View>

          {/* ══ FOTO: aro punteado exterior + anillo verde doble ══ */}
          <View style={styles.shareAvatarWrap}>
            <View style={styles.shareAvatarDashed} />
            <View style={styles.shareAvatarRingOut}>
              <View style={styles.shareAvatarRingIn}>
                {profilePhoto ? (
                  <Image
                    source={{ uri: `data:image/jpeg;base64,${profilePhoto}` }}
                    style={styles.shareAvatarImg}
                  />
                ) : user?.photoURL ? (
                  <Image source={{ uri: user.photoURL }} style={styles.shareAvatarImg} />
                ) : (
                  <View style={[styles.shareAvatarImg, styles.shareAvatarFallback]}>
                    <Text style={styles.shareAvatarInitial}>{initial}</Text>
                  </View>
                )}
              </View>
            </View>
          </View>

          {/* ══ NOMBRE a dos tintas + subrayado a mano ══ */}
          <Text style={[styles.shareName, { fontSize: nameSize(firstName) }]} numberOfLines={1}>
            {firstName}
          </Text>
          {!!apellido && (
            <Text style={[styles.shareLastName, { fontSize: nameSize(apellido) }]} numberOfLines={1}>
              {apellido}
            </Text>
          )}
          <View style={styles.shareUnderline} />
          <View style={styles.shareUnderline2} />
          <Text style={styles.shareTagline}>{L('ATLETA TEAM JORGE', 'TEAM JORGE ATHLETE')}</Text>

          {/* ══ PIE: píldora con el correo ══ */}
          <View style={styles.shareFooter}>
            <View style={styles.shareEmailPill}>
              <Ionicons name="mail-outline" size={12} color="#9DB8A4" />
              <Text style={styles.shareEmailText} numberOfLines={1}>{user?.email}</Text>
            </View>
          </View>
        </View>
      </ViewShot>"""
src = src.replace(old_jsx, new_jsx, 1)

# ── 6) Helper de tamaño de nombre (antes del return) ───────────────────────
rep(
"""  const initial = firstName.charAt(0).toUpperCase();""",
"""  const initial = firstName.charAt(0).toUpperCase();
  // El nombre se escala solo si es largo para que nunca se salga del arte
  const nameSize = (s) => ((s || '').length > 12 ? 24 : (s || '').length > 9 ? 28 : 34);""")

# ── 7) Estilos de la tarjeta: sustitución completa ─────────────────────────
old_st = src[src.index("  // ── Tarjeta para compartir (oculta) ──"):src.index("  shareBadgeText: {") ]
old_st = old_st + src[src.index("  shareBadgeText: {"):src.index("});", src.index("  shareBadgeText: {"))]
new_st = """  // ── Tarjeta para compartir: artwork 4:5, se captura tal cual ──
  shareCardWrapper: {
    position: 'absolute',
    top: -1200,                 // fuera de pantalla; ya no sobra ancho alrededor
    left: 0,
    width: CARD_W,
    height: CARD_H,
    backgroundColor: 'transparent',
    overflow: 'hidden',
  },
  shareCard: {
    width: CARD_W,
    height: CARD_H,
    backgroundColor: INK,
    alignItems: 'center',
    overflow: 'hidden',
  },
  shareArt: { position: 'absolute', top: 0, left: 0 },
  shareHeader: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    alignSelf: 'stretch', paddingHorizontal: 28, paddingTop: 28,
  },
  shareLogoSticker: {
    width: 40, height: 40, borderRadius: 10,
    backgroundColor: '#F4F6F2', alignItems: 'center', justifyContent: 'center',
    // leve giro de pegatina colocada a mano
    transform: [{ rotate: '-3deg' }],
    shadowColor: '#000', shadowOpacity: 0.35, shadowRadius: 6, shadowOffset: { width: 0, height: 3 },
  },
  shareLogoImg: { width: 32, height: 32 },
  shareBrand: {
    color: '#F2F5F0', fontSize: 18, fontFamily: 'Kalam-Bold', letterSpacing: 1,
  },
  shareBrandUnder: {
    height: 3, width: 66, backgroundColor: GREEN, borderRadius: 2,
    marginTop: 1, transform: [{ rotate: '-1.5deg' }],
  },
  shareAvatarWrap: {
    width: 172, height: 172, marginTop: 24,
    alignItems: 'center', justifyContent: 'center',
  },
  shareAvatarDashed: {
    position: 'absolute', width: 172, height: 172, borderRadius: 86,
    borderWidth: 1.5, borderStyle: 'dashed', borderColor: GREEN + '59',
  },
  shareAvatarRingOut: {
    width: 148, height: 148, borderRadius: 74,
    backgroundColor: GREEN_LT, borderWidth: 1, borderColor: GREEN_DK,
    alignItems: 'center', justifyContent: 'center',
  },
  shareAvatarRingIn: {
    width: 140, height: 140, borderRadius: 70, backgroundColor: INK,
    alignItems: 'center', justifyContent: 'center',
  },
  shareAvatarImg: { width: 130, height: 130, borderRadius: 65 },
  shareAvatarFallback: { backgroundColor: GREEN_DK, alignItems: 'center', justifyContent: 'center' },
  shareAvatarInitial: { color: '#fff', fontSize: 54, fontWeight: '800', fontFamily: 'Kalam-Bold' },
  shareName: {
    color: '#F5F8F4', fontWeight: '900', letterSpacing: 1.5,
    textTransform: 'uppercase', marginTop: 18,
    maxWidth: CARD_W - 56, textAlign: 'center',
  },
  shareLastName: {
    color: GREEN, fontWeight: '900', letterSpacing: 1.5,
    textTransform: 'uppercase', marginTop: -2,
    maxWidth: CARD_W - 56, textAlign: 'center',
  },
  shareUnderline: {
    height: 4, width: 118, backgroundColor: GREEN, borderRadius: 3,
    marginTop: 10, transform: [{ rotate: '-1.5deg' }],
  },
  shareUnderline2: {
    height: 3, width: 68, backgroundColor: GREEN + '77', borderRadius: 3,
    marginTop: 3, transform: [{ rotate: '-1.5deg' }],
  },
  shareTagline: {
    color: '#9DB8A4', fontSize: 11, fontWeight: '600',
    letterSpacing: 4, marginTop: 12, textTransform: 'uppercase',
  },
  shareFooter: { position: 'absolute', bottom: 26, alignSelf: 'center', maxWidth: CARD_W - 48 },
  shareEmailPill: {
    flexDirection: 'row', alignItems: 'center', gap: 7,
    backgroundColor: '#FFFFFF10', borderWidth: 1, borderColor: '#FFFFFF1A',
    borderRadius: 999, paddingHorizontal: 14, paddingVertical: 7,
  },
  shareEmailText: { color: '#B9CBBE', fontSize: 11.5, letterSpacing: 0.4 },
"""
src = src.replace(old_st, new_st, 1)

if CRLF:
    src = src.replace("\n", "\r\n")
open(PATH, "wb").write(src.encode("utf-8"))
print("OK SettingsScreen.js tarjeta rediseñada", len(src), "bytes")
