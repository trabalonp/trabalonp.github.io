#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Ajuste: detección de deporte en computeEsfuerzo (FIT usa sport='running' y
subSport='trail_running'/'treadmill_running'…; mapSport solo mira `sport`)."""
import io
import os

BASE = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(BASE, 'proyecto', 'mi-app-entrenos', 'services', 'SyncService.js')

with io.open(P, 'r', encoding='utf-8', newline='') as f:
    s = f.read()
nl = '\r\n' if '\r\n' in s else '\n'
s = s.replace(nl, '\n')

OLD = """  const tipoSesion = mapSport(session.sport);
"""
NEW = """  // En FIT, `sport` trae 'running'/'cycling'/'swimming' y `subSport` afina
  // ('trail_running', 'treadmill_running', 'mountain_biking'…), así que se
  // miran los dos para saber si es carrera a pie.
  const tipoSesion = mapSport(session.sport);
  const deporteRaw = `${session.sport ?? ''} ${session.subSport ?? ''}`.toLowerCase();
  const esCarrera = tipoSesion === 'Running' || /run/.test(deporteRaw);
"""
assert s.count(OLD) == 1, s.count(OLD)
s = s.replace(OLD, NEW, 1)

OLD2 = """  if (tipoSesion === 'Running' && durSec > 0) {"""
NEW2 = """  if (esCarrera && durSec > 0) {"""
assert s.count(OLD2) == 1, s.count(OLD2)
s = s.replace(OLD2, NEW2, 1)

with io.open(P, 'w', encoding='utf-8', newline='') as f:
    f.write(s.replace('\n', nl))
print('OK SyncService.js (detección de carrera a pie)')
