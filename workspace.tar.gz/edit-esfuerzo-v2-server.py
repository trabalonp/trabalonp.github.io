#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Corrección del ESFUERZO (TSS) en el servidor Vercel.

Causa raíz: se leían campos de intervals.icu que NO son TSS
(strain_score = Xert xSS, suffer_score = Strava Suffer Score) antes que
icu_training_load. Esos baremos no son comparables con el TSS de
TrainingPeaks => la app mostraba 27 donde TrainingPeaks muestra 83.
Además, una vez guardado un valor >0 el código nunca lo rectificaba,
así que el 27 se quedaba para siempre.
"""
import io
import os
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(BASE, 'vercel-server', 'mi-app-entrenos-main')


def read(rel):
    with io.open(os.path.join(ROOT, rel), 'r', encoding='utf-8') as f:
        return f.read()


def write(rel, text):
    with io.open(os.path.join(ROOT, rel), 'w', encoding='utf-8', newline='') as f:
        f.write(text)


def replace_once(text, old, new, etiqueta):
    n = text.count(old)
    if n != 1:
        raise SystemExit('ERROR [%s]: se esperaba 1 coincidencia y hay %d' % (etiqueta, n))
    return text.replace(old, new, 1)


# ══════════════════════════════════════════════════════════════════════
# 1) lib/intervals.js  →  helpers compartidos de esfuerzo (TSS)
# ══════════════════════════════════════════════════════════════════════
p = 'lib/intervals.js'
s = read(p)

HELPERS = '''
// ─────────────────────────────────────────────────────────────────────
// ESFUERZO (TSS): única fuente de verdad para todo el servidor
//
// intervals.icu devuelve varias métricas de carga con baremos DISTINTOS:
//   • icu_training_load / training_load → equivalente TSS. Es el "Load" que
//     muestra intervals.icu y el que coincide con TrainingPeaks (83, 55, 101…).
//   • strain_score  → Xert Strain Score (xSS). Otro baremo.
//   • suffer_score  → Suffer Score de Strava. Otro baremo.
//   • trimp / hr_load / pace_load → valores intermedios sin normalizar.
//
// Las versiones anteriores usaban
//   `strain_score ?? suffer_score ?? load ?? training_load`
// de modo que se quedaban con el xSS de Xert o con el Suffer Score de Strava
// ANTES que con el TSS: por eso la app marcaba 27 en un entreno que en
// TrainingPeaks era 83. Ahora sólo se leen campos con escala TSS.
// ─────────────────────────────────────────────────────────────────────
const TSS_KEYS = ['icu_training_load', 'training_load'];

/**
 * Devuelve { valor, fuente } con el TSS de una actividad, o null si no hay
 * ningún valor válido. Se toma el primero > 0 (no se usa una cadena de `??`
 * porque un 0 no es nullish y cortaría la cadena).
 */
function pickTrainingLoad(activity) {
  for (const k of TSS_KEYS) {
    const v = Number(activity && activity[k]);
    if (Number.isFinite(v) && v > 0) return { valor: Math.round(v), fuente: k };
  }
  return null;
}

/**
 * Decide si el esfuerzo guardado en Firestore debe sustituirse por el TSS de
 * intervals.icu. Nunca se pisa un valor editado a mano por el usuario
 * (esfuerzoManual === true); el resto se alinea SIEMPRE con intervals.icu,
 * incluidos los valores que escribieron las versiones antiguas leyendo un
 * campo equivocado. Así intervals.icu sigue siendo la fuente de verdad y,
 * si el atleta cambia su FTP/zonas allí, la app se actualiza sola.
 */
function effortNeedsUpdate(guardado, correcto, manual) {
  if (manual === true) return false;
  const c = Number(correcto);
  if (!Number.isFinite(c) || c <= 0) return false;
  const a = Number(guardado);
  if (!Number.isFinite(a) || a <= 0) return true;
  return Math.round(a) !== Math.round(c);
}

module.exports = {
  getConnection,
  fetchAthlete,
  fetchActivities,
  mapIntervalsSport,
  paceFromSpeed,
  pickTrainingLoad,
  effortNeedsUpdate,
  TSS_KEYS
};
'''

OLD_EXPORTS = '''module.exports = {
  getConnection,
  fetchAthlete,
  fetchActivities,
  mapIntervalsSport,
  paceFromSpeed
};'''

s = replace_once(s, OLD_EXPORTS, HELPERS.strip('\n'), 'intervals.exports')
write(p, s)
print('OK lib/intervals.js')


# ══════════════════════════════════════════════════════════════════════
# 2) api/sync-intervals.js
# ══════════════════════════════════════════════════════════════════════
p = 'api/sync-intervals.js'
s = read(p)

s = replace_once(
    s,
    """const {
  getConnection,
  fetchActivities,
  mapIntervalsSport,
  paceFromSpeed,
} = require('../lib/intervals');""",
    """const {
  getConnection,
  fetchActivities,
  mapIntervalsSport,
  paceFromSpeed,
  pickTrainingLoad,
  effortNeedsUpdate,
} = require('../lib/intervals');""",
    'sync.require',
)

OLD_BLOCK = """// ── Esfuerzo (TSS) desde la respuesta de Intervals.icu ──
// `training_load` es la estimación propia de intervals.icu (equivalente TSS,
// mismos valores que TrainingPeaks: 83, 55, 101…). Se toma el PRIMER valor
// numérico >0: no se usa una cadena de `??` porque un 0 en un campo anterior
// la cortaría (0 no es nullish) y el esfuerzo quedaba siempre a 0.
const LOAD_KEYS = ['training_load', 'icu_training_load', 'strain_score', 'suffer_score', 'load'];

function pickTrainingLoad(activity) {
  for (const k of LOAD_KEYS) {
    const v = Number(activity?.[k]);
    if (Number.isFinite(v) && v > 0) return Math.round(v);
  }
  return null;
}
"""

NEW_BLOCK = """// ── Esfuerzo (TSS) ──
// pickTrainingLoad() y effortNeedsUpdate() viven en lib/intervals.js para que
// sync, detalle y fitness usen SIEMPRE el mismo criterio. Sólo se leen campos
// con escala TSS (icu_training_load / training_load): strain_score (Xert xSS)
// y suffer_score (Strava) son baremos distintos y provocaban que la app
// mostrara 27 donde TrainingPeaks mostraba 83.
"""

s = replace_once(s, OLD_BLOCK, NEW_BLOCK, 'sync.helpers')

s = replace_once(
    s,
    """    let detailOps = 0;
    let backfilled = 0;""",
    """    let detailOps = 0;
    let backfilled = 0;
    let corregidos = 0;""",
    'sync.counters',
)

OLD_BF = """          // ── Backfill de esfuerzo SIN llamadas HTTP extra ──
          // La lista de actividades ya trae training_load: si el documento no
          // tiene un valor válido, se guarda en detalles y en el doc principal
          // (la analítica de la app lo lee desde ahí). No pisa valores manuales.
          const loadLista = pickTrainingLoad(activity);
          if (loadLista != null) {
            try {
              const detSnapBf = await docRef.collection('detalles').doc('data').get();
              const detBf = detSnapBf.exists ? detSnapBf.data() : null;
              const detEsf = Number(detBf?.esfuerzo) > 0 ? Math.round(Number(detBf.esfuerzo)) : null;
              const mainEsf = Number(existing.data()?.esfuerzo) > 0 ? Math.round(Number(existing.data().esfuerzo)) : null;
              if (detEsf == null || mainEsf == null) {
                if (detEsf == null) {
                  await docRef.collection('detalles').doc('data').set({ esfuerzo: loadLista, tss: loadLista }, { merge: true });
                }
                if (mainEsf == null) {
                  await docRef.update({ esfuerzo: detEsf ?? loadLista });
                }
                backfilled++;
              }
            } catch (e) {
              console.warn(`[sync-intervals] Backfill esfuerzo ${activityId}:`, e.message);
            }
          }
"""

NEW_BF = """          // ── Esfuerzo: alinea/rectifica con el TSS de intervals.icu ──
          // La lista de actividades ya trae icu_training_load, así que no hace
          // falta ninguna llamada HTTP extra. Si lo que hay en Firestore no
          // coincide, se corrige en `detalles` y en el documento principal (la
          // analítica y la insignia "E | 91" leen de ahí). Esto repara los
          // valores que escribieron las versiones antiguas leyendo strain_score
          // o suffer_score en vez del TSS. Nunca se pisa un esfuerzo editado a
          // mano en la app (esfuerzoManual === true).
          const loadLista = pickTrainingLoad(activity);
          if (loadLista) {
            try {
              const detSnapBf = await docRef.collection('detalles').doc('data').get();
              const detBf = detSnapBf.exists ? detSnapBf.data() : null;
              const mainBf = existing.data() || {};
              const manualBf = detBf?.esfuerzoManual === true || mainBf.esfuerzoManual === true;

              if (effortNeedsUpdate(detBf?.esfuerzo, loadLista.valor, manualBf)) {
                await docRef.collection('detalles').doc('data').set({
                  esfuerzo: loadLista.valor,
                  tss: loadLista.valor,
                  esfuerzoFuente: 'intervals.icu',
                }, { merge: true });
                backfilled++;
              }
              if (effortNeedsUpdate(mainBf.esfuerzo, loadLista.valor, manualBf)) {
                await docRef.update({ esfuerzo: loadLista.valor, esfuerzoFuente: 'intervals.icu' });
                corregidos++;
              }
            } catch (e) {
              console.warn(`[sync-intervals] Esfuerzo ${activityId}:`, e.message);
            }
          }
"""

s = replace_once(s, OLD_BF, NEW_BF, 'sync.backfill')

s = replace_once(
    s,
    """        const esfuerzoLoad = pickTrainingLoad(activity);
""",
    """        const esfuerzoLoad = pickTrainingLoad(activity);
        const esfuerzoVal = esfuerzoLoad ? esfuerzoLoad.valor : 0;
        const esfuerzoFuente = esfuerzoLoad ? 'intervals.icu' : null;
""",
    'sync.pick',
)

s = replace_once(
    s,
    """          estado: 'completo',
          esfuerzo: esfuerzoLoad ?? 0,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),""",
    """          estado: 'completo',
          esfuerzo: esfuerzoVal,
          esfuerzoFuente,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),""",
    'sync.maindoc',
)

s = replace_once(
    s,
    """          potenciaMedia,
          esfuerzo: esfuerzoLoad ?? 0,
          tss: esfuerzoLoad ?? 0,""",
    """          potenciaMedia,
          esfuerzo: esfuerzoVal,
          tss: esfuerzoVal,
          esfuerzoFuente,""",
    'sync.detalles',
)

OLD_HIST = s[s.index("    // ── 2c) Backfill histórico de esfuerzo"):s.index("    // ── 3) Recalcular serie Fitness/Fatigue/Form ──")]

NEW_HIST = """    // ── 2c) Corrección histórica de esfuerzo (una sola vez por conexión) ──
    // Recorre TODO el historial con una única llamada HTTP y alinea el esfuerzo
    // de cada documento con el TSS de intervals.icu (icu_training_load). Es lo
    // que repara de golpe los entrenos antiguos cuyo esfuerzo se calculó con
    // strain_score / suffer_score (baremos distintos del TSS: por ejemplo 27 en
    // vez de 83). Límites por pasada (400 inspecciones / 80 escrituras, en
    // paralelo de 20 en 20) para no agotar el tiempo de la función; el resto se
    // completa en syncs sucesivos hasta marcar esfuerzoFixDone.
    let backfillHistorico = 0;
    if (!connection.esfuerzoFixDone) {
      try {
        const bfActs = await fetchActivities(connection, '2015-01-01', toISODate(now));
        if (Array.isArray(bfActs)) {
          const candidatos = bfActs.filter((a) => a && a.id && pickTrainingLoad(a));
          const objetivo = candidatos.slice(0, 400);
          const listaCompleta = candidatos.length <= 400;
          let escritos = 0;
          for (let i = 0; i < objetivo.length && escritos < 80; i += 20) {
            const chunk = objetivo.slice(i, i + 20);
            const results = await Promise.all(chunk.map(async (act) => {
              const load = pickTrainingLoad(act);
              const ref = db.collection('entrenamientos').doc(`intervals_${act.id}`);
              try {
                const snap = await ref.get();
                if (!snap.exists) return false;
                const mainData = snap.data() || {};
                const detRef = ref.collection('detalles').doc('data');
                const detSnap = await detRef.get();
                const det = detSnap.exists ? detSnap.data() : null;
                const manual = det?.esfuerzoManual === true || mainData.esfuerzoManual === true;
                const faltaDet = effortNeedsUpdate(det?.esfuerzo, load.valor, manual);
                const faltaMain = effortNeedsUpdate(mainData.esfuerzo, load.valor, manual);
                if (!faltaDet && !faltaMain) return false;
                if (faltaDet) {
                  await detRef.set({
                    esfuerzo: load.valor,
                    tss: load.valor,
                    esfuerzoFuente: 'intervals.icu',
                  }, { merge: true });
                }
                if (faltaMain) {
                  await ref.update({ esfuerzo: load.valor, esfuerzoFuente: 'intervals.icu' });
                }
                return true;
              } catch (e) {
                return false;
              }
            }));
            escritos += results.filter(Boolean).length;
          }
          backfillHistorico = escritos;
          const done = listaCompleta && escritos < 80;
          if (done) {
            await db.collection('intervals_connections').doc(uid).update({
              esfuerzoFixDone: true,
              esfuerzoFixAt: admin.firestore.FieldValue.serverTimestamp(),
              esfuerzoBackfillDone: true,
            });
          }
          console.log(`[sync-intervals] Corrección histórica de esfuerzo: ${escritos} docs (completo=${done})`);
        }
      } catch (e) {
        console.warn('[sync-intervals] Corrección histórica de esfuerzo, error:', e.message);
      }
    }

"""

s = s.replace(OLD_HIST, NEW_HIST, 1)

s = replace_once(
    s,
    """      esfuerzoBackfill: backfilled + backfillHistorico,""",
    """      esfuerzoBackfill: backfilled + backfillHistorico,
      esfuerzoCorregidos: corregidos,""",
    'sync.response',
)

write(p, s)
print('OK api/sync-intervals.js')


# ══════════════════════════════════════════════════════════════════════
# 3) lib/intervalsDetail.js
# ══════════════════════════════════════════════════════════════════════
p = 'lib/intervalsDetail.js'
s = read(p)

s = replace_once(
    s,
    """// lib/intervalsDetail.js
const zlib = require('zlib');
""",
    """// lib/intervalsDetail.js
const zlib = require('zlib');
const { pickTrainingLoad, effortNeedsUpdate } = require('./intervals');
""",
    'detail.require',
)

OLD_ESF = """    // ── ESFUERZO (TSS): prioridad a training_load de intervals.icu ──
    // Es su estimación propia de carga (equivalente TSS: 83, 55, 101…).
    // Antes se usaba `strain_score ?? suffer_score ?? load ?? training_load`:
    // si uno de esos campos venía a 0, la cadena se cortaba (0 no es nullish)
    // y el esfuerzo quedaba siempre en 0. Ahora se toma el primer valor >0
    // y nunca se pisa un esfuerzo ya guardado (p. ej. editado a mano).
    let esfuerzoVal = null;
    for (const k of ['training_load', 'icu_training_load', 'strain_score', 'suffer_score', 'load']) {
      const v = rf(a[k]);
      if (v != null && v > 0) { esfuerzoVal = v; break; }
    }
    if (esfuerzoVal != null && !(Number(existing?.esfuerzo) > 0)) {
      extra.esfuerzo = Math.round(esfuerzoVal);
      extra.tss = extra.esfuerzo;
    }
"""

NEW_ESF = """    // ── ESFUERZO (TSS) ──
    // Sólo se leen campos con escala TSS (icu_training_load / training_load),
    // que es lo que muestra intervals.icu como "Load" y lo que coincide con el
    // TSS de TrainingPeaks. strain_score (Xert xSS) y suffer_score (Strava) son
    // baremos distintos: leerlos antes era lo que hacía que la app marcara 27
    // en un entreno que en TrainingPeaks era 83.
    // A diferencia de antes, aquí SÍ se rectifica un valor ya guardado cuando no
    // coincide con intervals.icu, salvo que el usuario lo haya editado a mano.
    const load = pickTrainingLoad(a);
    if (load && effortNeedsUpdate(existing?.esfuerzo, load.valor, existing?.esfuerzoManual)) {
      extra.esfuerzo = load.valor;
      extra.tss = load.valor;
      extra.esfuerzoFuente = 'intervals.icu';
    }
"""

s = replace_once(s, OLD_ESF, NEW_ESF, 'detail.esfuerzo')

OLD_MIRROR = """  // Refleja el esfuerzo en el documento principal (la analítica de la app
  // lo lee desde ahí). Solo si el principal aún no tiene un valor válido.
  const esfuerzoFinal = extra.esfuerzo != null
    ? extra.esfuerzo
    : (Number(existing?.esfuerzo) > 0 ? Math.round(Number(existing.esfuerzo)) : null);
  if (esfuerzoFinal != null) {
    try {
      const mSnap = await docRef.get();
      const mEsf = mSnap.exists ? Number(mSnap.data()?.esfuerzo) : 0;
      if (!(mEsf > 0)) {
        await docRef.set({ esfuerzo: esfuerzoFinal }, { merge: true });
      }
    } catch (e) {
      console.warn('[intervalsDetail] No se pudo reflejar esfuerzo en doc principal:', e.message);
    }
  }
"""

NEW_MIRROR = """  // Refleja el esfuerzo en el documento principal (la analítica y la insignia
  // "E | 91" de la app lo leen desde ahí). Se rectifica si no coincide, salvo
  // que el usuario lo haya editado a mano.
  const esfuerzoFinal = extra.esfuerzo != null
    ? extra.esfuerzo
    : (Number(existing?.esfuerzo) > 0 ? Math.round(Number(existing.esfuerzo)) : null);
  if (esfuerzoFinal != null) {
    try {
      const mSnap = await docRef.get();
      const mData = mSnap.exists ? (mSnap.data() || {}) : {};
      const manualMain = mData.esfuerzoManual === true || existing?.esfuerzoManual === true;
      if (effortNeedsUpdate(mData.esfuerzo, esfuerzoFinal, manualMain)) {
        await docRef.set({ esfuerzo: esfuerzoFinal, esfuerzoFuente: 'intervals.icu' }, { merge: true });
      }
    } catch (e) {
      console.warn('[intervalsDetail] No se pudo reflejar esfuerzo en doc principal:', e.message);
    }
  }
"""

s = replace_once(s, OLD_MIRROR, NEW_MIRROR, 'detail.mirror')

write(p, s)
print('OK lib/intervalsDetail.js')


# ══════════════════════════════════════════════════════════════════════
# 4) lib/fitness.js  →  CTL/ATL con el mismo criterio TSS
# ══════════════════════════════════════════════════════════════════════
p = 'lib/fitness.js'
s = read(p)

s = replace_once(
    s,
    "const { fetchActivities } = require('./intervals');",
    "const { fetchActivities, pickTrainingLoad } = require('./intervals');",
    'fitness.require',
)

s = replace_once(
    s,
    "    const load = Number(a.icu_training_load ?? a.load ?? a.training_load ?? 0) || 0;",
    """    // Mismo criterio que en el resto del servidor: sólo campos con escala TSS.
    // `a.load` no es un TSS y mezclaba baremos en la curva Fitness/Fatigue.
    const tl = pickTrainingLoad(a);
    const load = tl ? tl.valor : 0;""",
    'fitness.load',
)

write(p, s)
print('OK lib/fitness.js')

print('\nServidor actualizado.')
