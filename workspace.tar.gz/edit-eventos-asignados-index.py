#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Fix: events assigned via `asignados` not visible in the athlete's calendar.

Root cause: the query
    where('asignados','array-contains',uid) + where('fecha','>=',..) + where('fecha','<=',..)
requires a COMPOSITE INDEX in Firestore (asignados ASC, fecha ASC). That index does not
exist in the Firebase console, so getDocs(q2) fails with FAILED_PRECONDITION and the
error was silently swallowed by `catch(e){}` -> the athlete never sees the event.

Fix: drop the date-range filters from that query (a single-field array-contains uses the
automatic index that Firestore always creates) and filter the +/-30 day window client-side.
Also log the error instead of swallowing it silently.
"""
import os

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'proyecto', 'mi-app-entrenos')

def edit(path, pairs):
    full = os.path.join(BASE, path)
    with open(full, 'rb') as f:
        raw = f.read()
    crlf = b'\r\n' in raw
    text = raw.decode('utf-8')
    if crlf:
        text = text.replace('\r\n', '\n')
    for old, new in pairs:
        n = text.count(old)
        assert n == 1, f'{path}: expected 1 occurrence, found {n} for:\n{old[:150]}'
        text = text.replace(old, new)
    if crlf:
        text = text.replace('\n', '\r\n')
    with open(full, 'wb') as f:
        f.write(text.encode('utf-8'))
    print(f'OK {path} ({"CRLF" if crlf else "LF"})')

# ──────────────────────────── HomeScreen.js ────────────────────────────
home_old = "      try { const q2=query(collection(db,'entrenamientos'), where('asignados','array-contains',currentUserId), where('fecha','>=',Timestamp.fromDate(start)), where('fecha','<=',Timestamp.fromDate(end))); const s2=await getDocs(q2); s2.docs.forEach(d=>{ if(!lista.some(x=>x.id===d.id)) lista.push({ id:d.id, ...stripHeavyFields(d.data()) }); }); } catch(e){}"

home_new = """      try {
        // array-contains SIN rango de fechas: usa el indice automatico de un solo campo
        // (NO necesita indice compuesto en Firebase). El rango +/-30 dias se filtra en local.
        const q2=query(collection(db,'entrenamientos'), where('asignados','array-contains',currentUserId));
        const s2=await getDocs(q2);
        s2.docs.forEach(d=>{ const data=d.data(); const f=data.fecha?.toMillis?.() ?? null; if(f!=null && f>=start.getTime() && f<=end.getTime() && !lista.some(x=>x.id===d.id)) lista.push({ id:d.id, ...stripHeavyFields(data) }); });
      } catch(e){ console.log('Error eventos asignados:', e?.message || e); }"""

# ─────────────────────────── CalendarScreen.js ───────────────────────────
cal_old = """      try {
        const q2 = query(
          collection(db, 'entrenamientos'),
          where('asignados', 'array-contains', currentUserId),
          where('fecha', '>=', Timestamp.fromDate(start)),
          where('fecha', '<=', Timestamp.fromDate(end)),
        );
        const s2 = await getDocs(q2);
        s2.docs.forEach(d => { if (!lista.some(x => x.id === d.id)) lista.push({ id: d.id, ...stripHeavyFields(d.data()) }); });
      } catch (e) {}"""

cal_new = """      try {
        // array-contains SIN rango de fechas: usa el indice automatico de un solo campo
        // (NO necesita indice compuesto en Firebase). El rango +/-30 dias se filtra en local.
        const q2 = query(
          collection(db, 'entrenamientos'),
          where('asignados', 'array-contains', currentUserId),
        );
        const s2 = await getDocs(q2);
        s2.docs.forEach(d => {
          const data = d.data();
          const f = data.fecha?.toMillis?.() ?? null;
          if (f != null && f >= start.getTime() && f <= end.getTime() && !lista.some(x => x.id === d.id)) {
            lista.push({ id: d.id, ...stripHeavyFields(data) });
          }
        });
      } catch (e) {
        console.log('Error consultando eventos asignados:', e?.message || e);
      }"""

edit('screens/HomeScreen.js', [(home_old, home_new)])
edit('screens/CalendarScreen.js', [(cal_old, cal_new)])
print('Todo listo.')
