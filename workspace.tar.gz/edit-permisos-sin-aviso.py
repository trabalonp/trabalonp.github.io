#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Sin avisos: si no eres el creador, el botón Editar no aparece y el arrastre no
se activa. Cero Alerts de permisos.  (ejecutar con cwd = raíz del workspace)"""
import io, os

APP = os.path.join("proyecto", "mi-app-entrenos")

def rd(p):
    with io.open(p, encoding="utf-8", newline="") as f: return f.read()
def wr(p, s):
    with io.open(p, "w", encoding="utf-8", newline="") as f: f.write(s)
def rep(txt, old, new, n=1):
    c = txt.count(old)
    assert c == n, f"esperado {n}, encontrado {c}: {old[:90]!r}"
    return txt.replace(old, new)

W = os.path.join(APP, "screens", "WorkoutDetailModal.js")
t = rd(W)

# ── 1) Comentario de cabecera actualizado ────────────────────────────────────
t = rep(t,
"""  // ── Permisos de edición ──
  // Un entreno solo lo puede editar/borrar quien lo ha creado. Si el entrenador
  // me ha agregado a un evento (el documento tiene el userId del coach y mi uid
  // está en `asignados`), en mi calendario el botón \"Editar\" se ve atenuado y no
  // abre el modo edición. El coach sí puede editar cuando está viendo el
  // calendario de un atleta (athleteId distinto del suyo).""",
"""  // ── Permisos de edición ──
  // Un entreno solo lo puede editar/borrar quien lo ha creado. Si el entrenador
  // me ha agregado a un evento (el documento tiene el userId del coach y mi uid
  // está en `asignados`), en mi calendario simplemente NO aparece el botón
  // \"Editar\" y la tarjeta no se puede arrastrar: la acción no está disponible
  // y no se muestra ningún aviso. El coach sí puede editar cuando está viendo el
  // calendario de un atleta (athleteId distinto del suyo).""")

# ── 2) Botón Editar: no se renderiza si no hay permiso (sin Alert) ───────────
t = rep(t,
"""              <View style={s.headerSide}>
                {mode === 'view' && (
                  <TouchableOpacity
                    activeOpacity={puedeEditarEntreno ? 0.7 : 1}
                    onPress={() => {
                      if (!puedeEditarEntreno) {
                        // Atenuado: lo creó otra persona (p. ej. el entrenador que me agregó al evento)
                        Alert.alert(
                          L('No puedes editarlo', \"You can't edit it\"),
                          L('Solo quien ha creado el entrenamiento puede editarlo o borrarlo.', 'Only the person who created the workout can edit or delete it.')
                        );
                        return;
                      }
                      setMode('edit'); setMainTab('edit');
                    }}
                  >
                    <Text style={[s.editBtn, !puedeEditarEntreno && s.editBtnDisabled]}>{L('Editar','Edit')}</Text>
                  </TouchableOpacity>
                )}
              </View>""",
"""              <View style={s.headerSide}>
                {/* Sin permiso el botón no se muestra: la acción no existe */}
                {mode === 'view' && puedeEditarEntreno && (
                  <TouchableOpacity
                    activeOpacity={0.7}
                    onPress={() => { setMode('edit'); setMainTab('edit'); }}
                  >
                    <Text style={s.editBtn}>{L('Editar','Edit')}</Text>
                  </TouchableOpacity>
                )}
              </View>""")

# ── 3) Unificar criterio: puedeGestionarEvento -> puedeEditarEntreno ─────────
t = rep(t,
"""  // El coach puede gestionar los atletas del evento también cuando el evento
  // está creado en el calendario de un atleta (no solo en su propio perfil).
  const puedeGestionarEvento = workout.userId === miUid || esCoachContexto;
""", "")
t = rep(t,
"""                  {actividad === 'Evento' && puedeGestionarEvento && (""",
"""                  {actividad === 'Evento' && puedeEditarEntreno && (""")

# ── 4) Estilo ya sin uso ─────────────────────────────────────────────────────
t = rep(t,
""" editBtn:{color:BLUE,fontWeight:'700',fontSize:15,textAlign:'right'}, editBtnDisabled:{color:'#A9B8CC',opacity:0.55},""",
""" editBtn:{color:BLUE,fontWeight:'700',fontSize:15,textAlign:'right'},""")

wr(W, t)
print("OK WorkoutDetailModal.js escrito")

v = rd(W)
assert "editBtnDisabled" not in v, "queda editBtnDisabled"
assert "puedeGestionarEvento" not in v, "queda puedeGestionarEvento"
assert "No puedes editarlo" not in v, "queda el aviso de permiso"
assert "Acción no permitida" not in v, "queda un aviso de permiso"
assert v.count("if (!puedeEditarEntreno) return;") == 2, "guards silenciosos"
assert "{mode === 'view' && puedeEditarEntreno && (" in v, "botón condicional"
print("verificaciones OK")
