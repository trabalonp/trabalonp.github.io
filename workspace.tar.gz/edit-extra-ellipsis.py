# -*- coding: utf-8 -*-
import os
BASE = os.path.dirname(os.path.abspath(__file__))
p = os.path.join(BASE, 'proyecto', 'mi-app-entrenos', 'components', 'StepEditor.js')
raw = open(p, 'rb').read(); crlf = b'\r\n' in raw
txt = raw.decode('utf-8').replace('\r\n', '\n')
old = """          <Ionicons name="ellipsis-horizontal" size={18} color="#8FA8C8" />"""
new = """          <Ionicons name="ellipsis-horizontal" size={18} color={theme.muted} />"""
assert txt.count(old) == 1, txt.count(old)
txt = txt.replace(old, new)
open(p, 'wb').write((txt.replace('\n', '\r\n') if crlf else txt).encode('utf-8'))
print('OK StepEditor: icono del menú "..." ahora usa theme.muted')
