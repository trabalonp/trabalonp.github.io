#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Evento creado en el calendario de un atleta: el coach puede gestionar los
atletas del evento al editarlo (ya no está restringido a eventos de su propio
perfil). Además, al crear un Evento en el calendario de un atleta, el atleta
entra directo en la lista de apuntados, y se avisa por notificación a cada
atleta recién añadido a un evento.

Archivos tocados:
  - screens/WorkoutDetailModal.js
  - screens/AddWorkoutModal.js
"""
import io
import os

BASE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(BASE, 'proyecto', 'mi-app-entrenos')


def edit(rel, replacements):
    path = os.path.join(SRC, rel)
    with io.open(path, 'r', encoding='utf-8', newline='') as f:
        raw = f.read()
    crlf = '\r\n' in raw
    text = raw.replace('\r\n', '\n')
    for old, new in replacements:
        cnt = text.count(old)
        assert cnt == 1, '%s: encontrado %d veces (esperaba 1): %r' % (rel, cnt, old[:90])
        text = text.replace(old, new)
    out = text.replace('\n', '\r\n') if crlf else text
    with io.open(path, 'w', encoding='utf-8', newline='') as f:
        f.write(out)
    print('OK %s (%d cambios, CRLF=%s)' % (rel, len(replacements), crlf))


# ─────────────────────────── WorkoutDetailModal.js ───────────────────────────
wdm = []

# A) Cargar misAtletas también en contexto coach (viendo calendario de un atleta)
wdm.append((
    """      if (workout.userId === auth.currentUser?.uid) {
        setLoadingAtletas(true);""",
    """      // Cargar la lista de atletas si el evento es mío o si soy el coach
      // viendo el calendario de un atleta (evento creado en su perfil).
      if (workout.userId === auth.currentUser?.uid || (athleteId && athleteId !== auth.currentUser?.uid)) {
        setLoadingAtletas(true);"""
))

# B) Variable derivada: quién puede gestionar los atletas del evento
wdm.append((
    """  if (!workout) return null;
""",
    """  if (!workout) return null;
  // El coach puede gestionar los atletas del evento también cuando el evento
  // está creado en el calendario de un atleta (no solo en su propio perfil).
  const esCoachContexto = !!athleteId && athleteId !== auth.currentUser?.uid;
  const puedeGestionarEvento = workout.userId === auth.currentUser?.uid || esCoachContexto;
"""
))

# C) Sección de gestión de atletas en modo edición: quitar la restricción
wdm.append((
    """                  {actividad === 'Evento' && workout?.userId === auth.currentUser?.uid && (""",
    """                  {actividad === 'Evento' && puedeGestionarEvento && ("""
))

# D) toggleAsignado: notificar al atleta recién añadido al evento
wdm.append((
    """      if (!on && !perfilesAsignados[uid]) {
        try {
          const c = await getCachedProfile(uid);
          if (c) setPerfilesAsignados(p => ({ ...p, [uid]: c }));
          else { const s2 = await getDoc(doc(db, 'perfiles', uid)); if (s2.exists()) setPerfilesAsignados(p => ({ ...p, [uid]: s2.data() })); }
        } catch (e) {}
      }
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };""",
    """      if (!on && !perfilesAsignados[uid]) {
        try {
          const c = await getCachedProfile(uid);
          if (c) setPerfilesAsignados(p => ({ ...p, [uid]: c }));
          else { const s2 = await getDoc(doc(db, 'perfiles', uid)); if (s2.exists()) setPerfilesAsignados(p => ({ ...p, [uid]: s2.data() })); }
        } catch (e) {}
      }
      // Avisar al atleta recién añadido al evento
      if (!on) {
        const cn = await getCoachFullName(auth.currentUser.uid);
        await sendNotificationToAthlete(uid, auth.currentUser.uid,
          `🏆 ${cn} ${L('te ha añadido a un evento', 'added you to an event')}`,
          `${L('Evento', 'Event')}: ${w.titulo || w.tipo}`);
      }
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };"""
))

edit('screens/WorkoutDetailModal.js', wdm)

# ──────────────────────────── AddWorkoutModal.js ─────────────────────────────
awm = []

# E) Al crear un Evento en el calendario de un atleta, el atleta entra directo
#    en la lista de apuntados (asignados), así al editar se le ve ya apuntado.
awm.append((
    """      const pasosGuardados = pasos.map(normalizeStep);
      const refNew = await addDoc(collection(db, 'entrenamientos'), {
        userId: targetUserId,
        tipo: actividad,
        titulo: titulo || actividad,
        fecha: Timestamp.fromDate(fechaFinal),
        fechaStr,
        descripcion,
        pasos: pasosGuardados,
        estado: null,
        garminSynced: false,
        createdAt: Timestamp.now(),
      });""",
    """      const pasosGuardados = pasos.map(normalizeStep);
      const docNuevo = {
        userId: targetUserId,
        tipo: actividad,
        titulo: titulo || actividad,
        fecha: Timestamp.fromDate(fechaFinal),
        fechaStr,
        descripcion,
        pasos: pasosGuardados,
        estado: null,
        garminSynced: false,
        createdAt: Timestamp.now(),
      };
      // Evento creado en el calendario de un atleta: el atleta entra directo
      // en la lista de apuntados del evento
      if (athleteId && actividad === 'Evento') docNuevo.asignados = [athleteId];
      const refNew = await addDoc(collection(db, 'entrenamientos'), docNuevo);"""
))

edit('screens/AddWorkoutModal.js', awm)
print('TODO OK')
