#!/usr/bin/env python3
"""Regenera mi-app-entrenos-main-CORREGIDO.zip con el server de Vercel corregido.

Mismos 18 archivos que la versión anterior del ZIP (prefijo mi-app-entrenos-main/).
Uso: python3 build-server-corregido.py
"""
import os
import zipfile

BASE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(BASE, 'vercel-server', 'mi-app-entrenos-main')
OUT = os.path.join(BASE, 'mi-app-entrenos-main-CORREGIDO.zip')
PREFIJO = 'mi-app-entrenos-main/'

FILES = [
    '.gitignore',
    'package.json',
    'api/sync-fitness.js',
    'api/sync-intervals.js',
    'api/sync-intervals-detail.js',
    'api/upload-to-intervals.js',
    'api/intervals/save-credentials.js',
    'api/intervals/status.js',
    'api/intervals/disconnect.js',
    'lib/uploadWorkouts.js',
    'lib/auth.js',
    'lib/intervalsDetail.js',
    'lib/fitness.js',
    'lib/wellness.js',
    'lib/firebase.js',
    'lib/intervals.js',
    'lib/matcher.js',
    'lib/push.js',
]

missing = [n for n in FILES if not os.path.exists(os.path.join(SRC, n))]
if missing:
    raise SystemExit('FALTAN archivos en el server: ' + ', '.join(missing))

with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for n in FILES:
        z.write(os.path.join(SRC, n), PREFIJO + n)

print('OK -> %s (%d archivos, %d bytes)' % (OUT, len(FILES), os.path.getsize(OUT)))
