#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Refactor del cálculo de esfuerzo en la app + botón "Recalcular" en la ficha del
entreno, para poder corregir entrenos YA guardados sin volver a importar el FIT.
"""
import io
import os

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(BASE, 'proyecto', 'mi-app-entrenos')


def load(rel):
    with io.open(os.path.join(ROOT, rel), 'r', encoding='utf-8', newline='') as f:
        s = f.read()
    nl = '\r\n' if '\r\n' in s else '\n'
    return s.replace(nl, '\n'), nl


def save(rel, text, nl):
    with io.open(os.path.join(ROOT, rel), 'w', encoding='utf-8', newline='') as f:
        f.write(text.replace('\n', nl))


def rep(text, old, new, tag, n=1):
    c = text.count(old)
    if c != n:
        raise SystemExit('ERROR [%s]: esperadas %d coincidencias, encontradas %d' % (tag, n, c))
    return text.replace(old, new, 1)


# ══════════════════════════════════════════════════════════════════════
# 1) services/SyncService.js  →  bloque de esfuerzo refactorizado
# ══════════════════════════════════════════════════════════════════════
p = 'services/SyncService.js'
s, nl = load(p)

INI = '// ─────────────────────────────────────────────────────────────────\n// ESFUERZO (equivalente TSS'
i = s.index(INI)
j = s.index('export async function resetSyncFolder()')

BLOQUE = r'''// ─────────────────────────────────────────────────────────────────
// ESFUERZO (equivalente TSS, estilo TrainingPeaks: 83, 55, 101, 91…)
//
// Los archivos FIT de Garmin NO incluyen TSS, así que se calcula con la mejor
// fuente disponible y en el mismo orden de preferencia que usa TrainingPeaks:
//   1) session.trainingStressScore, si el archivo ya lo trae (Wahoo,
//      TrainingPeaks, Golden Cheetah…).
//   2) TSS por potencia:  TSS = (segundos × NP × IF) / (FTP × 3600) × 100,
//      con IF = NP / FTP.
//   3) rTSS por ritmo (carrera a pie con ritmo umbral en el perfil):
//      rTSS = horas × IF² × 100,  con IF = ritmoUmbral / ritmoMedio.
//   4) hrTSS por frecuencia cardíaca: TRIMP de Banister normalizado para que
//      1 hora al umbral de FC ≈ 100 (misma escala que TSS).
//   5) Último recurso: Training Effect de Garmin (0–5) escalado ×20.
//
// Devuelve siempre { valor, fuente } para que la app pueda mostrar de dónde
// sale el número y se pueda comparar con TrainingPeaks sin dudas.
//
// ⚠ CAMBIO IMPORTANTE: en esta app `perfil.umbralFC` es la FC MÁXIMA (es el
// campo "FC máxima" de la pantalla Zonas), NO el umbral de FC. Antes se usaba
// como si fuera el umbral, de modo que la comprobación `hrMax > lthr` no se
// cumplía NUNCA, el hrTSS se descartaba siempre y se acababa en el Training
// Effect ×20. Por eso la app mostraba 27 en un entreno que en TrainingPeaks
// era 83 (Training Effect 1.35 × 20 = 27).
// ─────────────────────────────────────────────────────────────────

const numOrNull = (v) => (v != null && Number.isFinite(Number(v)) ? Number(v) : null);

// "04:35" / "4:35" / "4.5" / 4.58  →  segundos por km
export function parseRitmoMinKm(v) {
  if (v == null || v === '') return null;
  if (typeof v === 'number') return Number.isFinite(v) && v > 0 ? Math.round(v * 60) : null;
  const txt = String(v).trim().replace(',', '.');
  const m = txt.match(/^(\d{1,3}):(\d{1,2})$/);
  if (m) {
    const seg = Number(m[1]) * 60 + Number(m[2]);
    return seg > 0 ? seg : null;
  }
  const n = Number(txt);
  return Number.isFinite(n) && n > 0 ? Math.round(n * 60) : null;
}

// Umbral de FC (LTHR) a partir de las zonas configuradas: el límite inferior de
// la zona de umbral. En esta app las zonas de FC se generan desde la FC máxima
// y la zona "SuperUmbral" empieza en el 90 %, así que se acepta cualquier
// límite entre el 84 % y el 96 % de la máxima y se descarta el resto.
export function lthrDesdeZonas(zonas, hrMax) {
  if (!Array.isArray(zonas) || zonas.length === 0 || !(hrMax > 0)) return null;
  const mins = zonas
    .map((z) => Number(z && z.min))
    .filter((n) => Number.isFinite(n) && n >= hrMax * 0.84 && n <= hrMax * 0.96)
    .sort((a, b) => a - b);
  return mins.length ? Math.round(mins[0]) : null;
}

// FC máxima efectiva: manda la del perfil (campo "FC máxima" de Zonas); si no
// está o no es creíble, fórmula de Tanaka con la fecha de nacimiento; y siempre
// se sube hasta la FC máxima vista en la sesión si fue mayor.
function hrMaxEfectiva(perfil, startDate, maxSesion) {
  let hrMax = numOrNull(perfil?.umbralFC);
  if (hrMax == null || hrMax < 100 || hrMax > 230) {
    hrMax = null;
    const fnRaw = perfil?.fechaNac;
    if (fnRaw) {
      const fn = fnRaw.toDate ? fnRaw.toDate() : new Date(fnRaw);
      const edad = (startDate.getTime() - fn.getTime()) / (365.25 * 24 * 3600 * 1000);
      if (edad > 5 && edad < 100) hrMax = 208 - 0.7 * edad;
    }
    if (hrMax == null) hrMax = 190;
  }
  if (maxSesion != null && maxSesion > hrMax) hrMax = maxSesion;
  return hrMax;
}

// Umbral de FC (LTHR): campo explícito del perfil → zona de umbral de las zonas
// de FC → 90 % de la FC máxima. NUNCA `umbralFC`, que es la FC máxima.
function lthrEfectiva(perfil, hrMax) {
  return numOrNull(perfil?.fcUmbral) ?? lthrDesdeZonas(perfil?.zonasFC, hrMax) ?? Math.round(hrMax * 0.90);
}

// hrTSS: TRIMP de Banister normalizado para que 1 h al umbral de FC = 100.
function calcularHrTss({ avgHr, maxHrSesion, durMin, startDate, perfil, wellnessDays }) {
  const avg = numOrNull(avgHr);
  if (avg == null || avg <= 0 || !(durMin >= 5)) return null;
  const when = startDate instanceof Date ? startDate : new Date(startDate || Date.now());
  const hrMax = hrMaxEfectiva(perfil, when, numOrNull(maxHrSesion));
  const dayKey = `${when.getFullYear()}-${String(when.getMonth() + 1).padStart(2, '0')}-${String(when.getDate()).padStart(2, '0')}`;
  const hrRest = numOrNull(wellnessDays?.[dayKey]?.rhr) ?? 60;
  const lthr = lthrEfectiva(perfil, hrMax);
  if (!(hrRest > 0 && hrMax > lthr && lthr > hrRest)) return null;
  const f = (r) => r * 0.64 * Math.exp(1.92 * r); // factor TRIMP
  const ratio = Math.min(1, Math.max(0, (avg - hrRest) / (hrMax - hrRest)));
  const denom = 60 * f((lthr - hrRest) / (hrMax - hrRest)); // TRIMP de 1 h al umbral
  if (!(ratio > 0 && denom > 0)) return null;
  return { valor: Math.round((durMin * f(ratio)) * (100 / denom)), fuente: 'fc' };
}

// rTSS: 1 hora al ritmo umbral = 100 (lo mismo que hace TrainingPeaks en
// carrera a pie cuando el atleta tiene ritmo umbral configurado).
function calcularRtss({ durSec, distanciaKm, ritmoUmbralSeg }) {
  const seg = numOrNull(durSec);
  const km = numOrNull(distanciaKm);
  const ru = numOrNull(ritmoUmbralSeg);
  if (ru == null || seg == null || seg <= 0 || km == null || km <= 0.2) return null;
  const ritmoMedio = seg / km; // s/km
  if (!(ritmoMedio > 0)) return null;
  const ifRitmo = ru / ritmoMedio; // >1 = más rápido que el umbral
  if (!(ifRitmo > 0.3 && ifRitmo < 2)) return null;
  return { valor: Math.round((seg / 3600) * ifRitmo * ifRitmo * 100), fuente: 'ritmo' };
}

function computeEsfuerzo(session, startDate, perfil, wellnessDays) {
  const out = (valor, fuente) => ({ valor: Math.max(0, Math.round(valor)), fuente });

  // 1) TSS grabado en el propio archivo FIT
  const tssFit = numOrNull(session.trainingStressScore);
  if (tssFit != null && tssFit > 0) return out(tssFit, 'archivo');

  const durSec = numOrNull(session.totalTimerTime) ?? numOrNull(session.totalElapsedTime) ?? 0;
  const durMin = durSec / 60;

  // 2) TSS por potencia (NP + FTP)
  const np = numOrNull(session.normalizedPower);
  const ftp = numOrNull(session.thresholdPower) ?? numOrNull(perfil?.umbralPotencia);
  if (np != null && np > 0 && ftp != null && ftp > 0 && durSec > 0) {
    return out(((durSec * np * (np / ftp)) / (ftp * 3600)) * 100, 'potencia');
  }

  // 3) rTSS por ritmo (carrera a pie). En FIT, `sport` trae 'running' y
  //    `subSport` afina ('trail_running', 'treadmill_running'…), así que se
  //    miran los dos.
  const tipoSesion = mapSport(session.sport);
  const deporteRaw = `${session.sport ?? ''} ${session.subSport ?? ''}`.toLowerCase();
  const esCarrera = tipoSesion === 'Running' || /run/.test(deporteRaw);
  if (esCarrera && durSec > 0) {
    const rtss = calcularRtss({
      durSec,
      distanciaKm: numOrNull(session.totalDistance) != null ? Number(session.totalDistance) / 1000 : null,
      ritmoUmbralSeg: parseRitmoMinKm(perfil?.umbralRitmo),
    });
    if (rtss) return rtss;
  }

  // 4) hrTSS por frecuencia cardíaca
  const hrtss = calcularHrTss({
    avgHr: session.avgHeartRate,
    maxHrSesion: session.maxHeartRate,
    durMin,
    startDate,
    perfil,
    wellnessDays,
  });
  if (hrtss) return hrtss;

  // 5) Último recurso: Training Effect de Garmin (0–5) → escala aproximada
  const te = numOrNull(session.totalTrainingEffect);
  if (te != null && te > 0) return out(te * 20, 'training-effect');

  return { valor: 0, fuente: null };
}

// ─────────────────────────────────────────────────────────────────
// Recalcula el esfuerzo a partir de los datos RESUMIDOS de un entreno ya
// guardado (duración, distancia, FC media/máxima). Sirve para corregir
// entrenos importados con versiones anteriores de la app sin tener que volver
// a importar el archivo FIT. Usa la misma prioridad que computeEsfuerzo().
// ─────────────────────────────────────────────────────────────────
export function calcularEsfuerzoDesdeResumen(datos, perfil, wellnessDays) {
  const d = datos || {};
  const durSec = numOrNull(d.duracionSeg);
  const durMin = durSec != null ? durSec / 60 : 0;
  const fecha = d.fecha?.toDate ? d.fecha.toDate() : (d.fecha instanceof Date ? d.fecha : new Date(d.fecha || Date.now()));
  const tipoTxt = String(d.tipo || '').toLowerCase();

  // rTSS por ritmo (carrera a pie con ritmo umbral configurado)
  if (/run|carrera/.test(tipoTxt) && durSec != null) {
    const rtss = calcularRtss({
      durSec,
      distanciaKm: numOrNull(d.distanciaKm),
      ritmoUmbralSeg: parseRitmoMinKm(perfil?.umbralRitmo),
    });
    if (rtss) return rtss;
  }

  // TSS por potencia media (aproximación si el entreno tiene potencia y FTP)
  const pot = numOrNull(d.potenciaMedia);
  const ftp = numOrNull(perfil?.umbralPotencia);
  if (pot != null && pot > 0 && ftp != null && ftp > 0 && durSec != null && durSec > 0 && !/run|carrera/.test(tipoTxt)) {
    const ifPot = pot / ftp;
    return { valor: Math.max(0, Math.round((durSec / 3600) * ifPot * ifPot * 100)), fuente: 'potencia' };
  }

  // hrTSS
  const hrtss = calcularHrTss({
    avgHr: d.fcMedia,
    maxHrSesion: d.fcMax,
    durMin,
    startDate: fecha,
    perfil,
    wellnessDays,
  });
  if (hrtss) return hrtss;

  return { valor: 0, fuente: null };
}

'''

s = s[:i] + BLOQUE + s[j:]
save(p, s, nl)
print('OK services/SyncService.js (bloque de esfuerzo refactorizado)')


# ══════════════════════════════════════════════════════════════════════
# 2) screens/WorkoutDetailModal.js  →  botón "Recalcular"
# ══════════════════════════════════════════════════════════════════════
p = 'screens/WorkoutDetailModal.js'
s, nl = load(p)

s = rep(
    s,
    "import { getApiUrl } from '../services/api';",
    "import { getApiUrl } from '../services/api';\nimport { calcularEsfuerzoDesdeResumen } from '../services/SyncService';",
    'wdm.import',
)

s = rep(
    s,
    """  const [esfuerzoOriginal, setEsfuerzoOriginal] = useState(''); // para detectar edición manual""",
    """  const [esfuerzoOriginal, setEsfuerzoOriginal] = useState(''); // para detectar edición manual
  const [recalculando, setRecalculando] = useState(false);""",
    'wdm.state2',
)

s = rep(
    s,
    """  const horaFinal = () =>""",
    """  // Recalcula el esfuerzo con los datos del entreno y los umbrales del perfil.
  // Permite corregir entrenos guardados con versiones anteriores de la app
  // (que daban valores muy bajos) sin tener que volver a importar el .fit.
  const recalcularEsfuerzo = async () => {
    if (recalculando) return;
    setRecalculando(true);
    try {
      const uid = athleteId || workout?.userId || auth.currentUser?.uid;
      const perfil = (await getCachedProfile(uid)) || null;
      let wellnessDays = {};
      try {
        const ws = await getDoc(doc(db, 'wellness', uid));
        if (ws.exists()) wellnessDays = ws.data().days || {};
      } catch (e) {}
      const r = calcularEsfuerzoDesdeResumen({
        tipo: actividad,
        duracionSeg: parseDuration(durText) ?? durSec,
        distanciaKm: distancia ? parseFloat(distancia) : null,
        fcMedia: fc ? parseInt(fc) : null,
        fcMax: fcMax ? parseInt(fcMax) : null,
        fecha: workout?.fecha,
      }, perfil, wellnessDays);
      if (!r || !(r.valor > 0)) {
        Alert.alert(
          L('No se puede calcular', 'Cannot calculate'),
          L('No hay datos suficientes. Hace falta duración y distancia (para rTSS) o FC media (para hrTSS), y tener configurados los umbrales en Zonas.',
            'Not enough data. Duration and distance (for rTSS) or average HR (for hrTSS) are needed, plus thresholds set in Zones.')
        );
        return;
      }
      setEsfuerzo(String(r.valor));
      setEsfuerzoOriginal(String(r.valor));
      setEsfuerzoFuente(r.fuente);
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally {
      setRecalculando(false);
    }
  };
  const horaFinal = () =>""",
    'wdm.recalc',
)

s = rep(
    s,
    """                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Esfuerzo','Effort')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border }]}><TextInput style={[s.inputInner, { color: theme.text }]} value={esfuerzo} onChangeText={setEsfuerzo} placeholder="0" placeholderTextColor="#4A6080" keyboardType="numeric" /></View>
                          <Text style={[s.fieldLabel, { color: theme.muted, fontSize: 10, marginTop: 3, opacity: 0.85 }]} numberOfLines={2}>
                            {L('Fuente','Source')}: {fuenteEsfuerzoTexto(esfuerzo !== esfuerzoOriginal ? 'manual' : esfuerzoFuente)}
                          </Text>""",
    """                          <View style={{ flexDirection:'row', alignItems:'center', justifyContent:'space-between' }}>
                            <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Esfuerzo','Effort')}</Text>
                            <TouchableOpacity onPress={recalcularEsfuerzo} disabled={recalculando} hitSlop={{top:6,bottom:6,left:6,right:6}}>
                              <Text style={{ color: recalculando ? theme.muted : BLUE, fontSize: 11, fontWeight: '700' }}>
                                {recalculando ? L('Calculando…','Calculating…') : L('⟳ Recalcular','⟳ Recalculate')}
                              </Text>
                            </TouchableOpacity>
                          </View>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border }]}><TextInput style={[s.inputInner, { color: theme.text }]} value={esfuerzo} onChangeText={setEsfuerzo} placeholder="0" placeholderTextColor="#4A6080" keyboardType="numeric" /></View>
                          <Text style={[s.fieldLabel, { color: theme.muted, fontSize: 10, marginTop: 3, opacity: 0.85 }]} numberOfLines={2}>
                            {L('Fuente','Source')}: {fuenteEsfuerzoTexto(esfuerzo !== esfuerzoOriginal ? 'manual' : esfuerzoFuente)}
                          </Text>""",
    'wdm.ui2',
)

save(p, s, nl)
print('OK screens/WorkoutDetailModal.js (botón Recalcular)')
print('\nListo.')
