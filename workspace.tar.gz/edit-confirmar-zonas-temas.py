# -*- coding: utf-8 -*-
"""
1) ZonesScreen: confirmar antes de eliminar una zona (con nombre de la zona).
2) Revisión de TODOS los menús desplegables: los que seguían en modo oscuro
   con la app en modo claro pasan a usar el tema activo.
   - SettingsScreen  -> picker "Contraste" (estaba 100% oscuro)
   - WeeklyKmChart   -> picker de métrica (estaba 100% oscuro)
   - StepEditor      -> menú "..." del paso (estaba 100% oscuro) + picker
   - ZonesScreen     -> modal "Añadir zona" (bordes/scrim)
"""
import os

BASE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(BASE, 'proyecto', 'mi-app-entrenos')


class F:
    def __init__(self, rel):
        self.path = os.path.join(APP, rel)
        with open(self.path, 'rb') as fh:
            raw = fh.read()
        self.crlf = b'\r\n' in raw
        self.txt = raw.decode('utf-8')
        if self.crlf:
            self.txt = self.txt.replace('\r\n', '\n')
        self.rel = rel
        self.n = 0

    def rep(self, old, new, count=1):
        found = self.txt.count(old)
        assert found == count, 'EN %s: esperado %d, encontrado %d de:\n%s' % (self.rel, count, found, old[:300])
        self.txt = self.txt.replace(old, new)
        self.n += count

    def save(self):
        out = self.txt.replace('\n', '\r\n') if self.crlf else self.txt
        with open(self.path, 'wb') as fh:
            fh.write(out.encode('utf-8'))
        print('OK %-38s (%d cambios, %s)' % (self.rel, self.n, 'CRLF' if self.crlf else 'LF'))


# ══════════════════════════════════════════════════════════════════
# 1) ZonesScreen.js  → YA APLICADO en la 1ª ejecución (7 cambios)
# ══════════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════════
# 2) SettingsScreen.js  (menú "Contraste")
# ══════════════════════════════════════════════════════════════════
s = F('screens/SettingsScreen.js')

s.rep(
    """      <Modal visible={themePickerOpen} transparent animationType="fade" onRequestClose={() => setThemePickerOpen(false)}>
        <View style={styles.overlay}>
          <TouchableOpacity style={styles.overlayClose} activeOpacity={1} onPress={() => setThemePickerOpen(false)} />
          <View style={styles.themePicker}>
            <Text style={styles.pickerTitle}>{L('Contraste', 'Contrast')}</Text>
            {[
              ['day', L('Día', 'Day')],
              ['night', L('Noche', 'Night')],
              ['device', L('Dispositivo', 'Device')],
            ].map(([value, label]) => (
              <TouchableOpacity key={value} style={[styles.themeOption, appSettings.themeMode === value && styles.themeOptionActive]} onPress={() => { saveSettings({ themeMode: value }); setThemePickerOpen(false); }}>
                <Text style={styles.themeOptionText}>{label}</Text>
                {appSettings.themeMode === value && <Ionicons name="checkmark-circle" size={18} color={BLUE} />}
              </TouchableOpacity>
            ))}
          </View>
        </View>
        <SystemBars />
      </Modal>""",
    """      {/* Menú desplegable de contraste: usa el tema activo (claro/oscuro) */}
      <Modal visible={themePickerOpen} transparent animationType="fade" onRequestClose={() => setThemePickerOpen(false)}>
        <View style={[styles.overlay, { backgroundColor: theme.overlay }]}>
          <TouchableOpacity style={styles.overlayClose} activeOpacity={1} onPress={() => setThemePickerOpen(false)} />
          <View style={[styles.themePicker, { backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border }]}>
            <Text style={[styles.pickerTitle, { color: theme.muted }]}>{L('Contraste', 'Contrast')}</Text>
            {[
              ['day', L('Día', 'Day')],
              ['night', L('Noche', 'Night')],
              ['device', L('Dispositivo', 'Device')],
            ].map(([value, label]) => {
              const activo = appSettings.themeMode === value;
              return (
                <TouchableOpacity
                  key={value}
                  style={[styles.themeOption, { borderBottomColor: theme.border }, activo && [styles.themeOptionActive, { backgroundColor: BLUE + '22' }]]}
                  onPress={() => { saveSettings({ themeMode: value }); setThemePickerOpen(false); }}
                >
                  <Text style={[styles.themeOptionText, { color: theme.text }, activo && { color: BLUE, fontWeight: '700' }]}>{label}</Text>
                  {activo && <Ionicons name="checkmark-circle" size={18} color={BLUE} />}
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
        <SystemBars />
      </Modal>""",
)

# Filas del menú y switch: iconos/colores que estaban fijados en oscuro
s.rep(
    """              <Ionicons name={item.icon} size={20} color="#8FA8C8" />
              <Text style={[styles.menuLabel, { color: theme.text }]}>{item.label}</Text>
              <Ionicons name="chevron-forward" size={18} color="#2A4060" />""",
    """              <Ionicons name={item.icon} size={20} color={theme.muted} />
              <Text style={[styles.menuLabel, { color: theme.text }]}>{item.label}</Text>
              <Ionicons name="chevron-forward" size={18} color={theme.navText} />""",
)
s.rep(
    """            <Ionicons name="notifications-outline" size={20} color="#8FA8C8" />""",
    """            <Ionicons name="notifications-outline" size={20} color={theme.muted} />""",
)
s.rep(
    """              trackColor={{ false: '#1E3048', true: BLUE }}""",
    """              trackColor={{ false: theme.border, true: BLUE }}""",
)
s.rep(
    """            <Ionicons name="contrast-outline" size={20} color={BLUE} />
            <Text style={[styles.menuLabel, { color: theme.text }]}>{L('Contraste', 'Contrast')}</Text>
            <Text style={styles.themeValue}>{appSettings.themeMode === 'day' ? L('Día', 'Day') : appSettings.themeMode === 'device' ? L('Dispositivo', 'Device') : L('Noche', 'Night')}</Text>
            <Ionicons name="chevron-forward" size={18} color="#2A4060" />""",
    """            <Ionicons name="contrast-outline" size={20} color={BLUE} />
            <Text style={[styles.menuLabel, { color: theme.text }]}>{L('Contraste', 'Contrast')}</Text>
            <Text style={[styles.themeValue, { color: theme.muted }]}>{appSettings.themeMode === 'day' ? L('Día', 'Day') : appSettings.themeMode === 'device' ? L('Dispositivo', 'Device') : L('Noche', 'Night')}</Text>
            <Ionicons name="chevron-forward" size={18} color={theme.navText} />""",
)
s.save()

# ══════════════════════════════════════════════════════════════════
# 3) WeeklyKmChart.js  (menú de métrica del gráfico semanal)
# ══════════════════════════════════════════════════════════════════
w = F('components/WeeklyKmChart.js')

w.rep(
    """        <TouchableOpacity style={pk.overlay} activeOpacity={1} onPress={()=>setPickerOpen(false)}>
          <View style={pk.box}>
            {METRIC_KEYS.map(m=>(
              <TouchableOpacity key={m} style={[pk.opt,metric===m&&pk.optActive]} onPress={()=>{setMetric(m);setPickerOpen(false);}}>
                <Text style={[pk.optText,metric===m&&pk.optTextActive]}>{t(`chart.metric.${m}`)}</Text>""",
    """        <TouchableOpacity style={[pk.overlay,{backgroundColor:theme.overlay}]} activeOpacity={1} onPress={()=>setPickerOpen(false)}>
          <View style={[pk.box,{backgroundColor:theme.card,borderWidth:1,borderColor:theme.border}]}>
            {METRIC_KEYS.map(m=>(
              <TouchableOpacity key={m} style={[pk.opt,{borderBottomColor:theme.border},metric===m&&[pk.optActive,{backgroundColor:BLUE+'22'}]]} onPress={()=>{setMetric(m);setPickerOpen(false);}}>
                <Text style={[pk.optText,{color:metric===m?BLUE:theme.text},metric===m&&pk.optTextActive]}>{t(`chart.metric.${m}`)}</Text>""",
)
w.save()

# ══════════════════════════════════════════════════════════════════
# 4) StepEditor.js  (menú "..." del paso + pickers internos)
# ══════════════════════════════════════════════════════════════════
e = F('components/StepEditor.js')

# Picker interno: scrim y borde según tema, opción activa en azul suave
e.rep(
    """        <TouchableOpacity style={pk.overlay} activeOpacity={1} onPress={() => setOpen(false)}>
          <View style={[pk.box, { backgroundColor: theme.card }]}>""",
    """        <TouchableOpacity style={[pk.overlay, { backgroundColor: theme.overlay }]} activeOpacity={1} onPress={() => setOpen(false)}>
          <View style={[pk.box, { backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border }]}>""",
)
e.rep(
    """value === valOf(o) && [pk.optActive, { backgroundColor: theme.input }]]}""",
    """value === valOf(o) && [pk.optActive, { backgroundColor: BLUE + '22' }]]}""",
)
e.rep(
    """        <Ionicons name="chevron-down" size={14} color="#8FA8C8" />""",
    """        <Ionicons name="chevron-down" size={14} color={theme.muted} />""",
)

# Componente principal: necesita el tema para el menú desplegable
e.rep(
    """export default function StepEditor({ pasos, setPasos }) {
  useAppSettings(); // re-renderiza al cambiar idioma""",
    """export default function StepEditor({ pasos, setPasos }) {
  const settings = useAppSettings(); // re-renderiza al cambiar idioma/tema
  const theme = getThemeColors(settings.themeMode, useColorScheme());""",
)

# Menú de opciones del paso ("..."): estaba siempre en modo oscuro
e.rep(
    """        <TouchableOpacity style={pk.overlay} activeOpacity={1} onPress={() => setMenuId(null)}>
          <View style={pk.box}>""",
    """        <TouchableOpacity style={[pk.overlay, { backgroundColor: theme.overlay }]} activeOpacity={1} onPress={() => setMenuId(null)}>
          <View style={[pk.box, { backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border }]}>""",
)
e.rep(
    """              <TouchableOpacity key={o.k} style={pk.opt} onPress={() => menuAction(o.k)}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <Ionicons name={o.icon} size={17} color={o.k === 'del' ? RED : '#8FA8C8'} />
                  <Text style={[pk.optText, o.k === 'del' && { color: RED }]}>{o.label}</Text>""",
    """              <TouchableOpacity key={o.k} style={[pk.opt, { borderBottomColor: theme.border }]} onPress={() => menuAction(o.k)}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <Ionicons name={o.icon} size={17} color={o.k === 'del' ? RED : theme.muted} />
                  <Text style={[pk.optText, { color: o.k === 'del' ? RED : theme.text }]}>{o.label}</Text>""",
)
e.save()

print('\nTodo listo.')
