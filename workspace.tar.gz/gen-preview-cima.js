/* Genera preview-tarjeta-perfil.html con el artwork "LA CIMA".
   Replica EXACTAMENTE las funciones de SettingsScreen.js para que lo que se
   ve aquí sea lo que capturará ViewShot en la app. */
const fs = require('fs');
const path = require('path');
const WS = process.env.ARENA_WORKSPACE || __dirname;

const CARD_W = 400, CARD_H = 520;
const GREEN = '#7BC86C', GREEN_DK = '#2F6B3A', GREEN_LT = '#8FE08A', INK = '#0C1310', CREAM = '#EAF7E6';

const hashStr = (s) => {
  let h = 2166136261;
  for (let i = 0; i < (s || '').length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
};
const mulberry32 = (a) => () => {
  a |= 0; a = (a + 0x6D2B79F5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const spline = (pts, close) => {
  const n = pts.length;
  const at = (i) => pts[close ? (i + n) % n : Math.min(Math.max(i, 0), n - 1)];
  let d = `M${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`;
  for (let i = 0; i < (close ? n : n - 1); i++) {
    const p0 = at(i - 1), p1 = at(i), p2 = at(i + 1), p3 = at(i + 2);
    const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C${c1x.toFixed(1)} ${c1y.toFixed(1)},${c2x.toFixed(1)} ${c2y.toFixed(1)},${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`;
  }
  return close ? d + ' Z' : d;
};
const topoRing = (cx, cy, r, ph, wob = 0.13) => {
  const pts = [];
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    const k = 1 + wob * (Math.sin(a * 2 + ph) * 0.6 + Math.sin(a * 3 - ph * 1.7) * 0.4);
    pts.push([cx + Math.cos(a) * r * k, cy + Math.sin(a) * r * k * 0.86]);
  }
  return spline(pts, true);
};
const TOPO_RADII = [96, 124, 154, 186, 222];
const TOPO_OP = [0.38, 0.28, 0.20, 0.14, 0.09];
const ridgePath = (y0, amp, ph, close) => {
  const pts = [];
  for (let x = -20; x <= CARD_W + 20; x += 24) {
    pts.push([x, y0 + Math.sin(x * 0.016 + ph) * amp + Math.sin(x * 0.043 + ph * 1.7) * amp * 0.4]);
  }
  const d = spline(pts, false);
  return close ? `${d} L${CARD_W + 20} ${CARD_H + 20} L-20 ${CARD_H + 20} Z` : d;
};
const RIDGES = [
  { y: 372, amp: 10, o: 0.22, w: 1.4 },
  { y: 402, amp: 12, o: 0.18, w: 1.2 },
  { y: 432, amp: 15, o: 0.14, w: 1.1 },
  { y: 466, amp: 18, o: 0.11, w: 1.0 },
];
const RUTA_GPS = 'M-10 468 C 50 460 92 414 152 420 C 212 426 210 458 262 448 C 314 438 348 372 412 356';
const TRAIL = { ax: 40, ay: 503, bx: 172, by: 393 };
const HUELLAS = [
  { t: 0.00, side: -1, o: 0.50, s: 1.00 },
  { t: 0.22, side: +1, o: 0.40, s: 0.94 },
  { t: 0.44, side: -1, o: 0.31, s: 0.88 },
  { t: 0.66, side: +1, o: 0.23, s: 0.82 },
  { t: 0.88, side: -1, o: 0.15, s: 0.76 },
];
const nameSize = (s) => ((s || '').length > 13 ? 22 : (s || '').length > 10 ? 26 : (s || '').length > 8 ? 30 : 34);

function artworkSVG(firstName, uid) {
  const seedPhase = (hashStr(firstName) % 628) / 100;
  const rnd = mulberry32(hashStr(firstName + '|cielo'));
  const estrellas = [];
  while (estrellas.length < 18) {
    const x = 14 + rnd() * (CARD_W - 28);
    const y = 14 + rnd() * 246;
    if (Math.hypot(x - CARD_W / 2, y - 158) < 112) continue;
    estrellas.push({ x, y, r: 0.7 + rnd() * 1.1, o: 0.10 + rnd() * 0.38 });
  }
  let s = `<svg width="${CARD_W}" height="${CARD_H}" viewBox="0 0 ${CARD_W} ${CARD_H}" class="art">
  <defs>
    <linearGradient id="tjBg${uid}" x1="0" y1="0" x2="0.35" y2="1">
      <stop offset="0" stop-color="#0C1B13"/><stop offset="0.55" stop-color="${INK}"/><stop offset="1" stop-color="#050806"/>
    </linearGradient>
    <radialGradient id="tjGlow${uid}" cx="0.5" cy="0.5" r="0.5">
      <stop offset="0" stop-color="#5FCE73" stop-opacity="0.26"/><stop offset="0.55" stop-color="#3E9B52" stop-opacity="0.10"/><stop offset="1" stop-color="#3E9B52" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="tjAuroraB${uid}" cx="0.5" cy="0.5" r="0.5">
      <stop offset="0" stop-color="#3E9B52" stop-opacity="0.15"/><stop offset="1" stop-color="#3E9B52" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="tjAuroraC${uid}" cx="0.5" cy="0.5" r="0.5">
      <stop offset="0" stop-color="#A7E89B" stop-opacity="0.07"/><stop offset="1" stop-color="#A7E89B" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="tjRuta${uid}" gradientUnits="userSpaceOnUse" x1="0" y1="500" x2="${CARD_W}" y2="350">
      <stop offset="0" stop-color="${GREEN_DK}"/><stop offset="0.5" stop-color="${GREEN}"/><stop offset="1" stop-color="${CREAM}"/>
    </linearGradient>
    <radialGradient id="tjVig${uid}" cx="0.5" cy="0.45" r="0.78">
      <stop offset="0.55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity="0.46"/>
    </radialGradient>
  </defs>
  <rect width="${CARD_W}" height="${CARD_H}" fill="url(#tjBg${uid})"/>
  <circle cx="${CARD_W / 2}" cy="158" r="205" fill="url(#tjGlow${uid})"/>
  <circle cx="54" cy="474" r="170" fill="url(#tjAuroraB${uid})"/>
  <circle cx="368" cy="492" r="150" fill="url(#tjAuroraC${uid})"/>`;
  for (const st of estrellas) {
    s += `\n  <circle cx="${st.x.toFixed(1)}" cy="${st.y.toFixed(1)}" r="${st.r.toFixed(1)}" fill="${CREAM}" fill-opacity="${st.o.toFixed(2)}"/>`;
  }
  TOPO_RADII.forEach((r, i) => {
    s += `\n  <path d="${topoRing(CARD_W / 2, 158, r, seedPhase + i * 0.8)}" fill="none" stroke="${GREEN}" stroke-width="${i === 0 ? 1.6 : 1.1}" stroke-opacity="${TOPO_OP[i]}"${i === TOPO_RADII.length - 1 ? ' stroke-dasharray="3 7"' : ''}/>`;
  });
  s += `\n  <path d="${ridgePath(432, 15, seedPhase * 1.3 + 2.1, true)}" fill="#081109" fill-opacity="0.55"/>`;
  s += `\n  <path d="${ridgePath(466, 18, seedPhase * 0.8 + 4.4, true)}" fill="#060C08" fill-opacity="0.72"/>`;
  RIDGES.forEach((rg, i) => {
    s += `\n  <path d="${ridgePath(rg.y, rg.amp, seedPhase * (1 + i * 0.25) + i * 2.1, false)}" fill="none" stroke="${GREEN}" stroke-width="${rg.w}" stroke-opacity="${rg.o}"/>`;
  });
  s += `\n  <path d="${RUTA_GPS}" fill="none" stroke="url(#tjRuta${uid})" stroke-width="8" stroke-opacity="0.10" stroke-linecap="round"/>`;
  s += `\n  <path d="${RUTA_GPS}" fill="none" stroke="url(#tjRuta${uid})" stroke-width="4.5" stroke-opacity="0.22" stroke-linecap="round"/>`;
  s += `\n  <path d="${RUTA_GPS}" fill="none" stroke="url(#tjRuta${uid})" stroke-width="2" stroke-linecap="round"/>`;
  s += `\n  <path d="${RUTA_GPS}" fill="none" stroke="${CREAM}" stroke-width="1.2" stroke-opacity="0.35" stroke-dasharray="1 11" stroke-linecap="round"/>`;
  s += `\n  <circle cx="152" cy="420" r="3" fill="${INK}" stroke="${GREEN}" stroke-width="1.4" stroke-opacity="0.85"/>`;
  s += `\n  <circle cx="262" cy="448" r="3" fill="${INK}" stroke="${GREEN}" stroke-width="1.4" stroke-opacity="0.85"/>`;
  s += `\n  <circle cx="396" cy="360" r="9" fill="none" stroke="${CREAM}" stroke-width="1" stroke-opacity="0.35"/>`;
  s += `\n  <circle cx="396" cy="360" r="3.4" fill="${CREAM}"/>`;
  for (const h of HUELLAS) {
    const x = TRAIL.ax + (TRAIL.bx - TRAIL.ax) * h.t + h.side * 5.6;
    const y = TRAIL.ay + (TRAIL.by - TRAIL.ay) * h.t + h.side * 7;
    const rot = 47 + (h.side > 0 ? 5 : -4);
    s += `\n  <g transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${rot}) scale(${h.s})" opacity="${h.o}">
    <ellipse cx="0" cy="0" rx="4.4" ry="7.2" fill="${GREEN}" transform="rotate(-7)"/>
    <ellipse cx="0.8" cy="10.6" rx="3.3" ry="4.3" fill="${GREEN}" transform="rotate(-4 0.8 10.6)"/>
  </g>`;
  }
  s += `\n  <path d="M266 96 L266 66" stroke="${GREEN_LT}" stroke-width="2" stroke-linecap="round" stroke-opacity="0.9"/>`;
  s += `\n  <path d="M267.5 67 L286 73.5 L267.5 80 Z" fill="${GREEN_LT}" fill-opacity="0.92"/>`;
  s += `\n  <circle cx="266" cy="97.5" r="2" fill="${GREEN_LT}"/>`;
  for (let row = 0; row < 4; row++) for (let col = 0; col < 5; col++) {
    s += `\n  <circle cx="${CARD_W - 88 + col * 13}" cy="${30 + row * 13}" r="1.4" fill="${GREEN}" fill-opacity="0.15"/>`;
  }
  s += `\n  <path d="M16 46 L16 16 L46 16" fill="none" stroke="${GREEN}" stroke-width="2.5" stroke-opacity="0.7"/>`;
  s += `\n  <path d="M${CARD_W - 16} ${CARD_H - 46} L${CARD_W - 16} ${CARD_H - 16} L${CARD_W - 46} ${CARD_H - 16}" fill="none" stroke="${GREEN}" stroke-width="2.5" stroke-opacity="0.7"/>`;
  s += `\n  <rect width="${CARD_W}" height="${CARD_H}" fill="url(#tjVig${uid})"/>`;
  s += `\n</svg>`;
  return s;
}

const MAIL_ICON = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#8FAF97" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="3"/><path d="m2 7 10 6L22 7"/></svg>`;

function cardHTML(firstName, email, avatarDataUri, uid) {
  const initial = firstName.charAt(0).toUpperCase();
  const fs_ = nameSize(firstName);
  const photo = avatarDataUri
    ? `<img class="photo" src="${avatarDataUri}" alt=""/>`
    : `<div class="photo fallback">${initial}</div>`;
  return `
  <figure>
    <div class="card">
      ${artworkSVG(firstName, uid)}
      <div class="avatarWrap">
        <div class="dashed"></div>
        <div class="ringOut"><div class="ringIn">${photo}</div></div>
      </div>
      <div class="name" style="font-size:${fs_}px">${firstName.toUpperCase()}</div>
      <div class="under1"></div>
      <div class="under2"></div>
      <div class="footer"><div class="pill">${MAIL_ICON}<span>${email}</span></div></div>
    </div>
    <figcaption>Nombre semilla: <b>${firstName}</b> → mapa único<br/>(solo nombre de pila + correo)</figcaption>
  </figure>`;
}

const avatarB64 = fs.readFileSync(path.join(WS, 'uploads/avatar-b64.txt'), 'utf8').trim();

const html = `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Tarjeta de perfil — LA CIMA</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: #070B09; color: #C8D6CC;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    padding: 36px 20px 56px; text-align: center;
  }
  h1 { color: #F4F8F2; font-size: 22px; letter-spacing: 1px; margin-bottom: 6px; }
  h1 span { color: #7BC86C; }
  .sub { font-size: 13px; color: #7E9184; max-width: 640px; margin: 0 auto 30px; line-height: 1.55; }
  .grid { display: flex; gap: 34px; justify-content: center; flex-wrap: wrap; }
  figure { text-align: center; }
  figcaption { margin-top: 14px; font-size: 12px; color: #7E9184; line-height: 1.6; }
  figcaption b { color: #A9CBB0; }
  .card {
    position: relative; width: 400px; height: 520px; background: #0C1310;
    overflow: hidden; display: flex; flex-direction: column; align-items: center;
    border-radius: 6px; box-shadow: 0 24px 60px rgba(0,0,0,.55), 0 0 0 1px rgba(123,200,108,.14);
    margin: 0 auto;
  }
  .art { position: absolute; top: 0; left: 0; }
  .avatarWrap { position: relative; width: 172px; height: 172px; margin-top: 66px; display: flex; align-items: center; justify-content: center; }
  .dashed { position: absolute; inset: 0; border-radius: 50%; border: 1.5px dashed rgba(123,200,108,.35); }
  .ringOut { width: 148px; height: 148px; border-radius: 50%; background: #8FE08A; border: 1px solid #2F6B3A; display: flex; align-items: center; justify-content: center; }
  .ringIn { width: 140px; height: 140px; border-radius: 50%; background: #0C1310; display: flex; align-items: center; justify-content: center; }
  .photo { width: 130px; height: 130px; border-radius: 50%; object-fit: cover; display: block; }
  .fallback { background: #2F6B3A; color: #fff; font-size: 54px; font-weight: 800; display: flex; align-items: center; justify-content: center; font-family: "Segoe Print", "Bradley Hand", cursive; }
  .name { margin-top: 26px; color: #F4F8F2; font-weight: 900; letter-spacing: 4px; text-transform: uppercase; max-width: 344px; font-family: "Kalam", "Segoe Print", "Bradley Hand", "Comic Sans MS", cursive; }
  .under1 { height: 3.5px; width: 132px; background: #7BC86C; border-radius: 3px; margin-top: 13px; transform: rotate(-1.2deg); }
  .under2 { height: 2.5px; width: 74px; background: rgba(123,200,108,.44); border-radius: 3px; margin-top: 4px; transform: rotate(-1.2deg); }
  .footer { position: absolute; bottom: 26px; left: 0; right: 0; display: flex; justify-content: center; }
  .pill { display: flex; align-items: center; gap: 7px; background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.12); border-radius: 999px; padding: 7px 14px; }
  .pill span { color: #AEC4B4; font-size: 11.5px; letter-spacing: .4px; }
  .nota { margin-top: 34px; font-size: 12px; color: #6B7D70; max-width: 640px; margin-left: auto; margin-right: auto; line-height: 1.7; }
  .nota b { color: #9DB8A4; }
</style>
</head>
<body>
  <h1>Tarjeta para compartir · <span>LA CIMA</span></h1>
  <p class="sub">La foto es la cumbre de un mapa topográfico: anillos de nivel, cielo estrellado,
  terreno en capas, ruta GPS con brillo, huellas que ascienden y bandera plantada en la cima.
  Sin apellidos, sin “Atleta Team Jorge”, sin logo: <b>solo nombre y correo</b> sobre artwork puro.</p>
  <div class="grid">
    ${cardHTML('Jorge', 'jorge@ejemplo.com', 'data:image/jpeg;base64,' + avatarB64, '1')}
    ${cardHTML('Alejandra', 'alejandra@ejemplo.com', null, '2')}
  </div>
  <p class="nota"><b>Cada persona recibe un mapa distinto:</b> el nombre semilla los anillos topográficos y las
  estrellas (determinista: siempre el mismo para el mismo nombre). La segunda tarjeta muestra el avatar con
  inicial cuando no hay foto. En la app se captura a 1200×1560 px (4:5) y se comparte como PNG.</p>
</body>
</html>`;

fs.writeFileSync(path.join(WS, 'preview-tarjeta-perfil.html'), html);
console.log('preview-tarjeta-perfil.html generado,', html.length, 'bytes');
