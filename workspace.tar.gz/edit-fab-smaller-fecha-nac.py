# -*- coding: utf-8 -*-
# 1) CalendarScreen.js: FAB un pelín más pequeño (56→48, icono 30→26)
# 2) ProfileScreen.js: validación de fecha de nacimiento al pulsar "Actualiza"
import os

BASE = os.path.dirname(os.path.abspath(__file__))

def load(rel):
    p = os.path.join(BASE, rel)
    b = open(p, 'rb').read()
    crlf = b'\r\n' in b
    return p, b.decode('utf-8').replace('\r\n', '\n'), crlf

def save(p, text, crlf):
    if crlf:
        text = text.replace('\n', '\r\n')
    open(p, 'wb').write(text.encode('utf-8'))

def rep(text, old, new):
    assert text.count(old) == 1, 'anclaje no único o no encontrado: %r' % old[:70]
    return text.replace(old, new, 1)

# ───────────────────────── CalendarScreen.js (LF) ─────────────────────────
p, t, crlf = load('proyecto/mi-app-entrenos/screens/CalendarScreen.js')
t = rep(t,
    "    width: 56, height: 56, borderRadius: 28,",
    "    width: 48, height: 48, borderRadius: 24,")
t = rep(t,
    '        <Ionicons name="add" size={30} color="#fff" />',
    '        <Ionicons name="add" size={26} color="#fff" />')
save(p, t, crlf)
print('OK CalendarScreen.js (CRLF=%s)' % crlf)

# ───────────────────────── ProfileScreen.js (CRLF) ────────────────────────
p, t, crlf = load('proyecto/mi-app-entrenos/screens/ProfileScreen.js')

# 1. Importar locale()
t = rep(t,
    "import { getThemeColors, L, useAppSettings } from '../services/appSettings';",
    "import { getThemeColors, L, locale, useAppSettings } from '../services/appSettings';")

# 2. Helpers de fecha de nacimiento antes del componente
HELPERS = '''// ── Fecha de nacimiento: parseo y validación ──
const MESES_ES_LARGOS = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
const MESES_EN_LARGOS = ['january','february','march','april','may','june','july','august','september','october','november','december'];
const MESES_ES_CORTOS = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
const MESES_EN_CORTOS = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
const MESES_DISPLAY = {
  es: ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'],
  en: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
};

function mesesDisplay() {
  return locale() === 'en-US' ? MESES_DISPLAY.en : MESES_DISPLAY.es;
}

function mesDesdeTexto(txt) {
  const t = String(txt).toLowerCase().trim();
  if (!t) return null;
  let i = MESES_ES_LARGOS.indexOf(t); if (i >= 0) return i + 1;
  i = MESES_EN_LARGOS.indexOf(t); if (i >= 0) return i + 1;
  if (t.length <= 4) {
    const t3 = t.slice(0, 3);
    i = MESES_ES_CORTOS.indexOf(t3); if (i >= 0) return i + 1;
    i = MESES_EN_CORTOS.indexOf(t3); if (i >= 0) return i + 1;
  }
  return null;
}

function esFechaReal(y, m, d) {
  if (!(m >= 1 && m <= 12) || !(d >= 1)) return false;
  const dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
}

// Parsea el campo y devuelve { y, m, d } o null si no encaja en ningún formato
// aceptado:
//   · DD/MM/AAAA, DD-MM-AAAA, DD.MM.AAAA (también año de 2 dígitos: 30-99 → 19xx, 00-29 → 20xx)
//   · AAAA-MM-DD (ISO)
//   · DD MMM AAAA / DD de MMMM de AAAA / MMM DD, AAAA ("15 Mar 1990", "15 de marzo de 1990", "Mar 15, 1990"; mes en español o inglés)
function parseFechaNac(txt) {
  if (txt == null) return null;
  const s = String(txt).trim().replace(/\\s+/g, ' ');
  if (!s) return null;
  const expandir = (yy) => (yy <= 29 ? 2000 + yy : 1900 + yy);

  let r = /^(\\d{4})-(\\d{1,2})-(\\d{1,2})$/.exec(s); // AAAA-MM-DD
  if (r) {
    const y = +r[1], m = +r[2], d = +r[3];
    return esFechaReal(y, m, d) ? { y, m, d } : null;
  }
  r = /^(\\d{1,2})[\\/\\-.](\\d{1,2})[\\/\\-.](\\d{2}|\\d{4})$/.exec(s); // DD/MM/AAAA
  if (r) {
    const d = +r[1], m = +r[2];
    const y = r[3].length === 2 ? expandir(+r[3]) : +r[3];
    return esFechaReal(y, m, d) ? { y, m, d } : null;
  }
  r = /^(\\d{1,2})[\\s.]+(?:de\\s+)?([A-Za-zÁÉÍÓÚÜÑáéíóúüñ]{3,12})[.,]?\\s*(?:de\\s+|del\\s+)?(\\d{2}|\\d{4})$/.exec(s); // DD MMM AAAA
  if (r) {
    const d = +r[1], m = mesDesdeTexto(r[2]);
    const y = r[3].length === 2 ? expandir(+r[3]) : +r[3];
    return m && esFechaReal(y, m, d) ? { y, m, d } : null;
  }
  r = /^([A-Za-zÁÉÍÓÚÜÑáéíóúüñ]{3,12})[.,]?\\s+(\\d{1,2})(?:st|nd|rd|th)?[,\\s]+(\\d{2}|\\d{4})$/.exec(s); // MMM DD, AAAA (inglés)
  if (r) {
    const m = mesDesdeTexto(r[1]), d = +r[2];
    const y = r[3].length === 2 ? expandir(+r[3]) : +r[3];
    return m && esFechaReal(y, m, d) ? { y, m, d } : null;
  }
  return null;
}

// Valida el campo: vacío se permite (campo opcional); si no, debe tener un
// formato aceptado, ser una fecha real del calendario, no futura y no implicar
// más de 110 años. Si es correcta devuelve { ok: true, iso } con la fecha
// normalizada a AAAA-MM-DD (es lo que se guarda en Firestore, para que
// new Date() la entienda siempre — p. ej. la fórmula de Tanaka del SyncService).
function validarFechaNac(txt) {
  const s = txt == null ? '' : String(txt).trim();
  if (!s) return { ok: true, iso: '' };
  const p = parseFechaNac(s);
  if (!p) return { ok: false, motivo: 'formato' };
  const hoy = new Date();
  const nac = new Date(p.y, p.m - 1, p.d);
  if (nac.getTime() > hoy.getTime()) return { ok: false, motivo: 'futura' };
  const edad = (hoy.getTime() - nac.getTime()) / (365.25 * 24 * 3600 * 1000);
  if (edad > 110) return { ok: false, motivo: 'rango' };
  const iso = `${p.y}-${String(p.m).padStart(2, '0')}-${String(p.d).padStart(2, '0')}`;
  return { ok: true, iso };
}

// Muestra la fecha guardada (cadena ISO o Timestamp de Firestore) como
// "DD MMM AAAA". Si no se puede interpretar, la devuelve tal cual.
function formatoBonitoFechaNac(v) {
  if (v == null || v === '') return '';
  if (typeof v === 'object' && typeof v.toDate === 'function') {
    const d = v.toDate();
    return `${String(d.getDate()).padStart(2, '0')} ${mesesDisplay()[d.getMonth()]} ${d.getFullYear()}`;
  }
  const s = String(v).trim();
  const p = parseFechaNac(s);
  if (!p) return s;
  return `${String(p.d).padStart(2, '0')} ${mesesDisplay()[p.m - 1]} ${p.y}`;
}

'''
t = rep(t, 'export default function ProfileScreen() {', HELPERS + 'export default function ProfileScreen() {')

# 3. Cargadores: mostrar la fecha con formato bonito
t = rep(t,
    "setSexo(cached.sexo || ''); setFechaNac(cached.fechaNac || '');",
    "setSexo(cached.sexo || ''); setFechaNac(formatoBonitoFechaNac(cached.fechaNac));")
t = rep(t,
    "setSexo(data.sexo || ''); setFechaNac(data.fechaNac || '');",
    "setSexo(data.sexo || ''); setFechaNac(formatoBonitoFechaNac(data.fechaNac));")

# 4. handleUpdate: validar antes de guardar y bloquear si el formato es incorrecto
OLD_UPDATE = """  const handleUpdate = async () => {
    if (!uid) { Alert.alert(L('Error','Error'), L('No se ha identificado al usuario.','User not identified.')); return; }
    setLoading(true);
    try {
      const dataToSave = {
        nombre, apellido, sexo, fechaNac, altura, unidadAltura, peso, unidadPeso,"""
NEW_UPDATE = """  const handleUpdate = async () => {
    if (!uid) { Alert.alert(L('Error','Error'), L('No se ha identificado al usuario.','User not identified.')); return; }
    // Validar la fecha de nacimiento antes de guardar nada: si está rellena y
    // el formato no es correcto (o es futura / inverosímil), se bloquea la
    // actualización completa del perfil y se avisa al usuario.
    const fnCheck = validarFechaNac(fechaNac);
    if (!fnCheck.ok) {
      const mensajes = {
        futura: L('La fecha de nacimiento no puede ser futura.','Date of birth cannot be in the future.'),
        rango: L('La fecha de nacimiento no parece válida (más de 110 años).','Date of birth does not look valid (over 110 years).'),
        formato: L('El formato de la fecha de nacimiento no es correcto. Formatos válidos: DD/MM/AAAA, DD-MM-AAAA, AAAA-MM-DD o DD MMM AAAA (p. ej. 15/03/1990 o 15 Mar 1990).','Invalid date of birth format. Valid formats: DD/MM/YYYY, DD-MM-YYYY, YYYY-MM-DD or DD MMM YYYY (e.g. 15/03/1990 or 15 Mar 1990).'),
      };
      Alert.alert(
        L('Fecha de nacimiento no válida','Invalid date of birth'),
        (mensajes[fnCheck.motivo] || mensajes.formato) + ' ' + L('No se ha guardado ningún cambio.','No changes were saved.')
      );
      return;
    }
    setLoading(true);
    try {
      const dataToSave = {
        nombre, apellido, sexo, fechaNac: fnCheck.iso, altura, unidadAltura, peso, unidadPeso,"""
t = rep(t, OLD_UPDATE, NEW_UPDATE)

# 5. Placeholder bilingüe
t = rep(t,
    """<Field label={L('Fecha de nacimiento','Date of birth')} value={fechaNac} onChange={setFechaNac} placeholder="DD MMM AAAA" />""",
    """<Field label={L('Fecha de nacimiento','Date of birth')} value={fechaNac} onChange={setFechaNac} placeholder={L('DD MMM AAAA','DD MMM YYYY')} />""")

save(p, t, crlf)
print('OK ProfileScreen.js (CRLF=%s)' % crlf)
print('TODO OK')
