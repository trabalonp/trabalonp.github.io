#!/usr/bin/env python3
# Añade el campo `creadoPor` y lo usa en los permisos de edición/arrastre,
# para que el atleta NO pueda editar ni mover lo que el coach creó en su calendario.
import sys, os

BASE = os.environ.get('ARENA_WORKSPACE') or os.path.dirname(os.path.abspath(__file__))
SCR = os.path.join(BASE, 'proyecto', 'mi-app-entrenos', 'screens')

def edit(path, pairs):
    with open(path, 'r', encoding='utf-8', newline='') as f:
        raw = f.read()
    crlf = '\r\n' in raw
    text = raw.replace('\r\n', '\n')
    for i, (old, new) in enumerate(pairs):
        n = text.count(old)
        if n != 1:
            print('ERROR: ancla #%d de %s encontrada %d veces' % (i, path, n))
            print(old[:200])
            sys.exit(1)
        text = text.replace(old, new)
    out = text.replace('\n', '\r\n') if crlf else text
    with open(path, 'w', encoding='utf-8', newline='') as f:
        f.write(out)
    print('OK %s (%d ediciones)' % (path, len(pairs)))

# ── 1) AddWorkoutModal.js: guardar quién crea el entreno ──
edit(os.path.join(SCR, 'AddWorkoutModal.js'), [(
"""      const docNuevo = {
        userId: targetUserId,""",
"""      const docNuevo = {
        userId: targetUserId,
        // Quién lo crea: si el coach lo crea en el calendario del atleta, el
        // userId es el del atleta pero creadoPor es el del coach. La app usa
        // este campo para que el atleta no pueda editarlo ni moverlo.
        creadoPor: auth.currentUser?.uid || targetUserId,""",
)])

# ── 2) WorkoutDetailModal.js: permisos basados en el creador real ──
edit(os.path.join(SCR, 'WorkoutDetailModal.js'), [
(
"""  // ── Permisos de edición ──
  // Un entreno solo lo puede editar/borrar quien lo ha creado. Si el entrenador
  // me ha agregado a un evento (el documento tiene el userId del coach y mi uid
  // está en `asignados`), en mi calendario simplemente NO aparece el botón
  // "Editar" y la tarjeta no se puede arrastrar: la acción no está disponible
  // y no se muestra ningún aviso. El coach sí puede editar cuando está viendo el
  // calendario de un atleta (athleteId distinto del suyo).
  const miUid = auth.currentUser?.uid;
  const esCoachContexto = !!athleteId && athleteId !== miUid;
  const esCreadorEntreno = !workout?.userId || workout.userId === miUid;
  const puedeEditarEntreno = esCreadorEntreno || esCoachContexto;""",
"""  // ── Permisos de edición ──
  // Un entreno solo lo puede editar/borrar quien lo ha creado. Si el entrenador
  // me ha agregado a uno de sus eventos (documento con el userId del coach) o
  // lo ha creado directamente en mi calendario (documento con mi userId pero
  // `creadoPor` del coach), en mi lado simplemente NO aparece el botón "Editar"
  // y la tarjeta no se puede arrastrar: la acción no está disponible y no se
  // muestra ningún aviso. El coach sí puede editar siempre que está viendo el
  // calendario de un atleta (athleteId distinto del suyo).
  const miUid = auth.currentUser?.uid;
  const esCoachContexto = !!athleteId && athleteId !== miUid;
  // El creador real es `creadoPor` (se guarda al crear el entreno). En
  // documentos antiguos se usa `userId` como referencia, salvo que el dueño
  // aparezca en `asignados`: esa combinación solo se da en eventos que el
  // coach creó directamente en el calendario del atleta (antes de que se
  // guardara `creadoPor`), así que el creador se considera el coach.
  const creadoPorCoachLegacy = !workout?.creadoPor && !!workout?.userId
    && Array.isArray(workout?.asignados) && workout.asignados.includes(workout.userId);
  const creadorUid = workout?.creadoPor || (creadoPorCoachLegacy ? null : workout?.userId);
  const esCreadorEntreno = !workout?.userId || creadorUid === miUid;
  const puedeEditarEntreno = esCreadorEntreno || esCoachContexto;""",
),
(
"""      if (w.mergedFromPlanId) {
        await addDoc(collection(db, 'entrenamientos'), {
          userId: w.userId,""",
"""      if (w.mergedFromPlanId) {
        await addDoc(collection(db, 'entrenamientos'), {
          userId: w.userId,
          creadoPor: w.creadoPor || w.userId, // mantiene el creador original""",
),
(
"""      await addDoc(collection(db, 'entrenamientos'), {
        userId: w.userId,
        fecha: w.planFecha ?? w.fecha,""",
"""      await addDoc(collection(db, 'entrenamientos'), {
        userId: w.userId,
        creadoPor: w.creadoPor || w.userId, // mantiene el creador original
        fecha: w.planFecha ?? w.fecha,""",
),
])

# ── 3) CalendarScreen.js: guard de arrastre con el creador real ──
edit(os.path.join(SCR, 'CalendarScreen.js'), [(
"""    // Un evento al que me ha agregado mi entrenador (userId = coach) no se
    // puede arrastrar: solo su creador puede modificarlo. El coach sí puede
    // (user.uid es el coach aunque esté viendo el calendario de un atleta).
    if (w.userId && w.userId !== currentUserId && w.userId !== user?.uid) return;""",
"""    // Los entrenos creados por el coach no se pueden arrastrar: ni los que
    // me ha agregado él (userId = coach) ni los que creó directamente en mi
    // calendario (userId = yo pero creadoPor = coach). Solo su creador puede
    // modificarlos. El coach sí puede (user.uid es el coach aunque esté
    // viendo el calendario de un atleta). En documentos antiguos sin
    // creadoPor, la pista es que el dueño aparezca en asignados: eso solo
    // pasa en eventos que el coach creó en el calendario del atleta.
    const duenoDrag = w.creadoPor || w.userId;
    const legacyCreadoPorCoach = !w.creadoPor && !!w.userId && Array.isArray(w.asignados) && w.asignados.includes(w.userId);
    if (legacyCreadoPorCoach) {
      // Solo el coach (viendo el calendario del atleta) puede moverlo
      if (!athleteId || athleteId === user?.uid) return;
    } else if (duenoDrag && duenoDrag !== currentUserId && duenoDrag !== user?.uid) {
      return;
    }""",
)])

print('TODO OK')
