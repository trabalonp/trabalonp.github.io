#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mantenimiento masivo: recalcular el esfuerzo (TSS) de los entrenos YA guardados
en la app, sin volver a importar los .fit. Añade:
  • services/SyncService.js  → export recalcularEsfuerzos(userId, onProgress)
  • screens/SyncSettingsScreen.js → botón "Recalcular esfuerzo (TSS)"
"""
import io
import os

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(BASE, 'proyecto', 'mi-app-entrenos')


def load(rel):
    with io.open(os.path.join(ROOT, rel), 'r', encoding='utf-8', newline='') as f:
        s = f.read()
    nl = '\r\n' if '\r\n' in s else '\n'
    return s.replace(nl, '\n'), nl


def save(rel, text, nl):
    with io.open(os.path.join(ROOT, rel), 'w', encoding='utf-8', newline='') as f:
        f.write(text.replace('\n', nl))


def rep(text, old, new, tag):
    c = text.count(old)
    if c != 1:
        raise SystemExit('ERROR [%s]: esperadas 1 coincidencias, encontradas %d' % (tag, c))
    return text.replace(old, new, 1)


# ══════════════════════════════════════════════════════════════════════
# 1) services/SyncService.js
# ══════════════════════════════════════════════════════════════════════
p = 'services/SyncService.js'
s, nl = load(p)

NUEVA_FN = r'''
// ─────────────────────────────────────────────────────────────────
// MANTENIMIENTO: recalcula en bloque el esfuerzo de los entrenos que ya están
// guardados, a partir de sus datos resumen (duración, distancia, FC media y
// FC máxima) y de los umbrales del perfil. Sirve para corregir el histórico
// importado con versiones anteriores de la app (que daba valores muy bajos)
// sin tener que volver a importar los archivos .fit.
//
// No toca los entrenos sincronizados desde intervals.icu: en ésos manda el TSS
// de intervals.icu y es el servidor quien los corrige al sincronizar. Tampoco
// pisa valores editados a mano por el usuario (esfuerzoManual === true).
// ─────────────────────────────────────────────────────────────────
export async function recalcularEsfuerzos(userId, onProgress) {
  const snap = await getDocs(query(collection(db, 'entrenamientos'), where('userId', '==', userId)));
  const docs = snap.docs;
  let perfil = null;
  let wellnessDays = {};
  try {
    const ps = await getDoc(doc(db, 'perfiles', userId));
    if (ps.exists()) perfil = ps.data();
    const ws = await getDoc(doc(db, 'wellness', userId));
    if (ws.exists()) wellnessDays = ws.data().days || {};
  } catch (e) {
    console.warn('[recalcularEsfuerzos] Error leyendo perfil/wellness:', e.message);
  }

  let actualizados = 0, sinDatos = 0, intactos = 0, omitidos = 0;

  for (let i = 0; i < docs.length; i++) {
    const d = docs[i];
    const w = d.data() || {};
    onProgress?.(`${i + 1}/${docs.length}`, i + 1, docs.length);

    // Los de intervals.icu los corrige el servidor con el TSS real
    if (w.source === 'intervals.icu' || w.intervalsId) { omitidos++; continue; }

    let det = null;
    try {
      const ds = await getDoc(doc(db, 'entrenamientos', d.id, 'detalles', 'data'));
      if (ds.exists()) det = ds.data();
    } catch (e) {}

    if (det?.esfuerzoManual === true || w.esfuerzoManual === true) { intactos++; continue; }

    // duración: en la app puede venir en minutos (<600) o en segundos
    let durSeg = null;
    if (w.duracion != null && Number.isFinite(Number(w.duracion))) {
      const dv = Number(w.duracion);
      durSeg = dv < 600 ? dv * 60 : dv;
    }

    const fecha = w.fecha?.toDate ? w.fecha.toDate() : (w.fecha ? new Date(w.fecha) : new Date());
    const r = calcularEsfuerzoDesdeResumen({
      tipo: w.tipo,
      duracionSeg: durSeg,
      distanciaKm: w.distancia != null ? Number(w.distancia) : null,
      fcMedia: w['fc-media'] ?? det?.['fc-media'] ?? null,
      fcMax: det?.fcMax ?? w.fcMax ?? null,
      potenciaMedia: w.potenciaMedia ?? det?.potenciaMedia ?? null,
      fecha,
    }, perfil, wellnessDays);

    const anterior = Math.round(Number(w.esfuerzo) || 0);
    if (!(r.valor > 0)) { sinDatos++; continue; }
    if (r.valor === anterior && (det?.esfuerzoFuente || w.esfuerzoFuente)) { intactos++; continue; }

    try {
      await updateDoc(doc(db, 'entrenamientos', d.id), { esfuerzo: r.valor, esfuerzoFuente: r.fuente });
      await setDoc(doc(db, 'entrenamientos', d.id, 'detalles', 'data'), {
        esfuerzo: r.valor,
        tss: r.valor,
        esfuerzoFuente: r.fuente,
      }, { merge: true });
      actualizados++;
    } catch (e) {
      console.warn('[recalcularEsfuerzos] Error guardando', d.id, e.message);
    }
  }

  return { total: docs.length, actualizados, sinDatos, intactos, omitidos };
}

'''

s = rep(
    s,
    "export async function resetSyncFolder() {",
    NUEVA_FN.strip('\n') + "\n\nexport async function resetSyncFolder() {",
    'sync.recalc',
)

# updateDoc no estaba importado en SyncService
s = rep(
    s,
    "import { addDoc, collection, doc, getDoc, getDocs, query, setDoc, Timestamp, where } from 'firebase/firestore';",
    "import { addDoc, collection, doc, getDoc, getDocs, query, setDoc, Timestamp, updateDoc, where } from 'firebase/firestore';",
    'sync.import',
)

save(p, s, nl)
print('OK services/SyncService.js (recalcularEsfuerzos)')


# ══════════════════════════════════════════════════════════════════════
# 2) screens/SyncSettingsScreen.js
# ══════════════════════════════════════════════════════════════════════
p = 'screens/SyncSettingsScreen.js'
s, nl = load(p)

s = rep(
    s,
    "import { resetSyncFolder, syncFitFiles } from '../services/SyncService';",
    "import { resetSyncFolder, syncFitFiles, recalcularEsfuerzos } from '../services/SyncService';",
    'sss.import',
)

s = rep(
    s,
    """  const folderName = folderUri""",
    """  // ── Mantenimiento: recalcular el esfuerzo (TSS) de lo ya guardado ──
  const [recalculando, setRecalculando] = useState(false);
  const [recalculoMsg, setRecalculoMsg] = useState('');
  const handleRecalcularEsfuerzo = () => {
    const userId = auth.currentUser?.uid;
    if (!userId) return;
    Alert.alert(
      L('Recalcular esfuerzo', 'Recalculate effort'),
      L(
        'Vuelve a calcular el esfuerzo (TSS) de tus entrenos guardados usando la duración, la distancia, la FC y tus umbrales de Zonas. No modifica los entrenos sincronizados desde intervals.icu (ésos usan el TSS real de intervals.icu) ni los que hayas editado a mano.',
        'Recalculates the effort (TSS) of your saved workouts using duration, distance, HR and your Zones thresholds. Workouts synced from intervals.icu (which use the real intervals.icu TSS) and manually edited ones are not modified.'
      ),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Recalcular', 'Recalculate'),
          onPress: async () => {
            setRecalculando(true);
            setRecalculoMsg(L('Preparando…', 'Preparing…'));
            try {
              const r = await recalcularEsfuerzos(userId, (msg) => setRecalculoMsg(msg));
              Alert.alert(
                L('Esfuerzo recalculado', 'Effort recalculated'),
                `${r.actualizados} ${L('actualizados', 'updated')} · ${r.intactos} ${L('sin cambios', 'unchanged')} · ${r.sinDatos} ${L('sin datos suficientes', 'not enough data')} · ${r.omitidos} ${L('de intervals.icu (los corrige el servidor)', 'from intervals.icu (fixed by the server)')}`
              );
            } catch (e) {
              Alert.alert(L('Error', 'Error'), e.message);
            } finally {
              setRecalculando(false);
              setRecalculoMsg('');
            }
          },
        },
      ]
    );
  };

  const folderName = folderUri""",
    'sss.handler',
)

s = rep(
    s,
    """        <TouchableOpacity style={s.guideHeader} onPress={() => setOpenGuideFit(v => !v)} activeOpacity={0.8}>""",
    """        {/* ══════════ MANTENIMIENTO: ESFUERZO (TSS) ══════════ */}
        <Text style={[s.sectionTitle, { marginTop: 24, color: theme.text }]}>{L('Esfuerzo (TSS)', 'Effort (TSS)')}</Text>
        <TouchableOpacity
          style={[s.primaryBtn, { backgroundColor: '#2A4060', marginTop: 8 }, recalculando && s.disabled]}
          onPress={handleRecalcularEsfuerzo}
          disabled={recalculando}
          activeOpacity={0.85}
        >
          {recalculando ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <Ionicons name="refresh-outline" size={20} color="#fff" />
              <Text style={s.primaryBtnText}>{L('Recalcular esfuerzo de mis entrenos', 'Recalculate effort of my workouts')}</Text>
            </>
          )}
        </TouchableOpacity>
        {recalculando && !!recalculoMsg && (
          <View style={[s.progressBox, { backgroundColor: theme.input, borderColor: theme.border }]}>
            <ActivityIndicator size="small" color={BLUE} />
            <Text style={[s.progressText, { color: theme.muted }]} numberOfLines={1}>{recalculoMsg}</Text>
          </View>
        )}
        <TouchableOpacity style={s.guideHeader} onPress={() => setOpenGuideFit(v => !v)} activeOpacity={0.8}>""",
    'sss.ui',
)

save(p, s, nl)
print('OK screens/SyncSettingsScreen.js (botón Recalcular esfuerzo)')
print('\nListo.')
