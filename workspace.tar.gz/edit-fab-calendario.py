#!/usr/bin/env python3
"""Añade un FAB redondo azul con '+' (abajo a la derecha) en CalendarScreen.
Hace lo mismo que los botones de agregar entreno de cada día: openModal().
Color = BLUE (#4A90E2), el mismo del botón 'Hoy'."""
import os

BASE = os.path.dirname(os.path.abspath(__file__))
TARGET = os.path.join(BASE, 'proyecto', 'mi-app-entrenos', 'screens', 'CalendarScreen.js')

raw = open(TARGET, 'rb').read()
crlf = b'\r\n' in raw
text = raw.decode('utf-8')
if crlf:
    text = text.replace('\r\n', '\n')

def rep(old, new):
    global text
    n = text.count(old)
    assert n == 1, f'Esperaba 1 aparición, encontré {n} de:\n{old[:120]}'
    text = text.replace(old, new)

# ── 1) JSX: FAB entre el ScrollView y el overlay de drag ─────────────────
rep(
"""        </ScrollView>
      </View>

      {drag && (
""",
"""        </ScrollView>
      </View>

      {/* FAB: agregar entreno (mismo '+' que el de cada día), abajo a la derecha */}
      <TouchableOpacity
        style={styles.fabAdd}
        onPress={() => openModal(new Date())}
        activeOpacity={0.85}
      >
        <Ionicons name="add" size={30} color="#fff" />
      </TouchableOpacity>

      {drag && (
""")

# ── 2) Estilos: fabAdd justo después de dragOverlay ──────────────────────
rep(
"""  dragOverlay: {
    position: 'absolute', top: 0, left: 16, right: 16,
    borderRadius: 10, overflow: 'hidden',
    elevation: 16, zIndex: 999, opacity: 0.96,
    shadowColor: '#000', shadowOpacity: 0.35, shadowRadius: 8, shadowOffset: { width: 0, height: 6 },
  },
""",
"""  dragOverlay: {
    position: 'absolute', top: 0, left: 16, right: 16,
    borderRadius: 10, overflow: 'hidden',
    elevation: 16, zIndex: 999, opacity: 0.96,
    shadowColor: '#000', shadowOpacity: 0.35, shadowRadius: 8, shadowOffset: { width: 0, height: 6 },
  },
  fabAdd: {
    position: 'absolute', right: 18, bottom: 18,
    width: 56, height: 56, borderRadius: 28,
    backgroundColor: BLUE, alignItems: 'center', justifyContent: 'center',
    elevation: 8, zIndex: 900,
    shadowColor: '#000', shadowOpacity: 0.35, shadowRadius: 6, shadowOffset: { width: 0, height: 4 },
  },
""")

if crlf:
    text = text.replace('\n', '\r\n')
open(TARGET, 'wb').write(text.encode('utf-8'))
print('OK ->', TARGET, '| CRLF:', crlf, '| bytes:', os.path.getsize(TARGET))
