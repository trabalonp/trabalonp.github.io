const fs = require('fs');
const path = require('path');
const root = process.env.ARENA_WORKSPACE || '.';
const wdmPath = path.join(root, 'proyecto/mi-app-entrenos/screens/WorkoutDetailModal.js');
const calPath = path.join(root, 'proyecto/mi-app-entrenos/screens/CalendarScreen.js');

let pass = 0, fail = 0;
const t = (name, cond) => { if (cond) { pass++; console.log('  OK  ', name); } else { fail++; console.log('  FAIL', name); } };

// ── 1) Lógica real de permisos extraída del archivo ─────────────────────────
const src = fs.readFileSync(wdmPath, 'utf8');
const permLines = src.split('\n').filter(l => /const (miUid|esCoachContexto|esCreadorEntreno|puedeEditarEntreno) =/.test(l)).map(l => l.trim());
t('encuentra las 4 líneas de permisos', permLines.length === 4);
const perms = new Function('auth', 'athleteId', 'workout',
  permLines.join('\n') + '\nreturn { miUid, esCoachContexto, esCreadorEntreno, puedeEditarEntreno };');

const COACH = 'uid-coach', ATH = 'uid-atleta', authAth = { currentUser: { uid: ATH } }, authCoach = { currentUser: { uid: COACH } };
const evtDelCoach = { id: 'e1', tipo: 'Evento', userId: COACH, asignados: [ATH] };
const entrenoDelAtleta = { id: 'w1', userId: ATH };
const legacy = { id: 'w3' };

console.log('\n— puedeEditarEntreno —');
t('atleta ve evento del coach que le agregó  -> NO puede', perms(authAth, null, evtDelCoach).puedeEditarEntreno === false);
t('atleta ve su propio entreno               -> puede', perms(authAth, null, entrenoDelAtleta).puedeEditarEntreno === true);
t('coach ve su propio evento (mi calendario) -> puede', perms(authCoach, null, evtDelCoach).puedeEditarEntreno === true);
t('coach ve calendario del atleta (evento)   -> puede', perms(authCoach, ATH, evtDelCoach).puedeEditarEntreno === true);
t('otro atleta del mismo evento              -> NO puede', perms({ currentUser: { uid: 'uid-otro' } }, null, evtDelCoach).puedeEditarEntreno === false);
t('workout legacy sin userId                 -> puede', perms(authAth, null, legacy).puedeEditarEntreno === true);
t('athleteId === mi uid no cuenta como coach', perms(authAth, ATH, evtDelCoach).puedeEditarEntreno === false);

// ── 2) UI: sin permiso el botón NO existe y no hay ningún aviso ─────────────
console.log('\n— UI sin avisos —');
t('el botón Editar solo se renderiza si puedeEditarEntreno', /\{mode === 'view' && puedeEditarEntreno && \(/.test(src));
t('ya no existe el estilo editBtnDisabled (nada atenuado)', !/editBtnDisabled/.test(src));
t('no queda ningún Alert de permiso', !/No puedes editarlo|Acción no permitida|Solo quien ha creado el entrenamiento/.test(src));
t('ya no existe puedeGestionarEvento (criterio unificado)', !/puedeGestionarEvento/.test(src));
t('esCoachContexto se define una sola vez', (src.match(/const esCoachContexto =/g) || []).length === 1);
t('la sección "Atletas del evento" usa puedeEditarEntreno', /actividad === 'Evento' && puedeEditarEntreno &&/.test(src));

// render simulado del header: ¿aparece el botón Editar?
const rendersEdit = new Function('mode', 'puedeEditarEntreno', 'return (mode === "view" && puedeEditarEntreno) ? "EDITAR" : "";');
t('atleta + evento del coach -> el header no muestra Editar', rendersEdit('view', perms(authAth, null, evtDelCoach).puedeEditarEntreno) === '');
t('atleta + entreno propio   -> el header muestra Editar', rendersEdit('view', perms(authAth, null, entrenoDelAtleta).puedeEditarEntreno) === 'EDITAR');
t('coach + calendario atleta -> el header muestra Editar', rendersEdit('view', perms(authCoach, ATH, evtDelCoach).puedeEditarEntreno) === 'EDITAR');

// onPress limpio: entra directo en modo edición (sin guard ni Alert)
const ini = src.indexOf('Sin permiso el botón no se muestra');
const btnBlock = src.slice(ini, src.indexOf('</TouchableOpacity>', ini));
t('el onPress entra directo en modo edición', /onPress=\{\(\) => \{ setMode\('edit'\); setMainTab\('edit'\); \}\}/.test(btnBlock));
t('el onPress no contiene Alert', !/Alert/.test(btnBlock));

// guards silenciosos de seguridad (por si se llegara a llamar por otra vía)
t('handleSaveEdit: guard silencioso', /const handleSaveEdit = async \(\) => \{\n    if \(!puedeEditarEntreno\) return;/.test(src));
t('handleDelete: guard silencioso', /const handleDelete = \(\) => \{\n    if \(!puedeEditarEntreno\) return;/.test(src));
t('los guards no abren bloque con Alert', !/if \(!puedeEditarEntreno\) \{/.test(src));
t("Guardar/Borrar viven dentro del modo edición (inalcanzable sin permiso)", src.indexOf("mode === 'edit' && mainTab === 'edit'") < src.indexOf('onPress={handleSaveEdit}'));

// ── 3) CalendarScreen: arrastre bloqueado en silencio ───────────────────────
console.log('\n— CalendarScreen: armDrag —');
const src2 = fs.readFileSync(calPath, 'utf8');
const guardLine = (src2.split('\n').find(l => l.includes('w.userId !== currentUserId')) || '').trim();
t('existe el guard de arrastre', /if \(w\.userId && w\.userId !== currentUserId && w\.userId !== user\?\.uid\) return;/.test(guardLine));
const canDrag = new Function('w', 'currentUserId', 'user', guardLine.replace(/return;/, 'return false;') + '\nreturn true;');
t('atleta NO puede arrastrar evento del coach', canDrag(evtDelCoach, ATH, authAth.currentUser) === false);
t('atleta puede arrastrar su propio entreno', canDrag(entrenoDelAtleta, ATH, authAth.currentUser) === true);
t('coach puede arrastrar en calendario del atleta', canDrag(evtDelCoach, ATH, authCoach.currentUser) === true);
t('legacy sin userId se puede arrastrar', canDrag(legacy, ATH, authAth.currentUser) === true);
const dragBlock = src2.slice(src2.indexOf('const armDrag'), src2.indexOf('const armDrag') + 900);
t('el guard de arrastre no muestra ningún aviso', !/Alert|Toast|Snackbar/.test(dragBlock));

console.log(`\n${pass}/${pass + fail} tests OK`);
process.exitCode = fail ? 1 : 0;
