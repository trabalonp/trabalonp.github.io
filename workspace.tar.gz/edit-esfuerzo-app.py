#!/usr/bin/env python3
"""Corrige el ESFUERZO (TSS) en la app.

1) services/SyncService.js (importación de archivos FIT):
   - El código usaba `session.totalTrainingEffect ?? session.activityTrainingLoad ?? 0`:
     `activityTrainingLoad` NO existe en el formato FIT (siempre undefined) y
     `totalTrainingEffect` es el Training Effect de Garmin (0–5), no un TSS.
   - Nuevo computeEsfuerzo(): TSS del fichero → TSS por potencia (NP+FTP) →
     hrTSS (TRIMP normalizado a umbral) → Training Effect ×20.
   - Guarda esfuerzo también en el documento principal y tss en detalles.
2) screens/WorkoutDetailModal.js:
   - Muestra el esfuerzo aunque venga del doc principal; acepta 0 reales.
   - Al abrir un entreno de intervals sin esfuerzo, fuerza el detalle.
   - Al guardar sesión, escribe esfuerzo también en el doc principal.
3) services/analyticsEngine.js:
   - La gráfica "Esfuerzo" usaba solo la carga de wellness (claves que
     intervals.icu no devuelve → siempre 0). Ahora acumula el esfuerzo por
     entreno (suma diaria de TSS) con fallback a la carga de wellness.
"""
import os

BASE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(BASE, 'proyecto', 'mi-app-entrenos')

def read(p):
    data = open(p, 'rb').read()
    crlf = b'\r\n' in data
    text = data.decode('utf-8')
    if crlf:
        text = text.replace('\r\n', '\n')
    return text, crlf

def write(p, text, crlf):
    if crlf:
        text = text.replace('\n', '\r\n')
    open(p, 'wb').write(text.encode('utf-8'))

def apply(text, old, new, tag):
    n = text.count(old)
    assert n == 1, f'[{tag}] esperado 1 coincidencia, encontradas {n}'
    return text.replace(old, new)

# ══════════════════════════════════════════════════════════════
# services/SyncService.js
# ══════════════════════════════════════════════════════════════
P = os.path.join(APP, 'services', 'SyncService.js')
t, crlf = read(P)

# 1) import getDoc
t = apply(t,
"import { addDoc, collection, doc, getDocs, query, setDoc, Timestamp, where } from 'firebase/firestore';",
"import { addDoc, collection, doc, getDoc, getDocs, query, setDoc, Timestamp, where } from 'firebase/firestore';",
'import getDoc')

# 2) cargar perfil y wellness antes del bucle
t = apply(t, """  let synced = 0, skipped = 0, errors = 0;
  for (let i = 0; i < fitFiles.length; i++) {
""", """  let synced = 0, skipped = 0, errors = 0;

  // Perfil del atleta y wellness: se usan para calcular el esfuerzo (TSS/hrTSS)
  // cuando el archivo FIT no trae el dato directamente (umbral de potencia,
  // umbral de FC, fecha de nacimiento y FC en reposo del día).
  let perfil = null;
  let wellnessDays = {};
  try {
    const ps = await getDoc(doc(db, 'perfiles', userId));
    if (ps.exists()) perfil = ps.data();
    const ws = await getDoc(doc(db, 'wellness', userId));
    if (ws.exists()) wellnessDays = ws.data().days || {};
  } catch (e) {
    console.warn('[SyncService] Error leyendo perfil/wellness:', e.message);
  }

  for (let i = 0; i < fitFiles.length; i++) {
""", 'perfil/wellness')

# 3) pasar contexto a parseFitFile
t = apply(t,
"      const parsed = await parseFitFile(file.uri);",
"      const parsed = await parseFitFile(file.uri, perfil, wellnessDays);",
'call parseFitFile')

# 4) esfuerzo en el documento principal
t = apply(t, """        potenciaMedia: parsed.potenciaMedia || 0,
        cadencia: parsed.cadencia || 0,
      });
""", """        potenciaMedia: parsed.potenciaMedia || 0,
        cadencia: parsed.cadencia || 0,
        esfuerzo: parsed.esfuerzo ?? 0,
      });
""", 'main doc esfuerzo')

# 5) tss = esfuerzo en detalles
t = apply(t, """        esfuerzo: parsed.esfuerzo ?? 0,
        tss: 0,
""", """        esfuerzo: parsed.esfuerzo ?? 0,
        tss: parsed.esfuerzo ?? 0,
""", 'detalles tss')

# 6) firma de parseFitFile
t = apply(t,
"async function parseFitFile(contentUri) {",
"async function parseFitFile(contentUri, perfil, wellnessDays) {",
'parseFitFile firma')

# 7) extracción de esfuerzo desde la sesión FIT
t = apply(t,
"      esfuerzo = session.totalTrainingEffect ?? session.activityTrainingLoad ?? 0;",
"""      // OJO: `activityTrainingLoad` no existe en el formato FIT y
      // `totalTrainingEffect` es el Training Effect de Garmin (0–5), no un TSS.
      // El esfuerzo real (tipo TrainingPeaks: 83, 55, 101…) se calcula en
      // computeEsfuerzo() con los datos disponibles.
      esfuerzo = computeEsfuerzo(session, startTime, perfil, wellnessDays);""",
'computeEsfuerzo call')

# 8) función computeEsfuerzo tras mapSport
t = apply(t, """function mapSport(sport) {
  const map = {
    cycling: 'Ciclismo',
    running: 'Running',
    swimming: 'Natación',
    training: 'Fuerza',
    generic: 'Otro',
  };
  return map[sport?.toLowerCase()] ?? 'Otro';
}
""", """function mapSport(sport) {
  const map = {
    cycling: 'Ciclismo',
    running: 'Running',
    swimming: 'Natación',
    training: 'Fuerza',
    generic: 'Otro',
  };
  return map[sport?.toLowerCase()] ?? 'Otro';
}

// ─────────────────────────────────────────────────────────────────
// ESFUERZO (equivalente TSS, estilo TrainingPeaks: 83, 55, 101, 91…)
// Los archivos FIT de Garmin NO incluyen TSS, así que se calcula con la
// mejor fuente disponible, en este orden:
//   1) session.trainingStressScore si el archivo ya lo trae (Wahoo,
//      TrainingPeaks, Golden Cheetah…).
//   2) TSS por potencia: potencia normalizada (NP) + FTP (del archivo o del
//      perfil).   TSS = (segundos × NP × IF) / (FTP × 3600) × 100, IF = NP/FTP
//   3) hrTSS por frecuencia cardíaca: TRIMP de Banister normalizado para que
//      1 hora al umbral de FC ≈ 100 (misma escala que TSS).
//   4) Último recurso: Training Effect de Garmin (0–5) escalado ×20.
// ─────────────────────────────────────────────────────────────────
function computeEsfuerzo(session, startDate, perfil, wellnessDays) {
  const num = (v) => (v != null && Number.isFinite(Number(v)) ? Number(v) : null);

  // 1) TSS grabado en el propio archivo FIT
  const tssFit = num(session.trainingStressScore);
  if (tssFit != null && tssFit > 0) return Math.round(tssFit);

  const durSec = num(session.totalTimerTime) ?? num(session.totalElapsedTime) ?? 0;
  const durMin = durSec / 60;

  // 2) TSS por potencia (NP + FTP)
  const np = num(session.normalizedPower);
  const ftp = num(session.thresholdPower) ?? num(perfil?.umbralPotencia);
  if (np != null && np > 0 && ftp != null && ftp > 0 && durSec > 0) {
    return Math.round(((durSec * np * (np / ftp)) / (ftp * 3600)) * 100);
  }

  // 3) hrTSS: TRIMP de Banister normalizado al umbral de FC
  const avgHr = num(session.avgHeartRate);
  if (avgHr != null && avgHr > 0 && durMin >= 5) {
    // FC máxima: fórmula de Tanaka con la fecha de nacimiento del perfil
    let hrMax = null;
    const fnRaw = perfil?.fechaNac;
    if (fnRaw) {
      const fn = fnRaw.toDate ? fnRaw.toDate() : new Date(fnRaw);
      const edad = (startDate.getTime() - fn.getTime()) / (365.25 * 24 * 3600 * 1000);
      if (edad > 5 && edad < 100) hrMax = 208 - 0.7 * edad;
    }
    if (hrMax == null) hrMax = 190;
    const maxSesion = num(session.maxHeartRate);
    if (maxSesion != null && maxSesion > hrMax) hrMax = maxSesion;

    // FC en reposo: wellness del día de la actividad, si no, 60
    const dayKey = `${startDate.getFullYear()}-${String(startDate.getMonth() + 1).padStart(2, '0')}-${String(startDate.getDate()).padStart(2, '0')}`;
    const hrRest = num(wellnessDays?.[dayKey]?.rhr) ?? 60;

    // Umbral de FC (LTHR): del perfil, si no, ~85 % de la FC máxima
    const lthr = num(perfil?.umbralFC) ?? Math.round(hrMax * 0.85);

    if (hrRest > 0 && hrMax > lthr && lthr > hrRest) {
      const f = (r) => r * 0.64 * Math.exp(1.92 * r); // factor TRIMP
      const ratio = Math.min(1, Math.max(0, (avgHr - hrRest) / (hrMax - hrRest)));
      const denom = 60 * f((lthr - hrRest) / (hrMax - hrRest)); // TRIMP de 1 h al umbral
      if (ratio > 0 && denom > 0) return Math.round((durMin * f(ratio)) * (100 / denom));
    }
  }

  // 4) Último recurso: Training Effect de Garmin (0–5) → escala aproximada
  const te = num(session.totalTrainingEffect);
  if (te != null && te > 0) return Math.round(te * 20);

  return 0;
}
""", 'computeEsfuerzo fn')

write(P, t, crlf)
print('OK', P)

# ══════════════════════════════════════════════════════════════
# screens/WorkoutDetailModal.js
# ══════════════════════════════════════════════════════════════
P = os.path.join(APP, 'screens', 'WorkoutDetailModal.js')
t, crlf = read(P)

# 1) estado inicial: solo mostrar valores > 0 (el 0/placeholder no aporta)
t = apply(t,
"setCarga(workout.cargaPercibida ?? null); setEsfuerzo(workout.esfuerzo?.toString() ?? '');",
"setCarga(workout.cargaPercibida ?? null); setEsfuerzo(Number(workout.esfuerzo) > 0 ? workout.esfuerzo.toString() : '');",
'estado inicial esfuerzo')

# 2) carga desde detalles: ignorar 0/nulos y mostrar el valor real
t = apply(t,
"if (d.cargaPercibida) setCarga(d.cargaPercibida); if (d.esfuerzo) setEsfuerzo(d.esfuerzo.toString()); if (d.enlace) setEnlace(d.enlace);",
"if (d.cargaPercibida) setCarga(d.cargaPercibida); if (d.esfuerzo != null && Number(d.esfuerzo) > 0) setEsfuerzo(String(d.esfuerzo)); if (d.enlace) setEnlace(d.enlace);",
'detalles esfuerzo')

# 3) efecto de detalle bajo demanda: saltar solo si además YA tiene esfuerzo
t = apply(t,
"        if (det.exists() && det.data().intervalsDetailSynced && det.data().hasRuta === true) return;",
"""        const dd = det.exists() ? det.data() : null;
        if (dd && dd.intervalsDetailSynced && dd.hasRuta === true && Number(dd.esfuerzo) > 0) return;""",
'guard detalle bajo demanda')

# 4) tras re-sincronizar el detalle, refrescar también el esfuerzo en pantalla
t = apply(t,
"        if (d2s.exists()) { const d2 = d2s.data(); setVueltas(d2.vueltas ?? []); if (d2.elevacionMin != null) setElevMin(d2.elevacionMin.toString()); if (d2.elevacionMax != null) setElevMax(d2.elevacionMax.toString()); }",
"        if (d2s.exists()) { const d2 = d2s.data(); setVueltas(d2.vueltas ?? []); if (d2.elevacionMin != null) setElevMin(d2.elevacionMin.toString()); if (d2.elevacionMax != null) setElevMax(d2.elevacionMax.toString()); if (Number(d2.esfuerzo) > 0) setEsfuerzo(String(d2.esfuerzo)); }",
'refresco esfuerzo post-detalle')

# 5) handleSaveSession: guardar esfuerzo también en el documento principal
t = apply(t,
"await updateDoc(doc(db,'entrenamientos',workout.id), { estado, duracion: secs ?? null, distancia: distancia ? parseFloat(distancia) : null, 'fc-media': fc ? parseInt(fc) : null });",
"await updateDoc(doc(db,'entrenamientos',workout.id), { estado, duracion: secs ?? null, distancia: distancia ? parseFloat(distancia) : null, 'fc-media': fc ? parseInt(fc) : null, esfuerzo: esfuerzo ? parseInt(esfuerzo) : null });",
'save main doc esfuerzo')

write(P, t, crlf)
print('OK', P)

# ══════════════════════════════════════════════════════════════
# services/analyticsEngine.js
# ══════════════════════════════════════════════════════════════
P = os.path.join(APP, 'services', 'analyticsEngine.js')
t, crlf = read(P)

# 1) emptyDay: campo efort
t = apply(t, """    planDist: 0,
    planDur: 0,
    load: 0,
    kcal: 0,
""", """    planDist: 0,
    planDur: 0,
    load: 0,
    efort: 0,
    kcal: 0,
""", 'emptyDay efort')

# 2) mergeWorkout: acumular esfuerzo del documento principal
t = apply(t, """    d.dist += w.distancia || 0;
    d.dur += w.duracion || 0;
    d.count++;
""", """    d.dist += w.distancia || 0;
    d.dur += w.duracion || 0;
    d.count++;

    // Esfuerzo (TSS) por entreno, guardado en el documento principal por la
    // sincronización. Alimentará la gráfica "Esfuerzo" de Análisis.
    const esf = Number(w.esfuerzo);
    if (Number.isFinite(esf) && esf > 0) {
      d.efort = (d.efort || 0) + esf;
    }
""", 'mergeWorkout efort')

# 3) newB de buildSeries: campo efort
t = apply(t, """    pt: 0,
    load: 0,
    kcal: 0,
""", """    pt: 0,
    load: 0,
    efort: 0,
    kcal: 0,
""", 'newB efort')

# 4) acumulación en el bucket
t = apply(t, """    b.load += d.load;
    b.kcal += d.kcal;
""", """    b.load += d.load;
    b.efort += d.efort || 0;
    b.kcal += d.kcal;
""", 'bucket efort')

# 5) serie 'esfuerzo': priorizar la suma diaria de TSS
t = apply(t, """      case 'esfuerzo':
        v = b.load;
        break;
""", """      case 'esfuerzo':
        // Prioriza el esfuerzo real por entreno (suma diaria de TSS);
        // como respaldo usa la carga procedente de wellness.
        v = b.efort > 0 ? b.efort : b.load;
        break;
""", "case esfuerzo")

# 6) carga semanal del resumen: misma preferencia
t = apply(t,
"    weekLoad[wk] = (weekLoad[wk] || 0) + d.load;",
"    weekLoad[wk] = (weekLoad[wk] || 0) + ((d.efort || 0) > 0 ? d.efort : d.load);",
'weekLoad')

write(P, t, crlf)
print('OK', P)
print('TODO OK')
