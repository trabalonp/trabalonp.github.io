/* Render de verificación: tarjeta "LA CIMA" completa en SVG puro → PNG.
   Replica el artwork y la maquetación de SettingsScreen.js.
   Uso: NODE_PATH=/tmp/render/node_modules node render-check-cima.js */
const fs = require('fs');
const path = require('path');
const { Resvg } = require('@resvg/resvg-js');

const CARD_W = 400, CARD_H = 520;
const GREEN = '#7BC86C', GREEN_DK = '#2F6B3A', GREEN_LT = '#8FE08A', INK = '#0C1310', CREAM = '#EAF7E6';

const hashStr = (s) => { let h = 2166136261; for (let i = 0; i < (s || '').length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const mulberry32 = (a) => () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const spline = (pts, close) => {
  const n = pts.length;
  const at = (i) => pts[close ? (i + n) % n : Math.min(Math.max(i, 0), n - 1)];
  let d = `M${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`;
  for (let i = 0; i < (close ? n : n - 1); i++) {
    const p0 = at(i - 1), p1 = at(i), p2 = at(i + 1), p3 = at(i + 2);
    const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C${c1x.toFixed(1)} ${c1y.toFixed(1)},${c2x.toFixed(1)} ${c2y.toFixed(1)},${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`;
  }
  return close ? d + ' Z' : d;
};
const topoRing = (cx, cy, r, ph, wob = 0.13) => {
  const pts = [];
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    const k = 1 + wob * (Math.sin(a * 2 + ph) * 0.6 + Math.sin(a * 3 - ph * 1.7) * 0.4);
    pts.push([cx + Math.cos(a) * r * k, cy + Math.sin(a) * r * k * 0.86]);
  }
  return spline(pts, true);
};
const TOPO_RADII = [96, 124, 154, 186, 222];
const TOPO_OP = [0.38, 0.28, 0.20, 0.14, 0.09];
const ridgePath = (y0, amp, ph, close) => {
  const pts = [];
  for (let x = -20; x <= CARD_W + 20; x += 24) pts.push([x, y0 + Math.sin(x * 0.016 + ph) * amp + Math.sin(x * 0.043 + ph * 1.7) * amp * 0.4]);
  const d = spline(pts, false);
  return close ? `${d} L${CARD_W + 20} ${CARD_H + 20} L-20 ${CARD_H + 20} Z` : d;
};
const RIDGES = [
  { y: 372, amp: 10, o: 0.22, w: 1.4 },
  { y: 402, amp: 12, o: 0.18, w: 1.2 },
  { y: 432, amp: 15, o: 0.14, w: 1.1 },
  { y: 466, amp: 18, o: 0.11, w: 1.0 },
];
const RUTA_GPS = 'M-10 468 C 50 460 92 414 152 420 C 212 426 210 458 262 448 C 314 438 348 372 412 356';
const TRAIL = { ax: 40, ay: 503, bx: 172, by: 393 };
const HUELLAS = [
  { t: 0.00, side: -1, o: 0.50, s: 1.00 },
  { t: 0.22, side: +1, o: 0.40, s: 0.94 },
  { t: 0.44, side: -1, o: 0.31, s: 0.88 },
  { t: 0.66, side: +1, o: 0.23, s: 0.82 },
  { t: 0.88, side: -1, o: 0.15, s: 0.76 },
];
const nameSize = (s) => ((s || '').length > 13 ? 22 : (s || '').length > 10 ? 26 : (s || '').length > 8 ? 30 : 34);

function cardSVG(firstName, email, photoDataUri, uid) {
  const seedPhase = (hashStr(firstName) % 628) / 100;
  const rnd = mulberry32(hashStr(firstName + '|cielo'));
  const estrellas = [];
  while (estrellas.length < 18) {
    const x = 14 + rnd() * (CARD_W - 28);
    const y = 14 + rnd() * 246;
    if (Math.hypot(x - CARD_W / 2, y - 158) < 112) continue;
    estrellas.push({ x, y, r: 0.7 + rnd() * 1.1, o: 0.10 + rnd() * 0.38 });
  }
  const fs = nameSize(firstName);
  const initial = firstName.charAt(0).toUpperCase();
  let s = `<svg width="${CARD_W}" height="${CARD_H}" viewBox="0 0 ${CARD_W} ${CARD_H}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<defs>
  <linearGradient id="tjBg${uid}" x1="0" y1="0" x2="0.35" y2="1"><stop offset="0" stop-color="#0C1B13"/><stop offset="0.55" stop-color="${INK}"/><stop offset="1" stop-color="#050806"/></linearGradient>
  <radialGradient id="tjGlow${uid}" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stop-color="#5FCE73" stop-opacity="0.26"/><stop offset="0.55" stop-color="#3E9B52" stop-opacity="0.10"/><stop offset="1" stop-color="#3E9B52" stop-opacity="0"/></radialGradient>
  <radialGradient id="tjAuroraB${uid}" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stop-color="#3E9B52" stop-opacity="0.15"/><stop offset="1" stop-color="#3E9B52" stop-opacity="0"/></radialGradient>
  <radialGradient id="tjAuroraC${uid}" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stop-color="#A7E89B" stop-opacity="0.07"/><stop offset="1" stop-color="#A7E89B" stop-opacity="0"/></radialGradient>
  <linearGradient id="tjRuta${uid}" gradientUnits="userSpaceOnUse" x1="0" y1="500" x2="${CARD_W}" y2="350"><stop offset="0" stop-color="${GREEN_DK}"/><stop offset="0.5" stop-color="${GREEN}"/><stop offset="1" stop-color="${CREAM}"/></linearGradient>
  <radialGradient id="tjVig${uid}" cx="0.5" cy="0.45" r="0.78"><stop offset="0.55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity="0.46"/></radialGradient>
  <clipPath id="clipPhoto${uid}"><circle cx="200" cy="152" r="65"/></clipPath>
</defs>
<rect width="${CARD_W}" height="${CARD_H}" fill="url(#tjBg${uid})"/>
<circle cx="200" cy="158" r="205" fill="url(#tjGlow${uid})"/>
<circle cx="54" cy="474" r="170" fill="url(#tjAuroraB${uid})"/>
<circle cx="368" cy="492" r="150" fill="url(#tjAuroraC${uid})"/>`;
  for (const st of estrellas) s += `\n<circle cx="${st.x.toFixed(1)}" cy="${st.y.toFixed(1)}" r="${st.r.toFixed(1)}" fill="${CREAM}" fill-opacity="${st.o.toFixed(2)}"/>`;
  TOPO_RADII.forEach((r, i) => {
    s += `\n<path d="${topoRing(200, 158, r, seedPhase + i * 0.8)}" fill="none" stroke="${GREEN}" stroke-width="${i === 0 ? 1.6 : 1.1}" stroke-opacity="${TOPO_OP[i]}"${i === TOPO_RADII.length - 1 ? ' stroke-dasharray="3 7"' : ''}/>`;
  });
  s += `\n<path d="${ridgePath(432, 15, seedPhase * 1.3 + 2.1, true)}" fill="#081109" fill-opacity="0.55"/>`;
  s += `\n<path d="${ridgePath(466, 18, seedPhase * 0.8 + 4.4, true)}" fill="#060C08" fill-opacity="0.72"/>`;
  RIDGES.forEach((rg, i) => {
    s += `\n<path d="${ridgePath(rg.y, rg.amp, seedPhase * (1 + i * 0.25) + i * 2.1, false)}" fill="none" stroke="${GREEN}" stroke-width="${rg.w}" stroke-opacity="${rg.o}"/>`;
  });
  s += `\n<path d="${RUTA_GPS}" fill="none" stroke="url(#tjRuta${uid})" stroke-width="8" stroke-opacity="0.10" stroke-linecap="round"/>`;
  s += `\n<path d="${RUTA_GPS}" fill="none" stroke="url(#tjRuta${uid})" stroke-width="4.5" stroke-opacity="0.22" stroke-linecap="round"/>`;
  s += `\n<path d="${RUTA_GPS}" fill="none" stroke="url(#tjRuta${uid})" stroke-width="2" stroke-linecap="round"/>`;
  s += `\n<path d="${RUTA_GPS}" fill="none" stroke="${CREAM}" stroke-width="1.2" stroke-opacity="0.35" stroke-dasharray="1 11" stroke-linecap="round"/>`;
  s += `\n<circle cx="152" cy="420" r="3" fill="${INK}" stroke="${GREEN}" stroke-width="1.4" stroke-opacity="0.85"/>`;
  s += `\n<circle cx="262" cy="448" r="3" fill="${INK}" stroke="${GREEN}" stroke-width="1.4" stroke-opacity="0.85"/>`;
  s += `\n<circle cx="396" cy="360" r="9" fill="none" stroke="${CREAM}" stroke-width="1" stroke-opacity="0.35"/>`;
  s += `\n<circle cx="396" cy="360" r="3.4" fill="${CREAM}"/>`;
  for (const h of HUELLAS) {
    const x = TRAIL.ax + (TRAIL.bx - TRAIL.ax) * h.t + h.side * 5.6;
    const y = TRAIL.ay + (TRAIL.by - TRAIL.ay) * h.t + h.side * 7;
    const rot = 47 + (h.side > 0 ? 5 : -4);
    s += `\n<g transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${rot}) scale(${h.s})" opacity="${h.o}"><ellipse cx="0" cy="0" rx="4.4" ry="7.2" fill="${GREEN}" transform="rotate(-7)"/><ellipse cx="0.8" cy="10.6" rx="3.3" ry="4.3" fill="${GREEN}" transform="rotate(-4 0.8 10.6)"/></g>`;
  }
  s += `\n<path d="M266 96 L266 66" stroke="${GREEN_LT}" stroke-width="2" stroke-linecap="round" stroke-opacity="0.9"/>`;
  s += `\n<path d="M267.5 67 L286 73.5 L267.5 80 Z" fill="${GREEN_LT}" fill-opacity="0.92"/>`;
  s += `\n<circle cx="266" cy="97.5" r="2" fill="${GREEN_LT}"/>`;
  for (let row = 0; row < 4; row++) for (let col = 0; col < 5; col++) s += `\n<circle cx="${CARD_W - 88 + col * 13}" cy="${30 + row * 13}" r="1.4" fill="${GREEN}" fill-opacity="0.15"/>`;
  s += `\n<path d="M16 46 L16 16 L46 16" fill="none" stroke="${GREEN}" stroke-width="2.5" stroke-opacity="0.7"/>`;
  s += `\n<path d="M384 474 L384 504 L354 504" fill="none" stroke="${GREEN}" stroke-width="2.5" stroke-opacity="0.7"/>`;
  s += `\n<rect width="${CARD_W}" height="${CARD_H}" fill="url(#tjVig${uid})"/>`;
  /* ── Foto (la cumbre) ── */
  s += `\n<circle cx="200" cy="152" r="86" fill="none" stroke="rgba(123,200,108,0.35)" stroke-width="1.5" stroke-dasharray="5 5"/>`;
  s += `\n<circle cx="200" cy="152" r="74" fill="${GREEN_LT}" stroke="${GREEN_DK}" stroke-width="1"/>`;
  s += `\n<circle cx="200" cy="152" r="70" fill="${INK}"/>`;
  if (photoDataUri) {
    s += `\n<image xlink:href="${photoDataUri}" x="135" y="87" width="130" height="130" clip-path="url(#clipPhoto${uid})" preserveAspectRatio="xMidYMid slice"/>`;
  } else {
    s += `\n<circle cx="200" cy="152" r="65" fill="${GREEN_DK}"/>`;
    s += `\n<text x="200" y="171" text-anchor="middle" font-family="Kalam-Bold" font-size="54" font-weight="800" fill="#fff">${initial}</text>`;
  }
  /* ── Nombre + subrayados ── */
  const nameTop = 66 + 172 + 26;               // 264
  const nameBaseline = nameTop + fs * 0.84;
  s += `\n<text x="200" y="${nameBaseline.toFixed(1)}" text-anchor="middle" font-family="Inter" font-weight="900" font-size="${fs}" letter-spacing="4" fill="#F4F8F2">${firstName.toUpperCase()}</text>`;
  const u1 = nameTop + fs * 1.2 + 13;           // ~318
  s += `\n<rect x="134" y="${u1.toFixed(1)}" width="132" height="3.5" rx="1.75" fill="${GREEN}" transform="rotate(-1.2 200 ${(u1 + 1.75).toFixed(1)})"/>`;
  s += `\n<rect x="163" y="${(u1 + 7.5).toFixed(1)}" width="74" height="2.5" rx="1.25" fill="rgba(123,200,108,0.44)" transform="rotate(-1.2 200 ${(u1 + 8.75).toFixed(1)})"/>`;
  /* ── Píldora del correo ── */
  const pillW = 28 + 12 + 7 + email.length * 6.15;
  const pillX = 200 - pillW / 2, pillY = CARD_H - 26 - 30;
  s += `\n<rect x="${pillX.toFixed(1)}" y="${pillY}" width="${pillW.toFixed(1)}" height="30" rx="15" fill="rgba(255,255,255,0.05)" stroke="rgba(255,255,255,0.12)" stroke-width="1"/>`;
  const iconX = pillX + 14, iconY = pillY + 9;
  s += `\n<g transform="translate(${iconX.toFixed(1)} ${iconY}) scale(0.5)" fill="none" stroke="#8FAF97" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="3"/><path d="m2 7 10 6L22 7"/></g>`;
  s += `\n<text x="${(iconX + 19).toFixed(1)}" y="${pillY + 19}" font-family="Inter" font-size="11.5" letter-spacing="0.4" fill="#AEC4B4">${email}</text>`;
  s += `\n</svg>`;
  return s;
}

const WS = process.env.ARENA_WORKSPACE || '/home/user';
const avatar = 'data:image/jpeg;base64,' + fs.readFileSync(path.join(WS, 'uploads/avatar-b64.txt'), 'utf8').trim();

const c1 = cardSVG('Jorge', 'jorge@ejemplo.com', avatar, '1');
const c2 = cardSVG('Alejandra', 'alejandra@ejemplo.com', null, '2');

const combined = `<svg width="860" height="580" viewBox="0 0 860 580" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<rect width="860" height="580" fill="#070B09"/>
<g transform="translate(20 25)">${c1.replace(/^<svg[^>]*>/, '').replace(/<\/svg>$/, '')}</g>
<g transform="translate(440 25)">${c2.replace(/^<svg[^>]*>/, '').replace(/<\/svg>$/, '')}</g>
</svg>`;

const opts = {
  background: '#070B09',
  fitTo: { mode: 'width', value: 1290 },
  font: {
    fontDirs: ['/tmp/render/node_modules/@fontsource/inter/files', path.join(WS, 'proyecto/mi-app-entrenos/assets/fonts')],
    defaultFontFamily: 'Inter',
    serifFamily: 'Inter',
    sansSerifFamily: 'Inter',
  },
};
const out = process.argv[2] || '/tmp/render/tarjeta-cima-check.png';
const png = new Resvg(combined, opts).render().asPng();
fs.writeFileSync(out, png);
console.log('PNG escrito:', out, png.length, 'bytes');
