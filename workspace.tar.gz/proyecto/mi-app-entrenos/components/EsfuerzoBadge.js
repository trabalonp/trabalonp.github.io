// components/EsfuerzoBadge.js
// Insignia de esfuerzo (TSS) para las tarjetas de entreno: [E|91]
// Se coloca en la parte inferior derecha del recuadro del entreno.
// Solo se pinta si hay un valor de esfuerzo > 0 (entrenos sincronizados
// o sesiones guardadas con esfuerzo); si no, devuelve null y no ocupa sitio.
//
// DISEÑO: es UNA sola píldora partida en dos mitades pegadas (sin separación
// entre ellas) y con el mismo borde exterior continuo. Cada mitad conserva su
// color propio:
//   · "E"     -> gris muy claro (#EDF0F2) con el texto oscuro.
//   · número  -> gris medio claro (#7A848D), más claro que el gris oscuro
//                anterior (#333B41), con el texto blanco.
// Al estar las dos mitades dentro del mismo recuadro con borderRadius y
// overflow:'hidden', los bordes se "cosen" y no se ven líneas dobles.
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

const BORDE = 'rgba(51, 59, 65, 0.30)';

export default function EsfuerzoBadge({ value, style }) {
  const v = Math.round(Number(value) || 0);
  if (!v || v <= 0) return null;
  return (
    <View style={[styles.wrap, style]} accessibilityLabel={`Esfuerzo ${v}`}>
      <View style={styles.labelChip}>
        <Text style={styles.labelText}>E</Text>
      </View>
      <View style={styles.valueChip}>
        <Text style={styles.valueText}>{v}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  // Recuadro único: sin gap entre las dos mitades.
  wrap: {
    flexDirection: 'row',
    alignItems: 'stretch',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: BORDE,
    overflow: 'hidden',
    alignSelf: 'flex-start',
  },
  // Mitad izquierda: la "E"
  labelChip: {
    backgroundColor: '#EDF0F2',
    paddingHorizontal: 4,
    justifyContent: 'center',
    alignItems: 'center',
  },
  labelText: {
    color: '#333B41',
    fontSize: 11,
    fontWeight: '800',
    lineHeight: 15,
  },
  // Mitad derecha: el número (gris MÁS CLARO que antes)
  valueChip: {
    backgroundColor: '#7A848D',
    paddingHorizontal: 5,
    minWidth: 22,
    justifyContent: 'center',
    alignItems: 'center',
    borderLeftWidth: 1,
    borderLeftColor: BORDE,
  },
  valueText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '800',
    lineHeight: 15,
  },
});
