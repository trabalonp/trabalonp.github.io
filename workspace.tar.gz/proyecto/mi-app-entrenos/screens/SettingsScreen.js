// screens/SettingsScreen.js
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import * as Sharing from 'expo-sharing';
import SystemBars from '../components/SystemBars';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { useCallback, useMemo, useRef, useState } from 'react';
import {
  Alert, Image, Modal,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
  useColorScheme,
} from 'react-native';
import ViewShot from 'react-native-view-shot';
import Svg, {
  Circle, Defs, Ellipse, G, LinearGradient, Path, RadialGradient, Rect, Stop,
} from 'react-native-svg';
import { useFonts } from 'expo-font';
import { auth, db } from '../firebaseConfig';
import { cacheProfile, getCachedProfile } from '../services/profileCache';
import { getThemeColors, saveSettings, useAppSettings } from '../services/appSettings';

const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';

/* ── Tarjeta compartible: artwork 4:5 "LA CIMA" (paleta de marca) ──
   Mapa topográfico donde la foto es la cumbre: anillos de nivel, cielo
   estrellado, terreno en capas, ruta GPS brillante y huellas que ascienden.
   Sin textos de marca: solo nombre de pila y correo. ── */
const CARD_W    = 400;   // puntos; se captura con pixelRatio 3 → 1200×1560 px
const CARD_H    = 520;
const GREEN     = '#7BC86C';  // verde claro del logo (tema noche)
const GREEN_DK  = '#2F6B3A';  // verde oscuro del logo
const GREEN_LT  = '#8FE08A';  // verde vivo para el anillo
const INK       = '#0C1310';  // carbón del fondo de la tarjeta
const CREAM     = '#EAF7E6';  // blanco cálido para estrellas y ruta

/* Aleatorio determinista: el nombre semilla el mapa (mismo nombre → mismo
   mapa; distinto nombre → anillos y cielo distintos). Estable entre renders. */
const hashStr = (s) => {
  let h = 2166136261;
  for (let i = 0; i < (s || '').length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
};
const mulberry32 = (a) => () => {
  a |= 0; a = (a + 0x6D2B79F5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

/* Catmull-Rom → Bézier: curva suave que pasa por todos los puntos */
const spline = (pts, close) => {
  const n = pts.length;
  const at = (i) => pts[close ? (i + n) % n : Math.min(Math.max(i, 0), n - 1)];
  let d = `M${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`;
  for (let i = 0; i < (close ? n : n - 1); i++) {
    const p0 = at(i - 1), p1 = at(i), p2 = at(i + 1), p3 = at(i + 2);
    const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C${c1x.toFixed(1)} ${c1y.toFixed(1)},${c2x.toFixed(1)} ${c2y.toFixed(1)},${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`;
  }
  return close ? d + ' Z' : d;
};

/* Anillo topográfico (curva de nivel) alrededor de la cumbre, achatado
   como visto en perspectiva de mapa */
const topoRing = (cx, cy, r, ph, wob = 0.13) => {
  const pts = [];
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    const k = 1 + wob * (Math.sin(a * 2 + ph) * 0.6 + Math.sin(a * 3 - ph * 1.7) * 0.4);
    pts.push([cx + Math.cos(a) * r * k, cy + Math.sin(a) * r * k * 0.86]);
  }
  return spline(pts, true);
};
const TOPO_RADII = [96, 124, 154, 186, 222];
const TOPO_OP    = [0.38, 0.28, 0.20, 0.14, 0.09];

/* Arista de terreno que cruza la tarjeta; close=true rellena hasta abajo */
const ridgePath = (y0, amp, ph, close) => {
  const pts = [];
  for (let x = -20; x <= CARD_W + 20; x += 24) {
    pts.push([x, y0 + Math.sin(x * 0.016 + ph) * amp + Math.sin(x * 0.043 + ph * 1.7) * amp * 0.4]);
  }
  const d = spline(pts, false);
  return close ? `${d} L${CARD_W + 20} ${CARD_H + 20} L-20 ${CARD_H + 20} Z` : d;
};
const RIDGES = [
  { y: 372, amp: 10, o: 0.22, w: 1.4 },
  { y: 402, amp: 12, o: 0.18, w: 1.2 },
  { y: 432, amp: 15, o: 0.14, w: 1.1 },
  { y: 466, amp: 18, o: 0.11, w: 1.0 },
];

/* Ruta GPS con brillo (trazo degradado) que sobrevuela el terreno */
const RUTA_GPS = 'M-10 468 C 50 460 92 414 152 420 C 212 426 210 458 262 448 C 314 438 348 372 412 356';

/* Huellas que ascienden en diagonal hacia la cumbre (alternando pie) */
const TRAIL = { ax: 40, ay: 503, bx: 172, by: 393 };
const HUELLAS = [
  { t: 0.00, side: -1, o: 0.50, s: 1.00 },
  { t: 0.22, side: +1, o: 0.40, s: 0.94 },
  { t: 0.44, side: -1, o: 0.31, s: 0.88 },
  { t: 0.66, side: +1, o: 0.23, s: 0.82 },
  { t: 0.88, side: -1, o: 0.15, s: 0.76 },
];

export default function SettingsScreen() {
  const user = auth.currentUser;
  const navigation = useNavigation();
  const shareCardRef = useRef();
  const appSettings = useAppSettings();
  const lang = appSettings.language;            // re-renderiza al cambiar idioma
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  useFonts({ 'Kalam-Bold': require('../assets/fonts/Kalam-Bold.ttf') });
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción

  // Menú con etiquetas traducidas (las claves y el orden no cambian)
  const MENU_ITEMS = [
    { key: 'perfil',     label: L('Perfil', 'Profile'),                 icon: 'person-outline' },
    { key: 'sync',       label: L('Sincronización', 'Sync'),            icon: 'sync-outline' },
    { key: 'zonas',      label: L('Zonas', 'Zones'),                    icon: 'pulse-outline' },
    { key: 'donaciones', label: L('Donaciones', 'Donations'),           icon: 'cafe' },
    { key: 'entrenador', label: L('Mi Entrenador', 'My Coach'),         icon: 'people-outline' },
    { key: 'ajustes',    label: L('Ajustes', 'Settings'), icon: 'options-outline' },
    { key: 'soporte',    label: L('Soporte', 'Support'),                icon: 'help-circle-outline' },
  ];

  /* ── Compartir tarjeta de perfil ── */
  const handleShareProfile = async () => {
    try {
      if (shareCardRef.current) {
        const uri = await shareCardRef.current.capture({
          format: 'png',
          quality: 1,
          pixelRatio: 3,   // 400×520 pt → PNG de 1200×1560 px, nítido al compartir
        });
        await Sharing.shareAsync(uri);
      }
    } catch (e) {
      Alert.alert(L('Error', 'Error'), L('No se pudo compartir la tarjeta', 'Could not share the card'));
    }
  };

  const [athleteId, setAthleteId] = useState(null);
  useFocusEffect(
    useCallback(() => {
      AsyncStorage.getItem('currentAthleteId').then(setAthleteId);
    }, [])
  );

  // Estado local para el switch
  const [notifs, setNotifs] = useState(true);
  const [themePickerOpen, setThemePickerOpen] = useState(false);
  const [profile, setProfile] = useState(null);

  /* ── Obtener perfil desde Firestore y la preferencia de notificaciones ── */
  const fetchProfile = useCallback(async () => {
    if (!user) return;
    const cached = await getCachedProfile(user.uid);
    if (cached) {
      setProfile(cached);
      if (cached.notificacionesActivadas !== undefined) {
        setNotifs(cached.notificacionesActivadas);
      }
      try {
        const snap = await getDoc(doc(db, 'perfiles', user.uid));
        if (snap.exists()) {
          const data = snap.data();
          setProfile(data);
          await cacheProfile(user.uid, data);
          if (data.notificacionesActivadas !== undefined) {
            setNotifs(data.notificacionesActivadas);
          }
        }
      } catch (e) {}
      return;
    }
    try {
      const snap = await getDoc(doc(db, 'perfiles', user.uid));
      if (snap.exists()) {
        const data = snap.data();
        setProfile(data);
        await cacheProfile(user.uid, data);
        if (data.notificacionesActivadas !== undefined) {
          setNotifs(data.notificacionesActivadas);
        }
      } else {
        setProfile(null);
      }
    } catch (e) {
      console.log('Error al cargar perfil:', e);
    }
  }, [user]);

  useFocusEffect(
    useCallback(() => {
      const load = async () => {
        const cached = await getCachedProfile(user.uid);
        if (cached) {
          setProfile(cached);
          if (cached.notificacionesActivadas !== undefined) {
            setNotifs(cached.notificacionesActivadas);
          }
        }
        fetchProfile();
      };
      load();
    }, [fetchProfile])
  );

  const handleToggleNotifs = async (value) => {
    setNotifs(value);
    try {
      await setDoc(doc(db, 'perfiles', user.uid), { notificacionesActivadas: value }, { merge: true });
    } catch (error) {
      Alert.alert(L('Error', 'Error'), L('No se pudo guardar la preferencia de notificaciones', 'Could not save the notification preference'));
      setNotifs(!value);
    }
  };

  const handleMenuItem = (key) => {
    if (key === 'perfil') {
      navigation.navigate('Profile');
      return;
    }
    if (key === 'sync') {
      navigation.navigate('SyncSettings');
      return;
    }
    if (key === 'entrenador') {
      navigation.navigate('Coach');
      return;
    }
    if (key === 'zonas') {
      navigation.navigate('Zones', { athleteId });
      return;
    }
    if (key === 'donaciones') {
      navigation.navigate('Donaciones');
      return;
    }
    if (key === 'ajustes') {
      navigation.navigate('AppSettings'); // ← pantalla de idioma/unidades/fecha
      return;
    }
    if (key === 'soporte') {
      navigation.navigate('Support'); // ← pantalla de soporte (correo a trabalonp@gmail.com)
      return;
    }
    Alert.alert(L('Próximamente', 'Coming soon'), L(`La sección "${key}" estará disponible pronto.`, `The "${key}" section will be available soon.`));
  };

  /* ── Datos para el header ── */
  const profilePhoto = profile?.foto;
  const firstName = profile?.nombre?.trim().split(' ')[0] || user?.displayName || 'Atleta';
  const initial = firstName.charAt(0).toUpperCase();
  // El nombre se escala solo si es largo para que nunca se salga del arte
  const nameSize = (s) => ((s || '').length > 13 ? 22 : (s || '').length > 10 ? 26 : (s || '').length > 8 ? 30 : 34);

  /* ── Semilla del artwork: el nombre genera SU mapa (único por persona) ── */
  const seedPhase = useMemo(() => (hashStr(firstName) % 628) / 100, [firstName]);
  const estrellas = useMemo(() => {
    const rnd = mulberry32(hashStr(firstName + '|cielo'));
    const out = [];
    while (out.length < 18) {
      const x = 14 + rnd() * (CARD_W - 28);
      const y = 14 + rnd() * 246;                       // solo zona de cielo
      if (Math.hypot(x - CARD_W / 2, y - 158) < 112) continue;  // no tapar la foto
      out.push({ x, y, r: 0.7 + rnd() * 1.1, o: 0.10 + rnd() * 0.38 });
    }
    return out;
  }, [firstName]);

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header con foto / inicial y nombre + email */}
        <View style={styles.header}>
          <View style={styles.avatar}>
            {profilePhoto ? (
              <Image source={{ uri: `data:image/jpeg;base64,${profilePhoto}` }} style={styles.avatarImg} />
            ) : user?.photoURL ? (
              <Image source={{ uri: user.photoURL }} style={styles.avatarImg} />
            ) : (
              <Text style={styles.avatarInitial}>{initial}</Text>
            )}
          </View>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={[styles.userName, { color: theme.text }]}>{firstName}</Text>
              <TouchableOpacity onPress={handleShareProfile} style={{ marginLeft: 8 }}>
                <Ionicons name="share-outline" size={22} color={BLUE} />
              </TouchableOpacity>
            </View>
            <Text style={[styles.userEmail, { color: theme.muted }]}>{user?.email}</Text>
          </View>
        </View>

        {/* Menú */}
        <View style={[styles.menuCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
          {MENU_ITEMS.map((item, index) => (
            <TouchableOpacity
              key={item.key}
              style={[
                styles.menuRow,
                index < MENU_ITEMS.length - 1 && styles.menuRowBorder,
                index < MENU_ITEMS.length - 1 && { borderBottomColor: theme.border },
              ]}
              onPress={() => handleMenuItem(item.key)}
              activeOpacity={0.7}
            >
              <Ionicons name={item.icon} size={20} color={theme.muted} />
              <Text style={[styles.menuLabel, { color: theme.text }]}>{item.label}</Text>
              <Ionicons name="chevron-forward" size={18} color={theme.navText} />
            </TouchableOpacity>
          ))}
        </View>

        {/* Switch de notificaciones funcional */}
        <View style={[styles.menuCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.menuRow}>
            <Ionicons name="notifications-outline" size={20} color={theme.muted} />
            <Text style={[styles.menuLabel, { color: theme.text }]}>{L('Activar Notificaciones', 'Enable Notifications')}</Text>
            <Switch
              value={notifs}
              onValueChange={handleToggleNotifs}
              trackColor={{ false: theme.border, true: BLUE }}
              thumbColor="#fff"
            />
          </View>
          <TouchableOpacity style={styles.menuRow} onPress={() => setThemePickerOpen(true)}>
            <Ionicons name="contrast-outline" size={20} color={BLUE} />
            <Text style={[styles.menuLabel, { color: theme.text }]}>{L('Contraste', 'Contrast')}</Text>
            <Text style={[styles.themeValue, { color: theme.muted }]}>{appSettings.themeMode === 'day' ? L('Día', 'Day') : appSettings.themeMode === 'device' ? L('Dispositivo', 'Device') : L('Noche', 'Night')}</Text>
            <Ionicons name="chevron-forward" size={18} color={theme.navText} />
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Menú desplegable de contraste: usa el tema activo (claro/oscuro) */}
      <Modal visible={themePickerOpen} transparent animationType="fade" onRequestClose={() => setThemePickerOpen(false)}>
        <View style={[styles.overlay, { backgroundColor: theme.overlay }]}>
          <TouchableOpacity style={styles.overlayClose} activeOpacity={1} onPress={() => setThemePickerOpen(false)} />
          <View style={[styles.themePicker, { backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border }]}>
            <Text style={[styles.pickerTitle, { color: theme.muted }]}>{L('Contraste', 'Contrast')}</Text>
            {[
              ['day', L('Día', 'Day')],
              ['night', L('Noche', 'Night')],
              ['device', L('Dispositivo', 'Device')],
            ].map(([value, label]) => {
              const activo = appSettings.themeMode === value;
              return (
                <TouchableOpacity
                  key={value}
                  style={[styles.themeOption, { borderBottomColor: theme.border }, activo && [styles.themeOptionActive, { backgroundColor: BLUE + '22' }]]}
                  onPress={() => { saveSettings({ themeMode: value }); setThemePickerOpen(false); }}
                >
                  <Text style={[styles.themeOptionText, { color: theme.text }, activo && { color: BLUE, fontWeight: '700' }]}>{label}</Text>
                  {activo && <Ionicons name="checkmark-circle" size={18} color={BLUE} />}
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
        <SystemBars />
      </Modal>

      {/* ── TARJETA OCULTA PARA COMPARTIR ("LA CIMA") ──
          El ViewShot mide EXACTAMENTE lo que mide la tarjeta (CARD_W×CARD_H):
          el PNG sale recortado al arte, sin franjas negras alrededor. */}
      <ViewShot
        ref={shareCardRef}
        options={{ format: 'png', quality: 1, pixelRatio: 3 }}
        style={styles.shareCardWrapper}
      >
        <View style={styles.shareCard}>
          {/* ══ ARTWORK "LA CIMA" (SVG): mapa topográfico cuya cumbre es la
               foto — anillos de nivel, cielo estrellado, auroras, terreno en
               capas, ruta GPS con brillo, huellas ascendiendo y bandera.
               El nombre semilla el mapa: cada persona tiene el suyo. ══ */}
          <Svg width={CARD_W} height={CARD_H} style={styles.shareArt}>
            <Defs>
              <LinearGradient id="tjBg" x1="0" y1="0" x2="0.35" y2="1">
                <Stop offset="0" stopColor="#0C1B13" />
                <Stop offset="0.55" stopColor={INK} />
                <Stop offset="1" stopColor="#050806" />
              </LinearGradient>
              <RadialGradient id="tjGlow" cx="0.5" cy="0.5" r="0.5">
                <Stop offset="0" stopColor="#5FCE73" stopOpacity="0.26" />
                <Stop offset="0.55" stopColor="#3E9B52" stopOpacity="0.10" />
                <Stop offset="1" stopColor="#3E9B52" stopOpacity="0" />
              </RadialGradient>
              <RadialGradient id="tjAuroraB" cx="0.5" cy="0.5" r="0.5">
                <Stop offset="0" stopColor="#3E9B52" stopOpacity="0.15" />
                <Stop offset="1" stopColor="#3E9B52" stopOpacity="0" />
              </RadialGradient>
              <RadialGradient id="tjAuroraC" cx="0.5" cy="0.5" r="0.5">
                <Stop offset="0" stopColor="#A7E89B" stopOpacity="0.07" />
                <Stop offset="1" stopColor="#A7E89B" stopOpacity="0" />
              </RadialGradient>
              <LinearGradient id="tjRuta" gradientUnits="userSpaceOnUse" x1="0" y1="500" x2={CARD_W} y2="350">
                <Stop offset="0" stopColor={GREEN_DK} />
                <Stop offset="0.5" stopColor={GREEN} />
                <Stop offset="1" stopColor={CREAM} />
              </LinearGradient>
              <RadialGradient id="tjVig" cx="0.5" cy="0.45" r="0.78">
                <Stop offset="0.55" stopColor="#000000" stopOpacity="0" />
                <Stop offset="1" stopColor="#000000" stopOpacity="0.46" />
              </RadialGradient>
            </Defs>

            <Rect width={CARD_W} height={CARD_H} fill="url(#tjBg)" />

            {/* Auroras: halo tras la foto (sol de cumbre) + esquiras bajas */}
            <Circle cx={CARD_W / 2} cy={158} r={205} fill="url(#tjGlow)" />
            <Circle cx={54} cy={474} r={170} fill="url(#tjAuroraB)" />
            <Circle cx={368} cy={492} r={150} fill="url(#tjAuroraC)" />

            {/* Cielo estrellado (único por nombre) */}
            {estrellas.map((s, i) => (
              <Circle key={`st-${i}`} cx={s.x} cy={s.y} r={s.r} fill={CREAM} fillOpacity={s.o} />
            ))}

            {/* Anillos topográficos: curvas de nivel de la cumbre */}
            {TOPO_RADII.map((r, i) => (
              <Path
                key={`topo-${r}`}
                d={topoRing(CARD_W / 2, 158, r, seedPhase + i * 0.8)}
                fill="none" stroke={GREEN}
                strokeWidth={i === 0 ? 1.6 : 1.1}
                strokeOpacity={TOPO_OP[i]}
                strokeDasharray={i === TOPO_RADII.length - 1 ? '3 7' : undefined}
              />
            ))}

            {/* Terreno: aristas rellenas (profundidad) + curvas de nivel */}
            <Path d={ridgePath(432, 15, seedPhase * 1.3 + 2.1, true)} fill="#081109" fillOpacity={0.5} />
            <Path d={ridgePath(466, 18, seedPhase * 0.8 + 4.4, true)} fill="#060C08" fillOpacity={0.65} />
            {RIDGES.map((rg, i) => (
              <Path
                key={`ridge-${i}`}
                d={ridgePath(rg.y, rg.amp, seedPhase * (1 + i * 0.25) + i * 2.1, false)}
                fill="none" stroke={GREEN} strokeWidth={rg.w} strokeOpacity={rg.o}
              />
            ))}

            {/* Ruta GPS: degradado + brillo por capas + trazo punteado */}
            <Path d={RUTA_GPS} fill="none" stroke="url(#tjRuta)" strokeWidth={8} strokeOpacity={0.10} strokeLinecap="round" />
            <Path d={RUTA_GPS} fill="none" stroke="url(#tjRuta)" strokeWidth={4.5} strokeOpacity={0.22} strokeLinecap="round" />
            <Path d={RUTA_GPS} fill="none" stroke="url(#tjRuta)" strokeWidth={2} strokeLinecap="round" />
            <Path d={RUTA_GPS} fill="none" stroke={CREAM} strokeWidth={1.2} strokeOpacity={0.35} strokeDasharray="1 11" strokeLinecap="round" />
            <Circle cx={152} cy={420} r={3} fill={INK} stroke={GREEN} strokeWidth={1.4} strokeOpacity={0.85} />
            <Circle cx={262} cy={448} r={3} fill={INK} stroke={GREEN} strokeWidth={1.4} strokeOpacity={0.85} />
            <Circle cx={396} cy={360} r={9} fill="none" stroke={CREAM} strokeWidth={1} strokeOpacity={0.35} />
            <Circle cx={396} cy={360} r={3.4} fill={CREAM} />

            {/* Huellas que ascienden desde la esquina inferior izquierda */}
            {HUELLAS.map((h, i) => {
              const x = TRAIL.ax + (TRAIL.bx - TRAIL.ax) * h.t + h.side * 5.6;
              const y = TRAIL.ay + (TRAIL.by - TRAIL.ay) * h.t + h.side * 7;
              const rot = 47 + (h.side > 0 ? 5 : -4);
              return (
                <G key={`huella-${i}`} transform={`translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${rot}) scale(${h.s})`} opacity={h.o}>
                  <Ellipse cx={0} cy={0} rx={4.4} ry={7.2} fill={GREEN} transform="rotate(-7)" />
                  <Ellipse cx={0.8} cy={10.6} rx={3.3} ry={4.3} fill={GREEN} transform="rotate(-4 0.8 10.6)" />
                </G>
              );
            })}

            {/* Bandera de cima, plantada sobre el aro de la foto */}
            <Path d="M266 96 L266 66" stroke={GREEN_LT} strokeWidth={2} strokeLinecap="round" strokeOpacity={0.9} />
            <Path d="M267.5 67 L286 73.5 L267.5 80 Z" fill={GREEN_LT} fillOpacity={0.92} />
            <Circle cx={266} cy={97.5} r={2} fill={GREEN_LT} />

            {/* Textura de puntos (arriba derecha) y esquinas de galería */}
            {Array.from({ length: 4 }).map((_, row) =>
              Array.from({ length: 5 }).map((__, col) => (
                <Circle
                  key={`dot-${row}-${col}`}
                  cx={CARD_W - 88 + col * 13} cy={30 + row * 13} r={1.4}
                  fill={GREEN} fillOpacity={0.15}
                />
              ))
            )}
            <Path d="M16 46 L16 16 L46 16" fill="none" stroke={GREEN} strokeWidth={2.5} strokeOpacity={0.7} />
            <Path
              d={`M${CARD_W - 16} ${CARD_H - 46} L${CARD_W - 16} ${CARD_H - 16} L${CARD_W - 46} ${CARD_H - 16}`}
              fill="none" stroke={GREEN} strokeWidth={2.5} strokeOpacity={0.7}
            />

            <Rect width={CARD_W} height={CARD_H} fill="url(#tjVig)" />
          </Svg>

          {/* ══ FOTO: la cumbre — aro punteado + anillo verde doble ══ */}
          <View style={styles.shareAvatarWrap}>
            <View style={styles.shareAvatarDashed} />
            <View style={styles.shareAvatarRingOut}>
              <View style={styles.shareAvatarRingIn}>
                {profilePhoto ? (
                  <Image
                    source={{ uri: `data:image/jpeg;base64,${profilePhoto}` }}
                    style={styles.shareAvatarImg}
                  />
                ) : user?.photoURL ? (
                  <Image source={{ uri: user.photoURL }} style={styles.shareAvatarImg} />
                ) : (
                  <View style={[styles.shareAvatarImg, styles.shareAvatarFallback]}>
                    <Text style={styles.shareAvatarInitial}>{initial}</Text>
                  </View>
                )}
              </View>
            </View>
          </View>

          {/* ══ NOMBRE de pila (sin apellidos) + subrayado a mano ══ */}
          <Text style={[styles.shareName, { fontSize: nameSize(firstName) }]} numberOfLines={1}>
            {firstName}
          </Text>
          <View style={styles.shareUnderline} />
          <View style={styles.shareUnderline2} />

          {/* ══ PIE: píldora con el correo (único texto adicional) ══ */}
          <View style={styles.shareFooter}>
            <View style={styles.shareEmailPill}>
              <Ionicons name="mail-outline" size={12} color="#8FAF97" />
              <Text style={styles.shareEmailText} numberOfLines={1}>{user?.email}</Text>
            </View>
          </View>
        </View>
      </ViewShot>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 20, paddingTop: 60, paddingBottom: 24, gap: 16,
  },
  avatar: {
    width: 56, height: 56, borderRadius: 28,
    backgroundColor: BLUE, alignItems: 'center', justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarImg:     { width: 56, height: 56 },
  avatarInitial: { color: '#fff', fontSize: 22, fontWeight: '800' },
  userName:      { color: '#fff', fontSize: 18, fontWeight: '700' },
  userEmail:     { color: '#8FA8C8', fontSize: 13, marginTop: 2 },
  menuCard: {
    backgroundColor: CARD, marginHorizontal: 16,
    marginBottom: 12, borderRadius: 12,
    borderWidth: 1, borderColor: BORDER, overflow: 'hidden',
  },
  menuRow: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 16, gap: 14,
  },
  menuRowBorder: { borderBottomWidth: 1, borderBottomColor: BORDER },
  menuLabel: { flex: 1, color: '#fff', fontSize: 15 },
  themeValue: { color: '#8FA8C8', fontSize: 13, marginRight: 4 },
  overlay: { flex: 1, backgroundColor: '#00000088', justifyContent: 'center', alignItems: 'center' },
  overlayClose: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
  themePicker: { width: '80%', backgroundColor: CARD, borderRadius: 12, overflow: 'hidden', paddingVertical: 6 },
  pickerTitle: { color: '#8FA8C8', fontSize: 12, fontWeight: '700', paddingHorizontal: 16, paddingTop: 10, paddingBottom: 6, textTransform: 'uppercase' },
  themeOption: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: BORDER },
  themeOptionActive: { backgroundColor: '#2A4060' },
  themeOptionText: { color: '#fff', fontSize: 14 },
  // ── Tarjeta para compartir: artwork 4:5 "LA CIMA", se captura tal cual ──
  shareCardWrapper: {
    position: 'absolute',
    top: -1200,                 // fuera de pantalla; el ViewShot mide exacto
    left: 0,
    width: CARD_W,
    height: CARD_H,
    backgroundColor: 'transparent',
    overflow: 'hidden',
  },
  shareCard: {
    width: CARD_W,
    height: CARD_H,
    backgroundColor: INK,
    alignItems: 'center',
    overflow: 'hidden',
  },
  shareArt: { position: 'absolute', top: 0, left: 0 },
  shareAvatarWrap: {
    width: 172, height: 172, marginTop: 66,   // la foto corona el mapa
    alignItems: 'center', justifyContent: 'center',
  },
  shareAvatarDashed: {
    position: 'absolute', width: 172, height: 172, borderRadius: 86,
    borderWidth: 1.5, borderStyle: 'dashed', borderColor: GREEN + '59',
  },
  shareAvatarRingOut: {
    width: 148, height: 148, borderRadius: 74,
    backgroundColor: GREEN_LT, borderWidth: 1, borderColor: GREEN_DK,
    alignItems: 'center', justifyContent: 'center',
  },
  shareAvatarRingIn: {
    width: 140, height: 140, borderRadius: 70, backgroundColor: INK,
    alignItems: 'center', justifyContent: 'center',
  },
  shareAvatarImg: { width: 130, height: 130, borderRadius: 65 },
  shareAvatarFallback: { backgroundColor: GREEN_DK, alignItems: 'center', justifyContent: 'center' },
  shareAvatarInitial: { color: '#fff', fontSize: 54, fontWeight: '800', fontFamily: 'Kalam-Bold' },
  shareName: {
    color: '#F4F8F2', fontWeight: '900', letterSpacing: 4,
    fontFamily: 'Kalam-Bold',          // el nombre como firma manuscrita
    textTransform: 'uppercase', marginTop: 26,
    maxWidth: CARD_W - 56, textAlign: 'center',
  },
  shareUnderline: {
    height: 3.5, width: 132, backgroundColor: GREEN, borderRadius: 3,
    marginTop: 13, transform: [{ rotate: '-1.2deg' }],
  },
  shareUnderline2: {
    height: 2.5, width: 74, backgroundColor: GREEN + '70', borderRadius: 3,
    marginTop: 4, transform: [{ rotate: '-1.2deg' }],
  },
  shareFooter: { position: 'absolute', bottom: 26, alignSelf: 'center', maxWidth: CARD_W - 48 },
  shareEmailPill: {
    flexDirection: 'row', alignItems: 'center', gap: 7,
    backgroundColor: '#FFFFFF0D', borderWidth: 1, borderColor: '#FFFFFF1F',
    borderRadius: 999, paddingHorizontal: 14, paddingVertical: 7,
  },
  shareEmailText: { color: '#AEC4B4', fontSize: 11.5, letterSpacing: 0.4 },
});
