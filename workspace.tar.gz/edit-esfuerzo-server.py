#!/usr/bin/env python3
"""Corrige el cálculo/obtención del ESFUERZO (TSS) en el server Vercel.

1) api/sync-intervals.js:
   - pickTrainingLoad(): primer valor >0 entre training_load, icu_training_load,
     strain_score, suffer_score, load (la cadena ?? anterior se rompía con un 0).
   - Al CREAR el documento ya guarda esfuerzo (desde la lista de actividades,
     sin HTTP extra) en doc principal + detalles (esfuerzo y tss).
   - En documentos existentes: backfill barato de esfuerzo (sin HTTP).
   - Backfill histórico único (esfuerzoBackfillDone) con límites por pasada.
2) lib/intervalsDetail.js:
   - Misma extracción robusta (training_load primero, ignora 0/null).
   - No pisa un esfuerzo manual ya guardado; refleja esfuerzo al doc principal.
"""
import os

BASE = os.path.dirname(os.path.abspath(__file__))

def read(p):
    data = open(p, 'rb').read()
    crlf = b'\r\n' in data
    text = data.decode('utf-8')
    if crlf:
        text = text.replace('\r\n', '\n')
    return text, crlf

def write(p, text, crlf):
    if crlf:
        text = text.replace('\n', '\r\n')
    open(p, 'wb').write(text.encode('utf-8'))

def apply(text, old, new, tag):
    n = text.count(old)
    assert n == 1, f'[{tag}] esperado 1 coincidencia, encontradas {n}'
    return text.replace(old, new)

# ══════════════════════════════════════════════════════════════
# api/sync-intervals.js
# ══════════════════════════════════════════════════════════════
P1 = os.path.join(BASE, 'vercel-server', 'mi-app-entrenos-main', 'api', 'sync-intervals.js')
t, crlf = read(P1)

# 1) Helper pickTrainingLoad tras parseStartDate
t = apply(t, """function parseStartDate(activity) {
  const candidates = [
    activity.start_time,
    activity.start_time_local,
    activity.start_date,
    activity.startDate,
    activity.date,
  ];
  for (const c of candidates) {
    if (!c) continue;
    const d = new Date(c);
    if (!isNaN(d.getTime())) return d;
  }
  return null;
}
""", """function parseStartDate(activity) {
  const candidates = [
    activity.start_time,
    activity.start_time_local,
    activity.start_date,
    activity.startDate,
    activity.date,
  ];
  for (const c of candidates) {
    if (!c) continue;
    const d = new Date(c);
    if (!isNaN(d.getTime())) return d;
  }
  return null;
}

// ── Esfuerzo (TSS) desde la respuesta de Intervals.icu ──
// `training_load` es la estimación propia de intervals.icu (equivalente TSS,
// mismos valores que TrainingPeaks: 83, 55, 101…). Se toma el PRIMER valor
// numérico >0: no se usa una cadena de `??` porque un 0 en un campo anterior
// la cortaría (0 no es nullish) y el esfuerzo quedaba siempre a 0.
const LOAD_KEYS = ['training_load', 'icu_training_load', 'strain_score', 'suffer_score', 'load'];

function pickTrainingLoad(activity) {
  for (const k of LOAD_KEYS) {
    const v = Number(activity?.[k]);
    if (Number.isFinite(v) && v > 0) return Math.round(v);
  }
  return null;
}
""", 'pickTrainingLoad')

# 2) Contador backfilled
t = apply(t, """    let synced = 0;
    let skipped = 0;
    let detailOps = 0;
    const errorsList = [];
""", """    let synced = 0;
    let skipped = 0;
    let detailOps = 0;
    let backfilled = 0;
    const errorsList = [];
""", 'contador backfilled')

# 3) Rama de documento existente: backfill barato de esfuerzo
t = apply(t, """        if (existing.exists) {
          skipped++;
          if (detailOps < MAX_DETAIL_OPS) {
""", """        if (existing.exists) {
          skipped++;

          // ── Backfill de esfuerzo SIN llamadas HTTP extra ──
          // La lista de actividades ya trae training_load: si el documento no
          // tiene un valor válido, se guarda en detalles y en el doc principal
          // (la analítica de la app lo lee desde ahí). No pisa valores manuales.
          const loadLista = pickTrainingLoad(activity);
          if (loadLista != null) {
            try {
              const detSnapBf = await docRef.collection('detalles').doc('data').get();
              const detBf = detSnapBf.exists ? detSnapBf.data() : null;
              const detEsf = Number(detBf?.esfuerzo) > 0 ? Math.round(Number(detBf.esfuerzo)) : null;
              const mainEsf = Number(existing.data()?.esfuerzo) > 0 ? Math.round(Number(existing.data().esfuerzo)) : null;
              if (detEsf == null || mainEsf == null) {
                if (detEsf == null) {
                  await docRef.collection('detalles').doc('data').set({ esfuerzo: loadLista, tss: loadLista }, { merge: true });
                }
                if (mainEsf == null) {
                  await docRef.update({ esfuerzo: detEsf ?? loadLista });
                }
                backfilled++;
              }
            } catch (e) {
              console.warn(`[sync-intervals] Backfill esfuerzo ${activityId}:`, e.message);
            }
          }

          if (detailOps < MAX_DETAIL_OPS) {
""", 'backfill skipped')

# 4) Creación de documento: esfuerzo desde la lista
t = apply(t, """        const avgSpeed = Number(
          activity.avg_speed ?? activity.average_speed ?? (duracion > 0 ? distanciaMetros / duracion : 0)
        );

        await docRef.set({
""", """        const avgSpeed = Number(
          activity.avg_speed ?? activity.average_speed ?? (duracion > 0 ? distanciaMetros / duracion : 0)
        );
        const esfuerzoLoad = pickTrainingLoad(activity);

        await docRef.set({
""", 'esfuerzoLoad const')

t = apply(t, """          'fc-media': fcMedia,
          estado: 'completo',
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });
""", """          'fc-media': fcMedia,
          estado: 'completo',
          esfuerzo: esfuerzoLoad ?? 0,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });
""", 'main doc esfuerzo')

t = apply(t, """          temperatura: Number(activity.avg_temp ?? activity.temperature ?? 0),
          potenciaMedia,
          tss: 0,
""", """          temperatura: Number(activity.avg_temp ?? activity.temperature ?? 0),
          potenciaMedia,
          esfuerzo: esfuerzoLoad ?? 0,
          tss: esfuerzoLoad ?? 0,
""", 'detalles esfuerzo+tss')

# 5) Backfill histórico único tras la reconciliación
t = apply(t, """    // ── 3) Recalcular serie Fitness/Fatigue/Form ──
""", """    // ── 2c) Backfill histórico de esfuerzo (una sola vez por conexión) ──
    // Recorre TODO el historial con una única llamada HTTP y rellena el
    // esfuerzo (training_load) en los documentos que no lo tengan. Límites por
    // pasada (400 inspecciones / 80 escrituras, en paralelo de 20 en 20) para
    // no agotar el tiempo de la función; el resto se completa en syncs
    // sucesivos hasta marcar esfuerzoBackfillDone.
    let backfillHistorico = 0;
    if (!connection.esfuerzoBackfillDone) {
      try {
        const bfActs = await fetchActivities(connection, '2015-01-01', toISODate(now));
        if (Array.isArray(bfActs)) {
          const candidatos = bfActs.filter((a) => a && a.id && pickTrainingLoad(a) != null);
          const objetivo = candidatos.slice(0, 400);
          const listaCompleta = candidatos.length <= 400;
          let escritos = 0;
          for (let i = 0; i < objetivo.length && escritos < 80; i += 20) {
            const chunk = objetivo.slice(i, i + 20);
            const results = await Promise.all(chunk.map(async (act) => {
              const load = pickTrainingLoad(act);
              const ref = db.collection('entrenamientos').doc(`intervals_${act.id}`);
              try {
                const snap = await ref.get();
                if (!snap.exists) return false;
                const detRef = ref.collection('detalles').doc('data');
                const detSnap = await detRef.get();
                const det = detSnap.exists ? detSnap.data() : null;
                const detEsf = Number(det?.esfuerzo) > 0 ? Math.round(Number(det.esfuerzo)) : null;
                const mainEsf = Number(snap.data()?.esfuerzo) > 0 ? Math.round(Number(snap.data().esfuerzo)) : null;
                if (detEsf != null && mainEsf != null) return false;
                if (detEsf == null) {
                  await detRef.set({ esfuerzo: load, tss: load }, { merge: true });
                }
                if (mainEsf == null) {
                  await ref.update({ esfuerzo: detEsf ?? load });
                }
                return true;
              } catch (e) {
                return false;
              }
            }));
            escritos += results.filter(Boolean).length;
          }
          backfillHistorico = escritos;
          const done = listaCompleta && escritos < 80;
          if (done) {
            await db.collection('intervals_connections').doc(uid).update({
              esfuerzoBackfillDone: true,
              esfuerzoBackfillAt: admin.firestore.FieldValue.serverTimestamp(),
            });
          }
          console.log(`[sync-intervals] Backfill histórico esfuerzo: ${escritos} docs (completo=${done})`);
        }
      } catch (e) {
        console.warn('[sync-intervals] Backfill histórico error:', e.message);
      }
    }

    // ── 3) Recalcular serie Fitness/Fatigue/Form ──
""", 'backfill histórico')

# 6) Respuesta JSON
t = apply(t, """    return res.json({
      synced,
      skipped,
      subidos: uploaded,
""", """    return res.json({
      synced,
      skipped,
      esfuerzoBackfill: backfilled + backfillHistorico,
      subidos: uploaded,
""", 'respuesta json')

write(P1, t, crlf)
print('OK', P1)

# ══════════════════════════════════════════════════════════════
# lib/intervalsDetail.js
# ══════════════════════════════════════════════════════════════
P2 = os.path.join(BASE, 'vercel-server', 'mi-app-entrenos-main', 'lib', 'intervalsDetail.js')
t, crlf = read(P2)

t = apply(t, """    // ── ESFUERZO: prioridad a strain_score (TRIMP), luego suffer_score, luego load ──
    const esfuerzoVal = rf(a.strain_score ?? a.suffer_score ?? a.load ?? a.training_load);
    if (esfuerzoVal != null) extra.esfuerzo = Math.round(esfuerzoVal);
""", """    // ── ESFUERZO (TSS): prioridad a training_load de intervals.icu ──
    // Es su estimación propia de carga (equivalente TSS: 83, 55, 101…).
    // Antes se usaba `strain_score ?? suffer_score ?? load ?? training_load`:
    // si uno de esos campos venía a 0, la cadena se cortaba (0 no es nullish)
    // y el esfuerzo quedaba siempre en 0. Ahora se toma el primer valor >0
    // y nunca se pisa un esfuerzo ya guardado (p. ej. editado a mano).
    let esfuerzoVal = null;
    for (const k of ['training_load', 'icu_training_load', 'strain_score', 'suffer_score', 'load']) {
      const v = rf(a[k]);
      if (v != null && v > 0) { esfuerzoVal = v; break; }
    }
    if (esfuerzoVal != null && !(Number(existing?.esfuerzo) > 0)) {
      extra.esfuerzo = Math.round(esfuerzoVal);
      extra.tss = extra.esfuerzo;
    }
""", 'extracción esfuerzo')

t = apply(t, """  await detRef.set(update, { merge: true });
  await docRef.collection('registros').doc('data').set({ puntos }, { merge: true });
""", """  await detRef.set(update, { merge: true });
  await docRef.collection('registros').doc('data').set({ puntos }, { merge: true });

  // Refleja el esfuerzo en el documento principal (la analítica de la app
  // lo lee desde ahí). Solo si el principal aún no tiene un valor válido.
  const esfuerzoFinal = extra.esfuerzo != null
    ? extra.esfuerzo
    : (Number(existing?.esfuerzo) > 0 ? Math.round(Number(existing.esfuerzo)) : null);
  if (esfuerzoFinal != null) {
    try {
      const mSnap = await docRef.get();
      const mEsf = mSnap.exists ? Number(mSnap.data()?.esfuerzo) : 0;
      if (!(mEsf > 0)) {
        await docRef.set({ esfuerzo: esfuerzoFinal }, { merge: true });
      }
    } catch (e) {
      console.warn('[intervalsDetail] No se pudo reflejar esfuerzo en doc principal:', e.message);
    }
  }
""", 'mirror main doc')

write(P2, t, crlf)
print('OK', P2)
print('TODO OK')
