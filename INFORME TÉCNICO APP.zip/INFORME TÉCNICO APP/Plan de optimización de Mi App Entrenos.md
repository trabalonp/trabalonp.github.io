# Plan de optimización de Mi App Entrenos

## Prioridad 0: seguridad y medición

No cambiar el esquema todavía. Incorporar el backend real y `firestore.indexes.json` a la auditoría. Crear medición de lecturas devueltas, bytes serializados, puntos procesados, hit/miss de caché, tiempo de consulta, procesamiento y render. Ejecutar la medición en un entorno controlado con 10, 50, 100 y 300 actividades.

Validación: los resultados deben separar red/Firestore, procesamiento JS y render. No usar porcentajes de la consola como consumo por usuario.

## Fase 1: correcciones de bajo riesgo

- Reutilizar los resultados de `fetchWorkouts` entre gráficas.
- Evitar recalcular períodos no afectados por una sincronización.
- Invalidar streams por usuario, actividad, fecha y tipo, no todos los períodos.
- Mantener una sola carga de `wellness` por ciclo.
- Revisar la consulta de duplicados de FIT y agrupar nombres cuando sea seguro.
- Eliminar la condición de caché duplicada en `analyticsEngine.js`.

Pruebas: snapshots de referencia, conteo de lecturas y comparación de resultados numéricos.

## Fase 2: curvas visuales resumidas

Crear una función pura de bucketing que conserve extremos, máximos/mínimos y metadatos de cada ventana. Aplicarla durante la importación o en la primera lectura, no en cada render. Mantener `registros/data` original como fuente de precisión.

Pruebas: error máximo de ritmo/FC frente al cálculo actual; número de puntos; tiempo p95.

## Fase 3: agregados persistentes

Añadir, si la medición lo justifica, documentos ligeros de días y curvas por período/actividad. Versionar el esquema y guardar `updatedAt`, `sourceVersion` y watermark. Recalcular solamente fechas/actividades afectadas.

Migración: escritura dual temporal, comparación de resultados, fallback a cálculo antiguo y solo después retirar duplicados.

## Fase 4: documentos grandes

Medir el tamaño real de `registros/data`. Si se acerca al límite de 1 MiB, elegir entre buckets de puntos o R2. No dividir automáticamente: comparar lecturas necesarias para abrir un detalle completo y para una gráfica parcial.

## Fase 5: seguridad

Reescribir reglas con propietario y vínculo entrenador-atleta. Probar con Emulator Suite: propietario, entrenador vinculado, entrenador no vinculado y usuario no autenticado. Revisar también posts, librería, entrenamientos y subcolecciones.

## Criterios de aceptación globales

- Las gráficas históricas devuelven resultados equivalentes dentro de una tolerancia documentada.
- El detalle de un entrenamiento conserva precisión y puntos originales.
- El recálculo de un período no lee registros de actividades no afectadas.
- Se reduce el p95 de carga y el número de documentos leídos en una prueba reproducible.
- No se modifican ni eliminan datos antiguos hasta completar una migración reversible.
