# Auditoría técnica integral de Mi App Entrenos

**Fecha:** 21 de octubre de 2026  
**Alcance:** auditoría estática y de solo lectura del repositorio móvil Expo/React Native disponible en `/mnt/043ecd8e-d36e-451b-a89f-85af1c9454dd/mi-app-entrenos`.  
**Objetivo:** documentar la arquitectura real y explicar qué puede estar causando latencia y consumo elevado de Firestore en gráficas y estadísticas históricas, sin modificar la aplicación.

## 1. Resumen ejecutivo

La aplicación combina tres patrones de almacenamiento para un entrenamiento: un documento resumen en `entrenamientos/{id}`, un subdocumento `detalles/data` y un subdocumento `registros/data` con el array `puntos`. Esta separación evita que el historial ligero arrastre siempre los registros pesados, pero no se aplica de forma uniforme en todas las pantallas: `HomeScreen` y `CalendarScreen` cargan detalles por lotes para entrenamientos realizados, mientras que las curvas históricas de `analyticsEngine.getStreamsStats` consultan primero la totalidad de los entrenamientos del período y después hacen un `getDoc` de `registros/data` para cada actividad.

El cuello de botella más claro y comprobado está en las curvas históricas. Para cada período, el motor pagina `entrenamientos` en bloques de 100, conserva todas las actividades completas y, en grupos de cuatro, consulta una subcolección `registros/data` por entrenamiento. Una consulta de dos años puede generar aproximadamente una lectura por documento resumen más una lectura por subdocumento de registros, además del procesamiento de la totalidad de los puntos en el dispositivo. No se observa en la app móvil una agregación persistente de curvas históricas; el resultado se guarda en `AsyncStorage` y memoria después de calcularlo. El backend remoto disponible en GitHub tampoco contiene un endpoint dedicado a materializar estas curvas.

El historial analítico diario está mejor resuelto: `fetchWorkouts` pagina a 300, `syncAnalyticsDays` usa una ventana incremental desde la última sincronización con solape de tres días y fusiona el documento `wellness` una vez. Sin embargo, hay rutas que pueden repetir consultas completas: la primera construcción del snapshot, la invalidación de cachés, el cambio de período y las curvas de streams no comparten aún un almacén de agregados común.

Hay dos riesgos P0/P1 ajenos al rendimiento que deben tratarse antes de una migración: las reglas de Firestore permiten a cualquier usuario autenticado leer y escribir cualquier documento de `entrenamientos`, `detalles`, `registros`, `libreria`, `posts` y varias colecciones; y el backend remoto no incluye `firestore.indexes.json`; por ello, aunque los endpoints sí se han auditado desde GitHub, la correspondencia completa de índices y las reglas realmente desplegadas siguen requiriendo acceso a las consolas de Firebase/Vercel.

La recomendación de menor riesgo es conservar el esquema actual y hacer primero medición, caché de resultados por usuario/período/actividad, reducción del trabajo de curvas y consultas de campos ligeros. Solo después de medir conviene introducir agregados persistentes. La opción equilibrada es crear resúmenes diarios y curvas reducidas incrementales sin borrar los datos originales de `registros/data`.

## 2. Estado general de la arquitectura

### Tecnologías comprobadas

- Expo `^57.0.0` y React `19.2.3`.
- React Native `^0.86.3`.
- Firebase Web SDK `^9.14.0` con Firestore y Authentication.
- `@garmin/fitsdk`, `fit-decoder` y `fit-file-parser`.
- `@shopify/react-native-skia`, `victory-native`, `react-native-chart-kit` y `react-native-graph`.
- `AsyncStorage` para cachés locales.
- Expo FileSystem, Image, Notifications, Audio y Sharing.
- Cloudflare R2/Vercel aparecen en servicios y llamadas; el backend desplegable está en el repositorio remoto de GitHub y se analiza en la sección 10.

El punto de entrada declarado es `node_modules/expo/AppEntry.js`; también existe `app/index.tsx`. Las pantallas de entrenamiento, calendario, análisis, marcas, social, sincronización y ajustes están separadas en `screens/`. La lógica de datos está repartida entre `services/SyncService.js`, `services/analyticsEngine.js`, `services/chartCache.js`, `services/GarminSyncService.js`, `services/chatSync.js` y los componentes de gráficas.

## 3. Inventario del repositorio y límites de la auditoría

El checkout local contiene `screens`, `components`, `services`, `tests`, `app`, `assets`, reglas de Firestore y configuración Expo. No contiene la parte server-side, pero la rama `main` del repositorio privado de GitHub sí incluye `api/[...path].js`, `handlers/`, `lib/` y `vercel.json`. No se encontró `firestore.indexes.json` ni en el checkout móvil ni en la rama remota auditada.

La diferencia entre ambos entornos es importante: el checkout local corresponde principalmente a la app Expo, mientras que GitHub contiene el backend desplegable. Las conclusiones backend que siguen están verificadas contra la rama `main` de GitHub; las métricas de producción y las reglas activas en Firebase/Vercel siguen requiriendo observabilidad de las plataformas.

## 4. Mapa del flujo de datos actual

El diagrama completo se entrega también en `arquitectura_actual.mmd`.

```mermaid
flowchart TD
  A[Garmin / archivo FIT / edición manual] --> B[SyncService.parseFitFile]
  B --> C[Resumen: entrenamientos/{id}]
  B --> D[detalles/data]
  B --> E[registros/data: puntos]
  C --> F[HomeScreen / CalendarScreen]
  D --> F
  E --> G[WorkoutDetailModal]
  E --> H[analyticsEngine.getStreamsStats]
  C --> H
  H --> I[procesamiento de zonas y curvas]
  I --> J[AsyncStorage + memoria]
  J --> K[AnalysisScreen / gráficas]
  C --> L[analyticsEngine.fetchWorkouts]
  L --> M[snapshot diario de métricas]
  M --> N[AsyncStorage + analysis/{uid}]
  O[wellness/{uid}] --> M
  P[posts / perfiles / notificaciones] --> Q[SocialScreen / NotificacionesScreen]
```

### Flujo comprobado de importación FIT

`services/SyncService.js:12-108` busca archivos FIT en una carpeta SAF, carga una vez `perfiles/{userId}` y `wellness/{userId}`, comprueba duplicados por `userId + id_archivo`, parsea el archivo y realiza tres escrituras: documento principal, `detalles/data` y, si hay puntos, `registros/data`. El documento principal conserva métricas de resumen; los detalles incluyen vueltas, pasos, comentarios y campos editables; los registros guardan `puntos`.

La comprobación de duplicados (`SyncService.js:133-141`) es una consulta `where(userId == ...)` y `where(id_archivo == ...)` por archivo FIT. Si se importan muchos archivos, esa consulta se ejecuta dentro del bucle de sincronización y puede convertirse en una lectura repetida por archivo.

## 5. Inventario de Firestore observado

### `entrenamientos`

Es la colección central. El resumen escrito por `SyncService.js:53-71` contiene `userId`, `id_archivo`, `fecha`, `tipo`, `titulo`, `distancia`, `duracion`, `fc-media`, `estado`, elevación, potencia, cadencia y esfuerzo. Otras pantallas también leen o actualizan `pasos`, `asignados`, `completado`, `vueltas`, `mergedFromPlanId`, `intervalsId` y campos de planificación.

La aplicación utiliza consultas por usuario y fecha en Home, Calendar y Analytics. También consulta entrenamientos asignados a un usuario mediante `array-contains` en `HomeScreen.js:420` según el inventario del código.

### `entrenamientos/{id}/detalles/data`

`SyncService.js:73-95` guarda calorías, FC máxima, ritmo, elevación, cadencia, temperatura, esfuerzo, TSS, notas, carga percibida, sensación, descripción, pasos, comentarios, vueltas y `hasRuta`. `WorkoutDetailModal` vuelve a consultar este subdocumento al abrir o guardar el entrenamiento (`WorkoutDetailModal.js:623-684`, según las referencias encontradas).

### `entrenamientos/{id}/registros/data`

`SyncService.js:97-101` guarda `{ puntos: parsed.registros }`. Es la fuente de las gráficas detalladas, mapa, curvas de duración, curvas por distancia y estadísticas de zonas. Un documento con aproximadamente 3.700 elementos está dentro de un único documento, no en una colección de muestras separadas. Esto reduce lecturas para abrir el detalle completo, pero hace que cada lectura transfiera el array entero y acerca el diseño al límite de tamaño de documento de Firestore: 1 MiB por documento [1]. El tamaño real no se puede confirmar sin exportar o medir documentos de producción.

### `perfiles`

Contiene el perfil del usuario y zonas/umbrales. Se lee durante sincronización y desde pantallas. Las reglas permiten lectura a cualquier usuario autenticado, aunque el contenido del perfil puede incluir más datos de los estrictamente necesarios.

### `wellness`

`analyticsEngine.mergeWellness` lee `wellness/{uid}` y recorre `days`, incorporando sueño, pasos, FC en reposo, HRV, peso y otros indicadores. Es un documento mapa por usuario. Puede crecer con el tiempo y su lectura es de un documento, pero la respuesta completa se transfiere cada vez que se carga o fusiona.

### `analysis`

`AnalysisScreen.js:330-341` persiste la configuración de gráficas del usuario en `analysis/{uid}` y también la guarda en `AsyncStorage`. No se observa en el código inspeccionado una materialización server-side de las series históricas; este documento parece almacenar configuración (`charts`), no los datos derivados.

### `posts`

`chatSync.js` obtiene mensajes del tablón con consultas ordenadas y limitadas. El historial se pagina y existe caché local. Las reacciones se actualizan por campos dinámicos y el catálogo de emojis se mantiene local, lo cual evita guardar miles de claves vacías.

### `avatares`, `archivosLib`, `libreria`, `retos`, `solicitudes`, `fitness`

Se observan usos de estas colecciones en servicios y pantallas. El inventario detallado estructurado se entrega en `inventario_datos.json`. La finalidad exacta de algunos documentos depende de datos de producción no incluidos en el repositorio.

## 6. Análisis profundo de arrays y registros

Los registros son puntos temporales con al menos `timestamp` y, según el flujo de parseo y el uso en las gráficas, campos como `distancia`, `velocidad`, `frecuencia`, `cadencia`, `potencia`, `altitud`, `lat` y `lon`. `WorkoutDetailModal` ordena los puntos por timestamp si detecta desorden y calcula distribuciones recorriendo el array completo.

El detalle usa una estrategia razonable: los puntos se cargan bajo demanda (`WorkoutDetailModal.js:330-363`), no necesariamente al mostrar el historial. Después, `ActivityChart` decima índices a `MAX_PTS` antes de construir la geometría (`ActivityChart.js:286-301`). Para la pestaña Detalles se remuestrea por segundo, mientras que las curvas de análisis usan el stream original o una reducción visual posterior.

El problema es diferente en las curvas históricas: la reducción de puntos para pintar ocurre después de haber leído cada `registros/data` y recorrido sus puntos. La reducción visual evita saturar Skia, pero no reduce las lecturas ni el ancho descargado.

## 7. Inventario de operaciones y consultas

El inventario completo se entrega en `inventario_consultas.json`. Los flujos principales son:

1. **Sincronización FIT:** dos lecturas iniciales (`perfiles`, `wellness`), una consulta de duplicado por archivo, hasta tres escrituras por entrenamiento y una lectura potencial de almacenamiento local.
2. **Historial Home:** consulta por `userId` y rango de fechas ordenada por `fecha`; cuando hay entrenamientos completos, carga detalles por lotes con `getDoc`.
3. **Analytics diario:** `fetchWorkouts` usa `limit(300)` y `startAfter`; puede paginar el conjunto completo el historial del período. `syncAnalyticsDays` reduce el trabajo después de la primera marca usando una ventana desde `lastSyncAt - 3 días`.
4. **Streams históricos:** `getStreamsStats` consulta actividades en páginas de 100 (`analyticsEngine.js:800-823`) y después hace una lectura de `registros/data` por actividad en grupos de cuatro (`analyticsEngine.js:825-837`).
5. **Detalle de entrenamiento:** una lectura del documento principal, una de `detalles/data` y otra de `registros/data` según pestaña y estado de carga; existen rutas de refresco que pueden volver a obtener el documento.
6. **Social:** `chatSync` usa páginas limitadas y caché local; los listeners de posts pueden cobrar lecturas adicionales cuando documentos entran, cambian o salen del resultado [2].

Una función llamada muchas veces no equivale automáticamente al mismo número de lecturas: una caché puede evitar la red, mientras que un `onSnapshot` puede cobrar lecturas por cambios del conjunto resultante. La medición debe instrumentarse con contadores y Performance Monitoring o Query Explain en un entorno controlado.

## 8. Auditoría de gráficas y estadísticas

### Resúmenes diarios y semanales

`analyticsEngine` transforma entrenamientos y wellness en un mapa `days`. `mergeWorkout` agrega distancia, duración, carga, calorías y planificación. La carga incremental y el snapshot de `AsyncStorage` explican por qué los resúmenes semanales pueden sentirse rápidos después de una primera carga.

### Análisis configurable

`AnalysisScreen` mantiene configuraciones de gráficos y obtiene `days` y `streams` según las tarjetas activas. Esto evita dibujar gráficos no configurados, pero el motor de streams trabaja por período y actividad y puede recalcular al cambiar cualquiera de esos parámetros.

### Curvas de FC, ritmo y streams

`getStreamsStats` inicializa curvas de tamaño fijo (`STREAM_SIZES`) y calcula zonas, curvas de ritmo, velocidad, FC, potencia y cadencia. La consulta de cada actividad incluye solo el resumen en la primera fase, pero luego recupera `registros/data`. El procesamiento se hace en el dispositivo y puede ser costoso para dos años, especialmente si cada actividad tiene miles de puntos.

Hay una duplicación visible en `getStreamsStats`: el bloque `if (!force && c) return c.val` aparece dos veces (`analyticsEngine.js:723-728`). No cambia el resultado, pero indica deuda de mantenimiento.

La caché persistente por `uid + periodo + zonaAct` (`analyticsEngine.js:730-741`) es positiva, pero se invalida de forma amplia en `invalidateStreamsCache`, eliminando seis períodos y cuatro actividades (`analyticsEngine.js:701-713`). Una nueva sincronización puede forzar recalculado de la totalidad de los períodos, aunque solo haya cambiado una actividad.

## 9. Análisis de rendimiento y cuellos de botella

### P1 — Curvas históricas con N+1 lecturas

Evidencia: consulta paginada de `entrenamientos` seguida de un `getDoc` de `registros/data` por actividad. Impacto: alto en lecturas, transferencia y CPU; confianza alta. Solución: curvas resumidas persistentes o un único documento agregado por período, manteniendo originales para detalle.

### P1 — Procesamiento de la totalidad de los puntos antes de reducir visualmente

Evidencia: `getStreamsStats` recorre cada `pts` y calcula ventanas antes de guardar; `ActivityChart` decima solo para render. Impacto: alto en CPU y memoria; confianza alta. Solución: conservar una serie visual preagregada por actividad y periodo, o procesar por buckets durante la importación.

### P1 — Caché de streams invalidada globalmente

Evidencia: `invalidateStreamsCache` borra la totalidad de los períodos y actividades. Impacto: alto en cargas posteriores a una sincronización; confianza alta. Solución: invalidación por fecha/tipo de actividad y versionado incremental.

### P0 — Reglas de Firestore demasiado permisivas

Evidencia: `firestore.rules:22-30` permite `read, write` a cualquier autenticado para entrenamientos y subcolecciones; hay patrones similares en `libreria` y `posts:84-88`. Impacto: seguridad e integridad de datos; confianza alta. Solución: reglas por `request.auth.uid`, vínculo entrenador-atleta y validación de campos. No se debe cambiar sin pruebas de emulador y revisión del backend.

### P1 — Documento `registros/data` potencialmente cercano a 1 MiB

Evidencia: arrays de miles de puntos y límite Firestore de 1 MiB [1]. Impacto: fallos de escritura, transferencia y latencia; confianza media porque falta tamaño real. Solución: medir bytes serializados en muestras reales; si procede, usar archivos R2 o buckets de subdocumentos, sin asumir que dividir siempre reduce lecturas.

### P2 — Consultas de duplicados dentro del bucle de importación

Evidencia: `checkDuplicate` se ejecuta por cada archivo. Impacto: lecturas repetidas y latencia de sincronización; confianza alta. Solución: consultar identificadores existentes en lotes o mantener un índice local de nombres importados, preservando una comprobación final.

### P2 — Lecturas completas de wellness

Evidencia: `mergeWellness` lee un documento con mapa `days` completo. Impacto: transferencia y crecimiento de documento; confianza alta. Solución: separar por mes/año o materializar días recientes, solo si el tamaño real lo justifica.

## 10. Auditoría del backend de Vercel y GitHub

El backend sí está en el repositorio remoto privado de GitHub, rama `main`. La estructura real es `api/[...path].js`, `handlers/`, `lib/`, `vercel.json` y un `package.json` separado con `firebase-admin`, `@aws-sdk/client-s3` y `@aws-sdk/s3-request-presigner`.

### Dispatcher y despliegue

`api/[...path].js:1-19` documenta que el proyecto utiliza una única Serverless Function para evitar el límite de 12 funciones del plan Hobby. `vercel.json:2-7` reescribe `/api/:path*` hacia `/api/[...path]?path=:path*`, necesario para que funcionen rutas con varios segmentos como `/api/social/presign`. El dispatcher carga los handlers de forma perezosa y limita el cuerpo de petición a 26 MiB, con margen sobre el límite de 25 MB indicado para presign.

El mapa contiene 19 rutas, entre ellas `notify-athlete`, `sync-fitness`, `sync-intervals`, `sync-intervals-detail`, `upload-to-intervals`, `intervals/*`, `social/delete-message`, `social/link-preview`, `social/notify-message`, `social/presign`, `social/purge` y `archivos/*`. La configuración está bien alineada con el objetivo de evitar la limitación de funciones del plan Hobby.

### Autenticación server-side

`lib/auth.js:3-14` extrae `Authorization: Bearer <Firebase ID token>` y llama a `admin.auth().verifyIdToken`. Los handlers de sincronización, R2, notificaciones y detalles de Intervals usan esta función antes de operar. Esto es una protección adicional correcta, pero no sustituye las reglas Firestore: cualquier endpoint server-side que use Firebase Admin puede escribir sin que las reglas del cliente lo limiten.

### Push e historial de notificaciones

`lib/push.js:4-35` guarda el historial en `perfiles/{uid}/notificaciones`, aplica `dedupeKey` para evitar duplicados y respeta `notificacionesActivadas`. `sendPushToUser` lee el perfil, guarda el aviso y envía a Expo Push API. También lee la respuesta de Expo y elimina tokens `DeviceNotRegistered` o `InvalidCredentials`.

`handlers/social/notify-message.js:32-60` autentica al remitente, lee la totalidad de los perfiles y envía el mensaje a la totalidad de menos al remitente en paralelo. Esto explica por qué el chat puede notificar con la app cerrada, siempre que el perfil destinatario tenga un `expoPushToken` válido y las notificaciones estén habilitadas. También identifica un coste potencial: cada mensaje social provoca una lectura completa de `perfiles` y después una lectura adicional del perfil de cada destinatario dentro de `sendPushToUser`. Para E destinatarios, el flujo puede producir aproximadamente E+1 lecturas de perfiles, más la consulta `dedupeKey` por destinatario si está presente.

### R2

`handlers/social/presign.js:34-66` autentica, valida nombre/tamaño, genera una URL firmada PUT contra R2 y construye `publicUrl` eliminando barras finales de `R2_PUBLIC_URL`. Las credenciales nunca salen al móvil. El límite es 25 MB y las variables requeridas son `R2_ACCOUNT_ID`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`, `R2_BUCKET` y `R2_PUBLIC_URL`. La corrección del espacio sobrante en la URL pública es coherente con este código: si la variable contiene un espacio interno, la URL persistida queda inválida aunque R2 reciba el objeto.

### Sincronización remota y registros

`handlers/sync-intervals-detail.js:15-39` autentica, comprueba que `entrenamientos/intervals_{intervalsId}` pertenece al usuario y llama a `fetchAndStoreDetail`. Esta verificación de propietario está mejor restringida que las reglas Firestore observadas en el cliente. `handlers/sync-fitness.js` calcula fitness mediante el token de Intervals y escribe usando Firebase Admin.

### Marcas personales

`lib/records.js:31-112` implementa la creación automática de una distancia clásica, seleccionando solo la distancia estándar más larga cubierta por el entrenamiento. Después calcula el tiempo proporcional, compara con `marcasBest` y `marcasResults`, actualiza resultados y devuelve batidos. Esta lógica sí cubre el requisito de que un 10K aparezca aunque no estuviera configurado, pero la calidad del récord depende de la distancia y duración resumidas del entrenamiento: no es equivalente a un mejor esfuerzo GPS real dentro de un entrenamiento largo.

### Observaciones backend pendientes

- `handlers/social/notify-message.js` hace un `get()` completo de `perfiles` por cada mensaje. Debe medirse con el número real de usuarios; para equipos grandes conviene mantener una lista de destinatarios o un índice de tokens activos.
- `lib/push.js` hace una consulta `where(dedupeKey == ...)` antes de cada escritura cuando hay deduplicación. Sin un índice adecuado puede fallar o degradarse.
- El dispatcher devuelve 500 si un handler no existe en el bundle; los `require` literales están correctamente documentados para que Vercel NFT empaquete handlers y librerías.
- No se encontró `firestore.indexes.json` en la rama auditada; los índices de producción siguen sin estar versionados en GitHub.
- Vercel documenta que Hobby incluye 1 millón de invocaciones mensuales y 4 horas de CPU activa; Pro factura CPU, memoria e invocaciones [4]. Esto no permite estimar el coste real sin plan, región y métricas de uso.

## 11. Índices y reglas de seguridad

No se encontró `firestore.indexes.json`, por lo que no se puede confirmar si los índices compuestos observados en consola son reproducibles desde el repositorio. Las consultas que combinan `where(userId)`, rangos de `fecha`, `orderBy(fecha)` y paginación probablemente requieren índices según la consulta exacta y la configuración actual.

Firestore ofrece 50.000 lecturas, 20.000 escrituras y 20.000 borrados diarios en la cuota gratuita, además de 1 GiB almacenado y 10 GiB mensuales de salida para la base gratuita [1] [2]. La cuota se aplica por proyecto/base de datos elegible y se reinicia aproximadamente a medianoche del Pacífico. En Spark, superar la cuota de un producto puede detener ese producto el resto del mes; Blaze añade facturación por uso [3].

La seguridad es el riesgo más urgente. La función `esSuEntrenador` existe, pero no se usa para restringir `entrenamientos`; solo se aplica de forma parcial a actualizaciones de perfiles. Además, `allow read, write: if request.auth != null` permite que cualquier usuario autenticado modifique entrenamientos ajenos si conoce sus IDs.

## 12. Estimación de consumo y costes

No se dispone de métricas de producción ni del tamaño real de documentos, por lo que las cifras siguientes son escenarios, no mediciones.

### Escenario de una curva histórica

Para `N` actividades completas dentro del período, el flujo de streams requiere aproximadamente:

- `ceil(N/100)` lecturas de páginas de `entrenamientos`, cobradas por documento devuelto, no por página como unidad única.
- Hasta `N` lecturas de `registros/data` si todas las actividades tienen puntos.
- CPU local proporcional a la suma de puntos de esas N actividades.

En términos simplificados, el mínimo de documentos leídos está cerca de `2N` cuando cada actividad tiene resumen y registros, más posibles lecturas de wellness y configuración. Si un usuario tiene 200 actividades, la consulta puede implicar alrededor de 400 documentos leídos, sin contar reintentos, listeners o pantallas adicionales. Esta es una estimación estructural derivada del código, no una medición de consola.

### Escenarios hipotéticos

| Escenario | Actividades históricas procesadas | Lecturas estructurales aproximadas por cálculo de streams | Riesgo principal |
|---|---:|---:|---|
| Usuario nuevo | 20 | hasta 40 | aceptable, pero sensible al tamaño de puntos |
| Usuario activo | 100 | hasta 200 | latencia visible y transferencia alta |
| Usuario muy activo | 300 | hasta 600 | bloqueos de UI y cuota diaria |
| 50 usuarios activos | 5.000 en conjunto | hasta 10.000 por recálculo completo | la caché debe evitar recálculos repetidos |
| 1.000 usuarios activos | 100.000 en conjunto | hasta 200.000 por recálculo completo | inviable como patrón frecuente |

Las escrituras FIT son aproximadamente tres por entrenamiento nuevo más la consulta de duplicado, y pueden aumentar por actualizaciones del detalle. El coste exacto depende del número de usuarios, frecuencia real, tamaño de respuestas, ubicación de Firestore y plan de facturación. No es correcto multiplicar el porcentaje de uso observado en Firebase por usuarios sin conocer el intervalo temporal y la métrica.

## 13. Alternativas de almacenamiento

### Mantener registros en `registros/data`

Ventajas: una lectura abre la totalidad de los puntos de una actividad y mantiene el detalle simple. Inconvenientes: documento potencialmente grande, transferencia completa y riesgo de límite de 1 MiB.

### Subcolección por bloques temporales

Ventajas: se puede cargar solo una ventana y evitar documentos gigantes. Inconvenientes: más lecturas para reconstruir una actividad completa y mayor complejidad de ordenación/migración.

### Archivo FIT/JSON en R2 y resumen en Firestore

Ventajas: Firestore conserva documentos ligeros y R2 es adecuado para binarios/series grandes. Inconvenientes: una gráfica necesitaría descarga HTTP o un servicio de reducción; hay que gestionar URLs, caché, borrado y permisos.

### Agregados persistentes

Ventajas: las estadísticas históricas se leen en pocos documentos y su coste deja de depender de N. Inconvenientes: sincronización, invalidación, migraciones y riesgo de resultados desactualizados.

La recomendación para el tamaño actual es un enfoque híbrido: mantener el detalle original, crear agregados ligeros por día/mes y guardar curvas visuales resumidas por actividad/periodo. No mover la totalidad de los puntos automáticamente hasta medir tamaño, frecuencia de apertura y necesidad de edición.

## 14. Arquitectura objetivo propuesta

La arquitectura recomendada se entrega también en `arquitectura_propuesta.mmd`.

### Diseño mínimo recomendado

1. Mantener `entrenamientos/{id}` como resumen.
2. Mantener `detalles/data` para datos editables y `registros/data` para el detalle original.
3. Añadir `analyticsDaily/{uid}/days/{yyyy-mm-dd}` con distancia, duración, carga, pasos y sueño agregados.
4. Añadir `analyticsCurves/{uid}/periods/{period_activity}` con puntos reducidos y versión de cálculo.
5. Actualizar agregados solo para entrenamientos nuevos, modificados o eliminados.
6. Leer agregados en AnalysisScreen; leer `registros/data` solo en el detalle o cuando el usuario pide precisión.

### Diseño ambicioso

Un backend autenticado procesa FIT y genera agregados, curvas y métricas versionadas. Firestore guarda resúmenes; R2 conserva archivos originales y series largas; una tarea incremental recalcula solo fechas afectadas. Esta opción es mejor para muchos usuarios, pero no debe implantarse antes de medir y asegurar idempotencia.

## 15. Matriz priorizada de problemas

| ID | Prioridad | Problema | Evidencia | Confianza | Solución | Dificultad |
|---|---|---|---|---|---|---|
| SEC-01 | P0 | Lectura/escritura abierta de entrenamientos | `firestore.rules:22-30` | Alta | reglas por propietario/vínculo y emulador | Media |
| CUR-01 | P1 | N+1 en curvas históricas | `analyticsEngine.js:800-837` | Alta | agregados/curvas resumidas | Media-alta |
| CUR-02 | P1 | Se procesa el conjunto completo antes de decimar | `analyticsEngine.js:843+`, `ActivityChart.js:286+` | Alta | bucketing incremental/preagregado | Media |
| CACHE-01 | P1 | Invalidación global de streams | `analyticsEngine.js:701-713` | Alta | invalidación por fecha/actividad | Media |
| DOC-01 | P1 | `registros/data` puede acercarse a 1 MiB | `SyncService.js:97-101` | Media | medir y decidir R2/buckets | Media |
| SYNC-01 | P2 | Duplicado consultado por archivo | `SyncService.js:47-49`, `133-141` | Alta | lote/índice local | Baja-media |
| WELL-01 | P2 | Wellness completo por fusión | `analyticsEngine.js:425-460` | Alta | particionar si el tamaño lo justifica | Media |
| IDX-01 | P2 | Índices no versionados en repo | ausencia de `firestore.indexes.json` | Alta | exportar y versionar índices | Baja |
| BE-01 | P2 | Backend Vercel no auditable desde checkout | ausencia de `api/`, `handlers/`, `lib/` | Alta | incorporar repo/backend a auditoría | Baja |
| MAINT-01 | P3 | Condición de caché duplicada | `analyticsEngine.js:723-728` | Alta | limpieza de deuda | Baja |

## 16. Plan de optimización por fases

### Fase 1 — Medición sin cambios de esquema

Instrumentar tiempos de consulta, número de documentos devueltos, puntos procesados, tamaño serializado, cache hit/miss y tiempo de render. Usar Firebase Usage/Cloud Monitoring y una matriz de pruebas con 10, 50, 100 y 300 actividades. Criterio: separar tiempo Firestore, procesamiento JS y render.

### Fase 2 — Mejoras de bajo riesgo

Reutilizar el snapshot de resumen, evitar consultas duplicadas al cambiar pestañas, mantener la caché por período y no invalidar períodos no afectados. Limitar detalles a la pestaña activa. Criterio: reducir lecturas y tiempo p95 sin cambiar resultados.

### Fase 3 — Curvas resumidas

Crear una función pura que produzca buckets visuales por actividad y por período, conservando máximos/mínimos y metadatos. Validar contra el cálculo actual con tolerancia explícita. Criterio: mismo resultado dentro de tolerancia y reducción de puntos procesados.

### Fase 4 — Agregados persistentes

Materializar días y curvas en documentos separados, con `schemaVersion`, `sourceWorkoutIds` o watermark y marca de actualización. Recalcular solo el rango afectado. Mantener el cálculo antiguo como fallback durante la migración.

### Fase 5 — Seguridad y escalabilidad

Corregir reglas con Firebase Emulator Suite, versionar índices y auditar backend. Probar propietario, entrenador vinculado, usuario no vinculado y datos inexistentes. No borrar campos antiguos hasta comparar resultados durante una ventana de observación.

## 17. Datos que faltan para confirmar conclusiones

- Tamaño serializado real de documentos `registros/data`.
- Número de entrenamientos por usuario y distribución de puntos.
- Métricas de Firebase por pantalla y período.
- `firestore.indexes.json` y proyecto backend de Vercel.
- Plan Firebase activo y región de Firestore.
- Si Firestore offline persistence está activa en la inicialización.
- Tiempos p50/p95 de consulta, procesamiento y render.
- Ejemplos reales de actividades con datos nulos, pausas y duplicados.
- Resultado de Query Explain para las consultas de Analytics.

## 18. Conclusiones principales

El problema de las estadísticas largas no parece ser un único fallo de Skia o de Firestore. Es la combinación de una estrategia de lectura N+1, arrays de puntos grandes, procesamiento local de la totalidad de los registros y una invalidación de caché amplia. Los resúmenes semanales funcionan mejor porque reutilizan un snapshot diario y consultan agregados de resumen, mientras que las curvas requieren volver a abrir los registros de cada actividad.

La intervención con mejor relación riesgo/beneficio es medir primero, reutilizar los resúmenes ligeros, limitar el procesamiento a la pestaña activa y materializar curvas reducidas de forma incremental. No conviene mover la totalidad de los registros a subcolecciones ni crear un backend analítico completo sin tamaños reales, métricas de uso y pruebas de equivalencia.

La prioridad inmediata no relacionada con rendimiento es la seguridad de Firestore. Las reglas actuales no restringen adecuadamente entrenamientos ni posts a propietarios o vínculos autorizados. Debe corregirse mediante pruebas controladas antes de abrir la aplicación a más usuarios.

## Referencias

[1]: https://firebase.google.com/docs/firestore/quotas "Cloud Firestore quotas and limits"
[2]: https://firebase.google.com/docs/firestore/pricing "Understand Cloud Firestore billing"
[3]: https://firebase.google.com/docs/projects/billing/firebase-pricing-plans "Firebase pricing plans"
[4]: https://vercel.com/docs/functions/usage-and-pricing "Vercel Fluid Compute pricing"
