// firebaseConfig.js
import { initializeApp, getApps }          from 'firebase/app';
import { initializeAuth,
         getReactNativePersistence }        from 'firebase/auth';
import ReactNativeAsyncStorage              from '@react-native-async-storage/async-storage';
import { getFirestore }                     from 'firebase/firestore';
import { getDatabase }                      from 'firebase/database';

const firebaseConfig = {
  apiKey:            "AIzaSyA53fXsM_p-8ke6psbp3kKSidt4rOYAfgU",
  authDomain:        "team-jorge-e9d8b.firebaseapp.com",
  projectId:         "team-jorge-e9d8b",
  storageBucket:     "team-jorge-e9d8b.firebasestorage.app",
  messagingSenderId: "900611777392",
  appId:             "1:900611777392:web:7af54e82cccb4495ec25b5",
  measurementId:     "G-95P0MMWD4R",
  databaseURL:       "https://team-jorge-e9d8b-default-rtdb.europe-west1.firebasedatabase.app",
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

// ✅ Auth con persistencia real en AsyncStorage
export const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(ReactNativeAsyncStorage),
});

export const db   = getFirestore(app);
export const rtdb = getDatabase(app);
export default app;