// services/encuestas.js
/* Recuento PURO de las encuestas del Tablón (sin dependencias de React
   Native: verificable desde Node con tests/enlaces-test.js).

   Patrón WhatsApp: los resultados viven DENTRO del mensaje y se actualizan en
   vivo; cada opción muestra su barra con el porcentaje y el recuento, y la
   opción que va ganando se marca con color. Un empate marca varios líderes.

   Modelo de datos ( Firestore, posts/<id>.encuesta ):
     { pregunta, opciones: [string], votos: { uid: idxOpcion } } */

export const COLORES_ENCUESTA = ['#4A90E2', '#2DB37A', '#E5426A', '#F5A623', '#8E44AD', '#16A085'];

/** Color estable de la opción i-ésima (misma paleta en todos los teléfonos). */
export function colorOpcion(i) {
  const n = Number(i) || 0;
  return COLORES_ENCUESTA[((n % COLORES_ENCUESTA.length) + COLORES_ENCUESTA.length) % COLORES_ENCUESTA.length];
}

/**
 * Recuento completo de una encuesta.
 * Devuelve { porOpcion, porcentajes, total, max, lideres, mio }:
 *  · porOpcion[i]   → votos de la opción i
 *  · porcentajes[i] → % redondeado (0 si no hay votos)
 *  · total          → votos válidos (índices fuera de rango se ignoran)
 *  · lideres        → [índices] con el máximo de votos (>0); [] si nadie votó
 *  · mio            → índice que votó meUid, o null
 */
export function contarVotos(encuesta, meUid) {
  const opciones = (encuesta && Array.isArray(encuesta.opciones)) ? encuesta.opciones : [];
  const votos = (encuesta && encuesta.votos && typeof encuesta.votos === 'object') ? encuesta.votos : {};
  const porOpcion = opciones.map(() => 0);
  let total = 0;
  for (const uid of Object.keys(votos)) {
    const crudo = votos[uid];
    // null/''/booleanos NO son votos (Number(null)===0 colaría un voto fantasma)
    if (crudo == null || crudo === '' || typeof crudo === 'boolean') continue;
    const idx = Number(crudo);
    if (!Number.isInteger(idx) || idx < 0 || idx >= opciones.length) continue;   // voto inválido: se ignora
    porOpcion[idx] += 1;
    total += 1;
  }
  const porcentajes = porOpcion.map((n) => (total ? Math.round((n / total) * 100) : 0));
  const max = porOpcion.length ? Math.max.apply(null, porOpcion) : 0;
  const lideres = max > 0 ? porOpcion.map((n, i) => (n === max ? i : -1)).filter((i) => i >= 0) : [];
  let mio = null;
  if (meUid && votos[meUid] != null) {
    const idx = Number(votos[meUid]);
    if (Number.isInteger(idx) && idx >= 0 && idx < opciones.length) mio = idx;
  }
  return { porOpcion, porcentajes, total, max, lideres, mio };
}
