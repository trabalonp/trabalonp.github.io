// services/appSettings.js
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSyncExternalStore } from 'react';

const KEY = 'appSettings_v1';
const DEFAULTS = { language: 'es', units: 'metric', dateFormat: 'largo', themeMode: 'night' };

let settings = { ...DEFAULTS };
const listeners = new Set();
function emit() { listeners.forEach(fn => fn()); }
export function subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); }
export function getSettingsSnapshot() { return settings; }

export async function loadSettings() {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (raw) settings = { ...DEFAULTS, ...JSON.parse(raw) };
  } catch (e) {}
  emit();
  return settings;
}
export async function saveSettings(patch) {
  settings = { ...settings, ...patch };
  try { await AsyncStorage.setItem(KEY, JSON.stringify(settings)); } catch (e) {}
  emit();
  return settings;
}
export function useAppSettings() {
  return useSyncExternalStore(subscribe, getSettingsSnapshot, getSettingsSnapshot);
}
export function getThemeColors(themeMode = settings.themeMode, systemScheme = 'dark') {
  const light = themeMode === 'day' || (themeMode === 'device' && systemScheme === 'light');
  return light ? {
    background: '#F4F7FB', card: '#FFFFFF', text: '#152238', muted: '#5D6B82', border: '#D9E1EC',
    tab: '#FFFFFF', input: '#EEF3F8', overlay: '#00000055', navText: '#607089',
  } : {
    background: '#0D1B2A', card: '#162032', text: '#FFFFFF', muted: '#8FA8C8', border: '#1E3048',
    tab: '#0D1B2A', input: '#0D1B2A', overlay: '#00000088', navText: '#4A6080',
  };
}
loadSettings();

// ── i18n: diccionario central para claves compartidas ──
const DICT = {
  es: {
    'home.today': 'Entrenamiento de hoy',
    'home.tomorrow': 'Mañana',
    'home.upcoming': 'Próximos eventos',
    'home.add': 'Añadir',
    'home.emptyToday': 'No hay entrenamiento para hoy',
    'home.bannerTitle': 'Mira cómo evoluciona tu condición física',
    'home.bannerSub': 'Sincroniza tu cuenta de Intervals.icu para traer tus actividades de Garmin automáticamente.',
    'home.syncing': 'Sincronizando con Intervals.icu…',
    'settings.appSettings': 'Ajustes de la app',
    'appsettings.title': 'Ajustes de la app',
    'appsettings.language': 'Idioma',
    'appsettings.units': 'Preferencia de unidad',
    'appsettings.dateFormat': 'Formato de fecha',
    'appsettings.themeMode': 'Modo de la app',
    'theme.day': 'Día',
    'theme.night': 'Noche',
    'theme.device': 'Dispositivo',
    'appsettings.update': 'Actualizar',
    'appsettings.updated': 'Ajustes actualizados',
    'appsettings.updatedMsg': 'La configuración se ha aplicado en toda la app.',
    'units.metric': 'Métrica',
    'units.imperial': 'Imperial',
    'fmt.largo': 'Largo · 13 septiembre, 2026',
    'fmt.ddmmyyyy': 'DD/MM/AAAA · 13/09/2026',
    'fmt.mmddyyyy': 'MM/DD/AAAA · 09/13/2026',
    'fmt.yyyymmdd': 'AAAA-MM-DD · 2026-09-13',
    'chart.thisWeek': 'Esta Semana',
    'chart.lastWeek': 'La Semana Pasada',
    'chart.metric.distancia': 'Distancia',
    'chart.metric.duracion': 'Duración',
    'chart.metric.carga': 'Carga',
    'chart.metric.resumen': 'Resumen',
    'chart.completed': 'Completado',
    'chart.planned': 'Planificado',
    'chart.res.hour': 'Hora',
    'chart.res.dist': 'Dist',
    'chart.res.load': 'Carga',
    'chart.res.kcal': 'kcal',
    'chart.res.alt': 'Altura',
    'chart.res.steps': 'Pasos',
    'chart.res.ramp': 'Rampa',
    'chart.zonesTitle': 'Zonas de ritmo',
    'fitness.title': 'Progreso de entrenamiento',
    'fitness.fatigue': 'Fatiga',
    'fitness.condition': 'Condición',
    'fitness.form': 'Forma',
    'fitness.fitness': 'Fitness',
    'fitness.noPoints': 'No hay puntos suficientes para este intervalo.',
    'bucket.day': 'Día',
    'bucket.week': 'Semana',
    'bucket.month': 'Mes',
    'bucket.year': 'Año',
    'common.save': 'Guardar',
    'common.cancel': 'Cancelar',
    'common.delete': 'Eliminar',
    'common.close': 'Cerrar',
    'common.add': 'Añadir',
    'common.today': 'Hoy',
    'common.retry': 'Reintentar',
    'common.noData': 'Sin datos',
    'common.loading': 'Cargando…',
  },
  en: {
    'home.today': "Today's training",
    'home.tomorrow': 'Tomorrow',
    'home.upcoming': 'Upcoming events',
    'home.add': 'Add',
    'home.emptyToday': 'No training for today',
    'home.bannerTitle': 'See how your fitness is evolving',
    'home.bannerSub': 'Sync your Intervals.icu account to bring your Garmin activities in automatically.',
    'home.syncing': 'Syncing with Intervals.icu…',
    'settings.appSettings': 'App settings',
    'appsettings.title': 'App settings',
    'appsettings.language': 'Language',
    'appsettings.units': 'Unit preference',
    'appsettings.dateFormat': 'Date format',
    'appsettings.themeMode': 'App appearance',
    'theme.day': 'Day',
    'theme.night': 'Night',
    'theme.device': 'Device',
    'appsettings.update': 'Update',
    'appsettings.updated': 'Settings updated',
    'appsettings.updatedMsg': 'Your configuration has been applied across the app.',
    'units.metric': 'Metric',
    'units.imperial': 'Imperial',
    'fmt.largo': 'Long · September 13, 2026',
    'fmt.ddmmyyyy': 'DD/MM/YYYY · 09/13/2026',
    'fmt.mmddyyyy': 'MM/DD/YYYY · 09/13/2026',
    'fmt.yyyymmdd': 'YYYY-MM-DD · 2026-09-13',
    'chart.thisWeek': 'This Week',
    'chart.lastWeek': 'Last Week',
    'chart.metric.distancia': 'Distance',
    'chart.metric.duracion': 'Duration',
    'chart.metric.carga': 'Load',
    'chart.metric.resumen': 'Summary',
    'chart.completed': 'Completed',
    'chart.planned': 'Planned',
    'chart.res.hour': 'Time',
    'chart.res.dist': 'Dist',
    'chart.res.load': 'Load',
    'chart.res.kcal': 'kcal',
    'chart.res.alt': 'Elevation',
    'chart.res.steps': 'Steps',
    'chart.res.ramp': 'Ramp',
    'chart.zonesTitle': 'Pace zones',
    'fitness.title': 'Training progress',
    'fitness.fatigue': 'Fatigue',
    'fitness.condition': 'Fitness',
    'fitness.form': 'Form',
    'fitness.fitness': 'Fitness',
    'fitness.noPoints': 'Not enough points for this interval.',
    'bucket.day': 'Day',
    'bucket.week': 'Week',
    'bucket.month': 'Month',
    'bucket.year': 'Year',
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.delete': 'Delete',
    'common.close': 'Close',
    'common.add': 'Add',
    'common.today': 'Today',
    'common.retry': 'Retry',
    'common.noData': 'No data',
    'common.loading': 'Loading…',
  },
};
export function t(key) {
  const lang = settings.language || 'es';
  return (DICT[lang] && DICT[lang][key]) || DICT.es[key] || key;
}
// ── i18n inline para textos locales de cada pantalla ──
export function L(es, en) {
  return settings.language === 'en' ? en : es;
}
export function getDayLetters() {
  return settings.language === 'en'
    ? ['M', 'T', 'W', 'T', 'F', 'S', 'S']
    : ['L', 'M', 'Mx', 'J', 'V', 'S', 'D'];
}
export function locale() {
  return settings.language === 'en' ? 'en-US' : 'es-ES';
}

// ── Formateadores que respetan los ajustes ──
function fmtClock(s) {
  if (s == null) return '';
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = Math.floor(s % 60);
  return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
}
export function fmtDistance(km) {
  if (km == null) return '';
  if (settings.units === 'imperial') return `${(km * 0.621371).toFixed(2)} mi`;
  return `${km.toFixed(2)} km`;
}
export function formatSubtitleItem(item) {
  const parts = [];
  const time = fmtClock(item.duracion); if (time) parts.push(time);
  if (item.distancia != null) parts.push(fmtDistance(item.distancia));
  if (item['fc-media'] != null && item['fc-media'] > 0) {
    parts.push(`${item['fc-media']} ${settings.language === 'en' ? 'bpm' : 'ppm'}`);
  }
  return parts.join(' · ');
}
export function fmtHomeDate(date) {
  const loc = locale();
  const weekday = date.toLocaleDateString(loc, { weekday: 'long' });
  const dd = String(date.getDate()).padStart(2, '0');
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const yyyy = date.getFullYear();
  const monthLong = date.toLocaleDateString(loc, { month: 'long' });
  let core;
  switch (settings.dateFormat) {
    case 'dd/mm/yyyy': core = `${dd}/${mm}/${yyyy}`; break;
    case 'mm/dd/yyyy': core = `${mm}/${dd}/${yyyy}`; break;
    case 'yyyy-mm-dd': core = `${yyyy}-${mm}-${dd}`; break;
    default: core = settings.language === 'en' ? `${monthLong} ${date.getDate()}, ${yyyy}` : `${date.getDate()} ${monthLong}, ${yyyy}`;
  }
  const w = weekday.charAt(0).toUpperCase() + weekday.slice(1);
  return `${w} ${core}`;
}
