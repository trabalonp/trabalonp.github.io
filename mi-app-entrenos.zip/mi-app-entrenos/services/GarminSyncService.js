// services/GarminSyncService.js
import { auth } from '../firebaseConfig';
import { getApiUrl } from './api';

async function callApi(path, { method = 'GET', body } = {}) {
  const user = auth.currentUser;

  if (!user) {
    throw new Error('No hay sesión iniciada');
  }

  const apiUrl = await getApiUrl();
  const token = await user.getIdToken();

  const res = await fetch(`${apiUrl}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const raw = await res.text();
  let data = {};
  try {
    data = JSON.parse(raw);
  } catch {
    // El servidor devolvió HTML o texto (típico de 404/500 de otra plataforma)
    data = { _raw: raw.slice(0, 300) };
  }

  return { res, data, url: `${apiUrl}${path}` };
}

function detailOf(data, res) {
  return data.error || data._raw || `HTTP ${res.status} sin detalles`;
}

// Estado de la conexión con Intervals.icu
export async function getIntervalsStatus() {
  try {
    const { res, data } = await callApi('/intervals/status');
    if (!res.ok) return { connected: false };
    return data;
  } catch {
    return { connected: false };
  }
}

// Guardar credenciales (Athlete ID + API key) y validarlas contra la API
export async function saveIntervalsCredentials(athleteId, apiKey) {
  const { res, data, url } = await callApi('/intervals/save-credentials', {
    method: 'POST',
    body: { athleteId, apiKey },
  });

  if (!res.ok) {
    throw new Error(`HTTP ${res.status} contra ${url} → ${detailOf(data, res)}`);
  }

  return data;
}

// Desconectar Intervals.icu
export async function disconnectIntervals() {
  const { res, data, url } = await callApi('/intervals/disconnect', {
    method: 'POST',
  });

  if (!res.ok) {
    throw new Error(`HTTP ${res.status} contra ${url} → ${detailOf(data, res)}`);
  }

  return data;
}

// Sincronizar actividades nuevas desde Intervals.icu
export async function syncFromIntervals(onProgress) {
  onProgress?.('Sincronizando con Intervals.icu…', 0, 0);

  const { res, data, url } = await callApi('/sync-intervals', {
    method: 'POST',
    body: {},
  });

  if (res.status === 400 && data.error === 'Intervals.icu no conectado') {
    return { needsConnection: true };
  }

  if (!res.ok) {
    throw new Error(`HTTP ${res.status} contra ${url} → ${detailOf(data, res)}`);
  }

  return {
    synced: data.synced || 0,
    skipped: data.skipped || 0,
    errors: data.errors || 0,
    total: data.total || 0,
  };
}