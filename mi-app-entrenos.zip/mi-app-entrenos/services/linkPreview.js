// services/linkPreview.js
/* Previsualización de enlaces estilo WhatsApp.

   Cómo lo hace WhatsApp (investigado): el cliente del EMISOR obtiene los
   metadatos Open Graph de la página (og:title, og:description, og:image)
   mientras se escribe el mensaje y los ADJUNTA al propio mensaje; quien lo
   recibe pinta la tarjeta sin descargar nada. La app no puede navegar la web
   directamente de forma fiable (CORS, SSRF, coste), así que aquí el metadata
   lo obtiene el servidor Vercel (api/social/link-preview.js) y el resultado
   se cachea 7 días en el dispositivo (una sola petición por URL).

   · previewParaEnvio(url, me) → emisora: fresco, con tope de 3.5 s para no
     retrasar el envío; se adjunta al post de Firestore (campo `preview`).
   · obtenerPreview(url)       → receptora: para mensajes antiguos sin campo
     `preview`; usa la caché y, si falta, pide al servidor (single-flight,
     fallos cacheados 1 h para no insistir). */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { auth } from '../firebaseConfig';
import { getApiUrl } from './api';
import { dominioDe } from './enlaces';

const K = 'tj_linkprev_v1';
const TTL_MS = 7 * 86400000;      // previews buenos: 7 días
const TTL_FALLO_MS = 3600000;     // fallos: no reintentar en 1 h
const MAX_ENTRADAS = 200;

let memIdx = null;                // { [url]: { url, titulo, descripcion, imagen, dominio, sitio, ts, fallo? } }
let initPr = null;
let saveTimer = null;
const inflight = new Map();       // url -> promesa (single-flight)

function safeJson(s, d) { try { const v = JSON.parse(s); return v == null ? d : v; } catch (e) { return d; } }

async function leer() {
  if (memIdx) return memIdx;
  if (!initPr) {
    initPr = (async () => {
      try { memIdx = safeJson(await AsyncStorage.getItem(K), {}) || {}; } catch (e) { memIdx = {}; }
      if (typeof memIdx !== 'object' || Array.isArray(memIdx)) memIdx = {};
      return memIdx;
    })();
  }
  return initPr;
}

function persist() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      // Evicción: fuera lo caducado; si sigue grande, lo más antiguo
      const ahora = Date.now();
      let entradas = Object.keys(memIdx || {}).map((k) => [k, memIdx[k]]);
      entradas = entradas.filter(([, v]) => v && v.ts && (v.fallo ? ahora - v.ts < TTL_FALLO_MS : ahora - v.ts < TTL_MS));
      if (entradas.length > MAX_ENTRADAS) {
        entradas.sort((a, b) => (b[1].ts || 0) - (a[1].ts || 0));
        entradas = entradas.slice(0, MAX_ENTRADAS);
      }
      const limpio = {};
      for (const [k, v] of entradas) limpio[k] = v;
      memIdx = limpio;
      AsyncStorage.setItem(K, JSON.stringify(limpo));
    } catch (e) { /* caché: no crítica */ }
  }, 400);
}

function guardar(url, entrada) {
  if (!url || !entrada) return;
  leer().then((idx) => { idx[url] = entrada; persist(); }).catch(() => {});
}

function limpiar(e, url) {
  if (!e || (!e.titulo && !e.imagen)) return null;
  return {
    url: e.url || url,
    titulo: e.titulo || null,
    descripcion: e.descripcion || null,
    imagen: e.imagen || null,
    dominio: e.dominio || dominioDe(e.url || url),
    sitio: e.sitio || null,
    ts: e.ts || Date.now(),
  };
}

async function pedir(url, timeoutMs, meUser) {
  const me = meUser || auth.currentUser;
  if (!me) return null;
  const apiUrl = (await getApiUrl()).replace(/\/+$/, '');
  const token = await me.getIdToken();
  const ctrl = new AbortController();
  const t = setTimeout(() => { try { ctrl.abort(); } catch (e) {} }, timeoutMs);
  try {
    const r = await fetch(`${apiUrl}/social/link-preview`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ url }),
      signal: ctrl.signal,
    });
    const d = await r.json().catch(() => null);
    if (r.ok && d && d.preview) {
      const bueno = { ...d.preview, ts: Date.now() };
      guardar(url, bueno);
      return limpiar(bueno, url);
    }
    // Servidor respondió pero sin metadatos (o error): se cachea como fallo
    if (r.ok) guardar(url, { ts: Date.now(), fallo: true });
    return null;
  } finally {
    clearTimeout(t);
  }
}

/** Emisora: preview fresco para adjuntar al mensaje (tope 3.5 s, nunca lanza). */
export async function previewParaEnvio(url, meUser) {
  try {
    if (!url) return null;
    const idx = await leer();
    const e = idx[url];
    if (e && !e.fallo && e.ts && Date.now() - e.ts < TTL_MS) {
      const c = limpiar(e, url);
      if (c) return c;
    }
    return await pedir(url, 3500, meUser);
  } catch (e) { return null; }
}

/** Receptora: preview cacheado o pedido al servidor (single-flight, nunca lanza). */
export async function obtenerPreview(url) {
  try {
    if (!url) return null;
    const idx = await leer();
    const e = idx[url];
    const ahora = Date.now();
    if (e && e.ts) {
      if (e.fallo) {
        if (ahora - e.ts < TTL_FALLO_MS) return null;      // fallo reciente: no insistir
      } else if (ahora - e.ts < TTL_MS) {
        const c = limpiar(e, url);
        if (c) return c;
      }
    }
    if (inflight.has(url)) return inflight.get(url);
    const pr = pedir(url, 6500, null)
      .catch((err) => { guardar(url, { ts: Date.now(), fallo: true }); return null; })
      .then((r) => { inflight.delete(url); return r; });
    inflight.set(url, pr);
    return pr;
  } catch (e) { return null; }
}
