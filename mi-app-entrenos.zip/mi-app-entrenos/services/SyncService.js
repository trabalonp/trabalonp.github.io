// services/SyncService.js
import { Decoder, Stream } from '@garmin/fitsdk';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system/legacy';
import { addDoc, collection, doc, getDocs, query, setDoc, Timestamp, where } from 'firebase/firestore';
import { db } from '../firebaseConfig';

const FOLDER_KEY = 'fit_folder_uri';
const MAX_GRAPH_POINTS = 1000;
const SEMI = 180 / 2147483648;

export async function syncFitFiles(userId, onProgress) {
  const folderUri = await AsyncStorage.getItem(FOLDER_KEY);
  if (!folderUri) {
    return {
      synced: 0, skipped: 0, errors: 0, cancelled: true,
      message: 'No hay carpeta configurada. Ve a Ajustes > Sincronizar archivos.',
    };
  }
  onProgress?.('Buscando archivos .fit…', 0, 0);
  const fitFiles = await listFitFilesRecursive(folderUri, 0);
  if (fitFiles.length === 0) {
    return { synced: 0, skipped: 0, errors: 0, total: 0 };
  }
  let synced = 0, skipped = 0, errors = 0;
  for (let i = 0; i < fitFiles.length; i++) {
    const file = fitFiles[i];
    onProgress?.(`Procesando ${file.name}`, i + 1, fitFiles.length);
    try {
      const alreadyExists = await checkDuplicate(userId, file.name);
      if (alreadyExists) { skipped++; continue; }

      const parsed = await parseFitFile(file.uri);
      if (!parsed) { errors++; continue; }
      
      const docRef = await addDoc(collection(db, 'entrenamientos'), {
        userId,
        id_archivo: file.name,
        fecha: Timestamp.fromDate(parsed.fecha),
        tipo: parsed.tipo,
        titulo: parsed.nombre || parsed.tipo,
        distancia: parsed.distancia,
        duracion: parsed.duracion,
        'fc-media': parsed.fcMedia,
        estado: 'completo',
        // NUEVOS CAMPOS en el documento principal para las gráficas
        elevacion: parsed.desnivelPos || 0,
        desnivelPos: parsed.desnivelPos || 0,
        desnivelNeg: parsed.desnivelNeg || 0,
        potenciaMedia: parsed.potenciaMedia || 0,
        cadencia: parsed.cadencia || 0,
      });
      
      await setDoc(doc(db, 'entrenamientos', docRef.id, 'detalles', 'data'), {
        calorias: parsed.calorias,
        fcMax: parsed.fcMax,
        ritmo: parsed.ritmo,
        elevacionMin: parsed.elevacionMin,
        elevacionMax: parsed.elevacionMax,
        cadencia: parsed.cadencia,
        desnivelPos: parsed.desnivelPos,
        temperatura: parsed.temperatura,
        esfuerzo: parsed.esfuerzo ?? 0,
        tss: 0,
        notas: '',
        cargaPercibida: '',
        enlace: '',
        sensacion: 0,
        descripcion: '',
        pasos: [],
        comentarios: [],
        vueltas: parsed.vueltas,
        completado: false,
        hasRuta: (parsed.registros || []).some(p => p.lat != null && p.lon != null),
      });
      
      if (parsed.registros?.length > 0) {
        await setDoc(doc(db, 'entrenamientos', docRef.id, 'registros', 'data'), {
          puntos: parsed.registros,
        });
      }
      synced++;
    } catch (err) {
      console.warn('[SyncService] Error en', file.name, err.message);
      errors++;
    }
  }
  return { synced, skipped, errors, total: fitFiles.length };
}

async function listFitFilesRecursive(uri, depth) {
  if (depth > 4) return [];
  let files = [];
  try {
    const entries = await FileSystem.StorageAccessFramework.readDirectoryAsync(uri);
    for (const entryUri of entries) {
      if (entryUri.endsWith('/')) {
        const sub = await listFitFilesRecursive(entryUri, depth + 1);
        files = files.concat(sub);
      } else {
        const name = decodeURIComponent(entryUri.split('/').pop());
        if (name.toLowerCase().endsWith('.fit')) {
          files.push({ uri: entryUri, name });
        }
      }
    }
  } catch (e) {
    console.warn('[SyncService] Error al leer carpeta:', e.message);
  }
  return files;
}

async function checkDuplicate(userId, idArchivo) {
  const q = query(
    collection(db, 'entrenamientos'),
    where('userId', '==', userId),
    where('id_archivo', '==', idArchivo),
  );
  const snap = await getDocs(q);
  return !snap.empty;
}

async function parseFitFile(contentUri) {
  try {
    const base64 = await FileSystem.readAsStringAsync(contentUri, {
      encoding: FileSystem.EncodingType.Base64,
    });
    const binary = _base64ToArrayBuffer(base64);
    const stream = Stream.fromByteArray(new Uint8Array(binary));
    if (!Decoder.isFIT(stream)) {
      console.warn('[SyncService] El archivo no es un FIT válido');
      return null;
    }
    const decoder = new Decoder(stream);
    const { messages, errors } = decoder.read({
      includeUnknownData: true,
      mergeHeartRates: true,
    });
    if (errors.length > 0) {
      console.warn('[SyncService] Errores al decodificar:', errors);
    }
    const sessionMesgs = messages['sessionMesgs'] || [];
    const lapMesgs = messages['lapMesgs'] || [];
    const recordMesgs = messages['recordMesgs'] || [];
    
    let startTime, distancia, duracion, calorias, fcMedia, fcMax, elevMin, elevMax,
        avgSpeed, ritmo, cadencia, desnivelPos, desnivelNeg, temperatura, nombre, sport, esfuerzo, potenciaMedia;
    
    if (sessionMesgs.length > 0) {
      const session = sessionMesgs[0];
      startTime = session.startTime || new Date();
      distancia = parseFloat(((session.totalDistance ?? 0) / 1000).toFixed(2));
      duracion = Math.round(session.totalElapsedTime ?? 0);
      calorias = session.totalCalories ?? 0;
      fcMedia = session.avgHeartRate ?? 0;
      fcMax = session.maxHeartRate ?? 0;
      elevMin = session.minAltitude ?? 0;
      elevMax = session.maxAltitude ?? 0;
      avgSpeed = session.enhancedAvgSpeed ?? session.avgSpeed ?? null;
      cadencia = session.avgCadence ?? 0;
      desnivelPos = session.totalAscent ?? 0;
      desnivelNeg = session.totalDescent ?? 0;
      temperatura = session.avgTemperature ?? 0;
      nombre = session.sessionName ?? session.workoutName ?? session.activityName ?? '';
      sport = session.sport ?? 'generic';
      esfuerzo = session.totalTrainingEffect ?? session.activityTrainingLoad ?? 0;
      potenciaMedia = session.avgPower ?? 0;
    } else if (recordMesgs.length > 0) {
      startTime = new Date(recordMesgs[0].timestamp);
      const lastRecord = recordMesgs[recordMesgs.length - 1];
      distancia = parseFloat(((lastRecord.distance ?? 0) / 1000).toFixed(2));
      const firstTs = new Date(recordMesgs[0].timestamp).getTime();
      const lastTs = new Date(recordMesgs[recordMesgs.length - 1].timestamp).getTime();
      duracion = Math.round((lastTs - firstTs) / 1000);
      calorias = 0; fcMedia = 0; fcMax = 0; elevMin = 0; elevMax = 0;
      avgSpeed = null; cadencia = 0; desnivelPos = 0; desnivelNeg = 0; temperatura = 0;
      nombre = ''; sport = 'generic'; esfuerzo = 0; potenciaMedia = 0;
    } else {
      console.warn('[SyncService] No se encontraron datos');
      return null;
    }
    
    const tipo = mapSport(sport);
    const isRunning = tipo === 'Running';
    
    if (isRunning && cadencia > 0) cadencia = cadencia * 2;
    
    if (avgSpeed && avgSpeed > 0) {
      const speedKmh = avgSpeed * 3.6;
      const pace = 60 / speedKmh;
      const minutes = Math.floor(pace);
      const seconds = Math.round((pace - minutes) * 60);
      ritmo = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    } else if (distancia > 0 && duracion > 0) {
      const totalMin = duracion / 60;
      const pace = totalMin / distancia;
      const minutes = Math.floor(pace);
      const seconds = Math.round((pace - minutes) * 60);
      ritmo = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    } else {
      ritmo = '';
    }
    
    const vueltas = lapMesgs.map((lap, index) => {
      const lapDistancia = parseFloat(((lap.totalDistance ?? 0) / 1000).toFixed(2));
      const lapDuracion = lap.totalElapsedTime ?? 0;
      const lapVelocidad = lap.enhancedAvgSpeed ?? lap.avgSpeed ?? 0;
      const lapMaxSpeed = lap.enhancedMaxSpeed ?? lap.maxSpeed ?? 0;
      let lapRitmo = '';
      if (lapVelocidad > 0) {
        const pace = 60 / (lapVelocidad * 3.6);
        const min = Math.floor(pace);
        const sec = Math.round((pace - min) * 60);
        lapRitmo = `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
      } else if (lapDistancia > 0 && lapDuracion > 0) {
        const pace = (lapDuracion / 60) / lapDistancia;
        const min = Math.floor(pace);
        const sec = Math.round((pace - min) * 60);
        lapRitmo = `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
      }
      let lapRitmoMax = '';
      if (lapMaxSpeed > 0) {
        const paceMax = 60 / (lapMaxSpeed * 3.6);
        const min = Math.floor(paceMax);
        const sec = Math.round((paceMax - min) * 60);
        lapRitmoMax = `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
      }
      const ascent = lap.totalAscent ?? 0;
      const descent = lap.totalDescent ?? 0;
      return {
        vuelta: index + 1,
        distancia: lapDistancia,
        tiempo: lapDuracion,
        ritmo: lapRitmo,
        ritmoMaximo: lapRitmoMax,
        fcMedia: lap.avgHeartRate ?? 0,
        fcMaxima: lap.maxHeartRate ?? 0,
        cadenciaMedia: isRunning ? (lap.avgCadence ?? 0) * 2 : (lap.avgCadence ?? 0),
        cadenciaMaxima: isRunning ? (lap.maxCadence ?? 0) * 2 : (lap.maxCadence ?? 0),
        gananciaElev: ascent,
        perdidaElev: descent,
        difElev: ascent - descent,
      };
    });
    
    let registros = recordMesgs.map(r => ({
      timestamp: r.timestamp ? new Date(r.timestamp).toISOString() : new Date().toISOString(),
      distancia: parseFloat(((r.distance ?? 0) / 1000).toFixed(2)),
      altitud: r.enhancedAltitude ?? r.altitude ?? 0,
      frecuencia: r.heartRate ?? 0,
      cadencia: isRunning ? (r.cadence ?? 0) * 2 : (r.cadence ?? 0),
      potencia: r.power ?? 0,
      velocidad: parseFloat(((r.enhancedSpeed ?? r.speed ?? 0) * 3.6).toFixed(2)),
      lat: r.position_lat != null ? r.position_lat * SEMI : null,
      lon: r.position_long != null ? r.position_long * SEMI : null,
    }));
    
    if (registros.length > MAX_GRAPH_POINTS) {
      const step = Math.ceil(registros.length / MAX_GRAPH_POINTS);
      registros = registros.filter((_, i) => i % step === 0);
      const last = recordMesgs[recordMesgs.length - 1];
      if (registros[registros.length - 1]?.timestamp !== new Date(last.timestamp).toISOString()) {
        registros.push({
          timestamp: last.timestamp ? new Date(last.timestamp).toISOString() : new Date().toISOString(),
          distancia: parseFloat(((last.distance ?? 0) / 1000).toFixed(2)),
          altitud: last.enhancedAltitude ?? last.altitude ?? 0,
          frecuencia: last.heartRate ?? 0,
          cadencia: isRunning ? (last.cadence ?? 0) * 2 : (last.cadence ?? 0),
          potencia: last.power ?? 0,
          velocidad: parseFloat(((last.enhancedSpeed ?? last.speed ?? 0) * 3.6).toFixed(2)),
          lat: last.position_lat != null ? last.position_lat * SEMI : null,
          lon: last.position_long != null ? last.position_long * SEMI : null,
        });
      }
    }
    
    return {
      fecha: startTime,
      distancia,
      duracion,
      calorias,
      fcMedia,
      fcMax,
      ritmo,
      elevacionMin: elevMin,
      elevacionMax: elevMax,
      cadencia,
      desnivelPos,
      desnivelNeg,
      temperatura,
      esfuerzo: esfuerzo ?? 0,
      potenciaMedia,
      tipo,
      nombre,
      vueltas,
      registros,
    };
  } catch (e) {
    console.warn('[parseFitFile] error:', e.message);
    return null;
  }
}

function mapSport(sport) {
  const map = {
    cycling: 'Ciclismo',
    running: 'Running',
    swimming: 'Natación',
    training: 'Fuerza',
    generic: 'Otro',
  };
  return map[sport?.toLowerCase()] ?? 'Otro';
}

export async function resetSyncFolder() {
  await AsyncStorage.removeItem(FOLDER_KEY);
}

function _base64ToArrayBuffer(base64) {
  const binary_string = atob(base64);
  const len = binary_string.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary_string.charCodeAt(i);
  }
  return bytes;
}