// services/analyticsEngine.js
import AsyncStorage from '@react-native-async-storage/async-storage';
import { collection, doc, getDoc, getDocs, limit, orderBy, query, startAfter, where } from 'firebase/firestore';
import { db } from '../firebaseConfig';

const mem = {};
const streamMem = {};
const MEM_TTL = 5 * 60 * 1000;
const WINDOW_DAYS = 60;
const STREAM_ACT_LIMIT = 20;
const MAX_BUCKETS = 160;

// Incrementar esta versión invalida automáticamente las cachés antiguas.
const CACHE_V = 3;

const pad = (n) => String(n).padStart(2, '0');
const dayKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export const STREAM_SIZES = [60, 120, 300, 600, 1200, 1800, 3600, 5400, 7200];
export const STREAM_LABELS = ['1m', '2m', '5m', '10m', '20m', '30m', '1h', '1h30', '2h'];

const chunksOf = (arr, n) => {
  const out = [];

  for (let i = 0; i < arr.length; i += n) {
    out.push(arr.slice(i, i + n));
  }

  return out;
};

function isoWeekKey(d) {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = date.getUTCDay() || 7;

  date.setUTCDate(date.getUTCDate() + 4 - dayNum);

  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  const week = Math.ceil((((date - yearStart) / 86400000) + 1) / 7);

  return `${date.getUTCFullYear()}-W${pad(week)}`;
}

export function groupKey(d, group) {
  if (group === 'diario') return dayKey(d);
  if (group === 'semanal') return isoWeekKey(d);
  if (group === 'mensual') return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;

  return `${d.getFullYear()}`;
}

export function periodStart(period) {
  const now = new Date();

  if (period === '30d') {
    return new Date(now.getFullYear(), now.getMonth(), now.getDate() - 30);
  }

  if (period === '3m') {
    return new Date(now.getFullYear(), now.getMonth() - 3, now.getDate());
  }

  if (period === '6m') {
    return new Date(now.getFullYear(), now.getMonth() - 6, now.getDate());
  }

  if (period === '1y') {
    return new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
  }

  if (period === '2y') {
    return new Date(now.getFullYear() - 2, now.getMonth(), now.getDate());
  }

  return null;
}

function paceToSec(v) {
  if (v == null || v === '') return null;

  if (typeof v === 'number') return v;

  const m = String(v).trim().match(/^(\d+):(\d{1,2})$/);

  if (m) {
    return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
  }

  const n = Number(v);

  return Number.isFinite(n) && n > 0 ? n : null;
}

function normalizeUmbral(v) {
  if (v == null) return null;

  if (typeof v === 'string') {
    return paceToSec(v);
  }

  const n = Number(v);

  if (!Number.isFinite(n) || n <= 0) return null;

  return n < 20 ? 1000 / n : n;
}

export function fmtBucketLabel(k, group) {
  if (group === 'diario') {
    return k.slice(5).replace('-', '/');
  }

  if (group === 'semanal') {
    return k.slice(5);
  }

  if (group === 'mensual') {
    const [y, m] = k.split('-');
    return `${['E', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'][+m - 1]}${y.slice(2)}`;
  }

  return k;
}

export function effectiveGroupFor(group, period) {
  const order = ['diario', 'semanal', 'mensual', 'anio'];
  const sizes = {
    diario: 1,
    semanal: 7,
    mensual: 30,
    anio: 365,
  };

  const start = periodStart(period);
  const span = start
    ? Math.max(1, Math.round((Date.now() - start.getTime()) / 86400000))
    : 1095;

  let idx = Math.max(0, order.indexOf(group));
  let count = span / sizes[order[idx]];

  while (count > MAX_BUCKETS && idx < order.length - 1) {
    idx++;
    count = span / sizes[order[idx]];
  }

  return {
    group: order[idx],
    upgraded: order[idx] !== group,
    label: order[idx],
  };
}

function emptyDay() {
  return {
    dist: 0,
    dur: 0,
    count: 0,
    planDist: 0,
    planDur: 0,
    load: 0,
    kcal: 0,
    steps: 0,

    sleep: null,
    rhr: null,
    fcMax: null,
    avgHr: null,
    vo2: null,
    hrv: null,
    weight: null,
    spo2: null,
    score: null,
    bf: null,
    bw: null,
    ftp: null,
    lthr: null,
    umbral: null,

    fcMS: 0,
    fcMN: 0,
    maxDist: 0,
    maxDur: 0,
    bestPace: null,
    elev: 0,
    potS: 0,
    potT: 0,
    iDist: 0,
    iDur: 0,
  };
}

function resetWorkoutFields(d) {
  d.dist = 0;
  d.dur = 0;
  d.count = 0;
  d.planDist = 0;
  d.planDur = 0;
  d.maxDist = 0;
  d.maxDur = 0;
  d.bestPace = null;
  d.fcMS = 0;
  d.fcMN = 0;
  d.elev = 0;
  d.potS = 0;
  d.potT = 0;
  d.iDist = 0;
  d.iDur = 0;
}

function planOf(pasos) {
  let sec = 0;
  let km = 0;

  const walk = (list) => (list || []).forEach((p) => {
    const reps = Number(p.repeticiones) || 1;
    const val = Number(p.durValor ?? p.valor);

    let s = 0;
    let k = 0;

    if (Number.isFinite(val) && val > 0) {
      const isDist =
        p.durTipo === 'Distancia' ||
        (
          p.durTipo !== 'Tiempo' &&
          ['km', 'm', 'mi', 'yd'].includes(p.durUnidad || p.unidad)
        );

      if (isDist) {
        const u = p.durUnidad || p.unidad || 'km';

        k =
          u === 'mi'
            ? val * 1.609344
            : u === 'm'
              ? val / 1000
              : u === 'yd'
                ? val * 0.0009144
                : val;
      } else {
        s = val * 60;
      }
    }

    let pace = null;

    if (p.objetivo === 'Ritmo' || p.objetivo === 'Zona ritmo') {
      const a = paceToSec(p.objMin);
      const b = paceToSec(p.objMax);

      if (a != null && b != null) {
        pace = (a + b) / 2;
      }
    }

    if (k === 0 && s > 0 && pace) {
      k = s / pace;
    }

    if (s === 0 && k > 0 && pace) {
      s = k * pace;
    }

    sec += s * reps;
    km += k * reps;

    walk(p.hijos);
  });

  walk(pasos);

  return { sec, km };
}

function mergeWorkout(days, w) {
  if (!w.fecha || w.tipo === 'Descanso' || w.tipo === 'Evento') {
    return;
  }

  const f = w.fecha.toDate ? w.fecha.toDate() : new Date(w.fecha);
  const k = dayKey(f);
  const d = days[k] || (days[k] = emptyDay());

  const real = (w.duracion > 0) || w.estado === 'completo';

  if (real) {
    d.dist += w.distancia || 0;
    d.dur += w.duracion || 0;
    d.count++;

    const fcM = Number(w['fc-media']);

    if (Number.isFinite(fcM) && fcM > 0) {
      d.fcMS += fcM;
      d.fcMN++;
    }

    if ((w.distancia || 0) > d.maxDist) {
      d.maxDist = w.distancia;
    }

    if ((w.duracion || 0) > d.maxDur) {
      d.maxDur = w.duracion;
    }

    if ((w.distancia || 0) >= 1 && (w.duracion || 0) > 0) {
      const p = w.duracion / w.distancia;

      if (d.bestPace == null || p < d.bestPace) {
        d.bestPace = p;
      }
    }
  }

  if (Array.isArray(w.pasos) && w.pasos.length) {
    const pl = planOf(w.pasos);

    d.planDist += pl.km;
    d.planDur += pl.sec;
  }
}

// Construye el historial a partir de la misma lista que ya utiliza la home.
// Sirve como fuente de verdad local cuando la consulta/persistencia del análisis
// no está disponible o contiene una caché antigua.
export function buildDaysFromWorkouts(workouts) {
  const days = {};
  (workouts || []).forEach((workout) => mergeWorkout(days, workout));
  return days;
}

async function fetchWorkouts(uid, days, { from, to }) {
  try {
    let last = null;
    let total = 0;

    for (;;) {
      const cs = [
        where('userId', '==', uid),
        orderBy('fecha', 'desc'),
        limit(300),
      ];

      if (from) {
        cs.push(where('fecha', '>=', from));
      }

      if (to) {
        cs.push(where('fecha', '<=', to));
      }

      if (last) {
        cs.push(startAfter(last));
      }

      const snap = await getDocs(
        query(collection(db, 'entrenamientos'), ...cs)
      );

      if (snap.empty) {
        break;
      }

      snap.forEach((ds) => {
        mergeWorkout(days, ds.data());
      });

      total += snap.size;
      last = snap.docs[snap.docs.length - 1];

      if (snap.size < 300) {
        break;
      }
    }

    return total;
  } catch (e) {
    console.warn('[analytics] fetchWorkouts(order) falló:', e.message);
  }

  try {
    const cs = [
      where('userId', '==', uid),
      limit(1000),
    ];

    if (from) {
      cs.push(where('fecha', '>=', from));
    }

    if (to) {
      cs.push(where('fecha', '<=', to));
    }

    const snap = await getDocs(
      query(collection(db, 'entrenamientos'), ...cs)
    );

    snap.forEach((ds) => {
      mergeWorkout(days, ds.data());
    });

    return snap.size;
  } catch (e) {
    console.warn('[analytics] fetchWorkouts falló:', e.message);
    return 0;
  }
}

async function mergeWellness(uid, days) {
  try {
    const s = await getDoc(doc(db, 'wellness', uid));

    if (!s.exists()) {
      console.warn('[analytics] wellness sin documento para', uid);
      return;
    }

    const wd = s.data().days || {};

    for (const [k, v] of Object.entries(wd)) {
      const d = days[k] || (days[k] = emptyDay());

      if (v.load != null) d.load = v.load;
      if (v.kcal != null) d.kcal = v.kcal;
      if (v.steps != null) d.steps = v.steps;
      if (v.sleep != null) d.sleep = v.sleep / 3600;
      if (v.rhr != null) d.rhr = v.rhr;
      if (v.fcMax != null) d.fcMax = v.fcMax;
      if (v.avgHr != null) d.avgHr = v.avgHr;

      const vo2 = v.vo2_est ?? v.vo2;

      if (vo2 != null) d.vo2 = vo2;
      if (v.hrv != null) d.hrv = v.hrv;
      if (v.weight != null) d.weight = v.weight;
      if (v.spo2 != null) d.spo2 = v.spo2;
      if (v.score != null) d.score = v.score;
      if (v.bf != null) d.bf = v.bf;

      if (v.bw != null && v.bw <= 100) {
        d.bw = v.bw;
      }

      if (v.ftp != null) d.ftp = v.ftp;
      if (v.lthr != null) d.lthr = v.lthr;
      if (v.umbral != null) d.umbral = normalizeUmbral(v.umbral);

      if (v.elev != null) {
        d.elev = (d.elev || 0) + v.elev;
      }

      if (v.potS != null) {
        d.potS = (d.potS || 0) + v.potS;
      }

      if (v.potT != null) {
        d.potT = (d.potT || 0) + v.potT;
      }

      if (v.iDist != null) d.iDist = v.iDist;
      if (v.iDur != null) d.iDur = v.iDur;
    }
  } catch (e) {
    console.warn('[analytics] mergeWellness falló:', e.message);
  }
}

function hasUsableAnalyticsCache(cache) {
  if (!cache || typeof cache !== 'object') {
    return false;
  }

  if (cache.v !== CACHE_V) {
    return false;
  }

  if (!cache.days || typeof cache.days !== 'object') {
    return false;
  }

  return Object.keys(cache.days).length > 0;
}

export async function getAnalyticsDays(uid, { force = false } = {}) {
  if (!uid) {
    return {};
  }

  const cachedMem = mem[uid];

  if (
    !force &&
    cachedMem &&
    Date.now() - cachedMem.ts < MEM_TTL &&
    cachedMem.days &&
    Object.keys(cachedMem.days).length > 0
  ) {
    return cachedMem.days;
  }

  const key = `analyticsCache_v${CACHE_V}_${uid}`;

  let cache = null;

  if (!force) {
    try {
      const raw = await AsyncStorage.getItem(key);

      if (raw) {
        const parsed = JSON.parse(raw);

        if (hasUsableAnalyticsCache(parsed)) {
          cache = parsed;
        } else {
          // Elimina una caché antigua, vacía o incompatible.
          await AsyncStorage.removeItem(key);
        }
      }
    } catch (e) {
      console.warn('[analytics] caché local inválida:', e.message);
      cache = null;
    }
  }

  // El análisis funciona como un snapshot persistente: si ya existe, no se
  // vuelve a consultar Firestore hasta que el usuario pulse refrescar.
  if (!force && cache?.days) {
    mem[uid] = { days: cache.days, ts: Date.now() };
    return cache.days;
  }

  const days = cache?.days || {};

  const winStart = new Date();
  winStart.setDate(winStart.getDate() - WINDOW_DAYS);

  const winKey = dayKey(winStart);

  for (const k of Object.keys(days)) {
    if (k >= winKey) {
      resetWorkoutFields(days[k]);
    }
  }

  const nWin = await fetchWorkouts(uid, days, {
    from: winStart,
  });

  let nOld = 0;

  if (force || !cache?.oldDone || Object.keys(days).length === 0) {
    const to = new Date(winStart);
    to.setDate(to.getDate() - 1);

    nOld = await fetchWorkouts(uid, days, {
      to,
    });
  }

  await mergeWellness(uid, days);

  try {
    await AsyncStorage.setItem(
      key,
      JSON.stringify({
        v: CACHE_V,
        oldDone: true,
        days,
      })
    );
  } catch (e) {
    console.warn('[analytics] no se pudo guardar la caché:', e.message);
  }

  mem[uid] = {
    days,
    ts: Date.now(),
  };

  console.log(
    `[analytics] days listos: ventana=${nWin} historial=${nOld} claves=${Object.keys(days).length}`
  );

  return days;
}

export function invalidateAnalytics(uid) {
  if (uid) {
    delete mem[uid];
    Object.keys(streamMem)
      .filter((key) => key.startsWith(`${uid}:`))
      .forEach((key) => delete streamMem[key]);
  }
}

export async function getStreamsStats(uid, period, profile, { force = false } = {}) {
  const key = `${uid}:${period}`;
  const c = streamMem[key];

  if (!force && c) {
    return c.val;
  }

  const storageKey = `analyticsStreams_v${CACHE_V}_${uid}_${period}`;
  if (!force) {
    try {
      const raw = await AsyncStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed?.v === CACHE_V && parsed.val) {
          streamMem[key] = { val: parsed.val, ts: Date.now() };
          return parsed.val;
        }
      }
    } catch (e) {
      console.warn('[analytics] caché persistente de streams inválida:', e.message);
    }
  }

  const fcZ = (profile?.zonasFC || [])
    .map((z) => ({
      label: z.label || 'Z',
      lo: Number(z.min),
      hi: Number(z.max),
    }))
    .filter((b) => Number.isFinite(b.lo) && Number.isFinite(b.hi));

  const rtZ = (profile?.zonasRitmo || [])
    .map((z) => {
      const a = paceToSec(z.min);
      const b = paceToSec(z.max);

      if (a == null || b == null) {
        return null;
      }

      return {
        label: z.label || 'R',
        lo: Math.min(a, b),
        hi: Math.max(a, b),
      };
    })
    .filter(Boolean);

  const zoneFc = fcZ.map((b) => ({
    label: b.label,
    sec: 0,
  }));
  if (fcZ.length) zoneFc.push({ label: 'Fuera', sec: 0 });

  const zoneRt = rtZ.map((b) => ({
    label: b.label,
    sec: 0,
  }));
  if (rtZ.length) zoneRt.push({ label: 'Fuera', sec: 0 });

  const zoneFcDays = {};
  const zoneRtDays = {};

  const curveRitmo = STREAM_SIZES.map(() => null);
  const curveFc = STREAM_SIZES.map(() => null);
  const curvePot = STREAM_SIZES.map(() => null);
  const curveCad = STREAM_SIZES.map(() => null);

  let ok = true;

  try {
    const start = periodStart(period);

    // No limitar a los 20 últimos entrenamientos: un periodo de 3 meses o
    // "Todo" debe incluir todos los registros disponibles.
    const acts = [];
    let last = null;
    for (;;) {
      const cs = [
        where('userId', '==', uid),
        orderBy('fecha', 'desc'),
        limit(100),
      ];

      if (start) cs.push(where('fecha', '>=', start));
      if (last) cs.push(startAfter(last));

      const snap = await getDocs(query(collection(db, 'entrenamientos'), ...cs));
      acts.push(
        ...snap.docs
          .map((d) => ({ id: d.id, ...d.data() }))
          .filter((w) => w.estado === 'completo' || (w.duracion || 0) > 0)
      );

      if (snap.size < 100) break;
      last = snap.docs[snap.docs.length - 1];
    }

    for (const chunk of chunksOf(acts, 4)) {
      await Promise.all(
        chunk.map(async (w) => {
          try {
            const rs = await getDoc(
              doc(db, 'entrenamientos', w.id, 'registros', 'data')
            );

            if (!rs.exists()) {
              return;
            }

            const pts = rs.data().puntos || [];

            if (!pts.length) {
              return;
            }

            const t0 = new Date(pts[0].timestamp).getTime();
            const chunks = STREAM_SIZES.map(() => ({}));

            for (let i = 1; i < pts.length; i++) {
              const dt =
                (
                  new Date(pts[i].timestamp) -
                  new Date(pts[i - 1].timestamp)
                ) / 1000;

              if (dt <= 0 || dt > 120) {
                continue;
              }

              const hr = Number(pts[i].frecuencia) || 0;
              const v = Number(pts[i].velocidad) || 0;
              const pot = Number(pts[i].potencia) || 0;
              const cad = Number(pts[i].cadencia) || 0;
              const dk = dayKey(new Date(pts[i].timestamp));

              if (hr > 0) {
                let matchedFc = false;
                for (let zi = 0; zi < fcZ.length; zi++) {
                  if (hr >= fcZ[zi].lo && hr <= fcZ[zi].hi) {
                    zoneFc[zi].sec += dt;

                    (
                      zoneFcDays[dk] ||
                      (zoneFcDays[dk] = new Array(fcZ.length).fill(0))
                    )[zi] += dt;

                    matchedFc = true;
                    break;
                  }
                }
                if (!matchedFc && fcZ.length) zoneFc[fcZ.length].sec += dt;
              }

              if (v > 0) {
                // `velocidad` se guarda en km/h; el ritmo debe expresarse en s/km.
                const pace = 3600 / v;

                let matchedRt = false;
                for (let zi = 0; zi < rtZ.length; zi++) {
                  if (pace >= rtZ[zi].lo && pace <= rtZ[zi].hi) {
                    zoneRt[zi].sec += dt;

                    (
                      zoneRtDays[dk] ||
                      (zoneRtDays[dk] = new Array(rtZ.length).fill(0))
                    )[zi] += dt;

                    matchedRt = true;
                    break;
                  }
                }
                if (!matchedRt && rtZ.length) zoneRt[rtZ.length].sec += dt;
              }

              const elapsed =
                (
                  new Date(pts[i].timestamp).getTime() - t0
                ) / 1000;

              for (let si = 0; si < STREAM_SIZES.length; si++) {
                const idx = Math.floor(elapsed / STREAM_SIZES[si]);

                const ck =
                  chunks[si][idx] ||
                  (chunks[si][idx] = {
                    t: 0,
                    d: 0,
                    hrS: 0,
                    hrT: 0,
                    pS: 0,
                    pT: 0,
                    cS: 0,
                    cT: 0,
                  });

                ck.t += dt;

                if (v > 0) {
                  // velocidad está en km/h; ck.d se acumula en metros.
                  ck.d += (v * dt) / 3.6;
                }

                if (hr > 0) {
                  ck.hrS += hr * dt;
                  ck.hrT += dt;
                }

                if (pot > 0) {
                  ck.pS += pot * dt;
                  ck.pT += dt;
                }

                if (cad > 0) {
                  ck.cS += cad * dt;
                  ck.cT += dt;
                }
              }
            }

            for (let si = 0; si < STREAM_SIZES.length; si++) {
              for (const idx of Object.keys(chunks[si])) {
                const ck = chunks[si][idx];

                if (ck.d > 0) {
                  const pace = ck.t / (ck.d / 1000);

                  if (
                    curveRitmo[si] == null ||
                    pace < curveRitmo[si]
                  ) {
                    curveRitmo[si] = pace;
                  }
                }

                if (ck.hrT > 0) {
                  const avg = ck.hrS / ck.hrT;

                  if (
                    curveFc[si] == null ||
                    avg > curveFc[si]
                  ) {
                    curveFc[si] = avg;
                  }
                }

                if (ck.pT > 0) {
                  const avg = ck.pS / ck.pT;

                  if (
                    curvePot[si] == null ||
                    avg > curvePot[si]
                  ) {
                    curvePot[si] = avg;
                  }
                }

                if (ck.cT > 0) {
                  const avg = ck.cS / ck.cT;

                  if (
                    curveCad[si] == null ||
                    avg > curveCad[si]
                  ) {
                    curveCad[si] = avg;
                  }
                }
              }
            }
          } catch (e) {
            console.warn(
              '[analytics] error procesando registros:',
              e.message
            );
          }
        })
      );
    }
  } catch (e) {
    ok = false;
    console.warn('[analytics] getStreamsStats falló:', e.message);
  }

  const val = {
    zoneFc,
    zoneRt,
    zoneFcDays,
    zoneRtDays,
    curveRitmo,
    curveFc,
    curvePot,
    curveCad,
    hasAny:
      zoneFc.some((z) => z.sec > 0) ||
      zoneRt.some((z) => z.sec > 0) ||
      curveRitmo.some((v) => v != null) ||
      curveFc.some((v) => v != null),
    ok,
  };

  streamMem[key] = {
    val,
    ts: Date.now(),
  };

  try {
    await AsyncStorage.setItem(storageKey, JSON.stringify({ v: CACHE_V, val }));
  } catch (e) {
    console.warn('[analytics] no se pudo guardar el snapshot de streams:', e.message);
  }

  return val;
}

export function buildZoneSeries(zoneDays, group, period, zoneLabels) {
  const start = periodStart(period);
  const buckets = new Map();

  for (const [k, arr] of Object.entries(zoneDays || {})) {
    const [y, m, dd] = k.split('-').map(Number);
    const date = new Date(y, m - 1, dd);

    if (start && date < start) {
      continue;
    }

    const gk = groupKey(date, group);

    if (!buckets.has(gk)) {
      buckets.set(gk, new Array(zoneLabels.length).fill(0));
    }

    const row = buckets.get(gk);

    for (let zi = 0; zi < Math.min(arr.length, row.length); zi++) {
      row[zi] += arr[zi];
    }
  }

  const keys = [...buckets.keys()].sort();

  return {
    labels: keys.map((k) => fmtBucketLabel(k, group)),
    matrix: keys.map((k) => buckets.get(k)),
  };
}

export function buildSeries(days, tipo, group, period, profile) {
  const start = periodStart(period);
  const buckets = new Map();

  const newB = () => ({
    rd: 0,
    pd: 0,
    rt: 0,
    pt: 0,
    load: 0,
    kcal: 0,
    steps: 0,
    sleepS: 0,
    sleepN: 0,
    rhrS: 0,
    rhrN: 0,
    fcMS: 0,
    fcMN: 0,
    fcMaxS: 0,
    fcMaxN: 0,
    hrAvgS: 0,
    hrAvgN: 0,
    vo2S: 0,
    vo2N: 0,
    hrvS: 0,
    hrvN: 0,
    wS: 0,
    wN: 0,
    spo2S: 0,
    spo2N: 0,
    scoreS: 0,
    scoreN: 0,
    maxDist: 0,
    maxDur: 0,
    bestPace: null,
    elevS: 0,
    potS: 0,
    potT: 0,
    bfS: 0,
    bfN: 0,
    bwS: 0,
    bwN: 0,
    ftpS: 0,
    ftpN: 0,
    lthrS: 0,
    lthrN: 0,
    umS: 0,
    umN: 0,
  });

  for (const [k, d] of Object.entries(days || {})) {
    const [y, m, dd] = k.split('-').map(Number);
    const date = new Date(y, m - 1, dd);

    if (start && date < start) {
      continue;
    }

    const gk = groupKey(date, group);
    let b = buckets.get(gk);

    if (!b) {
      b = newB();
      buckets.set(gk, b);
    }

    const eDist = d.count > 0 ? d.dist : (d.iDist || 0);
    const eDur = d.count > 0 ? d.dur : (d.iDur || 0);

    b.rd += eDist;
    b.rt += eDur;
    b.pd += d.planDist;
    b.pt += d.planDur;
    b.load += d.load;
    b.kcal += d.kcal;
    b.steps += d.steps;

    b.elevS += d.elev || 0;
    b.potS += d.potS || 0;
    b.potT += d.potT || 0;

    if (eDist > b.maxDist) {
      b.maxDist = eDist;
    }

    if (eDur > b.maxDur) {
      b.maxDur = eDur;
    }

    if (eDist >= 1 && eDur > 0) {
      const p = eDur / eDist;

      if (b.bestPace == null || p < b.bestPace) {
        b.bestPace = p;
      }
    }

    if (d.sleep != null) {
      b.sleepS += d.sleep;
      b.sleepN++;
    }

    if (d.rhr != null) {
      b.rhrS += d.rhr;
      b.rhrN++;
    }

    if (d.fcMax != null) {
      b.fcMaxS += d.fcMax;
      b.fcMaxN++;
    }

    if (d.avgHr != null) {
      b.hrAvgS += d.avgHr;
      b.hrAvgN++;
    }

    if (d.vo2 != null) {
      b.vo2S += d.vo2;
      b.vo2N++;
    }

    if (d.hrv != null) {
      b.hrvS += d.hrv;
      b.hrvN++;
    }

    if (d.weight != null) {
      b.wS += d.weight;
      b.wN++;
    }

    if (d.spo2 != null) {
      b.spo2S += d.spo2;
      b.spo2N++;
    }

    if (d.score != null) {
      b.scoreS += d.score;
      b.scoreN++;
    }

    if (d.bf != null) {
      b.bfS += d.bf;
      b.bfN++;
    }

    if (d.bw != null) {
      b.bwS += d.bw;
      b.bwN++;
    }

    if (d.ftp != null) {
      b.ftpS += d.ftp;
      b.ftpN++;
    }

    if (d.lthr != null) {
      b.lthrS += d.lthr;
      b.lthrN++;
    }

    if (d.umbral != null) {
      b.umS += d.umbral;
      b.umN++;
    }

    if (d.fcMN > 0) {
      b.fmS = (b.fmS || 0) + d.fcMS;
      b.fmN = (b.fmN || 0) + d.fcMN;
    }
  }

  const keys = [...buckets.keys()].sort();
  const avg = (s, n) => (n > 0 ? s / n : null);

  const heightM = profile?.altura
    ? profile.altura > 3
      ? profile.altura / 100
      : profile.altura
    : null;

  const values = [];
  const values2 = [];

  for (const k of keys) {
    const b = buckets.get(k);

    let v = null;
    let v2 = null;

    switch (tipo) {
      case 'distancia':
        v = b.rd;
        v2 = b.pd;
        break;

      case 'duracion':
        v = b.rt / 3600;
        v2 = b.pt / 3600;
        break;

      case 'rendimiento':
        v =
          b.pt > 0
            ? (b.rt / b.pt) * 100
            : b.pd > 0
              ? (b.rd / b.pd) * 100
              : null;
        break;

      case 'esfuerzo':
        v = b.load;
        break;

      case 'calorias':
        v = b.kcal;
        break;

      case 'pasos':
        v = b.steps;
        break;

      case 'elevacion':
        v = b.elevS;
        break;

      case 'potencia':
        v = b.potT > 0 ? b.potS / b.potT : null;
        break;

      case 'sueno':
        v = avg(b.sleepS, b.sleepN);
        break;

      case 'score':
        v = avg(b.scoreS, b.scoreN);
        break;

      case 'spo2':
        v = avg(b.spo2S, b.spo2N);
        break;

      case 'fcreposo':
        v = avg(b.rhrS, b.rhrN);
        break;

      case 'fcmax':
        v = avg(b.fcMaxS, b.fcMaxN);
        break;

      case 'fcmedia':
        v =
          b.fmN > 0
            ? b.fmS / b.fmN
            : b.hrAvgN > 0
              ? b.hrAvgS / b.hrAvgN
              : null;
        break;

      case 'vo2':
        v = avg(b.vo2S, b.vo2N);
        break;

      case 'vfc':
        v = avg(b.hrvS, b.hrvN);
        break;

      case 'peso':
        v = avg(b.wS, b.wN);
        break;

      case 'imc': {
        const w = avg(b.wS, b.wN);
        v = w != null && heightM
          ? w / (heightM * heightM)
          : null;
        break;
      }

      case 'masagrasa':
        v = avg(b.bfS, b.bfN);
        break;

      case 'masamuscular':
        v = null;
        break;

      case 'agua':
        v = avg(b.bwS, b.bwN);
        break;

      case 'ftp':
        v = avg(b.ftpS, b.ftpN);
        break;

      case 'lthr':
        v = avg(b.lthrS, b.lthrN);
        break;

      case 'ritmoumbral':
        v = avg(b.umS, b.umN);
        break;

      case 'records':
        v = b.maxDist;
        break;

      default:
        v = null;
    }

    values.push(v);
    values2.push(v2);
  }

  const labels = keys.map((k) => fmtBucketLabel(k, group));

  const hasData =
    values.some((v) => v != null && v > 0) ||
    values2.some((v) => v != null && v > 0);

  return {
    labels,
    values,
    values2,
    hasData,
  };
}

export function buildRecords(days) {
  let maxDist = 0;
  let maxDur = 0;
  let bestPace = null;

  const weekLoad = {};

  for (const [k, d] of Object.entries(days || {})) {
    const eDist = d.count > 0 ? d.dist : (d.iDist || 0);
    const eDur = d.count > 0 ? d.dur : (d.iDur || 0);

    if (eDist > maxDist) {
      maxDist = eDist;
    }

    if (eDur > maxDur) {
      maxDur = eDur;
    }

    if (eDist >= 1 && eDur > 0) {
      const p = eDur / eDist;

      if (bestPace == null || p < bestPace) {
        bestPace = p;
      }
    }

    const [y, m, dd] = k.split('-').map(Number);
    const wk = isoWeekKey(new Date(y, m - 1, dd));

    weekLoad[wk] = (weekLoad[wk] || 0) + d.load;
  }

  const maxWeekLoad = Math.max(0, ...Object.values(weekLoad));

  const fmtPace = (s) => {
    if (s == null) return '—';

    return `${Math.floor(s / 60)}:${pad(Math.round(s % 60))}/km`;
  };

  const fmtDur = (s) => {
    if (s <= 0) return '—';

    return `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m`;
  };

  return [
    {
      icon: 'route-outline',
      label: 'Mayor distancia',
      value: maxDist > 0 ? `${maxDist.toFixed(2)} km` : '—',
    },
    {
      icon: 'time-outline',
      label: 'Entreno más largo',
      value: maxDur > 0 ? fmtDur(maxDur) : '—',
    },
    {
      icon: 'speedometer-outline',
      label: 'Mejor ritmo medio (≥1 km)',
      value: fmtPace(bestPace),
    },
    {
      icon: 'flame-outline',
      label: 'Mayor carga semanal',
      value: maxWeekLoad > 0 ? `${Math.round(maxWeekLoad)}` : '—',
    },
  ];
}
