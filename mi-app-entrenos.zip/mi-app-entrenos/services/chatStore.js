// services/chatStore.js
/* ══════════════════════════════════════════════════════════════════════
   ALMACÉN LOCAL DEL CHAT (patrón "local-first" estilo WhatsApp)
   ──────────────────────────────────────────────────────────────────────
   Igual que WhatsApp, el chat NO descarga toda la conversación cada vez:
   · Los mensajes ya recibidos viven en ESTE almacén local persistente.
   · Al abrir el Tablón se pinta el almacén local AL INSTANTE (sin red).
   · Después se hace una sincronización INCREMENTAL: solo se piden al
     servidor los mensajes posteriores al último sincronizado
     (where createdAt > lastSync), que es baratísimo.
   · El historial más antiguo que el dispositivo nunca recibió se pagina
     hacia atrás por bloques de 50 (limit + where < oldestAt), nunca de
     golpe.
   · El servidor NO purga mensajes (historial permanente); los eventos
     "removed" del listener se ignoran igualmente por seguridad, así la
     copia local nunca desaparece del dispositivo.

   Backend: AsyncStorage (ya instalado, funciona sin rebuild ni Expo Go).
   El diseño es conmutables: todo el acceso pasa por estas funciones, así
   que si algún día se quiere SQLite basta con reimplementarlas aquí.
   Tope de seguridad: 4000 mensajes guardados (meses de chat de equipo);
   al superarlos se evictan los más antiguos SOLO del local.
   ══════════════════════════════════════════════════════════════════════ */
import AsyncStorage from '@react-native-async-storage/async-storage';

const K_MSGS = 'tj_chat_msgs_v1';
const K_META = 'tj_chat_meta_v1';
const K_OLD  = 'social_posts_cache_v1';   // caché antigua → se migra una vez
const MAX_MSGS = 4000;

let mem = null;            // { msgs: Map(id->msg), meta: {} }
let initPr = null;
let saveTimer = null;

function ordenAsc(list) {
  return list.slice().sort((a, b) => String(a.createdAt || '').localeCompare(String(b.createdAt || '')));
}

async function cargar() {
  const [rawM, rawMeta, rawOld] = await Promise.all([
    AsyncStorage.getItem(K_MSGS),
    AsyncStorage.getItem(K_META),
    AsyncStorage.getItem(K_OLD),
  ]);
  const meta = rawMeta ? safeJson(rawMeta, {}) : {};
  let msgs = rawM ? safeJson(rawM, []) : [];
  if (!Array.isArray(msgs)) msgs = [];
  // Migración única de la caché antigua (80 últimos posts) al almacén nuevo
  if (!meta.migradoV1) {
    meta.migradoV1 = true;
    if (!msgs.length && rawOld) {
      const old = safeJson(rawOld, null);
      if (old && Array.isArray(old.posts) && old.posts.length) {
        msgs = old.posts;
        if (!meta.oldestAt && msgs.length) meta.oldestAt = msgs[0].createdAt || null;
        if (meta.hasMore === undefined) meta.hasMore = true;
      }
    }
    if (!meta.lastSync && rawOld) {
      const old = safeJson(rawOld, null);
      if (old && old.lastCreatedAt) meta.lastSync = old.lastCreatedAt;
    }
  }
  const map = new Map();
  for (const m of msgs) if (m && m.id) map.set(m.id, m);
  mem = { msgs: map, meta };
  persist();
  return mem;
}

function safeJson(s, d) {
  try { const v = JSON.parse(s); return v == null ? d : v; } catch (e) { return d; }
}

export async function chatStoreInit() {
  if (mem) return mem;
  if (!initPr) initPr = cargar().catch((e) => { console.warn('[chatStore] init:', e && e.message); mem = { msgs: new Map(), meta: {} }; return mem; });
  return initPr;
}

/** Todos los mensajes locales, cronológicos ascendentes. */
export async function chatStoreAll() {
  await chatStoreInit();
  return ordenAsc([...mem.msgs.values()]);
}

/** Upsert de mensajes (por id). Acepta uno o varios. */
export async function chatStorePut(list) {
  await chatStoreInit();
  const arr = Array.isArray(list) ? list : [list];
  for (const m of arr) {
    if (!m || !m.id) continue;
    const limpio = { ...m };
    delete limpio.expiresAt;           // el Timestamp de Firestore no se serializa
    mem.msgs.set(m.id, limpio);
  }
  if (mem.msgs.size > MAX_MSGS) {
    const todos = ordenAsc([...mem.msgs.values()]).slice(-MAX_MSGS);
    mem.msgs = new Map(todos.map((m) => [m.id, m]));
  }
  persist();
}

/** Metadatos de sincronización: { lastSync, oldestAt, hasMore, migradoV1 } */
export async function chatStoreMeta() {
  await chatStoreInit();
  return { ...mem.meta };
}

export async function chatStoreSetMeta(patch) {
  await chatStoreInit();
  mem.meta = { ...mem.meta, ...patch };
  persist();
}

/** Escritura diferida (400 ms): una ráfaga del listener = 1 sola escritura. */
function persist() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      const msgs = ordenAsc([...mem.msgs.values()]);
      AsyncStorage.setItem(K_MSGS, JSON.stringify(msgs));
      AsyncStorage.setItem(K_META, JSON.stringify(mem.meta));
    } catch (e) { console.warn('[chatStore] persist:', e && e.message); }
  }, 400);
}
