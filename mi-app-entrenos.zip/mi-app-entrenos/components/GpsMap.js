// components/GpsMap.js
import React, { useMemo, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, useColorScheme } from 'react-native';
import { WebView } from 'react-native-webview';
import { Ionicons } from '@expo/vector-icons';
import { getThemeColors, useAppSettings } from '../services/appSettings';

const MAX_MAP_POINTS = 5000; // Leaflet maneja esto sin problema

function buildData(registros, vueltas) {
  const pts = (registros || []).filter(p => p.lat != null && p.lon != null);
  if (pts.length < 2) return null;

  // Decimación inteligente: si hay más de MAX_MAP_POINTS, reducir uniformemente
  // pero siempre incluir el primero y el último para que la ruta esté completa
  let coords;
  if (pts.length <= MAX_MAP_POINTS) {
    coords = pts.map(p => [
      Number(p.lat),
      Number(p.lon),
      Number(p.distancia ?? 0),
    ]);
  } else {
    const step = (pts.length - 2) / (MAX_MAP_POINTS - 2);
    coords = [
      [Number(pts[0].lat), Number(pts[0].lon), Number(pts[0].distancia ?? 0)],
    ];
    for (let i = 1; i < pts.length - 1; i++) {
      if (Math.floor(i / step) !== Math.floor((i - 1) / step)) {
        coords.push([
          Number(pts[i].lat),
          Number(pts[i].lon),
          Number(pts[i].distancia ?? 0),
        ]);
      }
    }
    coords.push([
      Number(pts[pts.length - 1].lat),
      Number(pts[pts.length - 1].lon),
      Number(pts[pts.length - 1].distancia ?? 0),
    ]);
  }

  let acc = 0;
  const laps = (vueltas || [])
    .filter(v => v && v.distancia != null)
    .map((v, i) => {
      acc += Number(v.distancia);
      return { n: i + 1, d: acc };
    });

  return { coords, laps, start: coords[0], end: coords[coords.length - 1] };
}

function buildHtml(data) {
  const json = JSON.stringify(data);
  return `<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
  html,body{margin:0;padding:0;height:100%;background:#0d1b2a;overscroll-behavior:none;}
  #map{width:100%;height:100%;touch-action:none;}
  .dot-start{width:14px;height:14px;background:#2f9e44;border:3px solid #fff;border-radius:50%;box-shadow:0 1px 4px rgba(0,0,0,.6);}
  .dot-end{width:16px;height:16px;border:2px solid #fff;border-radius:50%;box-shadow:0 1px 4px rgba(0,0,0,.6);
    background:repeating-conic-gradient(#141414 0% 25%, #ffffff 0% 50%);background-size:8px 8px;}
  .lapctrl button{width:34px;height:34px;background:#fff;border:none;border-radius:4px;font-size:18px;line-height:32px;cursor:pointer;color:#111;}
  .lapctrl button.off{color:#9aa5b1;}
  .lap-num{background:#111;color:#fff;border-radius:50%;width:18px;height:18px;font:11px/18px sans-serif;text-align:center;border:2px solid #fff;box-shadow:0 1px 3px rgba(0,0,0,.5);}
</style>
</head>
<body>
<div id="map"></div>
<script>
  var DATA = ${json};

  // zoomSnap: 0  → zoom fraccional/continuo (sin niveles, sigue al dedo)
  // zoomDelta: 0.5 → pasos finos con doble toque / botones
  // maxNativeZoom 19 + maxZoom 22 → zoom suave más allá del tile nativo (reescalado)
  var map = L.map('map', {
    zoomControl: true,
    attributionControl: true,
    zoomSnap: 0,
    zoomDelta: 0.5,
    zoomAnimation: true,
    fadeAnimation: true,
    markerZoomAnimation: true,
    bounceAtZoomLimits: false,
    minZoom: 2,
    maxZoom: 22,
    touchZoom: true,
    doubleClickZoom: true,
    boxZoom: false,
    keyboard: false
  });

  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxNativeZoom: 19,
    maxZoom: 22,
    attribution: '&copy; OpenStreetMap contributors.'
  }).addTo(map);

  var pts = DATA.coords.map(function(c){ return [c[0], c[1]]; });

  // Trazo más fino (weight 3 en lugar de 6)
  var line = L.polyline(pts, {
    color: '#e03131',
    weight: 3,
    opacity: 0.9,
    lineJoin: 'round',
    lineCap: 'round',
    smoothFactor: 1,
    interactive: false
  }).addTo(map);

  map.fitBounds(line.getBounds(), { padding: [14, 14] });

  L.marker(DATA.start.slice(0, 2), {
    interactive: false,
    icon: L.divIcon({ className: '', html: '<div class="dot-start"></div>', iconSize: [20, 20], iconAnchor: [10, 10] })
  }).addTo(map);

  L.marker(DATA.end.slice(0, 2), {
    interactive: false,
    icon: L.divIcon({ className: '', html: '<div class="dot-end"></div>', iconSize: [20, 20], iconAnchor: [10, 10] })
  }).addTo(map);

  var lapLayer = L.layerGroup();
  function nearest(d){
    var best = DATA.coords[0], bd = 1e9;
    for (var i = 0; i < DATA.coords.length; i++){
      var dd = Math.abs(DATA.coords[i][2] - d);
      if (dd < bd){ bd = dd; best = DATA.coords[i]; }
    }
    return best;
  }
  DATA.laps.forEach(function(l){
    var c = nearest(l.d);
    L.marker([c[0], c[1]], {
      icon: L.divIcon({ className: '', html: '<div class="lap-num">' + l.n + '</div>', iconSize: [22, 22], iconAnchor: [11, 11] })
    }).bindTooltip('Vuelta ' + l.n).addTo(lapLayer);
  });

  var lapsOn = false;
  var ctrl = L.control({ position: 'topright' });
  ctrl.onAdd = function(){
    var div = L.DomUtil.create('div', 'leaflet-bar lapctrl');
    var btn = L.DomUtil.create('button', 'off');
    btn.innerHTML = '&#9873;';
    btn.title = 'Mostrar / ocultar vueltas';
    btn.onclick = function(e){
      L.DomEvent.stop(e);
      lapsOn = !lapsOn;
      if (lapsOn){ lapLayer.addTo(map); btn.classList.remove('off'); }
      else { map.removeLayer(lapLayer); btn.classList.add('off'); }
    };
    div.appendChild(btn);
    L.DomEvent.disableClickPropagation(div);
    return div;
  };
  ctrl.addTo(map);

  setTimeout(function(){ map.invalidateSize(); }, 200);
</script>
</body>
</html>`;
}

export default function GpsMap({
  registros,
  vueltas,
  onInteractionStart,
  onInteractionEnd,
}) {
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const [loaded, setLoaded] = useState(false);
  const data = useMemo(() => buildData(registros, vueltas), [registros, vueltas]);
  const html = useMemo(() => (data ? buildHtml(data) : null), [data]);

  if (!data) {
    return (
      <View style={[st.noGps, { backgroundColor: theme.card, borderColor: theme.border }]}>
        <Ionicons name="map-outline" size={30} color={theme.muted} />
        <Text style={[st.noGpsTitle, { color: theme.text }]}>Esta actividad no tiene datos de GPS</Text>
        <Text style={[st.noGpsText, { color: theme.muted }]}>
          Intervals.icu no ha proporcionado coordenadas para esta actividad.
          Para ver el mapa, importa el archivo .fit original desde Ajustes → Sincronizar .fit.
        </Text>
      </View>
    );
  }

  const handleStart = () => onInteractionStart?.();
  const handleEnd   = () => onInteractionEnd?.();

  return (
    <View style={st.wrap}>
      {!loaded && (
        <View style={st.loading}>
          <ActivityIndicator color="#4A90E2" />
        </View>
      )}
      <View
        style={st.webviewHost}
        onTouchStart={handleStart}
        onTouchEnd={handleEnd}
        onTouchCancel={handleEnd}
      >
        <WebView
          source={{ html }}
          style={st.webview}
          originWhitelist={['*']}
          javaScriptEnabled
          domStorageEnabled
          scrollEnabled={false}
          bounces={false}
          nestedScrollEnabled={true}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          onLoadEnd={() => setLoaded(true)}
        />
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  wrap: {
    height: 360, borderRadius: 12, overflow: 'hidden',
    borderWidth: 1, borderColor: '#1E3048',
    marginTop: 4, marginBottom: 14, backgroundColor: '#0d1b2a',
  },
  webviewHost: { flex: 1, backgroundColor: '#0d1b2a' },
  webview:     { flex: 1, backgroundColor: '#0d1b2a' },
  loading: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    alignItems: 'center', justifyContent: 'center', zIndex: 2,
  },
  noGps: {
    marginTop: 4, marginBottom: 14, padding: 18,
    backgroundColor: '#162032', borderRadius: 12,
    borderWidth: 1, borderColor: '#1E3048',
    alignItems: 'center', gap: 8,
  },
  noGpsTitle: { color: '#fff', fontSize: 14, fontWeight: '700' },
  noGpsText:  { color: '#8FA8C8', fontSize: 12, lineHeight: 18, textAlign: 'center' },
});
