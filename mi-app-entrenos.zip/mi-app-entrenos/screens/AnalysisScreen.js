// screens/AnalysisScreen.js
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Modal, ScrollView, StyleSheet, Text, TouchableOpacity, View, Vibration, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from '../firebaseConfig';
import { getCachedProfile } from '../services/profileCache';
import { getEntrenamientos } from '../services/chartCache';
import { getSettingsSnapshot, getThemeColors, useAppSettings } from '../services/appSettings';
import { getAnalyticsDays, invalidateAnalytics, buildDaysFromWorkouts, buildSeries, buildRecords, getStreamsStats, STREAM_LABELS } from '../services/analyticsEngine';

const NAVY='#0D1B2A', CARD='#162032', BLUE='#4A90E2', BORDER='#1E3048', WHITE='#E8EDF5', GREEN='#2DB37A';
const STREAM_TYPES = ['zonasfc','zonasritmo','zonaspot','curvaritmo','curvafc','curvapot','curvacad'];
const CATALOG = [
  { section: 'Entrenamiento', items: [
    { tipo:'rendimiento', label:'Rendimiento', unit:'%' },
    { tipo:'distancia', label:'Distancia', unit:'km' },
    { tipo:'duracion',   label:'Duración', unit:'h' },
    { tipo:'esfuerzo', label:'Esfuerzo', unit:'carga' },
    { tipo:'fcmedia', label:'FC media', unit:'ppm' },
    { tipo:'elevacion', label:'Elevación', unit:'m' },
    { tipo:'potencia', label:'Potencia', unit:'W' },
  ]},
  { section: 'Zonas', items: [
    { tipo:'zonasfc', label:'Frecuencia cardíaca', unit:'min' },
    { tipo:'zonasritmo', label:'Ritmo', unit:'min' },
    { tipo:'zonaspot', label:'Potencia', unit:'min' },
  ]},
  { section: 'Curvas', items: [
    { tipo:'curvaritmo', label:'Curva de ritmo', unit:'/km' },
    { tipo:'curvafc',   label:'Curva de FC', unit:'ppm' },
    { tipo:'curvapot', label:'Curva de potencia', unit:'W' },
    { tipo:'curvacad', label:'Curva de cadencia', unit:'rpm' },
  ]},
  { section: 'Récords',  items: [ { tipo:'records', label:'Mejores marcas', unit:'' } ]},
  { section: 'Métricas corporales', items: [
    { tipo:'sueno',  label:'Sueño', unit:'h' },
    { tipo:'score', label:'Puntuación de sueño', unit:'' },
    { tipo:'fcmax', label:'FC máxima', unit:'ppm' },
    { tipo:'fcreposo', label:'FC en reposo', unit:'ppm' },
    { tipo:'vo2', label:'VO2 máx', unit:'' },
    { tipo:'ftp', label:'FTP', unit:'W' },
    { tipo:'lthr', label:'LTHR', unit:'ppm' },
    { tipo:'ritmoumbral', label:'Ritmo umbral', unit:'/km' },
    { tipo:'calorias', label:'Calorías', unit:'kcal' },
    { tipo:'vfc', label:'VFC', unit:'ms' },
    { tipo:'spo2', label:'SpO2', unit:'%' },
    { tipo:'pasos', label:'Pasos', unit:'' },
  ]},
];
const GROUPS = ['Diario', 'Semanal', 'Mensual', 'Año'];
const GROUP_KEY = { 'Diario':'diario', 'Semanal':'semanal', 'Mensual':'mensual', 'Año':'anio' };
const PERIODS = ['Últimos 30 días', 'Últimos 3 meses', 'Últimos 6 meses', 'Último año', 'Últimos 2 años', 'Todo'];
const PERIOD_KEY = { 'Últimos 30 días':'30d', 'Últimos 3 meses':'3m', 'Últimos 6 meses':'6m', 'Último año':'1y', 'Últimos 2 años':'2y', 'Todo':'todo' };
const AVAILABLE_TYPES = new Set(CATALOG.flatMap((section) => section.items.map((item) => item.tipo)));
const EN_LABELS = {
  rendimiento:'Performance', distancia:'Distance', duracion:'Duration', esfuerzo:'Effort', fcmedia:'Average HR', elevacion:'Elevation', potencia:'Power',
  zonasfc:'Heart-rate zones', zonasritmo:'Pace zones', zonaspot:'Power zones', curvaritmo:'Pace curve', curvafc:'Heart-rate curve', curvapot:'Power curve', curvacad:'Cadence curve',
  records:'Best marks', sueno:'Sleep', score:'Sleep score', fcmax:'Maximum HR', fcreposo:'Resting HR', vo2:'VO2 max', ftp:'FTP', lthr:'LTHR', ritmoumbral:'Threshold pace', calorias:'Calories', vfc:'HRV', spo2:'SpO2', pasos:'Steps',
};
const EN_SECTIONS = { Entrenamiento:'Training', Zonas:'Zones', Curvas:'Curves', Récords:'Records', 'Métricas corporales':'Body metrics' };
const labelOf = (tipo) => { for (const s of CATALOG) { const it = s.items.find(i => i.tipo === tipo); if (it) return getSettingsSnapshot().language === 'en' ? (EN_LABELS[tipo] || it.label) : it.label; } return tipo; };
const text = (es, en) => getSettingsSnapshot().language === 'en' ? en : es;
const fmtTimeSec = (s) => { if (!s || s <= 0) return '0m'; const mins = Math.floor(s / 60); const sec = Math.round(s % 60); if (mins < 60) return `${mins}m ${sec}s`; return `${Math.floor(mins / 60)}h ${mins % 60}m`; };

function BarChart({ labels, values, values2, height = 180, fmt, theme }) {
  const max = Math.max(...values.map(v => v || 0), ...values2.map(v => v || 0), 0.001);
  const stepLbl = Math.max(1, Math.ceil(labels.length / 6));
  const ticks = [max, (max * 2) / 3, max / 3, 0];
  const fmtTick = (t) => (max >= 100 ? String(Math.round(t)) : String(Math.round(t * 10) / 10));
  return (
    <View>
      <View style={{ flexDirection: 'row' }}>
        <View style={[st.yAxis, { height }]}>
          {ticks.map((t, i) => ( <Text key={i} style={[st.yLabel, { color: theme?.muted }]}>{fmtTick(t)}</Text> ))}
        </View>
        <View style={[{ height, flex: 1 }, st.chartArea]}>
          {ticks.map((v, i) => ( <View key={i} style={[st.gridLine, { top: (i / Math.max(ticks.length - 1, 1)) * height }]} /> ))}
          <View style={st.barsRow}>
            {labels.map((_, i) => (
              <View key={i} style={st.barCol}>
                {(values2[i] || 0) > 0 && <View style={[st.bar, { height: ((values2[i] || 0) / max) * height, backgroundColor: theme?.background === '#F4F7FB' ? '#9AA7B8' : WHITE, opacity: theme?.background === '#F4F7FB' ? 0.78 : 0.5 }]} />}
                {(values[i] || 0) > 0 && <View style={[st.bar, { height: ((values[i] || 0) / max) * height, backgroundColor: BLUE }]} />}
              </View>
            ))}
          </View>
        </View>
      </View>
      <View style={[st.labelsRow, { marginLeft: 40 }]}>
        {labels.map((l, i) => ( <Text key={i} style={[st.labelX, { color: theme?.muted }]} numberOfLines={1}>{i % stepLbl === 0 ? l : ''}</Text> ))}
      </View>
      {fmt && <Text style={st.fmtHint}>{fmt}</Text>}
    </View>
  );
}
function compactZoneLabel(label, prefix, index) {
  const text = String(label || '').trim();
  const match = text.match(/^([ZR]\d+(?:[A-Z])?(?:\+)?)/i);
  return match ? match[1].toUpperCase() : (text || `${prefix}${index + 1}`);
}

function ZoneRows({ zones, prefix = 'Z', theme }) {
  const total = zones.reduce((a, z) => a + z.sec, 0);
  if (total <= 0) return <View style={st.noData}><Text style={st.noDataText}>{text('Sin datos de zonas en este período (requiere entrenos completados con registros).', 'No zone data for this period (completed workouts with records are required).')}</Text></View>;
  return (
    <View style={st.recordsBox}>
      {zones.map((z, i) => {
        const p = Math.round((z.sec / total) * 100);
        const outside = z.label === 'Fuera';
        const label = outside ? 'Fuera' : compactZoneLabel(z.label, prefix, i);
        return (
          <View key={i} style={st.recordRow}>
            <Text style={[st.zoneName, { color: theme?.text }]}>{label}</Text>
            <View style={[st.zoneBarBg, { backgroundColor: theme?.input }]}><View style={[st.zoneBar, outside && st.zoneBarOutside, { width: `${Math.min(p, 100)}%` }]} /></View>
            <Text style={[st.recordValue, { color: theme?.text }]}>{fmtTimeSec(z.sec)}</Text>
            <Text style={[st.zonePct, { color: theme?.muted }]}>{p}%</Text>
          </View>
        );
      })}
    </View>
  );
}
export default function AnalysisScreen() {
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const uid = auth.currentUser?.uid;
  const [charts, setCharts] = useState([]);
  const [days, setDays] = useState(null);
  const [daysError, setDaysError] = useState(false);
  const [profile, setProfile] = useState(null);
  const [streams, setStreams] = useState({});
  const [loading, setLoading] = useState(true);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [config, setConfig] = useState(null);
  const [moveId, setMoveId] = useState(null);
  const hydrated = useRef(false);
  const lastSavedJson = useRef(null);
  const saveWarned = useRef(false);
  const forceStreamsRef = useRef(false);

  const loadAll = useCallback(async (force = false) => {
    if (!uid) return;
    setLoading(true); setDaysError(false);
    if (force) {
      invalidateAnalytics(uid);
      forceStreamsRef.current = true;
      setStreams({}); // refresca también zonas/curvas
    }
    try {
      let loaded = null;
      try {
        const snap = await getDoc(doc(db, 'analysis', uid));
        if (snap.exists() && Array.isArray(snap.data().charts)) loaded = snap.data().charts;
      } catch (e) {}
      if (!loaded) {
        const raw = await AsyncStorage.getItem(`analysisCharts_${uid}`);
        if (raw) loaded = JSON.parse(raw);
      }
      const arr = (Array.isArray(loaded) ? loaded : [])
        .filter((chart) => AVAILABLE_TYPES.has(chart.tipo));
      setCharts(arr);
      lastSavedJson.current = JSON.stringify(arr);
      hydrated.current = true;
      const cachedProfile = await getCachedProfile(uid);
      let p = cachedProfile;
      if (force || !cachedProfile) {
        try {
          const profileSnap = await getDoc(doc(db, 'perfiles', uid));
          if (profileSnap.exists()) p = { ...(cachedProfile || {}), ...profileSnap.data() };
        } catch (e) {
          // Si no hay red, se conserva el perfil cacheado como respaldo.
        }
      }
      setProfile(p);
      const fetchedDays = await getAnalyticsDays(uid, { force });
      const sharedWorkouts = force ? null : getEntrenamientos(uid);
      const sharedDays = buildDaysFromWorkouts(sharedWorkouts);
      const d = Object.keys(sharedDays).length > 0
        ? { ...fetchedDays, ...sharedDays }
        : fetchedDays;
      console.log('[analysis] datos:', {
        uid,
        sharedWorkouts: sharedWorkouts?.length || 0,
        fetchedDays: Object.keys(fetchedDays || {}).length,
        finalDays: Object.keys(d || {}).length,
      });
      setDays(d);
      if (!d || Object.keys(d).length === 0) setDaysError(true);
    } catch (e) {
      console.warn('[analysis] loadAll falló:', e.message);
      setDaysError(true);
      hydrated.current = true;
      lastSavedJson.current = null;
    } finally { setLoading(false); }
  }, [uid]);
  useFocusEffect(useCallback(() => { loadAll(false); }, [loadAll]));

  useEffect(() => {
    if (!uid || !hydrated.current) return;
    const json = JSON.stringify(charts);
    if (json === lastSavedJson.current) return;
    lastSavedJson.current = json;
    AsyncStorage.setItem(`analysisCharts_${uid}`, json).catch(() => {});
    setDoc(doc(db, 'analysis', uid), { charts }, { merge: true }).catch(e => {
      console.warn('[analysis] no se pudo guardar en Firestore:', e.message);
      if (!saveWarned.current) {
        saveWarned.current = true;
        Alert.alert('Guardado en la nube no disponible', 'Tus gráficas se guardan solo en este dispositivo: ' + e.message + '\n\nRevisa en Firebase las reglas de Firestore (colección "analysis") y tu conexión.');
      }
    });
  }, [charts, uid]);

  useEffect(() => {
    if (!uid || loading || !profile || !days) return;
    const forceStreams = forceStreamsRef.current;
    forceStreamsRef.current = false;
    const needed = [...new Set(charts.filter(c => STREAM_TYPES.includes(c.tipo)).map(c => c.period))];
    needed.forEach(period => {
      if (streams[period] !== undefined) return;
      setStreams(s => ({ ...s, [period]: null }));
      getStreamsStats(uid, period, profile, { force: forceStreams })
        .then(val => setStreams(s => ({ ...s, [period]: val })))
        .catch(() => setStreams(s => ({ ...s, [period]: { zoneFc: [], zoneRt: [], zoneFcDays: {}, zoneRtDays: {}, curveRitmo: [null,null,null,null,null,null,null,null,null], curveFc: [null,null,null,null,null,null,null,null,null], curvePot: [null,null,null,null,null,null,null,null,null], curveCad: [null,null,null,null,null,null,null,null,null], hasAny: false, ok: false } })));
    });
  }, [charts, uid, profile, days, streams]);

  const saveConfig = () => {
    if (!config) return;
    if (config.id) setCharts(cs => cs.map(c => (c.id === config.id ? { ...c, group: config.group, period: config.period } : c)));
    else setCharts(cs => [...cs, { id: Date.now(), tipo: config.tipo, group: config.group, period: config.period }]);
    setConfig(null);
  };
  const deleteChart = (id) => setCharts(cs => cs.filter(c => c.id !== id));
  const moveChart = (targetId) => {
    setCharts(cs => {
      const from = cs.findIndex(c => c.id === moveId);
      const target = cs.findIndex(c => c.id === targetId);
      if (from < 0 || target < 0 || from === target) return cs;
      const [item] = cs.splice(from, 1);
      // Si el destino estaba debajo, se inserta después de él; si estaba
      // encima, se inserta antes. Así ambos sentidos cambian de posición.
      const insertAt = target;
      cs.splice(insertAt, 0, item);
      return [...cs];
    });
    setMoveId(null);
  };
  const moveEnd = () => {
    setCharts(cs => {
      const from = cs.findIndex(c => c.id === moveId);
      if (from < 0) return cs;
      const [item] = cs.splice(from, 1);
      return [...cs, item];
    });
    setMoveId(null);
  };

  const renderBody = (c) => {
    if (c.tipo === 'records') {
      return (
        <View style={st.recordsBox}>
          {(days ? buildRecords(days) : []).map((r, i) => (
            <View key={i} style={st.recordRow}>
              <Ionicons name={r.icon} size={16} color={BLUE} />
              <Text style={st.recordLabel}>{r.label}</Text>
              <Text style={st.recordValue}>{r.value}</Text>
            </View>
          ))}
        </View>
      );
    }
    if (STREAM_TYPES.includes(c.tipo)) {
      const s = streams[c.period];
      if (s === undefined || s === null) return <View style={st.noData}><ActivityIndicator color={BLUE} /><Text style={st.noDataText}>Cargando registros…</Text></View>;
      if (s.ok === false) return <View style={st.noData}><Text style={st.noDataText}>{text('Error al cargar registros. Vuelve a entrar o refresca.', 'Error loading records. Re-enter or refresh.')}</Text></View>;
      if (c.tipo === 'zonasfc') return <ZoneRows zones={s.zoneFc} prefix="Z" theme={theme} />;
      if (c.tipo === 'zonasritmo') return <ZoneRows zones={s.zoneRt} prefix="R" theme={theme} />;
      if (c.tipo === 'zonaspot') return <View style={st.noData}><Text style={st.noDataText}>Sin datos de potencia en tus registros.</Text></View>;
      const vals = (c.tipo === 'curvaritmo' ? s.curveRitmo : c.tipo === 'curvafc' ? s.curveFc : c.tipo === 'curvapot' ? s.curvePot : s.curveCad) || [];
      const clean = vals.map(v => (v == null ? 0 : v));
      if (!clean.some(v => v > 0)) return <View style={st.noData}><Text style={st.noDataText}>{text('Sin registros con esos datos en el período elegido.', 'No records with these data in the selected period.')}</Text></View>;
      return <BarChart labels={STREAM_LABELS} values={clean} values2={[]} theme={theme} fmt={c.tipo === 'curvaritmo' ? text('Seg/km por ventana (menor = mejor)', 'Sec/km per window (lower = better)') : undefined} />;
    }
    if (!days) {
      return (
        <View style={st.noData}>
          <Text style={st.noDataText}>{daysError ? text('Error cargando el historial.', 'Error loading history.') : text('Cargando…', 'Loading…')}</Text>
          {daysError && <TouchableOpacity style={st.retryBtn} onPress={() => loadAll(true)}><Text style={st.retryText}>{text('Reintentar', 'Retry')}</Text></TouchableOpacity>}
        </View>
      );
    }
    const series = buildSeries(days, c.tipo, c.group, c.period, profile);
    if (!series.hasData) return <View style={st.noData}><Text style={st.noDataText}>{text('Sin datos disponibles todavía para esta gráfica.', 'No data available for this chart yet.')}</Text></View>;
    return <BarChart labels={series.labels} values={series.values} values2={series.values2} theme={theme} />;
  };
  const preview = config ? { tipo: config.tipo, group: config.group, period: config.period } : null;

  return (
      <View style={[st.container, { backgroundColor: theme.background }]}>
      <View style={[st.header, { borderBottomColor: theme.border }]}>
        <Text style={[st.headerTitle, { color: theme.text }]}>{text('Análisis', 'Analysis')}</Text>
        <TouchableOpacity style={st.addBtn} onPress={() => loadAll(true)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Ionicons name="refresh" size={22} color="#8FA8C8" />
        </TouchableOpacity>
        <TouchableOpacity style={st.addBtn} onPress={() => setPickerOpen(true)}>
          <Ionicons name="add-circle-outline" size={26} color={BLUE} />
        </TouchableOpacity>
      </View>
      {moveId != null && (
        <View style={st.moveBanner}>
          <Ionicons name="move-outline" size={16} color="#fff" />
          <Text style={st.moveBannerText} numberOfLines={1}>Moviendo gráfica: toca destino o Cancelar</Text>
          <TouchableOpacity onPress={() => setMoveId(null)}><Text style={st.moveCancel}>Cancelar</Text></TouchableOpacity>
        </View>
      )}
      {loading ? (
        <View style={st.center}><ActivityIndicator color={BLUE} /><Text style={st.centerText}>Cargando historial…</Text></View>
      ) : (
        <ScrollView contentContainerStyle={st.scroll}>
          {charts.length === 0 && moveId == null && (
            <View style={st.empty}>
              <Ionicons name="bar-chart-outline" size={40} color="#2A4060" />
            <Text style={st.emptyText}>{text('Aún no tienes gráficas. Pulsa + para añadir la primera.', 'You have no charts yet. Tap + to add the first one.')}</Text>
            </View>
          )}
          {charts.map(c => (
            <View key={c.id} style={[st.card, { backgroundColor: theme.card, borderColor: theme.border }, moveId === c.id && st.cardMoving]}>
              <View style={st.cardHeader}>
              <Text style={[st.cardTitle, { color: theme.text }]}>{labelOf(c.tipo)}</Text>
                <View style={{ flex: 1 }} />
                {moveId == null && (
                  <TouchableOpacity onPress={() => deleteChart(c.id)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                    <Ionicons name="close" size={18} color="#8FA8C8" />
                  </TouchableOpacity>
                )}
              </View>
              <TouchableOpacity
                activeOpacity={0.85}
                onLongPress={() => { Vibration.vibrate(10); setMoveId(c.id); }}
                onPress={() => { if (moveId != null) { if (moveId !== c.id) moveChart(c.id); } else if (c.tipo !== 'records') setConfig({ id: c.id, tipo: c.tipo, group: c.group, period: c.period }); }}
              >
                {renderBody(c)}
              </TouchableOpacity>
            </View>
          ))}
          <TouchableOpacity style={st.bottomAdd} onPress={() => (moveId != null ? moveEnd() : setPickerOpen(true))}>
            <Ionicons name="add" size={20} color={BLUE} />
            <Text style={st.bottomAddText}>{moveId != null ? text('Mover al final', 'Move to end') : text('Añadir Gráfico', 'Add chart')}</Text>
          </TouchableOpacity>
        </ScrollView>
      )}
      <Modal visible={pickerOpen} transparent animationType="fade" onRequestClose={() => setPickerOpen(false)}>
        <TouchableOpacity style={st.overlay} activeOpacity={1} onPress={() => setPickerOpen(false)}>
          <View style={[st.pickerBox, { backgroundColor: theme.card }]}>
            <ScrollView style={{ maxHeight: '70%' }}>
              {CATALOG.map(s => (
                <View key={s.section}>
                  <Text style={[st.sectionTitle, { color: theme.muted }]}>{getSettingsSnapshot().language === 'en' ? (EN_SECTIONS[s.section] || s.section) : s.section}</Text>
                  {s.items.map(it => {
                    const added = charts.some(c => c.tipo === it.tipo);
                    return (
                      <TouchableOpacity key={it.tipo} style={[st.pickerItem, { borderBottomColor: theme.border }]} onPress={() => { setPickerOpen(false); setConfig({ id: null, tipo: it.tipo, group: 'semanal', period: '3m' }); }}>
                        <Text style={[st.pickerItemText, { color: theme.text }]}>{labelOf(it.tipo)}</Text>
                        {added && <Ionicons name="checkmark-circle" size={18} color={GREEN} />}
                      </TouchableOpacity>
                    );
                  })}
                </View>
              ))}
            </ScrollView>
          </View>
        </TouchableOpacity>
      </Modal>
      <Modal visible={!!config} transparent animationType="slide" onRequestClose={() => setConfig(null)}>
        <View style={[st.configSheet, { backgroundColor: theme.background }]}>
          <View style={[st.configHeader, { borderBottomColor: theme.border }]}>
            <TouchableOpacity onPress={() => setConfig(null)}><Ionicons name="close" size={24} color="#8FA8C8" /></TouchableOpacity>
            <Text style={[st.configTitle, { color: theme.text }]}>{config ? labelOf(config.tipo) : ''}</Text>
            <TouchableOpacity onPress={saveConfig}><Text style={st.configSave}>{text('Guardar', 'Save')}</Text></TouchableOpacity>
          </View>
          {config && (
            <ScrollView contentContainerStyle={st.configScroll}>
              <View style={[st.card, { backgroundColor: theme.card, borderColor: theme.border }]}>{renderBody(preview)}</View>
              <View style={[st.configRow, { backgroundColor: theme.card, borderColor: theme.border }]}>
                <Ionicons name="calendar-outline" size={20} color="#8FA8C8" />
                <Text style={[st.configLabel, { color: theme.text }]}>{text('Agrupar por', 'Group by')}</Text>
                <View style={{ flex: 1 }} />
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={st.chipRow}>
                  {GROUPS.map(g => (
                    <TouchableOpacity key={g} style={[st.chip, { backgroundColor: theme.input, borderColor: theme.border }, config.group === GROUP_KEY[g] && st.chipActive]} onPress={() => setConfig(c => ({ ...c, group: GROUP_KEY[g] }))}>
                      <Text style={[st.chipText, { color: config.group === GROUP_KEY[g] ? theme.text : theme.muted }, config.group === GROUP_KEY[g] && { fontWeight: '700' }]}>{text(g, { Diario:'Daily', Semanal:'Weekly', Mensual:'Monthly', Año:'Year' }[g])}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>
              <View style={[st.configRow, { backgroundColor: theme.card, borderColor: theme.border }]}>
                <Ionicons name="calendar-number-outline" size={20} color="#8FA8C8" />
                <Text style={[st.configLabel, { color: theme.text }]}>{text('Período', 'Period')}</Text>
                <View style={{ flex: 1 }} />
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={st.chipRow}>
                  {PERIODS.map(p => (
                    <TouchableOpacity key={p} style={[st.chip, { backgroundColor: theme.input, borderColor: theme.border }, config.period === PERIOD_KEY[p] && st.chipActive]} onPress={() => setConfig(c => ({ ...c, period: PERIOD_KEY[p] }))}>
                      <Text style={[st.chipText, { color: config.period === PERIOD_KEY[p] ? theme.text : theme.muted }, config.period === PERIOD_KEY[p] && { fontWeight: '700' }]}>{text(p, { 'Últimos 30 días':'Last 30 days', 'Últimos 3 meses':'Last 3 months', 'Últimos 6 meses':'Last 6 months', 'Último año':'Last year', 'Últimos 2 años':'Last 2 years', Todo:'All time' }[p])}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>
            </ScrollView>
          )}
        </View>
      </Modal>
    </View>
  );
}
const st = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 56, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: BORDER },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700', flex: 1 },
  addBtn: { padding: 4, marginLeft: 6 },
  moveBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: BLUE, paddingHorizontal: 12, paddingVertical: 8 },
  moveBannerText: { color: '#fff', fontSize: 12, fontWeight: '600', flex: 1 },
  moveCancel: { color: '#fff', fontWeight: '800', fontSize: 12 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  centerText: { color: '#8FA8C8', fontSize: 13 },
  scroll: { padding: 16, paddingBottom: 32 },
  empty: { alignItems: 'center', gap: 10, paddingVertical: 60 },
  emptyText: { color: '#4A6080', fontSize: 14, textAlign: 'center' },
  card: { backgroundColor: CARD, borderRadius: 12, borderWidth: 1, borderColor: BORDER, padding: 14, marginBottom: 14 },
  cardMoving: { borderColor: BLUE, borderWidth: 2 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  cardTitle: { color: '#fff', fontSize: 15, fontWeight: '700' },
  yAxis: { justifyContent: 'space-between', alignItems: 'flex-end', width: 36, marginRight: 4, paddingVertical: 0 },
  yLabel: { color: '#5A708C', fontSize: 9 },
  chartArea: { flex: 1, position: 'relative' },
  gridLine: { position: 'absolute', left: 0, right: 0, height: 1, backgroundColor: 'rgba(143,168,200,0.12)' },
  barsRow: { position: 'absolute', top: 0, right: 0, bottom: 0, left: 0, flexDirection: 'row' },
  barCol: { flex: 1, alignItems: 'center', justifyContent: 'flex-end', height: '100%' },
  bar: { width: '60%', borderRadius: 2, position: 'absolute', bottom: 0 },
  labelsRow: { flexDirection: 'row', marginTop: 6 },
  labelX: { flex: 1, color: '#5A708C', fontSize: 9, textAlign: 'center' },
  fmtHint: { color: '#5A708C', fontSize: 10, marginTop: 4 },
  noData: { paddingVertical: 30, alignItems: 'center', gap: 8 },
  noDataText: { color: '#4A6080', fontSize: 13, textAlign: 'center' },
  retryBtn: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8, backgroundColor: BLUE },
  retryText: { color: '#fff', fontWeight: '700', fontSize: 13 },
  recordsBox: { gap: 10 },
  recordRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  recordLabel: { color: '#8FA8C8', fontSize: 13, flex: 1 },
  recordValue: { color: '#fff', fontSize: 14, fontWeight: '700' },
  zoneName: { color: '#fff', fontSize: 12, fontWeight: '700', width: 34 },
  zoneBarBg: { flex: 1, height: 8, borderRadius: 4, backgroundColor: '#0A1220', overflow: 'hidden' },
  zoneBar: { height: 8, borderRadius: 4, backgroundColor: GREEN },
  zoneBarOutside: { backgroundColor: '#E05252' },
  zonePct: { color: '#8FA8C8', fontSize: 11, width: 34, textAlign: 'right' },
  bottomAdd: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, padding: 14, borderWidth: 1, borderColor: BORDER, borderStyle: 'dashed', borderRadius: 12 },
  bottomAddText: { color: BLUE, fontWeight: '700', fontSize: 14 },
  overlay: { flex: 1, backgroundColor: '#00000088', justifyContent: 'center', alignItems: 'center' },
  pickerBox: { width: '80%', backgroundColor: '#1B1B1D', borderRadius: 12, paddingVertical: 8 },
  sectionTitle: { color: '#8FA8C8', fontSize: 12, fontWeight: '700', paddingHorizontal: 16, paddingTop: 12, paddingBottom: 4 },
  pickerItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#2A2A2D' },
  pickerItemText: { color: '#fff', fontSize: 14 },
  configSheet: { flex: 1, backgroundColor: NAVY, marginTop: 40, borderTopLeftRadius: 16, borderTopRightRadius: 16 },
  configHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: BORDER },
  configTitle: { color: '#fff', fontSize: 16, fontWeight: '700' },
  configSave: { color: BLUE, fontWeight: '700', fontSize: 15 },
  configScroll: { padding: 16, gap: 12 },
  configRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: CARD, borderRadius: 10, borderWidth: 1, borderColor: BORDER, padding: 12 },
  configLabel: { color: '#fff', fontSize: 14, fontWeight: '600' },
  chipRow: { flexDirection: 'row', flexGrow: 0 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 6, borderWidth: 1, borderColor: BORDER, marginLeft: 6, backgroundColor: NAVY },
  chipActive: { borderColor: BLUE, backgroundColor: BLUE + '22' },
  chipText: { color: '#8FA8C8', fontSize: 12 },
  chipTextActive: { color: '#fff', fontWeight: '700' },
});
