// screens/LoginScreen.js
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ActivityIndicator,
  KeyboardAvoidingView, Platform, ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
} from 'firebase/auth';
import { auth } from '../firebaseConfig';

const NAVY    = '#0D1B2A';
const CARD    = '#162032';
const BLUE    = '#4A90E2';
const BORDER  = '#1E3048';
const ERROR   = '#E05252';

const ERRORS = {
  'auth/invalid-email':         'El formato del email no es válido.',
  'auth/wrong-password':        'Contraseña incorrecta. Inténtalo de nuevo.',
  'auth/user-not-found':        'No existe ninguna cuenta con ese email.',
  'auth/email-already-in-use':  'Ese email ya tiene una cuenta registrada.',
  'auth/weak-password':         'La contraseña debe tener al menos 6 caracteres.',
  'auth/invalid-credential':    'Email o contraseña incorrectos.',
  'auth/too-many-requests':     'Demasiados intentos. Espera unos minutos.',
  'auth/network-request-failed':'Sin conexión a internet.',
};

export default function LoginScreen() {
  const [email,       setEmail]       = useState('');
  const [password,    setPassword]    = useState('');
  const [loading,     setLoading]     = useState(false);
  const [isNew,       setIsNew]       = useState(false);
  const [error,       setError]       = useState('');
  const [showPass,    setShowPass]    = useState(false);
  const [resetSent,   setResetSent]   = useState(false);

  const handleAuth = async () => {
    setError('');
    if (!email.trim())    { setError('Introduce tu email.'); return; }
    if (!password.trim()) { setError('Introduce tu contraseña.'); return; }

    try {
      setLoading(true);
      if (isNew) {
        await createUserWithEmailAndPassword(auth, email.trim(), password);
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), password);
      }
    } catch (err) {
      setError(ERRORS[err.code] || `Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async () => {
    if (!email.trim()) { setError('Introduce tu email para recuperar la contraseña.'); return; }
    try {
      setLoading(true);
      await sendPasswordResetEmail(auth, email.trim());
      setResetSent(true);
      setError('');
    } catch (err) {
      setError(ERRORS[err.code] || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: NAVY }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
      >
        {/* Logo */}
        <View style={styles.logoArea}>
          <View style={styles.logoIcon}>
            <Ionicons name="checkmark-circle" size={36} color={BLUE} />
          </View>
          <Text style={styles.logoText}>TEAM JORGE</Text>
        </View>

        {/* Campos */}
        <View style={styles.form}>
          {/* Error global */}
          {!!error && (
            <View style={styles.errorBox}>
              <Ionicons name="alert-circle" size={16} color={ERROR} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          {/* Reset enviado */}
          {resetSent && (
            <View style={styles.successBox}>
              <Ionicons name="mail" size={16} color="#2DB37A" />
              <Text style={styles.successText}>
                Email de recuperación enviado. Revisa tu bandeja.
              </Text>
            </View>
          )}

          <Text style={styles.fieldLabel}>Correo Electrónico</Text>
          <TextInput
            style={[styles.input, !!error && styles.inputError]}
            value={email}
            onChangeText={(v) => { setEmail(v); setError(''); }}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            placeholder=""
            placeholderTextColor="#2A4060"
          />

          <Text style={[styles.fieldLabel, { marginTop: 16 }]}>Contraseña</Text>
          <View style={styles.passWrapper}>
            <TextInput
              style={[styles.input, styles.inputPass, !!error && styles.inputError]}
              value={password}
              onChangeText={(v) => { setPassword(v); setError(''); }}
              secureTextEntry={!showPass}
              placeholder=""
              placeholderTextColor="#2A4060"
            />
            <TouchableOpacity
              style={styles.eyeBtn}
              onPress={() => setShowPass(!showPass)}
            >
              <Ionicons
                name={showPass ? 'eye-off-outline' : 'eye-outline'}
                size={20}
                color="#4A6080"
              />
            </TouchableOpacity>
          </View>

          {/* Botón principal */}
          <TouchableOpacity
            style={[styles.btnPrimary, loading && styles.disabled]}
            onPress={handleAuth}
            disabled={loading}
            activeOpacity={0.85}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.btnPrimaryText}>
                {isNew ? 'Registrarse' : 'Inicio de sesión'}
              </Text>
            )}
          </TouchableOpacity>

          {/* Botón secundario */}
          <TouchableOpacity
            style={styles.btnSecondary}
            onPress={() => { setIsNew(!isNew); setError(''); setResetSent(false); }}
            activeOpacity={0.85}
          >
            <Text style={styles.btnSecondaryText}>
              {isNew ? 'Inicio de sesión' : 'Registrarse'}
            </Text>
          </TouchableOpacity>

          {/* Recuperar contraseña */}
          {!isNew && (
            <TouchableOpacity onPress={handleReset} style={styles.resetBtn}>
              <Text style={styles.resetText}>¿Has olvidado tu contraseña?</Text>
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1, backgroundColor: NAVY,
    justifyContent: 'center', paddingHorizontal: 28, paddingVertical: 60,
  },
  logoArea: { alignItems: 'center', marginBottom: 48 },
  logoIcon: {
    width: 64, height: 64, borderRadius: 32,
    backgroundColor: '#0A1828', borderWidth: 2, borderColor: BLUE,
    alignItems: 'center', justifyContent: 'center', marginBottom: 12,
  },
  logoText: {
    fontSize: 22, fontWeight: '900', color: BLUE,
    letterSpacing: 4,
  },

  form: { gap: 4 },

  errorBox: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: '#2D1010', borderRadius: 10, padding: 12,
    borderWidth: 1, borderColor: '#5C2020', marginBottom: 12,
  },
  errorText: { color: ERROR, fontSize: 13, flex: 1 },

  successBox: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: '#0D2B1E', borderRadius: 10, padding: 12,
    borderWidth: 1, borderColor: '#1A5C3A', marginBottom: 12,
  },
  successText: { color: '#2DB37A', fontSize: 13, flex: 1 },

  fieldLabel: { color: '#8FA8C8', fontSize: 14, marginBottom: 8 },

  input: {
    backgroundColor: CARD, borderRadius: 8, paddingHorizontal: 16,
    paddingVertical: 14, color: '#FFF', fontSize: 15,
    borderWidth: 1, borderColor: BORDER,
  },
  inputError: { borderColor: ERROR },
  passWrapper: { position: 'relative' },
  inputPass:   { paddingRight: 48 },
  eyeBtn: {
    position: 'absolute', right: 14, top: 0, bottom: 0,
    justifyContent: 'center',
  },

  btnPrimary: {
    backgroundColor: BLUE, borderRadius: 8,
    paddingVertical: 16, alignItems: 'center', marginTop: 24,
  },
  disabled:       { opacity: 0.6 },
  btnPrimaryText: { color: '#FFF', fontSize: 16, fontWeight: '700' },

  btnSecondary: {
    borderRadius: 8, borderWidth: 1, borderColor: BLUE,
    paddingVertical: 16, alignItems: 'center', marginTop: 10,
  },
  btnSecondaryText: { color: BLUE, fontSize: 16, fontWeight: '700' },

  resetBtn:  { alignItems: 'flex-start', marginTop: 16 },
  resetText: { color: BLUE, fontSize: 14 },
});