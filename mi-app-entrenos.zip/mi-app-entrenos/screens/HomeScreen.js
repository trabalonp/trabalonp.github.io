// screens/HomeScreen.js
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import * as Notifications from 'expo-notifications';
import { collection, doc, getDoc, getDocs, onSnapshot, orderBy, query, setDoc, Timestamp, where } from 'firebase/firestore';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, AppState, Image, PanResponder, Platform, RefreshControl, ScrollView, StyleSheet, Text, TouchableOpacity, View, useColorScheme } from 'react-native';
import { auth, db } from '../firebaseConfig';
import { getApiUrl } from '../services/api';
import { cacheProfile, getCachedProfile } from '../services/profileCache';
import * as chartCache from '../services/chartCache';
import { getThemeColors, useAppSettings, t, formatSubtitleItem, fmtHomeDate } from '../services/appSettings';
import FitnessChart from '../components/FitnessChart';
import { consumePendingWorkoutId, subscribePendingWorkout } from '../services/deepLink';
import WeeklyKmChart from '../components/WeeklyKmChart';
import AddWorkoutModal from './AddWorkoutModal';
import WorkoutDetailModal from './WorkoutDetailModal';
import ActivityIcon from '../components/ActivityIcon';
import EsfuerzoBadge from '../components/EsfuerzoBadge';

const NAVY='#0D1B2A', CARD='#162032', BLUE='#4A90E2', GREEN='#2DB37A', RED='#E05252', GRAY='#4A6080', BORDER='#1E3048';
const TIPO_ICON={ Ciclismo:'bicycle', Running:'run', Natación:'water', Fuerza:'barbell', Triatlón:'medal-outline', Otro:'flash', Evento:'trophy', Descanso:'moon', Notas:'journal-outline' };

function stripHeavyFields(d){ const { registros, vueltas, ...light }=d; return light; }
const asc=(l)=>[...l].sort((a,b)=>(a.fecha?.toMillis?.()??0)-(b.fecha?.toMillis?.()??0));
function lighten(hex, amount = 0.5) {
  const num = parseInt(hex.replace('#',''), 16);
  let r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
  r = Math.round(r + (255 - r) * amount); g = Math.round(g + (255 - g) * amount); b = Math.round(b + (255 - b) * amount);
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}
// Modo claro: se intercambian los tonos de la tarjeta: el fondo pasa al
// tono gris/claro de la línea fina decorativa, y la línea fina pasa al
// color que antes tenía el fondo. En modo oscuro se mantiene como siempre.
function cardColors(color, isLight) {
  if (isLight) {
    // Planificados (gris): tonos mucho más suaves para que no resalten
    if (color === '#4A6080') return { bg: lighten(color, 0.78), accent: lighten(color, 0.35) };
    return { bg: lighten(color, 0.5), accent: color };
  }
  return { bg: color, accent: lighten(color, 0.5) };
}


export default function HomeScreen({ route }) {
  const user=auth.currentUser;
  const navigation=useNavigation();
  const appSettings = useAppSettings(); // re-renderiza al cambiar idioma/unidades/fecha/tema
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const [athleteId,setAthleteId]=useState(null);
  const [athleteName,setAthleteName]=useState(null);
  const currentUserId=athleteId||user?.uid;
  const [entrenamientos,setEntrenamientos]=useState(() => chartCache.getEntrenamientos(auth.currentUser?.uid) || []);
  const [wellness,setWellness]=useState(() => chartCache.getWellness(auth.currentUser?.uid) || {});
  const [loading,setLoading]=useState(!(chartCache.getEntrenamientos(auth.currentUser?.uid)));
  const [refreshing,setRefreshing]=useState(false);
  const [syncing,setSyncing]=useState(false);
  const [modalVisible,setModalVisible]=useState(false);
  const [detailModalVisible,setDetailModalVisible]=useState(false);
  const [selectedWorkout,setSelectedWorkout]=useState(null);

  // Deep link de notificaciones: si hay un workoutId pendiente (push tocado),
  // carga ese entreno y abre su modal de detalle. Suscrito también por si el
  // push llega con la app ya abierta en otra pestaña.
  useEffect(() => {
    try {
      const open = (id, tries = 2) => {
        getDoc(doc(db, 'entrenamientos', id)).then((s) => {
          if (s.exists()) {
            console.log('[deeplink] abriendo ficha del entreno', id);
            setSelectedWorkout({ id: s.id, ...s.data() });
            setDetailModalVisible(true);
          } else {
            console.warn('[deeplink] el entreno ya no existe:', id);
          }
        }).catch((e) => {
          // reintento por si la sesión/auth aún estaba asentándose al tocar el push
          console.warn('[deeplink] getDoc falló, reintento:', e.message);
          if (tries > 0) setTimeout(() => open(id, tries - 1), 1000);
        });
      };
      const un = subscribePendingWorkout(open);
      const id0 = consumePendingWorkoutId();
      if (id0) open(id0);
      return un;
    } catch (e) {
      return undefined;
    }
  }, []);
  const [profile,setProfile]=useState(null);
  const [fitnessDays,setFitnessDays]=useState([]);
  const [homePage,setHomePage]=useState(0);
  const appState=useRef(AppState.currentState);

  const pagerPan=useRef(PanResponder.create({
    onMoveShouldSetPanResponder:(e,gs)=>Math.abs(gs.dx)>14&&Math.abs(gs.dx)>Math.abs(gs.dy)*1.4,
    onPanResponderRelease:(e,gs)=>{ if(gs.dx<-40)setHomePage(p=>Math.min(2,p+1)); else if(gs.dx>40)setHomePage(p=>Math.max(0,p-1)); },
  })).current;

  useEffect(()=>{
    Notifications.setNotificationHandler({ handleNotification:async()=>({ shouldShowBanner:true, shouldShowList:true, shouldPlaySound:true, shouldSetBadge:false }) });
    Notifications.requestPermissionsAsync();
    if(Platform.OS==='android') Notifications.setNotificationChannelAsync('sync-channel',{ name:'Sincronización', importance:Notifications.AndroidImportance.HIGH });
    AsyncStorage.multiRemove(['garmin_email','garmin_password','garmin_days']).catch(()=>{});
  },[]);

  // ── PERFIL SIEMPRE CARGADO: caché instantánea + suscripción viva + backoff ──
  useEffect(()=>{
    const uid=currentUserId;
    if(!uid){ setProfile(null); return; }
    let cancelled=false;
    let unsub=null;
    let retryTimer=null;
    getCachedProfile(uid).then(c=>{ if(!cancelled&&c) setProfile(c); }).catch(()=>{});
    const subscribe=()=>{
      if(cancelled) return;
      unsub=onSnapshot(
        doc(db,'perfiles',uid),
        (snap)=>{
          if(cancelled) return;
          if(snap.exists()){
            const d=snap.data();
            setProfile(d);
            cacheProfile(uid,d).catch(()=>{});
          } else {
            setProfile(null);
          }
        },
        ()=>{
          if(cancelled) return;
          retryTimer=setTimeout(()=>{ if(!cancelled) subscribe(); }, 1500);
        }
      );
    };
    subscribe();
    return ()=>{
      cancelled=true;
      if(retryTimer) clearTimeout(retryTimer);
      if(unsub) unsub();
    };
  },[currentUserId]);

  const refreshProfile=useCallback(async(uid)=>{
    if(!uid)return;
    for(let i=0;i<3;i++){
      try{
        const snap=await getDoc(doc(db,'perfiles',uid));
        if(snap.exists()){
          const d=snap.data();
          setProfile(d);
          cacheProfile(uid,d).catch(()=>{});
        } else {
          setProfile(null);
        }
        return;
      }catch(e){
        if(i<2) await new Promise(r=>setTimeout(r, 700*(i+1)));
      }
    }
  },[]);

  const refreshAthleteContext=useCallback(async()=>{
    const id=await AsyncStorage.getItem('currentAthleteId');
    setAthleteId(id);
    const n=await AsyncStorage.getItem('currentAthleteName');
    setAthleteName(n);
  },[]);

  useFocusEffect(useCallback(()=>{
    let active=true;
    (async()=>{
      await refreshAthleteContext();
      if(!active)return;
      refreshProfile(currentUserId);
      fetchData();
      fetchWellness();
    })();
    return ()=>{ active=false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[currentUserId, refreshProfile, refreshAthleteContext]));

  useEffect(()=>{
    const sub=AppState.addEventListener('change',(next)=>{
      if(next==='active' && appState.current!=='active'){
        (async()=>{
          await refreshAthleteContext();
          refreshProfile(currentUserId);
          chartCache.bumpRefresh();
          fetchData();
          fetchWellness();
        })();
      }
      appState.current=next;
    });
    return ()=>sub.remove();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[currentUserId, refreshProfile, refreshAthleteContext]);

  const fetchData=useCallback(async()=>{
    if(!currentUserId)return;
    const cached=chartCache.getEntrenamientos(currentUserId);
    if(cached){ setEntrenamientos(cached); setLoading(false); setRefreshing(false); return; }
    try{
      const now=new Date(); const start=new Date(now); start.setDate(now.getDate()-30); start.setHours(0,0,0,0);
      const end=new Date(now); end.setDate(now.getDate()+30); end.setHours(23,59,59,999);
      const q=query(collection(db,'entrenamientos'), where('userId','==',currentUserId), where('fecha','>=',Timestamp.fromDate(start)), where('fecha','<=',Timestamp.fromDate(end)), orderBy('fecha','desc'));
      const snap=await getDocs(q);
      const lista=snap.docs.map(d=>({ id:d.id, ...stripHeavyFields(d.data()) }));
      try {
        // array-contains SIN rango de fechas: usa el indice automatico de un solo campo
        // (NO necesita indice compuesto en Firebase). El rango +/-30 dias se filtra en local.
        const q2=query(collection(db,'entrenamientos'), where('asignados','array-contains',currentUserId));
        const s2=await getDocs(q2);
        s2.docs.forEach(d=>{ const data=d.data(); const f=data.fecha?.toMillis?.() ?? null; if(f!=null && f>=start.getTime() && f<=end.getTime() && !lista.some(x=>x.id===d.id)) lista.push({ id:d.id, ...stripHeavyFields(data) }); });
      } catch(e){ console.log('Error eventos asignados:', e?.message || e); }
      chartCache.setEntrenamientos(currentUserId, lista);
      setEntrenamientos(lista);
    }catch(e){} finally { setLoading(false); setRefreshing(false); }
  },[currentUserId]);

  const fetchWellness=useCallback(async()=>{
    if(!currentUserId)return;
    const cached=chartCache.getWellness(currentUserId);
    if(cached){ setWellness(cached); return; }
    try{
      const s=await getDoc(doc(db,'wellness',currentUserId));
      const days=s.exists?(s.data().days||{}):{};
      chartCache.setWellness(currentUserId, days);
      setWellness(days);
    }catch(e){}
  },[currentUserId]);

  const fetchFitness=useCallback(async(mode='cache')=>{
    const uid=currentUserId; if(!uid)return;
    try{
      if(mode==='cache'){ const s=await getDoc(doc(db,'fitness',uid)); if(s.exists()){ setFitnessDays(s.data().days??[]); return; } setFitnessDays([]); }
      const conn=await getDoc(doc(db,'intervals_connections',uid)); if(!conn.exists())return;
      const apiUrl=(await getApiUrl()).replace(/\/+$/,''); const token=await user.getIdToken();
      const r=await fetch(`${apiUrl}/sync-fitness`,{ method:'POST', headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`} });
      if(r.ok){ const s2=await getDoc(doc(db,'fitness',uid)); if(s2.exists()) setFitnessDays(s2.data().days??[]); }
    }catch(e){}
  },[currentUserId]);

  useEffect(()=>{ fetchFitness('cache'); },[fetchFitness]);

  const handleRefresh=useCallback(()=>{
    setRefreshing(true);
    chartCache.bumpRefresh();
    fetchData();
    fetchWellness();
    fetchFitness('cache');
    refreshProfile(currentUserId);
  },[fetchData, fetchWellness, fetchFitness, refreshProfile, currentUserId]);

  const handleSync=async()=>{
    if(syncing||athleteId)return;
    setSyncing(true);
    try{
      const apiUrl=(await getApiUrl()).replace(/\/+$/,''); const token=await user.getIdToken();
      const now=new Date(); const ago=new Date(now); ago.setDate(now.getDate()-30);
      const oldest=ago.toISOString().split('T')[0]; const newest=now.toISOString().split('T')[0];
      const controller=new AbortController(); const timeout=setTimeout(()=>controller.abort(),120000);
      const res=await fetch(`${apiUrl}/sync-intervals`,{ method:'POST', headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`}, body:JSON.stringify({ oldest, newest }), signal:controller.signal });
      clearTimeout(timeout);
      if(res.status===400){ const data=await res.json().catch(()=>({})); if(data.error==='Intervals.icu no conectado'){ Alert.alert('Intervals.icu no conectado','Conecta tu cuenta de Intervals.icu antes de sincronizar.',[{text:'Cancelar',style:'cancel'},{text:'Conectar',onPress:()=>navigation.navigate('SyncSettings')}]); return; } throw new Error(data.error||'Error en la sincronización'); }
      if(res.status===401){ Alert.alert('Sesión expirada','Vuelve a iniciar sesión en la aplicación.'); return; }
      if(!res.ok){ const errData=await res.json().catch(()=>({})); throw new Error(errData.error||'Error del servidor'); }
      chartCache.bumpRefresh();
      fetchData(); fetchWellness(); fetchFitness('force');
    }catch(err){
      if(err.name==='AbortError') Alert.alert('Tiempo agotado','La sincronización tardó demasiado. Inténtalo de nuevo.');
      else Alert.alert('Error', err.message);
    } finally { setSyncing(false); }
  };

  const handleDataChanged=useCallback(()=>{
    chartCache.bumpRefresh();
    fetchData();
    fetchWellness();
  },[fetchData, fetchWellness]);

  const today=new Date(); const tomorrow=new Date(today); tomorrow.setDate(tomorrow.getDate()+1);
  const todayEntrenamientos=asc(entrenamientos.filter(e=>{ if(!e.fecha)return false; const d=e.fecha.toDate?e.fecha.toDate():new Date(e.fecha); return d.toDateString()===today.toDateString()&&e.tipo!=='Evento'; }));
  const tomorrowEntrenamientos=asc(entrenamientos.filter(e=>{ if(!e.fecha)return false; const d=e.fecha.toDate?e.fecha.toDate():new Date(e.fecha); return d.toDateString()===tomorrow.toDateString()&&e.tipo!=='Evento'; }));
  const proximosEventos=asc(entrenamientos.filter(e=>{ if(!e.fecha)return false; const d=e.fecha.toDate?e.fecha.toDate():new Date(e.fecha); return e.tipo==='Evento'&&d>=today; })).slice(0,5);
  // Días que faltan para el próximo evento (para el título de la sección)
  const diasEvento=(()=>{ if(!proximosEventos.length) return ''; const f=proximosEventos[0].fecha; const fd=f?.toDate?f.toDate():new Date(f); const a=new Date(); a.setHours(0,0,0,0); const b=new Date(fd); b.setHours(0,0,0,0); const d=Math.round((b-a)/86400000); if(d<=0) return t('common.today'); const en=appSettings.language==='en'; return `${d} ${d===1?(en?'day':'día'):(en?'days':'días')}`; })();

  const getWorkoutColor=(e)=>e==='completo'?GREEN:e==='incompleto'?RED:GRAY;
  const profilePhoto=profile?.foto;
  const firstName=profile?.nombre?.trim().split(' ')[0]||athleteName||user?.displayName||'Atleta';
  const initial=firstName.charAt(0).toUpperCase();
  const hoy=fmtHomeDate(new Date()); // respeta idioma + formato de fecha elegidos

  if(loading)return(<View style={[styles.splash, { backgroundColor: theme.background }]}><ActivityIndicator size="large" color={BLUE} /></View>);

  return (
    <>
      <ScrollView style={[styles.container, { backgroundColor: theme.background }]} contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={BLUE} />}
        showsVerticalScrollIndicator={false}>
        <View style={[styles.header, { backgroundColor: theme.background }]}>
          <View style={styles.avatar}>
            {profilePhoto?(<Image source={{ uri:`data:image/jpeg;base64,${profilePhoto}` }} style={styles.avatarImg} />):(<Text style={styles.avatarInitial}>{initial}</Text>)}
          </View>
          <View style={{flex:1}}>
            <Text style={[styles.userName, { color: theme.text }]}>{athleteName||firstName}</Text>
            <Text style={[styles.userDate, { color: theme.muted }]}>{hoy}</Text>
          </View>
          {athleteId&&(
            <TouchableOpacity style={[styles.backToMeBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={async()=>{ await AsyncStorage.removeItem('currentAthleteId'); await AsyncStorage.removeItem('currentAthleteName'); setAthleteId(null); setAthleteName(null); }}>
              <Ionicons name="person-outline" size={22} color={BLUE} />
            </TouchableOpacity>
          )}
          {!athleteId&&(
              <TouchableOpacity style={[styles.syncBtn, syncing&&styles.syncBtnActive, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={handleSync} disabled={syncing} activeOpacity={0.75}>
              {syncing?<ActivityIndicator size="small" color={BLUE} />:<Ionicons name="sync-outline" size={22} color={BLUE} />}
            </TouchableOpacity>
          )}
        </View>

        {syncing&&(
          <View style={[styles.syncBanner, { backgroundColor: theme.card, borderColor: BLUE }]}> 
            <ActivityIndicator size="small" color={BLUE} style={{marginRight:8}} />
            <Text style={styles.syncBannerText} numberOfLines={1}>{t('home.syncing')}</Text>
          </View>
        )}

        <View {...pagerPan.panHandlers} style={{ backgroundColor: theme.background }}>
          {homePage===0&&( fitnessDays.length>1?(<FitnessChart key={`fitness-${theme.background}`} days={fitnessDays} theme={theme} />):(
            <View style={[styles.bannerCard, { backgroundColor: theme.card, borderColor: theme.border }] }>
              <Ionicons name="trending-up" size={48} color={BLUE} style={{marginBottom:8}} />
              <Text style={[styles.bannerTitle, { color: theme.text }]}>{t('home.bannerTitle')}</Text>
              <Text style={[styles.bannerSub, { color: theme.muted }]}>{t('home.bannerSub')}</Text>
            </View>
          ))}
          {homePage===1&&(<WeeklyKmChart key={`weekly-0-${theme.background}`} entrenamientos={entrenamientos} wellness={wellness} weekOffset={0} userId={currentUserId} theme={theme} />)}
          {homePage===2&&(<WeeklyKmChart key={`weekly-1-${theme.background}`} entrenamientos={entrenamientos} wellness={wellness} weekOffset={1} userId={currentUserId} theme={theme} />)}
          <View style={styles.dotsRow}>{[0,1,2].map(i=>(<View key={i} style={[styles.dot, homePage===i&&styles.dotActive]} />))}</View>
        </View>

        <Section title={t('home.today')} onAdd={()=>setModalVisible(true)}>
          {todayEntrenamientos.length>0?todayEntrenamientos.map(e=>(
            <WorkoutRow key={e.id} item={e} color={getWorkoutColor(e.estado)} onPress={()=>{ setSelectedWorkout(e); setDetailModalVisible(true); }} />
          )):(<EmptyCard icon="add-circle-outline" text={t('home.emptyToday')} />)}
        </Section>
        {tomorrowEntrenamientos.length>0&&(
          <Section title={t('home.tomorrow')}>
            {tomorrowEntrenamientos.map(e=>(<WorkoutRow key={e.id} item={e} color={getWorkoutColor(e.estado)} onPress={()=>{ setSelectedWorkout(e); setDetailModalVisible(true); }} />))}
          </Section>
        )}
        {proximosEventos.length>0&&(
          <Section title={`${t('home.upcoming')} · ${diasEvento}`}>
            {proximosEventos.map(e=>(<WorkoutRow key={e.id} item={e} color={getWorkoutColor(e.estado)} onPress={()=>{ setSelectedWorkout(e); setDetailModalVisible(true); }} />))}
          </Section>
        )}
      </ScrollView>

      <AddWorkoutModal visible={modalVisible} onClose={()=>setModalVisible(false)} onWorkoutAdded={handleDataChanged} initialDate={new Date()} athleteId={athleteId} />
      <WorkoutDetailModal visible={detailModalVisible} workout={selectedWorkout} onClose={()=>{ setDetailModalVisible(false); setSelectedWorkout(null); }} onWorkoutUpdated={handleDataChanged} athleteId={athleteId} />
    </>
  );
}

function Section({ title, onAdd, children }){
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  return (
    <View style={styles.section}>
      <View style={[styles.sectionHeader, { backgroundColor: theme.card, borderColor: theme.border }]}>
        <Text style={[styles.sectionTitle, { color: theme.text }]}>{title}</Text>
        {onAdd&&(<TouchableOpacity style={styles.addBtn} onPress={onAdd}><Text style={styles.addBtnText}>{t('home.add')}</Text></TouchableOpacity>)}
      </View>
      {children}
    </View>
  );
}

function WorkoutRow({ item, color, onPress }){
  const subtitle=formatSubtitleItem(item); // respeta unidades (km/mi) y ppm/bpm
  const settings=useAppSettings();
  const theme=getThemeColors(settings.themeMode, useColorScheme());
  const isLight=theme.background==='#F4F7FB';
  const pal=cardColors(color, isLight);
  const esfuerzo=Math.round(Number(item.esfuerzo ?? item.tss) || 0); // TSS del entreno sincronizado
  const hasFooter=!!item.estado || esfuerzo>0;
  return (
    <TouchableOpacity style={[styles.workoutCard, { backgroundColor: pal.bg }]} onPress={onPress} activeOpacity={0.8}>
      <View style={[styles.cardAccent, { backgroundColor: pal.accent }]} />
      <View style={[styles.cardBody, hasFooter&&styles.cardBodyWithFooter]}>
        <View style={styles.iconChip}><ActivityIcon tipo={item.tipo} size={18} /></View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.workoutTitle, isLight && { color: theme.text }]}>{item.titulo || item.tipo}</Text>
          {subtitle ? <Text style={[styles.metaText, isLight && { color: theme.muted }]}>{subtitle}</Text> : null}
        </View>
      </View>
      {hasFooter && (
        <View style={styles.cardFooter}>
          {item.estado ? (
            <Ionicons name={item.estado === 'completo' ? 'checkmark-circle' : 'close-circle'} size={16} color={isLight ? color : '#fff'} />
          ) : <View />}
          <EsfuerzoBadge value={esfuerzo} />
        </View>
      )}
    </TouchableOpacity>
  );
}

function EmptyCard({ icon, text }){
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  return (<View style={[styles.emptyCard, { backgroundColor: theme.card, borderColor: theme.border }]}><Ionicons name={icon} size={28} color={theme.muted} /><Text style={[styles.emptyCardText, { color: theme.muted }]}>{text}</Text></View>);
}

const styles=StyleSheet.create({
  container:{flex:1,backgroundColor:NAVY}, content:{paddingBottom:32},
  splash:{flex:1,backgroundColor:NAVY,alignItems:'center',justifyContent:'center'},
  header:{flexDirection:'row',alignItems:'center',paddingHorizontal:16,paddingTop:56,paddingBottom:16,gap:12},
  avatar:{width:44,height:44,borderRadius:22,backgroundColor:BLUE,alignItems:'center',justifyContent:'center',overflow:'hidden'},
  avatarImg:{width:44,height:44}, avatarInitial:{color:'#fff',fontSize:18,fontWeight:'800'},
  userName:{color:'#fff',fontSize:16,fontWeight:'700'},
  userDate:{color:'#8FA8C8',fontSize:13,marginTop:2,lineHeight:18},
  syncBtn:{width:42,height:42,borderRadius:21,backgroundColor:'#0A1828',borderWidth:1,borderColor:BORDER,alignItems:'center',justifyContent:'center'},
  syncBtnActive:{borderColor:BLUE,backgroundColor:'#0D2040'},
  backToMeBtn:{width:42,height:42,borderRadius:21,backgroundColor:'#0A1828',borderWidth:1,borderColor:BORDER,alignItems:'center',justifyContent:'center',marginRight:8},
  syncBanner:{flexDirection:'row',alignItems:'center',backgroundColor:'#0D2040',borderRadius:8,marginHorizontal:16,marginBottom:8,paddingHorizontal:14,paddingVertical:10,borderWidth:1,borderColor:BLUE},
  syncBannerText:{color:BLUE,fontSize:13,flex:1},
  bannerCard:{margin:16,backgroundColor:CARD,borderRadius:12,borderWidth:1,borderColor:BORDER,padding:20,alignItems:'center'},
  bannerTitle:{color:'#fff',fontSize:16,fontWeight:'700',textAlign:'center',marginBottom:8},
  bannerSub:{color:'#8FA8C8',fontSize:13,textAlign:'center',lineHeight:18},
  dotsRow:{flexDirection:'row',justifyContent:'center',gap:8,marginTop:4,marginBottom:8},
  dot:{width:8,height:8,borderRadius:4,backgroundColor:'#2A4060'}, dotActive:{backgroundColor:BLUE},
  section:{marginTop:4},
  sectionHeader:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingHorizontal:16,paddingVertical:12,backgroundColor:'#111D2C',borderTopWidth:1,borderBottomWidth:1,borderColor:BORDER},
  sectionTitle:{color:'#fff',fontSize:15,fontWeight:'700'},
  addBtn:{backgroundColor:BLUE,borderRadius:6,paddingHorizontal:14,paddingVertical:6},
  addBtnText:{color:'#fff',fontSize:13,fontWeight:'700'},
  emptyCard:{margin:16,backgroundColor:CARD,borderRadius:10,borderWidth:1,borderColor:BORDER,padding:24,alignItems:'center',gap:8},
  emptyCardText:{color:'#4A6080',fontSize:14,textAlign:'center'},
  workoutCard:{marginHorizontal:16,marginTop:8,borderRadius:10,overflow:'hidden'},
  cardAccent:{height:3,width:'100%'},
  cardBody:{flexDirection:'row',alignItems:'flex-start',padding:12,gap:10},
  cardBodyWithFooter:{paddingBottom:6},
  cardFooter:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:12,paddingBottom:10},
  cardIcon:{marginTop:1},
  iconChip:{width:30,height:30,borderRadius:15,backgroundColor:'#FFFFFF',alignItems:'center',justifyContent:'center'},
  workoutTitle:{color:'#fff',fontSize:13,fontWeight:'700'},
  metaText:{color:'#cfffec',fontSize:12,marginTop:3},
});
