// screens/ProfileScreen.js
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import * as FileSystem from 'expo-file-system/legacy';
import * as ImageManipulator from 'expo-image-manipulator';
import * as ImagePicker from 'expo-image-picker';
import { deleteUser, signOut } from 'firebase/auth';
import { deleteDoc, doc, getDoc, setDoc } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import SystemBars from '../components/SystemBars';
import {
  ActivityIndicator,
  Alert,
  Image,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  useColorScheme,
} from 'react-native';
import { auth, db } from '../firebaseConfig';
import { clearCoachCache } from '../services/coachCache';
import { cacheProfile, clearProfileCache, getCachedProfile, invalidateProfileCache } from '../services/profileCache';
import { publicarMiAvatar } from '../services/avatarCache';
import { getThemeColors, L, locale, useAppSettings } from '../services/appSettings';

const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';
const RED    = '#E05252';
const SERVER_URL = 'https://garmin-fit-server.onrender.com';

function FullScreenPicker({ value, options, onChange, placeholder = 'Escoge' }) {
  const insets = useSafeAreaInsets();
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const [visible, setVisible] = useState(false);
  const select = (opt) => { onChange(opt); setVisible(false); };
  const currentLabel = value || placeholder;
  return (
    <>
      <TouchableOpacity style={[pk.btn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => setVisible(true)} activeOpacity={0.8}>
        <Text style={[pk.text, { color: value ? theme.text : theme.muted }]} numberOfLines={1}>{currentLabel}</Text>
        <Ionicons name="chevron-down" size={15} color="#8FA8C8" />
      </TouchableOpacity>
      <Modal visible={visible} animationType="slide" transparent={false}>
          <View style={[pk.fullScreen, { backgroundColor: theme.background }]}>
          <View style={[pk.fullHeader, { borderBottomColor: theme.border }]}>
            <Text style={[pk.fullTitle, { color: theme.text }]}>{L('Selecciona una opción','Select an option')}</Text>
            <TouchableOpacity onPress={() => setVisible(false)}>
              <Ionicons name="close" size={24} color="#8FA8C8" />
            </TouchableOpacity>
          </View>
          <ScrollView style={pk.fullList}>
            {options.map((opt, index) => {
              const selected = value === opt;
              return (
                <TouchableOpacity key={opt} style={[pk.fullOption, { borderBottomColor: theme.border }, selected && pk.fullOptionActive]} onPress={() => select(opt)}>
                  <Text style={[pk.fullOptionIndex, { color: theme.muted }, selected && pk.fullOptionIndexActive]}>{index + 1}</Text>
                  <Text style={[pk.fullOptionText, { color: theme.text }, selected && pk.fullOptionTextActive]}>{opt}</Text>
                  {selected && <Ionicons name="checkmark" size={20} color={BLUE} />}
                </TouchableOpacity>
              );
            })}
          </ScrollView>
          <TouchableOpacity style={[pk.fullCancelBtn, { borderTopColor: theme.border, paddingBottom: 18 + insets.bottom }]} onPress={() => setVisible(false)}>
            <Text style={pk.fullCancelText}>{L('Cancelar','Cancel')}</Text>
          </TouchableOpacity>
        </View>
        <SystemBars />
      </Modal>
    </>
  );
}
const pk = StyleSheet.create({
  btn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: CARD, borderRadius: 6, borderWidth: 1, borderColor: BORDER, paddingHorizontal: 12, paddingVertical: 12, marginVertical: 4 },
  text: { color: '#fff', fontSize: 14, flex: 1 },
  ph: { color: '#4A6080' },
  fullScreen: { flex: 1, backgroundColor: NAVY },
  fullHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 56, paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: BORDER },
  fullTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  fullList: { flex: 1, paddingHorizontal: 16 },
  fullOption: { flexDirection: 'row', alignItems: 'center', paddingVertical: 16, paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: BORDER, gap: 14 },
  fullOptionActive: { backgroundColor: BLUE + '22', borderRadius: 8 },
  fullOptionIndex: { color: '#8FA8C8', fontSize: 16, fontWeight: '600', minWidth: 24 },
  fullOptionIndexActive: { color: BLUE },
  fullOptionText: { color: '#fff', fontSize: 16, flex: 1 },
  fullOptionTextActive: { color: BLUE, fontWeight: '700' },
  fullCancelBtn: { paddingVertical: 18, alignItems: 'center', borderTopWidth: 1, borderTopColor: BORDER, marginTop: 8 },
  fullCancelText: { color: RED, fontSize: 16, fontWeight: '600' },
});

function Field({ label, value, onChange, keyboardType, placeholder, editable = true }) {
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  return (
    <View style={styles.fieldContainer}>
      <Text style={[styles.fieldLabel, { color: theme.muted }]}>{label}</Text>
      <TextInput
        style={[styles.fieldInput, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }, !editable && styles.disabledInput]}
        value={value}
        onChangeText={onChange}
        placeholder={placeholder || ''}
        placeholderTextColor="#4A6080"
        keyboardType={keyboardType}
        editable={editable}
      />
    </View>
  );
}

// ── Fecha de nacimiento: parseo y validación ──
const MESES_ES_LARGOS = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
const MESES_EN_LARGOS = ['january','february','march','april','may','june','july','august','september','october','november','december'];
const MESES_ES_CORTOS = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
const MESES_EN_CORTOS = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
const MESES_DISPLAY = {
  es: ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'],
  en: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
};

function mesesDisplay() {
  return locale() === 'en-US' ? MESES_DISPLAY.en : MESES_DISPLAY.es;
}

function mesDesdeTexto(txt) {
  const t = String(txt).toLowerCase().trim();
  if (!t) return null;
  let i = MESES_ES_LARGOS.indexOf(t); if (i >= 0) return i + 1;
  i = MESES_EN_LARGOS.indexOf(t); if (i >= 0) return i + 1;
  if (t.length <= 4) {
    const t3 = t.slice(0, 3);
    i = MESES_ES_CORTOS.indexOf(t3); if (i >= 0) return i + 1;
    i = MESES_EN_CORTOS.indexOf(t3); if (i >= 0) return i + 1;
  }
  return null;
}

function esFechaReal(y, m, d) {
  if (!(m >= 1 && m <= 12) || !(d >= 1)) return false;
  const dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
}

// Parsea el campo y devuelve { y, m, d } o null si no encaja en ningún formato
// aceptado:
//   · DD/MM/AAAA, DD-MM-AAAA, DD.MM.AAAA (también año de 2 dígitos: 30-99 → 19xx, 00-29 → 20xx)
//   · AAAA-MM-DD (ISO)
//   · DD MMM AAAA / DD de MMMM de AAAA / MMM DD, AAAA ("15 Mar 1990", "15 de marzo de 1990", "Mar 15, 1990"; mes en español o inglés)
function parseFechaNac(txt) {
  if (txt == null) return null;
  const s = String(txt).trim().replace(/\s+/g, ' ');
  if (!s) return null;
  const expandir = (yy) => (yy <= 29 ? 2000 + yy : 1900 + yy);

  let r = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s); // AAAA-MM-DD
  if (r) {
    const y = +r[1], m = +r[2], d = +r[3];
    return esFechaReal(y, m, d) ? { y, m, d } : null;
  }
  r = /^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2}|\d{4})$/.exec(s); // DD/MM/AAAA
  if (r) {
    const d = +r[1], m = +r[2];
    const y = r[3].length === 2 ? expandir(+r[3]) : +r[3];
    return esFechaReal(y, m, d) ? { y, m, d } : null;
  }
  r = /^(\d{1,2})[\s.]+(?:de\s+)?([A-Za-zÁÉÍÓÚÜÑáéíóúüñ]{3,12})[.,]?\s*(?:de\s+|del\s+)?(\d{2}|\d{4})$/.exec(s); // DD MMM AAAA
  if (r) {
    const d = +r[1], m = mesDesdeTexto(r[2]);
    const y = r[3].length === 2 ? expandir(+r[3]) : +r[3];
    return m && esFechaReal(y, m, d) ? { y, m, d } : null;
  }
  r = /^([A-Za-zÁÉÍÓÚÜÑáéíóúüñ]{3,12})[.,]?\s+(\d{1,2})(?:st|nd|rd|th)?[,\s]+(\d{2}|\d{4})$/.exec(s); // MMM DD, AAAA (inglés)
  if (r) {
    const m = mesDesdeTexto(r[1]), d = +r[2];
    const y = r[3].length === 2 ? expandir(+r[3]) : +r[3];
    return m && esFechaReal(y, m, d) ? { y, m, d } : null;
  }
  return null;
}

// Valida el campo: vacío se permite (campo opcional); si no, debe tener un
// formato aceptado, ser una fecha real del calendario, no futura y no implicar
// más de 110 años. Si es correcta devuelve { ok: true, iso } con la fecha
// normalizada a AAAA-MM-DD (es lo que se guarda en Firestore, para que
// new Date() la entienda siempre — p. ej. la fórmula de Tanaka del SyncService).
function validarFechaNac(txt) {
  const s = txt == null ? '' : String(txt).trim();
  if (!s) return { ok: true, iso: '' };
  const p = parseFechaNac(s);
  if (!p) return { ok: false, motivo: 'formato' };
  const hoy = new Date();
  const nac = new Date(p.y, p.m - 1, p.d);
  if (nac.getTime() > hoy.getTime()) return { ok: false, motivo: 'futura' };
  const edad = (hoy.getTime() - nac.getTime()) / (365.25 * 24 * 3600 * 1000);
  if (edad > 110) return { ok: false, motivo: 'rango' };
  const iso = `${p.y}-${String(p.m).padStart(2, '0')}-${String(p.d).padStart(2, '0')}`;
  return { ok: true, iso };
}

// Muestra la fecha guardada (cadena ISO o Timestamp de Firestore) como
// "DD MMM AAAA". Si no se puede interpretar, la devuelve tal cual.
function formatoBonitoFechaNac(v) {
  if (v == null || v === '') return '';
  if (typeof v === 'object' && typeof v.toDate === 'function') {
    const d = v.toDate();
    return `${String(d.getDate()).padStart(2, '0')} ${mesesDisplay()[d.getMonth()]} ${d.getFullYear()}`;
  }
  const s = String(v).trim();
  const p = parseFechaNac(s);
  if (!p) return s;
  return `${String(p.d).padStart(2, '0')} ${mesesDisplay()[p.m - 1]} ${p.y}`;
}

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const appSettings = useAppSettings(); // re-renderiza al cambiar idioma/tema
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const user = auth.currentUser;
  const uid = user?.uid;
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [profile, setProfile] = useState(null);
  const [nombre, setNombre] = useState('');
  const [apellido, setApellido] = useState('');
  const [sexo, setSexo] = useState('');
  const [fechaNac, setFechaNac] = useState('');
  const [altura, setAltura] = useState('');
  const [unidadAltura, setUnidadAltura] = useState('cm');
  const [peso, setPeso] = useState('');
  const [unidadPeso, setUnidadPeso] = useState('kg');
  const [pais, setPais] = useState('');
  const [ciudad, setCiudad] = useState('');
  const [dni, setDni] = useState('');
  const [telefono, setTelefono] = useState('');
  const [fotoBase64, setFotoBase64] = useState(null);
  const sexos = ['Masculino', 'Femenino', 'Otro'];
  const unidades = ['cm', 'm', 'in', 'ft'];
  const unidadesPeso = ['kg', 'lb'];

  useEffect(() => {
    if (!uid) { setFetching(false); return; }
    (async () => {
      const cached = await getCachedProfile();
      if (cached) {
        setProfile(cached);
        setNombre(cached.nombre || ''); setApellido(cached.apellido || '');
        setSexo(cached.sexo || ''); setFechaNac(formatoBonitoFechaNac(cached.fechaNac));
        setAltura(cached.altura || ''); setUnidadAltura(cached.unidadAltura || 'cm');
        setPeso(cached.peso || ''); setUnidadPeso(cached.unidadPeso || 'kg');
        setPais(cached.pais || ''); setCiudad(cached.ciudad || '');
        setDni(cached.dni || ''); setTelefono(cached.telefono || '');
        if (cached.foto) setFotoBase64(cached.foto);
        setFetching(false);
      }
      try {
        const snap = await getDoc(doc(db, 'perfiles', uid));
        if (snap.exists()) {
          const data = snap.data();
          setProfile(data);
          setNombre(data.nombre || ''); setApellido(data.apellido || '');
          setSexo(data.sexo || ''); setFechaNac(formatoBonitoFechaNac(data.fechaNac));
          setAltura(data.altura || ''); setUnidadAltura(data.unidadAltura || 'cm');
          setPeso(data.peso || ''); setUnidadPeso(data.unidadPeso || 'kg');
          setPais(data.pais || ''); setCiudad(data.ciudad || '');
          setDni(data.dni || ''); setTelefono(data.telefono || '');
          if (data.foto) setFotoBase64(data.foto);
          await cacheProfile(uid, data);
        }
      } catch (err) {
        console.error('Error refrescando perfil:', err);
      } finally {
        setFetching(false);
      }
    })();
  }, [uid]);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert(L('Permiso requerido','Permission required'), L('Concede acceso a la galería para elegir una foto.','Grant gallery access to pick a photo.'));
      return;
    }
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });
    if (result.canceled || !result.assets || result.assets.length === 0) return;
    const imageUri = result.assets[0].uri;
    try {
      const tempFile = FileSystem.cacheDirectory + 'profile_pic_temp.jpg';
      await FileSystem.copyAsync({ from: imageUri, to: tempFile });
      const manipResult = await ImageManipulator.manipulateAsync(
        tempFile,
        [{ resize: { width: 200, height: 200 } }],
        { compress: 0.5, format: ImageManipulator.SaveFormat.JPEG }
      );
      const base64 = await FileSystem.readAsStringAsync(manipResult.uri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      setFotoBase64(base64);
      await FileSystem.deleteAsync(tempFile, { idempotent: true });
    } catch (error) {
      console.error('Error al manipular:', error);
      try {
        const base64 = await FileSystem.readAsStringAsync(imageUri, {
          encoding: FileSystem.EncodingType.Base64,
        });
        setFotoBase64(base64);
        Alert.alert(L('Imagen guardada','Image saved'), L('No se pudo comprimir, se guardó la imagen original.','Could not compress; original image saved.'));
      } catch (fallbackError) {
        console.error('Error al leer la imagen original:', fallbackError);
        Alert.alert(L('Error','Error'), L('No se pudo procesar la imagen seleccionada.','Could not process the selected image.'));
      }
    }
  };

  const handleUpdate = async () => {
    if (!uid) { Alert.alert(L('Error','Error'), L('No se ha identificado al usuario.','User not identified.')); return; }
    // Validar la fecha de nacimiento antes de guardar nada: si está rellena y
    // el formato no es correcto (o es futura / inverosímil), se bloquea la
    // actualización completa del perfil y se avisa al usuario.
    const fnCheck = validarFechaNac(fechaNac);
    if (!fnCheck.ok) {
      const mensajes = {
        futura: L('La fecha de nacimiento no puede ser futura.','Date of birth cannot be in the future.'),
        rango: L('La fecha de nacimiento no parece válida (más de 110 años).','Date of birth does not look valid (over 110 years).'),
        formato: L('El formato de la fecha de nacimiento no es correcto. Formatos válidos: DD/MM/AAAA, DD-MM-AAAA, AAAA-MM-DD o DD MMM AAAA (p. ej. 15/03/1990 o 15 Mar 1990).','Invalid date of birth format. Valid formats: DD/MM/YYYY, DD-MM-YYYY, YYYY-MM-DD or DD MMM YYYY (e.g. 15/03/1990 or 15 Mar 1990).'),
      };
      Alert.alert(
        L('Fecha de nacimiento no válida','Invalid date of birth'),
        (mensajes[fnCheck.motivo] || mensajes.formato) + ' ' + L('No se ha guardado ningún cambio.','No changes were saved.')
      );
      return;
    }
    setLoading(true);
    try {
      const dataToSave = {
        nombre, apellido, sexo, fechaNac: fnCheck.iso, altura, unidadAltura, peso, unidadPeso,
        pais, ciudad, dni, telefono, email: user?.email || '',
      };
      if (fotoBase64) dataToSave.foto = fotoBase64;
      await setDoc(doc(db, 'perfiles', uid), dataToSave, { merge: true });
      await cacheProfile(uid, dataToSave);
      await invalidateProfileCache(uid);
      if (fotoBase64) {
        // Avatar estilo WhatsApp: sube la foto a R2 y publica avatares/<uid>
        // (doc ligero). Los demás teléfonos la descargan UNA vez y solo
        // vuelven a bajarla cuando cambie. Si el servidor no está desplegado
        // no pasa nada: el chat usa el respaldo legacy (base64 de perfiles).
        publicarMiAvatar(fotoBase64, user).catch((e) => console.warn('[perfil] avatar:', e && e.message));
      }
      Alert.alert(L('Perfil actualizado','Profile updated'), L('Los cambios se han guardado correctamente.','Changes saved successfully.'));
    } catch (err) {
      console.error('Error al guardar perfil:', err);
      Alert.alert(L('Error','Error'), L('No se pudo guardar el perfil: ','Could not save profile: ') + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    Alert.alert(L('Cerrar sesión','Sign out'), L('¿Estás seguro de que quieres salir?','Are you sure you want to exit?'), [
      { text: L('Cancelar','Cancel'), style: 'cancel' },
      {
        text: L('Salir','Exit'),
        style: 'destructive',
        onPress: async () => {
          await clearProfileCache();
          await clearCoachCache();
          await AsyncStorage.multiRemove(['garmin_email', 'garmin_password', 'garmin_days', 'fit_folder_uri']);
          signOut(auth);
        },
      },
    ]);
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      L('Eliminar cuenta','Delete account'),
      L('Esta acción es irreversible. Se borrarán todos tus datos, entrenos y relaciones con entrenador.','This action is irreversible. All your data, workouts and coach relations will be deleted.'),
      [
        { text: L('Cancelar','Cancel'), style: 'cancel' },
        {
          text: L('Eliminar','Delete'),
          style: 'destructive',
          onPress: async () => {
            setLoading(true);
            try {
              if (profile?.entrenador) {
                await fetch(`${SERVER_URL}/eliminar-entrenador`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ atletaId: uid }),
                });
              }
              await deleteDoc(doc(db, 'perfiles', uid));
              await deleteUser(auth.currentUser);
            } catch (error) {
              Alert.alert(L('Error','Error'), L('Necesitas haber iniciado sesión recientemente para eliminar la cuenta. Vuelve a iniciar sesión e inténtalo.','You need a recent session to delete the account. Sign in again and retry.'));
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  };

  if (fetching) {
    return (
      <View style={[styles.centered, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={BLUE} />
      </View>
    );
  }
  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <ScrollView contentContainerStyle={[styles.scrollContent, { paddingBottom: Math.max(40, insets.bottom + 16) }]} showsVerticalScrollIndicator={false}>
        <View style={[styles.header, { backgroundColor: theme.card, borderBottomColor: theme.border }]}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="chevron-back" size={24} color="#8FA8C8" />
          </TouchableOpacity>
          <Text style={[styles.headerTitle, { color: theme.text }]}>{L('Perfil','Profile')}</Text>
          <View style={{ width: 24 }} />
        </View>
        <TouchableOpacity style={styles.photoContainer} onPress={pickImage} activeOpacity={0.7}>
          {fotoBase64 ? (
            <Image source={{ uri: `data:image/jpeg;base64,${fotoBase64}` }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatarPlaceholder, { backgroundColor: theme.card, borderColor: theme.border }]}>
              <Ionicons name="camera" size={36} color={theme.muted} />
            </View>
          )}
          <Text style={styles.photoText}>{L('Selecciona foto','Select photo')}</Text>
        </TouchableOpacity>
        <View style={styles.section}>
          <Field label={L('Nombre','First name')} value={nombre} onChange={setNombre} />
          <Field label={L('Apellido','Last name')} value={apellido} onChange={setApellido} />
          <Text style={[styles.fieldLabel, { color: theme.muted }]}>{L('Sexo','Gender')}</Text>
          <FullScreenPicker value={sexo} options={sexos} onChange={setSexo} placeholder={L('Seleccionar sexo','Select gender')} />
          <View style={{ height: 12 }} />
          <Field label={L('Fecha de nacimiento','Date of birth')} value={fechaNac} onChange={setFechaNac} placeholder={L('DD MMM AAAA','DD MMM YYYY')} />
          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <Field label={L('Altura','Height')} value={altura} onChange={setAltura} keyboardType="numeric" />
            </View>
            <View style={{ width: 80, marginLeft: 10 }}>
              <Text style={[styles.fieldLabel, { color: theme.muted }]}>{L('Unidad','Unit')}</Text>
              <FullScreenPicker value={unidadAltura} options={unidades} onChange={setUnidadAltura} />
            </View>
          </View>
          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <Field label={L('Peso','Weight')} value={peso} onChange={setPeso} keyboardType="numeric" />
            </View>
            <View style={{ width: 80, marginLeft: 10 }}>
              <Text style={[styles.fieldLabel, { color: theme.muted }]}>{L('Unidad','Unit')}</Text>
              <FullScreenPicker value={unidadPeso} options={unidadesPeso} onChange={setUnidadPeso} />
            </View>
          </View>
        </View>
        <View style={styles.section}>
          <Field label={L('Correo Electrónico','Email')} value={user?.email || ''} editable={false} />
          <Field label={L('País','Country')} value={pais} onChange={setPais} />
          <Field label={L('Ciudad','City')} value={ciudad} onChange={setCiudad} />
          <Field label={L('DNI','ID')} value={dni} onChange={setDni} />
          <Field label={L('Teléfono','Phone')} value={telefono} onChange={setTelefono} keyboardType="phone-pad" />
        </View>
        <TouchableOpacity style={styles.updateBtn} onPress={handleUpdate} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.updateBtnText}>{L('Actualiza','Update')}</Text>}
        </TouchableOpacity>
        <TouchableOpacity style={[styles.logoutBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={handleLogout}>
          <Ionicons name="log-out-outline" size={20} color="#E05252" />
          <Text style={styles.logoutText}>{L('Cerrar sesión','Sign out')}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.deleteBtn} onPress={handleDeleteAccount}>
          <Text style={styles.deleteText}>{L('Eliminar Cuenta','Delete Account')}</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  centered: { flex: 1, backgroundColor: NAVY, alignItems: 'center', justifyContent: 'center' },
  scrollContent: { paddingBottom: 40 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 56, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: BORDER },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  photoContainer: { alignItems: 'center', marginTop: 20, marginBottom: 10 },
  avatar: { width: 100, height: 100, borderRadius: 50, borderWidth: 2, borderColor: BLUE },
  avatarPlaceholder: { width: 100, height: 100, borderRadius: 50, backgroundColor: CARD, borderWidth: 2, borderColor: BLUE, alignItems: 'center', justifyContent: 'center' },
  photoText: { color: BLUE, fontSize: 14, marginTop: 8, fontWeight: '600' },
  section: { marginHorizontal: 16, marginTop: 16 },
  row: { flexDirection: 'row', alignItems: 'flex-start' },
  fieldContainer: { marginBottom: 12 },
  fieldLabel: { color: '#8FA8C8', fontSize: 13, marginBottom: 6 },
  fieldInput: { backgroundColor: CARD, borderRadius: 8, borderWidth: 1, borderColor: BORDER, paddingHorizontal: 14, paddingVertical: 12, color: '#fff', fontSize: 15 },
  disabledInput: { opacity: 0.7 },
  updateBtn: { backgroundColor: BLUE, borderRadius: 12, marginHorizontal: 16, marginTop: 24, paddingVertical: 16, alignItems: 'center' },
  updateBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginHorizontal: 16, marginTop: 12, backgroundColor: '#1C1010', borderRadius: 12, borderWidth: 1, borderColor: '#3C1515', paddingVertical: 16, gap: 10 },
  logoutText: { color: '#E05252', fontSize: 16, fontWeight: '600' },
  deleteBtn: { alignItems: 'center', marginTop: 16, marginBottom: 30 },
  deleteText: { color: '#E05252', fontSize: 14, fontWeight: '600' },
});
