// screens/ProfileScreen.js
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import * as FileSystem from 'expo-file-system/legacy';
import * as ImageManipulator from 'expo-image-manipulator';
import * as ImagePicker from 'expo-image-picker';
import { deleteUser, signOut } from 'firebase/auth';
import { deleteDoc, doc, getDoc, setDoc } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Image,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  useColorScheme,
} from 'react-native';
import { auth, db } from '../firebaseConfig';
import { clearCoachCache } from '../services/coachCache';
import { cacheProfile, clearProfileCache, getCachedProfile, invalidateProfileCache } from '../services/profileCache';
import { getThemeColors, L, useAppSettings } from '../services/appSettings';

const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';
const RED    = '#E05252';
const SERVER_URL = 'https://garmin-fit-server.onrender.com';

function FullScreenPicker({ value, options, onChange, placeholder = 'Escoge' }) {
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const [visible, setVisible] = useState(false);
  const select = (opt) => { onChange(opt); setVisible(false); };
  const currentLabel = value || placeholder;
  return (
    <>
      <TouchableOpacity style={[pk.btn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => setVisible(true)} activeOpacity={0.8}>
        <Text style={[pk.text, { color: value ? theme.text : theme.muted }]} numberOfLines={1}>{currentLabel}</Text>
        <Ionicons name="chevron-down" size={15} color="#8FA8C8" />
      </TouchableOpacity>
      <Modal visible={visible} animationType="slide" transparent={false}>
          <View style={[pk.fullScreen, { backgroundColor: theme.background }]}>
          <View style={[pk.fullHeader, { borderBottomColor: theme.border }]}>
            <Text style={[pk.fullTitle, { color: theme.text }]}>{L('Selecciona una opción','Select an option')}</Text>
            <TouchableOpacity onPress={() => setVisible(false)}>
              <Ionicons name="close" size={24} color="#8FA8C8" />
            </TouchableOpacity>
          </View>
          <ScrollView style={pk.fullList}>
            {options.map((opt, index) => {
              const selected = value === opt;
              return (
                <TouchableOpacity key={opt} style={[pk.fullOption, { borderBottomColor: theme.border }, selected && pk.fullOptionActive]} onPress={() => select(opt)}>
                  <Text style={[pk.fullOptionIndex, { color: theme.muted }, selected && pk.fullOptionIndexActive]}>{index + 1}</Text>
                  <Text style={[pk.fullOptionText, { color: theme.text }, selected && pk.fullOptionTextActive]}>{opt}</Text>
                  {selected && <Ionicons name="checkmark" size={20} color={BLUE} />}
                </TouchableOpacity>
              );
            })}
          </ScrollView>
          <TouchableOpacity style={[pk.fullCancelBtn, { borderTopColor: theme.border }]} onPress={() => setVisible(false)}>
            <Text style={pk.fullCancelText}>{L('Cancelar','Cancel')}</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </>
  );
}
const pk = StyleSheet.create({
  btn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: CARD, borderRadius: 6, borderWidth: 1, borderColor: BORDER, paddingHorizontal: 12, paddingVertical: 12, marginVertical: 4 },
  text: { color: '#fff', fontSize: 14, flex: 1 },
  ph: { color: '#4A6080' },
  fullScreen: { flex: 1, backgroundColor: NAVY },
  fullHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 56, paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: BORDER },
  fullTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  fullList: { flex: 1, paddingHorizontal: 16 },
  fullOption: { flexDirection: 'row', alignItems: 'center', paddingVertical: 16, paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: BORDER, gap: 14 },
  fullOptionActive: { backgroundColor: BLUE + '22', borderRadius: 8 },
  fullOptionIndex: { color: '#8FA8C8', fontSize: 16, fontWeight: '600', minWidth: 24 },
  fullOptionIndexActive: { color: BLUE },
  fullOptionText: { color: '#fff', fontSize: 16, flex: 1 },
  fullOptionTextActive: { color: BLUE, fontWeight: '700' },
  fullCancelBtn: { paddingVertical: 18, alignItems: 'center', borderTopWidth: 1, borderTopColor: BORDER, marginTop: 8 },
  fullCancelText: { color: RED, fontSize: 16, fontWeight: '600' },
});

function Field({ label, value, onChange, keyboardType, placeholder, editable = true }) {
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  return (
    <View style={styles.fieldContainer}>
      <Text style={[styles.fieldLabel, { color: theme.muted }]}>{label}</Text>
      <TextInput
        style={[styles.fieldInput, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }, !editable && styles.disabledInput]}
        value={value}
        onChangeText={onChange}
        placeholder={placeholder || ''}
        placeholderTextColor="#4A6080"
        keyboardType={keyboardType}
        editable={editable}
      />
    </View>
  );
}

export default function ProfileScreen() {
  const navigation = useNavigation();
  const appSettings = useAppSettings(); // re-renderiza al cambiar idioma/tema
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const user = auth.currentUser;
  const uid = user?.uid;
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [profile, setProfile] = useState(null);
  const [nombre, setNombre] = useState('');
  const [apellido, setApellido] = useState('');
  const [sexo, setSexo] = useState('');
  const [fechaNac, setFechaNac] = useState('');
  const [altura, setAltura] = useState('');
  const [unidadAltura, setUnidadAltura] = useState('cm');
  const [peso, setPeso] = useState('');
  const [unidadPeso, setUnidadPeso] = useState('kg');
  const [pais, setPais] = useState('');
  const [ciudad, setCiudad] = useState('');
  const [dni, setDni] = useState('');
  const [telefono, setTelefono] = useState('');
  const [fotoBase64, setFotoBase64] = useState(null);
  const sexos = ['Masculino', 'Femenino', 'Otro'];
  const unidades = ['cm', 'm', 'in', 'ft'];
  const unidadesPeso = ['kg', 'lb'];

  useEffect(() => {
    if (!uid) { setFetching(false); return; }
    (async () => {
      const cached = await getCachedProfile();
      if (cached) {
        setProfile(cached);
        setNombre(cached.nombre || ''); setApellido(cached.apellido || '');
        setSexo(cached.sexo || ''); setFechaNac(cached.fechaNac || '');
        setAltura(cached.altura || ''); setUnidadAltura(cached.unidadAltura || 'cm');
        setPeso(cached.peso || ''); setUnidadPeso(cached.unidadPeso || 'kg');
        setPais(cached.pais || ''); setCiudad(cached.ciudad || '');
        setDni(cached.dni || ''); setTelefono(cached.telefono || '');
        if (cached.foto) setFotoBase64(cached.foto);
        setFetching(false);
      }
      try {
        const snap = await getDoc(doc(db, 'perfiles', uid));
        if (snap.exists()) {
          const data = snap.data();
          setProfile(data);
          setNombre(data.nombre || ''); setApellido(data.apellido || '');
          setSexo(data.sexo || ''); setFechaNac(data.fechaNac || '');
          setAltura(data.altura || ''); setUnidadAltura(data.unidadAltura || 'cm');
          setPeso(data.peso || ''); setUnidadPeso(data.unidadPeso || 'kg');
          setPais(data.pais || ''); setCiudad(data.ciudad || '');
          setDni(data.dni || ''); setTelefono(data.telefono || '');
          if (data.foto) setFotoBase64(data.foto);
          await cacheProfile(uid, data);
        }
      } catch (err) {
        console.error('Error refrescando perfil:', err);
      } finally {
        setFetching(false);
      }
    })();
  }, [uid]);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert(L('Permiso requerido','Permission required'), L('Concede acceso a la galería para elegir una foto.','Grant gallery access to pick a photo.'));
      return;
    }
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });
    if (result.canceled || !result.assets || result.assets.length === 0) return;
    const imageUri = result.assets[0].uri;
    try {
      const tempFile = FileSystem.cacheDirectory + 'profile_pic_temp.jpg';
      await FileSystem.copyAsync({ from: imageUri, to: tempFile });
      const manipResult = await ImageManipulator.manipulateAsync(
        tempFile,
        [{ resize: { width: 200, height: 200 } }],
        { compress: 0.5, format: ImageManipulator.SaveFormat.JPEG }
      );
      const base64 = await FileSystem.readAsStringAsync(manipResult.uri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      setFotoBase64(base64);
      await FileSystem.deleteAsync(tempFile, { idempotent: true });
    } catch (error) {
      console.error('Error al manipular:', error);
      try {
        const base64 = await FileSystem.readAsStringAsync(imageUri, {
          encoding: FileSystem.EncodingType.Base64,
        });
        setFotoBase64(base64);
        Alert.alert(L('Imagen guardada','Image saved'), L('No se pudo comprimir, se guardó la imagen original.','Could not compress; original image saved.'));
      } catch (fallbackError) {
        console.error('Error al leer la imagen original:', fallbackError);
        Alert.alert(L('Error','Error'), L('No se pudo procesar la imagen seleccionada.','Could not process the selected image.'));
      }
    }
  };

  const handleUpdate = async () => {
    if (!uid) { Alert.alert(L('Error','Error'), L('No se ha identificado al usuario.','User not identified.')); return; }
    setLoading(true);
    try {
      const dataToSave = {
        nombre, apellido, sexo, fechaNac, altura, unidadAltura, peso, unidadPeso,
        pais, ciudad, dni, telefono, email: user?.email || '',
      };
      if (fotoBase64) dataToSave.foto = fotoBase64;
      await setDoc(doc(db, 'perfiles', uid), dataToSave, { merge: true });
      await cacheProfile(uid, dataToSave);
      await invalidateProfileCache(uid);
      Alert.alert(L('Perfil actualizado','Profile updated'), L('Los cambios se han guardado correctamente.','Changes saved successfully.'));
    } catch (err) {
      console.error('Error al guardar perfil:', err);
      Alert.alert(L('Error','Error'), L('No se pudo guardar el perfil: ','Could not save profile: ') + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    Alert.alert(L('Cerrar sesión','Sign out'), L('¿Estás seguro de que quieres salir?','Are you sure you want to exit?'), [
      { text: L('Cancelar','Cancel'), style: 'cancel' },
      {
        text: L('Salir','Exit'),
        style: 'destructive',
        onPress: async () => {
          await clearProfileCache();
          await clearCoachCache();
          await AsyncStorage.multiRemove(['garmin_email', 'garmin_password', 'garmin_days', 'fit_folder_uri']);
          signOut(auth);
        },
      },
    ]);
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      L('Eliminar cuenta','Delete account'),
      L('Esta acción es irreversible. Se borrarán todos tus datos, entrenos y relaciones con entrenador.','This action is irreversible. All your data, workouts and coach relations will be deleted.'),
      [
        { text: L('Cancelar','Cancel'), style: 'cancel' },
        {
          text: L('Eliminar','Delete'),
          style: 'destructive',
          onPress: async () => {
            setLoading(true);
            try {
              if (profile?.entrenador) {
                await fetch(`${SERVER_URL}/eliminar-entrenador`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ atletaId: uid }),
                });
              }
              await deleteDoc(doc(db, 'perfiles', uid));
              await deleteUser(auth.currentUser);
            } catch (error) {
              Alert.alert(L('Error','Error'), L('Necesitas haber iniciado sesión recientemente para eliminar la cuenta. Vuelve a iniciar sesión e inténtalo.','You need a recent session to delete the account. Sign in again and retry.'));
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  };

  if (fetching) {
    return (
      <View style={[styles.centered, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={BLUE} />
      </View>
    );
  }
  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={[styles.header, { backgroundColor: theme.card, borderBottomColor: theme.border }]}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="chevron-back" size={24} color="#8FA8C8" />
          </TouchableOpacity>
          <Text style={[styles.headerTitle, { color: theme.text }]}>{L('Perfil','Profile')}</Text>
          <View style={{ width: 24 }} />
        </View>
        <TouchableOpacity style={styles.photoContainer} onPress={pickImage} activeOpacity={0.7}>
          {fotoBase64 ? (
            <Image source={{ uri: `data:image/jpeg;base64,${fotoBase64}` }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatarPlaceholder, { backgroundColor: theme.card, borderColor: theme.border }]}>
              <Ionicons name="camera" size={30} color={theme.muted} />
            </View>
          )}
          <Text style={styles.photoText}>{L('Selecciona foto','Select photo')}</Text>
        </TouchableOpacity>
        <View style={styles.section}>
          <Field label={L('Nombre','First name')} value={nombre} onChange={setNombre} />
          <Field label={L('Apellido','Last name')} value={apellido} onChange={setApellido} />
          <Text style={[styles.fieldLabel, { color: theme.muted }]}>{L('Sexo','Gender')}</Text>
          <FullScreenPicker value={sexo} options={sexos} onChange={setSexo} placeholder={L('Seleccionar sexo','Select gender')} />
          <View style={{ height: 12 }} />
          <Field label={L('Fecha de nacimiento','Date of birth')} value={fechaNac} onChange={setFechaNac} placeholder="DD MMM AAAA" />
          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <Field label={L('Altura','Height')} value={altura} onChange={setAltura} keyboardType="numeric" />
            </View>
            <View style={{ width: 80, marginLeft: 10 }}>
              <Text style={[styles.fieldLabel, { color: theme.muted }]}>{L('Unidad','Unit')}</Text>
              <FullScreenPicker value={unidadAltura} options={unidades} onChange={setUnidadAltura} />
            </View>
          </View>
          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <Field label={L('Peso','Weight')} value={peso} onChange={setPeso} keyboardType="numeric" />
            </View>
            <View style={{ width: 80, marginLeft: 10 }}>
              <Text style={[styles.fieldLabel, { color: theme.muted }]}>{L('Unidad','Unit')}</Text>
              <FullScreenPicker value={unidadPeso} options={unidadesPeso} onChange={setUnidadPeso} />
            </View>
          </View>
        </View>
        <View style={styles.section}>
          <Field label={L('Correo Electrónico','Email')} value={user?.email || ''} editable={false} />
          <Field label={L('País','Country')} value={pais} onChange={setPais} />
          <Field label={L('Ciudad','City')} value={ciudad} onChange={setCiudad} />
          <Field label={L('DNI','ID')} value={dni} onChange={setDni} />
          <Field label={L('Teléfono','Phone')} value={telefono} onChange={setTelefono} keyboardType="phone-pad" />
        </View>
        <TouchableOpacity style={styles.updateBtn} onPress={handleUpdate} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.updateBtnText}>{L('Actualiza','Update')}</Text>}
        </TouchableOpacity>
        <TouchableOpacity style={[styles.logoutBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={handleLogout}>
          <Ionicons name="log-out-outline" size={20} color="#E05252" />
          <Text style={styles.logoutText}>{L('Cerrar sesión','Sign out')}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.deleteBtn} onPress={handleDeleteAccount}>
          <Text style={styles.deleteText}>{L('Eliminar Cuenta','Delete Account')}</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  centered: { flex: 1, backgroundColor: NAVY, alignItems: 'center', justifyContent: 'center' },
  scrollContent: { paddingBottom: 40 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 56, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: BORDER },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  photoContainer: { alignItems: 'center', marginTop: 20, marginBottom: 10 },
  avatar: { width: 80, height: 80, borderRadius: 40, borderWidth: 2, borderColor: BLUE },
  avatarPlaceholder: { width: 80, height: 80, borderRadius: 40, backgroundColor: CARD, borderWidth: 2, borderColor: BLUE, alignItems: 'center', justifyContent: 'center' },
  photoText: { color: BLUE, fontSize: 14, marginTop: 8, fontWeight: '600' },
  section: { marginHorizontal: 16, marginTop: 16 },
  row: { flexDirection: 'row', alignItems: 'flex-start' },
  fieldContainer: { marginBottom: 12 },
  fieldLabel: { color: '#8FA8C8', fontSize: 13, marginBottom: 6 },
  fieldInput: { backgroundColor: CARD, borderRadius: 8, borderWidth: 1, borderColor: BORDER, paddingHorizontal: 14, paddingVertical: 12, color: '#fff', fontSize: 15 },
  disabledInput: { opacity: 0.7 },
  updateBtn: { backgroundColor: BLUE, borderRadius: 12, marginHorizontal: 16, marginTop: 24, paddingVertical: 16, alignItems: 'center' },
  updateBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginHorizontal: 16, marginTop: 12, backgroundColor: '#1C1010', borderRadius: 12, borderWidth: 1, borderColor: '#3C1515', paddingVertical: 16, gap: 10 },
  logoutText: { color: '#E05252', fontSize: 16, fontWeight: '600' },
  deleteBtn: { alignItems: 'center', marginTop: 16, marginBottom: 30 },
  deleteText: { color: '#E05252', fontSize: 14, fontWeight: '600' },
});
