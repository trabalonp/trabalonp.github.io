// screens/AddWorkoutModal.js
import { Ionicons } from '@expo/vector-icons';
import {
  addDoc, collection, Timestamp, query, where, orderBy, getDocs, updateDoc, deleteDoc, increment, doc, getDoc,
} from 'firebase/firestore';
import { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator, Alert, KeyboardAvoidingView, Modal, Platform,
  ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View, useColorScheme,
} from 'react-native';
import { getCachedProfile } from '../services/profileCache';
import { getApiUrl } from '../services/api';
import { auth, db } from '../firebaseConfig';
import { getThemeColors, useAppSettings } from '../services/appSettings';
import StepEditor, { emptyStep, normalizeStep } from '../components/StepEditor';

const NAVY='#0D1B2A', CARD='#162032', BLUE='#4A90E2', BORDER='#1E3048', RED='#E05252';

// Valores GUARDADOS en Firestore (no se traducen): se guarda el string original y se pinta traducido
const TIPOS_ACTIVIDAD = [
  { label: 'Running', icon: 'walk', color: '#E05252' },
  { label: 'Ciclismo', icon: 'bicycle', color: '#F5A623' },
  { label: 'Natación', icon: 'water', color: '#4A90E2' },
  { label: 'Fuerza', icon: 'barbell', color: '#9B59B6' },
  { label: 'Triatlón', icon: 'trophy', color: '#2DB37A' },
  { label: 'Evento', icon: 'calendar-outline', color: '#F5A623' },
  { label: 'Descanso', icon: 'moon', color: '#7F8FA6' },
  { label: 'Otro', icon: 'flash', color: '#8FA8C8' },
];
const TIPO_ICON = { Running:'walk', Ciclismo:'bicycle', Natación:'water', Fuerza:'barbell', Triatlón:'trophy', Otro:'flash', Evento:'calendar-outline', Descanso:'moon' };
const TIPO_COLOR = { Running:'#E05252', Ciclismo:'#F5A623', Natación:'#4A90E2', Fuerza:'#9B59B6', Triatlón:'#2DB37A', Otro:'#8FA8C8', Evento:'#F5A623', Descanso:'#7F8FA6' };

// Picker a pantalla completa: guarda `value ?? label` y pinta la etiqueta traducida
function FullScreenPicker({ value, options, onChange, placeholder='Escoge', icon, iconColor, title, cancelText, theme }) {
  const [visible, setVisible] = useState(false);
  const isObj = options[0] && typeof options[0] === 'object';
  const valOf = (o) => (isObj ? (o.value ?? o.label) : o);
  const lblOf = (o) => (isObj ? o.label : o);
  const select = (o) => { onChange(valOf(o)); setVisible(false); };
  const currentLabel = isObj ? (options.find(o => valOf(o) === value)?.label ?? value) : value;
  return (
    <>
      <TouchableOpacity style={[pk.btn, { backgroundColor: theme?.card, borderColor: theme?.border }]} onPress={() => setVisible(true)} activeOpacity={0.8}>
        <View style={pk.pickerLeft}>
          {icon && <Ionicons name={icon} size={18} color={iconColor || '#8FA8C8'} style={{ marginRight: 8 }} />}
          <Text style={[pk.text, { color: currentLabel ? theme?.text : theme?.muted }]} numberOfLines={1}>{currentLabel || placeholder}</Text>
        </View>
        <Ionicons name="chevron-down" size={15} color="#8FA8C8" />
      </TouchableOpacity>
      <Modal visible={visible} animationType="slide" transparent={false}>
        <View style={[pk.fullScreen, { backgroundColor: theme?.background }]}>
          <View style={[pk.fullHeader, { borderBottomColor: theme?.border }]}>
            <Text style={[pk.fullTitle, { color: theme?.text }]}>{title ?? 'Selecciona una opción'}</Text>
            <TouchableOpacity onPress={() => setVisible(false)}>
              <Ionicons name="close" size={24} color="#8FA8C8" />
            </TouchableOpacity>
          </View>
          <ScrollView style={pk.fullList}>
            {options.map((o, i) => {
              const sel = valOf(o) === value;
              return (
                <TouchableOpacity key={String(valOf(o))} style={[pk.fullOption, { borderBottomColor: theme?.border }, sel && pk.fullOptionActive]} onPress={() => select(o)}>
                  <Text style={[pk.fullOptionIndex, { color: sel ? BLUE : theme?.muted }]}>{i + 1}</Text>
                  {isObj && o.icon ? <Ionicons name={o.icon} size={20} color={o.color || '#8FA8C8'} /> : null}
                  <Text style={[pk.fullOptionText, { color: sel ? BLUE : theme?.text }, sel && pk.fullOptionTextActive]}>{lblOf(o)}</Text>
                  {sel && <Ionicons name="checkmark" size={20} color={BLUE} />}
                </TouchableOpacity>
              );
            })}
          </ScrollView>
          <TouchableOpacity style={[pk.fullCancelBtn, { borderTopColor: theme?.border }]} onPress={() => setVisible(false)}>
            <Text style={pk.fullCancelText}>{cancelText ?? 'Cancelar'}</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </>
  );
}
const pk = StyleSheet.create({
  btn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: CARD, borderRadius: 6, borderWidth: 1, borderColor: BORDER, paddingHorizontal: 12, paddingVertical: 12, marginVertical: 4 },
  pickerLeft: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  text: { color: '#fff', fontSize: 14, flex: 1 },
  ph: { color: '#4A6080' },
  fullScreen: { flex: 1, backgroundColor: NAVY },
  fullHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 56, paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: BORDER },
  fullTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  fullList: { flex: 1, paddingHorizontal: 16 },
  fullOption: { flexDirection: 'row', alignItems: 'center', paddingVertical: 16, paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: BORDER, gap: 14 },
  fullOptionActive: { backgroundColor: BLUE + '22', borderRadius: 8 },
  fullOptionIndex: { color: '#8FA8C8', fontSize: 16, fontWeight: '600', minWidth: 24 },
  fullOptionIndexActive: { color: BLUE },
  fullOptionText: { color: '#fff', fontSize: 16, flex: 1 },
  fullOptionTextActive: { color: BLUE, fontWeight: '700' },
  fullCancelBtn: { paddingVertical: 18, alignItems: 'center', borderTopWidth: 1, borderTopColor: BORDER, marginTop: 8 },
  fullCancelText: { color: RED, fontSize: 16, fontWeight: '600' },
});

async function getCoachFullName(uid) {
  const c = await getCachedProfile(uid);
  if (c?.nombre) return `${c.nombre} ${c.apellido || ''}`.trim();
  const s = await getDoc(doc(db, 'perfiles', uid));
  if (s.exists()) { const d = s.data(); return `${d.nombre || ''} ${d.apellido || ''}`.trim(); }
  return 'Entrenador';
}
async function sendNotificationToAthlete(athleteId, coachId, title, body) {
  try {
    const apiUrl = (await getApiUrl()).replace(/\/+$/, '');
    await fetch(`${apiUrl}/notify-athlete`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ coachId, athleteId, title, body }) });
  } catch (err) {
    console.warn('Error notificando al atleta:', err.message);
  }
}

export default function AddWorkoutModal({ visible, onClose, initialDate, onWorkoutAdded, athleteId }) {
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const lang = settings.language;            // re-renderiza al cambiar idioma
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción

  const fecha = initialDate ?? new Date();
  const [loading, setLoading] = useState(false);
  const [mainTab, setMainTab] = useState('nuevo');
  const [actividad, setActividad] = useState('Running');
  const [titulo, setTitulo] = useState('');
  const [fechaStr, setFechaStr] = useState(fecha.toLocaleDateString('es-ES')); // formato de almacenamiento DD/MM/AAAA
  const [horaMode, setHoraMode] = useState('Mañana');
  const [horaCustom, setHoraCustom] = useState('08:00');
  const [descripcion, setDescripcion] = useState('');
  const [pasos, setPasos] = useState([]);
  const [libItems, setLibItems] = useState([]);
  const [loadingLib, setLoadingLib] = useState(false);
  const [savingLib, setSavingLib] = useState(false);
  const [libSort, setLibSort] = useState('usados');
  const [libSearch, setLibSearch] = useState('');
  const actSel = TIPOS_ACTIVIDAD.find(t => t.label === actividad) || TIPOS_ACTIVIDAD[0];

  // Opciones de hora traducidas (el valor guardado sigue siendo el original)
  const HORA_OPTS = [
    { value: 'Mañana', label: L('Mañana', 'Morning') },
    { value: 'Tarde', label: L('Tarde', 'Afternoon') },
    { value: 'Personalizado', label: L('Personalizado', 'Custom') },
  ];

  useEffect(() => {
    if (visible) {
      const d = initialDate ?? new Date();
      setMainTab('nuevo'); setActividad('Running'); setTitulo('');
      setFechaStr(d.toLocaleDateString('es-ES')); setHoraMode('Mañana'); setHoraCustom('08:00');
      setDescripcion(''); setPasos([]); setLoading(false); setLibSearch(''); setLibSort('usados');
    }
  }, [visible, initialDate]);

  const horaFinal = () => horaMode === 'Mañana' ? '08:00' : horaMode === 'Tarde' ? '18:00' : (horaCustom || '08:00');

  const fetchLibrary = useCallback(async () => {
    const uid = auth.currentUser?.uid; if (!uid) return;
    setLoadingLib(true);
    try {
      const q = query(collection(db, 'libreria'), where('userId', '==', uid), orderBy('timesUsed', 'desc'), orderBy('createdAt', 'asc'));
      const snap = await getDocs(q);
      let items = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      const s = libSearch.trim().toLowerCase();
      if (s) items = items.filter(i => (i.titulo || i.tipo || '').toLowerCase().includes(s));
      if (libSort === 'recientes') items.sort((a, b) => (b.createdAt?.toMillis?.() ?? 0) - (a.createdAt?.toMillis?.() ?? 0));
      setLibItems(items);
    } catch (e) {} finally { setLoadingLib(false); }
  }, [libSearch, libSort]);
  useEffect(() => { if (visible && mainTab === 'libreria') fetchLibrary(); }, [visible, mainTab, fetchLibrary]);

  const handleClose = () => {
    if (pasos.length > 0 || titulo) {
      Alert.alert(L('Descartar', 'Discard'), L('¿Seguro que quieres salir?', 'Are you sure you want to exit?'), [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        { text: L('Salir', 'Exit'), style: 'destructive', onPress: onClose },
      ]);
    } else onClose();
  };

  const handleSave = async () => {
    if (!titulo.trim()) { Alert.alert(L('Error', 'Error'), L('El título es obligatorio.', 'Title is required.')); return; }
    setLoading(true);
    try {
      const targetUserId = athleteId || auth.currentUser?.uid;
      if (!targetUserId) { Alert.alert(L('Error', 'Error'), L('No se pudo determinar el usuario.', 'Could not determine the user.')); setLoading(false); return; }
      const partes = fechaStr.split('/');
      const fechaFinal = new Date(partes[2], partes[1] - 1, partes[0]);
      const [h, m] = horaFinal().split(':');
      fechaFinal.setHours(parseInt(h), parseInt(m || 0));
      const pasosGuardados = pasos.map(normalizeStep);
      await addDoc(collection(db, 'entrenamientos'), {
        userId: targetUserId,
        tipo: actividad,
        titulo: titulo || actividad,
        fecha: Timestamp.fromDate(fechaFinal),
        fechaStr,
        descripcion,
        pasos: pasosGuardados,
        estado: null,
        garminSynced: false,
        createdAt: Timestamp.now(),
      });
      if (onWorkoutAdded) onWorkoutAdded();
      if (athleteId) {
        const coachName = await getCoachFullName(auth.currentUser.uid);
        if (actividad === 'Evento') {
          await sendNotificationToAthlete(athleteId, auth.currentUser.uid,
            `📅 ${coachName} ${L('ha añadido un nuevo evento', 'added a new event')}`,
            L(`${coachName} te ha añadido al evento: ${titulo || actividad}`, `${coachName} added you to the event: ${titulo || actividad}`));
        } else {
          await sendNotificationToAthlete(athleteId, auth.currentUser.uid,
            `📅 ${coachName} ${L('ha añadido un nuevo entrenamiento', 'added a new workout')}`,
            L(`${coachName} ha programado: ${titulo || actividad}`, `${coachName} scheduled: ${titulo || actividad}`));
        }
      }
      onClose();
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally { setLoading(false); }
  };

  const handleSaveToLibrary = async () => {
    const uid = auth.currentUser?.uid; if (!uid) return;
    setSavingLib(true);
    try {
      await addDoc(collection(db, 'libreria'), {
        userId: uid, tipo: actividad, titulo: titulo || actividad,
        descripcion: descripcion || '', pasos: pasos.map(normalizeStep),
        timesUsed: 0, createdAt: Timestamp.now(),
      });
      Alert.alert(L('Guardado', 'Saved'), L('Entrenamiento guardado en tu librería.', 'Workout saved to your library.'));
      fetchLibrary();
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); } finally { setSavingLib(false); }
  };

  const handleLoadFromLibrary = async (item) => {
    setActividad(item.tipo ?? 'Running');
    setTitulo(item.titulo ?? '');
    setDescripcion(item.descripcion ?? '');
    setPasos((Array.isArray(item.pasos) ? item.pasos : []).map(p => ({
      ...emptyStep(), ...p,
      durTexto: p.durTexto ?? p.durValor ?? '',
      hijos: p.hijos || [],
    })));
    try { await updateDoc(doc(db, 'libreria', item.id), { timesUsed: increment(1) }); } catch (e) {}
    setMainTab('nuevo');
    fetchLibrary();
  };

  const handleDeleteLibrary = (item) => Alert.alert(L('Eliminar de la librería', 'Delete from library'), L(`¿Eliminar "${item.titulo || item.tipo}"?`, `Delete "${item.titulo || item.tipo}"?`), [
    { text: L('Cancelar', 'Cancel'), style: 'cancel' },
    { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: async () => { try { await deleteDoc(doc(db, 'libreria', item.id)); fetchLibrary(); } catch (e) { Alert.alert(L('Error', 'Error'), e.message); } } },
  ]);

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={handleClose}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.kav}>
        <View style={styles.overlay}>
          <View style={[styles.sheet, { backgroundColor: theme.background }]}>
            <View style={[styles.header, { borderBottomColor: theme.border, backgroundColor: theme.card }]}>
              <TouchableOpacity onPress={handleClose}>
                <Ionicons name="close" size={24} color="#8FA8C8" />
              </TouchableOpacity>
              <Text style={[styles.headerTitle, { color: theme.text }]}>{L('Agregar entrenamiento', 'Add workout')}</Text>
              <View style={{ width: 24 }} />
            </View>
            <View style={[styles.tabs, { borderBottomColor: theme.border }]}>
              <TouchableOpacity style={[styles.tab, mainTab === 'nuevo' && styles.tabActive]} onPress={() => setMainTab('nuevo')}>
                <Text style={[styles.tabText, { color: mainTab === 'nuevo' ? theme.text : theme.muted }, mainTab === 'nuevo' && styles.tabTextActive]}>{L('Nuevo', 'New')}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.tab, mainTab === 'libreria' && styles.tabActive]} onPress={() => setMainTab('libreria')}>
                <Text style={[styles.tabText, { color: mainTab === 'libreria' ? theme.text : theme.muted }, mainTab === 'libreria' && styles.tabTextActive]}>{L('Librería', 'Library')}</Text>
              </TouchableOpacity>
            </View>
            {mainTab === 'nuevo' && (
              <>
                <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
                  <Text style={[styles.label, { color: theme.muted }]}>{L('Actividad', 'Activity')}</Text>
                  <FullScreenPicker theme={theme} value={actividad} options={TIPOS_ACTIVIDAD} onChange={setActividad} icon={actSel.icon} iconColor={actSel.color} placeholder={L('Escoge', 'Choose')} title={L('Selecciona una opción', 'Select an option')} cancelText={L('Cancelar', 'Cancel')} />
                  <Text style={[styles.label, { color: theme.muted }]}>{L('Título', 'Title')}</Text>
                  <TextInput style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={titulo} onChangeText={setTitulo} placeholder={L('Ej: Series Cuesta', 'e.g. Hill repeats')} placeholderTextColor="#4A6080" />
                  <View style={styles.row}>
                    <View style={styles.col}>
                      <Text style={[styles.label, { color: theme.muted }]}>{L('Fecha', 'Date')}</Text>
                      <TextInput style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={fechaStr} onChangeText={setFechaStr} placeholder="DD/MM/AAAA" placeholderTextColor="#4A6080" />
                    </View>
                    <View style={styles.col}>
                      <Text style={[styles.label, { color: theme.muted }]}>{L('Hora', 'Time')}</Text>
                      <FullScreenPicker theme={theme} value={horaMode} options={HORA_OPTS} onChange={setHoraMode} placeholder={L('Escoge', 'Choose')} title={L('Selecciona una opción', 'Select an option')} cancelText={L('Cancelar', 'Cancel')} />
                      {horaMode === 'Personalizado' && (
                        <TextInput style={[styles.input, { marginTop: 6, backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={horaCustom} onChangeText={setHoraCustom} placeholder="HH:MM" placeholderTextColor="#4A6080" keyboardType="number-pad" />
                      )}
                    </View>
                  </View>
                  <Text style={[styles.label, { color: theme.muted }]}>{L('Pasos (opcional)', 'Steps (optional)')}</Text>
                  <StepEditor pasos={pasos} setPasos={setPasos} />
                  <Text style={[styles.label, { color: theme.muted }]}>{L('Descripción', 'Description')}</Text>
                  <TextInput style={[styles.textarea, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={descripcion} onChangeText={setDescripcion} multiline placeholder={L('Detalles del entreno...', 'Workout details...')} placeholderTextColor="#4A6080" />
                  <TouchableOpacity style={[styles.libSaveBtn, savingLib && styles.disabled]} onPress={handleSaveToLibrary} disabled={savingLib}>
                    {savingLib ? <ActivityIndicator color="#fff" /> : <Ionicons name="bookmark-outline" size={18} color="#fff" />}
                    <Text style={styles.libSaveBtnText}>{L('Guardar en librería', 'Save to library')}</Text>
                  </TouchableOpacity>
                </ScrollView>
                <View style={styles.footer}>
                  <TouchableOpacity style={[styles.saveBtn, loading && styles.disabled]} onPress={handleSave} disabled={loading}>
                    {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveBtnText}>{L('Guardar', 'Save')}</Text>}
                  </TouchableOpacity>
                </View>
              </>
            )}
            {mainTab === 'libreria' && (
              <View style={{ flex: 1 }}>
                <View style={styles.libControls}>
                  <View style={styles.libSortRow}>
                    <TouchableOpacity style={[styles.libSortBtn, { backgroundColor: theme.card, borderColor: theme.border }, libSort === 'usados' && styles.libSortBtnActive]} onPress={() => setLibSort('usados')}>
                      <Text style={[styles.libSortBtnText, { color: libSort === 'usados' ? '#fff' : theme.muted }, libSort === 'usados' && styles.libSortBtnTextActive]}>{L('Más usados', 'Most used')}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.libSortBtn, { backgroundColor: theme.card, borderColor: theme.border }, libSort === 'recientes' && styles.libSortBtnActive]} onPress={() => setLibSort('recientes')}>
                      <Text style={[styles.libSortBtnText, { color: libSort === 'recientes' ? '#fff' : theme.muted }, libSort === 'recientes' && styles.libSortBtnTextActive]}>{L('Más recientes', 'Most recent')}</Text>
                    </TouchableOpacity>
                  </View>
                  <View style={[styles.libSearchBox, { backgroundColor: theme.card, borderColor: theme.border }]}>
                    <Ionicons name="search-outline" size={16} color="#8FA8C8" />
                    <TextInput style={[styles.libSearchInput, { color: theme.text }]} value={libSearch} onChangeText={setLibSearch} placeholder={L('Buscar por nombre...', 'Search by name...')} placeholderTextColor="#4A6080" />
                  </View>
                </View>
                {loadingLib ? (
                  <View style={styles.libEmpty}><ActivityIndicator color={BLUE} /></View>
                ) : libItems.length === 0 ? (
                  <View style={styles.libEmpty}>
                    <Ionicons name="library-outline" size={32} color="#2A4060" />
                    <Text style={styles.libEmptyText}>{L('Tu librería está vacía.', 'Your library is empty.')}</Text>
                  </View>
                ) : (
                  <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent}>
                    {libItems.map(item => (
                      <View key={item.id} style={[styles.libRow, { backgroundColor: theme.card, borderColor: theme.border }]}>
                        <TouchableOpacity style={styles.libRowMain} onPress={() => handleLoadFromLibrary(item)} activeOpacity={0.8}>
                          <Ionicons name={TIPO_ICON[item.tipo] ?? 'flash'} size={20} color={TIPO_COLOR[item.tipo] ?? '#8FA8C8'} />
                          <View style={{ flex: 1 }}>
                            <Text style={[styles.libRowTitle, { color: theme.text }]} numberOfLines={1}>{item.titulo || item.tipo}</Text>
                            <Text style={[styles.libRowMeta, { color: theme.muted }]}>
                              {L(`Usada ${item.timesUsed ?? 0} ${(item.timesUsed ?? 0) === 1 ? 'vez' : 'veces'}`, `Used ${item.timesUsed ?? 0} ${(item.timesUsed ?? 0) === 1 ? 'time' : 'times'}`)}
                            </Text>
                          </View>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.libDeleteBtn} onPress={() => handleDeleteLibrary(item)}>
                          <Ionicons name="trash-outline" size={18} color={RED} />
                        </TouchableOpacity>
                      </View>
                    ))}
                  </ScrollView>
                )}
              </View>
            )}
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  kav: { flex: 1 },
  overlay: { flex: 1, backgroundColor: '#000000AA', justifyContent: 'flex-end' },
  sheet: { backgroundColor: NAVY, height: '95%', borderTopLeftRadius: 20, borderTopRightRadius: 20, paddingBottom: 20 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: BORDER },
  headerTitle: { color: '#fff', fontSize: 16, fontWeight: '700' },
  tabs: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: BORDER },
  tab: { flex: 1, padding: 14, alignItems: 'center', flexDirection: 'row', justifyContent: 'center' },
  tabActive: { flex: 1, padding: 14, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: BLUE },
  tabText: { color: '#8FA8C8', fontWeight: '600' },
  tabTextActive: { color: '#fff', fontWeight: '700' },
  scroll: { flex: 1 },
  scrollContent: { padding: 16, gap: 12 },
  label: { color: '#8FA8C8', fontSize: 13, marginBottom: 4 },
  input: { backgroundColor: CARD, borderRadius: 8, borderWidth: 1, borderColor: BORDER, padding: 12, color: '#fff' },
  row: { flexDirection: 'row', gap: 10 },
  col: { flex: 1 },
  textarea: { backgroundColor: CARD, borderRadius: 8, borderWidth: 1, borderColor: BORDER, padding: 12, color: '#fff', minHeight: 80 },
  libSaveBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: BLUE, borderRadius: 8, paddingVertical: 12, marginTop: 8 },
  libSaveBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  footer: { padding: 16, borderTopWidth: 1, borderTopColor: BORDER },
  saveBtn: { backgroundColor: BLUE, padding: 16, borderRadius: 10, alignItems: 'center' },
  saveBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  disabled: { backgroundColor: '#4A6080' },
  libControls: { paddingHorizontal: 16, paddingTop: 12, gap: 10 },
  libSortRow: { flexDirection: 'row', gap: 8 },
  libSortBtn: { flex: 1, alignItems: 'center', backgroundColor: CARD, borderWidth: 1, borderColor: BORDER, borderRadius: 8, paddingVertical: 8 },
  libSortBtnActive: { backgroundColor: BLUE, borderColor: BLUE },
  libSortBtnText: { color: '#8FA8C8', fontSize: 12, fontWeight: '600' },
  libSortBtnTextActive: { color: '#fff' },
  libSearchBox: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: CARD, borderWidth: 1, borderColor: BORDER, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8 },
  libSearchInput: { flex: 1, color: '#fff', fontSize: 14, padding: 0 },
  libEmpty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  libEmptyText: { color: '#2A4060', fontSize: 14 },
  libRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: CARD, borderRadius: 10, borderWidth: 1, borderColor: BORDER, paddingHorizontal: 12, paddingVertical: 12, marginBottom: 8 },
  libRowMain: { flexDirection: 'row', alignItems: 'center', flex: 1, gap: 10 },
  libRowTitle: { color: '#fff', fontSize: 14, fontWeight: '700' },
  libRowMeta: { color: '#8FA8C8', fontSize: 12, marginTop: 2 },
  libDeleteBtn: { padding: 6 },
});
