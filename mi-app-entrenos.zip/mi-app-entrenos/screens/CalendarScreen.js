// screens/CalendarScreen.js
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import { collection, doc, getDoc, getDocs, orderBy, query, Timestamp, updateDoc, where } from 'firebase/firestore';
import {
  ActivityIndicator, Animated, Dimensions, PanResponder, RefreshControl,
  ScrollView, StyleSheet, Text, TouchableOpacity, Vibration, View, useColorScheme,
} from 'react-native';
import { auth, db } from '../firebaseConfig';
import * as chartCache from '../services/chartCache';
import { getThemeColors, useAppSettings, formatSubtitleItem } from '../services/appSettings';
import AddWorkoutModal from './AddWorkoutModal';
import WorkoutDetailModal from './WorkoutDetailModal';

const NAVY='#0D1B2A', CARD='#162032', BLUE='#4A90E2', GREEN='#2DB37A', RED='#E05252', GRAY='#4A6080', BORDER='#1E3048';
const SCREEN_H = Dimensions.get('window').height;
const IND_H = 44;
const HIDE_Y = -9999;

function getWeekDays(baseDate) {
  const date = new Date(baseDate);
  const day = date.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  const monday = new Date(date);
  monday.setDate(date.getDate() + diff);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    return d;
  });
}
function weekLabel(days, loc) {
  const from = days[0].toLocaleDateString(loc, { day: 'numeric', month: 'short' });
  const to   = days[6].toLocaleDateString(loc, { day: 'numeric', month: 'short' });
  return `${from} – ${to}`;
}
function getWeekKey(days) {
  return `${days[0].toISOString().split('T')[0]}_${days[6].toISOString().split('T')[0]}`;
}
function toKey(d) {
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`;
}
function fmtSleep(secs) {
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  return `${h}h ${m}m`;
}
function stripHeavyFields(data) {
  const { registros, vueltas, ...light } = data;
  return light;
}
function lighten(hex, amount = 0.5) {
  const num = parseInt(hex.replace('#',''), 16);
  let r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
  r = Math.round(r + (255 - r) * amount); g = Math.round(g + (255 - g) * amount); b = Math.round(b + (255 - b) * amount);
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}
const TIPO_ICON = { Ciclismo:'bicycle', Running:'walk', Natación:'water', Fuerza:'barbell', Triatlón:'trophy', Otro:'flash', Evento:'calendar-outline', Descanso:'moon' };

const _workoutCache = { uid: null, data: [], ts: 0 };
const CACHE_TTL_MS = 5 * 60 * 1000;

export default function CalendarScreen({ route }) {
  const user = auth.currentUser;
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const lang = settings.language || 'es';
  const loc = lang === 'en' ? 'en-US' : 'es-ES';
  const hrUnit = lang === 'en' ? 'bpm' : 'ppm';
  const todayLabel = lang === 'en' ? 'Today' : 'Hoy';

  const [athleteId, setAthleteId] = useState(null);
  const [athleteName, setAthleteName] = useState(null);
  const currentUserId = athleteId || user?.uid;
  const [baseDate, setBaseDate] = useState(new Date());
  const [weekDays, setWeekDays] = useState(getWeekDays(new Date()));
  const [entrenamientos, setEntrenamientos] = useState([]);
  const [wellness, setWellness] = useState({});
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedDay, setSelectedDay] = useState(null);
  const [detailModalVisible, setDetailModalVisible] = useState(false);
  const [selectedWorkout, setSelectedWorkout] = useState(null);

  // ── Drag & drop ──
  const [drag, setDrag] = useState(null);
  const [scrollLocked, setScrollLocked] = useState(false);
  const ty = useRef(new Animated.Value(0)).current;
  const indY = useRef(new Animated.Value(HIDE_Y)).current;
  const scrollRef = useRef(null);
  const scrollWrapRef = useRef(null);
  const scrollY = useRef(0);
  const containerPageY = useRef(0);
  const dayPos = useRef({});
  const cardPos = useRef({});
  const cardRefs = useRef({});
  const panRefs = useRef({});
  const dragMeta = useRef(null);
  const hoverRef = useRef(null);
  const movedRef = useRef(false);
  const lastPageY = useRef(0);
  const autoDir = useRef(0);
  const autoVel = useRef(0);
  const rafRef = useRef(null);
  const suppressTap = useRef(false);
  const dayPositions = useRef({});
  const prevUserIdRef = useRef(null);

  const entrenosRef = useRef([]);
  const weekDaysRef = useRef([]);
  const fetchDataRef = useRef(null);
  entrenosRef.current = entrenamientos;
  weekDaysRef.current = weekDays;

  useEffect(() => {
    const t = setTimeout(() => { scrollWrapRef.current?.measureInWindow((x, y) => { containerPageY.current = y; }); }, 300);
    return () => clearTimeout(t);
  }, []);

  const fetchData = useCallback(async (skipCache = false) => {
    if (!currentUserId) return;
    if (!skipCache && _workoutCache.uid === currentUserId && _workoutCache.data.length > 0 && Date.now() - _workoutCache.ts < CACHE_TTL_MS) {
      setEntrenamientos(_workoutCache.data);
      setLoading(false);
      setRefreshing(false);
      return;
    }
    try {
      const now = new Date();
      const start = new Date(now); start.setDate(now.getDate() - 30); start.setHours(0,0,0,0);
      const end = new Date(now); end.setDate(now.getDate() + 30); end.setHours(23,59,59,999);
      const q = query(
        collection(db, 'entrenamientos'),
        where('userId', '==', currentUserId),
        where('fecha', '>=', Timestamp.fromDate(start)),
        where('fecha', '<=', Timestamp.fromDate(end)),
        orderBy('fecha', 'desc'),
      );
      const snap = await getDocs(q);
      const lista = snap.docs.map(d => ({ id: d.id, ...stripHeavyFields(d.data()) }));
      _workoutCache.uid = currentUserId; _workoutCache.data = lista; _workoutCache.ts = Date.now();
      setEntrenamientos(lista);
    } catch (e) {
      console.log('Error fetchData:', e.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [currentUserId]);
  fetchDataRef.current = fetchData;

  const fetchWellness = useCallback(async (force = false) => {
    if (!currentUserId) return;
    if (!force) {
      const cached = chartCache.getWellness(currentUserId);
      if (cached) { setWellness(cached); return; }
    }
    try {
      const snap = await getDoc(doc(db, 'wellness', currentUserId));
      const days = snap.exists ? (snap.data().days || {}) : {};
      chartCache.setWellness(currentUserId, days);
      setWellness(days);
    } catch (e) {
      console.log('Error fetchWellness:', e.message);
    }
  }, [currentUserId]);

  useEffect(() => {
    if (currentUserId) { fetchData(true); fetchWellness(true); }
  }, [currentUserId, fetchData, fetchWellness]);

  useFocusEffect(useCallback(() => {
    AsyncStorage.getItem('currentAthleteId').then(id => {
      setAthleteId(id);
      AsyncStorage.getItem('currentAthleteName').then(n => setAthleteName(n));
      const newUserId = id || user?.uid;
      if (prevUserIdRef.current !== null && prevUserIdRef.current !== newUserId) {
        fetchWellness(true);
      }
      prevUserIdRef.current = newUserId;
    });
  }, [fetchWellness, user?.uid]));

  useEffect(() => { setWeekDays(getWeekDays(baseDate)); }, [baseDate]);

  const changeWeek = (dir) => { const d = new Date(baseDate); d.setDate(d.getDate() + dir * 7); setBaseDate(d); };

  const goToday = () => {
    const today = new Date();
    if (getWeekKey(weekDays) !== getWeekKey(getWeekDays(today))) setBaseDate(today);
    setTimeout(() => {
      const pos = dayPositions.current[toKey(today)];
      if (pos != null && scrollRef.current) scrollRef.current.scrollTo({ y: Math.max(0, pos - 10), animated: true });
    }, 150);
  };

  const getDayItems = (day, excludeId) => (entrenosRef.current || [])
    .filter(e => {
      if (!e.fecha) return false;
      if (excludeId && e.id === excludeId) return false;
      const d = e.fecha.toDate ? e.fecha.toDate() : new Date(e.fecha);
      return d.toDateString() === day.toDateString();
    })
    .sort((a, b) => (a.fecha?.toMillis?.() ?? 0) - (b.fecha?.toMillis?.() ?? 0));

  const isToday = (day) => day.toDateString() === new Date().toDateString();
  const openModal = (day) => { setSelectedDay(day); setModalVisible(true); };
  const getWorkoutColor = (estado) => estado === 'completo' ? GREEN : estado === 'incompleto' ? RED : GRAY;

  // ── Drag: snapshot del layout de la semana visible al empezar a arrastrar ──
  const fingerContentY = (pageY) => pageY - containerPageY.current + scrollY.current;

  const buildLayoutSnapshot = (draggedId) => {
    return weekDaysRef.current
      .map(d => {
        const key = toKey(d);
        const dp = dayPos.current[key];
        if (!dp) return null;
        const items = getDayItems(d, draggedId)
          .map(c => ({ id: c.id, cp: cardPos.current[c.id] }))
          .filter(x => x.cp);
        return { key, y: dp.y, height: dp.height, items };
      })
      .filter(Boolean);
  };

  const computeInsert = (pageY) => {
    const m = dragMeta.current;
    if (!m || !m.layout) return;
    const topLimit = containerPageY.current + 70;
    const botLimit = SCREEN_H - 80;
    const dir = pageY > botLimit ? 1 : pageY < topLimit ? -1 : 0;
    if (dir !== autoDir.current) { autoDir.current = dir; autoVel.current = 0; }
    const fy = fingerContentY(pageY);
    const day = m.layout.find(dd => fy >= dd.y && fy < dd.y + dd.height);
    const key = day ? day.key : null;
    let beforeId = null;
    if (day) {
      const fyDay = fy - day.y;
      for (const c of day.items) {
        if (fyDay < c.cp.y + c.cp.height / 2) { beforeId = c.id; break; }
      }
    }
    hoverRef.current = { key, beforeId };
    let indContentY = HIDE_Y;
    if (day) {
      if (beforeId) {
        const cp = day.items.find(c => c.id === beforeId)?.cp;
        if (cp) indContentY = Math.max(day.y, day.y + cp.y - IND_H - 6);
      } else {
        let bottom = 40;
        for (const c of day.items) { if (c.cp.y + c.cp.height > bottom) bottom = c.cp.y + c.cp.height; }
        indContentY = day.y + bottom - 6;
      }
    }
    indY.setValue(indContentY);
  };

  const autoScrollLoop = () => {
    if (!dragMeta.current) { autoDir.current = 0; autoVel.current = 0; return; }
    if (autoDir.current !== 0) {
      autoVel.current = Math.min(autoVel.current + 0.6, 16);
      const next = Math.max(0, scrollY.current + autoDir.current * autoVel.current);
      scrollRef.current?.scrollTo({ y: next, animated: false });
      scrollY.current = next;
      computeInsert(lastPageY.current);
    }
    rafRef.current = requestAnimationFrame(autoScrollLoop);
  };

  const armDrag = (pageY, id) => {
    const w = (entrenosRef.current || []).find(x => x.id === id);
    if (!w) return;
    const el = cardRefs.current[id];
    if (!el) return;
    el.measureInWindow((x, y) => {
      dragMeta.current = {
        id,
        grab: pageY - y,
        layout: buildLayoutSnapshot(id),
      };
      movedRef.current = false;
      lastPageY.current = pageY;
      autoDir.current = 0;
      autoVel.current = 0;
      ty.setValue(y);
      computeInsert(pageY);
      setScrollLocked(true);
      setDrag({
        id,
        color: getWorkoutColor(w.estado),
        tipo: w.tipo,
        titulo: w.titulo || w.tipo,
        descripcion: w.descripcion,
        subtitle: formatSubtitleItem(w),
        estado: w.estado,
      });
      Vibration.vibrate(10);
      rafRef.current = requestAnimationFrame(autoScrollLoop);
    });
  };

  const moveDrag = (pageY) => {
    const m = dragMeta.current;
    if (!m) return;
    movedRef.current = true;
    lastPageY.current = pageY;
    ty.setValue(pageY - m.grab);
    computeInsert(pageY);
  };

  const cleanup = () => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    autoDir.current = 0;
    autoVel.current = 0;
    dragMeta.current = null;
    hoverRef.current = null;
    movedRef.current = false;
    indY.setValue(HIDE_Y);
    setDrag(null);
    setScrollLocked(false);
    suppressTap.current = true;
    setTimeout(() => { suppressTap.current = false; }, 250);
  };

  const endDrag = () => {
    const m = dragMeta.current;
    const h = hoverRef.current;
    if (!m || !movedRef.current || !h || !h.key) { cleanup(); return; }
    const dayDate = weekDaysRef.current.find(d => toKey(d) === h.key);
    if (!dayDate) { cleanup(); return; }
    let nf = null;
    if (h.beforeId) {
      const before = (entrenosRef.current || []).find(e => e.id === h.beforeId);
      if (before) nf = new Date((before.fecha?.toMillis?.() ?? 0) - 60000);
    }
    if (!nf) {
      const items = getDayItems(dayDate, m.id);
      if (items.length) {
        nf = new Date((items[items.length - 1].fecha?.toMillis?.() ?? 0) + 60000);
      } else {
        nf = new Date(dayDate);
        nf.setHours(8, 0, 0, 0);
      }
    }
    const ts = Timestamp.fromDate(nf);
    const p2 = n => String(n).padStart(2, '0');
    const fechaStr = `${p2(nf.getDate())}/${p2(nf.getMonth()+1)}/${nf.getFullYear()}`;
    const mutate = (list) => list.map(e => (e.id === m.id ? { ...e, fecha: ts, fechaStr } : e));
    setEntrenamientos(prev => mutate(prev));
    _workoutCache.data = mutate(_workoutCache.data);
    _workoutCache.ts = Date.now();
    cleanup();
    updateDoc(doc(db, 'entrenamientos', m.id), { fecha: ts, fechaStr })
      .catch(() => { _workoutCache.uid = null; fetchDataRef.current?.(true); });
  };

  const getCardPan = (id) => {
    if (!panRefs.current[id]) {
      panRefs.current[id] = PanResponder.create({
        onMoveShouldSetPanResponder: () => !!dragMeta.current,
        onPanResponderMove: (e) => moveDrag(e.nativeEvent.pageY),
        onPanResponderRelease: () => endDrag(),
        onPanResponderTerminate: () => cleanup(),
      });
    }
    return panRefs.current[id];
  };

  const renderMetrics = (day, palette = theme) => {
    const m = wellness[toKey(day)];
    if (!m) return null;
    const chips = [];
    if (m.sleep != null) chips.push({ icon: 'moon', text: fmtSleep(m.sleep) });
    if (m.score != null) chips.push({ icon: 'star-outline', text: `${m.score}` });
    if (m.rhr != null)   chips.push({ icon: 'heart-half', text: `${m.rhr} ${hrUnit}` });
    if (m.hrv != null)   chips.push({ icon: 'pulse-outline', text: `${m.hrv} ms` });
    if (m.spo2 != null)  chips.push({ icon: 'water-outline', text: `${m.spo2}%` });
    const vo2Value = m.vo2_est ?? m.vo2;
    if (vo2Value != null) chips.push({ icon: 'speedometer-outline', text: `${Number(vo2Value).toFixed(1)}` });
    if (m.fcMax != null) chips.push({ icon: 'heart-outline', text: `${m.fcMax} ${hrUnit}` });
    if (m.kcal != null)  chips.push({ icon: 'flame-outline', text: `${m.kcal} kcal` });
    if (m.steps != null) chips.push({ icon: 'walk', text: `${m.steps}` });
    if (!chips.length) return null;
    return (
      <View style={[styles.metricsCard, { backgroundColor: palette.card, borderColor: palette.border }]}>
        {chips.map((c, i) => (
          <View key={i} style={styles.metricChip}>
            <Ionicons name={c.icon} size={13} color={palette.muted} />
            <Text style={[styles.metricText, { color: palette.muted }]}>{c.text}</Text>
          </View>
        ))}
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.splash}>
        <ActivityIndicator size="large" color={BLUE} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <View style={[styles.header, { backgroundColor: theme.card, borderBottomColor: theme.border }]}>
        <TouchableOpacity style={styles.todayBtn} onPress={goToday}>
          <Text style={styles.todayText}>{todayLabel}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => changeWeek(-1)} style={styles.navBtn}>
          <Ionicons name="chevron-back" size={20} color="#8FA8C8" />
        </TouchableOpacity>
        <View style={styles.weekLabelBox}>
          <Ionicons name="calendar-outline" size={14} color="#8FA8C8" />
          <Text style={[styles.weekLabel, { color: theme.text }]}>{weekLabel(weekDays, loc)}</Text>
        </View>
        <TouchableOpacity onPress={() => changeWeek(1)} style={styles.navBtn}>
          <Ionicons name="chevron-forward" size={20} color="#8FA8C8" />
        </TouchableOpacity>
      </View>

      <View
        ref={scrollWrapRef}
        style={{ flex: 1 }}
        onLayout={() => { scrollWrapRef.current?.measureInWindow((x, y) => { containerPageY.current = y; }); }}
      >
        <ScrollView
          ref={scrollRef}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          scrollEnabled={!scrollLocked}
          overScrollMode="never"
          onScroll={(e) => { if (!dragMeta.current) scrollY.current = e.nativeEvent.contentOffset.y; }}
          scrollEventThrottle={32}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              enabled={!scrollLocked}
              onRefresh={() => { setRefreshing(true); fetchData(true); fetchWellness(true); }}
              tintColor={BLUE}
            />
          }
        >
          {weekDays.map((day) => {
            const dayItems = getDayItems(day);
            const dayLabel = day.toLocaleDateString(loc, { weekday: 'long', day: 'numeric' });
            const isTodayDay = isToday(day);
            const key = toKey(day);
            return (
              <View
                key={day.toISOString()}
                style={[styles.dayBlock, { borderBottomColor: theme.border }]}
                onLayout={(e) => {
                  dayPos.current[key] = { y: e.nativeEvent.layout.y, height: e.nativeEvent.layout.height };
                  dayPositions.current[key] = e.nativeEvent.layout.y;
                }}
              >
                <Text style={[styles.dayTitle, { color: theme.muted }, isTodayDay && styles.dayTitleToday]}>
                  {dayLabel.charAt(0).toUpperCase() + dayLabel.slice(1)}
                </Text>
                {dayItems.map(e => {
                  const subtitle = formatSubtitleItem(e);
                  const color = getWorkoutColor(e.estado);
                  const pan = getCardPan(e.id);
                  return (
                    <View
                      key={e.id}
                      {...pan.panHandlers}
                      onTouchEnd={() => { if (dragMeta.current && !movedRef.current) cleanup(); }}
                      onLayout={(ev) => { cardPos.current[e.id] = { y: ev.nativeEvent.layout.y, height: ev.nativeEvent.layout.height }; }}
                    >
                      <TouchableOpacity
                        ref={(r) => { cardRefs.current[e.id] = r; }}
                        style={[styles.workoutCard, { backgroundColor: color }, isTodayDay && styles.todayBorder, drag?.id === e.id && styles.ghostCard]}
                        onPress={() => { if (suppressTap.current) return; setSelectedWorkout(e); setDetailModalVisible(true); }}
                        onLongPress={(ev) => armDrag(ev.nativeEvent.pageY, e.id)}
                        delayLongPress={250}
                        activeOpacity={0.8}
                      >
                        <View style={[styles.cardAccent, { backgroundColor: lighten(color, 0.5) }]} />
                        <View style={styles.cardBody}>
                          <Ionicons name={TIPO_ICON[e.tipo] ?? 'flash'} size={20} color="#fff" style={styles.cardIcon} />
                          <View style={{ flex: 1 }}>
                            <Text style={styles.cardTitle}>{e.titulo || e.tipo}</Text>
                            {e.descripcion ? <Text style={styles.cardDesc}>{e.descripcion}</Text> : null}
                            {subtitle ? <Text style={styles.metaText}>{subtitle}</Text> : null}
                          </View>
                          {e.estado && (
                            <Ionicons name={e.estado === 'completo' ? 'checkmark-circle' : 'close-circle'} size={16} color="#fff" />
                          )}
                        </View>
                      </TouchableOpacity>
                    </View>
                  );
                })}
                {renderMetrics(day, theme)}
                <TouchableOpacity
                  style={[styles.emptySlot, isTodayDay && styles.todayBorderDashed]}
                  onPress={() => openModal(day)}
                  activeOpacity={0.7}
                >
                  <Ionicons name="add" size={20} color={isTodayDay ? BLUE : '#2A4060'} />
                </TouchableOpacity>
              </View>
            );
          })}
          {drag && (
            <Animated.View pointerEvents="none" style={[styles.dropIndicator, { transform: [{ translateY: indY }] }]} />
          )}
        </ScrollView>
      </View>

      {drag && (
        <Animated.View
          pointerEvents="none"
          style={[styles.dragOverlay, { backgroundColor: drag.color, transform: [{ translateY: ty }, { scale: 1.04 }] }]}
        >
          <View style={[styles.cardAccent, { backgroundColor: lighten(drag.color, 0.5) }]} />
          <View style={styles.cardBody}>
            <Ionicons name={TIPO_ICON[drag.tipo] ?? 'flash'} size={20} color="#fff" style={styles.cardIcon} />
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{drag.titulo}</Text>
              {drag.descripcion ? <Text style={styles.cardDesc}>{drag.descripcion}</Text> : null}
              {drag.subtitle ? <Text style={styles.metaText}>{drag.subtitle}</Text> : null}
            </View>
            {drag.estado && <Ionicons name={drag.estado === 'completo' ? 'checkmark-circle' : 'close-circle'} size={16} color="#fff" />}
          </View>
        </Animated.View>
      )}

      <AddWorkoutModal
        visible={modalVisible}
        onClose={() => setModalVisible(false)}
        onWorkoutAdded={() => { _workoutCache.uid = null; fetchData(true); }}
        initialDate={selectedDay ?? new Date()}
        athleteId={athleteId}
      />
      <WorkoutDetailModal
        visible={detailModalVisible}
        workout={selectedWorkout}
        onClose={() => { setDetailModalVisible(false); setSelectedWorkout(null); }}
        onWorkoutUpdated={() => { _workoutCache.uid = null; fetchData(true); }}
        athleteId={athleteId}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  splash: { flex: 1, backgroundColor: NAVY, alignItems: 'center', justifyContent: 'center' },
  scrollContent: { paddingBottom: 32 },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 12, paddingTop: 56, paddingBottom: 12,
    backgroundColor: NAVY, borderBottomWidth: 1, borderBottomColor: BORDER, gap: 4,
  },
  todayBtn: { backgroundColor: BLUE, borderRadius: 6, paddingHorizontal: 12, paddingVertical: 6, marginRight: 4 },
  todayText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  navBtn: { padding: 6 },
  weekLabelBox: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  weekLabel: { color: '#8FA8C8', fontSize: 14, fontWeight: '600' },
  dayBlock: { borderBottomWidth: 1, borderBottomColor: BORDER },
  dayTitle: { color: '#8FA8C8', fontSize: 14, fontWeight: '600', paddingHorizontal: 16, paddingTop: 14, paddingBottom: 8 },
  dayTitleToday: { color: BLUE },
  workoutCard: { marginHorizontal: 16, marginBottom: 6, borderRadius: 10, overflow: 'hidden' },
  ghostCard: { opacity: 0.3 },
  todayBorder: { borderWidth: 1.5, borderColor: BLUE },
  todayBorderDashed: { borderColor: BLUE },
  dropIndicator: {
    position: 'absolute', top: 0, left: 16, right: 16, height: IND_H,
    borderRadius: 10, borderWidth: 1.5, borderStyle: 'dashed',
    borderColor: BLUE, backgroundColor: BLUE + '22', zIndex: 50,
  },
  dragOverlay: {
    position: 'absolute', top: 0, left: 16, right: 16,
    borderRadius: 10, overflow: 'hidden',
    elevation: 16, zIndex: 999, opacity: 0.96,
    shadowColor: '#000', shadowOpacity: 0.35, shadowRadius: 8, shadowOffset: { width: 0, height: 6 },
  },
  cardAccent: { height: 3, width: '100%' },
  cardBody: { flexDirection: 'row', alignItems: 'flex-start', padding: 12, gap: 10 },
  cardIcon: { marginTop: 1 },
  cardTitle: { color: '#fff', fontSize: 13, fontWeight: '700' },
  cardDesc: { color: 'rgba(255,255,255,0.85)', fontSize: 12, marginTop: 2, lineHeight: 17 },
  metaText: { color: '#cfffec', fontSize: 12, marginTop: 3 },
  metricsCard: {
    flexDirection: 'row', flexWrap: 'wrap', gap: 10,
    marginHorizontal: 16, marginBottom: 6,
    backgroundColor: '#101A28', borderWidth: 1, borderColor: BORDER,
    borderRadius: 8, paddingHorizontal: 10, paddingVertical: 8,
  },
  metricChip: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metricText: { color: '#8FA8C8', fontSize: 11 },
  emptySlot: {
    marginHorizontal: 16, marginBottom: 10,
    borderWidth: 1, borderColor: BORDER, borderStyle: 'dashed',
    borderRadius: 8, height: 36, alignItems: 'center', justifyContent: 'center',
  },
});
