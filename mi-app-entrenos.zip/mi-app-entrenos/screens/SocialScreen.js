// screens/SocialScreen.js
/* Pestaña SOCIAL — chat de equipo estilo WhatsApp + retos.
   TABLÓN:
   · Burbujas (propias derecha verde / demás izquierda con avatar y nombre de
     color), hora abajo-derecha, reacciones con pulsación larga (una por
     persona, pills con contador), responder/reenviar/eliminar al seleccionar,
     citas y marca de reenviado. Tocar la CITA salta al mensaje original si
     está cargado (destello azul); si no está, no hace nada.
   · Separadores de fecha estilo WhatsApp entre mensajes de días distintos:
     HOY / AYER / nombre del día (últimos 7 días) / "15 de marzo de 2024",
     en una píldora negra semitransparente centrada.
   · Audios reproducibles DENTRO del chat (expo-audio: play/pause, barra de
     progreso con seek, duración; uno a la vez) y archivos en tarjeta grande
     estilo WhatsApp (icono, nombre, extensión · tamaño).
   · Fondo del tablón tal cual se subió: sin velo blanco encima.
   · Imágenes (patrón WhatsApp real): al enviar se genera y sube también una
     MINIATURA de 640 px; la burbuja pinta la miniatura (expo-image, caché
     memoria+disco) y el visor a pantalla completa carga el ORIGINAL con
     gestos en el hilo de UI (gesture-handler + reanimated): pellizco anclado
     a los dedos, pan 1:1, doble toque 2.5x, swipe entre fotos y swipe abajo
     para cerrar.
   · Envío estilo WhatsApp: el mensaje se publica AL INSTANTE con la imagen en
     local y un aro de progreso; la subida a Cloudflare R2 va en segundo plano
     y al terminar se fija la URL en Firestore (los demás la ven entonces).
   · Caché local-first estilo WhatsApp (services/chatStore.js): el historial
     ya recibido vive en el dispositivo y se pinta AL INSTANTE sin red; las
     imágenes en disco (cacheDirectory) con descarga single-flight + .part +
     move atómico (adiós imágenes cortadas).
   · Sincronización INCREMENTAL: al abrir solo se piden los mensajes
     posteriores al último sincronizado (where createdAt > lastSync); el
     historial antiguo se pagina hacia atrás AUTOMÁTICAMENTE por zonas de
     50 al rozar el borde superior (sin botón de "descargar el chat de la
     nube"). Motor en services/chatSync.js, verificado por
     tests/chat-sync-test.js. Nunca se descarga todo el chat.
   · Listener en vivo con docChanges(): added/modified se fusionan en el
     almacén local; removed se ignora a propósito (defensivo: el servidor
     ya no purga mensajes).
   · Historial PERMANENTE: los mensajes no caducan. La sincronización
     incremental ya garantiza que nunca se descarga el chat entero, así que
     el tamaño del historial no aumenta el coste. El endpoint de purga
     (api/social/purge) queda como herramienta opcional, desactivada.
   · Eliminar = borrado lógico (eliminado:true): los demás ven "Mensaje
     eliminado". Si el mensaje tenía imagen/archivo, el borrado pasa por el
     servidor (api/social/delete-message.js), que elimina TAMBIÉN el objeto
     de Cloudflare R2 — solo si ningún otro mensaje vivo lo referencia (los
     reenvíos comparten URL y no se rompen). Sin servidor desplegado, la app
     hace el borrado lógico de siempre como respaldo.
   · Enlaces PINCHABLES en el texto (azul + subrayado, patrón WhatsApp) y
     PREVISUALIZACIÓN Open Graph generada en el lado del EMISOR: al enviar,
     la app pide los metadatos al servidor (api/social/link-preview.js, con
     protección SSRF) y los adjunta al mensaje (campo preview); el receptor
     pinta la tarjeta (imagen + título + dominio) sin descargar nada.
     Mensajes antiguos sin preview: se piden una vez y se cachean 7 días
     (services/linkPreview.js).
   · Encuestas estilo WhatsApp: resultados EN VIVO (listener propio por
     documento: los votos de los demás llegan al instante aunque la
     encuesta sea antigua), voto optimista en pantalla, barras de color por
     opción e insignia "GANANDO" en la líder (recuento en
     services/encuestas.js).
   · Foto de perfil en la burbuja con CACHÉ LOCAL (services/avatarCache.js,
     patrón WhatsApp): la foto se descarga UNA vez a disco y se pinta desde
     ahí; solo se vuelve a descargar cuando la persona cambia su foto (doc
     ligero avatares/<uid> con la URL en R2; los perfiles antiguos sin doc
     usan un respaldo con TTL de 6 h).
   · Scroll estilo WhatsApp: el viewport SOLO sigue el chat si ya estaba
     abajo. Votar una encuesta, reaccionar, seleccionar un mensaje o recibir
     mensajes mientras lees historial ya NO te arrastran al último mensaje;
     al volver de la pestaña "Retos" se restaura la posición exacta. Cuando
     NO estás abajo aparece un botón circular ↓ sobre la isla flotante
     (mismo diseño que las fichas de fecha, con insignia de no vistos).
   RETOS: coach crea con métrica, periodo y atletas invitados; invitados
   aceptan; ranking en vivo entre aceptados; historial con ganador. */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, Dimensions, Image, Keyboard, Linking,
  Modal, Platform, Pressable, RefreshControl, ScrollView, Text, TextInput,
  TouchableOpacity, View, useColorScheme,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { getSocialBg } from '../services/socialBg';
import { Ionicons } from '@expo/vector-icons';
import { chatStoreInit, chatStoreAll, chatStorePut, chatStoreMeta, chatStoreSetMeta } from '../services/chatStore';
import { gapSync, loadOlderZone } from '../services/chatSync';
import { claveDia, esAudioMedia, extDe, fmtDur, fmtSeparador, fmtSize } from '../services/fechasChat';
import { colorOpcion, contarVotos } from '../services/encuestas';
import { dominioDe, normalizarUrl, primeraUrl, segmentar } from '../services/enlaces';
import { obtenerPreview, previewParaEnvio } from '../services/linkPreview';
import { avatarCacheInit, sincronizarAvatares, useAvatar } from '../services/avatarCache';
import {
  Timestamp, addDoc, arrayUnion, collection, doc, getDocs, limit,
  onSnapshot, orderBy, query, updateDoc, where,
} from 'firebase/firestore';
import * as FileSystem from 'expo-file-system/legacy';  // uploadAsync/getInfoAsync clásicos
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import * as Sharing from 'expo-sharing';
// Reproductor de audio del chat (expo-audio, SDK 57). require PROTEGIDO: si
// el bundle llega por OTA a un binario antiguo sin el módulo nativo, la app
// sigue funcionando y los audios se abren con el panel del sistema.
let AudioLib = null;
try { AudioLib = require('expo-audio'); } catch (e) { AudioLib = null; }
import * as ImageManipulator from 'expo-image-manipulator';
import { Image as ExpoImage } from 'expo-image';
import { Gesture, GestureDetector, GestureHandlerRootView } from 'react-native-gesture-handler';
import Reanimated, {
  clamp, interpolate, runOnJS, useAnimatedStyle, useSharedValue,
  withSpring, withTiming,
} from 'react-native-reanimated';
import { auth, db } from '../firebaseConfig';
import { getThemeColors, useAppSettings } from '../services/appSettings';
import { getCachedProfile } from '../services/profileCache';
import { getApiUrl } from '../services/api';
import SystemBars from '../components/SystemBars';

// Método de subida binario (legacy expo-file-system): BINARY_CONTENT, con
// fallbacks por si el enum viene con otro nombre en alguna versión.
let GOOD_UPLOAD_TYPE = 0;   // se auto-corrige verificando el objeto subido
const BIN_UPLOAD = (() => {
  try {
    const M = FileSystem.FileSystemUploadMethod || FileSystem.FileSystemUploadType || {};
    if (typeof M.BINARY_CONTENT === 'number') return M.BINARY_CONTENT;
    if (typeof M.MULTIPART === 'number') return M.MULTIPART === 0 ? 1 : 0;
  } catch (e) {}
  return 0;
})();
GOOD_UPLOAD_TYPE = BIN_UPLOAD;

const REACCIONES = ['\u{1F44D}', '\u{2764}\u{FE0F}', '\u{1F602}', '\u{1F62E}', '\u{1F622}', '\u{1F64F}', '\u{1F525}'];
const NOMBRES_COLOR = ['#E5426A', '#0E8A6D', '#B5651D', '#4A90E2', '#8E44AD', '#2DB37A', '#D35400', '#16A085'];
const METRICAS = [
  { id: 'km',        label: 'Kilómetros',         unidad: 'km' },
  { id: 'sesiones',  label: 'Sesiones',           unidad: 'sesiones' },
  { id: 'minutos',   label: 'Tiempo',             unidad: 'min' },
  { id: 'esfuerzo',  label: 'Puntos de esfuerzo', unidad: 'pts' },
];

/* Votos optimistas recientes (postId -> { idx, ts }): durante 5 s ningún
   eco del servidor puede revertir un voto recién hecho en pantalla. */
const votosRecientes = new Map();

const colorDe = (uid) => {
  let h = 0;
  const str = String(uid || 'x');
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return NOMBRES_COLOR[h % NOMBRES_COLOR.length] || '#4A90E2';
};
const fmtHora = (ts, loc) => {
  if (!ts) return '';
  const d = ts?.toDate ? ts.toDate() : new Date(ts);
  if (isNaN(d.getTime())) return '';
  const hoy = new Date();
  return d.toDateString() === hoy.toDateString()
    ? d.toLocaleTimeString(loc, { hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString(loc, { day: '2-digit', month: '2-digit' }) + ' ' + d.toLocaleTimeString(loc, { hour: '2-digit', minute: '2-digit' });
};
const fmtDia = (ts, loc) => {
  if (!ts) return '';
  const d = ts?.toDate ? ts.toDate() : new Date(ts);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleDateString(loc, { day: 'numeric', month: 'short' });
};
const valorDe = (w, metrica) => {
  switch (metrica) {
    case 'km':       return Number(w.distancia || 0);
    case 'sesiones': return 1;
    case 'minutos':  return Number(w.duracion || 0) / 60;
    case 'esfuerzo': return Number(w.esfuerzo || 0);
    default:         return 0;
  }
};
const fmtValor = (v, metrica) =>
  metrica === 'sesiones' ? String(Math.round(v)) : metrica === 'minutos' ? `${Math.round(v)}'` :
  metrica === 'esfuerzo' ? String(Math.round(v)) : `${v.toFixed(1)} km`;

/* ── Caché de imágenes en disco: single-flight + .part + move atómico ── */
const IMG_DIR = (FileSystem.cacheDirectory || FileSystem.documentDirectory) + 'social-img-v3/';   // v2: invalida la caché anterior que pudo corromperse
let imgDirReady = false;
async function ensureImgDir() {
  if (imgDirReady) return;
  try {
    const info = await FileSystem.getInfoAsync(IMG_DIR);
    if (!info.exists) await FileSystem.makeDirectoryAsync(IMG_DIR, { intermediates: true });
  } catch (e) {}
  imgDirReady = true;
}
const localFor = (url) => IMG_DIR + ((url || '').split('/').pop().split('?')[0] || 'img');
const diskCache = new Map();   // url -> uri local ya descargada
const inflight = new Map();
function cachedOrDownload(url) {
  if (inflight.has(url)) return inflight.get(url);
  const pr = (async () => {
    await ensureImgDir();
    const local = localFor(url);
    const info = await FileSystem.getInfoAsync(local);
    if (info.exists && info.size > 0) { diskCache.set(url, local); return local; }
    const part = local + '.part';
    try { await FileSystem.deleteAsync(part, { idempotent: true }); } catch (e) {}
    await FileSystem.downloadAsync(url, part);
    await FileSystem.moveAsync({ from: part, to: local });
    diskCache.set(url, local);
    return local;
  })();
  inflight.set(url, pr);
  pr.catch(() => {}).then(() => inflight.delete(url));
  return pr;
}

/* Al eliminar un mensaje con media se olvidan sus archivos locales: las
   imágenes/audios borrados dejan de ocupar espacio en el dispositivo. */
function olvidarMediaLocal(urls) {
  for (const u of (urls || [])) {
    try {
      diskCache.delete(u);
      const f = localFor(u);
      FileSystem.deleteAsync(f, { idempotent: true }).catch(() => {});
      FileSystem.deleteAsync(f + '.part', { idempotent: true }).catch(() => {});
    } catch (e) {}
  }
}

/* ── Miniatura 640 px estilo WhatsApp: la burbuja del chat pinta esta copia
      ligera; el original solo se descarga en el visor a pantalla completa.
      API nueva por contexto (SDK 52+) con fallback al método legacy. ── */
const THUMB_W = 640;
const THUMB_MIN_BYTES = 200 * 1024;   // por debajo de esto no compensa miniatura
async function makeThumb(uri) {
  const save = { compress: 0.72, format: ImageManipulator.SaveFormat.JPEG };
  if (typeof ImageManipulator.manipulate === 'function') {
    const ctx = ImageManipulator.manipulate(uri);
    ctx.resize({ width: THUMB_W });
    const ref = await ctx.renderAsync();
    const out = await ref.saveAsync(save);
    return out.uri;
  }
  const out = await ImageManipulator.manipulateAsync(uri, [{ resize: { width: THUMB_W } }], save);
  return out.uri;
}

async function presign(me, filename, contentType, size) {
  const apiUrl = (await getApiUrl()).replace(/\/+$/, '');
  const token = await me.getIdToken();
  const r = await fetch(`${apiUrl}/social/presign`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ filename, contentType, size }),
  });
  const t = await r.text();
  let d = null;
  try { d = JSON.parse(t); } catch (e) { d = null; }
  if (!r.ok || !d || !d.uploadUrl) throw new Error((d && d.error) || `presign HTTP ${r.status}: ${t.slice(0, 120)}`);
  return d;
}

/* ── ErrorBoundary: un dato malo ya no puede tumbar la app; muestra el
      error en pantalla para poder diagnosticarlo con una captura ── */
class SocialErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { err: null, cstack: '' }; }
  static getDerivedStateFromError(e) { return { err: e }; }
  componentDidCatch(e, info) {
    this.setState({ cstack: (info && info.componentStack) || '' });
  }
  render() {
    if (this.state.err) {
      const stack = String((this.state.err && this.state.err.stack) || '').split('\n').slice(0, 8).join('\n');
      return (
        <ScrollView style={{ margin: 8, maxHeight: 300, padding: 12, borderRadius: 12, backgroundColor: '#00000018', borderWidth: 1, borderColor: '#E05252' }}>
          <Text style={{ color: '#E05252', fontWeight: '800', marginBottom: 4 }}>Error en Social</Text>
          <Text style={{ color: '#444', fontSize: 12 }} selectable>{String(this.state.err && this.state.err.message)}</Text>
          <Text style={{ color: '#666', fontSize: 10, marginTop: 6 }} selectable>{stack}</Text>
          {!!this.state.cstack && <Text style={{ color: '#888', fontSize: 10, marginTop: 6 }} selectable>{this.state.cstack.split('\n').slice(0, 6).join('\n')}</Text>}
        </ScrollView>
      );
    }
    return this.props.children;
  }
}

export default function SocialScreen() {
  const insets = useSafeAreaInsets();
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const lang = appSettings.language;
  const L = (es, en) => (lang === 'en' ? en : es);
  const loc = lang === 'en' ? 'en-US' : 'es-ES';
  const me = auth.currentUser;
  const isLight = theme.background === '#F4F7FB';

  const [tab, setTab] = useState('tablon');
  const [posts, setPosts] = useState([]);          // cronológico asc
  const [loading, setLoading] = useState(true);
  const [hasMoreOld, setHasMoreOld] = useState(false);  // queda historial por paginar
  const [loadingOld, setLoadingOld] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [selIds, setSelIds] = useState([]);          // multi-selección de mensajes
  const [bgUri, setBgUri] = useState(null);          // fondo local del tablón
  const [replyTo, setReplyTo] = useState(null);
  const [highlightId, setHighlightId] = useState(null);   // destello al saltar a un mensaje citado
  const [islandBottom, setIslandBottom] = useState(0.25);   // isla: 0.25 px de la barra; sube con el teclado
  const branchRef = useRef(null);
  const [viewer, setViewer] = useState(null);            // { index, urls } del visor
  const scrollRef = useRef(null);
  const contentH = useRef(0);          // alto del contenido (fija el scroll al paginar)
  const offsetRef = useRef(0);         // offset Y actual del scroll
  const pendingFix = useRef(null);     // { prevH, prevOff } al prepender antiguos
  const enElFinalRef = useRef(true);   // ¿el viewport está al final del chat?
  const prevCountRef = useRef(0);      // nº de mensajes en el último cambio de contenido
  const forzarFinalRef = useRef(false);// el próximo crecimiento FUERZA ir al final (mensaje propio)
  const restaurarRef = useRef(null);   // { y, h } guardado al salir a "Retos": se restaura al volver
  const primeraCargaRef = useRef(true);// primera carga del chat en esta sesión de la pantalla
  const [mostrarIrAbajo, setMostrarIrAbajo] = useState(false);  // visibilidad del FAB ↓
  const mostrarIrAbajoRef = useRef(false);                      // espejo del FAB (evita setState por evento)
  const [nuevosSinVer, setNuevosSinVer] = useState(0);          // insignia de no vistos del FAB ↓
  const posRef = useRef(new Map());    // id de mensaje -> { y } medido en el contenido
  const hlTimer = useRef(null);        // temporizador del destello

  const [retos, setRetos] = useState({ activos: [], pasados: [] });
  const [retosLoading, setRetosLoading] = useState(true);
  const [soyCoach, setSoyCoach] = useState(false);
  const [creaRetoOpen, setCreaRetoOpen] = useState(false);

  // La isla es FLOTANTE (absolute sobre el chat). Al salir el teclado se mide
  // el borde inferior del contenedor y el superior del teclado en las mismas
  // coordenadas de ventana, y se eleva justo hasta quedar encima.
  useEffect(() => {
    try {
    const evShow = Platform.OS === 'android' ? 'keyboardDidShow' : 'keyboardWillShow';
    const evHide = Platform.OS === 'android' ? 'keyboardDidHide' : 'keyboardWillHide';
    const s1 = Keyboard.addListener(evShow, (e) => {
      const kb = e.endCoordinates.height;
      branchRef.current?.measureInWindow((x, y, w, h) => {
        const winH = Dimensions.get('window').height;
        const off = (y + h) - (winH - kb);
        // + inset inferior (barra de navegación en edge-to-edge) + aire:
        // la isla queda justo por encima del borde superior del teclado.
        setIslandBottom(off > 0 ? off + insets.bottom + 0.25 : 0.25);
      });
    });
    const s2 = Keyboard.addListener(evHide, () => setIslandBottom(0.25));
    return () => { s1.remove(); s2.remove(); };
    } catch (e) { console.warn('[social] keyboard effect:', e.message); return undefined; }
  }, []);

  /* Scroll estilo WhatsApp: alFinal() solo baja si el usuario YA está al
     final (suave: no interrumpe la lectura del historial); alFinal(true)
     lo fuerza siempre (mensajes propios y primera apertura del chat). */
  const alFinal = (forzar = false) => setTimeout(() => {
    if (forzar || enElFinalRef.current) scrollRef.current?.scrollToEnd({ animated: false });
  }, 60);

  /* FAB ↓ (círculo sobre la isla): vuelve al último mensaje con animación
     y limpia la cuenta de mensajes no vistos. */
  const irAlFinal = () => {
    setNuevosSinVer(0);
    scrollRef.current?.scrollToEnd({ animated: true });
  };

  /* Al pasar a la pestaña "Retos" el ScrollView se desmonta: se guarda la
     posición exacta y se restaura al volver (WhatsApp no te tira al último
     mensaje cuando regresas a una conversación). */
  useEffect(() => {
    if (tab !== 'tablon') restaurarRef.current = { y: offsetRef.current, h: contentH.current };
  }, [tab]);

  // Fondo local del tablón (nunca en la nube): se refresca al volver a la pestaña
  useFocusEffect(useCallback(() => {
    getSocialBg().then((p) => setBgUri(p || null)).catch(() => {});
  }, []));

  const toggleSel = (id) => setSelIds((ids) => (ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id]));

  // Reenviar varios (uno a uno, como WhatsApp con múltiples)
  const reenviarVarios = async (list) => {
    setSelIds([]);
    try {
      const perfil = (await getCachedProfile(me.uid)) || {};
      const nuevos = [];
      for (const post of list) {
        const iso = new Date().toISOString();
        const ref = await addDoc(collection(db, 'posts'), {
          autorUid: me.uid,
          autorNombre: perfil.nombre || me.displayName || 'Alguien',
          texto: post.texto || '',
          media: (post.media || []).map((m) => ({ ...m })),
          reenviado: true,
          encuesta: null,
          preview: post.preview || null,
          reacciones: {},
          createdAt: iso,
        });
        nuevos.push({
          id: ref.id, autorUid: me.uid, autorNombre: perfil.nombre || me.displayName || 'Alguien',
          texto: post.texto || '', media: (post.media || []).map((m) => ({ ...m })),
          reenviado: true, encuesta: null, preview: post.preview || null, reacciones: {}, createdAt: iso,
        });
      }
      await chatStorePut(nuevos);
      await chatStoreSetMeta({ lastSync: new Date().toISOString() });
      forzarFinalRef.current = true;   // reenvío propio: siempre al final
      setPosts(await chatStoreAll());
      alFinal(true);
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };

  // Eliminar varios = BORRADO LÓGICO estilo WhatsApp: el doc se queda en el
  // servidor marcado como eliminado (los demás reciben "modified" y ven
  // "Mensaje eliminado"). Un deleteDoc físico llegaría a los demás como
  // "removed", que es la señal de CADUCIDAD (TTL) y aquí se ignora a propósito
  // para no borrar las copias locales.
  const eliminarVarios = (list) => {
    setSelIds([]);
    Alert.alert(L('Eliminar mensajes', 'Delete messages'), L(`¿Eliminar ${list.length} mensaje(s)?`, `Delete ${list.length} message(s)?`), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: async () => {
        const parche = { eliminado: true, texto: '', media: [], encuesta: null, preview: null, reacciones: {} };
        // URLs de R2 de la media (original + miniatura) de los mensajes
        const urls = [];
        for (const post of list) for (const m of (post.media || [])) {
          if (m && m.url) urls.push(m.url);
          if (m && m.thumbUrl) urls.push(m.thumbUrl);
        }
        // Con media, el borrado pasa por el SERVIDOR: marca eliminado Y borra
        // los objetos de R2 que ningún otro mensaje vivo referencie (los
        // reenvíos comparten URL y no se rompen).
        let hechoEnServidor = false;
        if (urls.length) {
          try {
            const apiUrl = (await getApiUrl()).replace(/\/+$/, '');
            const token = await me.getIdToken();
            const r = await fetch(`${apiUrl}/social/delete-message`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
              body: JSON.stringify({ postIds: list.map((p) => p.id) }),
            });
            const d = await r.json().catch(() => null);
            hechoEnServidor = !!(r.ok && d && d.ok);
          } catch (e) { hechoEnServidor = false; }
        }
        if (!hechoEnServidor) {
          // Respaldo (servidor sin desplegar o mensajes solo de texto):
          // borrado lógico directo, como siempre
          try { for (const post of list) await updateDoc(doc(db, 'posts', post.id), parche); } catch (e) {}
        }
        try {
          await chatStorePut(list.map((p) => ({ ...p, ...parche })));
          olvidarMediaLocal(urls);   // libera el disco local de la media borrada
          setPosts(await chatStoreAll());
        } catch (e) {}
      } },
    ]);
  };

  // Daño conocido: objeto multipart (empieza por '--boundary') o vacío,
  // producto del bug antiguo de subida. Lo 'desconocido' NO se bloquea.
  const isDamaged = async (uri) => {
    try {
      const b64 = await FileSystem.readAsync(uri, { encoding: FileSystem.EncodingType.Base64, position: 0, length: 12 });
      if (!b64 || b64.length === 0) return true;
      return b64.startsWith('LS0');   // '--' = boundary multipart = objeto corrupto
    } catch (e) {
      return false;   // si no se puede leer, no bloqueamos la apertura
    }
  };

  // Verifica el objeto YA subido a R2 (Range HTTP de 12 bytes). Si salió
  // multipart, reintenta con el uploadType contrario y recuerda el bueno.
  const remoteOk = async (publicUrl) => {
    try {
      const r = await fetch(publicUrl, { headers: { Range: 'bytes=0-11' } });
      const buf = await r.arrayBuffer();
      const b = new Uint8Array(buf);
      if (!b.length) return true;
      const multipart = b[0] === 0x2d && b[1] === 0x2d;   // '--'
      return !multipart;
    } catch (e) { return true; }
  };

  // Abrir visor estilo WhatsApp: lista de imágenes VÁLIDAS del chat + índice
  const openImage = async (url) => {
    const urls = [];
    posts.forEach((p) => (p.media || []).forEach((m) => { if (m.tipo === 'imagen' && m.url) urls.push(m.url); }));
    const valid = [];
    for (const u of urls) {
      try {
        const local = diskCache.get(u) || (await cachedOrDownload(u));
        if (!(await isDamaged(local))) valid.push(u);
      } catch (e) { valid.push(u); }
    }
    if (!valid.includes(url)) {
      Alert.alert(L('Imagen no disponible', 'Image unavailable'),
        L('Esta imagen se subió con una versión antigua de la app y está dañada; no puede mostrarse. Puedes eliminar el mensaje.',
          'This image was uploaded with an old app version and is corrupted; it cannot be displayed. You can delete the message.'));
      return;
    }
    setViewer({ index: valid.indexOf(url), urls: valid });
  };
  /* ══════════ MOTOR DE SINCRONIZACIÓN (patrón WhatsApp) ══════════
     1) El almacén local pinta el chat AL INSTANTE (sin red, sin volver a
        descargar lo que ya tienes en el dispositivo).
     2) Sincronización INCREMENTAL: solo los mensajes posteriores al último
        sincronizado (where createdAt > lastSync). Nunca todo el historial.
     3) Primera vez en un dispositivo: únicamente los 60 más recientes; el
        resto se pagina hacia atrás bajo demanda ("Cargar anteriores").
     4) Listener en vivo con docChanges(): added/modified se fusionan en el
        almacén; removed se IGNORA a propósito: la copia local se conserva
        (el servidor no purga; solo aplicaría ante borrados manuales). */
  const reloadFromStore = useCallback(async () => {
    const all = await chatStoreAll();
    setPosts(all);
    const meta = await chatStoreMeta();
    setHasMoreOld(!!meta.hasMore);
    return all;
  }, []);

  // gapSync (primera página de 60 + incremental where createdAt > lastSync)
  // vive en services/chatSync.js: aislado y verificado por
  // tests/chat-sync-test.js contra un Firestore simulado.

  // Paginación AUTOMÁTICA por zonas (patrón WhatsApp del documento duck.ai):
  // bloques de 50 más antiguos, disparados al rozar el borde superior del
  // scroll — sin botón de "descargar el chat". Mantiene la posición.
  const cargarAnteriores = useCallback(async () => {
    if (loadingOld) return;
    setLoadingOld(true);
    try {
      const { hasMore } = await loadOlderZone();
      setHasMoreOld(hasMore);
      pendingFix.current = { prevH: contentH.current, prevOff: offsetRef.current };
      setPosts(await chatStoreAll());
    } catch (e) {
      console.warn('[social] antiguos:', e.message);
    } finally {
      setLoadingOld(false);
    }
  }, [loadingOld]);

  /* Listener en vivo: solo mensajes NUEVOS o MODIFICADOS desde la marca de
     agua. docChanges() da added/modified/removed; removed se ignora: ya no
     hay purga por caducidad y la copia local permanece. */
  useEffect(() => {
    if (tab !== 'tablon') return undefined;
    let alive = true;
    let unsub = null;
    (async () => {
      try {
        await chatStoreInit();
        // La bandera de "primera carga" se levanta ANTES del primer setPosts
        // para que forzarFinalRef se consuma de forma determinista en el
        // primer onContentSizeChange (una bandera vieja arrastraría el
        // viewport más adelante). Al VOLVER de "Retos" primera=false: no se
        // fuerza nada y restaurarRef devuelve la posición guardada.
        const primera = primeraCargaRef.current;
        primeraCargaRef.current = false;
        if (primera) forzarFinalRef.current = true;
        await reloadFromStore();
        setLoading(false);
        alFinal(primera);   // 1ª apertura: al final; vuelta de "Retos": nada
        await gapSync();
        if (!alive) return;
        await reloadFromStore();
        alFinal();   // suave: solo sigue el final si el usuario ya estaba ahí
        const meta = await chatStoreMeta();
        const marca = meta.lastSync || new Date().toISOString();
        const q = query(collection(db, 'posts'), where('createdAt', '>', marca), orderBy('createdAt', 'asc'));
        unsub = onSnapshot(q, (snap) => {
          if (!alive) return;
          const up = [];
          const changes = typeof snap.docChanges === 'function' ? snap.docChanges() : [];
          for (const ch of changes) {
            if (ch.type === 'removed') continue;   // caducidad TTL: conservar local
            up.push(protegerVoto({ id: ch.doc.id, ...ch.doc.data() }));
          }
          if (!up.length) return;
          (async () => {
            await chatStorePut(up);
            const m = await chatStoreMeta();
            const maxC = up[up.length - 1].createdAt;
            if (maxC && maxC > (m.lastSync || '')) await chatStoreSetMeta({ lastSync: maxC });
            setPosts(await chatStoreAll());
            alFinal();
          })();
        }, (err) => console.warn('[social] listener:', err.message));
      } catch (e) {
        console.warn('[social] sync:', e.message);
        setLoading(false);
      }
    })();
    return () => { alive = false; if (unsub) unsub(); };
  }, [tab, reloadFromStore]);

  /* Fotos de perfil (patrón WhatsApp): la caché se inicializa una vez y se
     sincroniza con debounce cuando cambian los autores visibles. No descarga
     nada si nada cambió: lee los docs ligeros avatares/<uid> (url) y solo
     baja el archivo cuando la URL es nueva. */
  useEffect(() => { avatarCacheInit(); }, []);
  useEffect(() => {
    if (tab !== 'tablon' || posts.length === 0) return undefined;
    const uids = [...new Set(posts.map((p) => p.autorUid).filter(Boolean))];
    const t = setTimeout(() => { sincronizarAvatares(uids, me.uid).catch(() => {}); }, 600);
    return () => clearTimeout(t);
  }, [posts, tab]);

  /* Encuestas EN VIVO (WhatsApp): el listener principal solo cubre mensajes
     nuevos (createdAt > lastSync), así que los votos en encuestas antiguas
     no llegaban. Aquí se suscribe por documento a las encuestas cargadas
     (máx. 12): cada voto de cualquier persona entra al instante. La clave
     del effect es la huella (id + si tiene encuesta), de modo que los votos
     recibidos NO re-suscriben (evita bucles). */
  useEffect(() => {
    if (tab !== 'tablon') return undefined;
    const conEnc = posts.filter((p) => p.encuesta && !p.eliminado).slice(-12);
    if (conEnc.length === 0) return undefined;
    let vivo = true;
    const unsubs = [];
    for (const pe of conEnc) {
      try {
        const u = onSnapshot(doc(db, 'posts', pe.id), (snap) => {
          if (!vivo || !snap.exists()) return;
          const nuevo = protegerVoto({ id: pe.id, ...snap.data() });
          chatStorePut(nuevo).catch(() => {});
          setPosts((ps) => ps.map((x) => (x.id === nuevo.id ? { ...x, ...nuevo } : x)));
        }, () => {});
        unsubs.push(u);
      } catch (e) {}
    }
    return () => { vivo = false; for (const u of unsubs) { try { u(); } catch (e) {} } };
  }, [posts.map((p) => `${p.id}:${p.encuesta ? 'e' : ''}`).join('|'), tab]);

  /* ── Retos ── */
  const loadRetos = useCallback(async () => {
    try {
      const miPerfil = (await getCachedProfile(me.uid)) || {};
      const coach = miPerfil.entrenador || null;
      const ids = [me.uid, coach].filter(Boolean);
      const [snapCreados, snapInvitado, snapCoach] = await Promise.all([
        getDocs(query(collection(db, 'retos'), where('creadorUid', 'in', ids))),
        getDocs(query(collection(db, 'retos'), where('invitados', 'array-contains', me.uid))),
        getDocs(query(collection(db, 'perfiles'), where('entrenador', '==', me.uid), limit(1))),
      ]);
      setSoyCoach(!snapCoach.empty);
      const porId = new Map();
      [...snapCreados.docs, ...snapInvitado.docs].forEach((d) => porId.set(d.id, { id: d.id, ...d.data() }));
      const ahora = new Date();
      const activos = [], pasados = [];
      for (const r of porId.values()) {
        const fin = r.fin?.toDate?.() || new Date(r.fin);
        const ini = r.inicio?.toDate?.() || new Date(r.inicio);
        let invitados = Array.isArray(r.invitados) ? r.invitados : null;
        if (!invitados) {
          const snapAt = await getDocs(query(collection(db, 'perfiles'), where('entrenador', '==', r.creadorUid)));
          invitados = snapAt.docs.map((d) => d.id);
        }
        const aceptados = (Array.isArray(r.aceptados) ? r.aceptados : []).filter((u) => u !== r.creadorUid);
        const nombres = {};
        await Promise.all(aceptados.map(async (uid) => {
          const p = (await getCachedProfile(uid)) || {};
          nombres[uid] = p.nombre || L('Atleta', 'Athlete');
        }));
        const partSet = new Set(aceptados);
        const snapAct = await getDocs(query(collection(db, 'entrenamientos'),
          where('fecha', '>=', Timestamp.fromDate(ini)), where('fecha', '<=', Timestamp.fromDate(fin))));
        const acc = new Map();
        snapAct.docs.forEach((a) => {
          const w = a.data();
          if (w.estado !== 'completo' || !partSet.has(w.userId)) return;
          acc.set(w.userId, (acc.get(w.userId) || 0) + valorDe(w, r.metrica));
        });
        const ranking = aceptados
          .map((uid) => ({ uid, nombre: nombres[uid] || '?', valor: acc.get(uid) || 0 }))
          .sort((a, b) => b.valor - a.valor);
        const item = { ...r, ini, fin, ranking, invitados, aceptado: aceptados.includes(me.uid) || r.creadorUid === me.uid, diasRestantes: Math.ceil((fin - ahora) / 86400000) };
        (fin >= ahora ? activos : pasados).push(item);
      }
      activos.sort((a, b) => a.fin - b.fin);
      pasados.sort((a, b) => b.fin - a.fin);
      setRetos({ activos, pasados });
    } catch (e) {
      console.warn('[social] retos:', e.message);
    } finally {
      setRetosLoading(false);
    }
  }, [me.uid]);

  useEffect(() => { loadRetos().catch(() => {}); }, []);

  const aceptarReto = async (r) => {
    try {
      await updateDoc(doc(db, 'retos', r.id), { aceptados: arrayUnion(me.uid) });
      setRetosLoading(true);
      loadRetos();
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    }
  };

  /* ── Reacciones: una por persona ── */
  const reaccionar = async (post, emoji) => {
    const r = {};
    for (const e of REACCIONES) {
      const arr = (post.reacciones || {})[e] || [];
      if (e === emoji) r[e] = arr.includes(me.uid) ? arr.filter((u) => u !== me.uid) : [...arr, me.uid];
      else r[e] = arr.filter((u) => u !== me.uid);
    }
    const nuevo = { ...post, reacciones: r };
    setPosts((ps) => ps.map((p) => (p.id === post.id ? nuevo : p)));
    setSelIds([]);
    chatStorePut(nuevo).catch(() => {});   // persiste la reacción en el local
    try {
      const updates = {};
      for (const e of REACCIONES) updates[`reacciones.${e}`] = r[e];
      await updateDoc(doc(db, 'posts', post.id), updates);
    } catch (e) {}
  };

  /* Voto de encuesta (patrón WhatsApp): optimista EN PANTALLA al instante
     (antes el voto no se reflejaba hasta refrescar), persistido en el
     almacén local y en Firestore. El listener en vivo de encuestas (más
     abajo) devuelve los votos de los demás aunque la encuesta sea antigua. */
  const votarEncuesta = useCallback((post, idxOpcion) => {
    if (!post || !post.encuesta) return;
    votosRecientes.set(post.id, { idx: idxOpcion, ts: Date.now() });
    const votos = { ...(post.encuesta.votos || {}), [me.uid]: idxOpcion };
    const nuevo = { ...post, encuesta: { ...post.encuesta, votos } };
    setPosts((ps) => ps.map((x) => (x.id === post.id ? nuevo : x)));
    chatStorePut(nuevo).catch(() => {});
    updateDoc(doc(db, 'posts', post.id), { [`encuesta.votos.${me.uid}`]: idxOpcion })
      .catch((e) => console.warn('[social] voto:', e.message));
  }, [me.uid]);

  /* Fusiona un doc recibido del servidor protegiendo el voto propio recién
     hecho: los ecos iniciales de los listeners pueden llegar con el estado
     anterior al updateDoc y harían parpadear la encuesta hacia atrás. */
  const protegerVoto = (d) => {
    try {
      const rec = votosRecientes.get(d.id);
      if (rec && d.encuesta && Date.now() - rec.ts < 5000) {
        d.encuesta = { ...d.encuesta, votos: { ...(d.encuesta.votos || {}), [me.uid]: rec.idx } };
      } else if (rec && Date.now() - rec.ts >= 5000) {
        votosRecientes.delete(d.id);
      }
    } catch (e) {}
    return d;
  };

  const responder = (post) => {
    // Se guarda también el id: tocar la cita salta al mensaje original
    setReplyTo({ id: post.id, nombre: post.autorNombre, texto: post.texto || (post.media?.length ? '📎 ' + L('adjunto', 'attachment') : post.encuesta ? '📊 ' + L('encuesta', 'poll') : '') });
    setSelIds([]);
  };

  /* Saltar al mensaje citado (WhatsApp): si el original está cargado hace
     scroll hasta él y lo destella 1.6 s; si no existe (cita antigua sin id
     o mensaje de una zona aún no cargada) NO hace nada. */
  const irAMensaje = useCallback((id) => {
    if (!id) return;
    if (!posts.some((x) => x.id === id)) return;
    const m = posRef.current.get(id);
    if (m) scrollRef.current?.scrollTo({ y: Math.max(0, m.y - insets.top - 70), animated: true });
    setHighlightId(id);
    if (hlTimer.current) clearTimeout(hlTimer.current);
    hlTimer.current = setTimeout(() => setHighlightId(null), 1600);
  }, [posts, insets.top]);

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      await gapSync();
      // Refresca la ventana reciente (reacciones, encuestas, eliminados)
      // sin descargar todo el historial: solo los 120 últimos docs.
      const snap = await getDocs(query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(120)));
      await chatStorePut(snap.docs.map((d) => protegerVoto({ id: d.id, ...d.data() })));
      const all = await reloadFromStore();
      await loadRetos();
      // Refresco forzado de fotos de perfil (solo descarga las que cambiaron)
      sincronizarAvatares([...new Set(all.map((x) => x.autorUid).filter(Boolean))], me.uid, { force: true }).catch(() => {});
    } catch (e) { console.warn('[social] refresh:', e.message); }
    setRefreshing(false);
  };

  const c = {
    bg: theme.background, card: theme.card, border: theme.border,
    txt: theme.text, mut: theme.muted, acc: '#4A90E2',
    bubbleOwn: isLight ? '#D9FDD3' : '#005C4B',
    bubbleOther: isLight ? '#FFFFFF' : '#162032',
    txtBubble: isLight ? '#152238' : '#F4F8F2',
  };
  const selPosts = selIds.map((id) => posts.find((p) => p.id === id)).filter(Boolean);
  const sel = selPosts.length === 1 ? selPosts[0] : null;
  const allMine = selPosts.length > 0 && selPosts.every((p) => p.autorUid === me.uid);

  return (
    <SocialErrorBoundary>
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      {bgUri ? (
        /* Fondo TAL CUAL se subió: sin velo blanco ni tinte encima */
        <Image source={{ uri: bgUri }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} resizeMode="cover" />
      ) : null}
      {/* Cabecera flotante: pills finas sobre el chat, como la isla */}
      <View style={{ position: 'absolute', top: insets.top + 6, left: 10, right: 10, zIndex: 5 }}>
        {selPosts.length > 0 ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 13, borderRadius: 999, backgroundColor: c.card, borderWidth: 1, borderColor: c.border, paddingHorizontal: 14, paddingVertical: 9 }}>
            <TouchableOpacity onPress={() => setSelIds([])}><Ionicons name="close" size={24} color={c.txt} /></TouchableOpacity>
            <Text style={{ color: c.txt, fontWeight: '800', flex: 1, fontSize: 14 }}>{selIds.length} {L('seleccionados', 'selected')}</Text>
            {selIds.length === 1 && (
              <TouchableOpacity onPress={() => responder(sel)}><Ionicons name="arrow-undo-outline" size={25} color={c.txt} /></TouchableOpacity>
            )}
            <TouchableOpacity onPress={() => reenviarVarios(selPosts)}><Ionicons name="arrow-redo-outline" size={25} color={c.txt} /></TouchableOpacity>
            {allMine && (
              <TouchableOpacity onPress={() => eliminarVarios(selPosts)}><Ionicons name="trash-outline" size={25} color="#E05252" /></TouchableOpacity>
            )}
          </View>
        ) : (
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {[['tablon', L('Tablón', 'Feed'), 'megaphone-outline'], ['retos', L('Retos', 'Challenges'), 'trophy-outline']].map(([id, label, icon]) => (
              <Pressable key={id} onPress={() => setTab(id)} style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 6, borderRadius: 999, borderWidth: 1, borderColor: tab === id ? c.acc : c.border, backgroundColor: c.card }}>
                <Ionicons name={icon} size={15} color={tab === id ? c.acc : c.mut} />
                <Text style={{ color: tab === id ? c.acc : c.mut, fontWeight: '700', fontSize: 13 }}>{label}</Text>
              </Pressable>
            ))}
          </View>
        )}
      </View>

      {tab === 'tablon' ? (
        <View ref={branchRef} style={{ flex: 1 }}>
          <ScrollView
            ref={scrollRef}
            style={{ flex: 1 }}
            contentContainerStyle={{ paddingTop: insets.top + 46, paddingBottom: 56, paddingHorizontal: 10 }}
            onScroll={(e) => {
              const ev = e.nativeEvent;
              offsetRef.current = ev.contentOffset.y;
              // Remontaje en curso (se vuelve de "Retos"): no se evalúa nada
              // hasta que onContentSizeChange restaure la posición guardada.
              if (restaurarRef.current) return;
              // "Estar al final" con tolerancia de ~70 px (criterio WhatsApp):
              // solo en ese caso los mensajes nuevos arrastran el viewport.
              const dist = ev.contentSize.height - ev.layoutMeasurement.height - ev.contentOffset.y;
              enElFinalRef.current = dist <= 70;
              if (enElFinalRef.current && nuevosSinVer !== 0) setNuevosSinVer(0);
              // FAB ↓: visible si NO se está al final y el chat desborda la pantalla
              const fab = !enElFinalRef.current && ev.contentSize.height > ev.layoutMeasurement.height + 120;
              if (fab !== mostrarIrAbajoRef.current) { mostrarIrAbajoRef.current = fab; setMostrarIrAbajo(fab); }
              // Zonas automáticas estilo WhatsApp: al rozar el borde superior
              // se carga el siguiente bloque de 50 (sin ningún botón).
              if (offsetRef.current < 220 && hasMoreOld && !loadingOld) cargarAnteriores();
            }}
            scrollEventThrottle={16}
            onContentSizeChange={(w, h) => {
              contentH.current = h;
              // Al PREPENDER historial antiguo mantiene el viewport en el
              // mismo mensaje (el contenido crece por arriba).
              const fix = pendingFix.current;
              if (fix) {
                pendingFix.current = null;
                prevCountRef.current = posts.length;
                scrollRef.current?.scrollTo({ y: Math.max(0, h - fix.prevH + fix.prevOff), animated: false });
                return;
              }
              // Al VOLVER de la pestaña "Retos": restaura la posición guardada
              // en cuanto el layout ha reproducido el alto que tenía al salir.
              // Mientras se remonta NUNCA se hace scrollToEnd (era el salto).
              const rest = restaurarRef.current;
              if (rest) {
                if (h >= rest.h * 0.98) {
                  restaurarRef.current = null;
                  prevCountRef.current = posts.length;
                  scrollRef.current?.scrollTo({ y: rest.y, animated: false });
                }
                return;
              }
              // Solo se "sigue el chat" cuando AUMENTAN los mensajes. Un
              // cambio de altura por votar una encuesta, reaccionar,
              // seleccionar un mensaje o cargarse una imagen YA NO mueve el
              // viewport (ese era el salto molesto al último mensaje).
              const nuevos = posts.length - prevCountRef.current;
              prevCountRef.current = posts.length;
              if (nuevos <= 0) return;
              if (forzarFinalRef.current || enElFinalRef.current) {
                // Mensaje propio / primera apertura, o ya se estaba abajo:
                // se sigue la conversación hasta el final.
                forzarFinalRef.current = false;
                scrollRef.current?.scrollToEnd({ animated: false });
              } else {
                // Leyendo historial: no se interrumpe; los no vistos se
                // acumulan en la insignia del FAB ↓.
                setNuevosSinVer((n) => n + nuevos);
              }
            }}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={c.mut} />}
          >
            {posts.length > 0 && (
              hasMoreOld ? (
                loadingOld ? (
                  <View style={{ alignSelf: 'center', marginVertical: 8 }}>
                    <ActivityIndicator size="small" color={c.acc} />
                  </View>
                ) : null
              ) : (
                <Text style={{ color: c.mut, fontSize: 10, textAlign: 'center', marginBottom: 8 }}>
                  {L('Inicio del historial · este es el primer mensaje del chat', 'Start of history · this is the first message of the chat')}
                </Text>
              )
            )}
            {loading && posts.length === 0 ? (
              <ActivityIndicator style={{ marginTop: 40 }} color={c.acc} />
            ) : posts.length === 0 ? (
              <View style={{ alignItems: 'center', marginTop: 60, gap: 8 }}>
                <Ionicons name="megaphone-outline" size={40} color={c.mut} />
                <Text style={{ color: c.mut }}>{L('Aún no hay mensajes. ¡Estrena el tablón!', 'No messages yet. Be the first!')}</Text>
              </View>
            ) : posts.map((p, i) => {
              // Separador de fecha estilo WhatsApp entre mensajes de días
              // distintos: HOY / AYER / nombre del día / fecha con mes y año.
              const prev = posts[i - 1];
              const nuevoDia = !prev || claveDia(prev.createdAt) !== claveDia(p.createdAt);
              return (
                <React.Fragment key={p.id}>
                  {nuevoDia && (
                    <View style={{ alignItems: 'center', marginVertical: 9 }}>
                      <View style={{ backgroundColor: 'rgba(0,0,0,0.42)', borderRadius: 16, paddingHorizontal: 14, paddingVertical: 6, maxWidth: '85%' }}>
                        <Text style={{ color: '#FFFFFFF2', fontSize: 12, fontWeight: '700', letterSpacing: 0.3 }}>{fmtSeparador(p.createdAt, loc, L)}</Text>
                      </View>
                    </View>
                  )}
                  <View onLayout={(ev) => { posRef.current.set(p.id, { y: ev.nativeEvent.layout.y }); }}>
                    <SocialErrorBoundary>
                      <Burbuja p={p} me={me.uid} c={c} loc={loc} isLight={isLight}
                        selected={selIds.includes(p.id)} highlighted={highlightId === p.id}
                        onTapReply={irAMensaje} onVote={votarEncuesta}
                        onLongPress={() => toggleSel(p.id)} onOpenImage={openImage} />
                    </SocialErrorBoundary>
                  </View>
                </React.Fragment>
              );
            })}
          </ScrollView>

          {/* Columna flotante: barra de reacciones + isla, encima del chat */}
          <View style={{ position: 'absolute', left: 0.25, right: 0.25, bottom: islandBottom }}>
            {selPosts.length === 1 && (
              <View style={{ marginBottom: 6, borderRadius: 999, backgroundColor: c.bubbleOther, borderWidth: 1, borderColor: c.border, flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 6, paddingHorizontal: 4 }}>
                {REACCIONES.map((e) => (
                  <Pressable key={e} onPress={() => reaccionar(sel, e)} style={{ paddingHorizontal: 7, paddingVertical: 3 }}>
                    <Text style={{ fontSize: 22 }}>{e}</Text>
                  </Pressable>
                ))}
              </View>
            )}
            {mostrarIrAbajo && (
              <View pointerEvents="box-none" style={{ flexDirection: 'row', justifyContent: 'flex-end', paddingRight: 6, marginBottom: 8 }}>
                {/* FAB ↓ estilo WhatsApp: círculo con el MISMO aspecto que las
                    fichas de fecha del chat (negro translúcido + blanco) e
                    insignia con los mensajes no vistos mientras se lee arriba */}
                <Pressable
                  onPress={irAlFinal}
                  style={({ pressed }) => ({
                    width: 42, height: 42, borderRadius: 21,
                    backgroundColor: pressed ? 'rgba(0,0,0,0.58)' : 'rgba(0,0,0,0.42)',
                    alignItems: 'center', justifyContent: 'center',
                    borderWidth: 1, borderColor: 'rgba(255,255,255,0.16)',
                    elevation: 3, shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 3, shadowOffset: { width: 0, height: 1 },
                  })}
                >
                  <Ionicons name="chevron-down" size={24} color="#FFFFFFF2" />
                  {nuevosSinVer > 0 && (
                    <View style={{ position: 'absolute', top: -7, right: -7, minWidth: 20, height: 20, paddingHorizontal: 5, borderRadius: 10, backgroundColor: c.acc, alignItems: 'center', justifyContent: 'center' }}>
                      <Text style={{ color: '#FFFFFF', fontSize: 11, fontWeight: '800' }}>{nuevosSinVer > 99 ? '99+' : nuevosSinVer}</Text>
                    </View>
                  )}
                </Pressable>
              </View>
            )}
            <ComposerIsland c={c} L={L} replyTo={replyTo} onCancelReply={() => setReplyTo(null)}
              onPublicado={() => { forzarFinalRef.current = true; reloadFromStore().then(() => alFinal(true)); }} />
          </View>
        </View>
      ) : (
        <ScrollView contentContainerStyle={{ paddingTop: insets.top + 46, paddingBottom: 16 }} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={c.mut} />}>
          {soyCoach && (
            <TouchableOpacity onPress={() => setCreaRetoOpen(true)} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginHorizontal: 16, marginBottom: 12, paddingVertical: 12, borderRadius: 14, backgroundColor: c.acc }}>
              <Ionicons name="add-circle-outline" size={19} color="#fff" />
              <Text style={{ color: '#fff', fontWeight: '800' }}>{L('Crear reto e invitar atletas', 'Create challenge & invite')}</Text>
            </TouchableOpacity>
          )}
          {retosLoading ? <ActivityIndicator style={{ marginTop: 40 }} color={c.acc} /> : (
            <>
              <Text style={{ color: c.mut, marginHorizontal: 16, marginBottom: 6, fontWeight: '700' }}>{L('RETOS ACTIVOS', 'ACTIVE CHALLENGES')}</Text>
              {retos.activos.length === 0 && (
                <View style={{ alignItems: 'center', marginVertical: 30, gap: 8 }}>
                  <Ionicons name="trophy-outline" size={40} color={c.mut} />
                  <Text style={{ color: c.mut }}>{L('No hay retos activos ahora mismo.', 'No active challenges right now.')}</Text>
                </View>
              )}
              {retos.activos.map((r) => (
                <RetoCard key={r.id} r={r} activo c={c} loc={loc} L={L} meUid={me.uid} onAceptar={() => aceptarReto(r)} />
              ))}
              <Text style={{ color: c.mut, marginHorizontal: 16, marginTop: 18, marginBottom: 6, fontWeight: '700' }}>{L('HISTORIAL', 'HISTORY')}</Text>
              {retos.pasados.length === 0 && (
                <Text style={{ color: c.mut, marginHorizontal: 16 }}>{L('Todavía no hay retos terminados.', 'No finished challenges yet.')}</Text>
              )}
              {retos.pasados.map((r) => (
                <RetoCard key={r.id} r={r} c={c} loc={loc} L={L} meUid={me.uid} />
              ))}
            </>
          )}
        </ScrollView>
      )}

      {viewer && (
        <FocalViewer urls={viewer.urls} initialIndex={viewer.index} onClose={() => setViewer(null)} />
      )}
      {creaRetoOpen && (
        <CreaReto
          onClose={() => setCreaRetoOpen(false)}
          c={c} L={L}
          onCreado={() => { setCreaRetoOpen(false); setRetosLoading(true); loadRetos(); }}
        />
      )}
    </View>
    </SocialErrorBoundary>
  );
}

/* ══════════════ BURBUJA estilo WhatsApp ══════════════ */
function Burbuja({ p, me, c, loc, isLight, onLongPress, onOpenImage, selected, highlighted, onTapReply, onVote }) {
  const mio = p.autorUid === me;
  // Borrado lógico estilo WhatsApp: el doc sigue existiendo pero vaciado
  if (p.eliminado) {
    return (
      <View style={{ flexDirection: 'row', marginVertical: 3, justifyContent: mio ? 'flex-end' : 'flex-start' }}>
        {!mio && <AvatarChat uid={p.autorUid} nombre={p.autorNombre} dim />}
        <View style={{ maxWidth: '78%', borderRadius: 14, backgroundColor: isLight ? '#0000000A' : '#FFFFFF0D', borderWidth: isLight ? 1 : 0, borderColor: c.border, paddingHorizontal: 10, paddingVertical: 7 }}>
          <Text style={{ color: c.mut, fontSize: 13, fontStyle: 'italic' }}>🚫 {mio ? 'Mensaje eliminado' : 'Mensaje eliminado'}</Text>
          <View style={{ flexDirection: 'row', alignItems: 'flex-end', marginTop: 2 }}>
            <View style={{ flex: 1 }} />
            <Text style={{ color: isLight ? '#00000066' : '#FFFFFF77', fontSize: 11 }}>{fmtHora(p.createdAt, loc)}</Text>
          </View>
        </View>
      </View>
    );
  }
  const reacs = Object.entries(p.reacciones || {}).filter(([, arr]) => arr && arr.length > 0);
  return (
    <View style={{ flexDirection: 'row', marginVertical: 3, justifyContent: mio ? 'flex-end' : 'flex-start' }}>
      {!mio && <AvatarChat uid={p.autorUid} nombre={p.autorNombre} />}
      <Pressable onLongPress={onLongPress} delayLongPress={280}
        style={{ maxWidth: p.encuesta ? '94%' : '78%', borderRadius: 14, backgroundColor: mio ? c.bubbleOwn : c.bubbleOther, borderWidth: selected || highlighted ? 2.5 : (isLight ? 1 : 0), borderColor: selected || highlighted ? '#8AB4F8' : c.border, paddingHorizontal: 10, paddingVertical: 7, overflow: 'hidden' }}>
        {!mio && <Text style={{ color: colorDe(p.autorUid), fontWeight: '800', fontSize: 13, marginBottom: 2 }}>{p.autorNombre}</Text>}
        {!!p.reenviado && <Text style={{ color: c.mut, fontSize: 11, fontStyle: 'italic', marginBottom: 2 }}>↪ Reenviado</Text>}
        {p.replyTo && (
          /* Tocar la cita salta al mensaje original si está cargado */
          <Pressable onPress={() => { if (onTapReply) onTapReply(p.replyTo.id); }}
            style={{ backgroundColor: isLight ? '#00000010' : '#FFFFFF14', borderLeftWidth: 3, borderLeftColor: c.acc, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 5, marginBottom: 5 }}>
            <Text style={{ color: c.acc, fontWeight: '800', fontSize: 12 }}>{p.replyTo.nombre}</Text>
            <Text style={{ color: c.mut, fontSize: 12 }} numberOfLines={2}>{p.replyTo.texto}</Text>
          </Pressable>
        )}
        <VistaPrevia p={p} c={c} isLight={isLight} />
        {!!p.texto && <TextoEnlaces texto={p.texto} c={c} isLight={isLight} />}
        {(p.media || []).map((m, i) => (
          m.tipo === 'imagen'
            ? <FotoBurbuja key={i} m={m} c={c} isLight={isLight} onPress={() => onOpenImage(m.url)} />
            : <ChipArchivo key={i} m={m} c={c} isLight={isLight} />
        ))}
        {p.encuesta && <EncuestaBurbuja p={p} c={c} me={me} isLight={isLight} onVotar={onVote} />}
        <View style={{ flexDirection: 'row', alignItems: 'flex-end', marginTop: 2 }}>
          <View style={{ flex: 1 }} />
          <Text style={{ color: isLight ? '#00000066' : '#FFFFFF77', fontSize: 11 }}>{fmtHora(p.createdAt, loc)}</Text>
        </View>
        {reacs.length > 0 && (
          <View style={{ flexDirection: 'row', gap: 4, marginTop: 4, flexWrap: 'wrap' }}>
            {reacs.map(([e, arr]) => (
              <View key={e} style={{ flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: isLight ? '#00000010' : '#FFFFFF18', borderRadius: 999, paddingHorizontal: 6, paddingVertical: 2 }}>
                <Text style={{ fontSize: 13 }}>{e}</Text>
                {arr.length > 1 && <Text style={{ fontSize: 11, color: c.txtBubble, fontWeight: '700' }}>{arr.length}</Text>}
              </View>
            ))}
          </View>
        )}
      </Pressable>
    </View>
  );
}

/* ── Avatar del chat (patrón WhatsApp, services/avatarCache.js): pinta la
      foto desde el DISCO local (se descargó una sola vez); si la persona
      cambia su foto, la caché la vuelve a bajar y este componente se
      redibuja solo (useAvatar). Sin foto (o archivo dañado): inicial
      coloreada de siempre. ── */
function AvatarChat({ uid, nombre, dim }) {
  const uri = useAvatar(uid);
  const [falla, setFalla] = useState(false);
  useEffect(() => { setFalla(false); }, [uri]);
  const base = { width: 32, height: 32, borderRadius: 16, marginRight: 7, alignSelf: 'flex-end', overflow: 'hidden', opacity: dim ? 0.45 : 1 };
  if (uri && !falla) {
    return (
      <View style={[base, { backgroundColor: colorDe(uid) }]}>
        <ExpoImage source={{ uri }} style={{ width: 32, height: 32 }} contentFit="cover" cachePolicy="memory-disk" transition={120} onError={() => setFalla(true)} />
      </View>
    );
  }
  return (
    <View style={[base, { backgroundColor: colorDe(uid), alignItems: 'center', justifyContent: 'center' }]}>
      <Text style={{ color: '#fff', fontWeight: '800', fontSize: 14 }}>{(nombre || '?').charAt(0).toUpperCase()}</Text>
    </View>
  );
}

/* ── Texto con enlaces pinchables (WhatsApp): las URLs del mensaje se
      detectan (services/enlaces.js, puro y con tests), se pintan en azul +
      subrayado y al tocarlas se abren en el navegador. La pulsación larga
      sigue llegando al Pressable padre (selección del mensaje). ── */
function TextoEnlaces({ texto, c, isLight }) {
  const segs = useMemo(() => segmentar(texto), [texto]);
  const colorLink = isLight ? '#027EB5' : '#53BDEB';
  const abrir = (u) => { try { Linking.openURL(normalizarUrl(u)); } catch (e) {} };
  return (
    <Text style={{ color: c.txtBubble, fontSize: 15, lineHeight: 21 }}>
      {segs.map((sg, i) => (sg.url ? (
        <Text key={i} style={{ color: colorLink, textDecorationLine: 'underline' }} onPress={() => abrir(sg.v)}>{sg.v}</Text>
      ) : (
        <Text key={i}>{sg.v}</Text>
      )))}
    </Text>
  );
}

/* ── Tarjeta de previsualización de enlace (WhatsApp): miniatura + título +
      descripción + dominio, tocables. Los datos viajan ADJUNTOS al mensaje
      (campo preview, generados por quien lo envía); los mensajes antiguos
      sin preview lo piden una sola vez al servidor y lo cachean 7 días
      (services/linkPreview.js). Con fotos/archivos en el mensaje no se
      muestra (WhatsApp solo despliega enlaces de texto). ── */
function VistaPrevia({ p, c, isLight }) {
  const urlTxt = useMemo(() => primeraUrl(p.texto || ''), [p.texto]);
  const [prev, setPrev] = useState(() => ((p.preview && (p.preview.titulo || p.preview.imagen)) ? p.preview : null));
  useEffect(() => {
    setPrev((p.preview && (p.preview.titulo || p.preview.imagen)) ? p.preview : null);
  }, [p.preview]);
  useEffect(() => {
    if (prev || !urlTxt || (p.media || []).length) return undefined;
    let vivo = true;
    obtenerPreview(urlTxt).then((r) => { if (vivo && r) setPrev(r); }).catch(() => {});
    return () => { vivo = false; };
  }, [urlTxt, prev, p.media]);
  if (!urlTxt || (p.media || []).length) return null;
  if (!prev || (!prev.titulo && !prev.imagen)) return null;
  const colorLink = isLight ? '#027EB5' : '#53BDEB';
  const dominio = prev.dominio || dominioDe(prev.url || urlTxt);
  const abrir = () => { try { Linking.openURL(normalizarUrl(prev.url || urlTxt)); } catch (e) {} };
  return (
    <TouchableOpacity onPress={abrir} activeOpacity={0.85}
      style={{ minWidth: 235, maxWidth: 300, marginTop: 2, marginBottom: 5, borderRadius: 12, overflow: 'hidden', backgroundColor: isLight ? '#00000008' : '#FFFFFF10', borderWidth: 1, borderColor: isLight ? '#00000014' : '#FFFFFF1A' }}>
      {!!prev.imagen && (
        <ExpoImage source={{ uri: prev.imagen }} style={{ width: '100%', height: 130, backgroundColor: isLight ? '#0000000A' : '#FFFFFF10' }} contentFit="cover" cachePolicy="memory-disk" transition={150} />
      )}
      <View style={{ paddingHorizontal: 10, paddingVertical: 8, gap: 3 }}>
        {!!prev.titulo && <Text numberOfLines={2} style={{ color: c.txtBubble, fontWeight: '800', fontSize: 13.5, lineHeight: 18 }}>{prev.titulo}</Text>}
        {!!prev.descripcion && <Text numberOfLines={2} style={{ color: c.mut, fontSize: 12, lineHeight: 16 }}>{prev.descripcion}</Text>}
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 1 }}>
          <Ionicons name="link-outline" size={11} color={colorLink} />
          <Text numberOfLines={1} style={{ color: colorLink, fontSize: 11, fontWeight: '700' }}>{dominio}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

/* ── Imagen de burbuja: pinta la MINIATURA 640 px (thumbUrl) con expo-image
      (decodificación y caché memoria+disco eficientes); el tap abre el visor
      con el ORIGINAL. Mensajes antiguos sin thumbUrl: se usa el original. ── */
function FotoBurbuja({ m, c, isLight, onPress }) {
  const [cached, setCached] = useState(null);
  const showUrl = m.thumbUrl || m.url;
  useEffect(() => {
    if (!showUrl) return undefined;
    let alive = true;
    cachedOrDownload(showUrl).then((u) => { if (alive) setCached(u); }).catch(() => { if (alive) setCached(showUrl); });
    return () => { alive = false; };
  }, [showUrl]);
  if (!m.url) {
    // Posts antiguos cuya subida nunca terminó: placeholder en vez de crash
    return (
      <View style={{ width: 220, height: 120, borderRadius: 10, marginTop: 5, backgroundColor: isLight ? '#00000010' : '#FFFFFF10', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
        <Ionicons name="image-outline" size={26} color={c.mut} />
        <Text style={{ color: c.mut, fontSize: 11 }}>{'Imagen no disponible'}</Text>
      </View>
    );
  }
  const uri = cached || showUrl;
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.85}>
      <ExpoImage source={{ uri }} style={{ width: 220, height: 220, borderRadius: 10, marginTop: 5, backgroundColor: isLight ? '#00000010' : '#FFFFFF10' }} contentFit="cover" cachePolicy="memory-disk" transition={120} />
    </TouchableOpacity>
  );
}

/* ── Tarjeta de archivo estilo WhatsApp: más ancha y más alta que el chip
      viejo (icono por tipo, nombre, extensión · tamaño). Los AUDIOS se
      reproducen dentro del propio chat (expo-audio, uno a la vez) y el
      resto de archivos se abre con el visor del sistema. ── */
function ChipArchivo({ m, c, isLight }) {
  if (esAudioMedia(m)) return <AudioBurbuja m={m} c={c} isLight={isLight} />;
  const meta = [extDe(m.nombre) || 'ARCHIVO', fmtSize(m.size)].filter(Boolean).join(' · ');
  return (
    <TouchableOpacity onPress={() => { if (m.url) Linking.openURL(m.url); }}
      style={{ flexDirection: 'row', alignItems: 'center', gap: 11, minWidth: 240, maxWidth: 300, minHeight: 66, marginTop: 6, marginBottom: 2, paddingHorizontal: 12, paddingVertical: 10, borderRadius: 14, backgroundColor: isLight ? '#0000000D' : '#FFFFFF14' }}>
      <View style={{ width: 40, height: 48, borderRadius: 8, backgroundColor: '#D35400', alignItems: 'center', justifyContent: 'center' }}>
        <Ionicons name="document-text-outline" size={22} color="#fff" />
      </View>
      <View style={{ flex: 1, gap: 3 }}>
        <Text style={{ color: c.txtBubble, fontSize: 14, fontWeight: '700' }} numberOfLines={2}>{m.nombre || 'archivo'}</Text>
        {!!meta && <Text style={{ color: c.mut, fontSize: 11 }} numberOfLines={1}>{meta}</Text>}
      </View>
      <Ionicons name="download-outline" size={18} color={c.mut} />
    </TouchableOpacity>
  );
}

/* ── Audio en el chat (WhatsApp): botón play/pause, barra de progreso con
      seek al tocar y duración. Solo suena UN audio a la vez; el archivo se
      baja a disco la primera vez (misma caché single-flight que imágenes). ── */
let playerActivo = null;
let modoAudioOk = false;
async function asegurarModoAudio() {
  if (modoAudioOk || !AudioLib) return;
  modoAudioOk = true;
  try { await AudioLib.setAudioModeAsync({ playsInSilentMode: true }); } catch (e) {}
}

function AudioBurbuja({ m, c, isLight }) {
  const caja = { flexDirection: 'row', alignItems: 'center', gap: 11, minWidth: 250, maxWidth: 300, marginTop: 6, marginBottom: 2, paddingHorizontal: 11, paddingVertical: 9, borderRadius: 14, backgroundColor: isLight ? '#0000000D' : '#FFFFFF14' };
  if (!AudioLib || !m.url) {
    // Binario sin expo-audio (OTA antigua) o sin URL: tarjeta que lo abre
    return (
      <TouchableOpacity onPress={() => { if (m.url) Linking.openURL(m.url); }} style={caja}>
        <View style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: '#8E44AD', alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="musical-notes-outline" size={20} color="#fff" />
        </View>
        <View style={{ flex: 1, gap: 3 }}>
          <Text style={{ color: c.txtBubble, fontSize: 14, fontWeight: '700' }} numberOfLines={1}>{m.nombre || 'Audio'}</Text>
          <Text style={{ color: c.mut, fontSize: 11 }} numberOfLines={1}>{['AUDIO', fmtSize(m.size)].filter(Boolean).join(' · ')}</Text>
        </View>
        <Ionicons name="play-circle-outline" size={22} color={c.mut} />
      </TouchableOpacity>
    );
  }
  return <ReproductorAudio m={m} c={c} isLight={isLight} caja={caja} />;
}

function ReproductorAudio({ m, c, isLight, caja }) {
  const [localUri, setLocalUri] = useState(() => diskCache.get(m.url) || null);
  const [bajando, setBajando] = useState(false);
  const [barW, setBarW] = useState(1);
  const cargada = useRef(false);
  const player = AudioLib.useAudioPlayer(null, { updateInterval: 250 });
  const status = AudioLib.useAudioPlayerStatus(player);

  // Al desmontar: si este audio sonaba, se detiene (nunca se queda sonando)
  useEffect(() => () => {
    if (playerActivo === player) playerActivo = null;
    try { player.pause(); } catch (e) {}
  }, []);

  const toggle = async () => {
    try {
      await asegurarModoAudio();
      let uri = localUri;
      if (!uri) {
        setBajando(true);
        try { uri = diskCache.get(m.url) || (await cachedOrDownload(m.url)); } finally { setBajando(false); }
        if (!uri) return;
        setLocalUri(uri);
      }
      if (!cargada.current) { player.replace({ uri }); cargada.current = true; }
      if (status && status.playing) { player.pause(); return; }
      // Un solo audio a la vez, como WhatsApp
      if (playerActivo && playerActivo !== player) { try { playerActivo.pause(); } catch (e) {} }
      playerActivo = player;
      if (status && status.didJustFinish) { try { await player.seekTo(0); } catch (e) {} }
      player.play();
    } catch (e) {}
  };

  const dur = status && status.duration > 0 ? status.duration : 0;
  const cur = status && status.currentTime > 0 ? Math.min(status.currentTime, dur || status.currentTime) : 0;
  const pct = dur > 0 ? Math.max(0, Math.min(1, cur / dur)) : 0;
  const playing = !!(status && status.playing);

  const seek = (ev) => {
    if (!dur) return;
    const x = ev && ev.nativeEvent ? ev.nativeEvent.locationX : 0;
    try { player.seekTo(Math.max(0, Math.min(1, x / (barW || 1))) * dur); } catch (e) {}
  };

  return (
    <View style={caja}>
      <TouchableOpacity onPress={toggle} style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: c.acc, alignItems: 'center', justifyContent: 'center' }}>
        {bajando ? <ActivityIndicator size="small" color="#fff" />
          : <Ionicons name={playing ? 'pause' : 'play'} size={playing ? 20 : 22} color="#fff" style={playing ? undefined : { marginLeft: 3 }} />}
      </TouchableOpacity>
      <View style={{ flex: 1, gap: 5 }}>
        <Text style={{ color: c.txtBubble, fontSize: 13, fontWeight: '700' }} numberOfLines={1}>{m.nombre || 'Audio'}</Text>
        <Pressable onPress={seek} onLayout={(e) => setBarW(e.nativeEvent.layout.width || 1)}
          style={{ height: 6, borderRadius: 3, backgroundColor: isLight ? '#00000022' : '#FFFFFF30', overflow: 'hidden' }}>
          <View style={{ width: `${Math.round(pct * 100)}%`, height: 6, borderRadius: 3, backgroundColor: c.acc }} />
        </Pressable>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Text style={{ color: c.mut, fontSize: 11 }}>{fmtDur(cur)}</Text>
          <Text style={{ color: c.mut, fontSize: 11 }}>{dur > 0 ? fmtDur(dur) : fmtSize(m.size) || 'AUDIO'}</Text>
        </View>
      </View>
    </View>
  );
}

/* ── Encuesta dentro de la burbuja (WhatsApp): cuadro MÁS ANCHO (la burbuja
      sube a 94% cuando hay encuesta), barra de color por opción, insignia
      "GANANDO" en la líder (empates: varias), check en tu voto, recuento y
      porcentajes EN VIVO. Tocar vota; tocar otra opción cambia el voto. ── */
function EncuestaBurbuja({ p, c, me, isLight, onVotar }) {
  const enc = p.encuesta || {};
  const opciones = enc.opciones || [];
  const r = contarVotos(enc, me);
  return (
    <View style={{ minWidth: 255, marginTop: 6, marginBottom: 2, gap: 6 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
        <Ionicons name="stats-chart" size={15} color={c.acc} />
        <Text style={{ color: c.txtBubble, fontWeight: '800', fontSize: 14, flex: 1 }}>{enc.pregunta || 'Encuesta'}</Text>
      </View>
      {opciones.map((op, i) => {
        const color = colorOpcion(i);
        const n = r.porOpcion[i] || 0;
        const pct = r.porcentajes[i] || 0;
        const lider = n > 0 && r.lideres.indexOf(i) >= 0;
        const mio = r.mio === i;
        return (
          <TouchableOpacity key={i} activeOpacity={0.8} onPress={() => { if (onVotar) onVotar(p, i); }}
            style={{ borderRadius: 11, borderWidth: lider ? 1.8 : 1.2, borderColor: lider ? color : (mio ? c.acc : (isLight ? '#00000022' : '#FFFFFF2E')), backgroundColor: isLight ? '#FFFFFFCC' : '#0C1425CC', overflow: 'hidden' }}>
            <View style={{ position: 'absolute', top: 0, bottom: 0, left: 0, width: `${pct}%`, backgroundColor: color + (lider ? '66' : '33') }} />
            <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 9, gap: 7 }}>
              <Text style={{ flex: 1, color: c.txtBubble, fontSize: 13, fontWeight: lider ? '800' : '600' }} numberOfLines={2}>{op}</Text>
              {lider && (
                <View style={{ backgroundColor: color, borderRadius: 999, paddingHorizontal: 6, paddingVertical: 1.5 }}>
                  <Text style={{ color: '#fff', fontSize: 9, fontWeight: '800', letterSpacing: 0.4 }}>GANANDO</Text>
                </View>
              )}
              {mio && <Ionicons name="checkmark-circle" size={16} color={c.acc} />}
              <Text style={{ color: c.mut, fontSize: 11.5, fontWeight: '700' }}>{n > 0 ? `${pct}% · ${n}` : '—'}</Text>
            </View>
          </TouchableOpacity>
        );
      })}
      <Text style={{ color: c.mut, fontSize: 11 }}>
        {r.total === 1 ? '1 voto' : `${r.total} votos`} · {r.mio != null ? 'toca otra opción para cambiar tu voto' : 'toca una opción para votar'}
      </Text>
    </View>
  );
}

/* ── Visor a pantalla completa con ZOOM (pellizco + doble toque) ── */
/* ══════════════ TARJETA DE RETO ══════════════ */
function RetoCard({ r, activo, c, loc, L, meUid, onAceptar }) {
  const met = METRICAS.find((m) => m.id === r.metrica) || METRICAS[0];
  const ganador = r.ranking?.[0];
  const soyCreador = r.creadorUid === meUid;
  const invitado = (r.invitados || []).includes(meUid) || soyCreador;
  return (
    <View style={{ marginHorizontal: 16, marginBottom: 12, borderRadius: 16, backgroundColor: c.card, borderWidth: 1, borderColor: activo ? '#F5A62366' : c.border, padding: 14 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
        <Ionicons name="trophy" size={19} color={activo ? '#F5A623' : c.mut} />
        <Text style={{ color: c.txt, fontWeight: '800', flex: 1 }}>{r.titulo}</Text>
        {activo && (
          <View style={{ paddingHorizontal: 9, paddingVertical: 4, borderRadius: 999, backgroundColor: '#F5A62322' }}>
            <Text style={{ color: '#F5A623', fontWeight: '800', fontSize: 12 }}>
              {r.diasRestantes <= 0 ? L('último día', 'last day') : `${r.diasRestantes} ${L('días', 'days')}`}
            </Text>
          </View>
        )}
      </View>
      {!!r.descripcion && <Text style={{ color: c.mut, marginTop: 6 }}>{r.descripcion}</Text>}
      <Text style={{ color: c.mut, fontSize: 12, marginTop: 6 }}>
        {fmtDia(r.inicio, loc)} → {fmtDia(r.fin, loc)} · {met.label} · {L('creado por', 'by')} {r.creadorNombre || '?'}
      </Text>
      {activo && invitado && !r.aceptado && (
        <TouchableOpacity onPress={onAceptar} style={{ marginTop: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 11, borderRadius: 12, backgroundColor: '#2DB37A' }}>
          <Ionicons name="checkmark-circle-outline" size={18} color="#fff" />
          <Text style={{ color: '#fff', fontWeight: '800' }}>{L('Aceptar reto', 'Accept challenge')}</Text>
        </TouchableOpacity>
      )}
      {(r.aceptado || !activo) && (
        <View style={{ marginTop: 10, gap: 6 }}>
          {(r.ranking || []).slice(0, activo ? 8 : 3).map((row, i) => (
            <View key={row.uid} style={{ flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 10, backgroundColor: row.uid === meUid ? c.acc + '18' : c.bg, borderWidth: 1, borderColor: row.uid === meUid ? c.acc + '55' : 'transparent' }}>
              <Text style={{ width: 22, textAlign: 'center', fontWeight: '800', color: i === 0 ? '#F5A623' : c.mut }}>
                {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : i + 1}
              </Text>
              <Text style={{ color: c.txt, flex: 1 }} numberOfLines={1}>{row.nombre}{row.uid === meUid ? ` (${L('tú', 'you')})` : ''}</Text>
              <Text style={{ color: i === 0 ? '#F5A623' : c.txt, fontWeight: '800' }}>{fmtValor(row.valor, r.metrica)}</Text>
            </View>
          ))}
          {(r.ranking || []).length === 0 && (
            <Text style={{ color: c.mut, fontSize: 12 }}>{L('Nadie ha aceptado el reto todavía.', 'Nobody accepted the challenge yet.')}</Text>
          )}
        </View>
      )}
      {!activo && ganador && (
        <Text style={{ color: c.mut, marginTop: 8, fontSize: 12 }}>
          {L('Ganador', 'Winner')}: <Text style={{ color: c.txt, fontWeight: '800' }}>{ganador.nombre}</Text> · {fmtValor(ganador.valor, r.metrica)}
        </Text>
      )}
    </View>
  );
}

/* ══════════════ ISLA DE COMPOSICIÓN ══════════════ */
function ComposerIsland({ c, L, onPublicado, replyTo, onCancelReply }) {
  const me = auth.currentUser;
  const [texto, setTexto] = useState('');
  const [media, setMedia] = useState([]);
  const [encuesta, setEncuesta] = useState(null);
  const [panelEnc, setPanelEnc] = useState(false);
  const [sending, setSending] = useState(false);
  const [txtH, setTxtH] = useState(22);

  const pickFiles = async () => {
    const r = await DocumentPicker.getDocumentAsync({ type: '*/*', multiple: true, copyToCacheDirectory: true });
    if (r.canceled) return;
    const adds = (r.assets || []).map((a) => ({
      uri: a.uri, nombre: a.name || 'archivo', size: a.size || 0,
      contentType: a.mimeType || 'application/octet-stream',
      tipo: (a.mimeType || '').startsWith('image/') ? 'imagen' : 'archivo',
    }));
    setMedia((m) => [...m, ...adds]);
  };
  const pickCamera = async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      Alert.alert(L('Permiso requerido', 'Permission required'), L('Activa la cámara para hacer fotos.', 'Enable camera to take photos.'));
      return;
    }
    const r = await ImagePicker.launchCameraAsync({ quality: 0.8 });
    if (r.canceled) return;
    const adds = [];
    for (const a of r.assets) {
      const info = await FileSystem.getInfoAsync(a.uri);
      adds.push({ uri: a.uri, nombre: a.fileName || `foto-${Date.now()}.jpg`, size: info.size || 0, contentType: a.mimeType || 'image/jpeg', tipo: 'imagen' });
    }
    setMedia((m) => [...m, ...adds]);
  };

  /* Publicar AL INSTANTE: el post sale ya con la miniatura local y el aro de
     progreso; las subidas a R2 continúan en segundo plano. */
  const publicar = async () => {
    if (!texto.trim() && media.length === 0 && !(encuesta && encuesta.pregunta.trim())) return;
    setSending(true);
    try {
      const perfil = (await getCachedProfile(me.uid)) || {};
      // Como antes (lo que funciona): primero se suben los archivos a R2 y
      // después se publica el mensaje con las URLs finales, sin estados
      // intermedios que se puedan quedar colgados.
      const mediaUp = [];
      for (const item of media) {
        const ct = item.contentType || 'application/octet-stream';
        const d = await presign(me, item.nombre || 'archivo', ct, item.size || 0);
        // BINARIO explícito: el multipart por defecto envuelve el archivo y
        // corrompe el objeto en R2 (imágenes "cortadas" en el chat).
        await FileSystem.uploadAsync(d.uploadUrl, item.uri, {
          httpMethod: 'PUT',
          headers: { 'Content-Type': ct },
          mimeType: ct,
          uploadType: BIN_UPLOAD,
        });
        const entry = { tipo: item.tipo, url: d.publicUrl, nombre: item.nombre, size: item.size };
        // Miniatura estilo WhatsApp (dos URLs): la burbuja pintará thumbUrl y
        // el visor cargará el original. Si algo falla, seguimos sin miniatura
        // (la burbuja usa el original) y el envío NO se rompe.
        if (item.tipo === 'imagen' && (item.size || 0) > THUMB_MIN_BYTES) {
          try {
            const thumbUri = await makeThumb(item.uri);
            const tinfo = await FileSystem.getInfoAsync(thumbUri);
            const dt = await presign(me, `thumb-${item.nombre || 'foto'}.jpg`, 'image/jpeg', tinfo.size || 0);
            await FileSystem.uploadAsync(dt.uploadUrl, thumbUri, {
              httpMethod: 'PUT',
              headers: { 'Content-Type': 'image/jpeg' },
              mimeType: 'image/jpeg',
              uploadType: BIN_UPLOAD,
            });
            entry.thumbUrl = dt.publicUrl;
            entry.thumbSize = tinfo.size || 0;
          } catch (e) { /* sin miniatura: la burbuja usará el original */ }
        }
        mediaUp.push(entry);
      }
      // Previsualización de enlace estilo WhatsApp: se genera en el lado del
      // EMISOR (el servidor obtiene el Open Graph y se adjunta al mensaje;
      // los receptores no descargan nada). Tope de 3.5 s: si no llega, el
      // mensaje se envía igual sin preview.
      let preview = null;
      const urlEnTexto = primeraUrl(texto);
      if (urlEnTexto && mediaUp.length === 0) {
        try { preview = await previewParaEnvio(urlEnTexto, me); } catch (e) { preview = null; }
      }
      const iso = new Date().toISOString();
      const encFinal = encuesta && encuesta.pregunta.trim()
        ? { pregunta: encuesta.pregunta.trim(), opciones: encuesta.opciones.map((o) => o.trim()).filter(Boolean), votos: {} }
        : null;
      const ref = await addDoc(collection(db, 'posts'), {
        autorUid: me.uid,
        autorNombre: perfil.nombre || me.displayName || 'Alguien',
        texto: texto.trim(),
        media: mediaUp,
        replyTo: replyTo || null,
        encuesta: encFinal,
        preview: preview || null,
        reacciones: {},
        createdAt: iso,
        // Sin caducidad: el historial es permanente (la sincronización es
        // incremental y nunca descarga todo el chat, así que el tamaño no
        // aumenta el coste de uso).
      });
      // Copia local inmediata: se pinta sin esperar al listener
      chatStorePut({
        id: ref.id,
        autorUid: me.uid,
        autorNombre: perfil.nombre || me.displayName || 'Alguien',
        texto: texto.trim(),
        media: mediaUp,
        replyTo: replyTo || null,
        encuesta: encFinal,
        preview: preview || null,
        reacciones: {},
        createdAt: iso,
      }).catch(() => {});
      setTexto(''); setMedia([]); setEncuesta(null); setPanelEnc(false); onCancelReply();
      onPublicado();
    } catch (e) {
      const perm = /permission/i.test(e.message || '') || e.code === 'permission-denied';
      Alert.alert(L('Error', 'Error'), perm
        ? L('Faltan las reglas de Firestore de "posts": pega firestore.rules en Firebase Console → Firestore → Rules y publica.',
            'Missing Firestore rules for "posts": paste firestore.rules in Firebase Console → Firestore → Rules and publish.')
        : e.message);
    } finally {
      setSending(false);
    }
  };

  const hayAlgo = !!texto.trim() || media.length > 0 || !!(encuesta && encuesta.pregunta.trim());
  const iconBtn = { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' };

  return (
    <View style={{ marginHorizontal: 10, marginBottom: 8, borderRadius: 22, backgroundColor: c.card, borderWidth: 1, borderColor: c.border, overflow: 'hidden' }}>
      {replyTo && (
        <View style={{ flexDirection: 'row', alignItems: 'center', marginHorizontal: 10, marginTop: 8, backgroundColor: c.bg, borderLeftWidth: 3, borderLeftColor: c.acc, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 5 }}>
          <View style={{ flex: 1 }}>
            <Text style={{ color: c.acc, fontWeight: '800', fontSize: 12 }}>{replyTo.nombre}</Text>
            <Text style={{ color: c.mut, fontSize: 12 }} numberOfLines={1}>{replyTo.texto}</Text>
          </View>
          <TouchableOpacity onPress={onCancelReply}><Ionicons name="close-circle" size={17} color={c.mut} /></TouchableOpacity>
        </View>
      )}
      {media.length > 0 && (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ maxHeight: 84, marginTop: 10 }} contentContainerStyle={{ paddingHorizontal: 10, gap: 8 }}>
          {media.map((m, i) => (
            <View key={i} style={{ width: 62, height: 62, borderRadius: 10, overflow: 'hidden', borderWidth: 1, borderColor: c.border }}>
              {m.tipo === 'imagen' ? <Image source={{ uri: m.uri }} style={{ width: 62, height: 62 }} /> : (
                <View style={{ width: 62, height: 62, alignItems: 'center', justifyContent: 'center', backgroundColor: c.bg }}>
                  <Ionicons name={esAudioMedia(m) ? 'musical-notes-outline' : 'document-outline'} size={20} color={c.mut} />
                </View>
              )}
              <TouchableOpacity onPress={() => setMedia((mm) => mm.filter((_, j) => j !== i))} style={{ position: 'absolute', top: 1, right: 1, backgroundColor: '#000000AA', borderRadius: 9, paddingHorizontal: 4 }}>
                <Text style={{ color: '#fff', fontWeight: '800', fontSize: 11 }}>✕</Text>
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      )}
      {panelEnc && (
        <View style={{ marginHorizontal: 10, marginTop: 10, gap: 7, padding: 10, borderRadius: 12, borderWidth: 1, borderColor: c.border }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <TextInput value={encuesta?.pregunta || ''} onChangeText={(t) => setEncuesta((e) => ({ pregunta: t, opciones: e?.opciones || ['', ''] }))}
              placeholder={L('Pregunta de la encuesta', 'Poll question')} placeholderTextColor={c.mut}
              style={{ flex: 1, color: c.txt, fontWeight: '700' }} />
            <TouchableOpacity onPress={() => { setPanelEnc(false); setEncuesta(null); }}>
              <Ionicons name="trash-outline" size={18} color={c.mut} />
            </TouchableOpacity>
          </View>
          {(encuesta?.opciones || []).map((op, i) => (
            <View key={i} style={{ flexDirection: 'row', gap: 7, alignItems: 'center' }}>
              <TextInput value={op} onChangeText={(t) => setEncuesta((e) => { const o = [...e.opciones]; o[i] = t; return { ...e, opciones: o }; })}
                placeholder={`${L('Opción', 'Option')} ${i + 1}`} placeholderTextColor={c.mut}
                style={{ flex: 1, color: c.txt, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 9, backgroundColor: c.bg }} />
              <TouchableOpacity onPress={() => setEncuesta((e) => ({ ...e, opciones: e.opciones.filter((_, j) => j !== i) }))}>
                <Ionicons name="close-circle-outline" size={18} color={c.mut} />
              </TouchableOpacity>
            </View>
          ))}
          {(encuesta?.opciones || []).length < 6 && (
            <TouchableOpacity onPress={() => setEncuesta((e) => ({ ...e, opciones: [...(e?.opciones || ['']), ''] }))}>
              <Text style={{ color: c.acc, fontWeight: '700' }}>+ {L('Añadir opción', 'Add option')}</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 2, paddingHorizontal: 5, paddingVertical: 4 }}>
        <TouchableOpacity onPress={() => setPanelEnc((v) => !v)} style={iconBtn}>
          <Ionicons name={panelEnc ? 'bar-chart' : 'bar-chart-outline'} size={22} color={panelEnc || encuesta ? c.acc : c.mut} />
        </TouchableOpacity>
        <View style={{ flex: 1, maxHeight: 132, borderRadius: 19, backgroundColor: c.bg, borderWidth: 1, borderColor: c.border, paddingHorizontal: 12, paddingVertical: 6, justifyContent: 'center' }}>
          <TextInput
            value={texto} onChangeText={setTexto} multiline
            onContentSizeChange={(e) => setTxtH(e.nativeEvent.contentSize.height)}
            placeholder={L('Mensaje', 'Message')} placeholderTextColor={c.mut}
            style={{ color: c.txt, fontSize: 15, lineHeight: 22, paddingVertical: 0, height: Math.min(120, Math.max(24, txtH)), textAlignVertical: 'center' }}
          />
        </View>
        <TouchableOpacity onPress={pickFiles} style={iconBtn}><Ionicons name="attach-outline" size={21} color={c.mut} /></TouchableOpacity>
        {hayAlgo ? (
          <TouchableOpacity onPress={publicar} disabled={sending} style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: c.acc, alignItems: 'center', justifyContent: 'center' }}>
            {sending ? <ActivityIndicator color="#fff" size="small" /> : <Ionicons name="send" size={17} color="#fff" />}
          </TouchableOpacity>
        ) : (
          <TouchableOpacity onPress={pickCamera} style={iconBtn}><Ionicons name="camera-outline" size={21} color={c.mut} /></TouchableOpacity>
        )}
      </View>
    </View>
  );
}

/* ══════════════ CREAR RETO ══════════════ */
function CreaReto({ onClose, c, L, onCreado }) {
  const me = auth.currentUser;
  const [titulo, setTitulo] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [metrica, setMetrica] = useState('km');
  const [dias, setDias] = useState('30');
  const [atletas, setAtletas] = useState(null);
  const [sel, setSel] = useState(new Set());
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const snap = await getDocs(query(collection(db, 'perfiles'), where('entrenador', '==', me.uid)));
        setAtletas(snap.docs.map((d) => ({ uid: d.id, nombre: d.data().nombre || d.data().email || d.id })));
      } catch (e) { setAtletas([]); }
    })();
  }, []);

  const crear = async () => {
    if (!titulo.trim() || sel.size === 0) return;
    setSaving(true);
    try {
      const perfil = (await getCachedProfile(me.uid)) || {};
      const ini = new Date(); ini.setHours(0, 0, 0, 0);
      const fin = new Date(ini); fin.setDate(fin.getDate() + Math.max(1, parseInt(dias, 10) || 1)); fin.setHours(23, 59, 59, 999);
      await addDoc(collection(db, 'retos'), {
        creadorUid: me.uid,
        creadorNombre: perfil.nombre || me.displayName || 'Coach',
        titulo: titulo.trim(),
        descripcion: descripcion.trim(),
        metrica,
        invitados: [...sel],
        aceptados: [],
        inicio: ini.toISOString(),
        fin: fin.toISOString(),
        createdAt: new Date().toISOString(),
      });
      onCreado();
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally {
      setSaving(false);
    }
  };

  const inp = { color: c.txt, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 10, backgroundColor: c.bg, borderWidth: 1, borderColor: c.border };
  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: '#00000088', justifyContent: 'center', padding: 24 }}>
        <View style={{ backgroundColor: c.card, borderRadius: 18, padding: 16, gap: 10, maxHeight: '85%' }}>
          <Text style={{ color: c.txt, fontWeight: '800', fontSize: 16 }}>{L('Nuevo reto para tus atletas', 'New challenge for your athletes')}</Text>
          <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" style={{ maxHeight: 420 }}>
            <View style={{ gap: 10 }}>
              <TextInput value={titulo} onChangeText={setTitulo} placeholder={L('Título: Reto de mayo', 'Title: May challenge')} placeholderTextColor={c.mut} style={inp} />
              <TextInput value={descripcion} onChangeText={setDescripcion} placeholder={L('Descripción (opcional)', 'Description (optional)')} placeholderTextColor={c.mut} style={inp} multiline />
              <View style={{ flexDirection: 'row', gap: 8 }}>
                {METRICAS.map((m) => (
                  <Pressable key={m.id} onPress={() => setMetrica(m.id)} style={{ flex: 1, paddingVertical: 8, borderRadius: 9, borderWidth: 1, borderColor: metrica === m.id ? c.acc : c.border, backgroundColor: metrica === m.id ? c.acc + '18' : 'transparent', alignItems: 'center' }}>
                    <Text style={{ color: metrica === m.id ? c.acc : c.mut, fontSize: 11, fontWeight: '700', textAlign: 'center' }}>{m.label}</Text>
                  </Pressable>
                ))}
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Text style={{ color: c.mut }}>{L('Duración:', 'Duration:')}</Text>
                <TextInput value={dias} onChangeText={setDias} keyboardType="number-pad" style={[inp, { width: 60, textAlign: 'center' }]} />
                <Text style={{ color: c.mut }}>{L('días', 'days')}</Text>
              </View>
              <Text style={{ color: c.mut, fontWeight: '700' }}>{L('Invitar al reto:', 'Invite to the challenge:')}</Text>
              {atletas === null ? <ActivityIndicator color={c.acc} /> : atletas.length === 0 ? (
                <Text style={{ color: c.mut }}>{L('No tienes atletas asignados todavía.', 'You have no assigned athletes yet.')}</Text>
              ) : (
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                  {atletas.map((a) => {
                    const on = sel.has(a.uid);
                    return (
                      <Pressable key={a.uid} onPress={() => setSel((s) => { const n = new Set(s); if (n.has(a.uid)) n.delete(a.uid); else n.add(a.uid); return n; })}
                        style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 11, paddingVertical: 7, borderRadius: 999, borderWidth: 1, borderColor: on ? '#2DB37A' : c.border, backgroundColor: on ? '#2DB37A22' : 'transparent' }}>
                        <Ionicons name={on ? 'checkmark-circle' : 'person-outline'} size={15} color={on ? '#2DB37A' : c.mut} />
                        <Text style={{ color: on ? '#2DB37A' : c.txt, fontWeight: '800' }}>{a.nombre}</Text>
                      </Pressable>
                    );
                  })}
                </View>
              )}
            </View>
          </ScrollView>
          <View style={{ flexDirection: 'row', justifyContent: 'flex-end', gap: 10, marginTop: 4 }}>
            <TouchableOpacity onPress={onClose} style={{ paddingHorizontal: 14, paddingVertical: 9 }}><Text style={{ color: c.mut, fontWeight: '700' }}>{L('Cancelar', 'Cancel')}</Text></TouchableOpacity>
            <TouchableOpacity onPress={crear} disabled={saving || sel.size === 0} style={{ paddingHorizontal: 18, paddingVertical: 9, borderRadius: 999, backgroundColor: c.acc, opacity: saving || sel.size === 0 ? 0.5 : 1 }}>
              <Text style={{ color: '#fff', fontWeight: '800' }}>{saving ? L('Creando…', 'Creating…') : L('Crear e invitar', 'Create & invite')}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <SystemBars />
    </Modal>
  );
}

/* ══════════════ VISOR FOCAL estilo WhatsApp/Telegram (HILO DE UI) ══════════════
   Gesture Handler + Reanimated: pellizco, pan y doble toque se calculan en el
   hilo de UI (worklets), así el zoom no da tirones aunque el hilo JS esté
   ocupado (listas del chat, red, etc.) — el "mecanismo de zoom perfecto" de
   WhatsApp.
   · Pellizco: fórmula exacta de anclaje focal t = f − (f₀ − t₀)·(s/s₀): el
     punto bajo los dedos se queda bajo los dedos y el traslado a dos dedos
     va 1:1. Límites 1x–5x. Al levantar UN dedo el gesto se enmudece (fix
     del "salto al soltar": RNGH movería el foco al dedo restante y la foto
     saltaría) y el traslado va topado a los bordes durante el gesto → al
     soltar no rebota nada.
   · Pan: 1:1 con tope en los bordes REALES de la imagen (se respeta el
     letterbox del contentFit="contain"; nada de arrastrar por la zona negra).
   · Sin zoom: swipe horizontal pasa de foto (la imagen sigue al dedo) y
     swipe hacia abajo cierra (el fondo se atenúa siguiendo al dedo).
   · Doble toque: zoom 2.5x anclado al punto tocado / el siguiente vuelve a
     1x con muelle.
   · expo-image: decodificación y caché memoria/disco eficientes; se
     precargan las fotos vecinas para que el swipe no muestre spinner.
   · Barra superior NEGRA (cerrar + compartir, sin numeración de fotos):
     se oculta en cuanto se hace un poco de zoom y vuelve al regresar a 1x.
   OJO: en Android el Modal crea una ventana nativa nueva, por eso el
   contenido va envuelto en su propio GestureHandlerRootView. */
const MINZ = 1;
const MAXZ = 5;
const AnimatedImage = Reanimated.createAnimatedComponent(ExpoImage);

function FocalViewer({ urls, initialIndex, onClose }) {
  const insets = useSafeAreaInsets();
  const [idx, setIdx] = useState(initialIndex || 0);
  const [uri, setUri] = useState(null);

  /* Estado compartido: vive en el hilo de UI; los gestos lo leen/escriben
     sin pasar por JS (por eso el zoom es perfectamente fluido). */
  const scale = useSharedValue(1);
  const tx = useSharedValue(0);
  const ty = useSharedValue(0);
  const imgW = useSharedValue(0);      // tamaño natural de la imagen (onLoad)
  const imgH = useSharedValue(0);
  const boxW = useSharedValue(Dimensions.get('window').width);
  const boxH = useSharedValue(Dimensions.get('window').height);
  const p0s = useSharedValue(1);       // anclas del pellizco: scale/translate
  const p0x = useSharedValue(0);       // y foco en el momento de empezar
  const p0y = useSharedValue(0);
  const p0fx = useSharedValue(0);
  const p0fy = useSharedValue(0);
  const p0e = useSharedValue(1);       // e.scale acumulado en el anclaje
  const pfx = useSharedValue(0);       // foco del frame anterior (anti-salto)
  const pfy = useSharedValue(0);
  const lastE = useSharedValue(1);     // ultimo e.scale visto
  const pinchMuted = useSharedValue(false); // pellizco enmudecido al soltar 1 dedo
  const s0x = useSharedValue(0);       // anclas del pan
  const s0y = useSharedValue(0);

  useEffect(() => {
    let alive = true;
    const u = urls[idx];
    setUri(null);
    imgW.value = 0; imgH.value = 0;
    cachedOrDownload(u).then((l) => { if (alive) setUri(l); }).catch(() => { if (alive) setUri(u); });
    // Precarga las vecinas: el swipe lateral no muestra spinner
    if (urls[idx - 1]) cachedOrDownload(urls[idx - 1]).catch(() => {});
    if (urls[idx + 1]) cachedOrDownload(urls[idx + 1]).catch(() => {});
    return () => { alive = false; };
  }, [idx, urls]);

  const goIdx = (n) => {
    if (n < 0 || n >= urls.length || n === idx) return;
    scale.value = 1; tx.value = 0; ty.value = 0;
    setIdx(n);
  };

  /* Límites reales: con contentFit="contain" la imagen ocupa dw×dh dentro del
     contenedor (letterbox). El pan solo llega hasta el borde de lo que se ve. */
  const bounds = (s) => {
    'worklet';
    let dw = boxW.value;
    let dh = boxH.value;
    if (imgW.value > 0 && imgH.value > 0) {
      const fit = Math.min(boxW.value / imgW.value, boxH.value / imgH.value);
      dw = imgW.value * fit;
      dh = imgH.value * fit;
    }
    return {
      maxX: Math.max(0, (dw * s - boxW.value) / 2),
      maxY: Math.max(0, (dh * s - boxH.value) / 2),
    };
  };
  const snapToBounds = () => {
    'worklet';
    const b = bounds(scale.value);
    tx.value = withTiming(clamp(tx.value, -b.maxX, b.maxX), { duration: 160 });
    ty.value = withTiming(clamp(ty.value, -b.maxY, b.maxY), { duration: 160 });
  };
  const springHome = () => {
    'worklet';
    const cfg = { damping: 18, stiffness: 200 };
    tx.value = withSpring(0, cfg);
    ty.value = withSpring(0, cfg);
  };
  const resetZoom = () => {
    'worklet';
    const cfg = { damping: 17, stiffness: 170 };
    scale.value = withSpring(1, cfg);
    tx.value = withSpring(0, cfg);
    ty.value = withSpring(0, cfg);
  };

  /* ── Pellizco: zoom anclado al punto exacto de los dedos ──
     FIX "salto al soltar" (comportamiento WhatsApp): en Android RNGH NO
     termina el pellizco al levantar UN dedo — el handler ignora onScaleEnd y
     sigue ACTIVE despachando onUpdate con el FOCO TELETRANSPORTADO al dedo
     que queda (su ScaleGestureDetector recalcula el foco excluyendo el dedo
     levantado). La foto saltaba a otro punto, la arrastraba el dedo restante
     y al soltar del todo el snap la devolvía ("va y vuelve"). Los eventos de
     touches se despachan ANTES que los updates (garantizado por el
     GestureHandlerOrchestrator): en cuanto queda 1 touch enmudecemos el
     gesto — termina ahí, como en WhatsApp. Además el traslado va topado a
     los bordes reales DURANTE el gesto: al soltar no rebota nada. */
  const pinch = Gesture.Pinch()
    .onBegin(() => {
      pinchMuted.value = false;   // interaccion nueva: oidos abiertos
    })
    .onTouchesDown((e) => {
      // Si apoyas un dedo nuevo quedando otro en pantalla (pellizco ya
      // enmudecido), reanclamos el gesto al estado actual en vez de exigir
      // levantar todos los dedos primero.
      if (!pinchMuted.value || e.numberOfTouches < 2) return;
      const ts = e.allTouches;
      if (!ts || ts.length < 2) return;
      let sx = 0;
      let sy = 0;
      for (let i = 0; i < ts.length; i++) { sx += ts[i].x; sy += ts[i].y; }
      p0s.value = Math.max(0.01, scale.value);
      p0x.value = tx.value;
      p0y.value = ty.value;
      p0e.value = lastE.value > 0 ? lastE.value : 1;
      p0fx.value = sx / ts.length - boxW.value / 2;
      p0fy.value = sy / ts.length - boxH.value / 2;
      pfx.value = p0fx.value;
      pfy.value = p0fy.value;
      pinchMuted.value = false;
    })
    .onTouchesUp((e) => {
      // Queda 1 dedo (o ninguno): el pellizco termina AQUI, como en WhatsApp.
      // Sin esto RNGH seguiria mandando updates con el foco en el dedo
      // restante y la imagen daria el salto.
      if (e.numberOfTouches <= 1) pinchMuted.value = true;
    })
    .onStart((e) => {
      pinchMuted.value = false;
      p0s.value = Math.max(0.01, scale.value);
      p0x.value = tx.value;
      p0y.value = ty.value;
      p0e.value = e.scale > 0 ? e.scale : 1;
      p0fx.value = e.focalX - boxW.value / 2;
      p0fy.value = e.focalY - boxH.value / 2;
      pfx.value = p0fx.value;
      pfy.value = p0fy.value;
    })
    .onUpdate((e) => {
      lastE.value = e.scale;
      if (pinchMuted.value) return;
      const fx = e.focalX - boxW.value / 2;
      const fy = e.focalY - boxH.value / 2;
      // Red de seguridad: el foco no puede teletransportarse de un frame a
      // otro; si salta >150px es el artefacto de levantar un dedo -> callar.
      // (La defensa principal es onTouchesUp; esto cubre rutas exoticas.)
      const jx = fx - pfx.value;
      const jy = fy - pfy.value;
      if (jx * jx + jy * jy > 22500) { pinchMuted.value = true; return; }
      pfx.value = fx;
      pfy.value = fy;
      const s0 = p0s.value;
      if (s0 <= 0) return;
      const next = clamp(s0 * (e.scale / p0e.value), MINZ, MAXZ);
      const ratio = next / s0;
      scale.value = next;
      // t = f − (f₀ − t₀)·ratio: el contenido que estaba bajo el foco inicial
      // sigue bajo el foco actual (zoom + traslado de dos dedos exactos),
      // topado a los bordes reales: nada se sale y "vuelve" al soltar.
      const b = bounds(next);
      tx.value = clamp(fx - (p0fx.value - p0x.value) * ratio, -b.maxX, b.maxX);
      ty.value = clamp(fy - (p0fy.value - p0y.value) * ratio, -b.maxY, b.maxY);
    })
    .onEnd(() => {
      if (scale.value <= 1.02) resetZoom();
      else snapToBounds();
    });

  /* ── Arrastre: pan con zoom / paging y cierre sin zoom ── */
  const pan = Gesture.Pan()
    .maxPointers(1)          // a dos dedos manda el pellizco
    .minDistance(6)
    .onStart(() => {
      s0x.value = tx.value;
      s0y.value = ty.value;
    })
    .onUpdate((e) => {
      if (scale.value > 1.02) {
        const b = bounds(scale.value);
        tx.value = clamp(s0x.value + e.translationX, -b.maxX, b.maxX);
        ty.value = clamp(s0y.value + e.translationY, -b.maxY, b.maxY);
      } else {
        // Sin zoom: la foto sigue al dedo (goma si no hay más fotos o arriba)
        tx.value = urls.length > 1 ? e.translationX : e.translationX * 0.3;
        ty.value = e.translationY > 0 ? e.translationY : e.translationY * 0.3;
      }
    })
    .onEnd((e, success) => {
      if (!success) return;                 // cancelado por el pellizco
      if (scale.value > 1.02) { snapToBounds(); return; }
      const dx = e.translationX;
      const dy = e.translationY;
      if (dy > 110 || e.velocityY > 900) { runOnJS(onClose)(); return; }
      if (urls.length > 1 && Math.abs(dx) > Math.abs(dy)
          && (Math.abs(dx) > boxW.value * 0.28 || Math.abs(e.velocityX) > 650)) {
        runOnJS(goIdx)(idx + (dx < 0 ? 1 : -1));
        return;
      }
      springHome();
    });

  /* ── Doble toque: 2.5x en el punto tocado / vuelta a 1x ── */
  const doubleTap = Gesture.Tap()
    .numberOfTaps(2)
    .maxDuration(250)
    .maxDelay(250)
    .onEnd((e) => {
      if (scale.value > 1.02) { resetZoom(); return; }
      const s0 = Math.max(0.01, scale.value);
      const next = 2.5;
      const ratio = next / s0;
      const ex = e.x - boxW.value / 2;
      const ey = e.y - boxH.value / 2;
      const b = bounds(next);
      scale.value = withTiming(next, { duration: 220 });
      tx.value = withTiming(clamp(ex - (ex - tx.value) * ratio, -b.maxX, b.maxX), { duration: 220 });
      ty.value = withTiming(clamp(ey - (ey - ty.value) * ratio, -b.maxY, b.maxY), { duration: 220 });
    });

  const composed = Gesture.Simultaneous(pinch, pan, doubleTap);

  const imgStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: tx.value },
      { translateY: ty.value },
      { scale: scale.value },
    ],
  }));
  // El fondo se atenúa mientras arrastras hacia abajo para cerrar:
  const bgStyle = useAnimatedStyle(() => ({
    opacity: scale.value > 1.02
      ? 0.96
      : interpolate(ty.value, [0, 320], [0.96, 0.3], 'clamp'),
  }));

  // Compartir: panel del sistema (incluye "Guardar imagen").
  const compartir = async () => {
    try {
      const u = urls[idx];
      const local = diskCache.get(u) || (await cachedOrDownload(u));
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(local, { dialogTitle: 'Compartir imagen' });
      }
    } catch (e) {}
  };

  /* Barra superior NEGRA estilo WhatsApp (cerrar + compartir): se desliza
     fuera de pantalla y se desvanece en cuanto hay zoom, y vuelve sola al
     regresar a 1x. La animación vive en el hilo de UI (useAnimatedStyle). */
  const barStyle = useAnimatedStyle(() => {
    const vis = scale.value <= 1.02;
    return {
      opacity: withTiming(vis ? 1 : 0, { duration: 150 }),
      transform: [{ translateY: withTiming(vis ? 0 : -170, { duration: 220 }) }],
    };
  });

  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose}>
      {/* Android: el Modal abre una ventana nativa aparte; los gestos
          necesitan su propio GestureHandlerRootView dentro. */}
      <GestureHandlerRootView style={{ flex: 1 }}>
        <View
          style={{ flex: 1 }}
          onLayout={(e) => {
            const { width, height } = e.nativeEvent.layout;
            if (width > 0 && height > 0) { boxW.value = width; boxH.value = height; }
          }}
        >
          <Reanimated.View style={[{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#000' }, bgStyle]} />
          {uri ? (
            <GestureDetector gesture={composed}>
              <AnimatedImage
                source={{ uri }}
                style={[{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }, imgStyle]}
                contentFit="contain"
                cachePolicy="memory-disk"
                onLoad={(e) => {
                  const w = (e && e.source && e.source.width) || 0;
                  const h = (e && e.source && e.source.height) || 0;
                  if (w > 0 && h > 0) { imgW.value = w; imgH.value = h; }
                }}
              />
            </GestureDetector>
          ) : (
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
              <ActivityIndicator color="#fff" />
            </View>
          )}
          {/* Barra superior NEGRA: cerrar + compartir, SIN numeración de
              fotos. Se oculta sola con un poco de zoom y vuelve a 1x. */}
          <Reanimated.View pointerEvents="box-none" style={[{ position: 'absolute', top: 0, left: 0, right: 0, zIndex: 3, backgroundColor: '#000000', paddingTop: Math.max(insets.top, 24) + 8, paddingBottom: 10, paddingHorizontal: 8, flexDirection: 'row', alignItems: 'center' }, barStyle]}>
            <TouchableOpacity onPress={onClose} style={{ padding: 10 }} hitSlop={6}><Ionicons name="close" size={28} color="#fff" /></TouchableOpacity>
            <View style={{ flex: 1 }} />
            <TouchableOpacity onPress={compartir} style={{ padding: 10 }} hitSlop={6}><Ionicons name="share-outline" size={25} color="#fff" /></TouchableOpacity>
          </Reanimated.View>
        </View>
      </GestureHandlerRootView>
      <SystemBars />
    </Modal>
  );
}
