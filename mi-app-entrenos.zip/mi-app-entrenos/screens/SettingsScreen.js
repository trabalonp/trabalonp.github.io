// screens/SettingsScreen.js
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import * as Sharing from 'expo-sharing';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { useCallback, useRef, useState } from 'react';
import {
  Alert, Image, Modal,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
  useColorScheme,
} from 'react-native';
import ViewShot from 'react-native-view-shot';
import { auth, db } from '../firebaseConfig';
import { cacheProfile, getCachedProfile } from '../services/profileCache';
import { getThemeColors, saveSettings, useAppSettings } from '../services/appSettings';

const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';

export default function SettingsScreen() {
  const user = auth.currentUser;
  const navigation = useNavigation();
  const shareCardRef = useRef();
  const appSettings = useAppSettings();
  const lang = appSettings.language;            // re-renderiza al cambiar idioma
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción

  // Menú con etiquetas traducidas (las claves y el orden no cambian)
  const MENU_ITEMS = [
    { key: 'perfil',     label: L('Perfil', 'Profile'),                 icon: 'person-outline' },
    { key: 'sync',       label: L('Sincronización', 'Sync'),            icon: 'sync-outline' },
    { key: 'zonas',      label: L('Zonas', 'Zones'),                    icon: 'pulse-outline' },
    { key: 'donaciones', label: L('Donaciones', 'Donations'),           icon: 'cafe' },
    { key: 'entrenador', label: L('Mi Entrenador', 'My Coach'),         icon: 'people-outline' },
    { key: 'ajustes',    label: L('Ajustes', 'Settings'), icon: 'options-outline' },
    { key: 'soporte',    label: L('Soporte', 'Support'),                icon: 'help-circle-outline' },
  ];

  /* ── Compartir tarjeta de perfil ── */
  const handleShareProfile = async () => {
    try {
      if (shareCardRef.current) {
        const uri = await shareCardRef.current.capture({
          format: 'png',
          quality: 1,
        });
        await Sharing.shareAsync(uri);
      }
    } catch (e) {
      Alert.alert(L('Error', 'Error'), L('No se pudo compartir la tarjeta', 'Could not share the card'));
    }
  };

  const [athleteId, setAthleteId] = useState(null);
  useFocusEffect(
    useCallback(() => {
      AsyncStorage.getItem('currentAthleteId').then(setAthleteId);
    }, [])
  );

  // Estado local para el switch
  const [notifs, setNotifs] = useState(true);
  const [themePickerOpen, setThemePickerOpen] = useState(false);
  const [profile, setProfile] = useState(null);

  /* ── Obtener perfil desde Firestore y la preferencia de notificaciones ── */
  const fetchProfile = useCallback(async () => {
    if (!user) return;
    const cached = await getCachedProfile(user.uid);
    if (cached) {
      setProfile(cached);
      if (cached.notificacionesActivadas !== undefined) {
        setNotifs(cached.notificacionesActivadas);
      }
      try {
        const snap = await getDoc(doc(db, 'perfiles', user.uid));
        if (snap.exists()) {
          const data = snap.data();
          setProfile(data);
          await cacheProfile(user.uid, data);
          if (data.notificacionesActivadas !== undefined) {
            setNotifs(data.notificacionesActivadas);
          }
        }
      } catch (e) {}
      return;
    }
    try {
      const snap = await getDoc(doc(db, 'perfiles', user.uid));
      if (snap.exists()) {
        const data = snap.data();
        setProfile(data);
        await cacheProfile(user.uid, data);
        if (data.notificacionesActivadas !== undefined) {
          setNotifs(data.notificacionesActivadas);
        }
      } else {
        setProfile(null);
      }
    } catch (e) {
      console.log('Error al cargar perfil:', e);
    }
  }, [user]);

  useFocusEffect(
    useCallback(() => {
      const load = async () => {
        const cached = await getCachedProfile(user.uid);
        if (cached) {
          setProfile(cached);
          if (cached.notificacionesActivadas !== undefined) {
            setNotifs(cached.notificacionesActivadas);
          }
        }
        fetchProfile();
      };
      load();
    }, [fetchProfile])
  );

  const handleToggleNotifs = async (value) => {
    setNotifs(value);
    try {
      await setDoc(doc(db, 'perfiles', user.uid), { notificacionesActivadas: value }, { merge: true });
    } catch (error) {
      Alert.alert(L('Error', 'Error'), L('No se pudo guardar la preferencia de notificaciones', 'Could not save the notification preference'));
      setNotifs(!value);
    }
  };

  const handleMenuItem = (key) => {
    if (key === 'perfil') {
      navigation.navigate('Profile');
      return;
    }
    if (key === 'sync') {
      navigation.navigate('SyncSettings');
      return;
    }
    if (key === 'entrenador') {
      navigation.navigate('Coach');
      return;
    }
    if (key === 'zonas') {
      navigation.navigate('Zones', { athleteId });
      return;
    }
    if (key === 'donaciones') {
      navigation.navigate('Donaciones');
      return;
    }
    if (key === 'ajustes') {
      navigation.navigate('AppSettings'); // ← pantalla de idioma/unidades/fecha
      return;
    }
    if (key === 'soporte') {
      navigation.navigate('Support'); // ← pantalla de soporte (correo a trabalonp@gmail.com)
      return;
    }
    Alert.alert(L('Próximamente', 'Coming soon'), L(`La sección "${key}" estará disponible pronto.`, `The "${key}" section will be available soon.`));
  };

  /* ── Datos para el header ── */
  const profilePhoto = profile?.foto;
  const firstName = profile?.nombre?.trim().split(' ')[0] || user?.displayName || 'Atleta';
  const apellido = profile?.apellido || '';
  const initial = firstName.charAt(0).toUpperCase();

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header con foto / inicial y nombre + email */}
        <View style={styles.header}>
          <View style={styles.avatar}>
            {profilePhoto ? (
              <Image source={{ uri: `data:image/jpeg;base64,${profilePhoto}` }} style={styles.avatarImg} />
            ) : user?.photoURL ? (
              <Image source={{ uri: user.photoURL }} style={styles.avatarImg} />
            ) : (
              <Text style={styles.avatarInitial}>{initial}</Text>
            )}
          </View>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={[styles.userName, { color: theme.text }]}>{firstName}</Text>
              <TouchableOpacity onPress={handleShareProfile} style={{ marginLeft: 8 }}>
                <Ionicons name="share-outline" size={22} color={BLUE} />
              </TouchableOpacity>
            </View>
            <Text style={[styles.userEmail, { color: theme.muted }]}>{user?.email}</Text>
          </View>
        </View>

        {/* Menú */}
        <View style={[styles.menuCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
          {MENU_ITEMS.map((item, index) => (
            <TouchableOpacity
              key={item.key}
              style={[
                styles.menuRow,
                index < MENU_ITEMS.length - 1 && styles.menuRowBorder,
                index < MENU_ITEMS.length - 1 && { borderBottomColor: theme.border },
              ]}
              onPress={() => handleMenuItem(item.key)}
              activeOpacity={0.7}
            >
              <Ionicons name={item.icon} size={20} color="#8FA8C8" />
              <Text style={[styles.menuLabel, { color: theme.text }]}>{item.label}</Text>
              <Ionicons name="chevron-forward" size={18} color="#2A4060" />
            </TouchableOpacity>
          ))}
        </View>

        {/* Switch de notificaciones funcional */}
        <View style={[styles.menuCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.menuRow}>
            <Ionicons name="notifications-outline" size={20} color="#8FA8C8" />
            <Text style={[styles.menuLabel, { color: theme.text }]}>{L('Activar Notificaciones', 'Enable Notifications')}</Text>
            <Switch
              value={notifs}
              onValueChange={handleToggleNotifs}
              trackColor={{ false: '#1E3048', true: BLUE }}
              thumbColor="#fff"
            />
          </View>
          <TouchableOpacity style={styles.menuRow} onPress={() => setThemePickerOpen(true)}>
            <Ionicons name="contrast-outline" size={20} color={BLUE} />
            <Text style={[styles.menuLabel, { color: theme.text }]}>{L('Contraste', 'Contrast')}</Text>
            <Text style={styles.themeValue}>{appSettings.themeMode === 'day' ? L('Día', 'Day') : appSettings.themeMode === 'device' ? L('Dispositivo', 'Device') : L('Noche', 'Night')}</Text>
            <Ionicons name="chevron-forward" size={18} color="#2A4060" />
          </TouchableOpacity>
        </View>
      </ScrollView>

      <Modal visible={themePickerOpen} transparent animationType="fade" onRequestClose={() => setThemePickerOpen(false)}>
        <View style={styles.overlay}>
          <TouchableOpacity style={styles.overlayClose} activeOpacity={1} onPress={() => setThemePickerOpen(false)} />
          <View style={styles.themePicker}>
            <Text style={styles.pickerTitle}>{L('Contraste', 'Contrast')}</Text>
            {[
              ['day', L('Día', 'Day')],
              ['night', L('Noche', 'Night')],
              ['device', L('Dispositivo', 'Device')],
            ].map(([value, label]) => (
              <TouchableOpacity key={value} style={[styles.themeOption, appSettings.themeMode === value && styles.themeOptionActive]} onPress={() => { saveSettings({ themeMode: value }); setThemePickerOpen(false); }}>
                <Text style={styles.themeOptionText}>{label}</Text>
                {appSettings.themeMode === value && <Ionicons name="checkmark-circle" size={18} color={BLUE} />}
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </Modal>

      {/* ── TARJETA OCULTA PARA COMPARTIR (se renderiza fuera de pantalla) ── */}
      <ViewShot
        ref={shareCardRef}
        options={{ format: 'png', quality: 1 }}
        style={styles.shareCardWrapper}
      >
        <View style={styles.shareCard}>
          <View style={styles.shareCardTop}>
            <View style={styles.shareAvatarLarge}>
              {profilePhoto ? (
                <Image
                  source={{ uri: `data:image/jpeg;base64,${profilePhoto}` }}
                  style={styles.shareAvatarLargeImg}
                />
              ) : (
                <Text style={styles.shareAvatarLargeInitial}>{initial}</Text>
              )}
            </View>
            <View style={styles.shareCardLine} />
          </View>
          <Text style={styles.shareName}>{firstName} {apellido}</Text>
          <Text style={styles.shareEmail}>{user?.email}</Text>
          <View style={styles.shareBadge}>
            <Ionicons name="flash" size={14} color="#FFD700" />
            <Text style={styles.shareBadgeText}>Team Jorge App</Text>
          </View>
        </View>
      </ViewShot>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 20, paddingTop: 60, paddingBottom: 24, gap: 16,
  },
  avatar: {
    width: 56, height: 56, borderRadius: 28,
    backgroundColor: BLUE, alignItems: 'center', justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarImg:     { width: 56, height: 56 },
  avatarInitial: { color: '#fff', fontSize: 22, fontWeight: '800' },
  userName:      { color: '#fff', fontSize: 18, fontWeight: '700' },
  userEmail:     { color: '#8FA8C8', fontSize: 13, marginTop: 2 },
  menuCard: {
    backgroundColor: CARD, marginHorizontal: 16,
    marginBottom: 12, borderRadius: 12,
    borderWidth: 1, borderColor: BORDER, overflow: 'hidden',
  },
  menuRow: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 16, gap: 14,
  },
  menuRowBorder: { borderBottomWidth: 1, borderBottomColor: BORDER },
  menuLabel: { flex: 1, color: '#fff', fontSize: 15 },
  themeValue: { color: '#8FA8C8', fontSize: 13, marginRight: 4 },
  overlay: { flex: 1, backgroundColor: '#00000088', justifyContent: 'center', alignItems: 'center' },
  overlayClose: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
  themePicker: { width: '80%', backgroundColor: CARD, borderRadius: 12, overflow: 'hidden', paddingVertical: 6 },
  pickerTitle: { color: '#8FA8C8', fontSize: 12, fontWeight: '700', paddingHorizontal: 16, paddingTop: 10, paddingBottom: 6, textTransform: 'uppercase' },
  themeOption: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: BORDER },
  themeOptionActive: { backgroundColor: '#2A4060' },
  themeOptionText: { color: '#fff', fontSize: 14 },
  // ── Tarjeta para compartir (oculta) ──
  shareCardWrapper: {
    position: 'absolute',
    top: -1000,
    left: 0,
    width: 600,
    height: 320,
    backgroundColor: 'transparent',
  },
  shareCard: {
    width: 280,
    backgroundColor: '#0A1220',
    borderRadius: 16,
    paddingVertical: 24,
    paddingHorizontal: 20,
    alignItems: 'center',
    alignSelf: 'center',
    marginTop: 30,
  },
  shareCardTop: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    width: '100%',
  },
  shareAvatarLarge: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: BLUE,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#FFD700',
    overflow: 'hidden',
  },
  shareAvatarLargeImg: { width: 64, height: 64 },
  shareAvatarLargeInitial: { color: '#fff', fontSize: 28, fontWeight: '800' },
  shareCardLine: {
    flex: 1,
    height: 1,
    backgroundColor: BLUE,
    marginLeft: 12,
  },
  shareName: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 4,
  },
  shareEmail: {
    color: '#8FA8C8',
    fontSize: 13,
    marginBottom: 16,
  },
  shareBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E3048',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    gap: 6,
  },
  shareBadgeText: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '600',
  },
});
