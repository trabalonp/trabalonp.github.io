// screens/CoachScreen.js
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { useCallback, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  useColorScheme,
} from 'react-native';
import { auth } from '../firebaseConfig';
import { cacheCoach, clearCoachCache, getCachedCoach, isCacheStale } from '../services/coachCache';
import { getThemeColors, useAppSettings } from '../services/appSettings';

const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';
const RED    = '#E05252';
const SERVER_URL = 'https://garmin-fit-server.onrender.com';

// ── Calienta el servicio de Render al arrancar la app (una vez por arranque) ──
// Cualquier petición HTTP despierta un servicio dormido del plan gratuito;
// al lanzarla al cargar la app, cuando entras aquí el servidor ya está despierto.
let serverWarmed = false;
function warmServer() {
  if (serverWarmed) return;
  serverWarmed = true;
  fetch(`${SERVER_URL}/ping`, { method: 'GET' }).catch(() => {});
}
warmServer();

export default function CoachScreen() {
  const user = auth.currentUser;
  const navigation = useNavigation();
  const appSettings = useAppSettings();
  const lang = appSettings.language;            // re-renderiza al cambiar idioma
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción
  const loc = lang === 'en' ? 'en-US' : 'es-ES';   // locale para fechas

  const [entrenador, setEntrenador] = useState(null);
  const [loading, setLoading] = useState(true);            // sin caché: spinner a pantalla completa
  const [refreshingBg, setRefreshingBg] = useState(false); // con caché: indicador discreto
  const [emailSolicitud, setEmailSolicitud] = useState('');
  const [sending, setSending] = useState(false);
  const [solicitudes, setSolicitudes] = useState([]);
  const [showSolicitudes, setShowSolicitudes] = useState(false);
  const [atletas, setAtletas] = useState([]);

  // Única fuente de verdad remota: el endpoint del servidor
  const fetchFromServer = useCallback(async (signal) => {
    const res = await fetch(`${SERVER_URL}/coach-screen-data/${user.uid}`, { signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    setEntrenador(data.entrenador ?? null);
    setSolicitudes(Array.isArray(data.solicitudes) ? data.solicitudes : []);
    setAtletas(Array.isArray(data.atletas) ? data.atletas : []);
    await cacheCoach(data);
    return data;
  }, [user.uid]);

  const fetchData = useCallback(async (force = false) => {
    if (!user) return;
    // 1) Pintar caché al instante si existe (nunca se oculta mientras refresca)
    let hasCache = false;
    try {
      const cached = await getCachedCoach();
      if (cached) {
        hasCache = true;
        setEntrenador(cached.entrenador ?? null);
        setSolicitudes(cached.solicitudes || []);
        setAtletas(cached.atletas || []);
      }
    } catch (e) {}
    setLoading(!hasCache);
    // 2) ¿Toca refrescar? (caché caducada o refresco forzado)
    let stale = true;
    try { stale = await isCacheStale(); } catch (e) {}
    if (!force && hasCache && !stale) { setLoading(false); return; }
    // 3) Refresco en segundo plano con timeout, sin ruleta que tape la lista
    if (hasCache) setRefreshingBg(true);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 25000);
    try {
      await fetchFromServer(controller.signal);
    } catch (err) {
      console.log('Error al obtener datos:', err.message);
    } finally {
      clearTimeout(timeout);
      setLoading(false);
      setRefreshingBg(false);
    }
  }, [user, fetchFromServer]);

  useFocusEffect(
    useCallback(() => {
      fetchData(false);
    }, [fetchData])
  );

  const handleEnviarSolicitud = async () => {
    if (!emailSolicitud.trim()) {
      Alert.alert(L('Error', 'Error'), L('Introduce el correo del entrenador', 'Enter your coach\'s email'));
      return;
    }
    setSending(true);
    try {
      const res = await fetch(`${SERVER_URL}/solicitar-entrenador`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ atletaId: user.uid, entrenadorEmail: emailSolicitud.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error del servidor');
      Alert.alert(L('Solicitud enviada', 'Request sent'), L('Tu solicitud ha sido enviada correctamente.', 'Your request has been sent successfully.'));
      setEmailSolicitud('');
      fetchData(true);
    } catch (err) {
      Alert.alert(L('Error', 'Error'), err.message);
    } finally {
      setSending(false);
    }
  };

  const handleGestionarSolicitud = async (solicitudId, accion) => {
    try {
      const res = await fetch(`${SERVER_URL}/gestionar-solicitud`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ solicitudId, entrenadorId: user.uid, accion }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error del servidor');
      fetchData(true);
      if (accion === 'aceptar') {
        Alert.alert(L('Solicitud aceptada', 'Request accepted'), L('El atleta ya aparece en tu lista.', 'The athlete now appears in your list.'));
      }
    } catch (err) {
      Alert.alert(L('Error', 'Error'), err.message);
    }
  };

  const handleEliminarEntrenador = async () => {
    Alert.alert(
      L('Eliminar entrenador', 'Remove coach'),
      L('¿Estás seguro de que quieres eliminar a tu entrenador?', 'Are you sure you want to remove your coach?'),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Eliminar', 'Remove'),
          style: 'destructive',
          onPress: async () => {
            try {
              const res = await fetch(`${SERVER_URL}/eliminar-entrenador`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ atletaId: user.uid }),
              });
              if (!res.ok) throw new Error('Error al eliminar');
              setEntrenador(null);
              await clearCoachCache();
              Alert.alert(L('Eliminado', 'Removed'), L('Entrenador eliminado correctamente.', 'Coach removed successfully.'));
              fetchData(true);
            } catch (err) {
              Alert.alert(L('Error', 'Error'), err.message);
            }
          },
        },
      ]
    );
  };

  const nombreCompletoEntrenador = entrenador
    ? `${entrenador.nombre || ''} ${entrenador.apellido || ''}`.trim() || L('Entrenador', 'Coach')
    : '';
  const fotoEntrenador = entrenador?.foto;

  if (loading) {
    return (
      <View style={[styles.centered, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={BLUE} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={[styles.header, { borderBottomColor: theme.border }]}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="chevron-back" size={24} color="#8FA8C8" />
          </TouchableOpacity>
          <Text style={[styles.headerTitle, { color: theme.text }]}>{L('Mi Entrenador', 'My Coach')}</Text>
          <TouchableOpacity onPress={() => setShowSolicitudes(true)} style={styles.bellBtn}>
            <Ionicons name="notifications" size={24} color="#8FA8C8" />
            {solicitudes.length > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{solicitudes.length}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* Sección Entrenador */}
        {entrenador ? (
          <View style={[styles.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <View style={styles.infoRow}>
              <View style={styles.avatar}>
                {fotoEntrenador ? (
                  <Image source={{ uri: `data:image/jpeg;base64,${fotoEntrenador}` }} style={styles.avatarImg} />
                ) : (
                  <Text style={styles.avatarText}>{nombreCompletoEntrenador.charAt(0).toUpperCase()}</Text>
                )}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.name, { color: theme.text }]}>{nombreCompletoEntrenador}</Text>
                <Text style={[styles.email, { color: theme.muted }]}>{entrenador.email || ''}</Text>
              </View>
              <TouchableOpacity onPress={handleEliminarEntrenador}>
                <Ionicons name="trash-outline" size={20} color={RED} />
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <View style={[styles.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <Text style={[styles.label, { color: theme.text }]}>{L('Introduce el correo de tu entrenador:', 'Enter your coach\'s email:')}</Text>
            <TextInput
              style={[styles.input, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]}
              value={emailSolicitud}
              onChangeText={setEmailSolicitud}
              placeholder="correo@ejemplo.com"
              placeholderTextColor="#4A6080"
              keyboardType="email-address"
              autoCapitalize="none"
            />
            <TouchableOpacity style={[styles.btnPrimary, sending && styles.disabled]} onPress={handleEnviarSolicitud} disabled={sending}>
              {sending ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnPrimaryText}>{L('Enviar solicitud', 'Send request')}</Text>}
            </TouchableOpacity>
          </View>
        )}

        {/* Sección Atletas */}
        <View style={styles.sectionContainer}>
          <View style={styles.sectionHeaderRow}>
            <Text style={[styles.sectionTitle, { color: theme.muted }]}>{L('Personas a las que entrenas', 'People you coach')}</Text>
            {refreshingBg && <ActivityIndicator size="small" color={BLUE} />}
          </View>
          {atletas.length === 0 ? (
            <Text style={styles.emptyText}>
              {refreshingBg ? L('Buscando atletas…', 'Looking for athletes…') : L('Aún no entrenas a nadie.', 'You don\'t coach anyone yet.')}
            </Text>
          ) : (
            atletas.map((atleta) => (
              <TouchableOpacity
                key={atleta.uid}
                style={[styles.atletaCard, { backgroundColor: theme.card, borderColor: theme.border }]}
                onPress={async () => {
                  await AsyncStorage.setItem('currentAthleteId', atleta.uid);
                  await AsyncStorage.setItem('currentAthleteName', `${atleta.nombre} ${atleta.apellido}`.trim());
                  navigation.navigate('Main', { screen: 'Dashboard' });
                }}
              >
                <View style={styles.avatar}>
                  {atleta.foto ? (
                    <Image source={{ uri: `data:image/jpeg;base64,${atleta.foto}` }} style={styles.avatarImg} />
                  ) : (
                    <Text style={styles.avatarText}>{atleta.nombre ? atleta.nombre.charAt(0).toUpperCase() : 'A'}</Text>
                  )}
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.atletaName, { color: theme.text }]}>{atleta.nombre} {atleta.apellido}</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#4A6080" />
              </TouchableOpacity>
            ))
          )}
        </View>
      </ScrollView>

      {/* Modal de solicitudes */}
      <Modal visible={showSolicitudes} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: theme.background }]}>
            <View style={[styles.modalHeader, { borderBottomColor: theme.border }]}>
              <Text style={[styles.modalTitle, { color: theme.text }]}>{L('Solicitudes pendientes', 'Pending requests')}</Text>
              <TouchableOpacity onPress={() => setShowSolicitudes(false)}>
                <Ionicons name="close" size={24} color="#8FA8C8" />
              </TouchableOpacity>
            </View>
            {solicitudes.length === 0 ? (
              <Text style={styles.emptyText}>{L('No tienes solicitudes pendientes', 'You have no pending requests')}</Text>
            ) : (
              <FlatList
                data={solicitudes}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                  <View style={[styles.solicitudCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
                    <Text style={[styles.solicitudName, { color: theme.text }]}>{item.atletaNombre}</Text>
                    <Text style={[styles.solicitudDate, { color: theme.muted }]}>
                      {new Date(item.fecha).toLocaleDateString(loc, {
                        day: 'numeric', month: 'short', year: 'numeric',
                      })}
                    </Text>
                    <View style={styles.acciones}>
                      <TouchableOpacity
                        style={styles.btnAceptar}
                        onPress={() => handleGestionarSolicitud(item.id, 'aceptar')}
                      >
                        <Text style={styles.btnAceptarText}>{L('Aceptar', 'Accept')}</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={styles.btnRechazar}
                        onPress={() => handleGestionarSolicitud(item.id, 'rechazar')}
                      >
                        <Text style={styles.btnRechazarText}>{L('Rechazar', 'Reject')}</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                )}
              />
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  centered: { flex: 1, backgroundColor: NAVY, alignItems: 'center', justifyContent: 'center' },
  scrollContent: { paddingBottom: 40 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 56, paddingBottom: 16,
    borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  bellBtn: { padding: 4, position: 'relative' },
  badge: {
    position: 'absolute', top: -2, right: -6,
    backgroundColor: RED, borderRadius: 10, width: 18, height: 18,
    alignItems: 'center', justifyContent: 'center',
  },
  badgeText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  card: {
    backgroundColor: CARD, borderRadius: 12, margin: 16, padding: 16,
    borderWidth: 1, borderColor: BORDER,
  },
  label: { color: '#8FA8C8', fontSize: 14, marginBottom: 8 },
  input: {
    backgroundColor: NAVY, borderRadius: 8, borderWidth: 1, borderColor: BORDER,
    padding: 12, color: '#fff', marginBottom: 12,
  },
  btnPrimary: {
    backgroundColor: BLUE, borderRadius: 8, paddingVertical: 14,
    alignItems: 'center',
  },
  disabled: { opacity: 0.5 },
  btnPrimaryText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  avatar: {
    width: 50, height: 50, borderRadius: 25,
    backgroundColor: BLUE, alignItems: 'center', justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarImg: { width: 50, height: 50 },
  avatarText: { color: '#fff', fontSize: 22, fontWeight: '800' },
  name: { color: '#fff', fontSize: 16, fontWeight: '700' },
  email: { color: '#8FA8C8', fontSize: 13, marginTop: 2 },
  sectionContainer: { marginTop: 8, paddingHorizontal: 16 },
  sectionHeaderRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    marginBottom: 12,
  },
  sectionTitle: { color: '#8FA8C8', fontSize: 16, fontWeight: '600' },
  atletaCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: CARD, borderRadius: 10, padding: 12,
    marginBottom: 8, borderWidth: 1, borderColor: BORDER, gap: 12,
  },
  atletaName: { color: '#fff', fontSize: 16, fontWeight: '600' },
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: NAVY, borderTopLeftRadius: 20, borderTopRightRadius: 20,
    maxHeight: '80%', paddingBottom: 30,
  },
  modalHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 16, borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  modalTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  emptyText: { color: '#8FA8C8', textAlign: 'center', marginTop: 30 },
  solicitudCard: {
    backgroundColor: CARD, padding: 16, marginHorizontal: 16, marginTop: 10,
    borderRadius: 10, borderWidth: 1, borderColor: BORDER,
  },
  solicitudName: { color: '#fff', fontSize: 16, fontWeight: '600' },
  solicitudDate: { color: '#8FA8C8', fontSize: 12, marginTop: 4 },
  acciones: { flexDirection: 'row', marginTop: 12, gap: 10 },
  btnAceptar: {
    backgroundColor: BLUE, borderRadius: 6,
    paddingHorizontal: 20, paddingVertical: 10,
  },
  btnAceptarText: { color: '#fff', fontWeight: '600' },
  btnRechazar: {
    backgroundColor: 'transparent', borderRadius: 6,
    paddingHorizontal: 20, paddingVertical: 10,
    borderWidth: 1, borderColor: RED,
  },
  btnRechazarText: { color: RED, fontWeight: '600' },
});
