// screens/DonationScreen.js
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Linking, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getThemeColors, useAppSettings } from '../services/appSettings';

const NAVY   = '#0D1B2A';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';

export default function DonationScreen({ navigation }) {
  const appSettings = useAppSettings();
  const lang = appSettings.language;           // re-renderiza al cambiar idioma
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const L = (es, en) => (lang === 'en' ? en : es); // helper local de traducción

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <View style={[styles.header, { borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={24} color="#8FA8C8" />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: theme.text }]}>{L('Donaciones', 'Donations')}</Text>
        <View style={{ width: 40 }} />
      </View>
      <View style={styles.content}>
        {/* Icono del café */}
        <View style={[styles.coffeeIcon, { backgroundColor: theme.background === '#F4F7FB' ? '#FFF0D6' : '#3E2723' }]}>
          <Ionicons name="cafe" size={80} color={theme.background === '#F4F7FB' ? '#A85D1A' : '#C98A52'} />
        </View>
        <Text style={[styles.title, { color: theme.text }]}>
          {L('¡Ayúdanos a mantener la app!', 'Help us keep the app alive!')}
        </Text>
        <Text style={[styles.text, { color: theme.muted }]}>
          {L(
            'Si te gusta Team Jorge App y quieres apoyar su desarrollo, invítanos a un café.',
            'If you like Team Jorge App and want to support its development, buy us a coffee.'
          )}
          {'\n\n'}
          {L(
            'Tu contribución nos ayuda a cubrir los costes del servidor, mejorar la app y añadir nuevas funcionalidades.',
            'Your contribution helps us cover server costs, improve the app and add new features.'
          )}
          {'\n\n'}
          {L('¡Muchas gracias por tu apoyo! ❤️', 'Thank you so much for your support! ❤️')}
        </Text>
        {/* Botón de donación (puedes cambiar la URL por tu enlace de Ko‑fi, PayPal, etc.) */}
        <TouchableOpacity
          style={styles.donateBtn}
          onPress={() => Linking.openURL('https://ko-fi.com/pablotrabalon')}   // 👈 cambia la URL
        >
          <Ionicons name="heart" size={20} color="#fff" />
          <Text style={styles.donateBtnText}>{L('Invítanos a un café', 'Buy us a coffee')}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 56, paddingBottom: 16,
    borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  coffeeIcon: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#3E2723',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  title: {
    color: '#fff',
    fontSize: 22,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 16,
  },
  text: {
    color: '#8FA8C8',
    fontSize: 15,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 32,
  },
  donateBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: BLUE,
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 10,
  },
  donateBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
});
