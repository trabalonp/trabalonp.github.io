// screens/WorkoutDetailModal.js
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Modal, View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, KeyboardAvoidingView, Platform, Alert, ActivityIndicator, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { doc, updateDoc, deleteDoc, arrayUnion, arrayRemove, Timestamp, getDoc, setDoc, addDoc, collection, getDocs, orderBy, where, increment, query } from 'firebase/firestore';
import { auth, db } from '../firebaseConfig';
import { getCachedProfile } from '../services/profileCache';
import { getApiUrl } from '../services/api';
import { getThemeColors, useAppSettings } from '../services/appSettings';
import ActivityChart from '../components/ActivityChart';
import GpsMap from '../components/GpsMap';
import StepEditor, { normalizeStep } from '../components/StepEditor';

const NAVY='#0D1B2A', CARD='#162032', BLUE='#4A90E2', GREEN='#2DB37A', RED='#E05252', BORDER='#1E3048';
const MOODS = ['😫','😕','😐','🙂','😁'];
// Valores GUARDADOS en Firestore (no se traducen): se guarda el string ES y se pinta traducido
const CARGAS = ['Muy baja','Baja','Moderada','Alta','Muy alta'];
const TIPOS_ACTIV = [
  { label:'Running', icon:'walk', color:'#E05252' }, { label:'Ciclismo', icon:'bicycle', color:'#F5A623' },
  { label:'Natación', icon:'water', color:'#4A90E2' }, { label:'Fuerza', icon:'barbell', color:'#9B59B6' },
  { label:'Triatlón', icon:'trophy', color:'#2DB37A' }, { label:'Evento', icon:'calendar-outline', color:'#F5A623' },
  { label:'Descanso', icon:'moon', color:'#7F8FA6' }, { label:'Otro', icon:'flash', color:'#8FA8C8' },
];
const TIPO_ICON = { Running:'walk', Ciclismo:'bicycle', Natación:'water', Fuerza:'barbell', Triatlón:'trophy', Otro:'flash', Evento:'calendar-outline', Descanso:'moon' };
const TIPO_COLOR = { Running:'#E05252', Ciclismo:'#F5A623', Natación:'#4A90E2', Fuerza:'#9B59B6', Triatlón:'#2DB37A', Otro:'#8FA8C8', Evento:'#F5A623', Descanso:'#7F8FA6' };

const formatSeconds = (s) => { if (s == null) return '—'; const h=Math.floor(s/3600), m=Math.floor((s%3600)/60), ss=Math.floor(s%60); return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(ss).padStart(2,'0')}`; };
const parseDuration = (t) => { const p = t.trim().split(':'); if (p.length===3) return (parseInt(p[0])||0)*3600+(parseInt(p[1])||0)*60+(parseInt(p[2])||0); if (p.length===2) return (parseInt(p[0])||0)*60+(parseInt(p[1])||0); const n=parseFloat(t); return isNaN(n)?null:Math.round(n); };
const formatFecha = (ts, loc) => { if (!ts) return '—'; const d = ts.toDate ? ts.toDate() : new Date(ts); return d.toLocaleDateString(loc,{day:'numeric',month:'short',year:'numeric'}); };

// Picker a pantalla completa: guarda `value ?? label` y pinta la etiqueta traducida
function FullScreenPicker({ value, options, onChange, placeholder='Escoge', icon, iconColor, title, cancelText }) {
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const [visible, setVisible] = useState(false);
  const isObj = options[0] && typeof options[0] === 'object';
  const valOf = (o) => (isObj ? (o.value ?? o.label) : o);
  const lblOf = (o) => (isObj ? o.label : o);
  const select = (o) => { onChange(valOf(o)); setVisible(false); };
  const currentLabel = isObj ? (options.find(o => valOf(o) === value)?.label ?? value) : value;
  return (
    <>
      <TouchableOpacity style={[pk.btn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => setVisible(true)} activeOpacity={0.8}>
        <View style={pk.pickerLeft}>
          {icon && <Ionicons name={icon} size={18} color={iconColor || '#8FA8C8'} style={{ marginRight: 8 }} />}
          <Text style={[pk.text, { color: currentLabel ? theme.text : theme.muted }]} numberOfLines={1}>{currentLabel || placeholder}</Text>
        </View>
        <Ionicons name="chevron-down" size={15} color="#8FA8C8" />
      </TouchableOpacity>
      <Modal visible={visible} animationType="slide" transparent={false}>
        <View style={[pk.fullScreen, { backgroundColor: theme.background }]}>
          <View style={[pk.fullHeader, { borderBottomColor: theme.border }]}>
            <Text style={[pk.fullTitle, { color: theme.text }]}>{title ?? 'Selecciona una opción'}</Text>
            <TouchableOpacity onPress={() => setVisible(false)}>
              <Ionicons name="close" size={24} color="#8FA8C8" />
            </TouchableOpacity>
          </View>
          <ScrollView style={pk.fullList}>
            {options.map((o, i) => {
              const sel = valOf(o) === value;
              return (
                <TouchableOpacity key={String(valOf(o))} style={[pk.fullOption, { borderBottomColor: theme.border }, sel && pk.fullOptionActive]} onPress={() => select(o)}>
                  <Text style={[pk.fullOptionIndex, { color: theme.muted }, sel && pk.fullOptionIndexActive]}>{i+1}</Text>
                  {isObj && o.icon ? <Ionicons name={o.icon} size={20} color={o.color || '#8FA8C8'} /> : null}
                  <Text style={[pk.fullOptionText, { color: theme.text }, sel && pk.fullOptionTextActive]}>{lblOf(o)}</Text>
                  {sel && <Ionicons name="checkmark" size={20} color={BLUE} />}
                </TouchableOpacity>
              );
            })}
          </ScrollView>
          <TouchableOpacity style={[pk.fullCancelBtn, { borderTopColor: theme.border }]} onPress={() => setVisible(false)}>
            <Text style={pk.fullCancelText}>{cancelText ?? 'Cancelar'}</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </>
  );
}
const pk = StyleSheet.create({
  btn:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',backgroundColor:CARD,borderRadius:6,borderWidth:1,borderColor:BORDER,paddingHorizontal:12,paddingVertical:12,marginVertical:4},
  pickerLeft:{flexDirection:'row',alignItems:'center',flex:1}, text:{color:'#fff',fontSize:14,flex:1}, ph:{color:'#4A6080'},
  fullScreen:{flex:1,backgroundColor:NAVY},
  fullHeader:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingTop:56,paddingHorizontal:20,paddingBottom:16,borderBottomWidth:1,borderBottomColor:BORDER},
  fullTitle:{color:'#fff',fontSize:18,fontWeight:'700'}, fullList:{flex:1,paddingHorizontal:16},
  fullOption:{flexDirection:'row',alignItems:'center',paddingVertical:16,paddingHorizontal:12,borderBottomWidth:1,borderBottomColor:BORDER,gap:14},
  fullOptionActive:{backgroundColor:BLUE+'22',borderRadius:8},
  fullOptionIndex:{color:'#8FA8C8',fontSize:16,fontWeight:'600',minWidth:24}, fullOptionIndexActive:{color:BLUE},
  fullOptionText:{color:'#fff',fontSize:16,flex:1}, fullOptionTextActive:{color:BLUE,fontWeight:'700'},
  fullCancelBtn:{paddingVertical:18,alignItems:'center',borderTopWidth:1,borderTopColor:BORDER,marginTop:8},
  fullCancelText:{color:RED,fontSize:16,fontWeight:'600'},
});

async function getCoachFullName(uid) {
  const c = await getCachedProfile(uid); if (c?.nombre) return `${c.nombre} ${c.apellido || ''}`.trim();
  const s = await getDoc(doc(db,'perfiles',uid)); if (s.exists()) { const d = s.data(); return `${d.nombre||''} ${d.apellido||''}`.trim(); }
  return 'Entrenador';
}
async function sendNotificationToAthlete(athleteId, coachId, title, body) {
  try { const apiUrl = (await getApiUrl()).replace(/\/+$/, ''); await fetch(`${apiUrl}/notify-athlete`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ coachId, athleteId, title, body }) }); } catch (e) {}
}

export default function WorkoutDetailModal({ visible, workout, onClose, onWorkoutUpdated, athleteId }) {
  const appSettings = useAppSettings();
  const lang = appSettings.language;            // re-renderiza al cambiar idioma
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción
  const loc = lang === 'en' ? 'en-US' : 'es-ES';

  // Opciones traducidas (el valor guardado sigue siendo el original en español)
  const CARGA_OPTS = CARGAS.map(c => ({ value: c, label: ({'Muy baja':L('Muy baja','Very low'),'Baja':L('Baja','Low'),'Moderada':L('Moderada','Moderate'),'Alta':L('Alta','High'),'Muy alta':L('Muy alta','Very high')})[c] }));
  const HORA_OPTS = [
    { value:'Mañana', label:L('Mañana','Morning') },
    { value:'Tarde', label:L('Tarde','Afternoon') },
    { value:'Personalizado', label:L('Personalizado','Custom') },
  ];
  const SUBTAB_LABEL = { general:L('General','General'), vueltas:L('Vueltas','Laps'), detalles:L('Detalles','Details'), zonas:L('Zonas','Zones') };
  const LAP_HEADERS = [L('Vuelta','Lap'),L('Distancia','Distance'),L('Tiempo','Time'),L('Ritmo Med','Avg Pace'),L('Ritmo Máx','Max Pace'),L('FC Med','Avg HR'),L('FC Máx','Max HR'),L('Cad. Med','Avg Cad'),L('Cad. Máx','Max Cad'),L('Gan. Elev','Elev Gain'),L('Pér. Elev','Elev Loss'),L('Dif. Elev','Elev Diff')];

  const [mode, setMode] = useState('view');
  const [mainTab, setMainTab] = useState('sesion');
  const [subTab, setSubTab] = useState('general');
  const [estado, setEstado] = useState(null);
  const [originalFechaStr, setOriginalFechaStr] = useState('');
  const [durSec, setDurSec] = useState(null);
  const [durText, setDurText] = useState('');
  const [distancia, setDistancia] = useState('');
  const [ritmo, setRitmo] = useState('');
  const [fc, setFc] = useState('');
  const [fcMax, setFcMax] = useState('');
  const [elevMin, setElevMin] = useState('');
  const [elevMax, setElevMax] = useState('');
  const [carga, setCarga] = useState(null);
  const [esfuerzo, setEsfuerzo] = useState('');
  const [enlace, setEnlace] = useState('');
  const [sensacion, setSensacion] = useState(2);
  const [loading, setLoading] = useState(false);
  const [actividad, setActividad] = useState('Running');
  const [titulo, setTitulo] = useState('');
  const [fechaStr, setFechaStr] = useState('');
  const [horaMode, setHoraMode] = useState('Mañana');
  const [horaCustom, setHoraCustom] = useState('08:00');
  const [descripcion, setDescripcion] = useState('');
  const [pasos, setPasos] = useState([]);
  const [cadencia, setCadencia] = useState('');
  const [desnivelPos, setDesnivelPos] = useState('');
  const [temperatura, setTemperatura] = useState('');
  const [fcZones, setFcZones] = useState([]);
  const [ritmoZones, setRitmoZones] = useState([]);
  const [vueltas, setVueltas] = useState([]);
  const [registros, setRegistros] = useState(null);
  const [registrosLoaded, setRegistrosLoaded] = useState(false);
  const [loadingRegistros, setLoadingRegistros] = useState(false);
  const [loadingHeavyData, setLoadingHeavyData] = useState(false);
  const [comentario, setComentario] = useState('');
  const [comentarios, setComentarios] = useState([]);
  const [sendingComm, setSendingComm] = useState(false);
  const [currentUserName, setCurrentUserName] = useState('');
  const [libItems, setLibItems] = useState([]);
  const [loadingLib, setLoadingLib] = useState(false);
  const [savingLib, setSavingLib] = useState(false);
  const [libError, setLibError] = useState(null);
  const [libSort, setLibSort] = useState('usados');
  const [libSearch, setLibSearch] = useState('');
  const actSel = TIPOS_ACTIV.find(t => t.label === actividad) || TIPOS_ACTIV[0];

  const cargarRegistros = useCallback(async () => {
    if (!workout?.id || registrosLoaded || loadingRegistros) return;
    setLoadingRegistros(true);
    try { const s = await getDoc(doc(db,'entrenamientos',workout.id,'registros','data')); if (s.exists()) { const pts = s.data().puntos ?? []; pts.sort((a,b) => new Date(a.timestamp)-new Date(b.timestamp)); setRegistros(pts); setRegistrosLoaded(true); } } catch (e) {} finally { setLoadingRegistros(false); }
  }, [workout?.id, registrosLoaded, loadingRegistros]);
  useEffect(() => { if ((subTab === 'detalles' || subTab === 'zonas') && visible) cargarRegistros(); }, [subTab, visible, cargarRegistros]);

  const fcDistribution = useMemo(() => { if (!registros || registros.length < 2 || !fcZones.length) return []; const d = fcZones.map(z => ({...z, time:0})); for (let i=1;i<registros.length;i++){ const f=registros[i].frecuencia; const dt=(new Date(registros[i].timestamp)-new Date(registros[i-1].timestamp))/1000; for (const z of d){ if (f >=z.min && f <z.max){ z.time+=dt; break; } } } return d; }, [registros, fcZones]);
  const ritmoDistribution = useMemo(() => { if (!registros || registros.length < 2 || !ritmoZones.length) return []; const zs = ritmoZones.map(z => { const s1 = z.min ? z.min.split(':').reduce((a,b)=>Number(a)*60+Number(b),0) : 0; const s2 = z.max ? z.max.split(':').reduce((a,b)=>Number(a)*60+Number(b),0) : Infinity; return {...z, minSec:Math.min(s1,s2), maxSec:Math.max(s1,s2)}; }); const d = ritmoZones.map(z => ({...z, time:0})); for (let i=1;i<registros.length;i++){ const sp=registros[i].velocidad; if (sp <=0) continue; const rs=(60/sp)*60; const dt=(new Date(registros[i].timestamp)-new Date(registros[i-1].timestamp))/1000; for (const z of zs){ if (rs >=z.minSec && rs <z.maxSec){ const f=d.find(x=>x.id===z.id); if (f) f.time+=dt; break; } } } return d; }, [registros, ritmoZones]);

  const fetchLibrary = useCallback(async () => {
    const uid = auth.currentUser?.uid; if (!uid) return;
    setLoadingLib(true); setLibError(null);
    try {
      const q = query(collection(db,'libreria'), where('userId','==',uid), orderBy('timesUsed','desc'), orderBy('createdAt','asc'));
      const snap = await getDocs(q); let items = snap.docs.map(d => ({ id:d.id, ...d.data() }));
      const s = libSearch.trim().toLowerCase(); if (s) items = items.filter(i => (i.titulo||i.tipo||'').toLowerCase().includes(s));
      if (libSort === 'recientes') items.sort((a,b) => (b.createdAt?.toMillis?.() ?? 0)-(a.createdAt?.toMillis?.() ?? 0));
      setLibItems(items);
    } catch (e) { setLibError({ message: e.message }); } finally { setLoadingLib(false); }
  }, [libSearch, libSort]);
  useEffect(() => { if (visible && mode === 'edit' && mainTab === 'libreria') fetchLibrary(); }, [visible, mode, mainTab, fetchLibrary]);

  useEffect(() => {
    if (!workout || !visible) return;
    setRegistros(null); setRegistrosLoaded(true); setFcZones([]); setRitmoZones([]); setVueltas([]); setLoadingHeavyData(false);
    setEstado(workout.estado ?? null);
    let ns = null; if (workout.duracion != null) ns = workout.duracion < 600 ? workout.duracion*60 : workout.duracion;
    setDurSec(ns); setDurText(ns ? formatSeconds(ns) : '');
    setDistancia(workout.distancia?.toString() ?? ''); setRitmo(workout.ritmo ?? '');
    setFc((workout['fc-media'] ?? workout.fc)?.toString() ?? ''); setFcMax(workout.fcMax?.toString() ?? '');
    setElevMin(workout.elevacionMin?.toString() ?? ''); setElevMax(workout.elevacionMax?.toString() ?? '');
    setCarga(workout.cargaPercibida ?? null); setEsfuerzo(workout.esfuerzo?.toString() ?? '');
    setEnlace(workout.enlace ?? ''); setSensacion(workout.sensacion ?? 2);
    setActividad(workout.tipo ?? 'Running'); setTitulo(workout.titulo ?? workout.tipo ?? '');
    setDescripcion(workout.descripcion ?? ''); setPasos(workout.pasos ?? []); setComentarios(workout.comentarios ?? []);
    setCadencia(workout.cadencia?.toString() ?? ''); setDesnivelPos(workout.desnivelPos?.toString() ?? ''); setTemperatura(workout.temperatura?.toString() ?? '');
    const fd = workout.fecha?.toDate ? workout.fecha.toDate() : new Date(workout.fecha ?? Date.now());
    setFechaStr(fd.toLocaleDateString('es-ES')); setOriginalFechaStr(fd.toLocaleDateString('es-ES'));
    const hh = fd.getHours();
    if (hh === 8) { setHoraMode('Mañana'); setHoraCustom('08:00'); }
    else if (hh === 18) { setHoraMode('Tarde'); setHoraCustom('18:00'); }
    else { setHoraMode('Personalizado'); setHoraCustom(`${String(hh).padStart(2,'0')}:${String(fd.getMinutes()).padStart(2,'0')}`); }
    setMode('view'); setMainTab('sesion'); setSubTab('general'); setComentario(''); setLibSearch(''); setLibSort('usados');
    (async () => {
      const uid = athleteId || auth.currentUser?.uid;
      const c = await getCachedProfile(uid);
      if (c) { setCurrentUserName(c.nombre || 'Tú'); setFcZones(c.zonasFC || []); setRitmoZones(c.zonasRitmo || []); }
      else { try { const s = await getDoc(doc(db,'perfiles',uid)); if (s.exists()) { const d = s.data(); setCurrentUserName(d.nombre || 'Tú'); setFcZones(d.zonasFC || []); setRitmoZones(d.zonasRitmo || []); } } catch (e) {} }
    })();
    (async () => {
      setLoadingHeavyData(true);
      try {
        const det = await getDoc(doc(db,'entrenamientos',workout.id,'detalles','data'));
        if (det.exists()) { const d = det.data();
          if (d.ritmo) setRitmo(d.ritmo); if (d.fcMax) setFcMax(d.fcMax.toString());
          if (d.elevacionMin != null) setElevMin(d.elevacionMin.toString()); if (d.elevacionMax != null) setElevMax(d.elevacionMax.toString());
          if (d.cadencia) setCadencia(d.cadencia.toString()); if (d.desnivelPos) setDesnivelPos(d.desnivelPos.toString()); if (d.temperatura) setTemperatura(d.temperatura.toString());
          if (d.cargaPercibida) setCarga(d.cargaPercibida); if (d.esfuerzo) setEsfuerzo(d.esfuerzo.toString()); if (d.enlace) setEnlace(d.enlace);
          if (d.sensacion != null) setSensacion(d.sensacion); if (d.descripcion) setDescripcion(d.descripcion); if (d.pasos) setPasos(d.pasos); if (d.comentarios) setComentarios(d.comentarios);
          setVueltas(d.vueltas ?? []); setRegistrosLoaded(false);
        } else { const m = await getDoc(doc(db,'entrenamientos',workout.id)); if (m.exists()) { const d = m.data(); setVueltas(d.vueltas ?? []); if (d.registros) { setRegistros(d.registros); setRegistrosLoaded(true); } } }
      } catch (e) {} finally { setLoadingHeavyData(false); }
    })();
  }, [workout, visible, athleteId]);

  useEffect(() => {
    if (!workout || !visible || !workout.intervalsId) return;
    (async () => {
      try {
        const det = await getDoc(doc(db,'entrenamientos',workout.id,'detalles','data'));
        if (det.exists() && det.data().intervalsDetailSynced && det.data().hasRuta === true) return;
        const apiUrl = (await getApiUrl()).replace(/\/+$/, ''); const token = await auth.currentUser.getIdToken();
        const r = await fetch(`${apiUrl}/sync-intervals-detail`, { method:'POST', headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`}, body: JSON.stringify({ intervalsId: String(workout.intervalsId) }) });
        if (!r.ok) return;
        const d2s = await getDoc(doc(db,'entrenamientos',workout.id,'detalles','data'));
        if (d2s.exists()) { const d2 = d2s.data(); setVueltas(d2.vueltas ?? []); if (d2.elevacionMin != null) setElevMin(d2.elevacionMin.toString()); if (d2.elevacionMax != null) setElevMax(d2.elevacionMax.toString()); }
        setRegistrosLoaded(false);
      } catch (e) {}
    })();
  }, [workout, visible]);

  const horaFinal = () => horaMode === 'Mañana' ? '08:00' : horaMode === 'Tarde' ? '18:00' : (horaCustom || '08:00');
  const handleSaveSession = async () => {
    setLoading(true);
    try {
      const secs = parseDuration(durText);
      await updateDoc(doc(db,'entrenamientos',workout.id), { estado, duracion: secs ?? null, distancia: distancia ? parseFloat(distancia) : null, 'fc-media': fc ? parseInt(fc) : null });
      await setDoc(doc(db,'entrenamientos',workout.id,'detalles','data'), { ritmo, 'fc-media': fc?parseInt(fc):null, fcMax: fcMax?parseInt(fcMax):null, elevacionMin: elevMin?parseInt(elevMin):null, elevacionMax: elevMax?parseInt(elevMax):null, cargaPercibida: carga, esfuerzo: esfuerzo?parseInt(esfuerzo):null, enlace, sensacion, comentarios, cadencia: cadencia?parseInt(cadencia):null, desnivelPos: desnivelPos?parseInt(desnivelPos):null, temperatura: temperatura?parseInt(temperatura):null }, { merge: true });
      onWorkoutUpdated?.(); onClose();
    } catch (e) { Alert.alert(L('Error','Error'), e.message); } finally { setLoading(false); }
  };
  const handleSaveEdit = async () => {
    setLoading(true);
    try {
      const p = fechaStr.split('/'); const nf = new Date(p[2], p[1]-1, p[0]);
      const [h, m] = horaFinal().split(':'); nf.setHours(parseInt(h), parseInt(m || 0));
      await updateDoc(doc(db,'entrenamientos',workout.id), { tipo: actividad, titulo: titulo || actividad, descripcion, pasos: pasos.map(normalizeStep), fecha: Timestamp.fromDate(nf) });
      onWorkoutUpdated?.(); setMode('view'); setMainTab('sesion');
      if (athleteId && fechaStr !== originalFechaStr) {
        const cn = await getCoachFullName(auth.currentUser.uid);
        await sendNotificationToAthlete(athleteId, auth.currentUser.uid, `📅 ${cn} ${L('ha movido tu entrenamiento','moved your workout')}`, `${cn} ${L('ha cambiado la fecha de','changed the date of')} "${titulo || workout.titulo}" ${L('al','to')} ${fechaStr}`);
      }
    } catch (e) { Alert.alert(L('Error','Error'), e.message); } finally { setLoading(false); }
  };
  const handleDelete = () => Alert.alert(L('Borrar entrenamiento','Delete workout'), L('¿Estás seguro? Esta acción no se puede deshacer.','Are you sure? This action cannot be undone.'), [
    { text: L('Cancelar','Cancel'), style:'cancel' },
    { text: L('Borrar','Delete'), style:'destructive', onPress: async () => { try { await deleteDoc(doc(db,'entrenamientos',workout.id)); onWorkoutUpdated?.(); onClose(); } catch (e) {} } },
  ]);
  const toggleEstado = async (v) => { const n = estado === v ? null : v; setEstado(n); try { await updateDoc(doc(db,'entrenamientos',workout.id), { estado: n }); onWorkoutUpdated?.(); } catch (e) {} };
  const handleSendComment = async () => {
    if (!comentario.trim()) return; setSendingComm(true);
    try {
      const nuevo = { texto: comentario.trim(), nombre: currentUserName || 'Tú', timestamp: Timestamp.now() };
      await updateDoc(doc(db,'entrenamientos',workout.id), { comentarios: arrayUnion(nuevo) });
      setComentarios(prev => [...prev, nuevo]); setComentario('');
      if (athleteId) { const cn = await getCoachFullName(auth.currentUser.uid); await sendNotificationToAthlete(athleteId, auth.currentUser.uid, `💬 ${cn} ${L('ha comentado en tu entrenamiento','commented on your workout')}`, `${cn} ${L('dice','says')}: "${comentario.trim()}"`); }
      onWorkoutUpdated?.();
    } catch (e) {} finally { setSendingComm(false); }
  };
  const handleDeleteComment = (c) => Alert.alert(L('Eliminar comentario','Delete comment'), L('¿Seguro que quieres eliminar este comentario?','Are you sure you want to delete this comment?'), [
    { text: L('Cancelar','Cancel'), style:'cancel' },
    { text: L('Eliminar','Delete'), style:'destructive', onPress: async () => { try { await updateDoc(doc(db,'entrenamientos',workout.id), { comentarios: arrayRemove(c) }); setComentarios(prev => prev.filter(x => !(x.texto===c.texto && x.nombre===c.nombre))); onWorkoutUpdated?.(); } catch (e) {} } },
  ]);
  const handleSaveToLibrary = async () => {
    const uid = auth.currentUser?.uid; if (!uid) return; setSavingLib(true);
    try { await addDoc(collection(db,'libreria'), { userId: uid, tipo: actividad, titulo: titulo || actividad, descripcion: descripcion || '', pasos: pasos.map(normalizeStep), timesUsed: 0, createdAt: Timestamp.now() }); Alert.alert(L('Guardado','Saved'), L('Entrenamiento guardado en tu librería.','Workout saved to your library.')); fetchLibrary(); } catch (e) {} finally { setSavingLib(false); }
  };
  const handleLoadFromLibrary = async (item) => {
    setActividad(item.tipo ?? 'Running'); setTitulo(item.titulo ?? ''); setDescripcion(item.descripcion ?? '');
    setPasos((Array.isArray(item.pasos) ? item.pasos : []).map(p => ({ ...p, hijos: p.hijos || [] })));
    try { await updateDoc(doc(db,'libreria',item.id), { timesUsed: increment(1) }); } catch (e) {}
    setMainTab('edit'); fetchLibrary();
  };
  const handleDeleteLibrary = (item) => Alert.alert(L('Eliminar de la librería','Delete from library'), L(`¿Eliminar "${item.titulo || item.tipo}"?`, `Delete "${item.titulo || item.tipo}"?`), [
    { text: L('Cancelar','Cancel'), style:'cancel' },
    { text: L('Eliminar','Delete'), style:'destructive', onPress: async () => { try { await deleteDoc(doc(db,'libreria',item.id)); fetchLibrary(); } catch (e) {} } },
  ]);

  const iconName = actSel.icon; const iconColor = actSel.color;
  const cadenceUnit = actividad === 'Ciclismo' ? 'rpm' : (lang === 'en' ? 'spm' : 'ppm');
  const formatLapTime = (s) => { if (!s) return '00:00'; return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(Math.floor(s%60)).padStart(2,'0')}`; };
  if (!workout) return null;

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <KeyboardAvoidingView style={s.kav} behavior={Platform.OS==='ios'?'padding':'height'}>
        <View style={s.overlay}>
          <View style={[s.sheet, { backgroundColor: theme.background }]}>
            <View style={[s.header, { backgroundColor: theme.card, borderBottomColor: theme.border }]}>
              <TouchableOpacity onPress={onClose} style={s.headerSide}>
                <Ionicons name="close" size={22} color="#8FA8C8" />
              </TouchableOpacity>
              <Text style={[s.headerTitle, { color: theme.text }]} numberOfLines={1}>{mode === 'edit' ? L('Editar','Edit') : (workout.titulo || workout.tipo || L('Entrenamiento','Workout'))}</Text>
              <View style={s.headerSide}>
                {mode === 'view' && (
                  <TouchableOpacity onPress={() => { setMode('edit'); setMainTab('edit'); }}>
                    <Text style={s.editBtn}>{L('Editar','Edit')}</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>

            {mode === 'view' ? (
              <View style={s.tabs}>
                <TouchableOpacity style={[s.tab, mainTab==='sesion' && s.tabActive]} onPress={() => setMainTab('sesion')}>
                  <Text style={[s.tabText, { color: theme.muted }, mainTab==='sesion' && [s.tabTextActive, { color: theme.text }]]}>{L('Sesión','Session')}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.tab, mainTab==='comentarios' && s.tabActive]} onPress={() => setMainTab('comentarios')}>
                  <Text style={[s.tabText, { color: theme.muted }, mainTab==='comentarios' && [s.tabTextActive, { color: theme.text }]]}>{L('Comentarios','Comments')}</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={s.tabs}>
                <TouchableOpacity style={[s.tab, mainTab==='edit' && s.tabActive]} onPress={() => setMainTab('edit')}>
                  <Text style={[s.tabText, { color: theme.muted }, mainTab==='edit' && [s.tabTextActive, { color: theme.text }]]}>{L('Editar','Edit')}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.tab, mainTab==='libreria' && s.tabActive]} onPress={() => setMainTab('libreria')}>
                  <Text style={[s.tabText, { color: theme.muted }, mainTab==='libreria' && [s.tabTextActive, { color: theme.text }]]}>{L('Librería','Library')}</Text>
                </TouchableOpacity>
              </View>
            )}

            {mode === 'view' && mainTab === 'sesion' && (
              <>
                <ScrollView style={s.scroll} contentContainerStyle={s.scrollPad} showsVerticalScrollIndicator={false}>
                  <View style={[s.titleCard, { backgroundColor: theme.card, borderColor: theme.border, borderWidth: 1 }]}>
                    <View style={[s.actIcon, { backgroundColor: iconColor+'22', borderColor: iconColor }]}>
                      <Ionicons name={iconName} size={20} color={iconColor} />
                    </View>
                    <View>
                      <Text style={[s.titleCardName, { color: theme.text }]}>{workout.titulo || workout.tipo}</Text>
                      <Text style={[s.titleCardDate, { color: theme.muted }]}>{formatFecha(workout.fecha, loc)}</Text>
                    </View>
                  </View>
                  <Text style={[s.sectionHead, { color: theme.muted }]}>{L('Descripción','Description')}</Text>
                  <View style={[s.descBox, { backgroundColor: theme.card, borderColor: theme.border }]}><Text style={[s.descText, { color: theme.muted }]}>{workout.descripcion || ''}</Text></View>
                  <View style={s.grid2}>
                    <FieldBox label={L('Actividad','Activity')} value={workout.tipo} />
                    <FieldBox label={L('Medida','Measure')}>
                      <Text style={[s.fieldValue, { color: theme.text }]}>
                        {distancia ? `${distancia} km` : '—'}
                        {' / '}
                        {durSec != null ? formatSeconds(durSec) : '00:00:00'}
                      </Text>
                    </FieldBox>
                  </View>
                  <Text style={[s.sectionHead, { color: theme.muted }]}>{L('Entrenamiento realizado','Completed workout')}</Text>
                  <View style={s.estadoRow}>
                    <TouchableOpacity style={[s.estadoBtn, estado==='incompleto'?s.estadoBtnRojoOn:s.estadoBtnRojoOff]} onPress={() => toggleEstado('incompleto')}>
                      <Ionicons name="close" size={22} color={estado==='incompleto'?'#fff':RED} />
                    </TouchableOpacity>
                    <TouchableOpacity style={[s.estadoBtn, estado==='completo'?s.estadoBtnVerdeOn:s.estadoBtnVerdeOff]} onPress={() => toggleEstado('completo')}>
                      <Ionicons name="checkmark" size={22} color={estado==='completo'?'#fff':GREEN} />
                    </TouchableOpacity>
                  </View>
                  <View style={s.subTabs}>
                    {['general','vueltas','detalles','zonas'].map(t => (
                      <TouchableOpacity key={t} style={[s.subTab, subTab===t && s.subTabActive]} onPress={() => setSubTab(t)}>
                        <Text style={[s.subTabText, { color: subTab === t ? theme.text : theme.muted }, subTab===t && { fontWeight: '700' }]}>{SUBTAB_LABEL[t]}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>

                  {subTab === 'general' && (loadingHeavyData ? (
                    <View style={s.emptySubTab}>
                      <ActivityIndicator color={BLUE} />
                      <Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Cargando detalles...','Loading details...')}</Text>
                    </View>
                  ) : (
                    <View style={s.generalWrap}>
                      <View style={s.fieldRow}>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Duración','Duration')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border }]}><TextInput style={[s.inputInner, { color: theme.text }]} value={durText} onChangeText={setDurText} placeholder="hh:mm:ss" placeholderTextColor="#4A6080" /></View>
                        </View>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Distancia','Distance')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',alignItems:'center'}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={distancia} onChangeText={setDistancia} placeholder="0.00" placeholderTextColor="#4A6080" keyboardType="decimal-pad" />
                            <Text style={[s.unitText, { color: theme.muted }]}>km</Text>
                          </View>
                        </View>
                      </View>
                      <View style={s.fieldRow}>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Ritmo','Pace')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',alignItems:'center'}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={ritmo} onChangeText={setRitmo} placeholder="00:00" placeholderTextColor="#4A6080" />
                            <Text style={[s.unitText, { color: theme.muted }]}>/km</Text>
                          </View>
                        </View>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('FC','HR')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',gap:6}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={fc} onChangeText={setFc} placeholder="000" placeholderTextColor="#4A6080" keyboardType="numeric" />
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={fcMax} onChangeText={setFcMax} placeholder="000" placeholderTextColor="#4A6080" keyboardType="numeric" />
                          </View>
                        </View>
                      </View>
                      <View style={s.fieldRow}>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Elevación','Elevation')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',gap:6}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={elevMin} onChangeText={setElevMin} placeholder="0" placeholderTextColor="#4A6080" keyboardType="numeric" />
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={elevMax} onChangeText={setElevMax} placeholder="0" placeholderTextColor="#4A6080" keyboardType="numeric" />
                          </View>
                        </View>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Esfuerzo','Effort')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border }]}><TextInput style={[s.inputInner, { color: theme.text }]} value={esfuerzo} onChangeText={setEsfuerzo} placeholder="0" placeholderTextColor="#4A6080" keyboardType="numeric" /></View>
                        </View>
                      </View>
                      <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Carga percibida','Perceived load')}</Text>
                      <FullScreenPicker value={carga} options={CARGA_OPTS} onChange={setCarga} placeholder={L('Escoge','Choose')} title={L('Selecciona una opción','Select an option')} cancelText={L('Cancelar','Cancel')} />
                      <Text style={[s.fieldLabel,{marginTop:12}]}>{L('Enlace','Link')}</Text>
                      <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border }]}><TextInput style={[s.inputInner, { color: theme.text }]} value={enlace} onChangeText={setEnlace} placeholder="https://..." placeholderTextColor="#4A6080" autoCapitalize="none" /></View>
                      <View style={s.fieldRow}>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Cadencia','Cadence')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',alignItems:'center'}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={cadencia} onChangeText={setCadencia} placeholder={cadenceUnit} placeholderTextColor="#4A6080" keyboardType="numeric" />
                            <Text style={[s.unitText, { color: theme.muted }]}>{cadenceUnit}</Text>
                          </View>
                        </View>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Desnivel +','Elev +')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',alignItems:'center'}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={desnivelPos} onChangeText={setDesnivelPos} placeholder="m" placeholderTextColor="#4A6080" keyboardType="numeric" />
                            <Text style={[s.unitText, { color: theme.muted }]}>m</Text>
                          </View>
                        </View>
                      </View>
                      <View style={s.fieldRow}>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Temperatura','Temperature')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',alignItems:'center'}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={temperatura} onChangeText={setTemperatura} placeholder="°C" placeholderTextColor="#4A6080" keyboardType="numeric" />
                            <Text style={[s.unitText, { color: theme.muted }]}>°C</Text>
                          </View>
                        </View>
                        <View style={s.fieldHalf} />
                      </View>
                      <Text style={[s.fieldLabel,{marginTop:12}]}>{L('¿Cómo te has sentido?','How did you feel?')}</Text>
                      <View style={s.moodRow}>
                        {MOODS.map((e,i) => (
                          <TouchableOpacity key={i} style={[s.moodBtn, { backgroundColor: theme.card, borderColor: theme.border }, sensacion===i && s.moodBtnActive]} onPress={() => setSensacion(i)}>
                            <Text style={s.moodEmoji}>{e}</Text>
                          </TouchableOpacity>
                        ))}
                      </View>
                    </View>
                  ))}

                  {subTab === 'vueltas' && (
                    <View style={[s.lapsContainer, { backgroundColor: theme.card, borderColor: theme.border }]}>
                      {loadingHeavyData ? (
                        <View style={s.emptySubTab}>
                          <ActivityIndicator color={BLUE} />
                          <Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Cargando vueltas...','Loading laps...')}</Text>
                        </View>
                      ) : vueltas && vueltas.length > 0 ? (
                        <ScrollView horizontal showsHorizontalScrollIndicator={true}>
                          <View>
                            <View style={[s.lapHeaderRow, { backgroundColor: theme.input }]}>
                              {LAP_HEADERS.map((h,i) => (
                                <Text key={i} style={[s.lapHeaderCell, { width: [50,80,80,90,90,70,70,80,80,90,90,90][i] }]}>{h}</Text>
                              ))}
                            </View>
                            {vueltas.map((v,i) => (
                              <View key={i} style={[s.lapDataRow, { borderBottomColor: theme.border }]}>
                                <Text style={[s.lapDataCell,{width:50, color: theme.text}]}>{v.vuelta}</Text>
                                <Text style={[s.lapDataCell,{width:80, color: theme.text}]}>{v.distancia} km</Text>
                                <Text style={[s.lapDataCell,{width:80, color: theme.text}]}>{formatLapTime(v.tiempo)}</Text>
                                <Text style={[s.lapDataCell,{width:90, color: theme.text}]}>{v.ritmo||'—'}/km</Text>
                                <Text style={[s.lapDataCell,{width:90, color: theme.text}]}>{v.ritmoMaximo||'—'}/km</Text>
                                <Text style={[s.lapDataCell,{width:70, color: theme.text}]}>{v.fcMedia||'—'}</Text>
                                <Text style={[s.lapDataCell,{width:70, color: theme.text}]}>{v.fcMaxima||'—'}</Text>
                                <Text style={[s.lapDataCell,{width:80, color: theme.text}]}>{v.cadenciaMedia||'—'}</Text>
                                <Text style={[s.lapDataCell,{width:80, color: theme.text}]}>{v.cadenciaMaxima||'—'}</Text>
                                <Text style={[s.lapDataCell,{width:90, color: theme.text}]}>{v.gananciaElev||'—'}</Text>
                                <Text style={[s.lapDataCell,{width:90, color: theme.text}]}>{v.perdidaElev||'—'}</Text>
                                <Text style={[s.lapDataCell,{width:90, color: theme.text}]}>{v.difElev||'—'}</Text>
                              </View>
                            ))}
                          </View>
                        </ScrollView>
                      ) : (
                        <View style={s.emptySubTab}>
                          <Ionicons name="construct-outline" size={32} color="#2A4060" />
                          <Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Sin datos de vueltas','No lap data')}</Text>
                        </View>
                      )}
                    </View>
                  )}

                  {subTab === 'detalles' && (
                    <View style={s.detallesContainer}>
                      {(loadingHeavyData || loadingRegistros) ? (
                        <View style={s.emptySubTab}>
                          <ActivityIndicator color={BLUE} />
                          <Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Cargando datos de sensores...','Loading sensor data...')}</Text>
                        </View>
                      ) : registros && registros.length > 1 ? (
                        <>
                          <ActivityChart registros={registros} cadenceUnit={cadenceUnit} fcZones={fcZones} ritmoZones={ritmoZones} />
                          <GpsMap registros={registros} vueltas={vueltas} />
                        </>
                      ) : (
                        <View style={s.emptySubTab}>
                          <Ionicons name="construct-outline" size={32} color="#2A4060" />
                          <Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Sin datos de registros','No record data')}</Text>
                        </View>
                      )}
                    </View>
                  )}

                  {subTab === 'zonas' && (
                    <View style={s.zonesContainer}>
                      {!registros || registros.length < 2 ? (
                        <Text style={s.emptyText}>{L('Este entreno no tiene datos de registros.','This workout has no record data.')}</Text>
                      ) : fcZones.length === 0 && ritmoZones.length === 0 ? (
                        <Text style={s.emptyText}>{L('No hay zonas configuradas. Ve a Ajustes → Zonas para definirlas.','No zones configured. Go to Settings → Zones to define them.')}</Text>
                      ) : (
                        <ScrollView>
                          {ritmoZones.length > 0 && (
                            <View style={[s.zoneDistCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
                              <Text style={[s.zoneDistTitle, { color: theme.text }]}>{L('Ritmo','Pace')}</Text>
                              {ritmoDistribution.filter(z=>z.time>0).map((z,i)=>{
                                const total=ritmoDistribution.reduce((a,b)=>a+b.time,0);
                                const pct=total>0?(z.time/total)*100:0;
                                return (
                                  <View key={z.id} style={[s.zoneDistRow, { borderBottomColor: theme.border }]}>
                                    <View style={[s.zoneDistBar,{width:`${Math.min(pct,100)}%`,backgroundColor:'#4A90E2'}]} />
                                    <Text style={[s.zoneDistLabel, { color: theme.muted }]}>{z.label||`${L('Zona','Zone')} ${i+1}`}</Text>
                                    <Text style={[s.zoneDistValue, { color: theme.text }]}>{pct.toFixed(1)}%</Text>
                                  </View>
                                );
                              })}
                            </View>
                          )}
                          {fcZones.length > 0 && (
                            <View style={[s.zoneDistCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
                              <Text style={[s.zoneDistTitle, { color: theme.text }]}>{L('Frecuencia Cardíaca','Heart Rate')}</Text>
                              {fcDistribution.filter(z=>z.time>0).map((z,i)=>{
                                const total=fcDistribution.reduce((a,b)=>a+b.time,0);
                                const pct=total>0?(z.time/total)*100:0;
                                return (
                                  <View key={z.id} style={[s.zoneDistRow, { borderBottomColor: theme.border }]}>
                                    <View style={[s.zoneDistBar,{width:`${Math.min(pct,100)}%`,backgroundColor:'#E05252'}]} />
                                    <Text style={[s.zoneDistLabel, { color: theme.muted }]}>Z{i+1}</Text>
                                    <Text style={[s.zoneDistValue, { color: theme.text }]}>{pct.toFixed(1)}%</Text>
                                  </View>
                                );
                              })}
                            </View>
                          )}
                        </ScrollView>
                      )}
                    </View>
                  )}
                </ScrollView>
                {subTab === 'general' && (
                  <View style={s.footer}>
                    <TouchableOpacity style={[s.btnPrimary, loading && s.disabled]} onPress={handleSaveSession} disabled={loading}>
                      {loading ? <ActivityIndicator color="#fff" /> : <Text style={s.btnPrimaryText}>{L('Guardar','Save')}</Text>}
                    </TouchableOpacity>
                    <TouchableOpacity style={[s.btnSecondary, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={onClose}>
                      <Text style={[s.btnSecondaryText, { color: theme.text }]}>{L('Cancelar','Cancel')}</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </>
            )}

            {mode === 'view' && mainTab === 'comentarios' && (
              <View style={{ flex: 1 }}>
                <ScrollView style={s.scroll} contentContainerStyle={s.scrollPad}>
                  <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Deja un comentario','Leave a comment')}</Text>
                  <TextInput style={[s.commentInput, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={comentario} onChangeText={setComentario} multiline placeholder={L('Deja un comentario','Leave a comment')} placeholderTextColor="#4A6080" />
                  <TouchableOpacity style={[s.btnEnviar, sendingComm && s.disabled]} onPress={handleSendComment} disabled={sendingComm}>
                    {sendingComm ? <ActivityIndicator color="#fff" size="small" /> : <Text style={s.btnEnviarText}>{L('Enviar','Send')}</Text>}
                  </TouchableOpacity>
                  {comentarios.length > 0 && (
                    <View style={{ marginTop: 20 }}>
                      {comentarios.map((c,i) => {
                        const ts = c.timestamp?.toDate ? c.timestamp.toDate() : new Date(c.timestamp ?? Date.now());
                        return (
                          <View key={i} style={[s.commentCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
                            <View style={s.commentHeader}>
                              <View style={{flex:1}}>
                                <Text style={[s.commentName, { color: BLUE }]}>{c.nombre||L('Usuario','User')}</Text>
                                <Text style={[s.commentTime, { color: theme.muted }]}>{ts.toLocaleDateString(loc,{day:'numeric',month:'short'})}</Text>
                              </View>
                              <TouchableOpacity onPress={() => handleDeleteComment(c)}>
                                <Ionicons name="trash-outline" size={16} color={RED} />
                              </TouchableOpacity>
                            </View>
                            <Text style={[s.commentText, { color: theme.text }]}>{c.texto}</Text>
                          </View>
                        );
                      })}
                    </View>
                  )}
                </ScrollView>
              </View>
            )}

            {mode === 'edit' && mainTab === 'edit' && (
              <>
                <ScrollView style={s.scroll} contentContainerStyle={s.scrollPad} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
                  <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Actividad','Activity')}</Text>
                  <FullScreenPicker value={actividad} options={TIPOS_ACTIV} onChange={setActividad} icon={iconName} iconColor={iconColor} placeholder={L('Escoge','Choose')} title={L('Selecciona una opción','Select an option')} cancelText={L('Cancelar','Cancel')} />
                  <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border, marginTop: 6 }]}>
                    <TextInput style={[s.inputInner, { color: theme.text }]} value={titulo} onChangeText={setTitulo} placeholder={L('Título del entrenamiento','Workout title')} placeholderTextColor="#4A6080" />
                  </View>
                  <View style={s.fieldRow}>
                    <View style={s.fieldHalf}>
                      <Text style={[s.fieldLabel,{marginTop:12}]}>{L('Fecha','Date')}</Text>
                      <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border }]}><TextInput style={[s.inputInner, { color: theme.text }]} value={fechaStr} onChangeText={setFechaStr} placeholder="DD/MM/AAAA" placeholderTextColor="#4A6080" /></View>
                    </View>
                    <View style={s.fieldHalf}>
                      <Text style={[s.fieldLabel,{marginTop:12}]}>{L('Hora','Time')}</Text>
                      <FullScreenPicker value={horaMode} options={HORA_OPTS} onChange={setHoraMode} placeholder={L('Escoge','Choose')} title={L('Selecciona una opción','Select an option')} cancelText={L('Cancelar','Cancel')} />
                      {horaMode === 'Personalizado' && (
                        <TextInput style={[s.inputInner, { color: theme.text, backgroundColor: theme.card, borderColor: theme.border, borderWidth: 1, borderRadius: 6, padding: 10, marginTop: 6 }]} value={horaCustom} onChangeText={setHoraCustom} placeholder="HH:MM" placeholderTextColor={theme.muted} keyboardType="number-pad" />
                      )}
                    </View>
                  </View>
                  <Text style={[s.fieldLabel,{marginTop:12}]}>{L('Pasos','Steps')}</Text>
                  <StepEditor pasos={pasos} setPasos={setPasos} />
                  <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Descripción','Description')}</Text>
                  <TextInput style={[s.textarea, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={descripcion} onChangeText={setDescripcion} multiline placeholder={L('Detalles del entreno...','Workout details...')} placeholderTextColor="#4A6080" />
                  <TouchableOpacity style={[s.libSaveBtn, savingLib && s.disabled]} onPress={handleSaveToLibrary} disabled={savingLib}>
                    {savingLib ? <ActivityIndicator color="#fff" /> : <Ionicons name="bookmark-outline" size={18} color="#fff" />}
                    <Text style={s.libSaveBtnText}>{L('Guardar en librería','Save to library')}</Text>
                  </TouchableOpacity>
                </ScrollView>
                <View style={s.footerRow}>
                  <TouchableOpacity style={[s.btnPrimary, loading && s.disabled]} onPress={handleSaveEdit} disabled={loading}>
                    {loading ? <ActivityIndicator color="#fff" /> : <Text style={s.btnPrimaryText}>{L('Guardar','Save')}</Text>}
                  </TouchableOpacity>
                  <TouchableOpacity style={s.btnDelete} onPress={handleDelete}>
                    <Text style={s.btnDeleteText}>{L('Borrar','Delete')}</Text>
                  </TouchableOpacity>
                </View>
              </>
            )}

            {mode === 'edit' && mainTab === 'libreria' && (
              <View style={{ flex: 1 }}>
                <View style={s.libControls}>
                  <View style={s.libSortRow}>
                    <TouchableOpacity style={[s.libSortBtn, { backgroundColor: theme.card, borderColor: theme.border }, libSort==='usados' && s.libSortBtnActive]} onPress={() => setLibSort('usados')}>
                      <Text style={[s.libSortBtnText, { color: theme.muted }, libSort==='usados' && s.libSortBtnTextActive]}>{L('Más usados','Most used')}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[s.libSortBtn, { backgroundColor: theme.card, borderColor: theme.border }, libSort==='recientes' && s.libSortBtnActive]} onPress={() => setLibSort('recientes')}>
                      <Text style={[s.libSortBtnText, { color: theme.muted }, libSort==='recientes' && s.libSortBtnTextActive]}>{L('Más recientes','Most recent')}</Text>
                    </TouchableOpacity>
                  </View>
                  <View style={[s.libSearchBox, { backgroundColor: theme.card, borderColor: theme.border }]}>
                    <Ionicons name="search-outline" size={16} color="#8FA8C8" />
                    <TextInput style={[s.libSearchInput, { color: theme.text }]} value={libSearch} onChangeText={setLibSearch} placeholder={L('Buscar por nombre...','Search by name...')} placeholderTextColor="#4A6080" />
                  </View>
                </View>
                {loadingLib ? (
                  <View style={s.emptySubTab}><ActivityIndicator color={BLUE} /></View>
                ) : libError ? (
                  <View style={s.emptySubTab}>
                    <Ionicons name="alert-circle-outline" size={32} color={RED} />
                    <Text style={[s.emptySubTabText,{color:RED}]}>{libError.message}</Text>
                  </View>
                ) : libItems.length === 0 ? (
                  <View style={s.emptySubTab}>
                    <Ionicons name="library-outline" size={32} color="#2A4060" />
                    <Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Tu librería está vacía.','Your library is empty.')}</Text>
                  </View>
                ) : (
                  <ScrollView style={s.scroll} contentContainerStyle={s.scrollPad}>
                    {libItems.map(item => (
                      <View key={item.id} style={[s.libRow, { backgroundColor: theme.card, borderColor: theme.border }]}>
                        <TouchableOpacity style={s.libRowMain} onPress={() => handleLoadFromLibrary(item)} activeOpacity={0.8}>
                          <Ionicons name={TIPO_ICON[item.tipo] ?? 'flash'} size={20} color={TIPO_COLOR[item.tipo] ?? '#8FA8C8'} />
                          <View style={{flex:1}}>
                            <Text style={[s.libRowTitle, { color: theme.text }]} numberOfLines={1}>{item.titulo || item.tipo}</Text>
                            <Text style={[s.libRowMeta, { color: theme.muted }]}>{L(`Usada ${item.timesUsed ?? 0} ${(item.timesUsed ?? 0) === 1 ? 'vez' : 'veces'}`, `Used ${item.timesUsed ?? 0} ${(item.timesUsed ?? 0) === 1 ? 'time' : 'times'}`)}</Text>
                          </View>
                        </TouchableOpacity>
                        <TouchableOpacity style={s.libDeleteBtn} onPress={() => handleDeleteLibrary(item)}>
                          <Ionicons name="trash-outline" size={18} color={RED} />
                        </TouchableOpacity>
                      </View>
                    ))}
                  </ScrollView>
                )}
              </View>
            )}
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function FieldBox({ label, value, children }) {
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  return (
    <View style={[s.fieldBox, { backgroundColor: theme.card, borderColor: theme.border }]}>
      <Text style={[s.fieldLabel, { color: theme.muted }]}>{label}</Text>
      {children ?? <Text style={[s.fieldValue, { color: theme.text }]}>{value ?? '—'}</Text>}
    </View>
  );
}

const s = StyleSheet.create({
  kav:{flex:1}, overlay:{flex:1,backgroundColor:'#000000BB',justifyContent:'flex-end'},
  sheet:{backgroundColor:NAVY,height:'95%',borderTopLeftRadius:20, borderTopRightRadius:20},
  header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:16,paddingVertical:14,borderBottomWidth:1,borderBottomColor:BORDER},
  headerSide:{width:60}, headerTitle:{color:'#fff',fontSize:16,fontWeight:'700',flex:1,textAlign:'center'}, editBtn:{color:BLUE,fontWeight:'700',fontSize:15,textAlign:'right'},
  tabs:{flexDirection:'row',borderBottomWidth:1,borderBottomColor:BORDER},
  tab:{flex:1,paddingVertical:13,alignItems:'center',flexDirection:'row',justifyContent:'center',gap:4},
  tabActive:{borderBottomWidth:2,borderBottomColor:BLUE},
  tabText:{color:'#8FA8C8',fontWeight:'600',fontSize:14}, tabTextActive:{color:'#fff',fontWeight:'700',fontSize:14},
  subTabs:{flexDirection:'row',borderBottomWidth:1,borderBottomColor:BORDER},
  subTab:{flex:1,paddingVertical:10,alignItems:'center'}, subTabActive:{borderBottomWidth:2,borderBottomColor:BLUE},
  subTabText:{color:'#4A6080',fontSize:13}, subTabTextActive:{color:'#fff',fontWeight:'700',fontSize:13},
  scroll:{flex:1}, scrollPad:{padding:16,gap:10,paddingBottom:20},
  titleCard:{flexDirection:'row',alignItems:'center',gap:12,backgroundColor:CARD,padding:14,borderRadius:8,marginBottom:4},
  actIcon:{width:40,height:40,borderRadius:20,borderWidth:1.5,alignItems:'center',justifyContent:'center'},
  titleCardName:{color:'#fff',fontSize:15,fontWeight:'700'}, titleCardDate:{color:'#8FA8C8',fontSize:13,marginTop:2},
  sectionHead:{color:'#8FA8C8',fontSize:13,fontWeight:'600',marginTop:4},
  descBox:{backgroundColor:CARD,borderRadius:8,padding:12,minHeight:48,borderWidth:1,borderColor:BORDER}, descText:{color:'#8FA8C8',fontSize:14},
  grid2:{flexDirection:'row',gap:8}, fieldBox:{flex:1,backgroundColor:CARD,borderRadius:8,padding:12,borderWidth:1,borderColor:BORDER},
  fieldLabel:{color:'#8FA8C8',fontSize:12,marginBottom:4}, fieldValue:{color:'#fff',fontSize:14,fontWeight:'600'},
  estadoRow:{flexDirection:'row',gap:8}, estadoBtn:{flex:1,alignItems:'center',justifyContent:'center',paddingVertical:12,borderRadius:8,borderWidth:1.5},
  estadoBtnRojoOff:{backgroundColor:'transparent',borderColor:RED+'60'}, estadoBtnRojoOn:{backgroundColor:RED,borderColor:RED},
  estadoBtnVerdeOff:{backgroundColor:'transparent',borderColor:GREEN+'60'}, estadoBtnVerdeOn:{backgroundColor:GREEN,borderColor:GREEN},
  generalWrap:{gap:10,paddingTop:4}, fieldRow:{flexDirection:'row',gap:8}, fieldHalf:{flex:1,gap:4},
  inputBox:{backgroundColor:CARD,borderRadius:6,borderWidth:1,borderColor:BORDER,paddingHorizontal:12,paddingVertical:11},
  inputInner:{color:'#fff',fontSize:14,padding:0}, unitText:{color:'#8FA8C8',fontSize:13,marginRight:2},
  moodRow:{flexDirection:'row',justifyContent:'space-between',marginTop:6},
  moodBtn:{width:48,height:48,borderRadius:24,backgroundColor:CARD,alignItems:'center',justifyContent:'center',borderWidth:2,borderColor:BORDER},
  moodBtnActive:{borderColor:BLUE,backgroundColor:BLUE+'33'}, moodEmoji:{fontSize:22},
  emptySubTab:{alignItems:'center',paddingVertical:40,gap:10}, emptySubTabText:{color:'#2A4060',fontSize:14,textAlign:'center'},
  commentInput:{backgroundColor:CARD,borderRadius:8,borderWidth:1,borderColor:BORDER,padding:14,color:'#fff',minHeight:100,textAlignVertical:'top',fontSize:14,marginBottom:10},
  btnEnviar:{backgroundColor:BLUE,paddingHorizontal:20,paddingVertical:10,borderRadius:8,alignSelf:'flex-start'}, btnEnviarText:{color:'#fff',fontWeight:'700',fontSize:14},
  commentCard:{backgroundColor:CARD,borderRadius:10,padding:12,marginBottom:8},
  commentHeader:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:4},
  commentName:{color:BLUE,fontWeight:'700',fontSize:13}, commentTime:{color:'#4A6080',fontSize:12}, commentText:{color:'#fff',fontSize:14,lineHeight:20},
  lapsContainer:{marginTop:8,backgroundColor:CARD,borderRadius:8,borderWidth:1,borderColor:BORDER,overflow:'hidden'},
  lapHeaderRow:{flexDirection:'row',backgroundColor:'#0A1828',paddingVertical:10,paddingHorizontal:4},
  lapHeaderCell:{color:'#8FA8C8',fontSize:12,fontWeight:'700',textAlign:'center'},
  lapDataRow:{flexDirection:'row',paddingVertical:8,paddingHorizontal:4,borderBottomWidth:1,borderBottomColor:BORDER},
  lapDataCell:{color:'#fff',fontSize:12,textAlign:'center'},
  detallesContainer:{marginTop:8}, zonesContainer:{paddingHorizontal:8,paddingTop:8},
  zoneDistCard:{backgroundColor:CARD,borderRadius:10,padding:14,marginBottom:12,borderWidth:1,borderColor:BORDER},
  zoneDistTitle:{color:'#fff',fontSize:16,fontWeight:'700',marginBottom:10},
  zoneDistRow:{position:'relative',flexDirection:'row',justifyContent:'space-between',paddingVertical:8,paddingHorizontal:12,borderBottomWidth:1,borderBottomColor:BORDER,overflow:'hidden'},
  zoneDistLabel:{color:'#8FA8C8',fontSize:14,fontWeight:'600'}, zoneDistBar:{position:'absolute',top:0,bottom:0,left:0,borderRadius:6,opacity:0.25}, zoneDistValue:{color:'#fff',fontSize:14},
  emptyText:{color:'#8FA8C8',fontSize:14,textAlign:'center',marginTop:30},
  textarea:{backgroundColor:CARD,borderRadius:8,borderWidth:1,borderColor:BORDER,padding:14,color:'#fff',minHeight:80,textAlignVertical:'top',fontSize:14},
  libSaveBtn:{flexDirection:'row',alignItems:'center',justifyContent:'center',gap:8,backgroundColor:BLUE,borderRadius:8,paddingVertical:12,marginTop:12},
  libSaveBtnText:{color:'#fff',fontWeight:'700',fontSize:14},
  footer:{flexDirection:'row',padding:16,gap:10,borderTopWidth:1,borderTopColor:BORDER},
  btnPrimary:{flex:1,backgroundColor:BLUE,paddingVertical:15,borderRadius:10,alignItems:'center'}, btnPrimaryText:{color:'#fff',fontWeight:'700',fontSize:16},
  btnSecondary:{flex:1,backgroundColor:CARD,paddingVertical:15,borderRadius:10,alignItems:'center',borderWidth:1,borderColor:BORDER}, btnSecondaryText:{color:'#fff',fontWeight:'700',fontSize:16},
  footerRow:{flexDirection:'row',padding:16,gap:10,borderTopWidth:1,borderTopColor:BORDER},
  btnDelete:{flex:1,backgroundColor:RED,paddingVertical:15,borderRadius:10,alignItems:'center'}, btnDeleteText:{color:'#fff',fontWeight:'700',fontSize:16},
  disabled:{opacity:0.5},
  libControls:{paddingHorizontal:16,paddingTop:12,gap:10}, libSortRow:{flexDirection:'row',gap:8},
  libSortBtn:{flex:1,alignItems:'center',backgroundColor:CARD,borderWidth:1,borderColor:BORDER,borderRadius:8,paddingVertical:8},
  libSortBtnActive:{backgroundColor:BLUE,borderColor:BLUE}, libSortBtnText:{color:'#8FA8C8',fontSize:12,fontWeight:'600'}, libSortBtnTextActive:{color:'#fff'},
  libSearchBox:{flexDirection:'row',alignItems:'center',gap:8,backgroundColor:CARD,borderWidth:1,borderColor:BORDER,borderRadius:8,paddingHorizontal:12,paddingVertical:8},
  libSearchInput:{flex:1,color:'#fff',fontSize:14,padding:0},
  libRow:{flexDirection:'row',alignItems:'center',gap:10,backgroundColor:CARD,borderRadius:10,borderWidth:1,borderColor:BORDER,paddingHorizontal:12,paddingVertical:12,marginBottom:8},
  libRowMain:{flexDirection:'row',alignItems:'center',flex:1,gap:10}, libRowTitle:{color:'#fff',fontSize:14,fontWeight:'700'}, libRowMeta:{color:'#8FA8C8',fontSize:12,marginTop:2}, libDeleteBtn:{padding:6},
});
