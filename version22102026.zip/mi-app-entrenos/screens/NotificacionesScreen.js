// screens/NotificacionesScreen.js
// ─────────────────────────────────────────────────────────────
// Historial de notificaciones (subcolección perfiles/<uid>/notificaciones,
// que rellena el servidor con cada push que envía). Igual que el mockup:
//   · Cabecera con flecha atrás + título "Notificaciones".
//   · Lista con icono por tipo + texto + día/hora de llegada.
//   · PROCEDURAL: carga 10 y al bajar al final carga 10 más (startAfter).
//   · Las NO leídas salen en NEGRITA.
//   · Botón "Marcar como leídas" abajo (todas las del usuario).
//   · Tocar una: la marca como leída y abre a donde remite — el entreno
//     (data.workoutId, mismo puente que el push) o la pestaña de retos
//     (data.retoId). Los avisos de sincronización no navegan a ningún sitio.
// ─────────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, StyleSheet, Text, TouchableOpacity, View, useColorScheme } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  collection, doc, deleteDoc, getDocs, limit, orderBy, query, startAfter, updateDoc, where, writeBatch,
} from 'firebase/firestore';
import { auth, db } from '../firebaseConfig';
import { getThemeColors, useAppSettings, L } from '../services/appSettings';
import { setPendingWorkoutId } from '../services/deepLink';
import ActivityIcon from '../components/ActivityIcon';

const PAGE = 10;
const BLUE = '#4A90E2';

// Secciones del historial: General (sincronizaciones, entrenos, retos…),
// Chat (mensajes del tablón) y Récords (marcas batidas).
const SECCIONES = [
  ['general', 'General', 'notifications'],
  ['chat', 'Chat', 'chatbubble-ellipses'],
  ['records', 'Récords', 'medal'],
];
const seccionDe = (n) => {
  const k = n?.kind || n?.data?.kind || '';
  if (k === 'chat') return 'chat';
  if (k === 'record' || k === 'records') return 'records';
  return 'general';
};

const ICONOS = {
  sync: 'sync',
  creado: 'fitness',
  evento: 'calendar',
  movido: 'calendar',
  modificado: 'pencil',
  apuntado: 'people',
  comentario: 'chatbubble-ellipses',
  reto: 'trophy',
  chat: 'chatbubble-ellipses',
  record: 'medal',
};

// "hoy 6:33 pm" · "ayer 6:48 am" · "22/09/2026 6:47 pm" (formato del mockup)
function fmtFecha(d, lang) {
  const hoy = new Date();
  const mismoDia = (a, b) => a.getDate() === b.getDate() && a.getMonth() === b.getMonth() && a.getFullYear() === b.getFullYear();
  const ayer = new Date(hoy); ayer.setDate(hoy.getDate() - 1);
  const hora = (dt) => {
    const sufijo = dt.getHours() < 12 ? 'am' : 'pm';
    const h = dt.getHours() % 12 || 12;
    return `${h}:${String(dt.getMinutes()).padStart(2, '0')} ${sufijo}`;
  };
  const p2 = (n) => String(n).padStart(2, '0');
  if (mismoDia(d, hoy)) return `${lang === 'en' ? 'today' : 'hoy'} ${hora(d)}`;
  if (mismoDia(d, ayer)) return `${lang === 'en' ? 'yesterday' : 'ayer'} ${hora(d)}`;
  return `${p2(d.getDate())}/${p2(d.getMonth() + 1)}/${d.getFullYear()} ${hora(d)}`;
}

export default function NotificacionesScreen() {
  const navigation = useNavigation();
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const insets = useSafeAreaInsets();
  const lang = appSettings.language || 'es';
  const uid = auth.currentUser?.uid;

  const [items, setItems] = useState([]);
  const [lastDoc, setLastDoc] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [cargandoMas, setCargandoMas] = useState(false);
  const [fin, setFin] = useState(false);       // no queda más historial
  const [marcando, setMarcando] = useState(false);
  const [errorCarga, setErrorCarga] = useState('');
  const [filtro, setFiltro] = useState('general');
  const [expandidos, setExpandidos] = useState(new Set()); // ids de avisos de sync desplegados

  const visibles = items.filter((n) => seccionDe(n) === filtro);

  // Sin leer por sección (para los puntos rojos de los filtros)
  const sinLeerDe = (id) => items.filter((n) => seccionDe(n) === id && !n.leido).length;

  const notificationsRef = () => collection(db, 'perfiles', uid, 'notificaciones');

  // Página de 10 (o las 10 siguientes si hay cursor). En la subcolección no
  // hace falta repetir userId ni crear un índice compuesto.
  const cargaPagina = useCallback(async (after) => {
    if (!uid) { setFin(true); return; }
    const q = after
      ? query(notificationsRef(), orderBy('createdAt', 'desc'), startAfter(after), limit(PAGE))
      : query(notificationsRef(), orderBy('createdAt', 'desc'), limit(PAGE));
    const snap = await getDocs(q);
    const lista = snap.docs.map((d) => ({
      id: d.id,
      ...d.data(),
      fecha: d.data().createdAt?.toDate?.() || new Date(),
    }));
    setItems((prev) => (after ? [...prev, ...lista] : lista));
    setLastDoc(snap.docs[snap.docs.length - 1] || null);
    if (snap.docs.length < PAGE) setFin(true);
  }, [uid]);

  useEffect(() => {
    (async () => {
      try { await cargaPagina(null); } catch (e) { console.warn('[notificaciones] lectura:', e.message); setErrorCarga(e.message || 'No se pudieron cargar las notificaciones'); }
      finally { setCargando(false); }
    })();
  }, [cargaPagina]);

  const cargarMas = async () => {
    if (cargandoMas || fin || !lastDoc) return;
    setCargandoMas(true);
    try { await cargaPagina(lastDoc); } catch (e) { console.warn('[notificaciones] siguiente página:', e.message); setErrorCarga(e.message || 'No se pudieron cargar más notificaciones'); }
    finally { setCargandoMas(false); }
  };

  // Tocar una notificación: leída + navegar a su destino si lo tiene.
  // Las de sincronización ("Se han sincronizado N entrenos") se DESPLIEGAN
  // con la lista de entrenos sincronizados (estilo TrainerPlan).
  const abrir = async (n) => {
    try { await updateDoc(doc(db, 'perfiles', uid, 'notificaciones', n.id), { leido: true }); } catch (e) {}
    setItems((prev) => prev.map((x) => (x.id === n.id ? { ...x, leido: true } : x)));
    const esSync = n.kind === 'sync' || n.data?.kind === 'sync' || /Sincronización completada/i.test(n.titulo || '');
    const entrenos = Array.isArray(n.data?.entrenos) ? n.data.entrenos : (Array.isArray(n.entrenos) ? n.entrenos : []);
    // Desplegable SOLO si hay entrenos que mostrar ("No hay entrenos nuevos"
    // no se despliega: no tiene lista).
    if (esSync && !n.workoutId && !n.retoId && entrenos.length > 0) {
      // Desplegable: mostrar/ocultar los entrenos sincronizados
      setExpandidos((prev) => {
        const s = new Set(prev);
        if (s.has(n.id)) s.delete(n.id); else s.add(n.id);
        return s;
      });
      return;
    }
    if (n.workoutId) {
      setPendingWorkoutId(n.workoutId, { athleteId: n.contextAthleteId || n.data?.contextAthleteId || n.data?.athleteId || n.athleteId || null });
      navigation.navigate('Main', { screen: 'Dashboard' });
    } else if (n.retoId) {
      navigation.navigate('Main', { screen: 'Social', params: { tab: 'retos', ts: Date.now() } });
    } else if (n.kind === 'chat' || n.data?.kind === 'chat') {
      // Mensaje del chat social → abre el Tablón
      navigation.navigate('Main', { screen: 'Social', params: { tab: 'tablon', ts: Date.now() } });
    }
  };

  // Abrir un entreno concreto desde el desplegable de una sincronización.
  // El contexto es el ATLETA dueño del entreno (data.athleteId del aviso),
  // nunca el usuario que toca (el coach puede tener otro atleta abierto).
  const abrirEntrenoSync = (entreno, item) => {
    if (!entreno || !entreno.id) return;
    setPendingWorkoutId(entreno.id, { athleteId: item?.data?.athleteId || item?.athleteId || null });
    navigation.navigate('Main', { screen: 'Dashboard' });
  };

  // Todas las del usuario a leído (tope de 300 por pulsación por si el
  // historial fuese enorme; las siguientes se marcan en otra pulsación).
  const marcarTodas = async () => {
    if (!uid || marcando) return;
    setMarcando(true);
    try {
      const q = query(notificationsRef(), where('leido', '==', false), limit(300));
      const snap = await getDocs(q);
      const batch = writeBatch(db);
      snap.forEach((d) => batch.update(d.ref, { leido: true }));
      await batch.commit();
      setItems((prev) => prev.map((x) => ({ ...x, leido: true })));
    } catch (e) {}
    finally { setMarcando(false); }
  };

  const quedanSinLeer = items.some((n) => !n.leido);

  // Al entrar en una sección, si lo cargado aún no muestra suficientes
  // notificaciones de esa sección, sigue paginando el historial (hasta que
  // haya 10, se acabe o falle) para que la pestaña no parezca vacía.
  useEffect(() => {
    if (cargando || cargandoMas || fin) return;
    if (items.filter((n) => seccionDe(n) === filtro).length >= PAGE) return;
    (async () => {
      try { await cargaPagina(lastDoc); } catch (e) {}
    })();
  }, [filtro, items, cargando, cargandoMas, fin, lastDoc, cargaPagina]);

  // Borrar una notificación del historial (con confirmación previa).
  const borrar = (n) => {
    Alert.alert(
      L('Eliminar notificación', 'Delete notification'),
      L('¿Seguro que quieres eliminar esta notificación?', 'Are you sure you want to delete this notification?'),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Eliminar', 'Delete'), style: 'destructive',
          onPress: async () => {
            setItems((prev) => prev.filter((x) => x.id !== n.id));
            try { await deleteDoc(doc(db, 'perfiles', uid, 'notificaciones', n.id)); } catch (e) {
              console.warn('[notificaciones] borrado:', e.message);
            }
          },
        },
      ]
    );
  };

  const renderItem = ({ item }) => {
    const icono = ICONOS[item.kind] || 'notifications';
    const texto = item.cuerpo || item.titulo || L('Notificación', 'Notification');
    const esSync = item.kind === 'sync' || item.data?.kind === 'sync' || /Sincronización completada/i.test(item.titulo || '');
    const entrenos = Array.isArray(item.data?.entrenos) ? item.data.entrenos : (Array.isArray(item.entrenos) ? item.entrenos : []);
    const desplegado = expandidos.has(item.id);
    return (
      <View style={{ borderBottomColor: theme.border, borderBottomWidth: 1, paddingHorizontal: 16, paddingVertical: 12 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
          <TouchableOpacity style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 14 }} onPress={() => abrir(item)} activeOpacity={0.6}>
            <View style={[st.iconoCaja, { backgroundColor: BLUE + '22' }]}>
              <Ionicons name={icono} size={20} color={BLUE} />
              {/* Punto rojo: notificación sin leer */}
              {!item.leido && <View style={[st.puntoRojo, { borderColor: theme.background }]} />}
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: theme.text, fontSize: 15, lineHeight: 21, fontWeight: item.leido ? '400' : '700' }} numberOfLines={3}>{texto}</Text>
              <Text style={{ color: theme.muted, fontSize: 13, marginTop: 5 }}>{fmtFecha(item.fecha, lang)}</Text>
            </View>
            {esSync && entrenos.length > 0 && !item.workoutId && !item.retoId && (
              <Ionicons name={desplegado ? 'chevron-up' : 'chevron-down'} size={18} color={theme.muted} />
            )}
          </TouchableOpacity>
          <TouchableOpacity onPress={() => borrar(item)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }} style={{ paddingLeft: 6 }}>
            <Ionicons name="trash-outline" size={18} color="#E05252" />
          </TouchableOpacity>
        </View>
        {/* Desplegable: entrenos sincronizados individuales (estilo TrainerPlan) */}
        {esSync && desplegado && entrenos.length > 0 && (
          <View style={{ marginTop: 8, marginLeft: 56, gap: 4 }}>
            {entrenos.length > 0 ? entrenos.map((e, i) => (
              <TouchableOpacity key={e.id || i} onPress={() => abrirEntrenoSync(e, item)} activeOpacity={0.7}
                style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 8, paddingHorizontal: 10, borderRadius: 10, backgroundColor: theme.input || '#1E3048' }}>
                <ActivityIcon size={16} tipo={e.tipo} />
                <Text style={{ color: theme.text, fontSize: 13, flex: 1 }}>{e.titulo || e.nombre || L('Entreno', 'Workout')}</Text>
                {!!e.fechaStr && <Text style={{ color: theme.muted, fontSize: 11 }}>{e.fechaStr.split('-').reverse().join('/')}</Text>}
                <Ionicons name="chevron-forward" size={15} color={theme.muted} />
              </TouchableOpacity>
            )) : (
              <Text style={{ color: theme.muted, fontSize: 12, paddingVertical: 4 }}>{L('Este aviso antiguo no guarda el detalle de los entrenos.', 'This old notification has no workout detail.')}</Text>
            )}
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={[st.pantalla, { backgroundColor: theme.background }]}>
      {/* Cabecera: flecha atrás + título centrado (mockup) */}
      <View style={[st.cabecera, { borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Ionicons name="arrow-back" size={26} color={BLUE} />
        </TouchableOpacity>
        <Text style={[st.titulo, { color: theme.text }]}>{lang === 'en' ? 'Notifications' : 'Notificaciones'}</Text>
        <View style={{ width: 26 }} />
      </View>

      {/* Secciones: General · Chat · Récords */}
      <View style={{ flexDirection: 'row', gap: 8, paddingHorizontal: 16, paddingTop: 12, paddingBottom: 10 }}>
        {SECCIONES.map(([id, labelEs, icono]) => {
          const activo = filtro === id;
          return (
            <TouchableOpacity key={id} onPress={() => setFiltro(id)}
              style={{ flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 999, borderWidth: 1, borderColor: activo ? BLUE : theme.border, backgroundColor: activo ? BLUE : 'transparent' }}>
              <Ionicons name={icono} size={13} color={activo ? '#fff' : theme.muted} />
              <Text style={{ color: activo ? '#fff' : theme.muted, fontSize: 12, fontWeight: activo ? '800' : '600' }}>{lang === 'en' ? (id === 'records' ? 'Records' : id === 'chat' ? 'Chat' : 'General') : labelEs}</Text>
              {/* Punto rojo: hay notificaciones sin leer en esta sección */}
              {sinLeerDe(id) > 0 && <View style={st.puntoChip} />}
            </TouchableOpacity>
          );
        })}
      </View>

      {cargando ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator color={BLUE} />
        </View>
      ) : (
        <FlatList
          data={visibles}
          keyExtractor={(n) => n.id}
          renderItem={renderItem}
          contentContainerStyle={{ paddingBottom: 18 }}
          ListEmptyComponent={(
            <View style={{ alignItems: 'center', paddingVertical: 60, gap: 10 }}>
              <Ionicons name="notifications-off-outline" size={40} color={theme.muted} />
              <Text style={{ color: errorCarga ? '#E05252' : theme.muted, fontSize: 14, textAlign: 'center', paddingHorizontal: 20 }}>
                {errorCarga || L('Aún no tienes notificaciones.', 'You have no notifications yet.')}
              </Text>
            </View>
          )}
          onEndReached={cargarMas}
          onEndReachedThreshold={0.2}
          ListFooterComponent={cargandoMas ? (
            <View style={{ paddingVertical: 14 }}><ActivityIndicator color={BLUE} /></View>
          ) : null}
        />
      )}

      {/* Pie: marcar todas como leídas (mockup, botón azul) */}
      <View style={{ paddingHorizontal: 16, paddingTop: 10, paddingBottom: Math.max(12, insets.bottom) + 12, backgroundColor: theme.background }}>
        <TouchableOpacity
          onPress={marcarTodas}
          disabled={marcando || !quedanSinLeer}
          style={[st.botonLeidas, { opacity: marcando || !quedanSinLeer ? 0.5 : 1 }]}
        >
          {marcando ? <ActivityIndicator size="small" color="#fff" />
            : <Text style={st.botonLeidasTexto}>{L('Marcar como leídas', 'Mark all as read')}</Text>}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  pantalla: { flex: 1 },
  cabecera: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 56, paddingBottom: 12, borderBottomWidth: 1,
  },
  titulo: { fontSize: 18, fontWeight: '800' },
  item: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    paddingHorizontal: 16, paddingVertical: 16, borderBottomWidth: 1,
  },
  iconoCaja: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  puntoRojo: { position: 'absolute', top: -2, right: -2, width: 11, height: 11, borderRadius: 6, backgroundColor: '#E5384F', borderWidth: 1.5 },
  puntoChip: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#E5384F' },
  botonLeidas: {
    backgroundColor: BLUE, borderRadius: 14, paddingVertical: 15,
    alignItems: 'center', justifyContent: 'center',
  },
  botonLeidasTexto: { color: '#fff', fontWeight: '800', fontSize: 16 },
});
