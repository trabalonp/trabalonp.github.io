// screens/HomeScreen.js
// REDISEÑO VISUAL con animaciones (entrada escalonada, pulsación con muelle, campana
// que se agita, sync que gira, puntos elásticos…). La lógica (caché, sync con
// Intervals, deep links, notificaciones, fitness en vivo, colores por
// cumplimiento, modales de añadir/detalle) es la MISMA que antes.
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import * as Notifications from 'expo-notifications';
import { collection, doc, getDoc, getDocs, limit, onSnapshot, orderBy, query, setDoc, Timestamp, where } from 'firebase/firestore';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Animated, AppState, Easing, Image, PanResponder, Platform, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TouchableOpacity, View, useColorScheme } from 'react-native';
import { auth, db } from '../firebaseConfig';
import { getApiUrl } from '../services/api';
import { cacheProfile, getCachedProfile } from '../services/profileCache';
import * as chartCache from '../services/chartCache';
import { getThemeColors, useAppSettings, t, formatSubtitleItem, fmtHomeDate, fmtDistance } from '../services/appSettings';
import FitnessChart from '../components/FitnessChart';
import { consumePendingWorkoutId, subscribePendingWorkout, entregaYaHecha } from '../services/deepLink';
import WeeklyKmChart from '../components/WeeklyKmChart';
import AddWorkoutModal from './AddWorkoutModal';
import WorkoutDetailModal, { MOODS, MOOD_COLORS, CARGAS } from './WorkoutDetailModal';
import ActivityIcon from '../components/ActivityIcon';
import EsfuerzoBadge from '../components/EsfuerzoBadge';
import { complianceEntreno, ICONO_COMP } from '../services/compliance';
import { resolverPlanReal, useZonasRitmoPorTipo } from '../services/planReal';

const NAVY='#0D1B2A', CARD='#162032', BLUE='#4A90E2', RED='#E05252', BORDER='#1E3048';
// Candado GLOBAL de sincronización: evita que un mismo toque (o dos disparos
// casi simultáneos, p. ej. dos instancias de HomeScreen montadas) lance DOS
// peticiones /sync-intervals a la vez — era la causa de las notificaciones
// duplicadas de "se han sincronizado N entrenos".
let syncGlobalEnCurso = false;
const TIPO_ICON={ Ciclismo:'bicycle', Running:'run', Natación:'water', Fuerza:'barbell', Triatlón:'medal-outline', Otro:'flash', Evento:'trophy', Descanso:'moon', Notas:'journal-outline' };

function stripHeavyFields(d){ const { registros, vueltas, ...light }=d; return light; }
const asc=(l)=>[...l].sort((a,b)=>(a.fecha?.toMillis?.()??0)-(b.fecha?.toMillis?.()??0));
function lighten(hex, amount = 0.5) {
  const num = parseInt(hex.replace('#',''), 16);
  let r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
  r = Math.round(r + (255 - r) * amount); g = Math.round(g + (255 - g) * amount); b = Math.round(b + (255 - b) * amount);
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}
// Mezcla el color hacia el tono oscuro de las tarjetas (#162032): conserva
// el matiz del compliance pero baja mucho la luminosidad — a plena
// saturación el modo oscuro deslumbra de noche.
function apagar(hex, amount = 0.6) {
  const num = parseInt(hex.replace('#',''), 16);
  let r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
  r = Math.round(r + (0x16 - r) * amount); g = Math.round(g + (0x20 - g) * amount); b = Math.round(b + (0x32 - b) * amount);
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}
// Modo claro: se intercambian los tonos de la tarjeta: el fondo pasa al
// tono gris/claro de la línea fina decorativa, y la línea fina pasa al
// color que antes tenía el fondo. En modo oscuro el fondo y el acento van
// APAGADOS (mezcla hacia el tono oscuro), nunca a plena saturación.
// Tiempo compacto para las tarjetas: quita delante las unidades a cero
// ("01:05:30" → "1:05:30", "00:45:00" → "45:00", "00:00:30" → "30 s").
function fmtTiempoCorto(sec) {
  if (sec == null || !(sec > 0)) return '';
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = Math.floor(sec % 60);
  const p2 = (n) => String(n).padStart(2, '0');
  if (h > 0) return `${h}:${p2(m)}:${p2(s)}`;
  if (m > 0) return `${m}:${p2(s)}`;
  return `${s} s`;
}

function cardColors(color, isLight) {
  // Planificados (gris): la línea de decoración de arriba mucho más clara
  // para que se note sobre el recuadro (en oscuro era casi invisible).
  if (color === '#4A6080') {
    return isLight
      ? { bg: lighten(color, 0.78), accent: lighten(color, 0.6) }
      : { bg: apagar(color, 0.62), accent: lighten(color, 0.5) };
  }
  // Colores de cumplimiento: en claro, color reducido mezclando hacia BLANCO
  // (pastel claro, no oscuro); la línea de arriba se queda igual. En oscuro,
  // mezclado hacia el tono de la tarjeta (0.45): suave, sin saturación fuerte.
  if (isLight) return { bg: lighten(color, 0.65), accent: color };
  return { bg: apagar(color, 0.45), accent: lighten(color, 0.15) };
}


/* ════════════════════════════════════════════════════════════════════════════
   REDISEÑO VISUAL (solo capa visual; la lógica de Home no cambia)
   Componentes animados: entrada escalonada, pulsación con muelle, campana que
   se agita, sync que gira, halo del avatar, puntos del carrusel elásticos…
   ════════════════════════════════════════════════════════════════════════════ */
const AMBER_H = '#F5A623';

// Aparece con fundido + deslizamiento (vertical u horizontal)
function FadeIn({ delay = 0, children, style, from = 'y' }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, { toValue: 1, duration: 420, delay, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [v, delay]);
  const t = from === 'x'
    ? { translateX: v.interpolate({ inputRange: [0, 1], outputRange: [26, 0] }) }
    : { translateY: v.interpolate({ inputRange: [0, 1], outputRange: [16, 0] }) };
  return <Animated.View style={[style, { opacity: v, transform: [t] }]}>{children}</Animated.View>;
}

// Zona pulsable con efecto muelle
function Press({ onPress, disabled, style, children, hitSlop }) {
  const sc = useRef(new Animated.Value(1)).current;
  const to = (v) => Animated.spring(sc, { toValue: v, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <Pressable onPress={onPress} disabled={disabled} hitSlop={hitSlop} onPressIn={() => to(0.96)} onPressOut={() => to(1)}>
      <Animated.View style={[style, { transform: [{ scale: sc }] }]}>{children}</Animated.View>
    </Pressable>
  );
}

function useLoop(duration, active = true) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!active) { v.setValue(0); return undefined; }
    const loop = Animated.loop(Animated.timing(v, { toValue: 1, duration, easing: Easing.linear, useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [v, duration, active]);
  return v;
}
function usePingPong(duration) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(v, { toValue: 1, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [v, duration]);
  return v;
}

// Halo suave alrededor del avatar
function AvatarHalo() {
  const v = useLoop(2800);
  return (
    <Animated.View pointerEvents="none" style={{
      position: 'absolute', width: 44, height: 44, borderRadius: 22, borderWidth: 2, borderColor: BLUE,
      opacity: v.interpolate({ inputRange: [0, 1], outputRange: [0.45, 0] }),
      transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [1, 1.5] }) }],
    }} />
  );
}

// Icono de sincronizar: gira mientras se sincroniza
function SyncIcon({ spinning }) {
  const v = useLoop(900, spinning);
  return (
    <Animated.View style={{ transform: [{ rotate: v.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] }) }] }}>
      <Ionicons name="sync-outline" size={22} color={BLUE} />
    </Animated.View>
  );
}

// Campana: se agita de vez en cuando si hay notificaciones sin leer
function BellIcon({ count }) {
  const rot = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!(count > 0)) { rot.setValue(0); return undefined; }
    const s = (to) => Animated.timing(rot, { toValue: to, duration: 90, useNativeDriver: true });
    const loop = Animated.loop(Animated.sequence([s(1), s(-1), s(0.7), s(-0.7), s(0), Animated.delay(3200)]));
    loop.start();
    return () => loop.stop();
  }, [count, rot]);
  return (
    <Animated.View style={{ transform: [{ rotate: rot.interpolate({ inputRange: [-1, 1], outputRange: ['-18deg', '18deg'] }) }] }}>
      <Ionicons name={count > 0 ? 'notifications' : 'notifications-outline'} size={22} color={BLUE} />
    </Animated.View>
  );
}

// Icono que flota suavemente
function FloatIcon({ name, size, color, style }) {
  const v = usePingPong(2200);
  return (
    <Animated.View style={[style, { transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [4, -4] }) }] }]}>
      <Ionicons name={name} size={size} color={color} />
    </Animated.View>
  );
}

// Puntos del carrusel: el activo se alarga con un muelle
function Dot({ active }) {
  const v = useRef(new Animated.Value(active ? 1 : 0)).current;
  useEffect(() => { Animated.spring(v, { toValue: active ? 1 : 0, useNativeDriver: false, speed: 18, bounciness: 8 }).start(); }, [active, v]);
  return (
    <Animated.View style={{
      height: 8, borderRadius: 4,
      width: v.interpolate({ inputRange: [0, 1], outputRange: [8, 22] }),
      backgroundColor: v.interpolate({ inputRange: [0, 1], outputRange: ['#2A4060', BLUE] }),
    }} />
  );
}
function Dots({ page }) {
  return <View style={styles.dotsRow}>{[0, 1, 2].map((i) => <Dot key={i} active={page === i} />)}</View>;
}

// Pantalla de carga: barras que suben y bajan
function BarraHome({ delay }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.delay(delay),
      Animated.timing(v, { toValue: 1, duration: 450, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration: 450, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [v, delay]);
  return <Animated.View style={{ width: 10, height: 48, borderRadius: 5, backgroundColor: BLUE, transform: [{ scaleY: v.interpolate({ inputRange: [0, 1], outputRange: [0.3, 1] }) }] }} />;
}
function CargaHome() {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 7, height: 48 }}>
      {[0, 1, 2, 3, 4].map((i) => <BarraHome key={i} delay={i * 120} />)}
    </View>
  );
}

export default function HomeScreen({ route }) {
  const user=auth.currentUser;
  const navigation=useNavigation();
  const appSettings = useAppSettings(); // re-renderiza al cambiar idioma/unidades/fecha/tema
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const [athleteId,setAthleteId]=useState(null);
  const [athleteName,setAthleteName]=useState(null);
  const currentUserId=athleteId||user?.uid;
  const [entrenamientos,setEntrenamientos]=useState(() => chartCache.getEntrenamientos(auth.currentUser?.uid) || []);
  const [wellness,setWellness]=useState(() => chartCache.getWellness(auth.currentUser?.uid) || {});
  const [loading,setLoading]=useState(!(chartCache.getEntrenamientos(auth.currentUser?.uid)));
  const [refreshing,setRefreshing]=useState(false);
  const [syncing,setSyncing]=useState(false);
  const [notificacionesSinLeer,setNotificacionesSinLeer]=useState(0);
  const [modalVisible,setModalVisible]=useState(false);
  const [detailModalVisible,setDetailModalVisible]=useState(false);
  const [selectedWorkout,setSelectedWorkout]=useState(null);
  const [deepLinkAthleteId,setDeepLinkAthleteId]=useState(null);

  // Deep link de notificaciones: si hay un workoutId pendiente (push tocado),
  // carga ese entreno y abre su modal de detalle. Suscrito también por si el
  // push llega con la app ya abierta en otra pestaña.
  useEffect(() => {
    try {
      const abrirFicha = (id, tries = 2, contextAthleteId = null) => {
        getDoc(doc(db, 'entrenamientos', id)).then((s) => {
          if (s.exists()) {
            console.log('[deeplink] abriendo ficha del entreno', id);
            const data = s.data();
            setDeepLinkAthleteId(contextAthleteId || data.userId || null);
            setSelectedWorkout({ id: s.id, ...data });
            setDetailModalVisible(true);
          } else {
            console.warn('[deeplink] el entreno ya no existe:', id);
          }
        }).catch((e) => {
          // reintento por si la sesión/auth aún estaba asentándose al tocar el push
          console.warn('[deeplink] getDoc falló, reintento:', e.message);
          if (tries > 0) setTimeout(() => abrirFicha(id, tries - 1, contextAthleteId), 1000);
        });
      };
      const open = (payload) => {
        // payload = { workoutId, athleteId } (services/deepLink.js)
        const id = payload?.workoutId;
        const contextAthleteId = payload?.athleteId || null;
        if (!id) return;
        // Guarda COMPARTIDA entre montajes (deepLink): el mismo toque llega
        // por varios caminos y un remount de HomeScreen no debe reabrirlo.
        if (entregaYaHecha(id)) {
          console.log('[deeplink] apertura duplicada ignorada', id);
          return;
        }
        abrirFicha(id, 2, contextAthleteId);
      };
      const un = subscribePendingWorkout(open);
      const id0 = consumePendingWorkoutId();
      if (id0) open(id0);
      return un;
    } catch (e) {
      return undefined;
    }
  }, []);
  const [profile,setProfile]=useState(null);
  const [fitnessDays,setFitnessDays]=useState([]);
  const fitUnsub=useRef(null);   // listener en vivo del doc fitness/{uid}
  const [homePage,setHomePage]=useState(0);
  const appState=useRef(AppState.currentState);

  // Solo escucha la subcolección del usuario actual y cuenta las no leídas;
  // el historial completo se pagina únicamente dentro de NotificacionesScreen.
  useEffect(()=>{
    // La campana es SIEMPRE del usuario logueado (también en vista de
    // atleta): el historial que abre es el suyo propio.
    const uidNotif=user?.uid;
    if(!uidNotif){ setNotificacionesSinLeer(0); return undefined; }
    const q=query(collection(db,'perfiles',uidNotif,'notificaciones'), where('leido','==',false), limit(100));
    return onSnapshot(q,(snap)=>setNotificacionesSinLeer(snap.size),(error)=>console.warn('[home] contador de notificaciones:', error.message));
  },[user?.uid]);

  const pagerPan=useRef(PanResponder.create({
    onMoveShouldSetPanResponder:(e,gs)=>Math.abs(gs.dx)>14&&Math.abs(gs.dx)>Math.abs(gs.dy)*1.4,
    onPanResponderRelease:(e,gs)=>{ if(gs.dx<-40)setHomePage(p=>Math.min(2,p+1)); else if(gs.dx>40)setHomePage(p=>Math.max(0,p-1)); },
  })).current;

  useEffect(()=>{
    Notifications.setNotificationHandler({ handleNotification:async()=>({ shouldShowBanner:true, shouldShowList:true, shouldPlaySound:true, shouldSetBadge:false }) });
    Notifications.requestPermissionsAsync();
    if(Platform.OS==='android') Notifications.setNotificationChannelAsync('sync-channel',{ name:'Sincronización', importance:Notifications.AndroidImportance.HIGH });
    AsyncStorage.multiRemove(['garmin_email','garmin_password','garmin_days']).catch(()=>{});
  },[]);

  // ── PERFIL SIEMPRE CARGADO: caché instantánea + suscripción viva + backoff ──
  useEffect(()=>{
    const uid=currentUserId;
    if(!uid){ setProfile(null); return; }
    let cancelled=false;
    let unsub=null;
    let retryTimer=null;
    getCachedProfile(uid).then(c=>{ if(!cancelled&&c) setProfile(c); }).catch(()=>{});
    const subscribe=()=>{
      if(cancelled) return;
      unsub=onSnapshot(
        doc(db,'perfiles',uid),
        (snap)=>{
          if(cancelled) return;
          if(snap.exists()){
            const d=snap.data();
            setProfile(d);
            cacheProfile(uid,d).catch(()=>{});
          } else {
            setProfile(null);
          }
        },
        ()=>{
          if(cancelled) return;
          retryTimer=setTimeout(()=>{ if(!cancelled) subscribe(); }, 1500);
        }
      );
    };
    subscribe();
    return ()=>{
      cancelled=true;
      if(retryTimer) clearTimeout(retryTimer);
      if(unsub) unsub();
    };
  },[currentUserId]);

  const refreshProfile=useCallback(async(uid)=>{
    if(!uid)return;
    for(let i=0;i<3;i++){
      try{
        const snap=await getDoc(doc(db,'perfiles',uid));
        if(snap.exists()){
          const d=snap.data();
          setProfile(d);
          cacheProfile(uid,d).catch(()=>{});
        } else {
          setProfile(null);
        }
        return;
      }catch(e){
        if(i<2) await new Promise(r=>setTimeout(r, 700*(i+1)));
      }
    }
  },[]);

  const refreshAthleteContext=useCallback(async()=>{
    const id=await AsyncStorage.getItem('currentAthleteId');
    setAthleteId(id);
    const n=await AsyncStorage.getItem('currentAthleteName');
    setAthleteName(n);
  },[]);

  useFocusEffect(useCallback(()=>{
    let active=true;
    (async()=>{
      await refreshAthleteContext();
      if(!active)return;
      refreshProfile(currentUserId);
      fetchData();
      fetchWellness();
    })();
    return ()=>{ active=false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[currentUserId, refreshProfile, refreshAthleteContext]));

  useEffect(()=>{
    const sub=AppState.addEventListener('change',(next)=>{
      if(next==='active' && appState.current!=='active'){
        (async()=>{
          await refreshAthleteContext();
          refreshProfile(currentUserId);
          chartCache.bumpRefresh();
          fetchData();
          fetchWellness();
        })();
      }
      appState.current=next;
    });
    return ()=>sub.remove();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[currentUserId, refreshProfile, refreshAthleteContext]);

  const fetchData=useCallback(async()=>{
    if(!currentUserId)return;
    const cached=chartCache.getEntrenamientos(currentUserId);
    if(cached){ setEntrenamientos(cached); setLoading(false); setRefreshing(false); return; }
    try{
      const now=new Date(); const start=new Date(now); start.setDate(now.getDate()-30); start.setHours(0,0,0,0);
      const end=new Date(now); end.setDate(now.getDate()+30); end.setHours(23,59,59,999);
      const q=query(collection(db,'entrenamientos'), where('userId','==',currentUserId), where('fecha','>=',Timestamp.fromDate(start)), where('fecha','<=',Timestamp.fromDate(end)), orderBy('fecha','desc'));
      const snap=await getDocs(q);
      const lista=snap.docs.map(d=>({ id:d.id, ...stripHeavyFields(d.data()) }));
      try {
        // array-contains SIN rango de fechas: usa el indice automatico de un solo campo
        // (NO necesita indice compuesto en Firebase). El rango +/-30 dias se filtra en local.
        const q2=query(collection(db,'entrenamientos'), where('asignados','array-contains',currentUserId));
        const s2=await getDocs(q2);
        s2.docs.forEach(d=>{ const data=d.data(); const f=data.fecha?.toMillis?.() ?? null; if(f!=null && f>=start.getTime() && f<=end.getTime() && !lista.some(x=>x.id===d.id)) lista.push({ id:d.id, ...stripHeavyFields(data) }); });
      } catch(e){ console.log('Error eventos asignados:', e?.message || e); }
      // ── Duración del recuadro = Σ de las vueltas ──
      // Mismo número que la fila Σ del apartado Vueltas (las vueltas descartan
      // los tramos con la sesión parada que el reloj cuenta en elapsed). La
      // `duracion` del doc principal puede llegar inflada hasta que el sync la
      // realinee: para los realizados se lee detalles/data y se muestra esa
      // suma exacta. Sin vueltas o sin detalle se respeta la duración guardada.
      try{
        const hechos=lista.filter(x=>x.estado==='completo');
        for(let i=0;i<hechos.length;i+=10){
          const lote=hechos.slice(i,i+10);
          const dets=await Promise.all(lote.map(x=>getDoc(doc(db,'entrenamientos',x.id,'detalles','data')).catch(()=>null)));
          dets.forEach((ds,k)=>{ if(!ds||!ds.exists)return; const vs=ds.data().vueltas; if(Array.isArray(vs)&&vs.length){ const suma=Math.round(vs.reduce((a,v)=>a+(Number(v&&v.tiempo)||0),0)); if(suma>0 && !lote[k].duracionManual) lote[k].duracion=suma; } });
        }
      }catch(e){ console.log('[home] alineando duración con Σ vueltas:', e?.message||e); }
      chartCache.setEntrenamientos(currentUserId, lista);
      setEntrenamientos(lista);
    }catch(e){} finally { setLoading(false); setRefreshing(false); }
  },[currentUserId]);

  const fetchWellness=useCallback(async()=>{
    if(!currentUserId)return;
    const cached=chartCache.getWellness(currentUserId);
    if(cached){ setWellness(cached); return; }
    try{
      const s=await getDoc(doc(db,'wellness',currentUserId));
      const days=s.exists?(s.data().days||{}):{};
      chartCache.setWellness(currentUserId, days);
      setWellness(days);
    }catch(e){}
  },[currentUserId]);

  /* GRÁFICA DE RENDIMIENTO local-first (patrón chat de Social):
     1) Los días viven en caché local (AsyncStorage por usuario) → la gráfica
        se pinta AL INSTANTE al entrar, sin red.
     2) Listener EN VIVO sobre el doc fitness/{uid}: 1 lectura al montar y
        después SOLO deltas cuando el servidor recalcula el fitness.
     3) Los tres valores (Fatiga/Condición/Forma) salen del dato vivo del
        listener, nunca de una copia vieja. */
  const fetchFitness=useCallback(async(mode)=>{
    const uid=currentUserId; if(!uid)return;
    // 1) Caché local al instante
    try{
      const raw=await AsyncStorage.getItem(`tj_fitness_days_v1_${uid}`);
      if(raw){ const arr=JSON.parse(raw); if(Array.isArray(arr)&&arr.length) setFitnessDays(arr); }
    }catch(e){}
    // 2) Listener en vivo: 1 lectura al montar, luego solo deltas
    try{
      if(fitUnsub.current){ fitUnsub.current(); fitUnsub.current=null; }
      fitUnsub.current=onSnapshot(doc(db,'fitness',uid),(snap)=>{
        if(!snap.exists())return;
        const days=snap.data().days??[];
        setFitnessDays((prev)=>{
          if(JSON.stringify(prev)===JSON.stringify(days)) return prev;   // sin cambios: ni render ni escritura
          try{ AsyncStorage.setItem(`tj_fitness_days_v1_${uid}`, JSON.stringify(days)); }catch(e){}
          return days;
        });
      },(e)=>console.warn('[fitness] listener:',e.message));
    }catch(e){}
    // 3) 'force' (tras una sync): pide al servidor el recálculo del fitness
    if(mode==='force'){
      try{
        const conn=await getDoc(doc(db,'intervals_connections',uid)); if(!conn.exists())return;
        const apiUrl=(await getApiUrl()).replace(/\/+$/,''); const token=await user.getIdToken();
        const r=await fetch(`${apiUrl}/sync-fitness`,{ method:'POST', headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`} });
        if(r.ok){ const s2=await getDoc(doc(db,'fitness',uid)); if(s2.exists()) setFitnessDays(s2.data().days??[]); }
      }catch(e){}
    }
  },[currentUserId]);

  useEffect(()=>{ fetchFitness(); return ()=>{ if(fitUnsub.current){ fitUnsub.current(); fitUnsub.current=null; } }; },[fetchFitness]);

  const handleRefresh=useCallback(()=>{
    setRefreshing(true);
    chartCache.bumpRefresh();
    fetchData();
    fetchWellness();
    refreshProfile(currentUserId);   // el fitness se actualiza solo vía listener
  },[fetchData, fetchWellness, fetchFitness, refreshProfile, currentUserId]);

  const handleSync=async()=>{
    if(syncing||athleteId)return;
    if(syncGlobalEnCurso)return;   // ya hay una sync en marcha (candado global)
    syncGlobalEnCurso=true;
    setSyncing(true);
    try{
      const apiUrl=(await getApiUrl()).replace(/\/+$/,''); const token=await user.getIdToken();
      const now=new Date(); const ago=new Date(now); ago.setDate(now.getDate()-30);
      const oldest=ago.toISOString().split('T')[0]; const newest=now.toISOString().split('T')[0];
      const controller=new AbortController(); const timeout=setTimeout(()=>controller.abort(),120000);
      const res=await fetch(`${apiUrl}/sync-intervals`,{ method:'POST', headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`}, body:JSON.stringify({ oldest, newest }), signal:controller.signal });
      clearTimeout(timeout);
      if(res.status===400){ const data=await res.json().catch(()=>({})); if(data.error==='Intervals.icu no conectado'){ Alert.alert('Intervals.icu no conectado','Conecta tu cuenta de Intervals.icu antes de sincronizar.',[{text:'Cancelar',style:'cancel'},{text:'Conectar',onPress:()=>navigation.navigate('SyncSettings')}]); return; } throw new Error(data.error||'Error en la sincronización'); }
      if(res.status===401){ Alert.alert('Sesión expirada','Vuelve a iniciar sesión en la aplicación.'); return; }
      if(!res.ok){ const errData=await res.json().catch(()=>({})); throw new Error(errData.error||'Error del servidor'); }
      chartCache.bumpRefresh();
      fetchData(); fetchWellness(); fetchFitness('force');
    }catch(err){
      if(err.name==='AbortError') Alert.alert('Tiempo agotado','La sincronización tardó demasiado. Inténtalo de nuevo.');
      else Alert.alert('Error', err.message);
    } finally { setSyncing(false); syncGlobalEnCurso=false; }
  };

  const handleDataChanged=useCallback(()=>{
    chartCache.bumpRefresh();
    fetchData();
    fetchWellness();
  },[fetchData, fetchWellness]);

  const today=new Date(); const tomorrow=new Date(today); tomorrow.setDate(tomorrow.getDate()+1);
  const todayEntrenamientos=asc(entrenamientos.filter(e=>{ if(!e.fecha)return false; const d=e.fecha.toDate?e.fecha.toDate():new Date(e.fecha); return d.toDateString()===today.toDateString()&&e.tipo!=='Evento'; }));
  const tomorrowEntrenamientos=asc(entrenamientos.filter(e=>{ if(!e.fecha)return false; const d=e.fecha.toDate?e.fecha.toDate():new Date(e.fecha); return d.toDateString()===tomorrow.toDateString()&&e.tipo!=='Evento'; }));
  const proximosEventos=asc(entrenamientos.filter(e=>{ if(!e.fecha)return false; const d=e.fecha.toDate?e.fecha.toDate():new Date(e.fecha); return e.tipo==='Evento'&&d>=today; })).slice(0,5);
  // Días que faltan para el próximo evento (para el título de la sección)
  const diasEvento=(()=>{ if(!proximosEventos.length) return ''; const f=proximosEventos[0].fecha; const fd=f?.toDate?f.toDate():new Date(f); const a=new Date(); a.setHours(0,0,0,0); const b=new Date(fd); b.setHours(0,0,0,0); const d=Math.round((b-a)/86400000); if(d<=0) return t('common.today'); const en=appSettings.language==='en'; return `${d} ${d===1?(en?'day':'día'):(en?'days':'días')}`; })();

  // Zonas de ritmo del atleta que se está viendo: permiten estimar los km de
  // los pasos "Zona ritmo" cuando el doc fusionado vino sin planDist.
  const zonasDe=useZonasRitmoPorTipo(currentUserId);
  // Color por CUMPLIMIENTO (verde/amarillo/naranja/rojo/gris) — compliance.js
  const getWorkoutColor=(e)=>complianceEntreno(e, new Date(), resolverPlanReal(e, zonasDe(e.tipo))).color;
  const profilePhoto=profile?.foto;
  const firstName=profile?.nombre?.trim().split(' ')[0]||athleteName||user?.displayName||'Atleta';
  const initial=firstName.charAt(0).toUpperCase();
  const hoy=fmtHomeDate(new Date()); // respeta idioma + formato de fecha elegidos

  if(loading)return(<View style={[styles.splash, { backgroundColor: theme.background }]}><CargaHome /></View>);

  return (
    <>
      <ScrollView style={[styles.container, { backgroundColor: theme.background }]} contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={BLUE} />}
        showsVerticalScrollIndicator={false}>
        <FadeIn>
        <View style={[styles.header, { backgroundColor: theme.background }]}>
          <View style={styles.avatarWrap}>
            <AvatarHalo />
            <View style={styles.avatar}>
              {profilePhoto?(<Image source={{ uri:`data:image/jpeg;base64,${profilePhoto}` }} style={styles.avatarImg} />):(<Text style={styles.avatarInitial}>{initial}</Text>)}
            </View>
          </View>
          <View style={{flex:1}}>
            <Text style={[styles.userName, { color: theme.text }]}>{athleteName||firstName}</Text>
            <Text style={[styles.userDate, { color: theme.muted }]}>{hoy}</Text>
          </View>
          {/* La campana SIEMPRE en el mismo sitio (derecha); el botón que
              cambia de sitio es la rueda de sync / volver del atleta */}
          {!athleteId&&(
              <Press style={[styles.syncBtn, syncing&&styles.syncBtnActive, { backgroundColor: theme.card, borderColor: syncing ? BLUE : theme.border }]} onPress={handleSync} disabled={syncing}>
              <SyncIcon spinning={syncing} />
            </Press>
          )}
          {athleteId&&(
            <Press style={[styles.backToMeBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={async()=>{ await AsyncStorage.removeItem('currentAthleteId'); await AsyncStorage.removeItem('currentAthleteName'); setAthleteId(null); setAthleteName(null); }}>
              <Ionicons name="person-outline" size={22} color={BLUE} />
            </Press>
          )}
          <Press style={[styles.notificationBtn, { backgroundColor: theme.card, borderColor: notificacionesSinLeer>0 ? BLUE+'88' : theme.border }]} onPress={()=>navigation.navigate('Notificaciones')}>
            <BellIcon count={notificacionesSinLeer} />
            {notificacionesSinLeer>0&&<View style={styles.notificationBadge}><Text style={styles.notificationBadgeText}>{notificacionesSinLeer>99?'99+':notificacionesSinLeer}</Text></View>}
          </Press>
        </View>
        </FadeIn>

        {syncing&&(
          <FadeIn><View style={[styles.syncBanner, { backgroundColor: theme.card, borderColor: BLUE }]}> 
            <ActivityIndicator size="small" color={BLUE} style={{marginRight:8}} />
            <Text style={styles.syncBannerText} numberOfLines={1}>{t('home.syncing')}</Text>
          </View></FadeIn>
        )}

        <View {...pagerPan.panHandlers} style={{ backgroundColor: theme.background }}>
          <FadeIn key={`pg-${homePage}`} from="x">
          {homePage===0&&( fitnessDays.length>1?(<FitnessChart key={`fitness-${theme.background}`} days={fitnessDays} theme={theme} />):(
            <View style={[styles.bannerCard, { backgroundColor: theme.card, borderColor: theme.border }] }>
              <FloatIcon name="trending-up" size={48} color={BLUE} style={{marginBottom:8}} />
              <Text style={[styles.bannerTitle, { color: theme.text }]}>{t('home.bannerTitle')}</Text>
              <Text style={[styles.bannerSub, { color: theme.muted }]}>{t('home.bannerSub')}</Text>
            </View>
          ))}
          {homePage===1&&(<WeeklyKmChart key={`weekly-0-${theme.background}`} entrenamientos={entrenamientos} wellness={wellness} weekOffset={0} userId={currentUserId} theme={theme} />)}
          {homePage===2&&(<WeeklyKmChart key={`weekly-1-${theme.background}`} entrenamientos={entrenamientos} wellness={wellness} weekOffset={1} userId={currentUserId} theme={theme} />)}
          </FadeIn>
          <Dots page={homePage} />
        </View>

        <Section title={t('home.today')} onAdd={()=>setModalVisible(true)}>
          {todayEntrenamientos.length>0?todayEntrenamientos.map(e=>(
            <WorkoutRow key={e.id} item={e} color={getWorkoutColor(e)} zonasDe={zonasDe} onPress={()=>{ setSelectedWorkout(e); setDetailModalVisible(true); }} />
          )):(<EmptyCard icon="add-circle-outline" text={t('home.emptyToday')} />)}
        </Section>
        {tomorrowEntrenamientos.length>0&&(
          <Section title={t('home.tomorrow')}>
            {tomorrowEntrenamientos.map(e=>(<WorkoutRow key={e.id} item={e} color={getWorkoutColor(e)} zonasDe={zonasDe} onPress={()=>{ setSelectedWorkout(e); setDetailModalVisible(true); }} />))}
          </Section>
        )}
        {proximosEventos.length>0&&(
          <Section title={`${t('home.upcoming')} · ${diasEvento}`}>
            {proximosEventos.map(e=>(<WorkoutRow key={e.id} item={e} color={getWorkoutColor(e)} zonasDe={zonasDe} onPress={()=>{ setSelectedWorkout(e); setDetailModalVisible(true); }} />))}
          </Section>
        )}
      </ScrollView>

      <AddWorkoutModal visible={modalVisible} onClose={()=>setModalVisible(false)} onWorkoutAdded={handleDataChanged} initialDate={new Date()} athleteId={athleteId} />
      <WorkoutDetailModal key={selectedWorkout?.id || 'cerrado'} visible={detailModalVisible} workout={selectedWorkout} onClose={()=>{ setDetailModalVisible(false); setSelectedWorkout(null); setDeepLinkAthleteId(null); }} onWorkoutUpdated={handleDataChanged} athleteId={deepLinkAthleteId || athleteId} />
    </>
  );
}

function Section({ title, onAdd, children }){
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  return (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <View style={styles.sectionBar} />
        <Text style={[styles.sectionTitle, { color: theme.text }]} numberOfLines={1}>{title}</Text>
        <View style={[styles.sectionLine, { backgroundColor: theme.border }]} />
        {onAdd&&(
          <Press style={styles.addBtn} onPress={onAdd}>
            <Ionicons name="add" size={16} color="#fff" />
            <Text style={styles.addBtnText}>{t('home.add')}</Text>
          </Press>
        )}
      </View>
      {React.Children.map(children, (child, i) => (child ? <FadeIn delay={Math.min(i * 70, 420)}>{child}</FadeIn> : null))}
    </View>
  );
}

function WorkoutRow({ item, color, onPress, zonasDe }){
  const subtitle=formatSubtitleItem(item);
  const settings=useAppSettings();
  const theme=getThemeColors(settings.themeMode, useColorScheme());
  const isLight=theme.background==='#F4F7FB';
  const pal=cardColors(color, isLight);
  const esfuerzo=Math.round(Number(item.esfuerzo ?? item.tss) || 0); // TSS del entreno sincronizado
  // Realizado: comparativa con lo planificado. El plan se RESUELVE (no se lee
  // a pelo): planDist/planDur del doc fusionado y, si faltan —fusiones
  // antiguas, pasos por zona de ritmo—, la medida del planificado o el
  // recálculo desde los pasos (services/planReal.js). Así la distancia sale
  // SIEMPRE con su comparativa, igual que ya pasaba con el tiempo.
  const esRealizado=item.estado==='completo';
  const zonasRitmo=zonasDe?zonasDe(item.tipo):null;
  const plan=resolverPlanReal(item, zonasRitmo);
  const planDurTxt=esRealizado&&Number(plan.dur)>0?fmtTiempoCorto(Number(plan.dur)):null;
  const planDistTxt=esRealizado&&Number(plan.dist)>0?fmtDistance(Number(plan.dist)):null;
  const fcMedia=Number(item['fc-media'])||0;
  // Cumplimiento: icono ✅/⬆️/⬇️/❌ coloreado en el pie (los sincronizados
  // sin plan enlazado no llevan nada) + icono de actividad al mismo color.
  // Se le pasa el plan ya resuelto para que la flecha mida contra la DISTANCIA
  // cuando la hay (antes medía contra el tiempo si faltaba planDist).
  const comp=complianceEntreno(item, new Date(), plan);
  const iconoComp=ICONO_COMP[comp.kind];
  // Carita de sensaciones + nº de carga percibida (1-5, "Alta"=4), igual
  // que en la tarjeta del calendario; vive en el doc principal.
  const sensIdx=item.sensacion!=null?Math.round(Number(item.sensacion)):null;
  const sensOk=sensIdx!=null&&sensIdx>=0&&sensIdx<=4&&!!MOODS[sensIdx];
  const cargaIx=CARGAS.indexOf(item.cargaPercibida);
  const cargaNum=cargaIx>=0?cargaIx+1:null;
  const hasFooter=!!iconoComp || esfuerzo>0 || !!item.tieneComentarios || sensOk || cargaNum!=null;
  return (
    <Press style={[styles.workoutCard, { backgroundColor: pal.bg }]} onPress={onPress}>
      <View style={[styles.cardAccent, { backgroundColor: pal.accent }]} />
      <View style={[styles.cardBody, hasFooter&&styles.cardBodyWithFooter]}>
        <View style={styles.iconChip}><ActivityIcon tipo={item.tipo} size={18} color={comp.kind ? comp.color : undefined} /></View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.workoutTitle, isLight && { color: theme.text }]}>{item.titulo || item.tipo}</Text>
          {item.tipo === 'Evento' && item.fecha ? (() => {
            const d = item.fecha.toDate ? item.fecha.toDate() : new Date(item.fecha);
            const p2 = (n) => String(n).padStart(2, '0');
            return <Text style={[styles.metaText, isLight && { color: theme.muted }, { fontWeight: '700' }]}>{`${p2(d.getDate())}/${p2(d.getMonth() + 1)}/${d.getFullYear()}`}</Text>;
          })() : null}
          {esRealizado ? (
            /* Realizado: tiempo/km apilados como realizado/planeado; FC sin comparativa.
               En claro, gris claro para los datos. */
            <View style={{ marginTop: 2, gap: 1 }}>
              {Number(item.duracion) > 0 && (
                <Text style={[styles.metaText, isLight && { color: '#8A98AB' }]}>
                  {planDurTxt ? `${fmtTiempoCorto(Number(item.duracion))} / ${planDurTxt}` : fmtTiempoCorto(Number(item.duracion))}
                </Text>
              )}
              {item.distancia != null && Number(item.distancia) > 0 && (
                <Text style={[styles.metaText, isLight && { color: '#8A98AB' }]}>
                  {planDistTxt ? `${fmtDistance(Number(item.distancia))} / ${planDistTxt}` : fmtDistance(Number(item.distancia))}
                </Text>
              )}
              {fcMedia > 0 && (
                <Text style={[styles.metaText, isLight && { color: '#8A98AB' }]}>{fcMedia} {settings.language === 'en' ? 'bpm' : 'ppm'}</Text>
              )}
            </View>
          ) : subtitle ? <Text style={[styles.metaText, isLight && { color: theme.muted }]}>{subtitle}</Text> : null}
        </View>
      </View>
      {hasFooter && (
        <View style={styles.cardFooter}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            {/* Flechas de cumplimiento (▲/▼) blancas también en claro */}
            {iconoComp ? <Ionicons name={iconoComp} size={19} color={iconoComp.startsWith('arrow') ? '#fff' : (isLight ? comp.color : '#fff')} /> : <View />}
            {!!item.tieneComentarios && <Ionicons name="chatbubble-ellipses" size={14} color={isLight ? '#4A6080' : '#C8D4E4'} />}
            {(sensOk || cargaNum != null) && (() => {
              const mc = sensOk ? (MOOD_COLORS[sensIdx] || '#8FA8C8') : (isLight ? '#4A6080' : '#C8D4E4');
              // En claro la píldora va sólida y el número en blanco: con el
              // tinte del mismo color no se leía.
              return (
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: isLight ? mc : mc + '26', borderRadius: 999, paddingHorizontal: 6, paddingVertical: 1 }}>
                  {sensOk && <Text style={{ fontSize: 12, lineHeight: 15 }}>{Platform.OS === 'ios' ? `${MOODS[sensIdx]}\uFE0E` : MOODS[sensIdx]}</Text>}
                  {cargaNum != null && <Text style={{ color: isLight ? '#fff' : mc, fontSize: 11, fontWeight: '800' }}>{cargaNum}</Text>}
                </View>
              );
            })()}
          </View>
          <EsfuerzoBadge value={esfuerzo} />
        </View>
      )}
    </Press>
  );
}

function EmptyCard({ icon, text }){
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  return (<View style={[styles.emptyCard, { backgroundColor: theme.card, borderColor: theme.border }]}><FloatIcon name={icon} size={30} color={theme.muted} /><Text style={[styles.emptyCardText, { color: theme.muted }]}>{text}</Text></View>);
}

const styles=StyleSheet.create({
  avatarWrap:{width:44,height:44,alignItems:'center',justifyContent:'center'},
  sectionBar:{width:4,height:18,borderRadius:2,backgroundColor:BLUE},
  sectionLine:{flex:1,height:1},
  container:{flex:1,backgroundColor:NAVY}, content:{paddingBottom:32},
  splash:{flex:1,backgroundColor:NAVY,alignItems:'center',justifyContent:'center'},
  header:{flexDirection:'row',alignItems:'center',paddingHorizontal:16,paddingTop:56,paddingBottom:16,gap:12},
  avatar:{width:44,height:44,borderRadius:22,backgroundColor:BLUE,alignItems:'center',justifyContent:'center',overflow:'hidden'},
  avatarImg:{width:44,height:44}, avatarInitial:{color:'#fff',fontSize:18,fontWeight:'800'},
  userName:{color:'#fff',fontSize:16,fontWeight:'700'},
  userDate:{color:'#8FA8C8',fontSize:13,marginTop:2,lineHeight:18},
  syncBtn:{width:42,height:42,borderRadius:21,backgroundColor:'#0A1828',borderWidth:1,borderColor:BORDER,alignItems:'center',justifyContent:'center'},
  notificationBtn:{width:42,height:42,borderRadius:21,backgroundColor:'#0A1828',borderWidth:1,borderColor:BORDER,alignItems:'center',justifyContent:'center'},
  notificationBadge:{position:'absolute',right:-3,top:-3,minWidth:18,height:18,paddingHorizontal:4,borderRadius:9,backgroundColor:RED,alignItems:'center',justifyContent:'center',borderWidth:2,borderColor:NAVY},
  notificationBadgeText:{color:'#fff',fontSize:9,fontWeight:'800'},
  syncBtnActive:{borderColor:BLUE,backgroundColor:'#0D2040'},
  backToMeBtn:{width:42,height:42,borderRadius:21,backgroundColor:'#0A1828',borderWidth:1,borderColor:BORDER,alignItems:'center',justifyContent:'center',marginRight:8},
  syncBanner:{flexDirection:'row',alignItems:'center',backgroundColor:'#0D2040',borderRadius:8,marginHorizontal:16,marginBottom:8,paddingHorizontal:14,paddingVertical:10,borderWidth:1,borderColor:BLUE},
  syncBannerText:{color:BLUE,fontSize:13,flex:1},
  bannerCard:{margin:16,backgroundColor:CARD,borderRadius:20,borderWidth:1,borderColor:BORDER,padding:20,alignItems:'center'},
  bannerTitle:{color:'#fff',fontSize:16,fontWeight:'700',textAlign:'center',marginBottom:8},
  bannerSub:{color:'#8FA8C8',fontSize:13,textAlign:'center',lineHeight:18},
  dotsRow:{flexDirection:'row',justifyContent:'center',gap:8,marginTop:4,marginBottom:8},
  dot:{width:8,height:8,borderRadius:4,backgroundColor:'#2A4060'}, dotActive:{backgroundColor:BLUE},
  section:{marginTop:4},
  sectionHeader:{flexDirection:'row',alignItems:'center',gap:10,paddingHorizontal:16,paddingTop:14,paddingBottom:4},
  sectionTitle:{color:'#fff',fontSize:15,fontWeight:'700'},
  addBtn:{flexDirection:'row',alignItems:'center',gap:3,backgroundColor:BLUE,borderRadius:999,paddingLeft:9,paddingRight:14,paddingVertical:6},
  addBtnText:{color:'#fff',fontSize:13,fontWeight:'800'},
  emptyCard:{margin:16,backgroundColor:CARD,borderRadius:18,borderWidth:1.5,borderStyle:'dashed',borderColor:BORDER,padding:24,alignItems:'center',gap:10},
  emptyCardText:{color:'#4A6080',fontSize:14,textAlign:'center'},
  workoutCard:{marginHorizontal:16,marginTop:8,borderRadius:16,overflow:'hidden'},
  cardAccent:{height:3,width:'100%'},
  cardBody:{flexDirection:'row',alignItems:'flex-start',padding:12,gap:10},
  cardBodyWithFooter:{paddingBottom:6},
  cardFooter:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:12,paddingBottom:10},
  cardIcon:{marginTop:1},
  iconChip:{width:30,height:30,borderRadius:15,backgroundColor:'#FFFFFF',alignItems:'center',justifyContent:'center'},
  workoutTitle:{color:'#fff',fontSize:13,fontWeight:'700'},
  metaText:{color:'#C3CDD9',fontSize:12,marginTop:3,fontWeight:'600'},
});