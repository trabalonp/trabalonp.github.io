// screens/CalendarScreen.js
// REDISEÑO VISUAL con animaciones (cabecera de semana, bloques de día y tarjetas con
// entrada escalonada, botones con muelle, punto de «hoy», FAB con rebote…). La lógica
// (caché, fetch, arrastrar y soltar con avisos al atleta, cumpleaños, métricas de
// wellness, modales) es la MISMA que antes: las tarjetas conservan su ref/PanResponder.
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import { collection, doc, getDoc, getDocs, orderBy, query, Timestamp, updateDoc, where } from 'firebase/firestore';
import {
  ActivityIndicator, Animated, Dimensions, Easing, PanResponder, Platform, Pressable, RefreshControl,
  ScrollView, StyleSheet, Text, TouchableOpacity, Vibration, View, useColorScheme,
} from 'react-native';
import { auth, db } from '../firebaseConfig';
import { getCoachFullName, sendNotificationToAthlete } from '../services/coachNotify';
import * as chartCache from '../services/chartCache';
import { getThemeColors, useAppSettings, formatSubtitleItem, fmtDistance } from '../services/appSettings';
import AddWorkoutModal from './AddWorkoutModal';
import WorkoutDetailModal, { MOODS, MOOD_COLORS, CARGAS } from './WorkoutDetailModal';
import ActivityIcon from '../components/ActivityIcon';
import MonthPickerModal from '../components/MonthPickerModal';
import EsfuerzoBadge from '../components/EsfuerzoBadge';
import { complianceEntreno, ICONO_COMP } from '../services/compliance';
import { resolverPlanReal, useZonasRitmoPorTipo } from '../services/planReal';
import { invalidarCurvasEntreno } from '../services/analyticsEngine';
import { marcarPendiente, quitarDigest } from '../services/curvasStore';

const NAVY='#0D1B2A', BLUE='#4A90E2', BORDER='#1E3048';
const SCREEN_H = Dimensions.get('window').height;
const IND_H = 44;
const HIDE_Y = -9999;

function getWeekDays(baseDate) {
  const date = new Date(baseDate);
  const day = date.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  const monday = new Date(date);
  monday.setDate(date.getDate() + diff);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    return d;
  });
}
function weekLabel(days, loc) {
  const from = days[0].toLocaleDateString(loc, { day: 'numeric', month: 'short' });
  const to   = days[6].toLocaleDateString(loc, { day: 'numeric', month: 'short' });
  return `${from} – ${to}`;
}
function getWeekKey(days) {
  return `${days[0].toISOString().split('T')[0]}_${days[6].toISOString().split('T')[0]}`;
}
function toKey(d) {
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`;
}
function fmtSleep(secs) {
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  return `${h}h ${m}m`;
}
function stripHeavyFields(data) {
  const { registros, vueltas, ...light } = data;
  return light;
}
function lighten(hex, amount = 0.5) {
  const num = parseInt(hex.replace('#',''), 16);
  let r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
  r = Math.round(r + (255 - r) * amount); g = Math.round(g + (255 - g) * amount); b = Math.round(b + (255 - b) * amount);
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}
// Mezcla el color hacia el tono oscuro de las tarjetas (#162032): conserva
// el matiz del compliance pero baja mucho la luminosidad — a plena
// saturación el modo oscuro deslumbra de noche.
function apagar(hex, amount = 0.6) {
  const num = parseInt(hex.replace('#',''), 16);
  let r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
  r = Math.round(r + (0x16 - r) * amount); g = Math.round(g + (0x20 - g) * amount); b = Math.round(b + (0x32 - b) * amount);
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}
// Modo claro: se intercambian los tonos de la tarjeta: el fondo pasa al
// tono gris/claro de la línea fina decorativa, y la línea fina pasa al
// color que antes tenía el fondo. En modo oscuro el fondo y el acento van
// APAGADOS (mezcla hacia el tono oscuro), nunca a plena saturación.
function cardColors(color, isLight) {
  // Planificados (gris): la línea de decoración de arriba mucho más clara
  // para que se note sobre el recuadro (en oscuro era casi invisible).
  if (color === '#4A6080') {
    return isLight
      ? { bg: lighten(color, 0.78), accent: lighten(color, 0.6) }
      : { bg: apagar(color, 0.62), accent: lighten(color, 0.5) };
  }
  // Colores de cumplimiento: en claro, color reducido mezclando hacia BLANCO
  // (pastel claro, no oscuro); la línea de arriba se queda igual. En oscuro,
  // mezclado hacia el tono de la tarjeta (0.45): suave, sin saturación fuerte.
  if (isLight) return { bg: lighten(color, 0.65), accent: color };
  return { bg: apagar(color, 0.45), accent: lighten(color, 0.15) };
}

/* Luminancia relativa (0 = negro, 1 = blanco) de un color hex. Se usa para
   que la medalla de récord se lea sobre CUALQUIER fondo de cumplimiento:
   el amarillo de "por encima/por debajo del plan" es #F5C518, el mismo oro
   de la medalla, y sobre ese fondo la medalla desaparecía. */
function luminancia(hex) {
  const num = parseInt(String(hex).replace('#', ''), 16);
  const r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
}
/* Oro oscuro (#8A6D00) sobre fondos claros (modo claro, tarjetas amarillas,
   naranjas o verdes pálidas) y oro brillante (#F5C518) sobre fondos
   apagados (modo oscuro). Ambos conservan el "aspecto medalla". */
const colorMedalla = (bg) => (luminancia(bg) > 0.55 ? '#8A6D00' : '#F5C518');

const TIPO_ICON = { Ciclismo:'bicycle', Running:'run', Natación:'water', Fuerza:'barbell', Triatlón:'medal-outline', Otro:'flash', Evento:'trophy', Descanso:'moon', Notas:'journal-outline' };

const _workoutCache = { uid: null, data: [], ts: 0 };
const CACHE_TTL_MS = 5 * 60 * 1000;

/* ── Perfil visual de un entreno planificado: una barra por paso, con la
      ALTURA según la intensidad (ritmo más rápido = más alto) y la ANCHURA
      según la duración (más largo = más ancho). Los bucles se expanden
      repitiendo su secuencia. Estilo TrainingPeaks. ── */
const INTENSIDAD_TIPO = { Calentamiento: 0.45, Extensivo: 0.6, Intensivo: 1, Variable: 0.75, Recuperación: 0.3, 'Entrenamiento tecnico': 0.6, Enfriarse: 0.35, Otro: 0.5 };
function paceSeg(v) {
  if (v == null || v === '') return null;
  const m = String(v).trim().match(/^(d+):(d{1,2})$/);
  if (m) { const seg = parseInt(m[1], 10) * 60 + parseInt(m[2], 10); return seg > 0 ? seg : null; }
  const n = Number(v); return Number.isFinite(n) && n > 0 ? n : null;
}
// Tiempo compacto para las tarjetas: quita delante las unidades a cero
// ("01:05:30" → "1:05:30", "00:45:00" → "45:00", "00:00:30" → "30 s").
function fmtTiempoCorto(sec) {
  if (sec == null || !(sec > 0)) return '';
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = Math.floor(sec % 60);
  const p2 = (n) => String(n).padStart(2, '0');
  if (h > 0) return `${h}:${p2(m)}:${p2(s)}`;
  if (m > 0) return `${m}:${p2(s)}`;
  return `${s} s`;
}

function barrasPerfil(pasos) {
  const out = [];
  const cap = 60;
  const segDe = (p) => {
    const val = Number(p.durValor ?? p.valor);
    const durTipo = p.durTipo || (p.unidad && ['km', 'm', 'mi', 'yd'].includes(p.unidad) ? 'Distancia' : 'Tiempo');
    if (durTipo === 'Tiempo') return (Number.isFinite(val) && val > 0 ? val : 1) * 60;
    if (durTipo === 'Distancia') {
      const u = p.durUnidad || p.unidad || 'km';
      const k = u === 'mi' ? val * 1.609344 : u === 'm' ? val / 1000 : u === 'yd' ? val * 0.0009144 : val;
      return k * 300;   // supuesto ~5:00/km para dimensionar la anchura
    }
    return 60;   // botón de vuelta
  };
  const intensidadDe = (p) => {
    let inten = INTENSIDAD_TIPO[p.tipo] ?? 0.5;
    if (p.objetivo === 'Ritmo' || p.objetivo === 'Zona ritmo') {
      const a = paceSeg(p.objMin), b = paceSeg(p.objMax);
      const medio = a != null && b != null ? (a + b) / 2 : (a ?? b);
      if (medio) inten = Math.max(0.2, Math.min(1, 360 / medio));   // 6:00/km → 0.6 · 3:00/km → 1
    } else if (p.objetivo === 'Zona FC' && p.objZona) {
      const nz = parseInt((String(p.objZona).match(/(\d+)/) || [])[1] || '0', 10);
      if (nz) inten = Math.max(0.2, Math.min(1, 0.25 + nz * 0.15));
    }
    return inten;
  };
  const push = (p, mult) => {
    if (out.length >= cap) return;
    out.push({ seg: Math.max(20, segDe(p) * mult), inten: intensidadDe(p) });
  };
  const walk = (list, mult) => (list || []).forEach((p) => {
    const hijos = Array.isArray(p.hijos) ? p.hijos : [];
    const reps = Math.max(1, Number(p.repeticiones) || 1) * (mult || 1);
    if (hijos.length) {
      // Bucle: CADA iteración repite la barra propia del paso (si tiene
      // duración) + su secuencia de hijos, en orden. La barra propia va
      // DENTRO del bucle: es como lo interpreta la sync a Garmin/intervals
      // (el bloque "2x" incluye la línea del propio paso) y la Medida;
      // pintarla fuera hacía que la 1ª repetición se viera bien y las
      // siguientes perdieran su primer elemento.
      const iter = Math.min(12, reps);
      for (let r = 0; r < iter && out.length < cap; r++) {
        if (Number(p.durValor ?? p.valor) > 0) push(p, 1);
        hijos.forEach((h) => walk([h], 1));
      }
      return;
    }
    // Paso suelto: sus repeticiones propias × las heredadas del bucle
    // contenedor = una barra por cada vez que se ejecuta.
    const veces = Math.max(1, Math.min(12, reps));
    for (let r = 0; r < veces && out.length < cap; r++) push(p, 1);
  });
  walk(pasos, 1);
  return out;
}

/* Tarjeta de FUERZA: en vez de las barras de perfil, el listado de los
   ejercicios que componen la actividad: letra en recuadro + nombre, uno
   debajo de otro. */
function ListaEjercicios({ pasos, isLight }) {
  const ej = (pasos || []).filter((p) => p.esEjercicio);
  if (!ej.length) return null;
  const letra = (i) => String.fromCharCode(65 + (i % 26));
  return (
    <View style={{ marginTop: 8, gap: 5 }}>
      {ej.map((p, i) => (
        <View key={p.id || i} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <View style={{ width: 18, height: 18, borderRadius: 4, backgroundColor: '#4A90E2', alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ color: '#fff', fontWeight: '800', fontSize: 10 }}>{letra(i)}</Text>
          </View>
          <Text style={{ color: isLight ? '#152238' : '#E8EDF5', fontSize: 12, flex: 1 }} numberOfLines={1}>
            {p.nombre || '—'}
          </Text>
          {!!(Array.isArray(p.series) && p.series.length) && (
            <Text style={{ color: isLight ? '#4A6080' : '#8FA8C8', fontSize: 10 }}>
              {p.series.length} {p.series.length === 1 ? 'serie' : 'series'}
            </Text>
          )}
        </View>
      ))}
    </View>
  );
}

function PerfilPasos({ pasos, isLight }) {
  const barras = useMemo(() => barrasPerfil(pasos), [pasos]);
  if (!barras.length) return null;
  const total = barras.reduce((s, b) => s + b.seg, 0) || 1;
  return (
    <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 1, height: 34, marginTop: 8 }}>
      {barras.map((b, i) => (
        <View key={i} style={{ flexGrow: b.seg, flexBasis: 0, height: `${Math.round(b.inten * 100)}%`, backgroundColor: isLight ? '#9AA9BC' : '#5E7089', borderTopLeftRadius: 2, borderTopRightRadius: 2, minWidth: 2 }} />
      ))}
    </View>
  );
}

/* ════════════════════════════════════════════════════════════════════════════
   REDISEÑO VISUAL con animaciones (la lógica del calendario, el arrastrar y
   soltar, las tarjetas por cumplimiento y los modales NO cambian)
   ════════════════════════════════════════════════════════════════════════════ */
// View animada que reenvía TODAS las props (panHandlers, onLayout, onTouchEnd…):
// entra con fundido + deslizamiento. No altera el layout, así que el arrastrar
// y soltar sigue midiendo las mismas posiciones.
function AnimView({ delay = 0, style, children, ...rest }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, { toValue: 1, duration: 380, delay, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [v, delay]);
  return (
    <Animated.View {...rest} style={[style, { opacity: v, transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) }] }]}>
      {children}
    </Animated.View>
  );
}

// Zona pulsable con efecto muelle (para botones SIN ref)
function Press({ onPress, disabled, style, children, hitSlop }) {
  const sc = useRef(new Animated.Value(1)).current;
  const to = (v) => Animated.spring(sc, { toValue: v, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <Pressable onPress={onPress} disabled={disabled} hitSlop={hitSlop} onPressIn={() => to(0.94)} onPressOut={() => to(1)}>
      <Animated.View style={[style, { transform: [{ scale: sc }] }]}>{children}</Animated.View>
    </Pressable>
  );
}

// Texto que se desliza al cambiar (etiqueta de la semana)
function TextoCambiante({ children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    v.setValue(0);
    Animated.timing(v, { toValue: 1, duration: 280, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [children, v]);
  return (
    <Animated.Text style={[style, { opacity: v, transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [8, 0] }) }] }]} numberOfLines={1}>
      {children}
    </Animated.Text>
  );
}

// Punto que late junto al día de hoy
function PuntoHoy() {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.timing(v, { toValue: 1, duration: 1800, easing: Easing.out(Easing.quad), useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [v]);
  return (
    <View style={{ width: 14, height: 14, alignItems: 'center', justifyContent: 'center' }}>
      <Animated.View style={{ position: 'absolute', width: 14, height: 14, borderRadius: 7, backgroundColor: BLUE, opacity: v.interpolate({ inputRange: [0, 1], outputRange: [0.5, 0] }), transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.8, 2] }) }] }} />
      <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: BLUE }} />
    </View>
  );
}

// Tarta de cumpleaños que "salta" al aparecer
function SaltoIcono({ children }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => { Animated.spring(v, { toValue: 1, useNativeDriver: true, speed: 10, bounciness: 18 }).start(); }, [v]);
  return <Animated.View style={{ transform: [{ scale: v }] }}>{children}</Animated.View>;
}

// Botón flotante "+": entra con rebote y se hunde al pulsarlo
function FabAdd({ onPress }) {
  const entra = useRef(new Animated.Value(0)).current;
  const sc = useRef(new Animated.Value(1)).current;
  useEffect(() => { Animated.spring(entra, { toValue: 1, delay: 300, useNativeDriver: true, speed: 10, bounciness: 14 }).start(); }, [entra]);
  const to = (v) => Animated.spring(sc, { toValue: v, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <Animated.View style={[styles.fabAdd, { transform: [{ scale: entra }, { scale: sc }] }]}>
      <Pressable onPress={onPress} onPressIn={() => to(0.88)} onPressOut={() => to(1)} style={styles.fabInner}>
        <Ionicons name="add" size={28} color="#fff" />
      </Pressable>
    </Animated.View>
  );
}

// Pantalla de carga: barras que suben y bajan
function BarraCal({ delay }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.delay(delay),
      Animated.timing(v, { toValue: 1, duration: 450, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration: 450, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [v, delay]);
  return <Animated.View style={{ width: 10, height: 48, borderRadius: 5, backgroundColor: BLUE, transform: [{ scaleY: v.interpolate({ inputRange: [0, 1], outputRange: [0.3, 1] }) }] }} />;
}
function CargaCal() {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 7, height: 48 }}>
      {[0, 1, 2, 3, 4].map((i) => <BarraCal key={i} delay={i * 120} />)}
    </View>
  );
}

export default function CalendarScreen({ route }) {
  const user = auth.currentUser;
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const isLight = theme.background === '#F4F7FB';
  const lang = settings.language || 'es';
  const loc = lang === 'en' ? 'en-US' : 'es-ES';
  const hrUnit = lang === 'en' ? 'bpm' : 'ppm';
  const todayLabel = lang === 'en' ? 'Today' : 'Hoy';

  const [athleteId, setAthleteId] = useState(null);
  const [athleteName, setAthleteName] = useState(null);
  const currentUserId = athleteId || user?.uid;
  // Zonas de ritmo del atleta que se está viendo: sirven para estimar los km
  // de los pasos "Zona ritmo" cuando un doc fusionado vino sin planDist
  // (services/planReal.js). Sin ellas la tarjeta mostraría la distancia
  // realizada sola, sin su comparativa con la planificada.
  const zonasDe = useZonasRitmoPorTipo(currentUserId);
  const [baseDate, setBaseDate] = useState(new Date());
  const [monthPickerVisible, setMonthPickerVisible] = useState(false);
  const [focusDay, setFocusDay] = useState(null); // día elegido en el calendario mensual
  const [weekDays, setWeekDays] = useState(getWeekDays(new Date()));
  const [entrenamientos, setEntrenamientos] = useState([]);
  const [cumple, setCumple] = useState(null);   // 'MM-DD' del cumpleaños del dueño del calendario
  const [wellness, setWellness] = useState({});
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedDay, setSelectedDay] = useState(null);
  const [detailModalVisible, setDetailModalVisible] = useState(false);
  const [selectedWorkout, setSelectedWorkout] = useState(null);

  // ── Drag & drop ──
  const [drag, setDrag] = useState(null);
  const [scrollLocked, setScrollLocked] = useState(false);
  const ty = useRef(new Animated.Value(0)).current;
  const indY = useRef(new Animated.Value(HIDE_Y)).current;
  const scrollRef = useRef(null);
  const scrollWrapRef = useRef(null);
  const scrollY = useRef(0);
  const containerPageY = useRef(0);
  const dayPos = useRef({});
  const cardPos = useRef({});
  const cardRefs = useRef({});
  const panRefs = useRef({});
  const dragMeta = useRef(null);
  const hoverRef = useRef(null);
  const movedRef = useRef(false);
  const lastPageY = useRef(0);
  const autoDir = useRef(0);
  const autoVel = useRef(0);
  const rafRef = useRef(null);
  const suppressTap = useRef(false);
  const dayPositions = useRef({});
  const prevUserIdRef = useRef(null);

  const entrenosRef = useRef([]);
  const weekDaysRef = useRef([]);
  const fetchDataRef = useRef(null);
  entrenosRef.current = entrenamientos;
  weekDaysRef.current = weekDays;

  useEffect(() => {
    const t = setTimeout(() => { scrollWrapRef.current?.measureInWindow((x, y) => { containerPageY.current = y; }); }, 300);
    return () => clearTimeout(t);
  }, []);

  const fetchData = useCallback(async (skipCache = false) => {
    if (!currentUserId) return;
    if (!skipCache && _workoutCache.uid === currentUserId && _workoutCache.data.length > 0 && Date.now() - _workoutCache.ts < CACHE_TTL_MS) {
      setEntrenamientos(_workoutCache.data);
      setLoading(false);
      setRefreshing(false);
      return;
    }
    try {
      const now = new Date();
      const start = new Date(now); start.setDate(now.getDate() - 30); start.setHours(0,0,0,0);
      const end = new Date(now); end.setDate(now.getDate() + 30); end.setHours(23,59,59,999);
      const q = query(
        collection(db, 'entrenamientos'),
        where('userId', '==', currentUserId),
        where('fecha', '>=', Timestamp.fromDate(start)),
        where('fecha', '<=', Timestamp.fromDate(end)),
        orderBy('fecha', 'desc'),
      );
      const snap = await getDocs(q);
      const lista = snap.docs.map(d => ({ id: d.id, ...stripHeavyFields(d.data()) }));
      try {
        // array-contains SIN rango de fechas: usa el indice automatico de un solo campo
        // (NO necesita indice compuesto en Firebase). El rango +/-30 dias se filtra en local.
        const q2 = query(
          collection(db, 'entrenamientos'),
          where('asignados', 'array-contains', currentUserId),
        );
        const s2 = await getDocs(q2);
        s2.docs.forEach(d => {
          const data = d.data();
          const f = data.fecha?.toMillis?.() ?? null;
          if (f != null && f >= start.getTime() && f <= end.getTime() && !lista.some(x => x.id === d.id)) {
            lista.push({ id: d.id, ...stripHeavyFields(data) });
          }
        });
      } catch (e) {
        console.log('Error consultando eventos asignados:', e?.message || e);
      }
      // ── Duración del recuadro = Σ de las vueltas ──
      // El tiempo bueno de un entreno realizado es el MISMO número que muestra
      // la fila Σ del apartado Vueltas: las vueltas reconstruyen el cronómetro
      // descartando los tramos con la sesión parada (calentamiento, semáforos…)
      // que el reloj sí cuenta en elapsed. La `duracion` del doc principal
      // puede llegar inflada hasta que el sync la realinee, así que para los
      // realizados se lee detalles/data y se muestra esa suma exacta (la misma
      // matemática que el modal). Sin vueltas o sin detalle se respeta la
      // duración guardada. En lotes de 10 para no disparar lecturas de golpe.
      try {
        const hechos = lista.filter(x => x.estado === 'completo');
        for (let i = 0; i < hechos.length; i += 10) {
          const lote = hechos.slice(i, i + 10);
          const dets = await Promise.all(lote.map(x =>
            getDoc(doc(db, 'entrenamientos', x.id, 'detalles', 'data')).catch(() => null)
          ));
          dets.forEach((ds, k) => {
            if (!ds || !ds.exists) return;
            const vs = ds.data().vueltas;
            if (Array.isArray(vs) && vs.length) {
              const suma = Math.round(vs.reduce((a, v) => a + (Number(v && v.tiempo) || 0), 0));
              if (suma > 0 && !lote[k].duracionManual) lote[k].duracion = suma;
            }
          });
        }
      } catch (e) {
        console.log('[calendario] alineando duración con Σ vueltas:', e?.message || e);
      }
      _workoutCache.uid = currentUserId; _workoutCache.data = lista; _workoutCache.ts = Date.now();
      setEntrenamientos(lista);
    } catch (e) {
      console.log('Error fetchData:', e.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [currentUserId]);
  fetchDataRef.current = fetchData;

  const fetchWellness = useCallback(async (force = false) => {
    if (!currentUserId) return;
    if (!force) {
      const cached = chartCache.getWellness(currentUserId);
      if (cached) { setWellness(cached); return; }
    }
    try {
      const snap = await getDoc(doc(db, 'wellness', currentUserId));
      const days = snap.exists ? (snap.data().days || {}) : {};
      chartCache.setWellness(currentUserId, days);
      setWellness(days);
    } catch (e) {
      console.log('Error fetchWellness:', e.message);
    }
  }, [currentUserId]);

  useEffect(() => {
    if (currentUserId) { fetchData(true); fetchWellness(true); }
  }, [currentUserId, fetchData, fetchWellness]);

  useFocusEffect(useCallback(() => {
    AsyncStorage.getItem('currentAthleteId').then(id => {
      setAthleteId(id);
      AsyncStorage.getItem('currentAthleteName').then(n => setAthleteName(n));
      const newUserId = id || user?.uid;
      if (prevUserIdRef.current !== null && prevUserIdRef.current !== newUserId) {
        fetchWellness(true);
      }
      prevUserIdRef.current = newUserId;
    });
  }, [fetchWellness, user?.uid]));

  useEffect(() => { setWeekDays(getWeekDays(baseDate)); }, [baseDate]);

  // Cumpleaños del dueño del calendario (fechaNac en su perfil: ISO
  // 'YYYY-MM-DD' o Timestamp de Firestore en perfiles antiguos):
  // si el día coincide, se pinta una tarta junto al nombre del día.
  useEffect(() => {
    if (!currentUserId) { setCumple(null); return undefined; }
    let vivo = true;
    (async () => {
      try {
        const snap = await getDoc(doc(db, 'perfiles', currentUserId));
        if (!vivo) return;
        const raw = snap.exists() ? snap.data().fechaNac : '';
        let iso = '';
        if (raw && typeof raw.toDate === 'function') {         // Timestamp
          const d = raw.toDate();
          iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        } else {
          iso = String(raw || '').trim();
        }
        if (/^\d{4}-\d{2}-\d{2}$/.test(iso)) setCumple(iso.slice(5));   // 'MM-DD'
        else setCumple(null);
      } catch (e) { if (vivo) setCumple(null); }
    })();
    return () => { vivo = false; };
  }, [currentUserId]);

  // Scroll hasta un día concreto, reintentando hasta que el layout
  // de la semana haya medido sus bloques (dayPositions). Así funciona
  // tanto si hay que cambiar de semana como si ya estás en ella.
  const scrollTimer = useRef(null);
  const scrollTarget = useRef(null); // clave del día al que pertenece el timer activo
  const scrollToDay = useCallback((d) => {
    const key = toKey(d);
    if (scrollTimer.current) clearInterval(scrollTimer.current);
    scrollTarget.current = key;
    let tries = 0;
    scrollTimer.current = setInterval(() => {
      tries++;
      const pos = dayPositions.current[key];
      if (pos != null && scrollRef.current) {
        scrollRef.current.scrollTo({ y: Math.max(0, pos - 10), animated: true });
        clearInterval(scrollTimer.current); scrollTimer.current = null; scrollTarget.current = null;
      } else if (tries >= 12) { clearInterval(scrollTimer.current); scrollTimer.current = null; scrollTarget.current = null; }
    }, 60);
  }, []);

  // Al venir del calendario mensual, centra el día concreto elegido.
  // El cleanup SOLO cancela el timer si es del mismo día que este efecto
  // lanzó: así el scroll del botón "Hoy" no se mata al cambiar la semana.
  useEffect(() => {
    if (!focusDay) return;
    const key = toKey(focusDay);
    scrollToDay(focusDay);
    return () => {
      if (scrollTarget.current === key) {
        if (scrollTimer.current) clearInterval(scrollTimer.current);
        scrollTimer.current = null; scrollTarget.current = null;
      }
    };
  }, [focusDay, weekDays, scrollToDay]);

  const changeWeek = (dir) => { const d = new Date(baseDate); d.setDate(d.getDate() + dir * 7); setBaseDate(d); };

  const goToday = () => {
    const today = new Date();
    setFocusDay(null); // quita la marca/scroll del día del picker para evitar conflictos
    if (getWeekKey(weekDays) !== getWeekKey(getWeekDays(today))) setBaseDate(today);
    scrollToDay(today);
  };

  const getDayItems = (day, excludeId) => (entrenosRef.current || [])
    .filter(e => {
      if (!e.fecha) return false;
      if (excludeId && e.id === excludeId) return false;
      const d = e.fecha.toDate ? e.fecha.toDate() : new Date(e.fecha);
      return d.toDateString() === day.toDateString();
    })
    .sort((a, b) => (a.fecha?.toMillis?.() ?? 0) - (b.fecha?.toMillis?.() ?? 0));

  const isToday = (day) => day.toDateString() === new Date().toDateString();
  const openModal = (day) => { setSelectedDay(day); setModalVisible(true); };
  // Color de tarjeta por CUMPLIMIENTO del entreno (verde/amarillo/naranja/
  // rojo/gris) — services/compliance.js. Ya no es un simple estado.
  const getWorkoutColor = (w) => complianceEntreno(w, new Date(), resolverPlanReal(w, zonasDe(w && w.tipo))).color;
  const dragPal = drag ? cardColors(drag.color, isLight) : null;

  // ── Drag: snapshot del layout de la semana visible al empezar a arrastrar ──
  const fingerContentY = (pageY) => pageY - containerPageY.current + scrollY.current;

  const buildLayoutSnapshot = (draggedId) => {
    return weekDaysRef.current
      .map(d => {
        const key = toKey(d);
        const dp = dayPos.current[key];
        if (!dp) return null;
        const items = getDayItems(d, draggedId)
          .map(c => ({ id: c.id, cp: cardPos.current[c.id] }))
          .filter(x => x.cp);
        return { key, y: dp.y, height: dp.height, items };
      })
      .filter(Boolean);
  };

  const computeInsert = (pageY) => {
    const m = dragMeta.current;
    if (!m || !m.layout) return;
    const topLimit = containerPageY.current + 70;
    const botLimit = SCREEN_H - 80;
    const dir = pageY > botLimit ? 1 : pageY < topLimit ? -1 : 0;
    if (dir !== autoDir.current) { autoDir.current = dir; autoVel.current = 0; }
    const fy = fingerContentY(pageY);
    const day = m.layout.find(dd => fy >= dd.y && fy < dd.y + dd.height);
    const key = day ? day.key : null;
    let beforeId = null;
    if (day) {
      const fyDay = fy - day.y;
      for (const c of day.items) {
        if (fyDay < c.cp.y + c.cp.height / 2) { beforeId = c.id; break; }
      }
    }
    hoverRef.current = { key, beforeId };
    let indContentY = HIDE_Y;
    if (day) {
      if (beforeId) {
        const cp = day.items.find(c => c.id === beforeId)?.cp;
        if (cp) indContentY = Math.max(day.y, day.y + cp.y - IND_H - 6);
      } else {
        let bottom = 40;
        for (const c of day.items) { if (c.cp.y + c.cp.height > bottom) bottom = c.cp.y + c.cp.height; }
        indContentY = day.y + bottom - 6;
      }
    }
    indY.setValue(indContentY);
  };

  const autoScrollLoop = () => {
    if (!dragMeta.current) { autoDir.current = 0; autoVel.current = 0; return; }
    if (autoDir.current !== 0) {
      autoVel.current = Math.min(autoVel.current + 0.6, 16);
      const next = Math.max(0, scrollY.current + autoDir.current * autoVel.current);
      scrollRef.current?.scrollTo({ y: next, animated: false });
      scrollY.current = next;
      computeInsert(lastPageY.current);
    }
    rafRef.current = requestAnimationFrame(autoScrollLoop);
  };

  const armDrag = (pageY, id) => {
    const w = (entrenosRef.current || []).find(x => x.id === id);
    if (!w) return;
    // Los entrenos creados por el coach no se pueden arrastrar: ni los que
    // me ha agregado él (userId = coach) ni los que creó directamente en mi
    // calendario (userId = yo pero creadoPor = coach). Solo su creador puede
    // modificarlos. El coach sí puede (user.uid es el coach aunque esté
    // viendo el calendario de un atleta). En documentos antiguos sin
    // creadoPor, la pista es que el dueño aparezca en asignados: eso solo
    // pasa en eventos que el coach creó en el calendario del atleta.
    const creadorDrag = w.creadoPor || w.userId;
    const viendoOtroCalendario = !!athleteId && athleteId !== user?.uid;
    if (!viendoOtroCalendario) {
      // Calendario propio: los EVENTOS creados por otro no se pueden arrastrar
      // (ni los legacy del coach con apuntados). Cualquier OTRO entreno de tu
      // calendario se puede mover aunque lo haya creado el coach: él te dio
      // acceso completo. Viendo el calendario de un atleta (coach): sin límites.
      if (w.tipo === 'Evento' && creadorDrag !== user?.uid) return;
    }
    const el = cardRefs.current[id];
    if (!el) return;
    el.measureInWindow((x, y) => {
      dragMeta.current = {
        id,
        grab: pageY - y,
        layout: buildLayoutSnapshot(id),
      };
      movedRef.current = false;
      lastPageY.current = pageY;
      autoDir.current = 0;
      autoVel.current = 0;
      ty.setValue(y);
      computeInsert(pageY);
      setScrollLocked(true);
      const compDrag = complianceEntreno(w, new Date(), resolverPlanReal(w, zonasDe(w.tipo)));
      setDrag({
        id,
        // El color del snapshot es el de CUMPLIMIENTO: la tarjeta fantasma lo
        // usa para el icono (drag.color) y dragPal lo deriva de drag.color.
        color: compDrag.color,
        tipo: w.tipo,
        titulo: w.titulo || w.tipo,
        descripcion: w.descripcion,
        subtitle: formatSubtitleItem(w),
        estado: w.estado,
        kind: compDrag.kind,
        esfuerzo: Math.round(Number(w.esfuerzo ?? w.tss) || 0),
      });
      Vibration.vibrate(10);
      rafRef.current = requestAnimationFrame(autoScrollLoop);
    });
  };

  const moveDrag = (pageY) => {
    const m = dragMeta.current;
    if (!m) return;
    movedRef.current = true;
    lastPageY.current = pageY;
    ty.setValue(pageY - m.grab);
    computeInsert(pageY);
  };

  const cleanup = () => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    autoDir.current = 0;
    autoVel.current = 0;
    dragMeta.current = null;
    hoverRef.current = null;
    movedRef.current = false;
    indY.setValue(HIDE_Y);
    setDrag(null);
    setScrollLocked(false);
    suppressTap.current = true;
    setTimeout(() => { suppressTap.current = false; }, 250);
  };

  const endDrag = () => {
    const m = dragMeta.current;
    const h = hoverRef.current;
    if (!m || !movedRef.current || !h || !h.key) { cleanup(); return; }
    const dayDate = weekDaysRef.current.find(d => toKey(d) === h.key);
    if (!dayDate) { cleanup(); return; }
    let nf = null;
    if (h.beforeId) {
      const before = (entrenosRef.current || []).find(e => e.id === h.beforeId);
      if (before) nf = new Date((before.fecha?.toMillis?.() ?? 0) - 60000);
    }
    if (!nf) {
      const items = getDayItems(dayDate, m.id);
      if (items.length) {
        nf = new Date((items[items.length - 1].fecha?.toMillis?.() ?? 0) + 60000);
      } else {
        nf = new Date(dayDate);
        nf.setHours(8, 0, 0, 0);
      }
    }
    const ts = Timestamp.fromDate(nf);
    const p2 = n => String(n).padStart(2, '0');
    const fechaStr = `${p2(nf.getDate())}/${p2(nf.getMonth()+1)}/${nf.getFullYear()}`;
    const mutate = (list) => list.map(e => (e.id === m.id ? { ...e, fecha: ts, fechaStr } : e));
    setEntrenamientos(prev => mutate(prev));
    _workoutCache.data = mutate(_workoutCache.data);
    _workoutCache.ts = Date.now();
    cleanup();
    updateDoc(doc(db, 'entrenamientos', m.id), { fecha: ts, fechaStr })
      .catch(() => { _workoutCache.uid = null; fetchDataRef.current?.(true); });
    // A5 + C 4.6: mover la fecha invalida las curvas y reconstruye el digest
    // en el mes nuevo (quita el del mes antiguo). try/catch: nunca rompe el drag.
    try {
      const wMov0 = (entrenosRef.current || []).find((e) => e.id === m.id);
      const uidW = wMov0?.userId || auth.currentUser?.uid;
      if (uidW) {
        invalidarCurvasEntreno(uidW);
        const fms = wMov0?.fecha?.toMillis
          ? wMov0.fecha.toMillis()
          : (wMov0?.fecha instanceof Date ? wMov0.fecha.getTime() : Date.now());
        marcarPendiente(uidW, m.id).catch(() => {});
        quitarDigest(uidW, m.id, fms).catch(() => {});
      }
    } catch (e) {
      console.warn('[Calendar] invalidación de curvas falló:', e.message);
    }
    // Drag & drop: avisar al atleta de que el coach le ha MOVIDO el entreno
    // (dueño del entreno + apuntados al evento, nunca el propio coach).
    const wMov = (entrenosRef.current || []).find((e) => e.id === m.id);
    const coachUid = user?.uid;
    const dest = new Set();
    if (wMov?.userId && wMov.userId !== coachUid) dest.add(wMov.userId);
    (Array.isArray(wMov?.asignados) ? wMov.asignados : []).forEach((u) => { if (u !== coachUid) dest.add(u); });
    if (wMov && dest.size > 0 && coachUid) {
      const nombre = wMov.titulo || wMov.tipo;
      getCoachFullName(coachUid).then((cn) => {
        for (const d of dest) {
          // Título/cuerpo los compone el servidor en el idioma del atleta
          sendNotificationToAthlete(d, coachUid, { kind: 'movido', coachName: cn, nombre, fechaStr, workoutId: m.id });
        }
      }).catch(() => {});
    }
  };

  const getCardPan = (id) => {
    if (!panRefs.current[id]) {
      panRefs.current[id] = PanResponder.create({
        onMoveShouldSetPanResponder: () => !!dragMeta.current,
        onPanResponderMove: (e) => moveDrag(e.nativeEvent.pageY),
        onPanResponderRelease: () => endDrag(),
        onPanResponderTerminate: () => cleanup(),
      });
    }
    return panRefs.current[id];
  };

  const renderMetrics = (day, palette = theme) => {
    const m = wellness[toKey(day)];
    if (!m) return null;
    const chips = [];
    if (m.sleep != null) chips.push({ icon: 'moon', text: fmtSleep(m.sleep) });
    if (m.score != null) chips.push({ icon: 'star-outline', text: `${m.score}` });
    if (m.rhr != null)   chips.push({ icon: 'heart-half', text: `${m.rhr} ${hrUnit}` });
    if (m.hrv != null)   chips.push({ icon: 'pulse-outline', text: `${m.hrv} ms` });
    if (m.spo2 != null)  chips.push({ icon: 'water-outline', text: `${m.spo2}%` });
    const vo2Value = m.vo2_est ?? m.vo2;
    if (vo2Value != null) chips.push({ icon: 'speedometer-outline', text: `${Number(vo2Value).toFixed(1)}` });
    if (m.fcMax != null) chips.push({ icon: 'heart-outline', text: `${m.fcMax} ${hrUnit}` });
    if (m.kcal != null)  chips.push({ icon: 'flame-outline', text: `${m.kcal} kcal` });
    if (m.steps != null) chips.push({ icon: 'footsteps', text: `${m.steps}` });
    if (!chips.length) return null;
    return (
      <View style={[styles.metricsCard, { backgroundColor: palette.card, borderColor: palette.border }]}>
        {chips.map((c, i) => (
          <View key={i} style={styles.metricChip}>
            <Ionicons name={c.icon} size={13} color={palette.muted} />
            <Text style={[styles.metricText, { color: palette.muted }]}>{c.text}</Text>
          </View>
        ))}
      </View>
    );
  };

  if (loading) {
    return (
      <View style={[styles.splash, { backgroundColor: theme.background }]}>
        <CargaCal />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <View style={[styles.header, { backgroundColor: theme.card, borderBottomColor: theme.border }]}>
        <Press style={styles.todayBtn} onPress={goToday}>
          <Ionicons name="today-outline" size={14} color="#fff" />
          <Text style={styles.todayText}>{todayLabel}</Text>
        </Press>
        <Press onPress={() => changeWeek(-1)} style={[styles.navBtn, { backgroundColor: theme.background, borderColor: theme.border }]}>
          <Ionicons name="chevron-back" size={18} color="#8FA8C8" />
        </Press>
        <TouchableOpacity style={styles.weekLabelBox} onPress={() => setMonthPickerVisible(true)} activeOpacity={0.7}>
          <Ionicons name="calendar-outline" size={14} color={BLUE} />
          <TextoCambiante key={weekLabel(weekDays, loc)} style={[styles.weekLabel, { color: theme.text }]}>{weekLabel(weekDays, loc)}</TextoCambiante>
          <Ionicons name="chevron-down" size={12} color="#8FA8C8" />
        </TouchableOpacity>
        <Press onPress={() => changeWeek(1)} style={[styles.navBtn, { backgroundColor: theme.background, borderColor: theme.border }]}>
          <Ionicons name="chevron-forward" size={18} color="#8FA8C8" />
        </Press>
      </View>

      <View
        ref={scrollWrapRef}
        style={{ flex: 1 }}
        onLayout={() => { scrollWrapRef.current?.measureInWindow((x, y) => { containerPageY.current = y; }); }}
      >
        <ScrollView
          ref={scrollRef}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          scrollEnabled={!scrollLocked}
          overScrollMode="never"
          onScroll={(e) => { if (!dragMeta.current) scrollY.current = e.nativeEvent.contentOffset.y; }}
          scrollEventThrottle={32}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              enabled={!scrollLocked}
              onRefresh={() => { setRefreshing(true); fetchData(true); fetchWellness(true); }}
              tintColor={BLUE}
            />
          }
        >
          {weekDays.map((day, di) => {
            const dayItems = getDayItems(day);
            const dayLabel = day.toLocaleDateString(loc, { weekday: 'long', day: 'numeric' });
            const isTodayDay = isToday(day);
            const key = toKey(day);
            return (
              <AnimView
                key={day.toISOString()}
                delay={Math.min(di * 70, 420)}
                style={[styles.dayBlock, { borderBottomColor: theme.border }, isTodayDay && styles.dayBlockToday, focusDay && toKey(day) === toKey(focusDay) && { backgroundColor: BLUE + '12' }]}
                onLayout={(e) => {
                  dayPos.current[key] = { y: e.nativeEvent.layout.y, height: e.nativeEvent.layout.height };
                  dayPositions.current[key] = e.nativeEvent.layout.y;
                }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <Text style={[styles.dayTitle, { color: focusDay && toKey(day) === toKey(focusDay) ? BLUE : theme.muted }, isTodayDay && styles.dayTitleToday]}>
                    {dayLabel.charAt(0).toUpperCase() + dayLabel.slice(1)}
                  </Text>
                  {isTodayDay && <PuntoHoy />}
                  {/* Tarta de cumpleaños. OJO: es MaterialCommunityIcons a
                      propósito — Ionicons (@expo/vector-icons 15) NO tiene
                      ningún icono "cake" y pintaba una interrogación. Es la
                      misma familia de iconos que la medalla de récord. */}
                  {!!cumple && cumple === `${String(day.getMonth() + 1).padStart(2, '0')}-${String(day.getDate()).padStart(2, '0')}` && (
                    <SaltoIcono><MaterialCommunityIcons name="cake-variant" size={17} color="#E8A33D" /></SaltoIcono>
                  )}
                </View>
                {dayItems.map((e, ci) => {
                  const subtitle = formatSubtitleItem(e);
                  // Entreno realizado: comparativa con lo planificado. El plan
                  // se RESUELVE (services/planReal.js): planDist km / planDur seg
                  // del doc fusionado por el matcher y, si faltan —fusiones
                  // antiguas, planes con pasos por zona de ritmo—, la medida del
                  // planificado o el recálculo desde los pasos. Así la distancia
                  // sale siempre con su comparativa, igual que el tiempo.
                  const esRealizado = e.estado === 'completo';
                  const plan = resolverPlanReal(e, zonasDe(e.tipo));
                  const planDurTxt = esRealizado && Number(plan.dur) > 0 ? fmtTiempoCorto(Number(plan.dur)) : null;
                  const planDistTxt = esRealizado && Number(plan.dist) > 0 ? fmtDistance(Number(plan.dist)) : null;
                  const fcMedia = Number(e['fc-media']) || 0;
                  const esfuerzo = Math.round(Number(e.esfuerzo ?? e.tss) || 0); // TSS del entreno sincronizado
                  // Carita de sensaciones + nº de carga percibida (1-5, "Alta"=4).
                  // Viven en el doc principal (las guarda Guardar sesión en el
                  // detalle); sin carita → sensacion null/undefined.
                  const sensIdx = e.sensacion != null ? Math.round(Number(e.sensacion)) : null;
                  const sensOk = sensIdx != null && sensIdx >= 0 && sensIdx <= 4 && !!MOODS[sensIdx];
                  const cargaIx = CARGAS.indexOf(e.cargaPercibida);
                  const cargaNum = cargaIx >= 0 ? cargaIx + 1 : null;
                  const comp = complianceEntreno(e, new Date(), plan);
                  const iconoComp = ICONO_COMP[comp.kind];
                  const hasFooter = !!iconoComp || esfuerzo > 0 || !!e.tieneComentarios || (Array.isArray(e.records) && e.records.length > 0) || sensOk || cargaNum != null;
                  const color = comp.color;
                  const pal = cardColors(color, isLight);
                  const pan = getCardPan(e.id);
                  return (
                    <AnimView
                      key={e.id}
                      delay={Math.min(di * 70 + 120 + ci * 60, 600)}
                      {...pan.panHandlers}
                      onTouchEnd={() => { if (dragMeta.current && !movedRef.current) cleanup(); }}
                      onLayout={(ev) => { cardPos.current[e.id] = { y: ev.nativeEvent.layout.y, height: ev.nativeEvent.layout.height }; }}
                    >
                      <TouchableOpacity
                        ref={(r) => { cardRefs.current[e.id] = r; }}
                        style={[styles.workoutCard, { backgroundColor: pal.bg }, isTodayDay && styles.todayBorder, drag?.id === e.id && styles.ghostCard]}
                        onPress={() => { if (suppressTap.current) return; setSelectedWorkout(e); setDetailModalVisible(true); }}
                        onLongPress={(ev) => armDrag(ev.nativeEvent.pageY, e.id)}
                        delayLongPress={250}
                        activeOpacity={0.8}
                      >
                        <View style={[styles.cardAccent, { backgroundColor: pal.accent }]} />
                        <View style={[styles.cardBody, hasFooter && styles.cardBodyWithFooter]}>
                          <View style={styles.iconChip}><ActivityIcon tipo={e.tipo} size={18} color={comp.kind ? comp.color : undefined} /></View>
                          <View style={{ flex: 1 }}>
                            <Text style={[styles.cardTitle, isLight && { color: theme.text }]}>{e.titulo || e.tipo}</Text>
                            {e.descripcion ? <Text style={[styles.cardDesc, isLight && { color: theme.text }]}>{e.descripcion}</Text> : null}
                            {/* Fuerza: listado de ejercicios en vez de barras */}
                            {e.tipo === 'Fuerza' && !!(Array.isArray(e.pasos) && e.pasos.some((x) => x.esEjercicio)) && (
                              <ListaEjercicios pasos={e.pasos} isLight={isLight} />
                            )}
                            {/* Perfil visual del entreno: barras por paso (altura=intensidad, anchura=duración) */}
                            {!(e.tipo === 'Fuerza' && (Array.isArray(e.pasos) && e.pasos.some((x) => x.esEjercicio))) && !!(Array.isArray(e.pasos) && e.pasos.length > 0) && e.estado !== 'completo' && !e.intervalsId && !e.mergedFromPlanId && <PerfilPasos pasos={e.pasos} isLight={isLight} />}
                            {esRealizado ? (
                              /* Realizado: tiempo/km apilados como realizado/planeado;
                                 FC sin comparativa. En claro, gris claro para los datos. */
                              <View style={{ marginTop: 2, gap: 1 }}>
                                {Number(e.duracion) > 0 && (
                                  <Text style={[styles.metaText, isLight && { color: '#8A98AB' }]}>
                                    {planDurTxt ? `${fmtTiempoCorto(Number(e.duracion))} / ${planDurTxt}` : fmtTiempoCorto(Number(e.duracion))}
                                  </Text>
                                )}
                                {e.distancia != null && Number(e.distancia) > 0 && (
                                  <Text style={[styles.metaText, isLight && { color: '#8A98AB' }]}>
                                    {planDistTxt ? `${fmtDistance(Number(e.distancia))} / ${planDistTxt}` : fmtDistance(Number(e.distancia))}
                                  </Text>
                                )}
                                {fcMedia > 0 && (
                                  <Text style={[styles.metaText, isLight && { color: '#8A98AB' }]}>{fcMedia} {hrUnit}</Text>
                                )}
                              </View>
                            ) : subtitle ? <Text style={[styles.metaText, isLight && { color: theme.muted }]}>{subtitle}</Text> : null}
                          </View>
                        </View>
                        {hasFooter && (
                          <View style={styles.cardFooter}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                              {iconoComp ? (
                                // Las flechas de cumplimiento (▲/▼) van blancas
                                // también en claro: sobre el fondo de color
                                // su color propio se perdía.
                                <Ionicons name={iconoComp} size={19} color={iconoComp.startsWith('arrow') ? '#fff' : (isLight ? color : '#fff')} />
                              ) : <View />}
                              {!!e.tieneComentarios && <Ionicons name="chatbubble-ellipses" size={14} color={isLight ? '#4A6080' : '#C8D4E4'} />}
                              {/* Carita de sensaciones + nº de carga percibida
                                  ("Alta" = 4): píldora como la de récords */}
                              {(sensOk || cargaNum != null) && (() => {
                                const mc = sensOk ? (MOOD_COLORS[sensIdx] || '#8FA8C8') : (isLight ? '#4A6080' : '#C8D4E4');
                                // En claro la píldora va sólida y el número en
                                // blanco: con el tinte del mismo color no se leía.
                                return (
                                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: isLight ? mc : mc + '26', borderRadius: 999, paddingHorizontal: 6, paddingVertical: 1 }}>
                                    {sensOk && <Text style={{ fontSize: 12, lineHeight: 15 }}>{Platform.OS === 'ios' ? `${MOODS[sensIdx]}\uFE0E` : MOODS[sensIdx]}</Text>}
                                    {cargaNum != null && <Text style={{ color: isLight ? '#fff' : mc, fontSize: 11, fontWeight: '800' }}>{cargaNum}</Text>}
                                  </View>
                                );
                              })()}
                              {!!(Array.isArray(e.records) && e.records.length > 0) && (() => {
                                const mc = colorMedalla(pal.bg);
                                return (
                                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 2, backgroundColor: mc + '26', borderRadius: 999, paddingHorizontal: 6, paddingVertical: 1 }}>
                                    <MaterialCommunityIcons name="medal" size={14} color={mc} />
                                    <Text style={{ color: mc, fontSize: 11, fontWeight: '800' }}>x{e.records.length}</Text>
                                  </View>
                                );
                              })()}
                            </View>
                            <EsfuerzoBadge value={esfuerzo} />
                          </View>
                        )}
                      </TouchableOpacity>
                    </AnimView>
                  );
                })}
                {renderMetrics(day, theme)}
                <Press
                  style={[styles.emptySlot, isTodayDay && styles.todayBorderDashed]}
                  onPress={() => openModal(day)}
                >
                  <Ionicons name="add" size={20} color={isTodayDay ? BLUE : '#2A4060'} />
                </Press>
              </AnimView>
            );
          })}
          {drag && (
            <Animated.View pointerEvents="none" style={[styles.dropIndicator, { transform: [{ translateY: indY }] }]} />
          )}
        </ScrollView>
      </View>

      {/* FAB: agregar entreno (mismo '+' que el de cada día), abajo a la derecha */}
      <FabAdd onPress={() => openModal(new Date())} />

      {drag && (
        <Animated.View
          pointerEvents="none"
          style={[styles.dragOverlay, { backgroundColor: dragPal.bg, transform: [{ translateY: ty }, { scale: 1.04 }] }]}
        >
          <View style={[styles.cardAccent, { backgroundColor: dragPal.accent }]} />
          <View style={[styles.cardBody, (drag.kind || drag.esfuerzo > 0) && styles.cardBodyWithFooter]}>
            <View style={styles.iconChip}><ActivityIcon tipo={drag.tipo} size={18} color={drag.kind ? drag.color : undefined} /></View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.cardTitle, isLight && { color: theme.text }]}>{drag.titulo}</Text>
              {drag.descripcion ? <Text style={[styles.cardDesc, isLight && { color: theme.muted }]}>{drag.descripcion}</Text> : null}
              {drag.subtitle ? <Text style={[styles.metaText, isLight && { color: theme.muted }]}>{drag.subtitle}</Text> : null}
            </View>
          </View>
          {(drag.kind || drag.esfuerzo > 0) && (
            <View style={styles.cardFooter}>
              {drag.kind ? (
                <Ionicons name={ICONO_COMP[drag.kind]} size={19} color={isLight ? drag.color : '#fff'} />
              ) : <View />}
              <EsfuerzoBadge value={drag.esfuerzo} />
            </View>
          )}
        </Animated.View>
      )}

      <MonthPickerModal
        visible={monthPickerVisible}
        initialDate={baseDate}
        onClose={() => setMonthPickerVisible(false)}
        onSelect={(d) => { setBaseDate(d); setFocusDay(d); setMonthPickerVisible(false); }}
      />
      <AddWorkoutModal
        visible={modalVisible}
        onClose={() => setModalVisible(false)}
        onWorkoutAdded={() => { _workoutCache.uid = null; fetchData(true); }}
        initialDate={selectedDay}
        athleteId={athleteId}
      />
      <WorkoutDetailModal
        key={selectedWorkout?.id || 'cerrado'}
        visible={detailModalVisible}
        workout={selectedWorkout}
        onClose={() => { setDetailModalVisible(false); setSelectedWorkout(null); }}
        onWorkoutUpdated={() => { _workoutCache.uid = null; fetchData(true); }}
        athleteId={athleteId}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  splash: { flex: 1, backgroundColor: NAVY, alignItems: 'center', justifyContent: 'center' },
  scrollContent: { paddingBottom: 32 },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 12, paddingTop: 56, paddingBottom: 12,
    backgroundColor: NAVY, borderBottomWidth: 1, borderBottomColor: BORDER, gap: 4,
  },
  todayBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: BLUE, borderRadius: 999, paddingHorizontal: 13, paddingVertical: 8, marginRight: 4 },
  todayText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  navBtn: { width: 34, height: 34, borderRadius: 17, borderWidth: 1, borderColor: BORDER, alignItems: 'center', justifyContent: 'center' },
  weekLabelBox: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  weekLabel: { color: '#8FA8C8', fontSize: 14, fontWeight: '600' },
  dayBlock: { borderBottomWidth: 1, borderBottomColor: BORDER },
  dayBlockToday: { borderLeftWidth: 3, borderLeftColor: BLUE },
  fabInner: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center' },
  dayTitle: { color: '#8FA8C8', fontSize: 14, fontWeight: '600', paddingHorizontal: 16, paddingTop: 14, paddingBottom: 8 },
  dayTitleToday: { color: BLUE },
  workoutCard: { marginHorizontal: 16, marginBottom: 6, borderRadius: 16, overflow: 'hidden' },
  ghostCard: { opacity: 0.3 },
  todayBorder: { borderWidth: 1.5, borderColor: BLUE },
  todayBorderDashed: { borderColor: BLUE },
  dropIndicator: {
    position: 'absolute', top: 0, left: 16, right: 16, height: IND_H,
    borderRadius: 10, borderWidth: 1.5, borderStyle: 'dashed',
    borderColor: BLUE, backgroundColor: BLUE + '22', zIndex: 50,
  },
  dragOverlay: {
    position: 'absolute', top: 0, left: 16, right: 16,
    borderRadius: 10, overflow: 'hidden',
    elevation: 16, zIndex: 999, opacity: 0.96,
    shadowColor: '#000', shadowOpacity: 0.35, shadowRadius: 8, shadowOffset: { width: 0, height: 6 },
  },
  fabAdd: {
    position: 'absolute', right: 18, bottom: 18,
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: BLUE, alignItems: 'center', justifyContent: 'center',
    elevation: 8, zIndex: 900,
    shadowColor: '#000', shadowOpacity: 0.35, shadowRadius: 6, shadowOffset: { width: 0, height: 4 },
  },
  cardAccent: { height: 3, width: '100%' },
  cardBody: { flexDirection: 'row', alignItems: 'flex-start', padding: 12, gap: 10 },
  cardBodyWithFooter: { paddingBottom: 6 },
  cardFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 12, paddingBottom: 10 },
  cardIcon: { marginTop: 1 },
  iconChip: { width: 30, height: 30, borderRadius: 15, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center' },
  cardTitle: { color: '#fff', fontSize: 13, fontWeight: '700' },
  cardDesc: { color: '#F4F7FB', fontSize: 12, marginTop: 2, lineHeight: 17, fontWeight: '600' },
  metaText: { color: '#C3CDD9', fontSize: 12, marginTop: 3, fontWeight: '600' },
  metricsCard: {
    flexDirection: 'row', flexWrap: 'wrap', gap: 10,
    marginHorizontal: 16, marginBottom: 6,
    backgroundColor: '#101A28', borderWidth: 1, borderColor: BORDER,
    borderRadius: 14, paddingHorizontal: 12, paddingVertical: 9,
  },
  metricChip: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metricText: { color: '#8FA8C8', fontSize: 11 },
  emptySlot: {
    marginHorizontal: 16, marginBottom: 10,
    borderWidth: 1.5, borderColor: BORDER, borderStyle: 'dashed',
    borderRadius: 14, height: 38, alignItems: 'center', justifyContent: 'center',
  },
});