// screens/WorkoutDetailModal.js
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { Modal, View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, KeyboardAvoidingView, Platform, Alert, ActivityIndicator, Switch, useColorScheme, Image, Linking, Keyboard } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { doc, updateDoc, deleteDoc, arrayUnion, arrayRemove, Timestamp, getDoc, setDoc, addDoc, collection, getDocs, orderBy, where, increment, query, deleteField } from 'firebase/firestore';
import { auth, db } from '../firebaseConfig';
import { getCachedProfile } from '../services/profileCache';
import { getApiUrl } from '../services/api';
import { getCoachFullName, sendNotificationToAthlete } from '../services/coachNotify';
import { calcularEsfuerzoDesdeResumen } from '../services/SyncService';
import { invalidarCurvasEntreno } from '../services/analyticsEngine';
import { marcarPendiente, quitarDigest } from '../services/curvasStore';
import * as perfLog from '../services/perfLog';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getThemeColors, useAppSettings } from '../services/appSettings';
import ActivityChart from '../components/ActivityChart';
import VisorImagenZoom from '../components/VisorImagenZoom';
import RecordsBatidos from '../components/RecordsBatidos';
import {
  CurvaSkia, ChartCard, FullChartModal, TablaEsfuerzos,
  curvasDuracion, tiempoAcumuladoFC, mejoresEsfuerzos, remuestrearPorSegundo,
  DISTS_CURVA_RUN, DISTS_CURVA_BIKE, DISTS_TABLA_RUN, DISTS_TABLA_BIKE,
  fmtVentana, fmtPace, fmtAcum, duracionesCada10s, distanciasCada5m, promediarCurvas,
  duracionesParaMedia, distanciasParaMedia,
} from '../components/CurvasPicos';

// Ticks del eje X logarítmico, como en intervals.icu
const XT_FC = [{ v: 5, label: '5s' }, { v: 60, label: '1m' }, { v: 300, label: '5m' }, { v: 1200, label: '20m' }, { v: 3600, label: '1h' }];
const XT_KM_RUN = [{ v: 0.5, label: '500m' }, { v: 1, label: '1km' }, { v: 2, label: '2km' }, { v: 5, label: '5km' }, { v: 10, label: '10km' }, { v: 21, label: '21km' }];
const XT_KM_BIKE = [{ v: 5, label: '5km' }, { v: 10, label: '10km' }, { v: 20, label: '20km' }, { v: 40, label: '40km' }, { v: 60, label: '60km' }];
import AutoGrowTextInput from '../components/AutoGrowTextInput';
import PasosResumen from '../components/PasosResumen';
import VideoYouTube from '../components/VideoYouTube';
import LibreriaDrive, { PickerCarpetaLibreria } from '../components/LibreriaDrive';
import { libreriaStoreInit, libreriaStorePut } from '../services/libreriaStore';
import MonthPickerModal from '../components/MonthPickerModal';
import { zonasDeActividad } from '../services/zonas';
import { resolverPlanReal, computePlanMetrics as metricsPlan } from '../services/planReal';
import GpsMap from '../components/GpsMap';
import StepEditor, { normalizeStep, mascaraTiempoPaso, formatTimeInput } from '../components/StepEditor';
import SystemBars from '../components/SystemBars';
import * as DocumentPicker from 'expo-document-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import ArchivosPicker, { EjercicioViewer, PickerCarpetaArchivos } from '../components/ArchivosPicker';
import { subirArchivoDeEntreno } from '../services/archivosUpload';
import ActivityIcon from '../components/ActivityIcon';

const NAVY='#0D1B2A', CARD='#162032', BLUE='#4A90E2', GREEN='#2DB37A', RED='#E05252', BORDER='#1E3048';
// Caritas de sensación originales (emojis). Sin seleccionar se ven
// "apagadas" (filtro TV antiguas): en iOS en monocromo vía VS15 y en
// Android atenuadas; la seleccionada se ve a todo color y con su borde.
const SERVER_URL = 'https://garmin-fit-server.onrender.com';
// Exportadas: CalendarScreen las reutiliza para pintar la carita y el nº de
// carga percibida en el pie de la tarjeta del entreno.
export const MOODS = ['😫','😕','😐','🙂','😁'];
export const MOOD_COLORS = ['#E05252','#F5A623','#E9C46A','#7BC86C','#2DB37A'];
// Valores GUARDADOS en Firestore (no se traducen): se guarda el string ES y se pinta traducido
export const CARGAS = ['Muy baja','Baja','Moderada','Alta','Muy alta'];
const TIPOS_ACTIV = [
  { label:'Running', icon:'run', color:'#E05252' }, { label:'Ciclismo', icon:'bicycle', color:'#F5A623' },
  { label:'Natación', icon:'water', color:'#4A90E2' }, { label:'Fuerza', icon:'barbell', color:'#9B59B6' },
  { label:'Triatlón', icon:'medal-outline', color:'#2DB37A' }, { label:'Evento', icon:'trophy', color:'#4A90E2' },
  { label:'Descanso', icon:'moon', color:'#7F8FA6' },
  { label:'Notas', icon:'journal-outline', color:'#8D6E63' }, { label:'Otro', icon:'flash', color:'#8FA8C8' },
];
const TIPO_ICON = { Running:'run', Ciclismo:'bicycle', Natación:'water', Fuerza:'barbell', Triatlón:'medal-outline', Otro:'flash', Evento:'trophy', Descanso:'moon', Notas:'journal-outline' };
const TIPO_COLOR = { Running:'#E05252', Ciclismo:'#F5A623', Natación:'#4A90E2', Fuerza:'#9B59B6', Triatlón:'#2DB37A', Otro:'#8FA8C8', Evento:'#4A90E2', Descanso:'#7F8FA6' };

const formatSeconds = (s) => { if (s == null) return '—'; const h=Math.floor(s/3600), m=Math.floor((s%3600)/60), ss=Math.floor(s%60); return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(ss).padStart(2,'0')}`; };
const parseDuration = (t) => { const p = t.trim().split(':'); if (p.length===3) return (parseInt(p[0])||0)*3600+(parseInt(p[1])||0)*60+(parseInt(p[2])||0); if (p.length===2) return (parseInt(p[0])||0)*60+(parseInt(p[1])||0); const n=parseFloat(t); return isNaN(n)?null:Math.round(n*60); };
const formatFecha = (ts, loc) => { if (!ts) return '—'; const d = ts.toDate ? ts.toDate() : new Date(ts); return d.toLocaleDateString(loc,{day:'numeric',month:'short',year:'numeric'}); };
// Ritmo para mostrar: en Ciclismo siempre km/h (convierte pace legacy "MM:SS")
// Texto legible del origen del esfuerzo (TSS), para poder compararlo con
// TrainingPeaks / intervals.icu y saber si el número es fiable.
function fuenteEsfuerzoTexto(f) {
  switch (f) {
    case 'manual': return 'Manual (no se sobrescribirá al sincronizar)';
    case 'intervals.icu': return 'intervals.icu (TSS)';
    case 'archivo': return 'Archivo FIT';
    case 'potencia': return 'Potencia (TSS)';
    case 'ritmo': return 'Ritmo (rTSS)';
    case 'fc': return 'Frecuencia cardíaca (hrTSS)';
    case 'trimp': return 'Frecuencia cardíaca (TRIMP, algoritmo TrainerPlan)';
    case 'training-effect': return 'Training Effect de Garmin (aprox.)';
    default: return 'Sin calcular';
  }
}

function ritmoForDisplay(tipo, rit) {
  if (tipo !== 'Ciclismo' || rit == null || rit === '') return rit ?? '';
  const m = String(rit).trim().match(/^(\d{1,2}):(\d{1,2})$/);
  if (!m) return String(rit); // ya está en km/h
  const mins = parseInt(m[1], 10) + parseInt(m[2], 10) / 60;
  return mins > 0 ? (60 / mins).toFixed(1) : String(rit);
}
// Métricas planificadas desde los pasos (misma lógica que el matcher del server)
// zonasRitmo: zonas de ritmo del ATLETA — necesarias para estimar los km de
// los pasos de tiempo cuyo objetivo es una ZONA de ritmo ("R1", "CAMBIO"…):
// el ritmo medio de la zona (min/max del perfil) convierte tiempo → km.
//
// La implementación vive en services/planReal.js (compartida con las tarjetas
// de Home/Calendario): aquí se deja un envoltorio con la misma firma para no
// tocar el resto del modal y evitar dos copias que puedan divergir.
const computePlanMetrics = (pasos, zonasRitmo) => metricsPlan(pasos, zonasRitmo);

// Picker a pantalla completa: guarda `value ?? label` y pinta la etiqueta traducida
function FullScreenPicker({ value, options, onChange, placeholder='Escoge', iconTipo, icon, iconColor, title, cancelText }) {
  const insets = useSafeAreaInsets();
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const [visible, setVisible] = useState(false);
  const isObj = options[0] && typeof options[0] === 'object';
  const valOf = (o) => (isObj ? (o.value ?? o.label) : o);
  const lblOf = (o) => (isObj ? o.label : o);
  const select = (o) => { onChange(valOf(o)); setVisible(false); };
  const currentLabel = isObj ? (options.find(o => valOf(o) === value)?.label ?? value) : value;
  return (
    <>
      <TouchableOpacity style={[pk.btn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => setVisible(true)} activeOpacity={0.8}>
        <View style={pk.pickerLeft}>
          {iconTipo ? <ActivityIcon tipo={iconTipo} size={18} color={iconColor || '#8FA8C8'} style={{ marginRight: 8 }} /> : (icon ? <Ionicons name={icon} size={18} color={iconColor || '#8FA8C8'} style={{ marginRight: 8 }} /> : null)}
          <Text style={[pk.text, { color: currentLabel ? theme.text : theme.muted }]} numberOfLines={1}>{currentLabel || placeholder}</Text>
        </View>
        <Ionicons name="chevron-down" size={15} color="#8FA8C8" />
      </TouchableOpacity>
      <Modal visible={visible} animationType="slide" transparent={false}>
        <View style={[pk.fullScreen, { backgroundColor: theme.background }]}>
          <View style={[pk.fullHeader, { borderBottomColor: theme.border }]}>
            <Text style={[pk.fullTitle, { color: theme.text }]}>{title ?? 'Selecciona una opción'}</Text>
            <TouchableOpacity onPress={() => setVisible(false)}>
              <Ionicons name="close" size={24} color="#8FA8C8" />
            </TouchableOpacity>
          </View>
          <ScrollView style={pk.fullList}>
            {options.map((o, i) => {
              const sel = valOf(o) === value;
              return (
                <TouchableOpacity key={String(valOf(o))} style={[pk.fullOption, { borderBottomColor: theme.border }, sel && pk.fullOptionActive]} onPress={() => select(o)}>
                  <Text style={[pk.fullOptionIndex, { color: theme.muted }, sel && pk.fullOptionIndexActive]}>{i+1}</Text>
                  {isObj && o.icon ? <ActivityIcon tipo={valOf(o)} size={20} color={o.color || '#8FA8C8'} /> : null}
                  <Text style={[pk.fullOptionText, { color: theme.text }, sel && pk.fullOptionTextActive]}>{lblOf(o)}</Text>
                  {sel && <Ionicons name="checkmark" size={20} color={BLUE} />}
                </TouchableOpacity>
              );
            })}
          </ScrollView>
          <TouchableOpacity style={[pk.fullCancelBtn, { borderTopColor: theme.border, paddingBottom: 18 + insets.bottom }]} onPress={() => setVisible(false)}>
            <Text style={pk.fullCancelText}>{cancelText ?? 'Cancelar'}</Text>
          </TouchableOpacity>
        </View>
        <SystemBars />
      </Modal>
    </>
  );
}
const pk = StyleSheet.create({
  btn:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',backgroundColor:CARD,borderRadius:6,borderWidth:1,borderColor:BORDER,paddingHorizontal:12,paddingVertical:12,marginVertical:4},
  pickerLeft:{flexDirection:'row',alignItems:'center',flex:1}, text:{color:'#fff',fontSize:14,flex:1}, ph:{color:'#4A6080'},
  fullScreen:{flex:1,backgroundColor:NAVY},
  fullHeader:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingTop:56,paddingHorizontal:20,paddingBottom:16,borderBottomWidth:1,borderBottomColor:BORDER},
  fullTitle:{color:'#fff',fontSize:18,fontWeight:'700'}, fullList:{flex:1,paddingHorizontal:16},
  fullOption:{flexDirection:'row',alignItems:'center',paddingVertical:16,paddingHorizontal:12,borderBottomWidth:1,borderBottomColor:BORDER,gap:14},
  fullOptionActive:{backgroundColor:BLUE+'22',borderRadius:8},
  fullOptionIndex:{color:'#8FA8C8',fontSize:16,fontWeight:'600',minWidth:24}, fullOptionIndexActive:{color:BLUE},
  fullOptionText:{color:'#fff',fontSize:16,flex:1}, fullOptionTextActive:{color:BLUE,fontWeight:'700'},
  fullCancelBtn:{paddingVertical:18,alignItems:'center',borderTopWidth:1,borderTopColor:BORDER,marginTop:8},
  fullCancelText:{color:RED,fontSize:16,fontWeight:'600'},
});


// Borra el evento planificado de Intervals.icu al borrar el entreno en la app.
// Si falla (sin red), lo encola en perfiles.pendingDeletes y el sync lo limpia.
async function notifyIntervalsDelete(w) {
  const eid = w && w.intervalsEventId;
  if (!eid) return;
  try {
    const apiUrl = (await getApiUrl()).replace(/\/+$/, '');
    const token = await auth.currentUser.getIdToken();
    const r = await fetch(`${apiUrl}/intervals/delete-event`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      // El evento vive en el calendario de intervals.icu del DUEÑO del doc
      // (el atleta cuando el coach lo creó en su calendario): el servidor
      // debe borrarlo con la conexión de ese destino, no con la del coach.
      body: JSON.stringify({ eventId: eid, targetUid: w.userId || undefined }),
    });
    if (!r.ok) throw new Error('http ' + r.status);
  } catch (e) {
    // Offline: encolar en el perfil del DUEÑO del calendario — su sync
    // procesa pendingDeletes con SU conexión de intervals.icu.
    try {
      await setDoc(doc(db, 'perfiles', w.userId || auth.currentUser.uid), { pendingDeletes: arrayUnion(eid) }, { merge: true });
    } catch (e2) {}
  }
}

export default function WorkoutDetailModal({ visible, workout, onClose, onWorkoutUpdated, athleteId }) {
  const insets = useSafeAreaInsets();
  const appSettings = useAppSettings();
  const lang = appSettings.language;            // re-renderiza al cambiar idioma
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción
  const loc = lang === 'en' ? 'en-US' : 'es-ES';

  // ── Permisos de edición ──
  // El candado de "solo el creador" aplica ÚNICAMENTE a EVENTOS: un evento que
  // el coach crea para sus atletas no lo pueden editar ni mover ellos (ni
  // borrarlo). Cualquier OTRO tipo de entreno que el coach programe en el
  // calendario del atleta es de acceso COMPLETO para el atleta: editar,
  // mover y borrar. El coach conserva acceso total viendo el calendario
  // de un atleta (athleteId distinto del suyo).
  const miUid = auth.currentUser?.uid;
  const esCoachContexto = !!athleteId && athleteId !== miUid;
  // El creador real es `creadoPor` (se guarda al crear el entreno). En
  // documentos antiguos se usa `userId` como referencia, salvo que el dueño
  // aparezca en `asignados`: esa combinación solo se da en eventos que el
  // coach creó directamente en el calendario del atleta (antes de que se
  // guardara `creadoPor`), así que el creador se considera el coach.
  const creadoPorCoachLegacy = !workout?.creadoPor && !!workout?.userId
    && Array.isArray(workout?.asignados) && workout.asignados.includes(workout.userId);
  const creadorUid = workout?.creadoPor || (creadoPorCoachLegacy ? null : workout?.userId);
  const esCreadorEntreno = !workout?.userId || creadorUid === miUid;
  // Dueño/apuntado del documento: para todo lo que no sea Evento tiene acceso
  // completo aunque lo haya creado el coach.
  const soyDestinatario = workout?.userId === miUid
    || (Array.isArray(workout?.asignados) && workout.asignados.includes(miUid));
  const puedeEditarEntreno = esCreadorEntreno || esCoachContexto
    || (soyDestinatario && workout?.tipo !== 'Evento');

  // Opciones traducidas (el valor guardado sigue siendo el original en español)
  const CARGA_OPTS = CARGAS.map(c => ({ value: c, label: ({'Muy baja':L('Muy baja','Very low'),'Baja':L('Baja','Low'),'Moderada':L('Moderada','Moderate'),'Alta':L('Alta','High'),'Muy alta':L('Muy alta','Very high')})[c] }));
  const HORA_OPTS = [
    { value:'Mañana', label:L('Mañana','Morning') },
    { value:'Tarde', label:L('Tarde','Afternoon') },
    { value:'Personalizado', label:L('Personalizado','Custom') },
  ];
  const SUBTAB_LABEL = { general:L('General','General'), vueltas:L('Vueltas','Laps'), detalles:L('Detalles','Details'), zonas:L('Zonas','Zones'), curvafc:L('Curva FC','HR curve'), curvaritmo:L('Curva ritmo','Pace curve'), picos:L('Picos','Peaks') };
  const LAP_HEADERS = [L('Vuelta','Lap'),L('Distancia','Distance'),L('Tiempo','Time'),L('Ritmo Med','Avg Pace'),L('Ritmo Máx','Max Pace'),L('FC Med','Avg HR'),L('FC Máx','Max HR'),L('Cad. Med','Avg Cad'),L('Cad. Máx','Max Cad'),L('Gan. Elev','Elev Gain'),L('Pér. Elev','Elev Loss'),L('Dif. Elev','Elev Diff')];

  const [mode, setMode] = useState('view');
  const [mainTab, setMainTab] = useState('sesion');
  const [subTab, setSubTab] = useState('general');
  const [modoZonas, setModoZonas] = useState('pct'); // 'pct' | 'tiempo' | 'km' en la pestaña Zonas
  const [estado, setEstado] = useState(null);
  // Entreno PROGRAMADO (plan sin realizar): sin marca de sync y sin estado
  // marcado a mano. A estos no se les muestra la parte de datos
  // (general/vueltas/detalles/zonas) porque no tienen nada grabado todavía.
  const esProgramado = !!workout && !workout.estado && !workout.mergedFromPlanId
    && !workout.source && !workout.intervalsId
    && !/intervals_|\.fit$/i.test(String(workout.id_archivo || ''));
  // Cambios recién guardados en EDITAR: la vista "Sesión" se pinta del
  // objeto `workout` que trae el padre (snapshot antiguo hasta que el padre
  // refresque), así que tras guardar se parchea localmente y la vista
  // refleja los cambios al instante, sin cerrar y reabrir.
  const [patchVista, setPatchVista] = useState(null);
  const wV = workout ? { ...workout, ...(patchVista || {}) } : workout;
  const [originalFechaStr, setOriginalFechaStr] = useState('');
  const [durSec, setDurSec] = useState(null);
  const [durText, setDurText] = useState('');
  const [distancia, setDistancia] = useState('');
  const [ritmo, setRitmo] = useState('');
  const [fc, setFc] = useState('');
  const [fcMax, setFcMax] = useState('');
  const [elevMin, setElevMin] = useState('');
  const [elevMax, setElevMax] = useState('');
  const [carga, setCarga] = useState(null);
  const [esfuerzo, setEsfuerzo] = useState('');
  const [esfuerzoFuente, setEsfuerzoFuente] = useState(null); // de dónde sale el número
  const [esfuerzoOriginal, setEsfuerzoOriginal] = useState(''); // para detectar edición manual
  const [recalculando, setRecalculando] = useState(false);
  const [enlace, setEnlace] = useState('');
  const [sensacion, setSensacion] = useState(null); // sin carita seleccionada por defecto
  const [loading, setLoading] = useState(false);
  const [actividad, setActividad] = useState('Running');
  const [titulo, setTitulo] = useState('');
  const [fechaStr, setFechaStr] = useState('');
  const [horaMode, setHoraMode] = useState('Mañana');
  const [horaCustom, setHoraCustom] = useState('08:00');
  const [descripcion, setDescripcion] = useState('');
  const [archivos, setArchivos] = useState([]);        // adjuntos (R2 / gimnasio)
  const [pickerArch, setPickerArch] = useState(false);
  // Teclado arriba: los pies fijos (Guardar/Borrar) se ocultan para que el
  // sheet NO "suba" con el teclado; el scroll deja a la vista el campo activo.
  const [kbOpen, setKbOpen] = useState(false);
  const [subiendoArch, setSubiendoArch] = useState(false);
  const [viewerGym, setViewerGym] = useState(null);    // { id, nombre } del visor de ejercicio
  const [visorImg, setVisorImg] = useState(null);      // { url } imagen/gif a pantalla completa

  const [pendienteArch, setPendienteArch] = useState(null);   // asset esperando carpeta
  const [carpetaPickOpen, setCarpetaPickOpen] = useState(false);

  useEffect(() => {
    const show = Keyboard.addListener('keyboardDidShow', () => setKbOpen(true));
    const hide = Keyboard.addListener('keyboardDidHide', () => setKbOpen(false));
    return () => { show.remove(); hide.remove(); };
  }, []);

  // "Cargar archivo": 1) dispositivo → 2) carpeta de tu librería → 3) R2 + entreno.
  const cargarArchivoDirecto = async () => {
    try {
      const res = await DocumentPicker.getDocumentAsync({ copyToCacheDir: true });
      if (!res || res.canceled || !res.assets || !res.assets[0]) return;
      setPendienteArch(res.assets[0]);
      setCarpetaPickOpen(true);
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };
  const confirmarSubidaArch = async (carpetaId) => {
    const a = pendienteArch;
    setPendienteArch(null);
    if (!a) return;
    setSubiendoArch(true);
    try {
      const e = await subirArchivoDeEntreno(auth.currentUser, {
        uri: a.uri, nombre: a.name || 'archivo', contentType: a.mimeType || 'application/octet-stream', size: a.size || 0, carpeta: carpetaId,
      });
      setArchivos((xs) => [...xs, { id: e.id, tipo: e.tipo, url: e.url, nombre: e.nombre, thumb: (e.tipo === 'imagen' || e.tipo === 'gif') ? e.url : null, size: e.size }]);
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
    finally { setSubiendoArch(false); }
  };
  const abrirAdjunto = (a) => {
    if (a.tipo === 'ejercicio') setViewerGym({ id: a.gymId, nombre: a.nombre });
    else if (a.tipo === 'imagen' || a.tipo === 'gif') setVisorImg({ url: a.url });
    else if (a.url) Linking.openURL(a.url).catch(() => {});
  };
  const [pasos, setPasos] = useState([]);
  const [cadencia, setCadencia] = useState('');
  const [desnivelPos, setDesnivelPos] = useState('');
  const [temperatura, setTemperatura] = useState('');
  const [fcZones, setFcZones] = useState([]);
  const [ritmoZones, setRitmoZones] = useState([]);
  const [potZones, setPotZones] = useState([]);      // zonas de potencia del atleta
  const [vueltas, setVueltas] = useState([]);
  const [registros, setRegistros] = useState(null);
  const [registrosLoaded, setRegistrosLoaded] = useState(false);
  const [loadingRegistros, setLoadingRegistros] = useState(false);
  const [loadingHeavyData, setLoadingHeavyData] = useState(false);
  const [comentario, setComentario] = useState('');
  const [comentarios, setComentarios] = useState([]);
  const [saveLib, setSaveLib] = useState(false); // switch "Añadir a librería"
  const [libDocId, setLibDocId] = useState(null); // doc de libreria creado por el switch
  const [nuevaPlantilla, setNuevaPlantilla] = useState(false); // creando sesión NUEVA para la librería
  const [libOrigenId, setLibOrigenId] = useState(null);   // sesión de librería en edición
  const libItemRef = useRef(null);                 // sesión completa en edición (para reflejar el guardado en el almacén local)
  const [pickerLib, setPickerLib] = useState(null);       // { accion } selector de carpeta destino
  const [calFecha, setCalFecha] = useState(false);        // calendario para elegir la fecha
  const [sendingComm, setSendingComm] = useState(false);
  const [savingLib, setSavingLib] = useState(false);
  const [currentUserName, setCurrentUserName] = useState('');
  // ── Reasignar a otro planificado del día / Separar fusión ──
  const [reassignOpen, setReassignOpen] = useState(false);
  const [asignados, setAsignados] = useState([]);          // uids de atletas apuntados al evento
  const asignadosInicialesRef = useRef([]);                 // selección persistida al abrir el detalle
  const [misAtletas, setMisAtletas] = useState([]);        // lista de atletas del coach (endpoint)
  const [loadingAtletas, setLoadingAtletas] = useState(false);
  const [buscaAtletaEv, setBuscaAtletaEv] = useState('');   // buscador de atletas del evento
  const [buscaAbiertaEv, setBuscaAbiertaEv] = useState(false); // lupa: muestra/oculta el buscador
  const [perfilesAsignados, setPerfilesAsignados] = useState({});
  const [marcasData, setMarcasData] = useState({ defs: [], results: {}, bests: {} }); // récords batidos del entreno
  const [dayPlans, setDayPlans] = useState([]);
  const actSel = TIPOS_ACTIV.find(t => t.label === actividad) || TIPOS_ACTIV[0];

  const cargarRegistros = useCallback(async () => {
    if (!workout?.id || registrosLoaded || loadingRegistros) return;
    setLoadingRegistros(true);
    try { const s = await getDoc(doc(db,'entrenamientos',workout.id,'registros','data')); if (s.exists()) { const pts = s.data().puntos ?? []; pts.sort((a,b) => new Date(a.timestamp)-new Date(b.timestamp)); setRegistros(pts); setRegistrosLoaded(true); } } catch (e) {} finally { setLoadingRegistros(false); }
  }, [workout?.id, registrosLoaded, loadingRegistros]);
  // Curva FC / Curva ritmo / Picos también consumen `registros`: antes solo se
  // cargaban en Detalles y Zonas, así que al entrar directamente en una pestaña
  // de curvas salía «sin datos». Ahora es seguro porque los cálculos de
  // CurvasPicos.js van con escalas logarítmicas (hasta 29× menos datos).
  useEffect(() => { if ((subTab === 'detalles' || subTab === 'zonas' || subTab === 'curvafc' || subTab === 'curvaritmo' || subTab === 'picos') && visible) cargarRegistros(); }, [subTab, visible, cargarRegistros]);

  const fcDistribution = useMemo(() => { if (!registros || registros.length < 2 || !fcZones.length) return []; const d = fcZones.map(z => ({...z, time:0, dist:0})); for (let i=1;i<registros.length;i++){ const f=registros[i].frecuencia; const dt=(new Date(registros[i].timestamp)-new Date(registros[i-1].timestamp))/1000; for (const z of d){ if (f >=z.min && f <z.max){ z.time+=dt; const sp=Number(registros[i].velocidad)||0; if (sp>0) z.dist+=(dt*sp)/3600; break; } } } return d; }, [registros, fcZones]);
  const ritmoDistribution = useMemo(() => { if (!registros || registros.length < 2 || !ritmoZones.length) return []; const zs = ritmoZones.map(z => { const s1 = z.min ? z.min.split(':').reduce((a,b)=>Number(a)*60+Number(b),0) : 0; const s2 = z.max ? z.max.split(':').reduce((a,b)=>Number(a)*60+Number(b),0) : Infinity; return {...z, minSec:Math.min(s1,s2), maxSec:Math.max(s1,s2)}; }); const d = ritmoZones.map(z => ({...z, time:0, dist:0})); for (let i=1;i<registros.length;i++){ const sp=registros[i].velocidad; if (sp <=0) continue; const rs=(60/sp)*60; const dt=(new Date(registros[i].timestamp)-new Date(registros[i-1].timestamp))/1000; for (const z of zs){ if (rs >=z.minSec && rs <z.maxSec){ const f=d.find(x=>x.id===z.id); if (f){ f.time+=dt; f.dist+=(dt*sp)/3600; } break; } } } return d; }, [registros, ritmoZones]);
  // Curvas de distribución y picos (medias móviles) desde los registros,
  // mismo método que intervals.icu/TrainerPlan (streams → best efforts).
  // Curvas de duración (mejores medias móviles) y mejores esfuerzos por
  // distancia, el modelo de intervals.icu/TrainerPlan, desde los registros.
  // Las gráficas trabajan a 1 Hz; el stream original se conserva para mapa
  // y para no alterar los datos FIT guardados.
  // El remuestreo a 1 Hz solo lo consume ActivityChart (pestaña Detalles) y
  // cuesta una copia interpolada de todo el stream: se calcula únicamente ahí.
  const registrosGrafica = useMemo(() => (subTab === 'detalles' ? remuestrearPorSegundo(registros) : []), [registros, subTab]);
  // Las curvas de rendimiento trabajan sobre el stream FIT ORIGINAL: las medias
  // de curvasDuracion/mejoresEsfuerzos ya están ponderadas por tiempo, así que
  // el resultado es el mismo que con el stream remuestreado (verificado punto a
  // punto: 0,00 px de diferencia) sin copiar ni interpolar miles de puntos.
  const registrosCurva = useMemo(() => {
    if (!Array.isArray(registros) || registros.length < 2) return [];
    // cargarRegistros() ya ordena por tiempo; esto solo cubre el caso raro de
    // registros antiguos servidos desde el doc principal sin ordenar.
    let ordenado = true;
    for (let i = 1; i < registros.length; i++) {
      const a = registros[i - 1].timestamp, b = registros[i].timestamp;
      if (typeof a === 'string' && typeof b === 'string' && a.length === b.length) { if (b < a) { ordenado = false; break; } } else if (new Date(b) < new Date(a)) { ordenado = false; break; }
    }
    return ordenado ? registros : registros.slice().sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
  }, [registros]);
  const maxCurvaSec = useMemo(() => {
    if (registrosCurva.length < 2) return 0;
    return (new Date(registrosCurva[registrosCurva.length - 1].timestamp) - new Date(registrosCurva[0].timestamp)) / 1000;
  }, [registrosCurva]);
  // Línea DEL ENTRENO con la escala COMPLETA de siempre (1 ventana cada 10 s,
  // 1 distancia cada 5 m): sin generalizar. Cada curva pesada se calcula SOLO
  // en la pestaña que la dibuja (mismo criterio que registrosGrafica con
  // Detalles): abrir Detalles/Zonas no dispara ningún cálculo de curvas.
  // RONDA 43: cada memo de cálculo va entre try/catch → si un stream viniera
  // corrupto o surgiera cualquier excepción imprevista, la pestaña enseña
  // «sin datos» en vez de reventar (la excepción dentro de un memo de React
  // desmonta el árbol entero = pantalla negra, que es lo que no queremos).
  const curvaDuraciones = useMemo(() => duracionesCada10s(maxCurvaSec), [maxCurvaSec]);
  const curvas = useMemo(() => { try { return subTab === 'curvafc' ? curvasDuracion(registrosCurva, curvaDuraciones) : []; } catch (e) { return []; } }, [registrosCurva, curvaDuraciones, subTab]);
  const curvaFcPts = useMemo(() => curvas.filter((c) => c.fc > 0).map((c) => ({ x: c.w, v: Math.round(c.fc) })), [curvas]);
  const acumFcPts = useMemo(() => { try { return subTab === 'curvafc' ? tiempoAcumuladoFC(registrosCurva, 10) : []; } catch (e) { return []; } }, [registrosCurva, subTab]);
  const maxCurvaKm = useMemo(() => Number(registrosCurva[registrosCurva.length - 1]?.distancia) || 0, [registrosCurva]);
  const curvaDistancias = useMemo(() => distanciasCada5m(maxCurvaKm), [maxCurvaKm]);
  const esfuerzosCurva = useMemo(() => { try { return subTab === 'curvaritmo' ? mejoresEsfuerzos(registrosCurva, curvaDistancias) : []; } catch (e) { return []; } }, [registrosCurva, curvaDistancias, subTab]);
  const curvaRitmoPts = useMemo(() => esfuerzosCurva.map((e) => ({ x: e.d, v: actividad === 'Ciclismo' ? Math.round(e.speed * 10) / 10 : Math.round(e.pace * 10) / 10 })), [esfuerzosCurva, actividad]);
  const esfuerzos = useMemo(() => { try { return subTab === 'picos' ? mejoresEsfuerzos(registrosCurva, actividad === 'Ciclismo' ? DISTS_TABLA_BIKE : DISTS_TABLA_RUN) : []; } catch (e) { return []; } }, [registrosCurva, actividad, subTab]);
  // Línea de MEDIA histórica: MISMA escala reducida que en la RONDA 41 (no
  // cambia: referencia suave, ~45 ventanas / ≤71 distancias).
  const venMedia = useMemo(() => duracionesParaMedia(maxCurvaSec), [maxCurvaSec]);
  const disMedia = useMemo(() => distanciasParaMedia(maxCurvaKm), [maxCurvaKm]);
  const [fullChart, setFullChart] = useState(null);   // 'fc' | 'acum' | 'ritmo'
  const [curveDays, setCurveDays] = useState(null); // null = media DESACTIVADA por defecto (se calcula al elegir 42/90/365)
  const [curveHistory, setCurveHistory] = useState({ fc: null, ritmo: null });
  const zonasFc = useMemo(() => (fcZones || []).map((z, i) => ({ min: Number(z.min) || 0, max: Number(z.max) || 9999, label: `Z${i + 1}` })), [fcZones]);
  // Distribución de POTENCIA: igual que FC/ritmo, pero con zonas en vatios y
  // solo si el entreno tiene datos de potencia en los registros.
  const tienePotencia = useMemo(() => (registros || []).some((r) => Number(r.potencia) > 0), [registros]);
  const potDistribution = useMemo(() => {
    if (!registros || registros.length < 2 || !potZones.length || !tienePotencia) return [];
    const zs = potZones
      .map((z) => ({ ...z, minW: Number(z.min), maxW: Number.isFinite(Number(z.max)) && Number(z.max) > 0 ? Number(z.max) : Infinity }))
      .filter((z) => Number.isFinite(z.minW));
    if (!zs.length) return [];
    const d = zs.map((z) => ({ ...z, time: 0, dist: 0 }));
    for (let i = 1; i < registros.length; i++) {
      const w = Number(registros[i].potencia);
      if (!(w > 0)) continue;
      const dt = (new Date(registros[i].timestamp) - new Date(registros[i - 1].timestamp)) / 1000;
      for (const z of d) {
        if (w >= z.minW && w < z.maxW) { z.time += dt; const sp = Number(registros[i].velocidad) || 0; if (sp > 0) z.dist += (dt * sp) / 3600; break; }
      }
    }
    return d;
  }, [registros, potZones, tienePotencia]);

  useEffect(() => {
    if (!visible || !workout?.id || !['curvafc', 'curvaritmo'].includes(subTab)) return undefined;
    // Media DESACTIVADA: no se busca ni calcula nada hasta elegir periodo
    if (curveDays == null) return undefined;
    let cancelled = false;
    (async () => {
      try {
        const owner = workout.userId || athleteId || auth.currentUser?.uid;
        const end = workout.fecha?.toDate ? workout.fecha.toDate() : new Date(workout.fecha || Date.now());
        const start = new Date(end.getTime() - curveDays * 86400000);
        // A6 (H6): consulta ACOTADA por fecha (índice compuesto userId+fecha,
        // el mismo de Home/analytics) + límite 30 + mismo filtro en cliente.
        const snap = await getDocs(query(
          collection(db, 'entrenamientos'),
          where('userId', '==', owner),
          where('fecha', '>=', Timestamp.fromDate(start)),
          where('fecha', '<=', Timestamp.fromDate(end)),
          orderBy('fecha', 'desc'),
          limit(30),
        ));
        perfLog.contar('wdm.curvaMedia.resumenes', snap.size, perfLog.bytesDe(snap.docs.map((d) => d.data())));
        const candidates = snap.docs.map((d) => ({ id: d.id, ...d.data() })).filter((w) => {
          const wf = w.fecha?.toDate ? w.fecha.toDate() : new Date(w.fecha || 0);
          return w.id !== workout.id && w.estado === 'completo' && wf >= start && wf <= end;
        }).sort((a, b) => {
          const da = a.fecha?.toDate ? a.fecha.toDate() : new Date(a.fecha || 0);
          const dbb = b.fecha?.toDate ? b.fecha.toDate() : new Date(b.fecha || 0);
          return dbb - da;
        }).slice(0, 12);
        const streams = await Promise.all(candidates.map(async (w) => {
          try {
            const s = await getDoc(doc(db, 'entrenamientos', w.id, 'registros', 'data'));
            if (!s.exists()) return [];
            perfLog.contar('wdm.curvaMedia.registros', 1, perfLog.bytesDe(s.data()));
            const pts = s.data().puntos || [];
            pts.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
            return pts;
          } catch (e) { return []; }
        }));
        // La línea de media es una referencia SUAVE: se calcula con la escala
        // reducida de siempre (duracionesParaMedia/distanciasParaMedia) y solo
        // de la pestaña abierta, cediendo el hilo JS entre entreno y entreno
        // para que la interfaz siga respondiendo.
        const ven = subTab === 'curvafc' ? venMedia : [];
        const dis = subTab === 'curvaritmo' ? disMedia : [];
        const fcSeries = [];
        const paceSeries = [];
        for (let i = 0; i < streams.length; i++) {
          if (cancelled) return;
          const r = streams[i];
          if (r && r.length > 1) {
            if (ven.length) fcSeries.push(curvasDuracion(r, ven).filter((p) => p.fc > 0).map((p) => ({ x: p.w, v: p.fc })));
            if (dis.length) paceSeries.push(mejoresEsfuerzos(r, dis).map((p) => ({ x: p.d, v: actividad === 'Ciclismo' ? p.speed : p.pace })));
          }
          await new Promise((resolve) => setTimeout(resolve, 0));
        }
        if (!cancelled) setCurveHistory({ fc: promediarCurvas(fcSeries), ritmo: promediarCurvas(paceSeries) });
      } catch (e) { if (!cancelled) setCurveHistory({ fc: null, ritmo: null }); }
    })();
    return () => { cancelled = true; };
  }, [visible, workout?.id, workout?.fecha, workout?.userId, athleteId, subTab, curveDays, venMedia, disMedia, actividad]);

  // Recalculo de la Medida del planificado cuando llegan las ZONAS DE RITMO
  // del atleta (el perfil se carga asíncrono): los km de los pasos de tiempo
  // con objetivo "Zona ritmo" se estiman con el ritmo medio de esa zona.
  useEffect(() => {
    if (!workout || !visible || !esProgramado) return;
    // Plan resuelto: pasos → y si los pasos no dan km/tiempo, la medida que el
    // coach escribió a mano en el planificado (workout.distancia/duracion).
    // Se pasa la actividad: en Ciclismo los objetivos/zona de ritmo van en km/h.
    const plan = resolverPlanReal(workout, ritmoZones, actividad || workout.tipo);
    if (plan.dur > 0) { setDurSec(Math.round(plan.dur)); setDurText(formatSeconds(Math.round(plan.dur))); }
    if (plan.dist > 0) setDistancia(String(Math.round(plan.dist * 100) / 100));
    else if (!workout.distancia) setDistancia('');
  }, [workout, visible, esProgramado, ritmoZones]);

  useEffect(() => {
    if (!workout || !visible) return;
    setPatchVista(null);
    setRegistros(null); setRegistrosLoaded(true); setFcZones([]); setRitmoZones([]); setPotZones([]); setVueltas([]); setLoadingHeavyData(false);
    setEstado(workout.estado ?? null);
    let ns = workout.duracion ?? null;   // duracion se guarda SIEMPRE en segundos
    let distTxt = workout.distancia?.toString() ?? '';
    // Programado: la Medida muestra el PLAN — métricas calculadas desde los
    // pasos (misma lógica que el matcher del servidor) — no los ceros guardados.
    if (esProgramado) {
      const plan = resolverPlanReal(workout, ritmoZones, actividad || workout.tipo);
      if (plan.dur > 0) ns = Math.round(plan.dur);
      if (plan.dist > 0) distTxt = String(Math.round(plan.dist * 100) / 100);
      else if (!workout.distancia) distTxt = '';   // plan sin km → '—', no "0 km"
    }
    setDurSec(ns); setDurText(ns ? formatSeconds(ns) : '');
    setDistancia(distTxt); setRitmo(ritmoForDisplay(workout.tipo, workout.ritmo));
    setFc((workout['fc-media'] ?? workout.fc)?.toString() ?? ''); setFcMax(workout.fcMax?.toString() ?? '');
    setElevMin(workout.elevacionMin?.toString() ?? ''); setElevMax(workout.elevacionMax?.toString() ?? '');
    setCarga(workout.cargaPercibida ?? null);
    const esfIni = Number(workout.esfuerzo) > 0 ? workout.esfuerzo.toString() : '';
    setEsfuerzo(esfIni); setEsfuerzoOriginal(esfIni);
    setEsfuerzoFuente(workout.esfuerzoFuente ?? (workout.esfuerzoManual ? 'manual' : null));
    setEnlace(workout.enlace ?? ''); setSensacion(workout.sensacion ?? null);
    setActividad(workout.tipo ?? 'Running'); setTitulo(workout.titulo ?? workout.tipo ?? '');
    setDescripcion(workout.descripcion ?? ''); setArchivos(Array.isArray(workout.archivos) ? workout.archivos : []); setPasos(workout.pasos ?? []); setComentarios(workout.comentarios ?? []); setSaveLib(false); setLibDocId(null); setReassignOpen(false);
    const uidsEvt = Array.isArray(workout.asignados) ? workout.asignados : [];
    setAsignados(uidsEvt);
    asignadosInicialesRef.current = uidsEvt.slice();
    setPerfilesAsignados({});
    setMisAtletas([]);
    if (workout.tipo === 'Evento') {
      (async () => {
        const objs = {};
        for (const u of uidsEvt) {
          try {
            const c = await getCachedProfile(u);
            if (c) { objs[u] = c; continue; }
            const s2 = await getDoc(doc(db, 'perfiles', u));
            if (s2.exists()) objs[u] = s2.data();
          } catch (e) {}
        }
        setPerfilesAsignados(objs);
      })();
      // Cargar la lista de atletas si el evento es mío o si soy el coach
      // viendo el calendario de un atleta (evento creado en su perfil).
      if (workout.userId === auth.currentUser?.uid || (athleteId && athleteId !== auth.currentUser?.uid)) {
        setLoadingAtletas(true);
        (async () => {
          try {
            const r = await fetch(`${SERVER_URL}/coach-screen-data/${auth.currentUser.uid}`);
            if (r.ok) { const d = await r.json(); setMisAtletas(d.atletas || []); }
          } catch (e) {}
          setLoadingAtletas(false);
        })();
      }
    }
    setCadencia(workout.cadencia?.toString() ?? ''); setDesnivelPos(workout.desnivelPos?.toString() ?? ''); setTemperatura(workout.temperatura?.toString() ?? '');
    const fd = workout.fecha?.toDate ? workout.fecha.toDate() : new Date(workout.fecha ?? Date.now());
    setFechaStr(fd.toLocaleDateString('es-ES')); setOriginalFechaStr(fd.toLocaleDateString('es-ES'));
    const hh = fd.getHours();
    if (hh === 8) { setHoraMode('Mañana'); setHoraCustom('08:00'); }
    else if (hh === 18) { setHoraMode('Tarde'); setHoraCustom('18:00'); }
    else { setHoraMode('Personalizado'); setHoraCustom(`${String(hh).padStart(2,'0')}:${String(fd.getMinutes()).padStart(2,'0')}`); }
    setMode('view'); setMainTab('sesion'); setSubTab('general'); setComentario('');
    (async () => {
      // El nombre del comentario siempre pertenece al usuario que está usando
      // la app. athleteId solo decide de qué perfil se leen las zonas.
      const meUid = auth.currentUser?.uid;
      const profileUid = athleteId || meUid;
      const meProfile = meUid ? await getCachedProfile(meUid) : null;
      setCurrentUserName(meProfile?.nombre || auth.currentUser?.displayName || 'Tú');
      const c = profileUid ? await getCachedProfile(profileUid) : null;
      const cargaPot = (prof) => setPotZones(zonasDeActividad(prof, 'Potencia', workout.tipo));
      // Récords batidos en este entreno: marcasBest lleva el workoutId de
      // origen y lo mantiene el servidor, así que se lee SIEMPRE el doc
      // fresco (la caché del perfil puede ir por detrás).
      const cargaMarcas = (prof) => setMarcasData({
        defs: Array.isArray(prof?.marcasDefs) ? prof.marcasDefs : [],
        results: (prof?.marcasResults && typeof prof.marcasResults === 'object') ? prof.marcasResults : {},
        bests: (prof?.marcasBest && typeof prof.marcasBest === 'object') ? prof.marcasBest : {},
      });
      if (c) { setFcZones(zonasDeActividad(c, 'FC', workout.tipo)); setRitmoZones(zonasDeActividad(c, 'Ritmo', workout.tipo)); cargaPot(c); cargaMarcas(c); }
      else if (profileUid) { try { const s = await getDoc(doc(db,'perfiles',profileUid)); if (s.exists()) { const d = s.data(); setFcZones(zonasDeActividad(d, 'FC', workout.tipo)); setRitmoZones(zonasDeActividad(d, 'Ritmo', workout.tipo)); cargaPot(d); cargaMarcas(d); } } catch (e) {} }
      if (profileUid) { try { const sM = await getDoc(doc(db,'perfiles',profileUid)); if (sM.exists()) cargaMarcas(sM.data()); } catch (e) {} }
    })();
    (async () => {
      setLoadingHeavyData(true);
      try {
        // El prop `workout` puede venir de la caché de 5 min del calendario:
        // se lee el doc FRESCO al montar para que los kg/ticks de fuerza
        // (y estado/archivos) se vean aunque se guardaran con la app cerrada.
        try {
          const fresh = await getDoc(doc(db, 'entrenamientos', workout.id));
          if (fresh.exists()) {
            const fd = fresh.data();
            setPatchVista((pv) => ({
              ...(pv || {}),
              pasos: fd.pasos ?? (pv && pv.pasos) ?? [],
              estado: fd.estado ?? null,
              descripcion: fd.descripcion ?? '',
              archivos: fd.archivos ?? [],
              duracion: fd.duracion ?? null,
            }));
            setEstado(fd.estado ?? null);
            setArchivos(Array.isArray(fd.archivos) ? fd.archivos : []);
            // El campo Duración se init desde el prop (que puede venir
            // cachado/stale): se sincroniza también con el doc fresco para
            // que el tiempo registrado al Guardar se vea al reabrir.
            if (fd.duracion != null) { setDurSec(fd.duracion); setDurText(formatSeconds(fd.duracion)); }
          }
        } catch (e) {}
        const det = await getDoc(doc(db,'entrenamientos',workout.id,'detalles','data'));
        if (det.exists()) { const d = det.data();
          if (d.ritmo) setRitmo(ritmoForDisplay(workout.tipo, d.ritmo)); if (d.fcMax) setFcMax(d.fcMax.toString());
          if (d.elevacionMin != null) setElevMin(d.elevacionMin.toString()); if (d.elevacionMax != null) setElevMax(d.elevacionMax.toString());
          if (d.cadencia) setCadencia(d.cadencia.toString()); if (d.desnivelPos) setDesnivelPos(d.desnivelPos.toString()); if (d.temperatura) setTemperatura(d.temperatura.toString());
          if (d.cargaPercibida) setCarga(d.cargaPercibida); if (d.enlace) setEnlace(d.enlace);
          if (d.esfuerzo != null && Number(d.esfuerzo) > 0) {
            const esfDet = String(d.esfuerzo);
            setEsfuerzo(esfDet); setEsfuerzoOriginal(esfDet);
          }
          if (d.esfuerzoManual === true) setEsfuerzoFuente('manual');
          else if (d.esfuerzoFuente) setEsfuerzoFuente(d.esfuerzoFuente);
          if (d.sensacion != null) setSensacion(d.sensacion); if (d.descripcion) setDescripcion(d.descripcion);
          // pasos/comentarios: solo si traen contenido. Los syncs escriben []
          // en detalles y un array vacío es truthy: pisaba los pasos que el
          // matcher del servidor fusionó en el doc principal (desaparecían
          // al abrir la edición y se borraban de verdad al guardar).
          if (Array.isArray(d.pasos) && d.pasos.length) setPasos(d.pasos);
          if (Array.isArray(d.comentarios) && d.comentarios.length) setComentarios(d.comentarios);
          setVueltas(d.vueltas ?? []); alinearDuracionConVueltas(d.vueltas); setRegistrosLoaded(false);
        } else { const m = await getDoc(doc(db,'entrenamientos',workout.id)); if (m.exists()) { const d = m.data(); setVueltas(d.vueltas ?? []); alinearDuracionConVueltas(d.vueltas); if (d.registros) { setRegistros(d.registros); setRegistrosLoaded(true); } } }
      } catch (e) {} finally { setLoadingHeavyData(false); }
    })();
  }, [workout, visible, athleteId]);

  // El switch refleja el estado REAL de la librería: si ya existe una plantilla
  // de este entreno, se abre en ON (con compatibilidad para plantillas antiguas
  // guardadas sin workoutId: se localizan por título+tipo y se vinculan).
  useEffect(() => {
    const uid = auth.currentUser?.uid;
    if (!visible || !workout?.id || !uid) return;
    (async () => {
      try {
        const q1 = query(collection(db,'libreria'), where('userId','==',uid), where('workoutId','==',workout.id));
        const s1 = await getDocs(q1);
        if (!s1.empty) { setLibDocId(s1.docs[0].id); setSaveLib(true); return; }
        const q2 = query(collection(db,'libreria'), where('userId','==',uid), where('titulo','==',workout.titulo || workout.tipo), where('tipo','==',workout.tipo));
        const s2 = await getDocs(q2);
        if (!s2.empty) {
          const id = s2.docs[0].id;
          try { await updateDoc(doc(db,'libreria',id), { workoutId: workout.id }); } catch (e) {}
          setLibDocId(id); setSaveLib(true);
        }
      } catch (e) {}
    })();
  }, [visible, workout?.id]);

  useEffect(() => {
    if (!workout || !visible || !workout.intervalsId) return;
    (async () => {
      try {
        const det = await getDoc(doc(db,'entrenamientos',workout.id,'detalles','data'));
        const dd = det.exists() ? det.data() : null;
        // Si las vueltas están vacías y quedan reintentos, se pide el detalle
        // otra vez bajo demanda (antes un doc "sincronizado" sin vueltas no
        // se volvía a pedir nunca).
        const sinVueltasRetry = dd && !(Array.isArray(dd.vueltas) && dd.vueltas.length > 0) && (dd.vueltasRetries || 0) < 3;
        if (dd && dd.intervalsDetailSynced && dd.hasRuta === true && Number(dd.esfuerzo) > 0 && dd.esfuerzoFuente && !sinVueltasRetry) return;
        const apiUrl = (await getApiUrl()).replace(/\/+$/, ''); const token = await auth.currentUser.getIdToken();
        const r = await fetch(`${apiUrl}/sync-intervals-detail`, { method:'POST', headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`}, body: JSON.stringify({ intervalsId: String(workout.intervalsId) }) });
        if (!r.ok) return;
        const d2s = await getDoc(doc(db,'entrenamientos',workout.id,'detalles','data'));
        if (d2s.exists()) { const d2 = d2s.data(); setVueltas(d2.vueltas ?? []); alinearDuracionConVueltas(d2.vueltas); if (d2.elevacionMin != null) setElevMin(d2.elevacionMin.toString()); if (d2.elevacionMax != null) setElevMax(d2.elevacionMax.toString()); if (Number(d2.esfuerzo) > 0) { setEsfuerzo(String(d2.esfuerzo)); setEsfuerzoOriginal(String(d2.esfuerzo)); } if (d2.esfuerzoManual === true) setEsfuerzoFuente('manual'); else if (d2.esfuerzoFuente) setEsfuerzoFuente(d2.esfuerzoFuente); }
        setRegistrosLoaded(false);
      } catch (e) {}
    })();
  }, [workout, visible]);

  // Recalcula el esfuerzo con los datos del entreno y los umbrales del perfil.
  // Permite corregir entrenos guardados con versiones anteriores de la app
  // (que daban valores muy bajos) sin tener que volver a importar el .fit.
  const recalcularEsfuerzo = async () => {
    if (recalculando) return;
    setRecalculando(true);
    try {
      const uid = athleteId || workout?.userId || auth.currentUser?.uid;
      const perfil = (await getCachedProfile(uid)) || null;
      let wellnessDays = {};
      try {
        const ws = await getDoc(doc(db, 'wellness', uid));
        if (ws.exists()) wellnessDays = ws.data().days || {};
      } catch (e) {}
      // El TRIMP integrado (el que iguala a TrainerPlan) necesita las muestras
      // de FC; sin ellas cae a la aproximación con la FC media y sale desviado.
      // Las muestras solo se cargan al entrar en las pestañas de gráficas, así
      // que si no están en memoria se piden aquí antes de calcular.
      let muestras = Array.isArray(registros) && registros.length >= 2 ? registros : null;
      if (!muestras && workout?.id) {
        try {
          const s = await getDoc(doc(db, 'entrenamientos', workout.id, 'registros', 'data'));
          if (s.exists()) {
            const pts = s.data().puntos ?? [];
            pts.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
            setRegistros(pts); setRegistrosLoaded(true);
            if (pts.length >= 2) muestras = pts;
          }
        } catch (e) {}
      }
      const r = calcularEsfuerzoDesdeResumen({
        tipo: actividad,
        duracionSeg: parseDuration(durText) ?? durSec,
        distanciaKm: distancia ? parseFloat(distancia) : null,
        fcMedia: fc ? parseInt(fc) : null,
        fcMax: fcMax ? parseInt(fcMax) : null,
        muestras,
        fecha: workout?.fecha,
      }, perfil, wellnessDays);
      if (!r || !(r.valor > 0)) {
        Alert.alert(
          L('No se puede calcular', 'Cannot calculate'),
          L('No hay datos suficientes. Hace falta duración y distancia (para rTSS) o FC media (para hrTSS), y tener configurados los umbrales en Zonas.',
            'Not enough data. Duration and distance (for rTSS) or average HR (for hrTSS) are needed, plus thresholds set in Zones.')
        );
        return;
      }
      setEsfuerzo(String(r.valor));
      setEsfuerzoOriginal(String(r.valor));
      setEsfuerzoFuente(r.fuente);
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally {
      setRecalculando(false);
    }
  };
  const horaFinal = () => horaMode === 'Mañana' ? '08:00' : horaMode === 'Tarde' ? '18:00' : (horaCustom || '08:00');

  // ── Curvas por digest (A5 + C 4.6) ──
  // Invalida las cachés de curvas al editar/borrar (fecha/tipo/estado/
  // duracion/distancia), marca el entreno pendiente de recálculo y quita el
  // digest viejo (del mes antiguo si cambió la fecha). En try/catch: NUNCA
  // debe romper el flujo de guardado. Solo el propietario escribe (el store
  // lo comprueba con auth.currentUser.uid).
  const invalidarCurvasEnt = (wid, fechaVieja) => {
    const u = workout?.userId || auth.currentUser?.uid;
    if (!u || !wid) return;
    try {
      invalidarCurvasEntreno(u);
      const fms = fechaVieja?.toMillis
        ? fechaVieja.toMillis()
        : (fechaVieja instanceof Date ? fechaVieja.getTime() : (fechaVieja ? new Date(fechaVieja).getTime() : Date.now()));
      marcarPendiente(u, wid).catch(() => {});
      quitarDigest(u, wid, fms).catch(() => {});
    } catch (e) {
      console.warn('[WDM] invalidación de curvas falló:', e.message);
    }
  };
  // H12: antes de deleteDoc del padre, eliminar detalles/data y registros/data
  // (deleteDoc tolerando que no existan: antes quedaban huérfanas).
  const borrarSubdocumentos = async (wid) => {
    try { await deleteDoc(doc(db, 'entrenamientos', wid, 'detalles', 'data')); } catch (e) {}
    try { await deleteDoc(doc(db, 'entrenamientos', wid, 'registros', 'data')); } catch (e) {}
  };

  const handleSaveSession = async () => {
    setLoading(true);
    try {
      const secs = parseDuration(durText);
      // Si el usuario ha tocado el esfuerzo, se marca como manual para que el
      // servidor no lo vuelva a sobrescribir con el valor de intervals.icu.
      const esfManual = esfuerzo !== esfuerzoOriginal;
      const esfExtra = esfManual
        ? { esfuerzoManual: true, esfuerzoFuente: 'manual' }
        : (esfuerzoFuente && esfuerzoFuente !== 'manual' ? { esfuerzoManual: false, esfuerzoFuente } : { esfuerzoManual: false });
      // sensacion/cargaPercibida también en el doc principal: el calendario
      // pinta la carita y el nº de carga en la tarjeta y SOLO lee este doc.
      // duracionManual: si el usuario guarda una duración distinta de la Σ de
      // vueltas, se marca para que ni la app ni el server la vuelvan a pisar.
      const sumaVueltasActual = Math.round((vueltas || []).reduce((a, v) => a + (Number(v && v.tiempo) || 0), 0));
      const durManual = sumaVueltasActual > 0 && Math.abs((secs ?? 0) - sumaVueltasActual) > 5;
      await updateDoc(doc(db,'entrenamientos',workout.id), { estado, duracion: secs ?? null, duracionManual: durManual, distancia: distancia ? parseFloat(distancia) : null, 'fc-media': fc ? parseInt(fc) : null, esfuerzo: esfuerzo ? parseInt(esfuerzo) : null, ...esfExtra, sensacion: sensacion ?? null, cargaPercibida: carga || '' });
      invalidarCurvasEnt(workout.id, workout.fecha); // estado/duración/distancia/FC (A5 + 4.6)
      await setDoc(doc(db,'entrenamientos',workout.id,'detalles','data'), { ritmo, 'fc-media': fc?parseInt(fc):null, fcMax: fcMax?parseInt(fcMax):null, elevacionMin: elevMin?parseInt(elevMin):null, elevacionMax: elevMax?parseInt(elevMax):null, cargaPercibida: carga, esfuerzo: esfuerzo?parseInt(esfuerzo):null, ...esfExtra, enlace, sensacion, comentarios, cadencia: cadencia?parseInt(cadencia):null, desnivelPos: desnivelPos?parseInt(desnivelPos):null, temperatura: temperatura?parseInt(temperatura):null }, { merge: true });
      if (saveLib && libDocId) { try { await updateDoc(doc(db,'libreria',libDocId), { tipo: actividad, titulo: titulo || actividad, descripcion: descripcion || '', pasos: pasos.map(normalizeStep), archivos, workoutId: workout.id }); } catch (e) {} }
      onWorkoutUpdated?.(); onClose();
    } catch (e) { Alert.alert(L('Error','Error'), e.message); } finally { setLoading(false); }
  };
  // Notificaciones de un guardado (altas al evento + movido/modificado):
  // EN SEGUNDO PLANO y en paralelo, con timeouts en cada envío. Nunca deben
  // bloquear el cierre del formulario: el evento ya está guardado en
  // Firestore antes de llamar a esto.
  const notificarGuardadoEvento = async (info) => {
    try {
      const coachUid = auth.currentUser?.uid;
      if (!coachUid) return;
      const cn = await getCoachFullName(coachUid);
      const nuevosAsignados = info.actividad === 'Evento'
        ? (info.asignados || []).filter((uid) => !(info.asignadosIniciales || []).includes(uid))
        : [];
      const tareas = [];
      nuevosAsignados.forEach((uid) => tareas.push(
        sendNotificationToAthlete(uid, coachUid, {
          kind: 'apuntado', coachName: cn, nombre: info.titulo || info.actividad,
          fechaStr: info.fechaStr, workoutId: info.workoutId,
        })
      ));
      const dest = new Set();
      if (info.workout?.userId && info.workout.userId !== coachUid) dest.add(info.workout.userId);
      const paraModificar = info.actividad === 'Evento'
        ? (info.asignados || []).filter((uid) => !nuevosAsignados.includes(uid))
        : (Array.isArray(info.workout?.asignados) ? info.workout.asignados : []);
      paraModificar.forEach((u) => { if (u !== coachUid) dest.add(u); });
      if (dest.size > 0) {
        const kind = info.fechaStr !== info.originalFechaStr ? 'movido' : 'modificado';
        const nombre = info.titulo || info.workout?.titulo;
        dest.forEach((d) => tareas.push(
          sendNotificationToAthlete(d, coachUid, { kind, coachName: cn, nombre, fechaStr: info.fechaStr, workoutId: info.workoutId, contextAthleteId: d })
        ));
      }
      await Promise.allSettled(tareas);
    } catch (e) { console.warn('[evento] notificaciones:', e.message); }
  };

  const handleSaveEdit = async () => {
    // Sesión NUEVA para la librería: se pide carpeta y se guarda solo ahí.
    if (nuevaPlantilla) { setPickerLib({ accion: 'crear' }); return; }
    // Editando una SESIÓN de la librería: se actualiza la sesión, sin tocar
    // el calendario (de ahí vino y ahí vuelve).
    if (libOrigenId) {
      setLoading(true);
      try {
        const pasosNuevos = pasos.map(normalizeStep);
        const upd = { tipo: actividad, titulo: titulo || actividad, descripcion: descripcion || '', pasos: pasosNuevos, archivos };
        await updateDoc(doc(db, 'libreria', libOrigenId), upd);
        // Reflejo INMEDIATO en el almacén local de la librería: al volver a la
        // pestaña (o al reabrir el modal) la sesión ya sale con lo guardado,
        // sin esperar al listener en vivo (y sin arriesgarse a re-editar la
        // copia vieja, que es lo que descartaba los cambios).
        try {
          await libreriaStoreInit(auth.currentUser?.uid);
          await libreriaStorePut({ ...(libItemRef.current || {}), ...upd });
        } catch (e) {}
        libItemRef.current = null;
        setLibOrigenId(null); setMainTab('libreria');
        Alert.alert(L('Guardado','Saved'), L('Sesión actualizada en la librería.','Session updated in the library.'));
      } catch (e) { Alert.alert(L('Error','Error'), e.message); } finally { setLoading(false); }
      return;
    }
    if (!puedeEditarEntreno) return; // solo el creador puede guardar cambios
    setLoading(true);
    try {
      const p = fechaStr.split('/'); const nf = new Date(p[2], p[1]-1, p[0]);
      const [h, m] = horaFinal().split(':'); nf.setHours(parseInt(h), parseInt(m || 0));
      const pasosNuevos = pasos.map(normalizeStep);
      const payload = { tipo: actividad, titulo: titulo || actividad, descripcion, archivos, pasos: pasosNuevos, fecha: Timestamp.fromDate(nf), ...(actividad === 'Evento' ? { asignados } : {}) };
      // Doc FUSIONADO (realizado + plan): los pasos que se acaban de editar SON
      // el plan, así que se re-alinean planDist/planDur con ellos. Si no, tras
      // editar los pasos la tarjeta seguiría comparando contra un plan viejo
      // (o contra nada: distancia realizada sin su comparativa).
      if (workout.mergedFromPlanId) {
        const plan = computePlanMetrics(pasosNuevos, ritmoZones, actividad);
        if (plan.km > 0) payload.planDist = Math.round(plan.km * 100) / 100;
        if (plan.sec > 0) payload.planDur = Math.round(plan.sec);
      }
      await updateDoc(doc(db,'entrenamientos',workout.id), payload);
      invalidarCurvasEnt(workout.id, workout.fecha); // tipo y fecha (A5 + 4.6)
      if (actividad === 'Fuerza') AsyncStorage.removeItem(`tj_fuerza_ses_v1_${workout.id}`).catch(() => {});
      if (saveLib && libDocId) { try { await updateDoc(doc(db,'libreria',libDocId), { tipo: actividad, titulo: titulo || actividad, descripcion: descripcion || '', pasos: pasos.map(normalizeStep), archivos, workoutId: workout.id }); } catch (e) {} }
      // Vista al día: la pestaña Sesión pinta del snapshot `workout` del
      // padre; se parchea con lo recién guardado para verlo sin reabrir.
      setPatchVista({ titulo: titulo || actividad, descripcion, archivos, tipo: actividad, pasos: pasosNuevos, fecha: Timestamp.fromDate(nf), ...(payload.planDist != null ? { planDist: payload.planDist } : {}), ...(payload.planDur != null ? { planDur: payload.planDur } : {}) });
      onWorkoutUpdated?.(); setMode('view'); setMainTab('sesion');
      // Notificaciones EN SEGUNDO PLANO: nunca bloquean el guardado (el
      // evento ya está persistido). Antes el envío esperaba aquí en fila y,
      // si una llamada se colgaba, el botón "Guardando…" no terminaba nunca
      // y no se mandaba ninguna notificación.
      notificarGuardadoEvento({ actividad, asignados, asignadosIniciales: asignadosInicialesRef.current, titulo, fechaStr, originalFechaStr, workout, workoutId: workout.id });
    } catch (e) { Alert.alert(L('Error','Error'), e.message); } finally { setLoading(false); }
  };
  const handleDelete = () => {
    if (!puedeEditarEntreno) return; // solo el creador puede borrar
    Alert.alert(L('Borrar entrenamiento','Delete workout'), L('¿Estás seguro? Los entrenos sincronizados volverán a aparecer en la próxima sincronización.','Are you sure? Synced workouts will reappear on the next sync.'), [
      { text: L('Cancelar','Cancel'), style:'cancel' },
      { text: L('Borrar','Delete'), style:'destructive', onPress: async () => { try {
        await notifyIntervalsDelete(workout);
        invalidarCurvasEnt(workout.id, workout.fecha); // quita el digest (4.6)
        await borrarSubdocumentos(workout.id);          // H12: limpiar subcolecciones
        await deleteDoc(doc(db,'entrenamientos',workout.id));
        onWorkoutUpdated?.(); onClose();
      } catch (e) {} } },
    ]);
  };
  const toggleEstado = async (v) => { const n = estado === v ? null : v; setEstado(n); try { await updateDoc(doc(db,'entrenamientos',workout.id), { estado: n }); invalidarCurvasEnt(workout.id, workout.fecha); onWorkoutUpdated?.(); } catch (e) {} };
  const handleSendComment = async () => {
    if (!comentario.trim()) return; setSendingComm(true);
    try {
      const nuevo = { texto: comentario.trim(), nombre: currentUserName || 'Tú', timestamp: Timestamp.now() };
      const lista = [...comentarios, nuevo];
      await setDoc(doc(db,'entrenamientos',workout.id,'detalles','data'), { comentarios: lista }, { merge: true });
      try { await updateDoc(doc(db,'entrenamientos',workout.id), { tieneComentarios: true }); } catch (e) {}
      setComentarios(lista); setComentario('');
      // El comentario avisa a LA OTRA PARTE en los dos sentidos. No se puede
      // deducir "quien comenta es el coach" comparando con el creador: en los
      // entrenos propios/sincronizados del atleta NO hay creadoPor y "creador"
      // cae en userId (el atleta), con lo que su comentario no llegaba nunca
      // al entrenador. Se avisa a todos los implicados menos a quien comenta:
      // dueño del entreno + apuntados + creador + entrenador vinculado (si el
      // que comenta es atleta).
      const me = auth.currentUser.uid;
      const aUid = (v) => (typeof v === 'string' ? v : (v?.uid || v?.id || v?.userId || null));
      let miPerfil = (await getCachedProfile(me)) || {};
      if (!miPerfil.entrenador && !miPerfil.coachUid && !miPerfil.entrenadorUid) {
        try { const ps = await getDoc(doc(db, 'perfiles', me)); if (ps.exists()) miPerfil = { ...miPerfil, ...ps.data() }; } catch (e) {}
      }
      const linkedCoachUid = aUid(miPerfil.entrenador) || aUid(miPerfil.coachUid) || aUid(miPerfil.entrenadorUid) || aUid(miPerfil.coachId);
      const creador = workout.creadoPor || workout.coachUid || workout.entrenadorUid || workout.userId;
      // El entrenador personal del que comenta SOLO se incluye si el que
      // comenta PARTICIPA COMO ATLETA en ESTE entreno (es el dueño o está
      // apuntado). Si comenta como ENTRENADOR del atleta dueño del entreno,
      // su entrenador personal no tiene por qué ver este entreno ajeno
      // (antes le llegaba el aviso = fuga de datos entre entrenos).
      const participoComoAtleta = workout.userId === me || (Array.isArray(workout.asignados) && workout.asignados.includes(me));
      const destCom = new Set();
      if (workout.userId) destCom.add(workout.userId);
      (Array.isArray(workout.asignados) ? workout.asignados : []).forEach((u) => { if (u) destCom.add(u); });
      if (creador) destCom.add(creador);
      if (participaComoAtleta && linkedCoachUid) destCom.add(linkedCoachUid);
      destCom.delete(me);
      if (destCom.size > 0) {
        const participantes = new Set([workout.userId, ...(Array.isArray(workout.asignados) ? workout.asignados : [])].filter(Boolean));
        const cn = await getCoachFullName(me);   // nombre de quien comenta
        const nombreEnt = workout.titulo || workout.tipo;
        for (const d of destCom) {
          const contextoAtleta = participantes.has(me) ? me : d;
          await sendNotificationToAthlete(d, me, { kind: 'comentario', coachName: cn, nombre: nombreEnt, workoutId: workout.id, contextAthleteId: contextoAtleta });
        }
      }
      onWorkoutUpdated?.();
    } catch (e) {} finally { setSendingComm(false); }
  };
  const handleDeleteComment = (c) => Alert.alert(L('Eliminar comentario','Delete comment'), L('¿Seguro que quieres eliminar este comentario?','Are you sure you want to delete this comment?'), [
    { text: L('Cancelar','Cancel'), style:'cancel' },
    { text: L('Eliminar','Delete'), style:'destructive', onPress: async () => { try { const lista = comentarios.filter(x => !(x.texto===c.texto && x.nombre===c.nombre)); await setDoc(doc(db,'entrenamientos',workout.id,'detalles','data'), { comentarios: lista }, { merge: true }); setComentarios(lista); onWorkoutUpdated?.(); } catch (e) {} } },
  ]);

  // ── Reasignar a otro planificado del día / Separar fusión ──
  const [loadingPlans, setLoadingPlans] = useState(false);

  const fmtHora = (f) => {
    const d = f?.toDate ? f.toDate() : new Date(f);
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  };

  const loadDayPlans = async () => {
    const w = workout; if (!w) return;
    setLoadingPlans(true);
    try {
      const fd = w.fecha?.toDate ? w.fecha.toDate() : new Date(w.fecha);
      const ds = new Date(fd); ds.setHours(0, 0, 0, 0);
      const de = new Date(fd); de.setHours(23, 59, 59, 999);
      const snap = await getDocs(query(
        collection(db, 'entrenamientos'),
        where('userId', '==', w.userId),
        where('fecha', '>=', Timestamp.fromDate(ds)),
        where('fecha', '<=', Timestamp.fromDate(de)),
      ));
      const list = snap.docs.map(d => ({ id: d.id, ...d.data() }))
        .filter(x => x.id !== w.id && x.estado !== 'completo' && !x.mergedFromPlanId);
      list.sort((a, b) => (a.fecha?.toMillis?.() ?? 0) - (b.fecha?.toMillis?.() ?? 0));
      setDayPlans(list);
    } catch (e) { setDayPlans([]); }
    finally { setLoadingPlans(false); }
  };

  const toggleReassign = () => {
    const nv = !reassignOpen;
    setReassignOpen(nv);
    if (nv) loadDayPlans();
  };

  const executeReassign = async (p) => {
    const w = workout; if (!w) return;
    try {
      // Si estaba fusionado, el plan antiguo vuelve a existir como planificado
      if (w.mergedFromPlanId) {
        await addDoc(collection(db, 'entrenamientos'), {
          userId: w.userId,
          creadoPor: w.creadoPor || w.userId, // mantiene el creador original
          fecha: w.planFecha ?? w.fecha,
          tipo: w.tipo,
          titulo: w.titulo,
          descripcion: w.descripcion || '',
          pasos: w.pasos || [],
          estado: null,
          createdAt: Timestamp.now(),
        });
      }
      // Plan del planificado elegido, con los mismos respaldos que usan las
      // tarjetas (Home/Calendario): pasos → distancia/duración guardadas en el
      // planificado. Antes solo se miraban los pasos: un plan sin pasos (o con
      // pasos por zona de ritmo sin zonas cargadas) dejaba planDist en null y
      // la distancia salía sin comparativa.
      const plan = resolverPlanReal(p, ritmoZones, p.tipo || actividad || w.tipo);
      await updateDoc(doc(db, 'entrenamientos', w.id), {
        titulo: p.titulo || w.titulo,
        descripcion: p.descripcion || '',
        pasos: p.pasos || [],
        tipo: p.tipo || w.tipo,
        mergedFromPlanId: p.id,
        planTitulo: p.titulo || null,
        planFecha: p.fecha ?? null,
        planDist: plan.dist > 0 ? Math.round(plan.dist * 100) / 100 : null,
        planDur: plan.dur > 0 ? Math.round(plan.dur) : null,
        planMatchChecked: true,
      });
      invalidarCurvasEnt(w.id, w.fecha); // este updateDoc cambia `tipo` (A5 + 4.6)
      await notifyIntervalsDelete(p);
      invalidarCurvasEnt(p.id, p.fecha); // borrado del planificado: quita su digest (4.6)
      await borrarSubdocumentos(p.id);   // H12: limpiar subcolecciones del planificado
      await deleteDoc(doc(db, 'entrenamientos', p.id));
      onWorkoutUpdated?.();
      onClose();
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };

  const confirmReassign = (p) => Alert.alert(
    L('Traspasar', 'Transfer'),
    L(`¿Vincular este entreno al planificado "${p.titulo || p.tipo}" de las ${fmtHora(p.fecha)}?`, `Link this workout to planned "${p.titulo || p.tipo}" at ${fmtHora(p.fecha)}?`),
    [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      { text: L('Traspasar', 'Transfer'), onPress: () => executeReassign(p) },
    ]
  );

  const executeSplit = async () => {
    const w = workout; if (!w || !w.mergedFromPlanId) return;
    try {
      await addDoc(collection(db, 'entrenamientos'), {
        userId: w.userId,
        creadoPor: w.creadoPor || w.userId, // mantiene el creador original
        fecha: w.planFecha ?? w.fecha,
        tipo: w.tipo,
        titulo: w.titulo,
        descripcion: w.descripcion || '',
        pasos: w.pasos || [],
        estado: null,
        // Marca el par separados: el matcher del server podrá volver a
        // juntarlos (sin puertas ni puntuación) si se re-sincroniza el realizado.
        splitFromId: w.id,
        createdAt: Timestamp.now(),
      });
      await updateDoc(doc(db, 'entrenamientos', w.id), {
        titulo: w.tituloSync || w.titulo,
        descripcion: '',
        pasos: [],
        mergedFromPlanId: deleteField(),
        planTitulo: deleteField(),
        planFecha: deleteField(),
        planDist: deleteField(),
        planDur: deleteField(),
      });
      onWorkoutUpdated?.();
      onClose();
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };

  const toggleAsignado = async (uid) => {
    if (!workout) return;
    const on = asignados.includes(uid);
    const next = on ? asignados.filter(x => x !== uid) : [...asignados, uid];
    // La selección es provisional: no se persiste ni notifica hasta Guardar.
    setAsignados(next);
    if (!on && !perfilesAsignados[uid]) {
      try {
        const c = await getCachedProfile(uid);
        if (c) setPerfilesAsignados(p => ({ ...p, [uid]: c }));
        else {
          const s2 = await getDoc(doc(db, 'perfiles', uid));
          if (s2.exists()) setPerfilesAsignados(p => ({ ...p, [uid]: s2.data() }));
        }
      } catch (e) {}
    }
  };

  const confirmSplit = () => Alert.alert(
    L('Separar', 'Split'),
    L('Se creará un entreno planificado con el título, descripción y pasos planificados, y este entreno se quedará solo con los datos realizados.',
      'A planned workout will be created with the planned title, description and steps, and this workout will keep only the completed data.'),
    [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      { text: L('Separar', 'Split'), style: 'destructive', onPress: executeSplit },
    ]
  );

  // El "+" de la librería: crea una sesión NUEVA (vacía) que al guardar va a
  // la librería, no al calendario.
  // Editar una sesión de la librería desde el menú de pulsación larga:
  // carga la sesión en el formulario y marca libOrigenId para que al guardar
  // se actualice la sesión (sin contar uso). Antes LibreriaDrive no recibía
  // onEdit y la opción Editar del menú no hacía nada.
  const handleEditFromLibrary = (item) => {
    setActividad(item.tipo ?? 'Running'); setTitulo(item.titulo ?? ''); setDescripcion(item.descripcion ?? '');
    setPasos((Array.isArray(item.pasos) ? item.pasos : []).map(p => ({ ...p, durTexto: p.durTexto ?? p.durValor ?? '', hijos: p.hijos || [] })));
    setArchivos(Array.isArray(item.archivos) ? item.archivos : []);
    setLibOrigenId(item.id);
    libItemRef.current = item;
    setMainTab('edit');
  };

  const handleNuevaPlantilla = () => {
    setActividad('Running'); setTitulo(''); setDescripcion(''); setPasos([]);
    setNuevaPlantilla(true); setLibOrigenId(null); setMainTab('edit');
  };

  const handleToggleLib = async (value) => {
    const uid = auth.currentUser?.uid; if (!uid) return;
    if (value) {
      // ON: primero se elige la CARPETA destino; el doc se crea al elegir.
      setPickerLib({ accion: 'switch' });
    } else {
      // OFF: se quita de la librería lo que se añadió con este switch
      setSaveLib(false);
      if (libDocId) { try { await deleteDoc(doc(db, 'libreria', libDocId)); } catch (e) {} setLibDocId(null); }
    }
  };
  // Carpeta elegida en el selector: crea la sesión en la librería.
  const elegirCarpetaParaGuardar = async (carpetaId) => {
    const uid = auth.currentUser?.uid; if (!uid) return;
    try {
      const base = { userId: uid, carpeta: carpetaId, tipo: actividad, titulo: titulo || actividad, descripcion: descripcion || '', pasos: pasos.map(normalizeStep), archivos, timesUsed: 0, createdAt: Timestamp.now() };
      if (pickerLib?.accion === 'switch') {
        const ref = await addDoc(collection(db, 'libreria'), base);
        setLibDocId(ref.id); setSaveLib(true);
        Alert.alert(L('Guardado','Saved'), L('Entrenamiento guardado en tu librería.','Workout saved to your library.'));
      } else {
        await addDoc(collection(db, 'libreria'), base);
        setNuevaPlantilla(false); setMainTab('libreria');
      }
    } catch (e) { Alert.alert(L('Error','Error'), e.message); }
  };

  const handleLoadFromLibrary = async (item) => {
    setActividad(item.tipo ?? 'Running'); setTitulo(item.titulo ?? ''); setDescripcion(item.descripcion ?? '');
    setPasos((Array.isArray(item.pasos) ? item.pasos : []).map(p => ({ ...p, durTexto: p.durTexto ?? p.durValor ?? '', hijos: p.hijos || [] })));
    setArchivos(Array.isArray(item.archivos) ? item.archivos : []);
    setLibOrigenId(item.id);
    libItemRef.current = item;
    setMainTab('edit');
  };

  const iconName = actSel.icon; const iconColor = actSel.color;
  const cadenceUnit = actividad === 'Ciclismo' ? 'rpm' : (lang === 'en' ? 'spm' : 'ppm');
  const isLight = theme.background === '#F4F7FB';
  const fmtPaceLocal = (secKm) => { const m = Math.floor(secKm / 60), s2 = Math.round(secKm % 60); return s2 === 60 ? `${m + 1}:00` : `${m}:${String(s2).padStart(2, '0')}`; };
  const formatLapTime = (s) => { if (!s) return '00:00'; return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(Math.floor(s%60)).padStart(2,'0')}`; };
  // Duración mostrada = Σ de vueltas (tiempo bueno, sin pausas), el MISMO
  // número que la tarjeta del calendario y la fila Σ de Vueltas. Solo se
  // aplica si el doc no tiene una duración editada a mano (duracionManual).
  const alinearDuracionConVueltas = (vs) => {
    if (!Array.isArray(vs) || !vs.length) return;
    const suma = Math.round(vs.reduce((a, v) => a + (Number(v && v.tiempo) || 0), 0));
    if (suma > 0 && workout?.duracionManual !== true && Math.abs((Number(workout.duracion) || 0) - suma) > 5) {
      setDurSec(suma);
      setDurText(formatSeconds(suma));
    }
  };
  // Scroll del formulario de edición: al enfocar un campo de abajo (p. ej. la
  // descripción) se baja hasta él para que el teclado no lo tape.
  const editScrollRef = useRef(null);
  if (!workout) return null;

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <KeyboardAvoidingView style={s.kav} behavior={Platform.OS==='ios' ? 'padding' : 'height'}>
        <View style={s.overlay}>
          <View style={[s.sheet, { backgroundColor: theme.background, paddingBottom: insets.bottom + 6 }]}>
            <View style={[s.header, { backgroundColor: theme.card, borderBottomColor: theme.border }]}>
              <TouchableOpacity onPress={onClose} style={s.headerSide}>
                <Ionicons name="close" size={22} color="#8FA8C8" />
              </TouchableOpacity>
              <Text style={[s.headerTitle, { color: theme.text }]} numberOfLines={1}>{mode === 'edit' ? L('Editar','Edit') : (workout.titulo || workout.tipo || L('Entrenamiento','Workout'))}</Text>
              <View style={s.headerSide}>
                {/* Sin permiso el botón no se muestra: la acción no existe */}
                {mode === 'view' && puedeEditarEntreno && (
                  <TouchableOpacity
                    activeOpacity={0.7}
                    onPress={() => { setMode('edit'); setMainTab('edit'); }}
                  >
                    <Text style={s.editBtn}>{L('Editar','Edit')}</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>

            {mode === 'view' ? (
              <View style={s.tabs}>
                <TouchableOpacity style={[s.tab, mainTab==='sesion' && s.tabActive]} onPress={() => setMainTab('sesion')}>
                  <Text style={[s.tabText, { color: theme.muted }, mainTab==='sesion' && [s.tabTextActive, { color: theme.text }]]}>{L('Sesión','Session')}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.tab, mainTab==='comentarios' && s.tabActive]} onPress={() => setMainTab('comentarios')}>
                  <Text style={[s.tabText, { color: theme.muted }, mainTab==='comentarios' && [s.tabTextActive, { color: theme.text }]]}>{L('Comentarios','Comments')}</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={s.tabs}>
                <TouchableOpacity style={[s.tab, mainTab==='edit' && s.tabActive]} onPress={() => setMainTab('edit')}>
                  <Text style={[s.tabText, { color: theme.muted }, mainTab==='edit' && [s.tabTextActive, { color: theme.text }]]}>{L('Editar','Edit')}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.tab, mainTab==='libreria' && s.tabActive]} onPress={() => setMainTab('libreria')}>
                  <Text style={[s.tabText, { color: theme.muted }, mainTab==='libreria' && [s.tabTextActive, { color: theme.text }]]}>{L('Librería','Library')}</Text>
                </TouchableOpacity>
              </View>
            )}

            {mode === 'view' && mainTab === 'sesion' && (
              <>
                <ScrollView style={s.scroll} contentContainerStyle={s.scrollPad} showsVerticalScrollIndicator={false}>
                  <View style={[s.titleCard, { backgroundColor: theme.card, borderColor: theme.border, borderWidth: 1 }]}>
                    <View style={[s.actIcon, { backgroundColor: iconColor+'22', borderColor: iconColor }]}>
                      <ActivityIcon tipo={actividad} size={20} color={iconColor} />
                    </View>
                    <View>
                      <Text style={[s.titleCardName, { color: theme.text }]}>{wV.titulo || wV.tipo}</Text>
                      <Text style={[s.titleCardDate, { color: theme.muted }]}>{formatFecha(wV.fecha, loc)}</Text>
                    </View>
                  </View>
                  {/* Récords batidos en ESTE entreno (prueba, marca y mejora) */}
                  <RecordsBatidos
                    workoutId={workout.id}
                    defs={marcasData.defs}
                    results={marcasData.results}
                    bests={marcasData.bests}
                    theme={theme}
                    L={L}
                  />
                  {wV.tipo === 'Evento' && (
                    <View style={[s.partBox, { borderColor: theme.border }]}>
                      <Text style={[s.partTitle, { color: theme.text }]}>{L('Atletas del evento', 'Event athletes')}</Text>
                      {asignados.length === 0 ? (
                        <Text style={[s.partEmpty, { color: theme.muted }]}>{L('Sin atletas agregados', 'No athletes added')}</Text>
                      ) : asignados.map(u => {
                        const p = perfilesAsignados[u];
                        const nombre = p ? `${p.nombre || ''} ${p.apellido || ''}`.trim() : u;
                        return (
                          <View key={u} style={s.partRow}>
                            {p?.foto ? (
                              <Image source={{ uri: `data:image/jpeg;base64,${p.foto}` }} style={s.partPhoto} />
                            ) : (
                              <View style={[s.partPhoto, { backgroundColor: theme.input }]}><Text style={[s.partInitial, { color: theme.muted }]}>{(p?.nombre || '?').charAt(0).toUpperCase()}</Text></View>
                            )}
                            <Text style={[s.partName, { color: theme.text }]} numberOfLines={1}>{nombre}</Text>
                          </View>
                        );
                      })}
                    </View>
                  )}
                  <Text style={[s.sectionHead, { color: theme.muted }]}>{L('Descripción','Description')}</Text>
                  <View style={[s.descBox, { backgroundColor: theme.card, borderColor: theme.border }]}><Text style={[s.descText, { color: theme.muted }]}>{wV.descripcion || ''}</Text></View>
                  {!!(Array.isArray(wV.archivos) && wV.archivos.length > 0) && (
                    <View style={{ gap: 8, marginTop: 12 }}>
                      <Text style={[s.sectionHead, { color: theme.muted }]}>{L('Archivos del entreno','Workout files')}</Text>
                      {wV.archivos.map((a, i) => (
                        a.tipo === 'video' ? (
                          /* Vídeo de YouTube: tarjeta con título + reproductor
                             embebido para verlo DENTRO de la app */
                          <View key={`${a.id || i}-${a.nombre}`} style={{ backgroundColor: theme.card, borderRadius: 10, borderWidth: 1, borderColor: theme.border, padding: 8, gap: 8 }}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                              <Ionicons name="videocam-outline" size={16} color={BLUE} />
                              <Text style={{ color: theme.text, fontSize: 13, flex: 1 }} numberOfLines={1}>{a.nombre}</Text>
                              <TouchableOpacity onPress={() => abrirAdjunto(a)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                                <Ionicons name="open-outline" size={16} color={theme.muted} />
                              </TouchableOpacity>
                            </View>
                            <VideoYouTube url={a.url} />
                          </View>
                        ) : (
                          <TouchableOpacity key={`${a.id || i}-${a.nombre}`} style={[s.archChip, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => abrirAdjunto(a)} activeOpacity={0.8}>
                            {(a.tipo === 'imagen' || a.tipo === 'gif' || (a.tipo === 'ejercicio' && a.thumb))
                              ? <Image source={{ uri: a.thumb || a.url }} style={s.archMini} resizeMode="cover" />
                              : (a.tipo === 'ejercicio'
                                  ? <MaterialCommunityIcons name="dumbbell" size={18} color="#2DB37A" />
                                  : <Ionicons name={a.tipo === 'pdf' ? 'document-text-outline' : 'document-outline'} size={18} color={BLUE} />)}
                            <Text style={{ color: theme.text, fontSize: 13, flex: 1 }} numberOfLines={1}>{a.nombre}</Text>
                            <Ionicons name="chevron-forward" size={15} color={theme.muted} />
                          </TouchableOpacity>
                        )
                      ))}
                    </View>
                  )}
                  <View style={s.grid2}>
                    <FieldBox label={L('Actividad','Activity')} value={wV.tipo} />
                    <FieldBox label={L('Medida','Measure')}>
                      <Text style={[s.fieldValue, { color: theme.text }]}>
                        {distancia ? `${distancia} km` : '—'}
                        {' / '}
                        {durSec != null ? formatSeconds(durSec) : '00:00:00'}
                      </Text>
                    </FieldBox>
                  </View>
                  {/* Pasos programados en resumen (barras numeradas), entre
                      Actividad/Medida y los botones de completado */}
                  {(wV.pasos || []).length > 0 && (
                    <PasosResumen
                      pasos={wV.pasos}
                      profileUid={athleteId || auth.currentUser?.uid}
                      actividad={wV.tipo}
                      workoutId={workout.id}
                      onGuardarEntreno={(payload) => {
                        // El write ya lo hizo PasosResumen; aquí refrescamos
                        // la vista (incluido el tiempo del cronómetro) y
                        // confirmamos al usuario. La FECHA no se toca: el
                        // entreno vive en su día programado.
                        const pv = { estado: 'completo' };
                        if (payload && payload.elapsedSec > 0) {
                          pv.duracion = payload.elapsedSec;
                          setDurSec(payload.elapsedSec);
                          setDurText(formatSeconds(payload.elapsedSec));
                        }
                        setPatchVista((oldPv) => ({ ...(oldPv || {}), ...pv }));
                        setEstado('completo');
                        onWorkoutUpdated?.();
                        let msg = L('Se ha marcado como completado.', 'It has been marked as completed.');
                        if (payload && payload.elapsedSec > 0) {
                          const mm = Math.floor(payload.elapsedSec / 60), ss2 = payload.elapsedSec % 60;
                          msg = L(`Completado en ${mm} min ${ss2} s.`, `Completed in ${mm} min ${ss2} s.`);
                        }
                        Alert.alert(L('Entreno guardado', 'Workout saved'), msg);
                      }}
                      onUpdatePasos={(puedeEditarEntreno || wV.userId === auth.currentUser?.uid || (Array.isArray(wV.asignados) && wV.asignados.includes(auth.currentUser?.uid))) ? (next) => {
                        // NUNCA escribir pasos vacíos desde la vista (un pase
                        // accidental con la lista a medias borraba los ejercicios).
                        if (!Array.isArray(next) || next.length === 0) return;
                        setPatchVista((pv) => ({ ...(pv || {}), pasos: next }));
                        updateDoc(doc(db, 'entrenamientos', workout.id), { pasos: next }).catch((e) => console.warn('[fuerza] persist pasos:', e.message));
                      } : undefined}
                    />
                  )}
                  <Text style={[s.sectionHead, { color: theme.muted }]}>{L('Entrenamiento realizado','Completed workout')}</Text>
                  <View style={s.estadoRow}>
                    <TouchableOpacity style={[s.estadoBtn, estado==='incompleto'?s.estadoBtnRojoOn:s.estadoBtnRojoOff]} onPress={() => toggleEstado('incompleto')}>
                      <Ionicons name="close" size={22} color={estado==='incompleto'?'#fff':RED} />
                    </TouchableOpacity>
                    <TouchableOpacity style={[s.estadoBtn, estado==='completo'?s.estadoBtnVerdeOn:s.estadoBtnVerdeOff]} onPress={() => toggleEstado('completo')}>
                      <Ionicons name="checkmark" size={22} color={estado==='completo'?'#fff':GREEN} />
                    </TouchableOpacity>
                  </View>
                  {!esProgramado && (<>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} keyboardShouldPersistTaps="handled" contentContainerStyle={s.subTabs}>
                    {['general','vueltas','detalles','zonas','curvafc','curvaritmo','picos'].map(t => (
                      <TouchableOpacity key={t} style={[s.subTab, subTab===t && s.subTabActive]} onPress={() => setSubTab(t)}>
                        {/* Sin numberOfLines: el nombre SIEMPRE entero; si no
                            caben todas, la barra se desliza en horizontal */}
                        <Text style={[s.subTabText, { color: subTab === t ? theme.text : theme.muted }, subTab===t && { fontWeight: '700' }]}>{SUBTAB_LABEL[t]}</Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>

                  {subTab === 'general' && (loadingHeavyData ? (
                    <View style={s.emptySubTab}>
                      <ActivityIndicator color={BLUE} />
                      <Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Cargando detalles...','Loading details...')}</Text>
                    </View>
                  ) : (
                    <View style={s.generalWrap}>
                      <View style={s.fieldRow}>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Duración','Duration')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border }]}><TextInput style={[s.inputInner, { color: theme.text }]} value={durText} onChangeText={(t) => setDurText(mascaraTiempoPaso(t))} onBlur={() => { const fmt = formatTimeInput(durText); if (fmt != null) setDurText(fmt); }} placeholder="hh:mm:ss" placeholderTextColor="#4A6080" keyboardType="number-pad" /></View>
                        </View>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Distancia','Distance')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',alignItems:'center'}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={distancia} onChangeText={setDistancia} placeholder="0.00" placeholderTextColor="#4A6080" keyboardType="decimal-pad" />
                            <Text style={[s.unitText, { color: theme.muted }]}>km</Text>
                          </View>
                        </View>
                      </View>
                      <View style={s.fieldRow}>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Ritmo','Pace')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',alignItems:'center'}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={ritmo} onChangeText={setRitmo} placeholder={actividad === 'Ciclismo' ? '0.0' : '00:00'} placeholderTextColor="#4A6080" />
                            <Text style={[s.unitText, { color: theme.muted }]}>{actividad === 'Ciclismo' ? 'km/h' : '/km'}</Text>
                          </View>
                        </View>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('FC','HR')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',gap:6}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={fc} onChangeText={setFc} placeholder="000" placeholderTextColor="#4A6080" keyboardType="numeric" />
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={fcMax} onChangeText={setFcMax} placeholder="000" placeholderTextColor="#4A6080" keyboardType="numeric" />
                          </View>
                        </View>
                      </View>
                      <View style={s.fieldRow}>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Elevación','Elevation')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',gap:6}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={elevMin} onChangeText={setElevMin} placeholder="0" placeholderTextColor="#4A6080" keyboardType="numeric" />
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={elevMax} onChangeText={setElevMax} placeholder="0" placeholderTextColor="#4A6080" keyboardType="numeric" />
                          </View>
                        </View>
                        <View style={s.fieldHalf}>
                          <View style={{ flexDirection:'row', alignItems:'center', justifyContent:'space-between' }}>
                            <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Esfuerzo','Effort')}</Text>
                            <TouchableOpacity onPress={recalcularEsfuerzo} disabled={recalculando} hitSlop={{top:6,bottom:6,left:6,right:6}}>
                              <Text style={{ color: recalculando ? theme.muted : BLUE, fontSize: 11, fontWeight: '700' }}>
                                {recalculando ? L('Calculando…','Calculating…') : L('⟳ Recalcular','⟳ Recalculate')}
                              </Text>
                            </TouchableOpacity>
                          </View>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border }]}><TextInput style={[s.inputInner, { color: theme.text }]} value={esfuerzo} onChangeText={setEsfuerzo} placeholder="0" placeholderTextColor="#4A6080" keyboardType="numeric" /></View>
                        </View>
                      </View>
                      <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Carga percibida','Perceived load')}</Text>
                      <FullScreenPicker value={carga} options={CARGA_OPTS} onChange={setCarga} placeholder={L('Escoge','Choose')} title={L('Selecciona una opción','Select an option')} cancelText={L('Cancelar','Cancel')} />
                      <Text style={[s.fieldLabel,{marginTop:12}]}>{L('Enlace','Link')}</Text>
                      <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border }]}><TextInput style={[s.inputInner, { color: theme.text }]} value={enlace} onChangeText={setEnlace} placeholder="https://..." placeholderTextColor="#4A6080" autoCapitalize="none" /></View>
                      <View style={s.fieldRow}>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Cadencia','Cadence')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',alignItems:'center'}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={cadencia} onChangeText={setCadencia} placeholder={cadenceUnit} placeholderTextColor="#4A6080" keyboardType="numeric" />
                            <Text style={[s.unitText, { color: theme.muted }]}>{cadenceUnit}</Text>
                          </View>
                        </View>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Desnivel +','Elev +')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',alignItems:'center'}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={desnivelPos} onChangeText={setDesnivelPos} placeholder="m" placeholderTextColor="#4A6080" keyboardType="numeric" />
                            <Text style={[s.unitText, { color: theme.muted }]}>m</Text>
                          </View>
                        </View>
                      </View>
                      <View style={s.fieldRow}>
                        <View style={s.fieldHalf}>
                          <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Temperatura','Temperature')}</Text>
                          <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border },{flexDirection:'row',alignItems:'center'}]}>
                            <TextInput style={[s.inputInner,{flex:1, color: theme.text}]} value={temperatura} onChangeText={setTemperatura} placeholder="°C" placeholderTextColor="#4A6080" keyboardType="numeric" />
                            <Text style={[s.unitText, { color: theme.muted }]}>°C</Text>
                          </View>
                        </View>
                        <View style={s.fieldHalf} />
                      </View>
                      <Text style={[s.fieldLabel,{marginTop:12}]}>{L('¿Cómo te has sentido?','How did you feel?')}</Text>
                      <View style={s.moodRow}>
                        {MOODS.map((e,i) => (
                          <TouchableOpacity key={i} style={[s.moodBtn, { backgroundColor: theme.card, borderColor: sensacion===i ? MOOD_COLORS[i] : theme.border }]} onPress={() => setSensacion(sensacion===i ? null : i)}>
                            <Text style={[s.moodEmoji, sensacion!==i && s.moodEmojiOff]}>{Platform.OS === 'ios' ? e + '\uFE0E' : e}</Text>
                          </TouchableOpacity>
                        ))}
                      </View>
                    </View>
                  ))}

                  {subTab === 'vueltas' && (
                    <View style={[s.lapsContainer, { backgroundColor: theme.card, borderColor: theme.border }]}>
                      {loadingHeavyData ? (
                        <View style={s.emptySubTab}>
                          <ActivityIndicator color={BLUE} />
                          <Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Cargando vueltas...','Loading laps...')}</Text>
                        </View>
                      ) : vueltas && vueltas.length > 0 ? (
                        <ScrollView horizontal showsHorizontalScrollIndicator={true}>
                          <View>
                            <View style={[s.lapHeaderRow, { backgroundColor: theme.input }]}>
                              {LAP_HEADERS.map((h,i) => (
                                <Text key={i} style={[s.lapHeaderCell, { width: [50,80,80,90,90,70,70,80,80,90,90,90][i] }]}>{h}</Text>
                              ))}
                            </View>
                            {vueltas.map((v,i) => (
                              <View key={i} style={[s.lapDataRow, { borderBottomColor: theme.border }]}>
                                <Text style={[s.lapDataCell,{width:50, color: theme.text}]}>{v.vuelta}</Text>
                                <Text style={[s.lapDataCell,{width:80, color: theme.text}]}>{v.distancia} km</Text>
                                <Text style={[s.lapDataCell,{width:80, color: theme.text}]}>{formatLapTime(v.tiempo)}</Text>
                                <Text style={[s.lapDataCell,{width:90, color: theme.text}]}>{ritmoForDisplay(actividad, v.ritmo)||'—'}{actividad === 'Ciclismo' ? ' km/h' : '/km'}</Text>
                                <Text style={[s.lapDataCell,{width:90, color: theme.text}]}>{ritmoForDisplay(actividad, v.ritmoMaximo)||'—'}{actividad === 'Ciclismo' ? ' km/h' : '/km'}</Text>
                                <Text style={[s.lapDataCell,{width:70, color: theme.text}]}>{v.fcMedia||'—'}</Text>
                                <Text style={[s.lapDataCell,{width:70, color: theme.text}]}>{v.fcMaxima||'—'}</Text>
                                <Text style={[s.lapDataCell,{width:80, color: theme.text}]}>{v.cadenciaMedia||'—'}</Text>
                                <Text style={[s.lapDataCell,{width:80, color: theme.text}]}>{v.cadenciaMaxima||'—'}</Text>
                                <Text style={[s.lapDataCell,{width:90, color: theme.text}]}>{v.gananciaElev||'—'}</Text>
                                <Text style={[s.lapDataCell,{width:90, color: theme.text}]}>{v.perdidaElev||'—'}</Text>
                                <Text style={[s.lapDataCell,{width:90, color: theme.text}]}>{v.difElev||'—'}</Text>
                              </View>
                            ))}
                            {/* ── Fila RESUMEN (Σ): totales y medias, fondo gris ── */}
                            {(() => {
                              const tot = vueltas.reduce((a, v) => {
                                const t = Number(v.tiempo) || 0;
                                const fc = Number(v.fcMedia) || 0;
                                const cad = Number(v.cadenciaMedia) || 0;
                                return {
                                  d: a.d + (Number(v.distancia) || 0),
                                  t: a.t + t,
                                  fcM: a.fcM + fc * t, fcW: a.fcW + (fc ? t : 0),
                                  cadM: a.cadM + cad * t, cadW: a.cadW + (cad ? t : 0),
                                  fcMax: Math.max(a.fcMax, Number(v.fcMaxima) || 0),
                                  cadMax: Math.max(a.cadMax, Number(v.cadenciaMaxima) || 0),
                                  g: a.g + (Number(v.gananciaElev) || 0),
                                  p: a.p + (Number(v.perdidaElev) || 0),
                                };
                              }, { d: 0, t: 0, fcM: 0, fcW: 0, cadM: 0, cadW: 0, fcMax: 0, cadMax: 0, g: 0, p: 0 });
                              const fmtTot = (sg) => (sg >= 3600
                                ? `${Math.floor(sg / 3600)}:${String(Math.floor((sg % 3600) / 60)).padStart(2, '0')}:${String(Math.floor(sg % 60)).padStart(2, '0')}`
                                : formatLapTime(sg));
                              const paceSec = tot.d > 0 ? tot.t / tot.d : 0;
                              const ritmoMed = actividad === 'Ciclismo'
                                ? (tot.t > 0 ? (tot.d / (tot.t / 3600)).toFixed(1) : '')
                                : (paceSec > 0 ? `${Math.floor(paceSec / 60)}:${String(Math.round(paceSec % 60)).padStart(2, '0')}` : '');
                              let ritmoMax = '';
                              const rits = vueltas.map((v) => v.ritmo).filter((x) => x != null && x !== '');
                              if (actividad === 'Ciclismo') {
                                const xs = rits.map(Number).filter(Number.isFinite);
                                ritmoMax = xs.length ? String(Math.max(...xs)) : '';
                              } else {
                                const xs = rits.map((q) => { const m = String(q).match(/^(\d+):(\d{1,2})$/); return m ? (+m[1]) * 60 + (+m[2]) : NaN; }).filter(Number.isFinite);
                                if (xs.length) { const mm = Math.min(...xs); ritmoMax = `${Math.floor(mm / 60)}:${String(mm % 60).padStart(2, '0')}`; }
                              }
                              const unit = actividad === 'Ciclismo' ? ' km/h' : '/km';
                              const fcMed = tot.fcW ? Math.round(tot.fcM / tot.fcW) : 0;
                              const cadMed = tot.cadW ? Math.round(tot.cadM / tot.cadW) : 0;
                              const cSum = { color: theme.muted, fontWeight: '700' };
                              return (
                                <View style={[s.lapDataRow, { backgroundColor: theme.input, borderBottomWidth: 0, borderTopWidth: 1, borderTopColor: theme.border }]}>
                                  <Text style={[s.lapDataCell, { width: 50 }, cSum]}>Σ</Text>
                                  <Text style={[s.lapDataCell, { width: 80 }, cSum]}>{tot.d.toFixed(2)} km</Text>
                                  <Text style={[s.lapDataCell, { width: 80 }, cSum]}>{fmtTot(tot.t)}</Text>
                                  <Text style={[s.lapDataCell, { width: 90 }, cSum]}>{ritmoMed ? `${ritmoMed}${unit}` : '—'}</Text>
                                  <Text style={[s.lapDataCell, { width: 90 }, cSum]}>{ritmoMax ? `${ritmoMax}${unit}` : '—'}</Text>
                                  <Text style={[s.lapDataCell, { width: 70 }, cSum]}>{fcMed || '—'}</Text>
                                  <Text style={[s.lapDataCell, { width: 70 }, cSum]}>{tot.fcMax || '—'}</Text>
                                  <Text style={[s.lapDataCell, { width: 80 }, cSum]}>{cadMed || '—'}</Text>
                                  <Text style={[s.lapDataCell, { width: 80 }, cSum]}>{tot.cadMax || '—'}</Text>
                                  <Text style={[s.lapDataCell, { width: 90 }, cSum]}>{tot.g || '—'}</Text>
                                  <Text style={[s.lapDataCell, { width: 90 }, cSum]}>{tot.p || '—'}</Text>
                                  <Text style={[s.lapDataCell, { width: 90 }, cSum]}>{Number((tot.g - tot.p).toFixed(1)) || '—'}</Text>
                                </View>
                              );
                            })()}
                          </View>
                        </ScrollView>
                      ) : (
                        <View style={s.emptySubTab}>
                          <Ionicons name="construct-outline" size={32} color="#2A4060" />
                          <Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Sin datos de vueltas','No lap data')}</Text>
                        </View>
                      )}
                    </View>
                  )}

                  {subTab === 'detalles' && (
                    <View style={s.detallesContainer}>
                      {(loadingHeavyData || loadingRegistros) ? (
                        <View style={s.emptySubTab}>
                          <ActivityIndicator color={BLUE} />
                          <Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Cargando datos de sensores...','Loading sensor data...')}</Text>
                        </View>
                      ) : registros && registros.length > 1 ? (
                        <>
                          <ActivityChart registros={registrosGrafica} cadenceUnit={cadenceUnit} fcZones={fcZones} ritmoZones={ritmoZones} tipo={actividad} />
                          <GpsMap registros={registros} vueltas={vueltas} />
                        </>
                      ) : (
                        <View style={s.emptySubTab}>
                          <Ionicons name="construct-outline" size={32} color="#2A4060" />
                          <Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Sin datos de registros','No record data')}</Text>
                        </View>
                      )}
                    </View>
                  )}

                  {subTab === 'curvafc' && (
                    <View style={{ padding: 10 }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8, gap: 6 }}>
                        <Text style={{ color: theme.muted, fontSize: 11 }}>{L('Media últimos:', 'Average last:')}</Text>
                        {[42, 90, 365].map((d) => <TouchableOpacity key={d} onPress={() => setCurveDays(d)} style={{ paddingHorizontal: 9, paddingVertical: 5, borderRadius: 6, backgroundColor: curveDays === d ? BLUE : theme.card, borderWidth: 1, borderColor: curveDays === d ? BLUE : theme.border }}><Text style={{ color: curveDays === d ? '#fff' : theme.muted, fontSize: 11 }}>{d}d</Text></TouchableOpacity>)}
                        <View style={{ width: 10, height: 2, backgroundColor: '#68758A', marginLeft: 4 }} /><Text style={{ color: theme.muted, fontSize: 10 }}>{L('media', 'average')}</Text>
                      </View>
                      {curveDays == null && (
                        <Text style={{ color: theme.muted, fontSize: 11, marginBottom: 8 }}>{L('La media está desactivada: elige 42d, 90d o 365d para calcularla.', 'The average is off: pick 42d, 90d or 365d to calculate it.')}</Text>
                      )}
                      {loadingRegistros ? <View style={s.emptySubTab}><ActivityIndicator color={BLUE} /><Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Cargando registros...','Loading records...')}</Text></View> : curvaFcPts.length >= 2 ? (
                        <>
                          <ChartCard title={L('Curva de FC (duración)', 'HR curve (duration)')} subtitle={L('Mejor FC media por duración · eje X logarítmico', 'Best average HR per duration · log X')} theme={theme} onExpand={() => setFullChart('fc')}>
                            <CurvaSkia pts={curvaFcPts} comparisonPts={curveHistory.fc} logX theme={theme} isLight={isLight} color="#E05252" height={180}
                              xTicks={XT_FC} xFmt={(v) => fmtVentana(v)} vFmt={(v) => `${Math.round(v)}`} />
                          </ChartCard>
                          <ChartCard title={L('Tiempo acumulado por FC', 'Cumulative time by HR')} subtitle={L('Tiempo total a cada FC o por encima · franjas de zona', 'Total time at or above each HR · zone bands')} theme={theme} onExpand={() => setFullChart('acum')}>
                            <CurvaSkia pts={acumFcPts} theme={theme} isLight={isLight} color="#E05252" height={180} zonas={zonasFc}
                              xFmt={(v) => `${Math.round(v)}`} vFmt={(v) => fmtAcum(v)} />
                          </ChartCard>
                        </>
                      ) : (
                        <View style={s.emptySubTab}><Ionicons name="pulse-outline" size={32} color="#2A4060" /><Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Sin datos de FC suficientes','Not enough HR data')}</Text></View>
                      )}
                    </View>
                  )}

                  {subTab === 'curvaritmo' && (
                    <View style={{ padding: 10 }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8, gap: 6 }}>
                        <Text style={{ color: theme.muted, fontSize: 11 }}>{L('Media últimos:', 'Average last:')}</Text>
                        {[42, 90, 365].map((d) => <TouchableOpacity key={d} onPress={() => setCurveDays(d)} style={{ paddingHorizontal: 9, paddingVertical: 5, borderRadius: 6, backgroundColor: curveDays === d ? BLUE : theme.card, borderWidth: 1, borderColor: curveDays === d ? BLUE : theme.border }}><Text style={{ color: curveDays === d ? '#fff' : theme.muted, fontSize: 11 }}>{d}d</Text></TouchableOpacity>)}
                        <View style={{ width: 10, height: 2, backgroundColor: '#68758A', marginLeft: 4 }} /><Text style={{ color: theme.muted, fontSize: 10 }}>{L('media', 'average')}</Text>
                      </View>
                      {curveDays == null && (
                        <Text style={{ color: theme.muted, fontSize: 11, marginBottom: 8 }}>{L('La media está desactivada: elige 42d, 90d o 365d para calcularla.', 'The average is off: pick 42d, 90d or 365d to calculate it.')}</Text>
                      )}
                      {loadingRegistros ? <View style={s.emptySubTab}><ActivityIndicator color={BLUE} /><Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Cargando registros...','Loading records...')}</Text></View> : curvaRitmoPts.length >= 2 ? (
                        <ChartCard
                          title={actividad === 'Ciclismo' ? L('Curva de velocidad por distancia', 'Speed curve by distance') : L('Curva de ritmo por distancia', 'Pace curve by distance')}
                          subtitle={actividad === 'Ciclismo' ? L('Mejor velocidad media para cada distancia', 'Best average speed for each distance') : L('Mejor ritmo medio para cada distancia · más arriba = más rápido', 'Best average pace for each distance · higher = faster')}
                          theme={theme} onExpand={() => setFullChart('ritmo')}>
                          <CurvaSkia pts={curvaRitmoPts} comparisonPts={curveHistory.ritmo} logX invertY={actividad !== 'Ciclismo'} theme={theme} isLight={isLight} color="#9A7BEB" height={190}
                            xTicks={actividad === 'Ciclismo' ? XT_KM_BIKE : XT_KM_RUN} xFmt={(v) => `${v} km`} vFmt={(v) => (actividad === 'Ciclismo' ? `${v}` : fmtPace(v))} />
                        </ChartCard>
                      ) : (
                        <View style={s.emptySubTab}><Ionicons name="speedometer-outline" size={32} color="#2A4060" /><Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Sin datos de ritmo suficientes','Not enough pace data')}</Text></View>
                      )}
                    </View>
                  )}

                  {subTab === 'picos' && (
                    <View style={[s.lapsContainer, { backgroundColor: theme.card, borderColor: theme.border }]}>
                      {loadingRegistros ? <View style={s.emptySubTab}><ActivityIndicator color={BLUE} /><Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Cargando registros...','Loading records...')}</Text></View> : esfuerzos.length ? (
                        <View style={{ padding: 10, gap: 8 }}>
                          <Text style={[s.emptySubTabText, { color: theme.muted, textAlign: 'center', fontWeight: '800' }]}>{L('MEJORES ESFUERZOS', 'BEST EFFORTS')}</Text>
                          <TablaEsfuerzos rows={esfuerzos} actividad={actividad} theme={theme} />
                          <Text style={[s.emptySubTabText, { color: theme.muted, textAlign: 'center' }]}>{L('Mejor tiempo en cubrir cada distancia dentro del entreno', 'Best time to cover each distance within the workout')}</Text>
                        </View>
                      ) : (
                        <View style={s.emptySubTab}><Ionicons name="trending-up-outline" size={32} color="#2A4060" /><Text style={[s.emptySubTabText, { color: theme.muted }]}>{L('Sin registros suficientes para picos','Not enough records for peaks')}</Text></View>
                      )}
                    </View>
                  )}

                  <FullChartModal
                    visible={!!fullChart}
                    onClose={() => setFullChart(null)}
                    theme={theme}
                    title={fullChart === 'fc' ? L('Curva de FC (duración)', 'HR curve (duration)') : fullChart === 'acum' ? L('Tiempo acumulado por FC', 'Cumulative time by HR') : (actividad === 'Ciclismo' ? L('Curva de velocidad por distancia', 'Speed curve by distance') : L('Curva de ritmo por distancia', 'Pace curve by distance'))}
                  >
                    {(H) => (fullChart === 'fc' ? (
                      <CurvaSkia pts={curvaFcPts} comparisonPts={curveHistory.fc} logX interactive theme={theme} isLight={isLight} color="#E05252" height={H}
                        xTicks={XT_FC} xFmt={(v) => fmtVentana(v)} vFmt={(v) => `${Math.round(v)}`}
                        tip={{ v: (pt) => `${Math.round(pt.v)} ppm` }} />
                    ) : fullChart === 'acum' ? (
                      <CurvaSkia pts={acumFcPts} interactive theme={theme} isLight={isLight} color="#E05252" height={H} zonas={zonasFc}
                        xFmt={(v) => `${Math.round(v)}`} vFmt={(v) => fmtAcum(v)}
                        tip={{ v: (pt) => fmtAcum(pt.v) }} />
                    ) : (
                      <CurvaSkia pts={curvaRitmoPts} comparisonPts={curveHistory.ritmo} logX invertY={actividad !== 'Ciclismo'} interactive theme={theme} isLight={isLight} color="#9A7BEB" height={H}
                        xTicks={actividad === 'Ciclismo' ? XT_KM_BIKE : XT_KM_RUN} xFmt={(v) => `${v} km`} vFmt={(v) => (actividad === 'Ciclismo' ? `${v}` : fmtPace(v))}
                        tip={{ v: (pt) => (actividad === 'Ciclismo' ? `${pt.v} km/h` : `${fmtPace(pt.v)}/km`) }} />
                    ))}
                  </FullChartModal>

                  {subTab === 'zonas' && (
                    <View style={s.zonesContainer}>
                      {!registros || registros.length < 2 ? (
                        <Text style={s.emptyText}>{L('Este entreno no tiene datos de registros.','This workout has no record data.')}</Text>
                      ) : fcZones.length === 0 && ritmoZones.length === 0 && potDistribution.length === 0 ? (
                        <Text style={s.emptyText}>{L('No hay zonas configuradas. Ve a Ajustes → Zonas para definirlas.','No zones configured. Go to Settings → Zones to define them.')}</Text>
                      ) : (
                        <ScrollView>
                          {/* Selector de dato por zona: porcentaje / tiempo / km */}
                          <View style={{ flexDirection: 'row', gap: 6, marginBottom: 10 }}>
                            {[['pct', L('Porcentaje', 'Percentage')], ['tiempo', L('Tiempo', 'Time')], ['km', 'km']].map(([v, label]) => (
                              <TouchableOpacity key={v} onPress={() => setModoZonas(v)} activeOpacity={0.8}
                                style={{ paddingHorizontal: 14, paddingVertical: 7, borderRadius: 999, borderWidth: 1, borderColor: modoZonas === v ? BLUE : theme.border, backgroundColor: modoZonas === v ? BLUE + '1F' : 'transparent' }}>
                                <Text style={{ color: modoZonas === v ? BLUE : theme.muted, fontSize: 12, fontWeight: '800' }}>{label}</Text>
                              </TouchableOpacity>
                            ))}
                          </View>
                          {ritmoZones.length > 0 && (
                            <View style={[s.zoneDistCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
                              <Text style={[s.zoneDistTitle, { color: theme.text }]}>{L('Ritmo','Pace')}</Text>
                              {ritmoDistribution.filter(z=>z.time>0).map((z,i)=>{
                                const total=ritmoDistribution.reduce((a,b)=>a+b.time,0);
                                const pct=total>0?(z.time/total)*100:0;
                                return (
                                  <View key={z.id} style={[s.zoneDistRow, { borderBottomColor: theme.border }]}>
                                    <View style={[s.zoneDistBar,{width:`${Math.min(pct,100)}%`,backgroundColor:'#4A90E2'}]} />
                                    <Text style={[s.zoneDistLabel, { color: theme.muted }]}>{z.titulo||z.label||`${L('Zona','Zone')} ${i+1}`}</Text>
                                    <Text style={[s.zoneDistValue, { color: theme.text }]}>{modoZonas === 'tiempo' ? formatSeconds(Math.round(z.time)) : modoZonas === 'km' ? `${(z.dist||0).toFixed(2)} km` : `${pct.toFixed(1)}%`}</Text>
                                  </View>
                                );
                              })}
                            </View>
                          )}
                          {fcZones.length > 0 && (
                            <View style={[s.zoneDistCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
                              <Text style={[s.zoneDistTitle, { color: theme.text }]}>{L('Frecuencia Cardíaca','Heart Rate')}</Text>
                              {fcDistribution.filter(z=>z.time>0).map((z,i)=>{
                                const total=fcDistribution.reduce((a,b)=>a+b.time,0);
                                const pct=total>0?(z.time/total)*100:0;
                                return (
                                  <View key={z.id} style={[s.zoneDistRow, { borderBottomColor: theme.border }]}>
                                    <View style={[s.zoneDistBar,{width:`${Math.min(pct,100)}%`,backgroundColor:'#E05252'}]} />
                                    <Text style={[s.zoneDistLabel, { color: theme.muted }]}>Z{i+1}</Text>
                                    <Text style={[s.zoneDistValue, { color: theme.text }]}>{modoZonas === 'tiempo' ? formatSeconds(Math.round(z.time)) : modoZonas === 'km' ? `${(z.dist||0).toFixed(2)} km` : `${pct.toFixed(1)}%`}</Text>
                                  </View>
                                );
                              })}
                            </View>
                          )}
                          {potDistribution.length > 0 && (
                            <View style={[s.zoneDistCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
                              <Text style={[s.zoneDistTitle, { color: theme.text }]}>{L('Potencia','Power')}</Text>
                              {potDistribution.filter(z=>z.time>0).map((z,i)=>{
                                const total=potDistribution.reduce((a,b)=>a+b.time,0);
                                const pct=total>0?(z.time/total)*100:0;
                                return (
                                  <View key={z.id} style={[s.zoneDistRow, { borderBottomColor: theme.border }]}>
                                    <View style={[s.zoneDistBar,{width:`${Math.min(pct,100)}%`,backgroundColor:'#F5A623'}]} />
                                    <Text style={[s.zoneDistLabel, { color: theme.muted }]}>{z.titulo||z.label||`${L('Zona','Zone')} ${i+1}`}</Text>
                                    <Text style={[s.zoneDistValue, { color: theme.text }]}>{modoZonas === 'tiempo' ? formatSeconds(Math.round(z.time)) : modoZonas === 'km' ? `${(z.dist||0).toFixed(2)} km` : `${pct.toFixed(1)}%`}</Text>
                                  </View>
                                );
                              })}
                            </View>
                          )}
                        </ScrollView>
                      )}
                    </View>
                  )}
                  </>)}
                </ScrollView>
                {!esProgramado && subTab === 'general' && !kbOpen && (
                  <View style={s.footer}>
                    <TouchableOpacity style={[s.btnPrimary, loading && s.disabled]} onPress={handleSaveSession} disabled={loading}>
                      {loading ? <ActivityIndicator color="#fff" /> : <Text style={s.btnPrimaryText}>{L('Guardar','Save')}</Text>}
                    </TouchableOpacity>
                    <TouchableOpacity style={[s.btnSecondary, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={onClose}>
                      <Text style={[s.btnSecondaryText, { color: theme.text }]}>{L('Cancelar','Cancel')}</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </>
            )}

            {mode === 'view' && mainTab === 'comentarios' && (
              <View style={{ flex: 1 }}>
                <ScrollView style={s.scroll} contentContainerStyle={s.scrollPad}>
                  <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Deja un comentario','Leave a comment')}</Text>
                  <TextInput style={[s.commentInput, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={comentario} onChangeText={setComentario} multiline placeholder={L('Deja un comentario','Leave a comment')} placeholderTextColor="#4A6080" />
                  <TouchableOpacity style={[s.btnEnviar, sendingComm && s.disabled]} onPress={handleSendComment} disabled={sendingComm}>
                    {sendingComm ? <ActivityIndicator color="#fff" size="small" /> : <Text style={s.btnEnviarText}>{L('Enviar','Send')}</Text>}
                  </TouchableOpacity>
                  {comentarios.length > 0 && (
                    <View style={{ marginTop: 20 }}>
                      {comentarios.map((c,i) => {
                        const ts = c.timestamp?.toDate ? c.timestamp.toDate() : new Date(c.timestamp ?? Date.now());
                        return (
                          <View key={i} style={[s.commentCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
                            <View style={s.commentHeader}>
                              <View style={{flex:1}}>
                                <Text style={[s.commentName, { color: BLUE }]}>{c.nombre||L('Usuario','User')}</Text>
                                <Text style={[s.commentTime, { color: theme.muted }]}>{ts.toLocaleDateString(loc,{day:'numeric',month:'short'})}</Text>
                              </View>
                              <TouchableOpacity onPress={() => handleDeleteComment(c)}>
                                <Ionicons name="trash-outline" size={16} color={RED} />
                              </TouchableOpacity>
                            </View>
                            <Text style={[s.commentText, { color: theme.text }]}>{c.texto}</Text>
                          </View>
                        );
                      })}
                    </View>
                  )}
                </ScrollView>
              </View>
            )}

            {mode === 'edit' && mainTab === 'edit' && (
              <>
                <ScrollView ref={editScrollRef} style={s.scroll} contentContainerStyle={s.scrollPad} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
                  <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Actividad','Activity')}</Text>
                  <FullScreenPicker value={actividad} options={TIPOS_ACTIV} onChange={setActividad} iconTipo={actividad} iconColor={iconColor} placeholder={L('Escoge','Choose')} title={L('Selecciona una opción','Select an option')} cancelText={L('Cancelar','Cancel')} />
                  <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border, marginTop: 6 }]}>
                    <AutoGrowTextInput minHeight={44} style={[s.inputInner, { color: theme.text }]} value={titulo} onChangeText={setTitulo} placeholder={L('Título del entrenamiento','Workout title')} placeholderTextColor="#4A6080" />
                  </View>
                  <View style={s.fieldRow}>
                    <View style={s.fieldHalf}>
                      <Text style={[s.fieldLabel,{marginTop:12}]}>{L('Fecha','Date')}</Text>
                      <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border }]}><TouchableOpacity style={{ flex: 1 }} onPress={() => setCalFecha(true)} activeOpacity={0.7}><Text style={[s.inputInner, { color: theme.text }]}>{fechaStr || 'DD/MM/AAAA'}</Text></TouchableOpacity></View>
                    </View>
                    <View style={s.fieldHalf}>
                      <Text style={[s.fieldLabel,{marginTop:12}]}>{L('Hora','Time')}</Text>
                      <FullScreenPicker value={horaMode} options={HORA_OPTS} onChange={setHoraMode} placeholder={L('Escoge','Choose')} title={L('Selecciona una opción','Select an option')} cancelText={L('Cancelar','Cancel')} />
                      {horaMode === 'Personalizado' && (
                        <TextInput style={[s.inputInner, { color: theme.text, backgroundColor: theme.card, borderColor: theme.border, borderWidth: 1, borderRadius: 6, padding: 10, marginTop: 6 }]} value={horaCustom} onChangeText={setHoraCustom} placeholder="HH:MM" placeholderTextColor={theme.muted} keyboardType="number-pad" />
                      )}
                    </View>
                  </View>
                  <Text style={[s.fieldLabel,{marginTop:12}]}>{L('Pasos','Steps')}</Text>
                  <StepEditor pasos={pasos} setPasos={setPasos} profileUid={athleteId || auth.currentUser?.uid} actividad={actividad} />
                  <Text style={[s.fieldLabel, { color: theme.muted }]}>{L('Descripción','Description')}</Text>
                  <AutoGrowTextInput minHeight={80} style={[s.textarea, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={descripcion} onChangeText={setDescripcion} placeholder={L('Detalles del entreno...','Workout details...')} placeholderTextColor="#4A6080" onFocus={() => setTimeout(() => editScrollRef.current?.scrollToEnd({ animated: true }), 150)} />
                  <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
                    <TouchableOpacity style={[s.archBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={cargarArchivoDirecto} disabled={subiendoArch} activeOpacity={0.75}>
                      {subiendoArch ? <ActivityIndicator size="small" color={BLUE} /> : <Ionicons name="cloud-upload-outline" size={16} color={BLUE} />}
                      <Text style={{ color: theme.text, fontWeight: '700', fontSize: 13 }}>{subiendoArch ? L('Subiendo…','Uploading…') : L('Cargar archivo','Upload file')}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[s.archBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => setPickerArch(true)} activeOpacity={0.75}>
                      <Ionicons name="library-outline" size={16} color={BLUE} />
                      <Text style={{ color: theme.text, fontWeight: '700', fontSize: 13 }}>{L('Cargar de librería','Load from library')}</Text>
                    </TouchableOpacity>
                  </View>
                  {archivos.length > 0 && (
                    <View style={{ gap: 6, marginTop: 8 }}>
                      {archivos.map((a, i) => (
                        <View key={a.id || `${i}-${a.nombre}`} style={[s.archChip, { backgroundColor: theme.card, borderColor: theme.border }]}>
                          {a.tipo === 'ejercicio'
                            ? <MaterialCommunityIcons name="dumbbell" size={16} color="#2DB37A" />
                            : <Ionicons name={a.tipo === 'pdf' ? 'document-text-outline' : 'image-outline'} size={16} color={BLUE} />}
                          <Text style={{ color: theme.text, fontSize: 12, flex: 1 }} numberOfLines={1}>{a.nombre}</Text>
                          <TouchableOpacity onPress={() => setArchivos((xs) => xs.filter((_, j) => j !== i))} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                            <Ionicons name="close-circle" size={18} color="#E05252" />
                          </TouchableOpacity>
                        </View>
                      ))}
                    </View>
                  )}
                  <View style={s.libToggleRow}>
                    <Text style={[s.libToggleText, { color: theme.text }]}>{L('Añadir a librería','Add to library')}</Text>
                    <Switch value={saveLib} onValueChange={handleToggleLib} trackColor={{ false: '#1E3048', true: BLUE }} thumbColor="#fff" />
                  </View>
                  {actividad === 'Evento' && puedeEditarEntreno && (
                    <View style={[s.partBox, { borderColor: theme.border, marginTop: 14 }]}>
                      {/* Título + lupa EN LA MISMA FILA (como Mi Entrenador) */}
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                        <Text style={[s.partTitle, { color: theme.text, flex: 1 }]}>{L('Atletas del evento', 'Event athletes')}</Text>
                        <TouchableOpacity
                          onPress={() => { setBuscaAbiertaEv((v) => !v); setBuscaAtletaEv(''); }}
                          style={{ width: 30, height: 30, borderRadius: 15, borderWidth: 1.5, borderColor: buscaAbiertaEv || buscaAtletaEv ? BLUE : theme.border, backgroundColor: buscaAbiertaEv || buscaAtletaEv ? BLUE + '22' : 'transparent', alignItems: 'center', justifyContent: 'center' }}
                          activeOpacity={0.8}
                        >
                          <Ionicons name="search" size={14} color={BLUE} />
                        </TouchableOpacity>
                      </View>
                      {/* Recuadro de búsqueda: solo al desplegarlo con la lupa */}
                      {(buscaAbiertaEv || buscaAtletaEv.trim() !== '') && (
                        <View style={[s.inputBox, { backgroundColor: theme.card, borderColor: theme.border, flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 8, marginBottom: 4 }]}>
                          <TextInput
                            style={[s.inputInner, { flex: 1, color: theme.text }]}
                            value={buscaAtletaEv}
                            onChangeText={setBuscaAtletaEv}
                            placeholder={L('Buscar atleta por nombre…', 'Search athlete by name…')}
                            placeholderTextColor="#4A6080"
                          />
                          {buscaAtletaEv !== '' && (
                            <TouchableOpacity onPress={() => setBuscaAtletaEv('')} hitSlop={8}>
                              <Ionicons name="close-circle" size={16} color="#8FA8C8" />
                            </TouchableOpacity>
                          )}
                        </View>
                      )}
                      {loadingAtletas ? (
                        <ActivityIndicator size="small" color={BLUE} />
                      ) : misAtletas.length === 0 ? (
                        <Text style={[s.partEmpty, { color: theme.muted }]}>{L('No tienes atletas', 'You have no athletes')}</Text>
                      ) : misAtletas.filter(a => {
                        const t = buscaAtletaEv.trim().toLowerCase();
                        return !t || `${a.nombre || ''} ${a.apellido || ''}`.toLowerCase().includes(t);
                      }).map(a => {
                        const on = asignados.includes(a.uid);
                        const nombre = `${a.nombre || ''} ${a.apellido || ''}`.trim();
                        return (
                          <TouchableOpacity key={a.uid} style={s.partRow} onPress={() => toggleAsignado(a.uid)} activeOpacity={0.8}>
                            {a.foto ? (
                              <Image source={{ uri: `data:image/jpeg;base64,${a.foto}` }} style={s.partPhoto} />
                            ) : (
                              <View style={[s.partPhoto, { backgroundColor: theme.input }]}><Text style={[s.partInitial, { color: theme.muted }]}>{(a.nombre || '?').charAt(0).toUpperCase()}</Text></View>
                            )}
                            <Text style={[s.partName, { color: theme.text }]} numberOfLines={1}>{nombre}</Text>
                            <Ionicons name={on ? 'checkmark-circle' : 'add-circle-outline'} size={22} color={on ? GREEN : theme.muted} />
                          </TouchableOpacity>
                        );
                      })}
                    </View>
                  )}
                  <View style={s.reassignBox}>
                    <TouchableOpacity style={[s.reassignBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={toggleReassign} activeOpacity={0.8}>
                      <Ionicons name="swap-horizontal-outline" size={18} color={BLUE} />
                      <Text style={[s.reassignBtnText, { color: theme.text }]}>{L('Reasignar planificado', 'Reassign planned')}</Text>
                      <Ionicons name={reassignOpen ? 'chevron-up' : 'chevron-down'} size={16} color={theme.muted} />
                    </TouchableOpacity>
                    {reassignOpen && (
                      <View style={[s.reassignList, { borderColor: theme.border }]}>
                        {loadingPlans ? (
                          <ActivityIndicator size="small" color={BLUE} />
                        ) : (
                          dayPlans.map(p => (
                            <TouchableOpacity key={p.id} style={[s.reassignRow, { backgroundColor: theme.input }]} onPress={() => confirmReassign(p)} activeOpacity={0.8}>
                              <ActivityIcon tipo={p.tipo} size={18} />
                              <View style={{ flex: 1 }}>
                                <Text style={[s.reassignRowTitle, { color: theme.text }]} numberOfLines={1}>{p.titulo || p.tipo}</Text>
                                <Text style={[s.reassignRowSub, { color: theme.muted }]}>{fmtHora(p.fecha)}</Text>
                              </View>
                              <Ionicons name="arrow-forward-circle-outline" size={20} color={BLUE} />
                            </TouchableOpacity>
                          ))
                        )}
                        {!loadingPlans && dayPlans.length === 0 && (
                          <Text style={[s.reassignEmpty, { color: theme.muted }]}>{L('No hay planificados ese día', 'No planned workouts that day')}</Text>
                        )}
                        {workout?.mergedFromPlanId ? (
                          <TouchableOpacity style={[s.reassignRow, { backgroundColor: RED + '14' }]} onPress={confirmSplit} activeOpacity={0.8}>
                            <Ionicons name="call-split-outline" size={18} color={RED} />
                            <Text style={[s.reassignRowTitle, { color: RED }]} numberOfLines={1}>{L('Separar en planificado + realizado', 'Split into planned + completed')}</Text>
                          </TouchableOpacity>
                        ) : null}
                      </View>
                    )}
                  </View>
                </ScrollView>
                {!kbOpen && (
                <View style={s.footerRow}>
                  <TouchableOpacity style={[s.btnPrimary, loading && s.disabled]} onPress={handleSaveEdit} disabled={loading}>
                    {loading ? <ActivityIndicator color="#fff" /> : <Text style={s.btnPrimaryText}>{L('Guardar','Save')}</Text>}
                  </TouchableOpacity>
                  <TouchableOpacity style={s.btnDelete} onPress={handleDelete}>
                    <Text style={s.btnDeleteText}>{L('Borrar','Delete')}</Text>
                  </TouchableOpacity>
                </View>
                )}
              </>
            )}

            {mode === 'edit' && mainTab === 'libreria' && (
              <LibreriaDrive
                onLoad={handleLoadFromLibrary}
                onEdit={handleEditFromLibrary}
                onAdd={handleNuevaPlantilla}
              />
            )}
          </View>
        </View>
      </KeyboardAvoidingView>
      <PickerCarpetaLibreria
        visible={!!pickerLib}
        onClose={() => setPickerLib(null)}
        onElegir={elegirCarpetaParaGuardar}
        textoBoton={L('Guardar aquí', 'Save here')}
        titulo={L('Guardar en la librería', 'Save to library')}
        subtitulo={titulo || actividad}
      />
      {/* Librería de archivos + visores de adjuntos */}
      <ArchivosPicker
        visible={pickerArch}
        onClose={() => setPickerArch(false)}
        onSelect={(e) => { setArchivos((xs) => [...xs, e]); setPickerArch(false); }}
      />
      <PickerCarpetaArchivos
        visible={carpetaPickOpen}
        onClose={() => { setCarpetaPickOpen(false); setPendienteArch(null); }}
        onElegir={confirmarSubidaArch}
        titulo={L('Guardar en tu librería', 'Save to your library')}
        textoBoton={L('Subir aquí', 'Upload here')}
      />
      <EjercicioViewer
        visible={!!viewerGym}
        gymId={viewerGym?.id}
        nombre={viewerGym?.nombre}
        onClose={() => setViewerGym(null)}
      />
      {/* Visor de imagen adjunta CON ZOOM (pellizco/doble toque, como el chat) */}
      <VisorImagenZoom visible={!!visorImg} url={visorImg?.url} onClose={() => setVisorImg(null)} />
      <MonthPickerModal
        visible={calFecha}
        initialDate={(() => { const p = String(fechaStr || '').split('/').map(Number); const d = p.length === 3 && p.every(Number.isFinite) ? new Date(p[2], p[1] - 1, p[0]) : new Date(); return isNaN(d.getTime()) ? new Date() : d; })()}
        onClose={() => setCalFecha(false)}
        onSelect={(d) => { const p = (n) => String(n).padStart(2, '0'); setFechaStr(`${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`); setCalFecha(false); }}
      />
      <SystemBars />
    </Modal>
  );
}

function FieldBox({ label, value, children }) {
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  return (
    <View style={[s.fieldBox, { backgroundColor: theme.card, borderColor: theme.border }]}>
      <Text style={[s.fieldLabel, { color: theme.muted }]}>{label}</Text>
      {children ?? <Text style={[s.fieldValue, { color: theme.text }]}>{value ?? '—'}</Text>}
    </View>
  );
}

const s = StyleSheet.create({
  kav:{flex:1}, overlay:{flex:1,backgroundColor:'#000000BB',justifyContent:'flex-end'},
  sheet:{backgroundColor:NAVY,height:'95%',borderTopLeftRadius:20, borderTopRightRadius:20},
  header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:16,paddingVertical:14,borderBottomWidth:1,borderBottomColor:BORDER},
  headerSide:{width:60}, headerTitle:{color:'#fff',fontSize:16,fontWeight:'700',flex:1,textAlign:'center'}, editBtn:{color:BLUE,fontWeight:'700',fontSize:15,textAlign:'right'},
  tabs:{flexDirection:'row',borderBottomWidth:1,borderBottomColor:BORDER},
  tab:{flex:1,paddingVertical:9,alignItems:'center',flexDirection:'row',justifyContent:'center',gap:4},
  tabActive:{borderBottomWidth:2,borderBottomColor:BLUE},
  tabText:{color:'#8FA8C8',fontWeight:'600',fontSize:14}, tabTextActive:{color:'#fff',fontWeight:'700',fontSize:14},
  subTabs:{flexDirection:'row',borderBottomWidth:1,borderBottomColor:BORDER,paddingHorizontal:6},
  subTab:{flexShrink:0,paddingVertical:10,paddingHorizontal:12,alignItems:'center'}, subTabActive:{borderBottomWidth:2,borderBottomColor:BLUE},
  subTabText:{color:'#4A6080',fontSize:13}, subTabTextActive:{color:'#fff',fontWeight:'700',fontSize:13},
  scroll:{flex:1}, scrollPad:{padding:16,gap:10,paddingBottom:20},
  titleCard:{flexDirection:'row',alignItems:'center',gap:12,backgroundColor:CARD,padding:14,borderRadius:8,marginBottom:4},
  actIcon:{width:40,height:40,borderRadius:20,borderWidth:1.5,alignItems:'center',justifyContent:'center'},
  titleCardName:{color:'#fff',fontSize:15,fontWeight:'700'}, titleCardDate:{color:'#8FA8C8',fontSize:13,marginTop:2},
  sectionHead:{color:'#8FA8C8',fontSize:13,fontWeight:'600',marginTop:4},
  descBox:{backgroundColor:CARD,borderRadius:8,padding:12,minHeight:48,borderWidth:1,borderColor:BORDER}, descText:{color:'#8FA8C8',fontSize:14},
  archBtn:{flex:1,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:7,borderWidth:1,borderRadius:10,paddingVertical:10},
  archChip:{flexDirection:'row',alignItems:'center',gap:8,borderWidth:1,borderRadius:8,paddingHorizontal:10,paddingVertical:7},
  archMini:{width:34,height:34,borderRadius:6,backgroundColor:'#00000022'},
  visorImgWrap:{flex:1,backgroundColor:'#000000E6',justifyContent:'center',alignItems:'center'},
  visorImgClose:{position:'absolute',top:46,right:18,zIndex:5,backgroundColor:'#00000088',borderRadius:18,padding:6},
  grid2:{flexDirection:'row',gap:8}, fieldBox:{flex:1,backgroundColor:CARD,borderRadius:8,padding:12,borderWidth:1,borderColor:BORDER},
  fieldLabel:{color:'#8FA8C8',fontSize:12,marginBottom:4}, fieldValue:{color:'#fff',fontSize:14,fontWeight:'600'},
  estadoRow:{flexDirection:'row',gap:8}, estadoBtn:{flex:1,alignItems:'center',justifyContent:'center',paddingVertical:12,borderRadius:8,borderWidth:1.5},
  estadoBtnRojoOff:{backgroundColor:'transparent',borderColor:RED+'60'}, estadoBtnRojoOn:{backgroundColor:RED,borderColor:RED},
  estadoBtnVerdeOff:{backgroundColor:'transparent',borderColor:GREEN+'60'}, estadoBtnVerdeOn:{backgroundColor:GREEN,borderColor:GREEN},
  generalWrap:{gap:10,paddingTop:4}, fieldRow:{flexDirection:'row',gap:8}, fieldHalf:{flex:1,gap:4},
  inputBox:{backgroundColor:CARD,borderRadius:6,borderWidth:1,borderColor:BORDER,paddingHorizontal:12,paddingVertical:11},
  inputInner:{color:'#fff',fontSize:14,padding:0}, unitText:{color:'#8FA8C8',fontSize:13,marginRight:2},
  moodRow:{flexDirection:'row',justifyContent:'space-between',marginTop:6},
  moodBtn:{width:48,height:48,borderRadius:24,backgroundColor:CARD,alignItems:'center',justifyContent:'center',borderWidth:2,borderColor:BORDER},
  moodBtnActive:{borderColor:BLUE,backgroundColor:BLUE+'33'}, moodEmoji:{fontSize:22},
  emptySubTab:{alignItems:'center',paddingVertical:40,gap:10}, emptySubTabText:{color:'#2A4060',fontSize:14,textAlign:'center'},
  commentInput:{backgroundColor:CARD,borderRadius:8,borderWidth:1,borderColor:BORDER,padding:14,color:'#fff',minHeight:100,textAlignVertical:'top',fontSize:14,marginBottom:10},
  btnEnviar:{backgroundColor:BLUE,paddingHorizontal:20,paddingVertical:10,borderRadius:8,alignSelf:'flex-start'}, btnEnviarText:{color:'#fff',fontWeight:'700',fontSize:14},
  commentCard:{backgroundColor:CARD,borderRadius:10,padding:12,marginBottom:8},
  commentHeader:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:4},
  commentName:{color:BLUE,fontWeight:'700',fontSize:13}, commentTime:{color:'#4A6080',fontSize:12}, commentText:{color:'#fff',fontSize:14,lineHeight:20},
  lapsContainer:{marginTop:8,backgroundColor:CARD,borderRadius:8,borderWidth:1,borderColor:BORDER,overflow:'hidden'},
  lapHeaderRow:{flexDirection:'row',backgroundColor:'#0A1828',paddingVertical:10,paddingHorizontal:4},
  lapHeaderCell:{color:'#8FA8C8',fontSize:12,fontWeight:'700',textAlign:'center'},
  lapDataRow:{flexDirection:'row',paddingVertical:8,paddingHorizontal:4,borderBottomWidth:1,borderBottomColor:BORDER},
  lapDataCell:{color:'#fff',fontSize:12,textAlign:'center'},
  detallesContainer:{marginTop:8}, zonesContainer:{paddingHorizontal:8,paddingTop:8},
  zoneDistCard:{backgroundColor:CARD,borderRadius:10,padding:14,marginBottom:12,borderWidth:1,borderColor:BORDER},
  zoneDistTitle:{color:'#fff',fontSize:16,fontWeight:'700',marginBottom:10},
  zoneDistRow:{position:'relative',flexDirection:'row',justifyContent:'space-between',paddingVertical:8,paddingHorizontal:12,borderBottomWidth:1,borderBottomColor:BORDER,overflow:'hidden'},
  zoneDistLabel:{color:'#8FA8C8',fontSize:14,fontWeight:'600'}, zoneDistBar:{position:'absolute',top:0,bottom:0,left:0,borderRadius:6,opacity:0.25}, zoneDistValue:{color:'#fff',fontSize:14},
  emptyText:{color:'#8FA8C8',fontSize:14,textAlign:'center',marginTop:30},
  textarea:{backgroundColor:CARD,borderRadius:8,borderWidth:1,borderColor:BORDER,padding:14,color:'#fff',minHeight:80,textAlignVertical:'top',fontSize:14},
  libToggleRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginTop:12,paddingHorizontal:4},
  reassignBox:{marginTop:14},
  reassignBtn:{flexDirection:'row',alignItems:'center',justifyContent:'center',gap:8,borderRadius:8,borderWidth:1,paddingVertical:10},
  reassignBtnText:{fontSize:14,fontWeight:'600'},
  reassignList:{marginTop:8,borderWidth:1,borderRadius:8,padding:8,gap:6},
  reassignRow:{flexDirection:'row',alignItems:'center',gap:10,borderRadius:8,paddingHorizontal:10,paddingVertical:10},
  reassignRowTitle:{fontSize:14,fontWeight:'600'},
  reassignRowSub:{fontSize:12,marginTop:2},
  reassignEmpty:{fontSize:13,textAlign:'center',paddingVertical:8},
  moodEmojiOff:{opacity:0.35},
  partBox:{marginTop:10,borderWidth:1,borderRadius:8,padding:10,gap:6},
  partTitle:{fontSize:14,fontWeight:'700'},
  partEmpty:{fontSize:13,textAlign:'center',paddingVertical:6},
  partRow:{flexDirection:'row',alignItems:'center',gap:10,paddingVertical:6},
  partPhoto:{width:34,height:34,borderRadius:17,alignItems:'center',justifyContent:'center'},
  partInitial:{fontSize:15,fontWeight:'700'},
  partName:{flex:1,fontSize:14,fontWeight:'600'},
  libToggleText:{fontSize:14,fontWeight:'600'},
  libSaveBtn:{flexDirection:'row',alignItems:'center',justifyContent:'center',gap:8,backgroundColor:BLUE,borderRadius:8,paddingVertical:12,marginTop:12},
  libSaveBtnText:{color:'#fff',fontWeight:'700',fontSize:14},
  footer:{flexDirection:'row',paddingHorizontal:12,paddingTop:6,paddingBottom:6,gap:10,borderTopWidth:1,borderTopColor:BORDER},
  btnPrimary:{flex:1,backgroundColor:BLUE,paddingVertical:10,borderRadius:8,alignItems:'center'}, btnPrimaryText:{color:'#fff',fontWeight:'700',fontSize:14},
  btnSecondary:{flex:1,backgroundColor:CARD,paddingVertical:10,borderRadius:8,alignItems:'center',borderWidth:1,borderColor:BORDER}, btnSecondaryText:{color:'#fff',fontWeight:'700',fontSize:14},
  footerRow:{flexDirection:'row',paddingHorizontal:12,paddingTop:6,paddingBottom:6,gap:10,borderTopWidth:1,borderTopColor:BORDER},
  btnDelete:{flex:1,backgroundColor:RED,paddingVertical:10,borderRadius:8,alignItems:'center'}, btnDeleteText:{color:'#fff',fontWeight:'700',fontSize:14},
  disabled:{opacity:0.5},
  libControls:{paddingHorizontal:16,paddingTop:12,gap:10}, libSortRow:{flexDirection:'row',gap:8},
  libSortBtn:{flex:1,alignItems:'center',backgroundColor:CARD,borderWidth:1,borderColor:BORDER,borderRadius:8,paddingVertical:8},
  libSortBtnActive:{backgroundColor:BLUE,borderColor:BLUE}, libSortBtnText:{color:'#8FA8C8',fontSize:12,fontWeight:'600'}, libSortBtnTextActive:{color:'#fff'},
  libSearchBox:{flexDirection:'row',alignItems:'center',gap:8,backgroundColor:CARD,borderWidth:1,borderColor:BORDER,borderRadius:8,paddingHorizontal:12,paddingVertical:8},
  libSearchInput:{flex:1,color:'#fff',fontSize:14,padding:0},
  libRow:{flexDirection:'row',alignItems:'center',gap:10,backgroundColor:CARD,borderRadius:10,borderWidth:1,borderColor:BORDER,paddingHorizontal:12,paddingVertical:12,marginBottom:8},
  libRowMain:{flexDirection:'row',alignItems:'center',flex:1,gap:10}, libRowTitle:{color:'#fff',fontSize:14,fontWeight:'700'}, libRowMeta:{color:'#8FA8C8',fontSize:12,marginTop:2}, libDeleteBtn:{padding:6},
});
