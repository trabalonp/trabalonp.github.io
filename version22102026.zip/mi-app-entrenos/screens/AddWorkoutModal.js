// screens/AddWorkoutModal.js
// REDISEÑO VISUAL con animaciones (entrada escalonada de los campos, pestañas con
// indicador deslizante, selector a pantalla completa animado, guardar con destello).
// La lógica (guardado en Firestore, avisos al atleta, librería, archivos, pasos) es la MISMA.
import { Ionicons } from '@expo/vector-icons';
import {
  addDoc, collection, Timestamp, updateDoc, deleteDoc, increment, doc, getDoc,
} from 'firebase/firestore';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, Animated, Easing, KeyboardAvoidingView, Modal, Platform, Pressable,
  ScrollView, StyleSheet, Switch, Text, TextInput, TouchableOpacity, View, useColorScheme,
} from 'react-native';
import { getCachedProfile } from '../services/profileCache';
import { getApiUrl } from '../services/api';
import { getCoachFullName, sendNotificationToAthlete } from '../services/coachNotify';
import { auth, db } from '../firebaseConfig';
import AutoGrowTextInput from '../components/AutoGrowTextInput';
import LibreriaDrive, { PickerCarpetaLibreria } from '../components/LibreriaDrive';
import { libreriaStoreInit, libreriaStorePut } from '../services/libreriaStore';
import MonthPickerModal from '../components/MonthPickerModal';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getThemeColors, useAppSettings } from '../services/appSettings';
import StepEditor, { emptyStep, normalizeStep } from '../components/StepEditor';
import SystemBars from '../components/SystemBars';
import ActivityIcon from '../components/ActivityIcon';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import ArchivosPicker, { PickerCarpetaArchivos } from '../components/ArchivosPicker';
import { subirArchivoDeEntreno } from '../services/archivosUpload';

const NAVY='#0D1B2A', CARD='#162032', BLUE='#4A90E2', BORDER='#1E3048', RED='#E05252';

// Valores GUARDADOS en Firestore (no se traducen): se guarda el string original y se pinta traducido
const TIPOS_ACTIVIDAD = [
  { label: 'Running', icon: 'run', color: '#E05252' },
  { label: 'Ciclismo', icon: 'bicycle', color: '#F5A623' },
  { label: 'Natación', icon: 'water', color: '#4A90E2' },
  { label: 'Fuerza', icon: 'barbell', color: '#9B59B6' },
  { label: 'Triatlón', icon: 'medal-outline', color: '#2DB37A' },
  { label: 'Evento', icon: 'trophy', color: '#4A90E2' },
  { label: 'Descanso', icon: 'moon', color: '#7F8FA6' },
  { label: 'Notas', icon: 'journal-outline', color: '#8D6E63' },
  { label: 'Otro', icon: 'flash', color: '#8FA8C8' },
];
const TIPO_ICON = { Running:'run', Ciclismo:'bicycle', Natación:'water', Fuerza:'barbell', Triatlón:'medal-outline', Otro:'flash', Evento:'trophy', Descanso:'moon', Notas:'journal-outline' };

// Picker a pantalla completa: guarda `value ?? label` y pinta la etiqueta traducida
/* ════════════════════════════════════════════════════════════════════════════
   REDISEÑO VISUAL con animaciones (la lógica de guardado, librería, archivos,
   avisos al atleta y pasos NO cambia)
   ════════════════════════════════════════════════════════════════════════════ */
function FadeIn({ delay = 0, children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, { toValue: 1, duration: 380, delay, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [v, delay]);
  return (
    <Animated.View style={[style, { opacity: v, transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) }] }]}>
      {children}
    </Animated.View>
  );
}
function Press({ onPress, disabled, style, children, hitSlop }) {
  const sc = useRef(new Animated.Value(1)).current;
  const to = (v) => Animated.spring(sc, { toValue: v, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <Pressable onPress={onPress} disabled={disabled} hitSlop={hitSlop} onPressIn={() => to(0.96)} onPressOut={() => to(1)}>
      <Animated.View style={[style, { transform: [{ scale: sc }] }]}>{children}</Animated.View>
    </Pressable>
  );
}
function PopCheck() {
  const sc = useRef(new Animated.Value(0)).current;
  useEffect(() => { Animated.spring(sc, { toValue: 1, useNativeDriver: true, speed: 18, bounciness: 14 }).start(); }, [sc]);
  return <Animated.View style={{ transform: [{ scale: sc }] }}><Ionicons name="checkmark-circle" size={22} color={BLUE} /></Animated.View>;
}
// Destello que cruza el botón de guardar
function Shine() {
  const [w, setW] = useState(0);
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(v, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      Animated.delay(2600),
      Animated.timing(v, { toValue: 0, duration: 0, useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [v]);
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      <Animated.View style={{ position: 'absolute', top: -30, height: 120, width: 28, backgroundColor: 'rgba(255,255,255,0.22)', transform: [{ translateX: v.interpolate({ inputRange: [0, 1], outputRange: [-60, w + 60] }) }, { rotate: '20deg' }] }} />
    </View>
  );
}
// Pestañas con indicador deslizante
function TabsDeslizantes({ items, value, onChange, theme }) {
  const [w, setW] = useState(0);
  const x = useRef(new Animated.Value(0)).current;
  const idx = Math.max(0, items.findIndex((i) => i[0] === value));
  useEffect(() => {
    if (w > 0) Animated.spring(x, { toValue: idx * (w / items.length), useNativeDriver: true, speed: 18, bounciness: 6 }).start();
  }, [idx, w, items.length, x]);
  return (
    <View style={[styles.tabs, { borderBottomColor: theme.border }]} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      {items.map(([id, label, icon]) => {
        const on = value === id;
        return (
          <Pressable key={id} style={styles.tab} onPress={() => onChange(id)}>
            <Ionicons name={icon} size={15} color={on ? BLUE : theme.muted} style={{ marginRight: 6 }} />
            <Text style={[styles.tabText, { color: on ? theme.text : theme.muted }, on && styles.tabTextActive]}>{label}</Text>
          </Pressable>
        );
      })}
      {w > 0 && <Animated.View pointerEvents="none" style={{ position: 'absolute', bottom: 0, left: 0, width: w / items.length, height: 3, borderRadius: 2, backgroundColor: BLUE, transform: [{ translateX: x }] }} />}
    </View>
  );
}

function FullScreenPicker({ value, options, onChange, placeholder='Escoge', iconTipo, icon, iconColor, title, cancelText, theme }) {
  const insets = useSafeAreaInsets();
  const [visible, setVisible] = useState(false);
  const isObj = options[0] && typeof options[0] === 'object';
  const valOf = (o) => (isObj ? (o.value ?? o.label) : o);
  const lblOf = (o) => (isObj ? o.label : o);
  const select = (o) => { onChange(valOf(o)); setVisible(false); };
  const currentLabel = isObj ? (options.find(o => valOf(o) === value)?.label ?? value) : value;
  return (
    <>
      <Press style={[pk.btn, { backgroundColor: theme?.card, borderColor: theme?.border }]} onPress={() => setVisible(true)}>
        <View style={pk.pickerLeft}>
          {iconTipo ? <ActivityIcon tipo={iconTipo} size={18} color={iconColor || '#8FA8C8'} style={{ marginRight: 8 }} /> : (icon ? <Ionicons name={icon} size={18} color={iconColor || '#8FA8C8'} style={{ marginRight: 8 }} /> : null)}
          <Text style={[pk.text, { color: currentLabel ? theme?.text : theme?.muted }]} numberOfLines={1}>{currentLabel || placeholder}</Text>
        </View>
        <Ionicons name="chevron-down" size={15} color={BLUE} />
      </Press>
      <Modal visible={visible} animationType="slide" transparent={false} onRequestClose={() => setVisible(false)}>
        <View style={[pk.fullScreen, { backgroundColor: theme?.background }]}>
          <View style={[pk.fullHeader, { borderBottomColor: theme?.border }]}>
            <Text style={[pk.fullTitle, { color: theme?.text }]}>{title ?? 'Selecciona una opción'}</Text>
            <Press onPress={() => setVisible(false)} style={[pk.closeBtn, { backgroundColor: theme?.card, borderColor: theme?.border }]} hitSlop={10}>
              <Ionicons name="close" size={22} color="#8FA8C8" />
            </Press>
          </View>
          <ScrollView style={pk.fullList} contentContainerStyle={{ paddingTop: 10 }} showsVerticalScrollIndicator={false}>
            {options.map((o, i) => {
              const sel = valOf(o) === value;
              return (
                <FadeIn key={String(valOf(o))} delay={Math.min(i * 35, 350)}>
                  <Pressable style={({ pressed }) => [pk.fullOption, { borderColor: sel ? BLUE : theme?.border, backgroundColor: sel ? BLUE + '1F' : pressed ? (theme?.card) : 'transparent' }]} onPress={() => select(o)}>
                    <View style={[pk.indexBadge, { backgroundColor: sel ? BLUE : theme?.card, borderColor: sel ? BLUE : theme?.border }]}>
                      <Text style={{ color: sel ? '#fff' : theme?.muted, fontWeight: '800', fontSize: 13 }}>{i + 1}</Text>
                    </View>
                    {isObj && o.icon ? <ActivityIcon tipo={valOf(o)} size={20} color={o.color || '#8FA8C8'} /> : null}
                    <Text style={[pk.fullOptionText, { color: sel ? BLUE : theme?.text }, sel && pk.fullOptionTextActive]}>{lblOf(o)}</Text>
                    {sel && <PopCheck />}
                  </Pressable>
                </FadeIn>
              );
            })}
          </ScrollView>
          <Press style={[pk.fullCancelBtn, { borderTopColor: theme?.border, paddingBottom: 18 + insets.bottom }]} onPress={() => setVisible(false)}>
            <Text style={pk.fullCancelText}>{cancelText ?? 'Cancelar'}</Text>
          </Press>
        </View>
        <SystemBars />
      </Modal>
    </>
  );
}
const pk = StyleSheet.create({
  btn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: CARD, borderRadius: 12, borderWidth: 1.5, borderColor: BORDER, paddingHorizontal: 12, paddingVertical: 12, marginVertical: 4 },
  pickerLeft: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  text: { color: '#fff', fontSize: 14, flex: 1 },
  ph: { color: '#4A6080' },
  fullScreen: { flex: 1, backgroundColor: NAVY },
  fullHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 56, paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: BORDER },
  fullTitle: { color: '#fff', fontSize: 18, fontWeight: '800' },
  closeBtn: { width: 38, height: 38, borderRadius: 19, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  fullList: { flex: 1, paddingHorizontal: 16 },
  fullOption: { flexDirection: 'row', alignItems: 'center', paddingVertical: 13, paddingHorizontal: 12, borderWidth: 1.5, borderRadius: 14, marginBottom: 8, gap: 12 },
  indexBadge: { width: 30, height: 30, borderRadius: 15, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  fullOptionActive: { backgroundColor: BLUE + '22', borderRadius: 8 },
  fullOptionIndex: { color: '#8FA8C8', fontSize: 16, fontWeight: '600', minWidth: 24 },
  fullOptionIndexActive: { color: BLUE },
  fullOptionText: { color: '#fff', fontSize: 16, flex: 1 },
  fullOptionTextActive: { color: BLUE, fontWeight: '800' },
  fullCancelBtn: { paddingVertical: 18, alignItems: 'center', borderTopWidth: 1, borderTopColor: BORDER, marginTop: 8 },
  fullCancelText: { color: RED, fontSize: 16, fontWeight: '700' },
});


export default function AddWorkoutModal({ visible, onClose, initialDate, onWorkoutAdded, athleteId }) {
  const insets = useSafeAreaInsets();
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const lang = settings.language;            // re-renderiza al cambiar idioma
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción

  const fecha = initialDate ?? new Date();
  const [loading, setLoading] = useState(false);
  const [mainTab, setMainTab] = useState('nuevo');
  const [actividad, setActividad] = useState('Running');
  const [titulo, setTitulo] = useState('');
  const [fechaStr, setFechaStr] = useState(fecha.toLocaleDateString('es-ES')); // formato de almacenamiento DD/MM/AAAA
  const [horaMode, setHoraMode] = useState('Mañana');
  const [horaCustom, setHoraCustom] = useState('08:00');
  const [descripcion, setDescripcion] = useState('');
  const [pasos, setPasos] = useState([]);

  const [saveLib, setSaveLib] = useState(false); // switch "Añadir a librería"
  const [archivos, setArchivos] = useState([]);       // adjuntos del entreno (R2/gimnasio)
  const [pickerArch, setPickerArch] = useState(false);
  const [subiendoArch, setSubiendoArch] = useState(false);

  // Al abrir el modal se limpian los adjuntos de la sesión anterior.
  useEffect(() => { if (visible) { setArchivos([]); setPickerArch(false); } }, [visible]);

  // "Cargar archivo": del dispositivo → R2 (archivos/{uid}/…) → se añade a la
  // librería de archivos AUTOMÁTICAMENTE y al entreno.
  const [pendienteArch, setPendienteArch] = useState(null);   // asset esperando carpeta
  const [carpetaPickOpen, setCarpetaPickOpen] = useState(false);

  // 1) Elige el archivo del dispositivo…
  const cargarArchivoDirecto = async () => {
    try {
      const res = await DocumentPicker.getDocumentAsync({ copyToCacheDir: true });
      if (!res || res.canceled || !res.assets || !res.assets[0]) return;
      setPendienteArch(res.assets[0]);
      setCarpetaPickOpen(true);   // 2) …y elige la carpeta de tu librería
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };
  // 3) Sube a R2, guarda en la librería (carpeta elegida) y adjunta al entreno.
  const confirmarSubidaArch = async (carpetaId) => {
    const a = pendienteArch;
    setPendienteArch(null);
    if (!a) return;
    setSubiendoArch(true);
    try {
      const e = await subirArchivoDeEntreno(auth.currentUser, {
        uri: a.uri, nombre: a.name || 'archivo', contentType: a.mimeType || 'application/octet-stream', size: a.size || 0, carpeta: carpetaId,
      });
      setArchivos((xs) => [...xs, { id: e.id, tipo: e.tipo, url: e.url, nombre: e.nombre, thumb: (e.tipo === 'imagen' || e.tipo === 'gif') ? e.url : null, size: e.size }]);
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
    finally { setSubiendoArch(false); }
  };
  const [libDocId, setLibDocId] = useState(null); // doc de libreria creado por el switch
  const [modoLibreria, setModoLibreria] = useState(false); // creando sesión NUEVA para la librería
  const [libOrigenId, setLibOrigenId] = useState(null);   // sesión de librería en edición
  const libItemRef = useRef(null);                 // sesión completa en edición (para reflejar el guardado en el almacén local)
  const [pickerLib, setPickerLib] = useState(null);       // { accion } selector de carpeta destino
  const [calFecha, setCalFecha] = useState(false);        // calendario para elegir la fecha
  const actSel = TIPOS_ACTIVIDAD.find(t => t.label === actividad) || TIPOS_ACTIVIDAD[0];

  // Opciones de hora traducidas (el valor guardado sigue siendo el original)
  const HORA_OPTS = [
    { value: 'Mañana', label: L('Mañana', 'Morning') },
    { value: 'Tarde', label: L('Tarde', 'Afternoon') },
    { value: 'Personalizado', label: L('Personalizado', 'Custom') },
  ];

  // El formulario SOLO se resetea al ABRIR el modal (visible false→true).
  // Antes dependía de `initialDate`, y como el calendario pasaba
  // `selectedDay ?? new Date()` (objeto nuevo en cada render), cualquier
  // re-render del calendario MIENTRAS editabas reseteaba el formulario a
  // mitad de la edición: el título/pasos se perdían y, peor, libOrigenId se
  // ponía a null, así que al guardar una sesión editada desde la librería se
  // creaba un entreno nuevo en el calendario en vez de actualizar la sesión.
  const prevVisible = useRef(false);
  useEffect(() => {
    if (visible && !prevVisible.current) {
      const d = initialDate ?? new Date();
      setMainTab('nuevo'); setActividad('Running'); setTitulo('');
      setFechaStr(d.toLocaleDateString('es-ES')); setHoraMode('Mañana'); setHoraCustom('08:00');
      setDescripcion(''); setPasos([]); setLoading(false); setSaveLib(false); setLibDocId(null); setModoLibreria(false); setLibOrigenId(null); setPickerLib(null); libItemRef.current = null;
    }
    prevVisible.current = visible;
  }, [visible, initialDate]);

  const horaFinal = () => horaMode === 'Mañana' ? '08:00' : horaMode === 'Tarde' ? '18:00' : (horaCustom || '08:00');

  const handleClose = () => {
    if (pasos.length > 0 || titulo) {
      Alert.alert(L('Descartar', 'Discard'), L('¿Seguro que quieres salir?', 'Are you sure you want to exit?'), [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        { text: L('Salir', 'Exit'), style: 'destructive', onPress: onClose },
      ]);
    } else onClose();
  };

  const handleSave = async () => {
    if (!titulo.trim()) { Alert.alert(L('Error', 'Error'), L('El título es obligatorio.', 'Title is required.')); return; }
    // Editando una SESIÓN de la librería: se actualiza la sesión, sin tocar
    // el calendario (de ahí vino y ahí vuelve).
    if (libOrigenId) {
      setLoading(true);
      try {
        const pasosNuevos = pasos.map(normalizeStep);
        const upd = { tipo: actividad, titulo: titulo || actividad, descripcion: descripcion || '', pasos: pasosNuevos, archivos };
        await updateDoc(doc(db, 'libreria', libOrigenId), upd);
        // Reflejo INMEDIATO en el almacén local de la librería: al volver a la
        // pestaña (o al reabrir el modal) la sesión ya sale con lo guardado,
        // sin esperar al listener en vivo (y sin arriesgarse a re-editar la
        // copia vieja, que es lo que descartaba los cambios).
        try {
          await libreriaStoreInit(auth.currentUser?.uid);
          await libreriaStorePut({ ...(libItemRef.current || {}), ...upd });
        } catch (e) {}
        libItemRef.current = null;
        setLibOrigenId(null); setMainTab('libreria');
        Alert.alert(L('Guardado', 'Saved'), L('Sesión actualizada en la librería.', 'Session updated in the library.'));
      } catch (e) { Alert.alert(L('Error', 'Error'), e.message); } finally { setLoading(false); }
      return;
    }
    // Creando una sesión NUEVA para la librería: se pide carpeta destino y
    // se guarda solo en la librería (no en el calendario).
    if (modoLibreria) { setPickerLib({ accion: 'crear' }); return; }
    setLoading(true);
    try {
      const targetUserId = athleteId || auth.currentUser?.uid;
      if (!targetUserId) { Alert.alert(L('Error', 'Error'), L('No se pudo determinar el usuario.', 'Could not determine the user.')); setLoading(false); return; }
      const partes = fechaStr.split('/');
      const fechaFinal = new Date(partes[2], partes[1] - 1, partes[0]);
      const [h, m] = horaFinal().split(':');
      fechaFinal.setHours(parseInt(h), parseInt(m || 0));
      const pasosGuardados = pasos.map(normalizeStep);
      const docNuevo = {
        userId: targetUserId,
        // Quién lo crea: si el coach lo crea en el calendario del atleta, el
        // userId es el del atleta pero creadoPor es el del coach. La app usa
        // este campo para que el atleta no pueda editarlo ni moverlo.
        creadoPor: auth.currentUser?.uid || targetUserId,
        tipo: actividad,
        titulo: titulo || actividad,
        fecha: Timestamp.fromDate(fechaFinal),
        fechaStr,
        descripcion,
        archivos,
        pasos: pasosGuardados,
        estado: null,
        garminSynced: false,
        createdAt: Timestamp.now(),
      };
      // Evento creado en el calendario de un atleta: el atleta entra directo
      // en la lista de apuntados del evento
      if (athleteId && actividad === 'Evento') docNuevo.asignados = [athleteId];
      const refNew = await addDoc(collection(db, 'entrenamientos'), docNuevo);
      if (saveLib && libDocId) {
        try {
          await updateDoc(doc(db, 'libreria', libDocId), { tipo: actividad, titulo: titulo || actividad, descripcion: descripcion || '', pasos: pasosGuardados, archivos, workoutId: refNew.id });
        } catch (e) {}
      }
      if (onWorkoutAdded) onWorkoutAdded();
      if (athleteId) {
        const coachName = await getCoachFullName(auth.currentUser.uid);
        // El título/cuerpo los compone el servidor en el idioma del atleta,
        // y en "creado"/"evento" ya incluye el día para el que se programó.
        await sendNotificationToAthlete(athleteId, auth.currentUser.uid, {
          kind: actividad === 'Evento' ? 'evento' : 'creado',
          coachName,
          nombre: titulo || actividad,
          fechaStr,
          workoutId: refNew.id,
        });
      }
      onClose();
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally { setLoading(false); }
  };

  const handleToggleLib = async (value) => {
    if (!value) {
      // OFF: se quita de la librería lo que se añadió con este switch
      setSaveLib(false);
      if (libDocId) { try { await deleteDoc(doc(db, 'libreria', libDocId)); } catch (e) {} setLibDocId(null); }
      return;
    }
    // ON: primero se elige la CARPETA destino; el doc se crea al elegir.
    setPickerLib({ accion: 'switch' });
  };

  // Carpeta elegida en el selector: crea la sesión en la librería.
  const elegirCarpetaParaGuardar = async (carpetaId) => {
    const uid = auth.currentUser?.uid; if (!uid) return;
    try {
      const base = { userId: uid, carpeta: carpetaId, tipo: actividad, titulo: titulo || actividad, descripcion: descripcion || '', pasos: pasos.map(normalizeStep), archivos, timesUsed: 0, createdAt: Timestamp.now() };
      if (pickerLib?.accion === 'switch') {
        const ref = await addDoc(collection(db, 'libreria'), base);
        setLibDocId(ref.id); setSaveLib(true);
        Alert.alert(L('Guardado', 'Saved'), L('Entrenamiento guardado en tu librería.', 'Workout saved to your library.'));
      } else {
        // Sesión nueva creada desde la librería: se guarda y se vuelve al listado.
        await addDoc(collection(db, 'libreria'), base);
        setModoLibreria(false);
        setMainTab('libreria');
      }
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };

  const handleLoadFromLibrary = async (item) => {
    setActividad(item.tipo ?? 'Running');
    setTitulo(item.titulo ?? '');
    setDescripcion(item.descripcion ?? '');
    setPasos((Array.isArray(item.pasos) ? item.pasos : []).map(p => ({
      ...emptyStep(), ...p,
      durTexto: p.durTexto ?? p.durValor ?? '',
      hijos: p.hijos || [],
    })));
    try { await updateDoc(doc(db, 'libreria', item.id), { timesUsed: increment(1) }); } catch (e) {}
    setLibOrigenId(null);
    setMainTab('nuevo');
  };

  // Editar una sesión de la librería: igual que cargarla, pero SIN sumar
  // uso y marcando que al guardar se actualiza la sesión, no el calendario.
  const handleEditFromLibrary = (item) => {
    setActividad(item.tipo ?? 'Running');
    setTitulo(item.titulo ?? '');
    setDescripcion(item.descripcion ?? '');
    setPasos((Array.isArray(item.pasos) ? item.pasos : []).map(p => ({
      ...emptyStep(), ...p,
      durTexto: p.durTexto ?? p.durValor ?? '',
      hijos: p.hijos || [],
    })));
    setArchivos(Array.isArray(item.archivos) ? item.archivos : []);
    setLibOrigenId(item.id);
    libItemRef.current = item;
    setMainTab('nuevo');
  };

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={handleClose}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.kav}>
        <View style={styles.overlay}>
          <View style={[styles.sheet, { backgroundColor: theme.background, paddingBottom: insets.bottom + 6 }]}>
            <View style={[styles.header, { borderBottomColor: theme.border, backgroundColor: theme.card }]}>
              <Press onPress={handleClose} style={[styles.closeBtn, { backgroundColor: theme.background, borderColor: theme.border }]} hitSlop={10}>
                <Ionicons name="close" size={22} color="#8FA8C8" />
              </Press>
              <Text style={[styles.headerTitle, { color: theme.text }]}>{L('Agregar entrenamiento', 'Add workout')}</Text>
              <View style={{ width: 38 }} />
            </View>
            <TabsDeslizantes
              theme={theme}
              value={mainTab}
              onChange={setMainTab}
              items={[['nuevo', L('Nuevo', 'New'), 'add-circle-outline'], ['libreria', L('Librería', 'Library'), 'library-outline']]}
            />
            {mainTab === 'nuevo' && (
              <>
                <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
                  <FadeIn>
                    <Text style={[styles.label, { color: theme.muted }]}>{L('Actividad', 'Activity')}</Text>
                    <FullScreenPicker theme={theme} value={actividad} options={TIPOS_ACTIVIDAD} onChange={setActividad} iconTipo={actividad} iconColor={actSel.color} placeholder={L('Escoge', 'Choose')} title={L('Selecciona una opción', 'Select an option')} cancelText={L('Cancelar', 'Cancel')} />
                  </FadeIn>
                  <FadeIn delay={70}>
                    <Text style={[styles.label, { color: theme.muted }]}>{L('Título', 'Title')}</Text>
                    <AutoGrowTextInput minHeight={44} style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={titulo} onChangeText={setTitulo} placeholder={L('Ej: Series Cuesta', 'e.g. Hill repeats')} placeholderTextColor="#4A6080" />
                  </FadeIn>
                  <FadeIn delay={140}>
                    <View style={styles.row}>
                      <View style={styles.col}>
                        <Text style={[styles.label, { color: theme.muted }]}>{L('Fecha', 'Date')}</Text>
                        <Press style={[styles.input, styles.dateInput, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => setCalFecha(true)}>
                          <Ionicons name="calendar-outline" size={16} color={BLUE} />
                          <Text style={{ color: theme.text, fontSize: 14, flex: 1 }}>{fechaStr || 'DD/MM/AAAA'}</Text>
                        </Press>
                      </View>
                      <View style={styles.col}>
                        <Text style={[styles.label, { color: theme.muted }]}>{L('Hora', 'Time')}</Text>
                        <FullScreenPicker theme={theme} value={horaMode} options={HORA_OPTS} onChange={setHoraMode} placeholder={L('Escoge', 'Choose')} title={L('Selecciona una opción', 'Select an option')} cancelText={L('Cancelar', 'Cancel')} />
                        {horaMode === 'Personalizado' && (
                          <TextInput style={[styles.input, { marginTop: 6, backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={horaCustom} onChangeText={setHoraCustom} placeholder="HH:MM" placeholderTextColor="#4A6080" keyboardType="number-pad" />
                        )}
                      </View>
                    </View>
                  </FadeIn>
                  <FadeIn delay={210}>
                    <Text style={[styles.label, { color: theme.muted }]}>{L('Pasos (opcional)', 'Steps (optional)')}</Text>
                    {/* profileUid: al crear un entreno para un atleta, las zonas
                        del picker deben ser las SUYAS (athleteId), no las mías */}
                    <StepEditor pasos={pasos} setPasos={setPasos} profileUid={athleteId || undefined} actividad={actividad} />
                  </FadeIn>
                  <FadeIn delay={280}>
                    <Text style={[styles.label, { color: theme.muted }]}>{L('Descripción', 'Description')}</Text>
                    <AutoGrowTextInput minHeight={80} style={[styles.textarea, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={descripcion} onChangeText={setDescripcion} placeholder={L('Detalles del entreno...', 'Workout details...')} placeholderTextColor="#4A6080" />
                  </FadeIn>
                  {/* Archivos del entreno: subir del dispositivo o de la librería */}
                  <FadeIn delay={350}>
                    <View style={{ flexDirection: 'row', gap: 10, marginTop: 4 }}>
                      <Press style={[styles.archBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={cargarArchivoDirecto} disabled={subiendoArch}>
                        {subiendoArch ? <ActivityIndicator size="small" color={BLUE} /> : <Ionicons name="cloud-upload-outline" size={16} color={BLUE} />}
                        <Text style={{ color: theme.text, fontWeight: '700', fontSize: 13 }}>{subiendoArch ? L('Subiendo…', 'Uploading…') : L('Cargar archivo', 'Upload file')}</Text>
                      </Press>
                      <Press style={[styles.archBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => setPickerArch(true)}>
                        <Ionicons name="library-outline" size={16} color={BLUE} />
                        <Text style={{ color: theme.text, fontWeight: '700', fontSize: 13 }}>{L('Cargar de librería', 'Load from library')}</Text>
                      </Press>
                    </View>
                    {archivos.length > 0 && (
                      <View style={{ gap: 6, marginTop: 8 }}>
                        {archivos.map((a, i) => (
                          <FadeIn key={a.id || `${i}-${a.nombre}`}>
                            <View style={[styles.archChip, { backgroundColor: theme.card, borderColor: theme.border }]}>
                              {a.tipo === 'ejercicio'
                                ? <MaterialCommunityIcons name="dumbbell" size={16} color="#2DB37A" />
                                : <Ionicons name={a.tipo === 'pdf' ? 'document-text-outline' : 'image-outline'} size={16} color={BLUE} />}
                              <Text style={{ color: theme.text, fontSize: 12, flex: 1 }} numberOfLines={1}>{a.nombre}</Text>
                              <TouchableOpacity onPress={() => setArchivos((xs) => xs.filter((_, j) => j !== i))} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                                <Ionicons name="close-circle" size={18} color="#E05252" />
                              </TouchableOpacity>
                            </View>
                          </FadeIn>
                        ))}
                      </View>
                    )}
                  </FadeIn>
                  <FadeIn delay={420}>
                    <View style={[styles.libToggleRow, { backgroundColor: theme.card, borderColor: theme.border }]}>
                      <Ionicons name="library-outline" size={18} color={BLUE} />
                      <Text style={[styles.libToggleText, { color: theme.text, flex: 1 }]}>{L('Añadir a librería', 'Add to library')}</Text>
                      <Switch value={saveLib} onValueChange={handleToggleLib} trackColor={{ false: '#1E3048', true: BLUE }} thumbColor="#fff" />
                    </View>
                  </FadeIn>
                </ScrollView>
                <View style={[styles.footer, { borderTopColor: theme.border }]}>
                  <Press style={[styles.saveBtn, loading && styles.disabled]} onPress={handleSave} disabled={loading}>
                    {!loading && <Shine />}
                    {loading ? <ActivityIndicator color="#fff" /> : (<><Ionicons name="checkmark-circle-outline" size={18} color="#fff" /><Text style={styles.saveBtnText}>{L('Guardar', 'Save')}</Text></>)}
                  </Press>
                </View>
              </>
            )}
            {mainTab === 'libreria' && (
              <LibreriaDrive
                onLoad={handleLoadFromLibrary}
                onEdit={handleEditFromLibrary}
                onAdd={() => { setModoLibreria(true); setLibOrigenId(null); setMainTab('nuevo'); }}
              />
            )}
          </View>
        </View>
      </KeyboardAvoidingView>
      <PickerCarpetaLibreria
        visible={!!pickerLib}
        onClose={() => setPickerLib(null)}
        onElegir={elegirCarpetaParaGuardar}
        textoBoton={L('Guardar aquí', 'Save here')}
        titulo={L('Guardar en la librería', 'Save to library')}
        subtitulo={titulo || actividad}
      />
      <ArchivosPicker
        visible={pickerArch}
        onClose={() => setPickerArch(false)}
        onSelect={(e) => { setArchivos((xs) => [...xs, e]); setPickerArch(false); }}
      />
      <PickerCarpetaArchivos
        visible={carpetaPickOpen}
        onClose={() => { setCarpetaPickOpen(false); setPendienteArch(null); }}
        onElegir={confirmarSubidaArch}
        titulo={L('Guardar en tu librería', 'Save to your library')}
        textoBoton={L('Subir aquí', 'Upload here')}
      />
      <MonthPickerModal
        visible={calFecha}
        initialDate={(() => { const p = String(fechaStr || '').split('/').map(Number); const d = p.length === 3 && p.every(Number.isFinite) ? new Date(p[2], p[1] - 1, p[0]) : new Date(); return isNaN(d.getTime()) ? new Date() : d; })()}
        onClose={() => setCalFecha(false)}
        onSelect={(d) => { const p = (n) => String(n).padStart(2, '0'); setFechaStr(`${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`); setCalFecha(false); }}
      />
      <SystemBars />
    </Modal>
  );
}

const styles = StyleSheet.create({
  kav: { flex: 1 },
  overlay: { flex: 1, backgroundColor: '#000000AA', justifyContent: 'flex-end' },
  sheet: { backgroundColor: NAVY, height: '95%', borderTopLeftRadius: 26, borderTopRightRadius: 26, paddingBottom: 20, overflow: 'hidden' },
  closeBtn: { width: 38, height: 38, borderRadius: 19, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  dateInput: { flexDirection: 'row', alignItems: 'center', gap: 8, minHeight: 50 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: BORDER },
  headerTitle: { color: '#fff', fontSize: 17, fontWeight: '800' },
  tabs: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: BORDER },
  tab: { flex: 1, paddingVertical: 12, alignItems: 'center', flexDirection: 'row', justifyContent: 'center' },
  tabActive: { flex: 1, paddingVertical: 9, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: BLUE },
  tabText: { color: '#8FA8C8', fontWeight: '600' },
  tabTextActive: { fontWeight: '700' },
  scroll: { flex: 1 },
  scrollContent: { padding: 16, gap: 12 },
  label: { color: '#8FA8C8', fontSize: 13, marginBottom: 4 },
  input: { backgroundColor: CARD, borderRadius: 12, borderWidth: 1.5, borderColor: BORDER, padding: 12, color: '#fff' },
  row: { flexDirection: 'row', gap: 10 },
  col: { flex: 1 },
  textarea: { backgroundColor: CARD, borderRadius: 12, borderWidth: 1.5, borderColor: BORDER, padding: 12, color: '#fff', minHeight: 80 },
  libToggleRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 4, paddingHorizontal: 12, paddingVertical: 8, borderWidth: 1.5, borderRadius: 14 },
  archBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, borderWidth: 1.5, borderRadius: 14, paddingVertical: 11 },
  archChip: { flexDirection: 'row', alignItems: 'center', gap: 8, borderWidth: 1, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 8 },
  libToggleText: { fontSize: 14, fontWeight: '600' },
  libSaveBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: BLUE, borderRadius: 8, paddingVertical: 12, marginTop: 8 },
  libSaveBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  footer: { paddingHorizontal: 14, paddingTop: 10, paddingBottom: 8, borderTopWidth: 1, borderTopColor: BORDER },
  saveBtn: { flexDirection: 'row', justifyContent: 'center', gap: 8, backgroundColor: BLUE, paddingVertical: 14, paddingHorizontal: 14, borderRadius: 16, alignItems: 'center', overflow: 'hidden' },
  saveBtnText: { color: '#fff', fontWeight: '800', fontSize: 15 },
  disabled: { backgroundColor: '#4A6080' },
  libControls: { paddingHorizontal: 16, paddingTop: 12, gap: 10 },
  libSortRow: { flexDirection: 'row', gap: 8 },
  libSortBtn: { flex: 1, alignItems: 'center', backgroundColor: CARD, borderWidth: 1, borderColor: BORDER, borderRadius: 8, paddingVertical: 8 },
  libSortBtnActive: { backgroundColor: BLUE, borderColor: BLUE },
  libSortBtnText: { color: '#8FA8C8', fontSize: 12, fontWeight: '600' },
  libSortBtnTextActive: { color: '#fff' },
  libSearchBox: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: CARD, borderWidth: 1, borderColor: BORDER, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8 },
  libSearchInput: { flex: 1, color: '#fff', fontSize: 14, padding: 0 },
  libEmpty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  libEmptyText: { color: '#2A4060', fontSize: 14 },
  libRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: CARD, borderRadius: 10, borderWidth: 1, borderColor: BORDER, paddingHorizontal: 12, paddingVertical: 12, marginBottom: 8 },
  libRowMain: { flexDirection: 'row', alignItems: 'center', flex: 1, gap: 10 },
  libRowTitle: { color: '#fff', fontSize: 14, fontWeight: '700' },
  libRowMeta: { color: '#8FA8C8', fontSize: 12, marginTop: 2 },
  libDeleteBtn: { padding: 6 },
});