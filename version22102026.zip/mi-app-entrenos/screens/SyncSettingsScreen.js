// screens/SyncSettingsScreen.js
// v3 — PANTALLA MÁS CLARA: menos texto y jerarquía simple. Intervals.icu (lo
// principal) siempre visible; «Importar .fit» y «Recalcular esfuerzo» van plegados
// con un resumen de una línea. Las guías son pasos de una línea. Se conservan los
// arreglos del teclado (sin LayoutAnimation, campos sin FadeIn ni foco interno).
// ─────────────────────────────────────────────────────────────────────────────
// REDISEÑO VISUAL + ANIMACIONES.
// La lógica (estados, handlers, llamadas a GarminSyncService / SyncService,
// Firebase auth, SAF/FileSystem, AsyncStorage) es la MISMA que la versión
// original. Solo cambia la capa visual. No necesita dependencias nuevas
// (usa Animated de React Native + @expo/vector-icons).
// ─────────────────────────────────────────────────────────────────────────────
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Alert, ActivityIndicator, Linking,
  TextInput, useColorScheme, Animated, Easing, Pressable,
  Platform, Keyboard, KeyboardAvoidingView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as FileSystem from 'expo-file-system/legacy';
import { auth } from '../firebaseConfig';
import { getThemeColors, useAppSettings } from '../services/appSettings';
import { resetSyncFolder, syncFitFiles, recalcularEsfuerzos } from '../services/SyncService';
import {
  getIntervalsStatus,
  saveIntervalsCredentials,
  disconnectIntervals,
} from '../services/GarminSyncService';

const { StorageAccessFramework } = FileSystem;

const NAVY   = '#0D1B2A';
const BLUE   = '#4A90E2';
const GREEN  = '#2DB37A';
const RED    = '#E05252';
const BORDER = '#1E3048';
const AMBER  = '#F5A623';
const FOLDER_KEY = 'fit_folder_uri';

/* ════════════════════════════════════════════════════════════════════════════
   COMPONENTES VISUALES / ANIMADOS
   ════════════════════════════════════════════════════════════════════════════ */

// Aparece con fundido + deslizamiento suave (entrada escalonada con `delay`)
function FadeIn({ delay = 0, children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, {
      toValue: 1, duration: 450, delay,
      easing: Easing.out(Easing.cubic), useNativeDriver: true,
    }).start();
  }, [v, delay]);
  return (
    <Animated.View
      style={[style, {
        opacity: v,
        transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [18, 0] }) }],
      }]}
    >
      {children}
    </Animated.View>
  );
}

// Botón/zona pulsable con efecto "muelle" al presionar
function PressableScale({ onPress, disabled, style, children, hitSlop }) {
  const sc = useRef(new Animated.Value(1)).current;
  const to = (value) =>
    Animated.spring(sc, { toValue: value, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      hitSlop={hitSlop}
      onPressIn={() => to(0.96)}
      onPressOut={() => to(1)}
    >
      <Animated.View style={[style, { transform: [{ scale: sc }] }]}>{children}</Animated.View>
    </Pressable>
  );
}

// Valor animado 0→1 en bucle (para anillos de pulso, puntos viajeros, etc.)
function useLoop(duration, active = true, easing = Easing.linear) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!active) { v.setValue(0); return undefined; }
    const loop = Animated.loop(
      Animated.timing(v, { toValue: 1, duration, easing, useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, [v, duration, active, easing]);
  return v;
}

// Nodo circular del héroe (reloj, nube, móvil)
function HeroNode({ icon, color, label, theme, rings, spin, size = 58 }) {
  const pulse = useLoop(2200, !!rings, Easing.out(Easing.quad));
  const rot = useLoop(1400, !!spin);
  const ringStyle = (phase) => ({
    position: 'absolute', width: size, height: size, borderRadius: size / 2,
    borderWidth: 2, borderColor: color,
    opacity: pulse.interpolate(
      phase === 0
        ? { inputRange: [0, 1], outputRange: [0.5, 0] }
        : { inputRange: [0, 0.5, 0.5, 1], outputRange: [0.22, 0, 0.5, 0.22] }
    ),
    transform: [{
      scale: pulse.interpolate(
        phase === 0
          ? { inputRange: [0, 1], outputRange: [1, 1.9] }
          : { inputRange: [0, 0.5, 0.5, 1], outputRange: [1.45, 1.9, 1, 1.45] }
      ),
    }],
  });
  return (
    <View style={s.nodeCol}>
      <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
        {rings && <Animated.View style={ringStyle(0)} />}
        {rings && <Animated.View style={ringStyle(1)} />}
        <View style={[s.node, {
          width: size, height: size, borderRadius: size / 2,
          backgroundColor: color + '24', borderColor: color,
        }]}>
          <Animated.View
            style={spin ? { transform: [{ rotate: rot.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] }) }] } : null}
          >
            <Ionicons name={icon} size={26} color={color} />
          </Animated.View>
        </View>
      </View>
      <Text style={[s.nodeLabel, { color: theme.muted }]} numberOfLines={1}>{label}</Text>
    </View>
  );
}

// Línea de conexión con puntos de luz que viajan de un nodo a otro
function FlowLine({ color, active, fast }) {
  const [w, setW] = useState(0);
  const v = useLoop(fast ? 900 : 2200, active);
  return (
    <View style={s.flowLine} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      <View style={[s.flowBase, { backgroundColor: active ? color + '40' : '#4A608044' }]} />
      {active && (
        <>
          <Animated.View
            style={[s.flowDot, {
              backgroundColor: color,
              opacity: v.interpolate({ inputRange: [0, 0.1, 0.9, 1], outputRange: [0, 1, 1, 0] }),
              transform: [{ translateX: v.interpolate({ inputRange: [0, 1], outputRange: [0, Math.max(w - 9, 0)] }) }],
            }]}
          />
          <Animated.View
            style={[s.flowDot, {
              backgroundColor: color,
              opacity: v.interpolate({ inputRange: [0, 0.4, 0.5, 0.5, 0.6, 1], outputRange: [1, 1, 0, 0, 1, 1] }),
              transform: [{
                translateX: v.interpolate({
                  inputRange: [0, 0.5, 0.5, 1],
                  outputRange: [Math.max(w - 9, 0) / 2, Math.max(w - 9, 0), 0, Math.max(w - 9, 0) / 2],
                }),
              }],
            }]}
          />
        </>
      )}
    </View>
  );
}

// Cabecera visual: Garmin → Intervals.icu → tu app
function SyncHero({ status, busy, checking, theme, L }) {
  const connected = status === 'connected';
  const accent = connected ? GREEN : checking ? BLUE : AMBER;
  const flowing = connected || busy;
  const text = busy
    ? L('Sincronizando…', 'Syncing…')
    : checking
      ? L('Comprobando conexión…', 'Checking connection…')
      : connected
        ? L('Todo conectado', 'All connected')
        : L('Sin conectar', 'Not connected');
  return (
    <View style={[s.hero, { backgroundColor: theme.card, borderColor: accent + '55' }]}>
      <View style={[s.blob, { backgroundColor: accent + '16', top: -50, right: -30, width: 150, height: 150 }]} />
      <View style={[s.blob, { backgroundColor: BLUE + '10', bottom: -60, left: -40, width: 130, height: 130 }]} />
      <View style={s.heroRow}>
        <HeroNode icon="watch-outline" color={connected ? GREEN : BLUE} label="Garmin" theme={theme} />
        <FlowLine color={accent} active={flowing} fast={busy} />
        <HeroNode icon="sync" color={accent} label="Intervals.icu" theme={theme} rings={flowing} spin={busy} />
        <FlowLine color={accent} active={flowing} fast={busy} />
        <HeroNode icon="phone-portrait-outline" color={connected ? GREEN : BLUE} label={L('Tu app', 'Your app')} theme={theme} />
      </View>
      <View style={[s.chip, { backgroundColor: accent + '1F', borderColor: accent + '66' }]}>
        <View style={[s.chipDot, { backgroundColor: accent }]} />
        <Text style={[s.chipText, { color: accent }]}>{text}</Text>
      </View>
    </View>
  );
}

// Icono con halo que late (estado "conectado")
function PulsingIcon({ name, color, size = 26 }) {
  const v = useLoop(1800, true, Easing.out(Easing.quad));
  return (
    <View style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
      <Animated.View
        style={{
          position: 'absolute', width: 36, height: 36, borderRadius: 18, backgroundColor: color,
          opacity: v.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0] }),
          transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.8, 1.5] }) }],
        }}
      />
      <Ionicons name={name} size={size} color={color} />
    </View>
  );
}

// Destello que cruza el botón principal cada pocos segundos. Se PAUSA
// mientras el teclado está abierto: en Android, la animación nativa en bucle
// al abrirse el teclado hacía que este se cerrara al instante (los campos de
// texto parecían no poder escribirse).
function Shine() {
  const [w, setW] = useState(0);
  const [kbOpen, setKbOpen] = useState(false);
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const s = Keyboard.addListener('keyboardDidShow', () => setKbOpen(true));
    const h = Keyboard.addListener('keyboardDidHide', () => setKbOpen(false));
    return () => { s.remove(); h.remove(); };
  }, []);
  useEffect(() => {
    if (kbOpen) { v.setValue(0); return undefined; }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(v, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.delay(2600),
        Animated.timing(v, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [v, kbOpen]);
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      <Animated.View
        style={[s.shine, {
          transform: [
            { translateX: v.interpolate({ inputRange: [0, 1], outputRange: [-60, w + 60] }) },
            { rotate: '20deg' },
          ],
        }]}
      />
    </View>
  );
}

// Botón de acción (sólido o "tintado")
function ActionButton({ icon, label, onPress, color = BLUE, variant = 'solid', loading, disabled, shine, style }) {
  const solid = variant === 'solid';
  const fg = solid ? '#fff' : color;
  return (
    <PressableScale
      onPress={onPress}
      disabled={disabled || loading}
      style={[
        s.btn,
        solid
          ? { backgroundColor: color }
          : { backgroundColor: color + '1A', borderWidth: 1, borderColor: color + '55' },
        (disabled || loading) && s.disabled,
        style,
      ]}
    >
      {solid && shine && !disabled && !loading && <Shine />}
      {loading ? (
        <ActivityIndicator color={fg} />
      ) : (
        <>
          <Ionicons name={icon} size={19} color={fg} />
          <Text style={[s.btnText, { color: fg }]} numberOfLines={1}>{label}</Text>
        </>
      )}
    </PressableScale>
  );
}

// Campo de texto con icono y "ojo" para claves. SIN estado de foco interno:
// en Android, re-renderizar el campo justo al enfocarlo contribuía a que el
// teclado se abriera y se cerrara al instante.
function Field({ label, icon, theme, secure, ...props }) {
  const [hidden, setHidden] = useState(!!secure);
  return (
    <View style={{ marginTop: 10 }}>
      <Text style={[s.label, { color: theme.muted }]}>{label}</Text>
      <View style={[s.inputWrap, { backgroundColor: theme.input, borderColor: theme.border }]}>
        <Ionicons name={icon} size={18} color={theme.muted} />
        <TextInput
          {...props}
          secureTextEntry={hidden}
          style={[s.input, { color: theme.text }]}
          placeholderTextColor="#4A6080"
          autoCapitalize="none"
          autoCorrect={false}
        />
        {secure && (
          <Pressable onPress={() => setHidden((h) => !h)} hitSlop={10}>
            <Ionicons name={hidden ? 'eye-outline' : 'eye-off-outline'} size={19} color={theme.muted} />
          </Pressable>
        )}
      </View>
    </View>
  );
}

// Barra de progreso indeterminada + mensaje
function ProgressPanel({ message, theme }) {
  const [w, setW] = useState(0);
  const v = useLoop(1300, true, Easing.inOut(Easing.quad));
  const bar = w * 0.4;
  return (
    <View style={[s.progress, { backgroundColor: theme.input, borderColor: BLUE + '66' }]}>
      <View style={s.progressTop}>
        <Ionicons name="sync" size={15} color={BLUE} />
        <Text style={[s.progressText, { color: theme.muted }]} numberOfLines={1}>{message}</Text>
      </View>
      <View style={s.track} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
        <Animated.View
          style={[s.bar, {
            width: bar,
            transform: [{ translateX: v.interpolate({ inputRange: [0, 1], outputRange: [-bar, w] }) }],
          }]}
        />
      </View>
    </View>
  );
}

// Cabecera de sección con icono de color y etiqueta
function SectionHeader({ icon, color, title, tag, theme }) {
  return (
    <View style={s.sectionHeader}>
      <View style={[s.sectionIcon, { backgroundColor: color + '22', borderColor: color + '66' }]}>
        <Ionicons name={icon} size={18} color={color} />
      </View>
      <Text style={[s.sectionTitle, { color: theme.text }]}>{title}</Text>
      {!!tag && (
        <View style={[s.tag, { backgroundColor: color + '22' }]}>
          <Text style={[s.tagText, { color }]}>{tag}</Text>
        </View>
      )}
    </View>
  );
}

// Guía desplegable: pasos de una línea, compactos
function Guide({ icon, color, title, open, onToggle, steps, theme, L }) {
  const rot = useRef(new Animated.Value(open ? 1 : 0)).current;
  useEffect(() => {
    Animated.timing(rot, { toValue: open ? 1 : 0, duration: 220, useNativeDriver: true }).start();
  }, [open, rot]);
  return (
    <View style={[s.guide, { backgroundColor: theme.input, borderColor: theme.border }]}>
      <Pressable style={s.guideHeader} onPress={onToggle}>
        <Ionicons name={icon} size={18} color={color} />
        <Text style={[s.guideTitle, { color: theme.text }]}>{title}</Text>
        <Animated.View style={{ transform: [{ rotate: rot.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '180deg'] }) }] }}>
          <Ionicons name="chevron-down" size={18} color={theme.muted} />
        </Animated.View>
      </Pressable>
      {open && (
        <View style={s.stepsBox}>
          {steps.map((step, i) => (
            <FadeIn key={i} delay={i * 60}>
              <View style={s.stepRowC}>
                <View style={[s.stepNumC, { backgroundColor: color + '22', borderColor: color }]}>
                  <Text style={{ color, fontWeight: '800', fontSize: 12 }}>{i + 1}</Text>
                </View>
                <Text style={[s.stepText, { color: theme.text }]}>{step.title}</Text>
              </View>
            </FadeIn>
          ))}
        </View>
      )}
    </View>
  );
}

// Sección plegable: cabecera con icono, título, resumen de una línea y flecha.
// Solo la abierta muestra su contenido → la pantalla se ve despejada.
function Acordeon({ icon, color, title, subtitle, loading, open, onToggle, children, theme }) {
  const rot = useRef(new Animated.Value(open ? 1 : 0)).current;
  useEffect(() => {
    Animated.timing(rot, { toValue: open ? 1 : 0, duration: 220, useNativeDriver: true }).start();
  }, [open, rot]);
  return (
    <View style={[s.ac, { backgroundColor: theme.card, borderColor: open ? color + '77' : theme.border }]}>
      <Pressable style={s.acHeader} onPress={onToggle}>
        <View style={[s.sectionIcon, { backgroundColor: color + '22', borderColor: color + '66' }]}>
          <Ionicons name={icon} size={18} color={color} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[s.acTitle, { color: theme.text }]} numberOfLines={1}>{title}</Text>
          {!!subtitle && <Text style={[s.acSub, { color: theme.muted }]} numberOfLines={1}>{subtitle}</Text>}
        </View>
        {loading && <ActivityIndicator size="small" color={color} />}
        <Animated.View style={{ transform: [{ rotate: rot.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '180deg'] }) }] }}>
          <Ionicons name="chevron-down" size={20} color={theme.muted} />
        </Animated.View>
      </Pressable>
      {open && (
        <FadeIn>
          <View style={s.acBody}>{children}</View>
        </FadeIn>
      )}
    </View>
  );
}

// Enlace pequeño (en vez de un botón grande)
function LinkBtn({ icon, label, onPress, color }) {
  return (
    <PressableScale onPress={onPress} style={s.linkBtn}>
      <Ionicons name={icon} size={15} color={color} />
      <Text style={[s.linkText, { color }]}>{label}</Text>
    </PressableScale>
  );
}

/* ════════════════════════════════════════════════════════════════════════════
   PANTALLA
   ════════════════════════════════════════════════════════════════════════════ */
export default function SyncSettingsScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const appSettings = useAppSettings();
  const lang = appSettings.language;            // re-renderiza al cambiar idioma
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción

  // ── Intervals.icu ──
  const [intStatus, setIntStatus] = useState('unknown'); // unknown | connected | disconnected
  const [athleteName, setAthleteName] = useState(null);
  const [athleteId, setAthleteId] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [saving, setSaving] = useState(false);
  const [disconnecting, setDisconnecting] = useState(false);
  const [checking, setChecking] = useState(true);
  // ── Guías desplegables ──
  const [openGuideInt, setOpenGuideInt] = useState(false);
  const [openGuideFit, setOpenGuideFit] = useState(false);
  // ── Secciones plegables ──
  const [openFit, setOpenFit] = useState(false);
  const [openTss, setOpenTss] = useState(false);
  // ── Carpeta .fit (plan B) ──
  const [folderUri, setFolderUri] = useState(null);
  const [loadingFolder, setLoadingFolder] = useState(false);
  const [fileCount, setFileCount] = useState(null);
  const [syncingFolder, setSyncingFolder] = useState(false);
  const [folderProgress, setFolderProgress] = useState('');

  // Pasos de las guías (una línea cada uno, para leerlos de un vistazo)
  const STEPS_INTERVALS = [
    { icon: 'create-outline', color: BLUE,  title: L('Crea una cuenta gratuita en intervals.icu', 'Create a free account at intervals.icu') },
    { icon: 'download-outline', color: GREEN, title: L('En Settings → Garmin activa «Download activities»', 'In Settings → Garmin enable “Download activities”') },
    { icon: 'key-outline', color: AMBER, title: L('En Developer Settings copia tu Athlete ID y genera la API key', 'In Developer Settings copy your Athlete ID and generate the API key') },
    { icon: 'link-outline', color: BLUE, title: L('Pégalos aquí y pulsa Conectar', 'Paste them here and tap Connect') },
  ];
  const STEPS_FIT = [
    { icon: 'download-outline', color: AMBER, title: L('Descarga el .fit desde Garmin Connect', 'Download the .fit from Garmin Connect') },
    { icon: 'folder-outline', color: BLUE, title: L('Guárdalo en una carpeta (ej. Descargas/Garmin)', 'Save it in a folder (e.g. Downloads/Garmin)') },
    { icon: 'sync-outline', color: GREEN, title: L('Selecciona la carpeta aquí y sincroniza', 'Select the folder here and sync') },
  ];

  const checkStatus = useCallback(async () => {
    setChecking(true);
    const data = await getIntervalsStatus();
    if (data.connected) {
      setIntStatus('connected');
      setAthleteName(data.athleteName || null);
    } else {
      setIntStatus('disconnected');
      setAthleteName(null);
    }
    setChecking(false);
  }, []);

  useEffect(() => {
    checkStatus();
    AsyncStorage.getItem(FOLDER_KEY).then(uri => {
      if (uri) {
        setFolderUri(uri);
        countFiles(uri);
      }
    });
  }, [checkStatus]);

  const countFiles = async (uri) => {
    try {
      const entries = await StorageAccessFramework.readDirectoryAsync(uri);
      const fits = entries.filter(u => {
        const n = u.toLowerCase();
        return n.endsWith('.fit') || n.includes('.fit%');
      });
      setFileCount(fits.length);
    } catch {
      setFileCount(null);
    }
  };

  // ── Conectar Intervals.icu ──
  const handleConnect = async () => {
    if (!athleteId.trim() || !apiKey.trim()) {
      Alert.alert(L('Faltan datos', 'Missing data'), L('Introduce tu Athlete ID y tu API key de Intervals.icu.', 'Enter your Athlete ID and your Intervals.icu API key.'));
      return;
    }
    setSaving(true);
    try {
      const data = await saveIntervalsCredentials(athleteId.trim(), apiKey.trim());
      setAthleteName(data.athleteName || null);
      setIntStatus('connected');
      setApiKey('');
      Alert.alert(
        L('Conectado', 'Connected'),
        L('Intervals.icu vinculado correctamente', 'Intervals.icu linked successfully') + (data.athleteName ? ` (${data.athleteName})` : '') + '.'
      );
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDisconnect = () => {
    Alert.alert(
      L('Desconectar Intervals.icu', 'Disconnect Intervals.icu'),
      L('¿Seguro que quieres desconectar tu cuenta? Podrás volver a conectarla cuando quieras.', 'Are you sure you want to disconnect? You can reconnect it anytime.'),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Desconectar', 'Disconnect'),
          style: 'destructive',
          onPress: async () => {
            setDisconnecting(true);
            try {
              await disconnectIntervals();
              setIntStatus('disconnected');
              setAthleteName(null);
            } catch (e) {
              Alert.alert(L('Error', 'Error'), e.message);
            } finally {
              setDisconnecting(false);
            }
          },
        },
      ]
    );
  };

  // ── Carpeta .fit ──
  const handleSelectFolder = async () => {
    setLoadingFolder(true);
    try {
      const result = await StorageAccessFramework.requestDirectoryPermissionsAsync();
      if (!result.granted) { setLoadingFolder(false); return; }
      await AsyncStorage.setItem(FOLDER_KEY, result.directoryUri);
      setFolderUri(result.directoryUri);
      await countFiles(result.directoryUri);
      Alert.alert(L('Carpeta guardada', 'Folder saved'), L('La carpeta se ha guardado correctamente.', 'The folder has been saved successfully.'));
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally {
      setLoadingFolder(false);
    }
  };

  const handleResetFolder = () => {
    Alert.alert(L('Borrar carpeta', 'Delete folder'), L('¿Quieres eliminar la carpeta guardada?', 'Do you want to remove the saved folder?'), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      {
        text: L('Borrar', 'Delete'),
        style: 'destructive',
        onPress: async () => {
          await resetSyncFolder();
          setFolderUri(null);
          setFileCount(null);
        },
      },
    ]);
  };

  const handleSyncFolder = async () => {
    const userId = auth.currentUser?.uid;
    if (!userId) return;
    if (!folderUri) {
      Alert.alert(L('Sin carpeta', 'No folder'), L('Selecciona primero una carpeta con archivos .fit.', 'Select a folder with .fit files first.'));
      return;
    }
    setSyncingFolder(true);
    setFolderProgress(L('Preparando…', 'Preparing…'));
    try {
      const result = await syncFitFiles(userId, (msg) => setFolderProgress(msg), lang);
      if (result.cancelled) {
        Alert.alert(L('Cancelado', 'Cancelled'), result.message || L('No hay carpeta configurada.', 'No folder configured.'));
      } else {
        Alert.alert(
          L('Importación completada', 'Import completed'),
          `${result.synced} ${L('nuevos', 'new')} · ${result.skipped} ${L('existentes', 'existing')} · ${result.errors} ${L('errores', 'errors')}`
        );
      }
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally {
      setSyncingFolder(false);
      setFolderProgress('');
    }
  };

  // ── Mantenimiento: recalcular el esfuerzo (TSS) de lo ya guardado ──
  const [recalculando, setRecalculando] = useState(false);
  const [recalculoMsg, setRecalculoMsg] = useState('');
  const handleRecalcularEsfuerzo = () => {
    const userId = auth.currentUser?.uid;
    if (!userId) return;
    Alert.alert(
      L('Recalcular esfuerzo', 'Recalculate effort'),
      L(
        'Vuelve a calcular el esfuerzo (TSS) de tus entrenos guardados usando la duración, la distancia, la FC y tus umbrales de Zonas. No modifica los entrenos sincronizados desde intervals.icu (ésos usan el TSS real de intervals.icu) ni los que hayas editado a mano.',
        'Recalculates the effort (TSS) of your saved workouts using duration, distance, HR and your Zones thresholds. Workouts synced from intervals.icu (which use the real intervals.icu TSS) and manually edited ones are not modified.'
      ),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Recalcular', 'Recalculate'),
          onPress: async () => {
            setRecalculando(true);
            setRecalculoMsg(L('Preparando…', 'Preparing…'));
            try {
              const r = await recalcularEsfuerzos(userId, (msg) => setRecalculoMsg(msg));
              Alert.alert(
                L('Esfuerzo recalculado', 'Effort recalculated'),
                `${r.actualizados} ${L('actualizados', 'updated')} · ${r.intactos} ${L('sin cambios', 'unchanged')} · ${r.sinDatos} ${L('sin datos suficientes', 'not enough data')} · ${r.omitidos} ${L('de intervals.icu (los corrige el servidor)', 'from intervals.icu (fixed by the server)')}`
              );
            } catch (e) {
              Alert.alert(L('Error', 'Error'), e.message);
            } finally {
              setRecalculando(false);
              setRecalculoMsg('');
            }
          },
        },
      ]
    );
  };

  const folderName = folderUri
    ? decodeURIComponent(folderUri.split('%3A').pop().split(':').pop())
    : null;

  // Animación suave al abrir/cerrar guías (solo visual)
  // (Sin LayoutAnimation: el flag experimental de Android que exigía era la
  // causa de que el teclado se abriera y se cerrara solo en esta pantalla;
  // el chevron y los pasos ya animan con Animated.)
  const toggleGuide = (setter) => {
    setter((v) => !v);
  };

  const busy = saving || syncingFolder || recalculando || disconnecting;

  /* ─────────────────────────────── RENDER ─────────────────────────────── */
  return (
    <View style={[s.container, { backgroundColor: theme.background }]}>
      {/* Cabecera */}
      <View style={[s.header, { borderBottomColor: theme.border, paddingTop: insets.top + 10 }]}>
        <PressableScale
          onPress={() => navigation.goBack()}
          style={[s.backBtn, { backgroundColor: theme.card, borderColor: theme.border }]}
          hitSlop={10}
        >
          <Ionicons name="chevron-back" size={22} color="#8FA8C8" />
        </PressableScale>
        <Text style={[s.headerTitle, { color: theme.text }]}>{L('Sincronización', 'Sync')}</Text>
        <View style={{ width: 40 }} />
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView
        contentContainerStyle={[s.scrollContent, { paddingBottom: Math.max(40, insets.bottom + 16) }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="always"
      >
        {/* ══════════ HÉROE ANIMADO ══════════ */}
        <FadeIn>
          <SyncHero status={intStatus} busy={busy} checking={checking} theme={theme} L={L} />
        </FadeIn>

        {/* ══════════ BLOQUE 1: INTERVALS.ICU (lo principal, siempre visible) ══════════ */}
        <FadeIn delay={120}>
          <SectionHeader
            icon="flash-outline"
            color={BLUE}
            title={L('Sincronización automática', 'Automatic sync')}
            tag={L('Recomendado', 'Recommended')}
            theme={theme}
          />
        </FadeIn>
        {/* La tarjeta con los campos va SIN FadeIn: en Android, un ancestro
            animado durante el foco hacía que el teclado se cerrara solo. */}
          <View style={[s.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
            {intStatus === 'connected' ? (
              <View style={[s.statusRow, { backgroundColor: GREEN + '14', borderColor: GREEN + '55' }]}>
                <PulsingIcon name="checkmark-circle" color={GREEN} />
                <View style={{ flex: 1 }}>
                  <Text style={[s.statusTitle, { color: theme.text }]}>{L('Intervals.icu conectado', 'Intervals.icu connected')}</Text>
                  {athleteName && (
                    <Text style={[s.statusSub, { color: theme.muted }]} numberOfLines={1}>{athleteName}</Text>
                  )}
                </View>
                <PressableScale
                  onPress={handleDisconnect}
                  disabled={disconnecting}
                  style={s.dangerBtn}
                  hitSlop={8}
                >
                  {disconnecting
                    ? <ActivityIndicator size="small" color={RED} />
                    : <Ionicons name="trash-outline" size={18} color={RED} />}
                </PressableScale>
              </View>
            ) : (
              <>
                <Field
                  label="Athlete ID"
                  icon="person-outline"
                  theme={theme}
                  value={athleteId}
                  onChangeText={setAthleteId}
                  placeholder="i12345"
                />
                <Field
                  label="API Key"
                  icon="key-outline"
                  theme={theme}
                  secure
                  value={apiKey}
                  onChangeText={setApiKey}
                  placeholder={L('Pega aquí tu API key', 'Paste your API key here')}
                />
                <ActionButton
                  icon="link-outline"
                  label={L('Conectar', 'Connect')}
                  onPress={handleConnect}
                  loading={saving}
                  shine
                  style={{ marginTop: 14 }}
                />
                <LinkBtn
                  icon="open-outline"
                  color={BLUE}
                  label={L('Abrir Intervals.icu', 'Open Intervals.icu')}
                  onPress={() => Linking.openURL('https://intervals.icu/settings')}
                />
                <Guide
                  icon="help-circle-outline"
                  color={BLUE}
                  title={L('¿Cómo conectarlo?', 'How to connect?')}
                  open={openGuideInt}
                  onToggle={() => toggleGuide(setOpenGuideInt)}
                  steps={STEPS_INTERVALS}
                  theme={theme}
                  L={L}
                />
              </>
            )}
          </View>

        {/* ══════════ BLOQUE 2: CARPETA .FIT (plegado) ══════════ */}
        <FadeIn delay={220}>
          <Acordeon
            icon="folder-open-outline"
            color={GREEN}
            title={L('Importar archivos .fit', 'Import .fit files')}
            subtitle={syncingFolder
              ? (folderProgress || L('Sincronizando…', 'Syncing…'))
              : folderUri
                ? (fileCount != null
                    ? L(`${fileCount} archivo${fileCount !== 1 ? 's' : ''} .fit`, `${fileCount} .fit file${fileCount !== 1 ? 's' : ''}`)
                    : L('Carpeta configurada', 'Folder set'))
                : L('Plan B · opcional', 'Plan B · optional')}
            loading={syncingFolder}
            open={openFit}
            onToggle={() => toggleGuide(setOpenFit)}
            theme={theme}
          >
            {folderUri && (
              <View style={[s.statusRow, { backgroundColor: BLUE + '12', borderColor: BLUE + '55', marginBottom: 12 }]}>
                <Ionicons name="folder-open" size={24} color={BLUE} />
                <Text style={[s.statusTitle, { color: theme.text, flex: 1 }]} numberOfLines={1}>{folderName}</Text>
                <PressableScale onPress={handleResetFolder} style={s.dangerBtn} hitSlop={8}>
                  <Ionicons name="trash-outline" size={18} color={RED} />
                </PressableScale>
              </View>
            )}
            <ActionButton
              icon="folder-open-outline"
              label={folderUri ? L('Cambiar carpeta', 'Change folder') : L('Seleccionar carpeta', 'Select folder')}
              onPress={handleSelectFolder}
              variant="tint"
              color={BLUE}
              loading={loadingFolder}
            />
            <ActionButton
              icon="sync-outline"
              label={L('Sincronizar ahora', 'Sync now')}
              onPress={handleSyncFolder}
              color={GREEN}
              loading={syncingFolder}
              disabled={!folderUri}
              shine
              style={{ marginTop: 10 }}
            />
            {syncingFolder && !!folderProgress && <ProgressPanel message={folderProgress} theme={theme} />}
            <Guide
              icon="help-circle-outline"
              color={GREEN}
              title={L('¿Cómo funciona?', 'How does it work?')}
              open={openGuideFit}
              onToggle={() => toggleGuide(setOpenGuideFit)}
              steps={STEPS_FIT}
              theme={theme}
              L={L}
            />
          </Acordeon>
        </FadeIn>

        {/* ══════════ BLOQUE 3: ESFUERZO (TSS) (plegado) ══════════ */}
        <FadeIn delay={320}>
          <Acordeon
            icon="speedometer-outline"
            color={AMBER}
            title={L('Recalcular esfuerzo (TSS)', 'Recalculate effort (TSS)')}
            subtitle={recalculando ? (recalculoMsg || L('Recalculando…', 'Recalculating…')) : L('Mantenimiento', 'Maintenance')}
            loading={recalculando}
            open={openTss}
            onToggle={() => toggleGuide(setOpenTss)}
            theme={theme}
          >
            <ActionButton
              icon="refresh-outline"
              label={L('Recalcular ahora', 'Recalculate now')}
              onPress={handleRecalcularEsfuerzo}
              variant="tint"
              color={AMBER}
              loading={recalculando}
            />
            {recalculando && !!recalculoMsg && <ProgressPanel message={recalculoMsg} theme={theme} />}
          </Acordeon>
        </FadeIn>
      </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

/* ════════════════════════════════════════════════════════════════════════════
   ESTILOS
   ════════════════════════════════════════════════════════════════════════════ */
const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },

  // Cabecera
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingBottom: 12,
    borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  backBtn: {
    width: 40, height: 40, borderRadius: 20, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
  },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  scrollContent: { padding: 16, gap: 14 },

  // Héroe
  hero: {
    borderRadius: 24, borderWidth: 1.5, padding: 18, paddingTop: 22,
    overflow: 'hidden', alignItems: 'center',
  },
  blob: { position: 'absolute', borderRadius: 999 },
  heroRow: { flexDirection: 'row', alignItems: 'flex-start', width: '100%' },
  nodeCol: { width: 72, alignItems: 'center', gap: 8 },
  node: { borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  nodeLabel: { fontSize: 11, fontWeight: '600' },
  flowLine: { flex: 1, height: 58, justifyContent: 'center', overflow: 'hidden' },
  flowBase: { height: 3, borderRadius: 2 },
  flowDot: { position: 'absolute', top: 24.5, width: 9, height: 9, borderRadius: 5 },
  chip: {
    flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 18,
    paddingHorizontal: 14, paddingVertical: 7, borderRadius: 999, borderWidth: 1,
  },
  chipDot: { width: 8, height: 8, borderRadius: 4 },
  chipText: { fontSize: 13, fontWeight: '700' },

  // Secciones
  sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  sectionIcon: {
    width: 34, height: 34, borderRadius: 11, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
  },
  sectionTitle: { fontSize: 15, fontWeight: '800', flex: 1 },
  tag: { paddingHorizontal: 9, paddingVertical: 3, borderRadius: 999 },
  tagText: { fontSize: 11, fontWeight: '700' },
  card: { borderRadius: 20, borderWidth: 1, padding: 14 },
  cardDesc: { fontSize: 13, lineHeight: 19 },

  // Estado
  statusRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    borderRadius: 14, borderWidth: 1, padding: 12,
  },
  statusTitle: { fontWeight: '700', fontSize: 14 },
  statusSub: { fontSize: 12, marginTop: 2 },
  statusWarnText: { fontSize: 13, flex: 1, lineHeight: 18 },
  countChip: {
    flexDirection: 'row', alignItems: 'center', gap: 5, alignSelf: 'flex-start',
    marginTop: 6, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 999,
  },
  statusCount: { fontSize: 11, fontWeight: '700' },
  dangerBtn: {
    width: 38, height: 38, borderRadius: 19, backgroundColor: RED + '1F',
    alignItems: 'center', justifyContent: 'center',
  },

  // Formulario
  label: { fontSize: 12, fontWeight: '600', marginBottom: 6, marginLeft: 2 },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    borderRadius: 12, borderWidth: 1.5, paddingHorizontal: 12,
  },
  inputFocus: {
    shadowColor: BLUE, shadowOpacity: 0.35, shadowRadius: 8, shadowOffset: { width: 0, height: 0 },
  },
  input: { flex: 1, paddingVertical: 12, fontSize: 14 },

  // Botones
  btn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    borderRadius: 14, paddingVertical: 15, paddingHorizontal: 14, gap: 10, overflow: 'hidden',
  },
  btnText: { fontWeight: '800', fontSize: 15, flexShrink: 1 },
  disabled: { opacity: 0.55 },
  shine: {
    position: 'absolute', top: -30, height: 120, width: 28,
    backgroundColor: 'rgba(255,255,255,0.20)',
  },

  // Progreso
  progress: { marginTop: 12, borderRadius: 12, borderWidth: 1, padding: 12, gap: 10 },
  progressTop: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  progressText: { fontSize: 13, flex: 1 },
  track: { height: 5, borderRadius: 3, backgroundColor: BLUE + '2A', overflow: 'hidden' },
  bar: { height: 5, borderRadius: 3, backgroundColor: BLUE },

  // Guías (línea de tiempo)
  guide: { marginTop: 14, borderRadius: 14, borderWidth: 1, overflow: 'hidden' },
  guideHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 14 },
  guideTitle: { fontSize: 14, fontWeight: '700', flex: 1 },
  timeline: { paddingHorizontal: 14, paddingBottom: 6 },
  stepRow: { flexDirection: 'row', gap: 14 },
  stepRail: { alignItems: 'center', width: 40 },
  stepNode: {
    width: 40, height: 40, borderRadius: 20, borderWidth: 1.5,
    alignItems: 'center', justifyContent: 'center',
  },
  stepLine: { flex: 1, width: 2, marginVertical: 4, borderRadius: 1 },
  stepBody: { flex: 1, paddingBottom: 18 },
  stepNum: { fontSize: 11, fontWeight: '800', marginBottom: 2 },
  stepTitle: { fontSize: 14, fontWeight: '700', marginBottom: 4 },
  stepDesc: { fontSize: 13, lineHeight: 19 },

  // Acordeón + pasos compactos + enlace
  ac: { borderRadius: 20, borderWidth: 1.5, overflow: 'hidden' },
  acHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 },
  acTitle: { fontSize: 15, fontWeight: '800' },
  acSub: { fontSize: 12, marginTop: 2 },
  acBody: { paddingHorizontal: 14, paddingBottom: 14 },
  linkBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 12 },
  linkText: { fontSize: 13, fontWeight: '700' },
  stepsBox: { paddingHorizontal: 14, paddingBottom: 12, gap: 10 },
  stepRowC: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  stepNumC: { width: 26, height: 26, borderRadius: 13, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  stepText: { flex: 1, fontSize: 13, lineHeight: 18 },

  // Info
  infoBox: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 12,
    borderRadius: 16, padding: 14, borderWidth: 1,
  },
  infoIcon: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  infoText: { fontSize: 13, lineHeight: 19, flex: 1 },
});