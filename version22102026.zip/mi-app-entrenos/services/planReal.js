// services/planReal.js
// ─────────────────────────────────────────────────────────────
// PLANIFICADO vs REALIZADO: fuente única de verdad en el cliente.
//
// Las tarjetas de Home y Calendario pintan "realizado / planificado".
// El planificado viene de la fusión del servidor (lib/matcher.js), que
// deja en el doc realizado los campos planDist (km) y planDur (seg).
//
// PROBLEMA QUE RESUELVE ESTE MÓDULO: hay docs fusionados SIN planDist
// (fusiones hechas antes de que el matcher resolviera las zonas de ritmo,
// planes cuyos pasos son de tiempo con objetivo "Zona ritmo", o docs
// editados a mano). En esos casos la tarjeta mostraba la distancia
// realizada sola, sin su comparativa, aunque el tiempo sí salía bien.
//
// SOLUCIÓN: resolverPlanReal() devuelve SIEMPRE el plan, con tres niveles
// de respaldo (los mismos datos que usa el modal de detalle):
//   1) planDist / planDur guardados por el matcher (lo mejor: ya venía
//      calculado en el servidor con las zonas del atleta).
//   2) distancia / duracion del doc PLANIFICADO (planes antiguos que se
//      crearon con la medida a mano y sin pasos).
//   3) recálculo desde los pasos fusionados con computePlanMetrics() —
//      idéntica lógica que lib/matcher.js del servidor y que el modal de
//      detalle. Con las zonas de ritmo del atleta (useZonasRitmoPorTipo)
//      los pasos "Zona ritmo" también aportan km; sin zonas siguen
//      aportando los pasos de distancia y los de ritmo manual.
//
// Todo es de LECTURA: no escribe nada en Firestore, así que un coach que
// mira el calendario de su atleta no provoca escrituras cruzadas.
// ─────────────────────────────────────────────────────────────
import { useCallback, useEffect, useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebaseConfig';
import { getCachedProfile } from './profileCache';
import { getZonasRitmo, setZonasRitmo } from './chartCache';

/* ═══ MÉTRICAS DEL PLAN DESDE LOS PASOS ═══
   Misma lógica (y mismas unidades) que computePlanMetrics() del servidor:
   distancias → km, tiempos → segundos. Los pasos de tiempo cuyo objetivo es
   un RITMO (manual o zona del atleta) se convierten a km con ese ritmo, y al
   revés. Las repeticiones se multiplican y los hijos de una serie heredan las
   repeticiones del padre. */
// ¿Es una velocidad en km/h y no un ritmo MM:SS? En Ciclismo las zonas de
// ritmo se guardan en km/h (30 = 30 km/h); en el resto, en min/km ("4:30").
// La pista fiable es el formato: un ritmo siempre lleva ":" y una velocidad, no.
const ES_KMH = /^\d{1,3}([.,]\d+)?$/;

// Velocidad (km/h) → ritmo (seg/km). Para el ritmo MEDIO de una zona se usa la
// media armónica de las dos velocidades, que es el ritmo real al que se cubre
// la misma distancia con un tramo a cada velocidad (la media aritmética de los
// ritmos sesgaría la estimación de km hacia arriba).
export function kmhToPaceSec(kmh) {
  const n = Number(String(kmh == null ? '' : kmh).trim().replace(',', '.'));
  return Number.isFinite(n) && n > 0 ? 3600 / n : null;
}
function velocidadMediaAHoraPace(a, b) {
  const va = Number(String(a).trim().replace(',', '.'));
  const vb = Number(String(b).trim().replace(',', '.'));
  if (!(va > 0) || !(vb > 0)) return null;
  return 7200 / (va + vb);
}

export function paceToSec(v) {
  if (v == null || v === '') return null;
  if (typeof v === 'number') return v > 0 ? v : null;
  const m = String(v).trim().match(/^(\d+):(\d{1,2})$/);
  if (m) {
    const seg = parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
    return seg > 0 ? seg : null;
  }
  const n = Number(String(v).trim().replace(',', '.'));
  return Number.isFinite(n) && n > 0 ? n : null;
}

// Zonas de ritmo que tocan para una actividad: las específicas si existen,
// si no las genéricas del perfil (igual que zonasDeActividad()).
export function zonasRitmoDe(perfil, tipo) {
  if (!perfil) return [];
  const gen = Array.isArray(perfil.zonasRitmo) ? perfil.zonasRitmo : [];
  const act = tipo && perfil.zonasActividad && perfil.zonasActividad[tipo];
  const esp = act && act.ritmo;
  return Array.isArray(esp) && esp.length ? esp : gen;
}

// tipo: actividad del entreno ('Ciclismo' → objetivos y zonas en km/h).
export function computePlanMetrics(pasos, zonasRitmo, tipo) {
  let sec = 0;
  let km = 0;
  const esKmH = tipo === 'Ciclismo';
  const aSec = (v) => {
    if (v == null || v === '') return null;
    const t = String(v).trim();
    if (esKmH && ES_KMH.test(t)) return kmhToPaceSec(t);
    return paceToSec(t);
  };

  // Ritmo medio (seg/km) del objetivo del paso: min/max manuales o, si el
  // objetivo es una ZONA, el rango min/max de esa zona en el perfil.
  const paceDelPaso = (p) => {
    if (!p || (p.objetivo !== 'Ritmo' && p.objetivo !== 'Zona ritmo')) return null;
    const a = aSec(p.objMin);
    const b = aSec(p.objMax);
    if (a != null && b != null) return (a + b) / 2;
    if (a != null) return a;
    if (b != null) return b;
    if (p.objZona && Array.isArray(zonasRitmo)) {
      const nom = String(p.objZona).trim();
      let zi = zonasRitmo.findIndex((z) => String((z && (z.titulo || z.label)) || '').trim() === nom);
      if (zi < 0) zi = zonasRitmo.findIndex((z, i) => `R${i + 1}` === nom);
      if (zi < 0) {
        // Última pista: mismo número que el objetivo ("R2+", "Z2" → la zona 2)
        const num = (nom.match(/(\d+)/) || [])[1];
        if (num != null) {
          zi = zonasRitmo.findIndex((z) => {
            const nl = (String((z && (z.titulo || z.label)) || '').match(/(\d+)/) || [])[1];
            return nl === num;
          });
          if (zi < 0) {
            const n = parseInt(num, 10);
            if (Number.isFinite(n) && zonasRitmo[n - 1]) zi = n - 1;
          }
        }
      }
      const z = zi >= 0 ? zonasRitmo[zi] : null;
      // En Ciclismo los límites de la zona son km/h: el ritmo medio sale de la
      // velocidad media (armónica), no de promediar dos ritmos.
      if (esKmH && ES_KMH.test(String(z && z.min).trim()) && ES_KMH.test(String(z && z.max).trim())) {
        const pv = velocidadMediaAHoraPace(z.min, z.max);
        if (pv != null) return pv;
      }
      const za = aSec(z && z.min);
      const zb = aSec(z && z.max);
      if (za != null && zb != null) return (za + zb) / 2;
      if (za != null) return za;
      if (zb != null) return zb;
    }
    return null;
  };

  const kmDe = (val, u) => (
    u === 'mi' ? val * 1.609344
      : u === 'm' ? val / 1000
        : u === 'yd' ? val * 0.0009144
          : val
  );

  const walk = (list, mult) => (Array.isArray(list) ? list : []).forEach((p) => {
    if (!p) return;
    const reps = (Number(p.repeticiones) || 1) * mult;
    const val = Number(p.durValor ?? p.valor);
    let s = 0;
    let k = 0;
    if (Number.isFinite(val) && val > 0) {
      const unidad = p.durUnidad || p.unidad;
      const isDist = p.durTipo === 'Distancia'
        || (p.durTipo !== 'Tiempo' && ['km', 'm', 'mi', 'yd'].includes(unidad));
      if (isDist) k = kmDe(val, unidad || 'km');
      else s = val * 60;
    }
    const pace = paceDelPaso(p);
    if (k === 0 && s > 0 && pace) k = s / pace;
    if (s === 0 && k > 0 && pace) s = k * pace;
    sec += s * reps;
    km += k * reps;
    walk(p.hijos, reps);
  });

  walk(pasos, 1);
  return { sec, km };
}

/* ═══ RESOLVER EL PLAN DE UN ENTRENO ═══
   Devuelve { dist, dur } en km y segundos (null si de verdad no hay plan).
   `zonasRitmo` es opcional: solo mejora la estimación de los pasos por zona. */
// Caché por identidad del doc + zonas: las tarjetas de Home/Calendario llaman
// a esto en cada render (una para el texto y otra para el color), y recorrer
// los pasos de 50 entrenos dos veces por frame no aporta nada. En cuanto
// Firestore devuelve objetos nuevos (sync, edición, cambio de atleta) la clave
// cambia sola y se recalcula.
const cachePlan = new WeakMap();

// tipo: actividad del doc. Si no se pasa, se usa w.tipo (Ciclismo → km/h).
export function resolverPlanReal(w, zonasRitmo, tipo) {
  if (!w || typeof w !== 'object') return { dist: null, dur: null };

  const zKey = Array.isArray(zonasRitmo) ? zonasRitmo : null;
  const tKey = tipo || w.tipo || null;
  const hit = cachePlan.get(w);
  if (hit && hit.z === zKey && hit.t === tKey) return hit.res;

  const res = resolverPlanRealCalc(w, zKey, tKey);
  try { cachePlan.set(w, { z: zKey, t: tKey, res }); } catch (e) { /* objeto no cacheable */ }
  return res;
}

function resolverPlanRealCalc(w, zonasRitmo, tipo) {
  const num = (v) => {
    const n = Number(v);
    return Number.isFinite(n) && n > 0 ? n : null;
  };

  // 1) Lo que guardó la fusión del servidor (o el traspaso del modal).
  let dist = num(w.planDist);
  let dur = num(w.planDur);

  // 2) Plan antiguo sin pasos: la medida escrita a mano en el planificado.
  //    Solo tiene sentido si el doc NO es el realizado (un realizado guarda
  //    ahí su distancia real, no la planificada).
  const esRealizado = w.estado === 'completo';
  if (!esRealizado) {
    if (dist == null) dist = num(w.distancia);
    if (dur == null) dur = num(w.duracion);
  }

  // 3) Recálculo desde los pasos (fusionados o del planificado). Rellena
  //    SOLO lo que falta: nunca pisa un planDist/planDur bueno del servidor.
  const pasos = Array.isArray(w.pasos) ? w.pasos : [];
  if ((dist == null || dur == null) && pasos.length) {
    const plan = computePlanMetrics(pasos, zonasRitmo, tipo || w.tipo);
    if (dist == null && plan.km > 0) dist = Math.round(plan.km * 100) / 100;
    if (dur == null && plan.sec > 0) dur = Math.round(plan.sec);
  }

  return { dist, dur };
}

/* ═══ ZONAS DE RITMO DEL ATLETA (hook) ═══
   Caché en memoria compartida con el resumen semanal (chartCache) + caché del
   perfil en AsyncStorage; si no hay nada, una sola lectura a perfiles/{uid}.
   Devuelve una función estable: zonasDe(tipo) → zonas de ritmo de esa
   actividad (las específicas si existen, si no las genéricas). */
export function useZonasRitmoPorTipo(uid) {
  const [perfil, setPerfil] = useState(null);

  useEffect(() => {
    let vivo = true;
    if (!uid) { setPerfil(null); return undefined; }

    (async () => {
      // 1) Perfil cacheado (instantáneo; Home ya lo cachea al suscribirse).
      try {
        const c = await getCachedProfile(uid);
        if (vivo && c && (Array.isArray(c.zonasRitmo) || c.zonasActividad)) setPerfil(c);
      } catch (e) { /* sin caché: seguimos */ }

      // 2) La caché de zonas del resumen semanal ya resuelta para Running.
      try {
        const z = getZonasRitmo(uid);
        if (vivo && Array.isArray(z) && z.length) {
          setPerfil((p) => (p && (Array.isArray(p.zonasRitmo) || p.zonasActividad)
            ? p
            : { ...(p || {}), zonasRitmo: z }));
        }
      } catch (e) { /* nada */ }

      // 3) Lectura única al perfil (si el paso 1 no trajo zonas).
      try {
        const s = await getDoc(doc(db, 'perfiles', uid));
        if (vivo && s.exists()) {
          const d = s.data() || {};
          setPerfil(d);
          const gen = Array.isArray(d.zonasRitmo) ? d.zonasRitmo : [];
          if (gen.length) setZonasRitmo(uid, gen);
        }
      } catch (e) { /* sin permisos/offline: el plan sale sin zonas */ }
    })();

    return () => { vivo = false; };
  }, [uid]);

  return useCallback((tipo) => zonasRitmoDe(perfil, tipo), [perfil]);
}

