let pendingWorkout = null;
const subs = new Set();
let ultimaEntrega = null;
export function setPendingWorkoutId(id, context = {}) {
  if (!id) return;
  pendingWorkout = { workoutId: id, athleteId: context?.athleteId || null };
  if (subs.size) {
    const payload = pendingWorkout;
    subs.forEach((fn) => { try { fn(payload); } catch (e) {} });
    pendingWorkout = null;
  }
}
export function entregaYaHecha(id, ventanaMs = 10000) {
  const ahora = Date.now();
  if (ultimaEntrega && ultimaEntrega.id === id && ahora - ultimaEntrega.ts < ventanaMs) return true;
  ultimaEntrega = { id, ts: ahora };
  return false;
}
export function consumePendingWorkoutId() {
  const payload = pendingWorkout;
  pendingWorkout = null;
  return payload;
}
export function subscribePendingWorkout(fn) {
  subs.add(fn);
  return () => subs.delete(fn);
}
