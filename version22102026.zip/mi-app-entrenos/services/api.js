// services/api.js
import { getDatabase, ref, get } from 'firebase/database';

// ⚠️ Cambia esto por la URL de tu backend en Vercel (termina en /api)
export const DEFAULT_API_URL = 'https://mi-app-entrenos.vercel.app/api';

export async function getApiUrl() {
  try {
    const db = getDatabase();
    // Con timeout: una lectura de Realtime DB colgada no puede bloquear
    // para siempre el guardado de un entreno/evento (pasaba con los eventos
    // con atletas: el envío de notificaciones se quedaba esperando).
    const timeout = new Promise((resolve) => setTimeout(() => resolve(null), 3000));
    const snap = await Promise.race([get(ref(db, 'config/serverUrl')), timeout]);
    const val = snap && typeof snap.val === 'function' ? snap.val() : null;

    if (val && typeof val === 'string' && val.trim()) {
      return val.trim().replace(/\/+$/, '');
    }

    return DEFAULT_API_URL;
  } catch {
    return DEFAULT_API_URL;
  }
}