// services/curvasDigest.js
// Cálculo PURO del "digest" por actividad y fusión de digests para una gráfica
// (Bloque C). Sin Firebase ni AsyncStorage: se ejecuta en Node (tests) y en
// Metro. Replica LÍNEA A LÍNEA el bucle de ventanas/días de
// getStreamsStatsLegacy para que las curvas salgan idénticas:
//   · dt <= 0 || dt > 120  →  intervalo ignorado
//   · frecuencia/velocidad (km/h)/potencia/cadencia como Number(...) || 0
//   · día por dayKey(...) en hora LOCAL del dispositivo (mismo helper del motor)
//   · ritmo = 3600 / v; ciclismo NO aporta a ritmo
//   · dias.rt: bin de ritmo Math.floor(3600/v) en s/km, tope en la clave "3600"
//   · win: los 9 STREAM_SIZES con trozos fijos Math.floor(elapsed/tam),
//     incluidos los parciales; ritmo = mínimo, resto = máximos; ciclismo → vel
//   · los segundos se redondean a 2 decimales AL GUARDAR (redondearDigest);
//     el cálculo conserva precisión completa para no acumular error de redondeo
//   · el digest NO depende de las zonas del usuario: las zonas se aplican al
//     leer (fusionarDigests), así que cambiar zonas no obliga a recalcular.
import * as AE from './analyticsEngine';

export function calcularDigest(puntos, tipo, fechaMs) {
  const win = {
    ritmo: AE.STREAM_SIZES.map(() => null),
    vel: AE.STREAM_SIZES.map(() => null),
    fc: AE.STREAM_SIZES.map(() => null),
    pot: AE.STREAM_SIZES.map(() => null),
    cad: AE.STREAM_SIZES.map(() => null),
  };
  const dias = {};
  const pts = Array.isArray(puntos) ? puntos : [];
  const sig = pts.length
    ? `${pts.length}|${pts[0].timestamp}|${pts[pts.length - 1].timestamp}`
    : '0||';
  const digest = {
    f: Number(fechaMs) || 0,
    tipo: tipo ?? '',
    sig,
    win,
    dias,
  };

  if (pts.length < 2) return digest;

  const t0 = new Date(pts[0].timestamp).getTime();
  const chunks = AE.STREAM_SIZES.map(() => ({}));

  const acumDia = (dk, mapa, clave, dt) => {
    const d = dias[dk] || (dias[dk] = { fc: {}, rt: {} });
    d[mapa][clave] = (d[mapa][clave] || 0) + dt;
  };

  for (let i = 1; i < pts.length; i++) {
    const dt =
      (
        new Date(pts[i].timestamp) -
        new Date(pts[i - 1].timestamp)
      ) / 1000;

    if (dt <= 0 || dt > 120) {
      continue;
    }

    const hr = Number(pts[i].frecuencia) || 0;
    const v = Number(pts[i].velocidad) || 0;
    const pot = Number(pts[i].potencia) || 0;
    const cad = Number(pts[i].cadencia) || 0;
    const dk = AE.dayKey(new Date(pts[i].timestamp));

    if (hr > 0) {
      acumDia(dk, 'fc', String(hr), dt);
    }

    if (v > 0 && tipo !== 'Ciclismo') {
      // `velocidad` se guarda en km/h; el ritmo se expresa en s/km y el bin
      // es el entero hacia abajo, con tope en 3600 (ritmos más lentos).
      const pace = 3600 / v;
      let k = Math.floor(pace);
      if (k > 3600) k = 3600;
      acumDia(dk, 'rt', String(k), dt);
    }

    const elapsed =
      (
        new Date(pts[i].timestamp).getTime() - t0
      ) / 1000;

    for (let si = 0; si < AE.STREAM_SIZES.length; si++) {
      const idx = Math.floor(elapsed / AE.STREAM_SIZES[si]);

      const ck =
        chunks[si][idx] ||
        (chunks[si][idx] = {
          t: 0,
          d: 0,
          hrS: 0,
          hrT: 0,
          pS: 0,
          pT: 0,
          cS: 0,
          cT: 0,
        });

      ck.t += dt;

      if (v > 0) {
        // velocidad está en km/h; ck.d se acumula en metros.
        ck.d += (v * dt) / 3.6;
      }

      if (hr > 0) {
        ck.hrS += hr * dt;
        ck.hrT += dt;
      }

      if (pot > 0) {
        ck.pS += pot * dt;
        ck.pT += dt;
      }

      if (cad > 0) {
        ck.cS += cad * dt;
        ck.cT += dt;
      }
    }
  }

  for (let si = 0; si < AE.STREAM_SIZES.length; si++) {
    let rV = null;
    let vV = null;
    let fV = null;
    let pV = null;
    let cV = null;

    for (const idx of Object.keys(chunks[si])) {
      const ck = chunks[si][idx];

      if (ck.d > 0 && ck.t > 0) {
        if (tipo === 'Ciclismo') {
          const speedKmh = (3.6 * ck.d) / ck.t;
          if (vV == null || speedKmh > vV) vV = speedKmh;
        } else {
          const pace = ck.t / (ck.d / 1000);
          if (rV == null || pace < rV) rV = pace;
        }
      }

      if (ck.hrT > 0) {
        const avg = ck.hrS / ck.hrT;
        if (fV == null || avg > fV) fV = avg;
      }

      if (ck.pT > 0) {
        const avg = ck.pS / ck.pT;
        if (pV == null || avg > pV) pV = avg;
      }

      if (ck.cT > 0) {
        const avg = ck.cS / ck.cT;
        if (cV == null || avg > cV) cV = avg;
      }
    }

    win.ritmo[si] = rV;
    win.vel[si] = vV;
    win.fc[si] = fV;
    win.pot[si] = pV;
    win.cad[si] = cV;
  }

  return digest;
}

// Fusión de digests: devuelve EXACTAMENTE la misma estructura que hoy
// devuelve getStreamsStatsLegacy (zoneFc, zoneRt, zoneFcDays, zoneRtDays,
// curveRitmo/Vel/Fc/Pot/Cad, hasAny, ok). Las curvas se combinan con máximo
// (mínimo para ritmo) entre actividades. Las zonas se calculan con las mismas
// condiciones inclusivas lo <= x <= hi; como valor representativo del ritmo se
// usa clave + 0.5 (centro del bin). Lo que no encaje va a «Fuera».
export function fusionarDigests(listaDigests, perfilZonas, desdeMs) {
  const { fcZ, rtZ } = AE.parseStreamZones(perfilZonas || null);

  const zoneFc = fcZ.map((b) => ({
    label: b.label,
    sec: 0,
  }));
  if (fcZ.length) zoneFc.push({ label: 'Fuera', sec: 0 });

  const zoneRt = rtZ.map((b) => ({
    label: b.label,
    sec: 0,
  }));
  if (rtZ.length) zoneRt.push({ label: 'Fuera', sec: 0 });

  const zoneFcDays = {};
  const zoneRtDays = {};

  const curveRitmo = AE.STREAM_SIZES.map(() => null);
  const curveVel = AE.STREAM_SIZES.map(() => null);
  const curveFc = AE.STREAM_SIZES.map(() => null);
  const curvePot = AE.STREAM_SIZES.map(() => null);
  const curveCad = AE.STREAM_SIZES.map(() => null);

  const list = Array.isArray(listaDigests) ? listaDigests : [];

  for (const dg of list) {
    if (!dg) continue;

    // Mismo filtro que el motor: actividad dentro del período por su fecha.
    if (desdeMs != null && Number(dg.f) < desdeMs) continue;

    const win = dg.win || {};

    for (let si = 0; si < AE.STREAM_SIZES.length; si++) {
      const r = win.ritmo ? win.ritmo[si] : null;
      if (r != null && (curveRitmo[si] == null || r < curveRitmo[si])) curveRitmo[si] = r;

      const vv = win.vel ? win.vel[si] : null;
      if (vv != null && (curveVel[si] == null || vv > curveVel[si])) curveVel[si] = vv;

      const f = win.fc ? win.fc[si] : null;
      if (f != null && (curveFc[si] == null || f > curveFc[si])) curveFc[si] = f;

      const p = win.pot ? win.pot[si] : null;
      if (p != null && (curvePot[si] == null || p > curvePot[si])) curvePot[si] = p;

      const c = win.cad ? win.cad[si] : null;
      if (c != null && (curveCad[si] == null || c > curveCad[si])) curveCad[si] = c;
    }

    const dias = dg.dias || {};

    for (const dk of Object.keys(dias)) {
      const dd = dias[dk] || {};
      const fcMap = dd.fc || {};

      for (const val of Object.keys(fcMap)) {
        const hr = Number(val);
        const seg = Number(fcMap[val]) || 0;

        if (!(seg > 0) || !Number.isFinite(hr)) continue;

        let matchedFc = false;
        for (let zi = 0; zi < fcZ.length; zi++) {
          if (hr >= fcZ[zi].lo && hr <= fcZ[zi].hi) {
            zoneFc[zi].sec += seg;

            (
              zoneFcDays[dk] ||
              (zoneFcDays[dk] = new Array(fcZ.length).fill(0))
            )[zi] += seg;

            matchedFc = true;
            break;
          }
        }
        if (!matchedFc && fcZ.length) zoneFc[fcZ.length].sec += seg;
      }

      const rtMap = dd.rt || {};

      for (const clave of Object.keys(rtMap)) {
        // Valor representativo del bin: el centro (clave + 0,5 s/km).
        const rep = Number(clave) + 0.5;
        const seg = Number(rtMap[clave]) || 0;

        if (!(seg > 0) || !Number.isFinite(rep)) continue;

        let matchedRt = false;
        for (let zi = 0; zi < rtZ.length; zi++) {
          if (rep >= rtZ[zi].lo && rep <= rtZ[zi].hi) {
            zoneRt[zi].sec += seg;

            (
              zoneRtDays[dk] ||
              (zoneRtDays[dk] = new Array(rtZ.length).fill(0))
            )[zi] += seg;

            matchedRt = true;
            break;
          }
        }
        if (!matchedRt && rtZ.length) zoneRt[rtZ.length].sec += seg;
      }
    }
  }

  return {
    zoneFc,
    zoneRt,
    zoneFcDays,
    zoneRtDays,
    curveRitmo,
    curveVel,
    curveFc,
    curvePot,
    curveCad,
    hasAny:
      zoneFc.some((z) => z.sec > 0) ||
      zoneRt.some((z) => z.sec > 0) ||
      curveRitmo.some((v) => v != null) ||
      curveVel.some((v) => v != null) ||
      curveFc.some((v) => v != null),
    ok: true,
  };
}

// Mes "yyyy-mm" de una fecha en ms (día LOCAL, igual que dayKey del motor).
export function mesKeyDe(fechaMs) {
  const d = new Date(Number(fechaMs) || Date.now());
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
}

// Los segundos se redondean a 2 decimales AL GUARDAR (tamaño del documento
// mensual); el cálculo mantiene precisión completa para no acumular error.
export function redondearDigest(dg) {
  const out = { ...dg, dias: {} };

  for (const dk of Object.keys(dg.dias || {})) {
    const dd = dg.dias[dk] || {};
    out.dias[dk] = { fc: {}, rt: {} };

    for (const k of Object.keys(dd.fc || {})) {
      out.dias[dk].fc[k] = Math.round((dd.fc[k] || 0) * 100) / 100;
    }

    for (const k of Object.keys(dd.rt || {})) {
      out.dias[dk].rt[k] = Math.round((dd.rt[k] || 0) * 100) / 100;
    }
  }

  return out;
}
