// services/coachNotify.js
/* Notificaciones coach → atleta (push Expo vía el endpoint /notify-athlete).
   · Manda el token de Firebase en Authorization (Bearer): sin él el servidor
     responde "No autorizado" (bug histórico ya arreglado).
   · Ya NO redacta los textos: envía datos estructurados
     ({ kind, coachName, nombre, fechaStr, extra }) y es el SERVIDOR quien
     compone título y cuerpo EN EL IDIOMA DEL ATLETA.
   · kinds: creado | evento | movido | modificado | apuntado | comentario | reto */
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../firebaseConfig';
import { getApiUrl } from './api';
import { getCachedProfile } from './profileCache';

export async function sendNotificationToAthlete(athleteId, coachId, data) {
  try {
    const user = auth.currentUser;
    if (!user || !athleteId || athleteId === user.uid) return;
    const apiUrl = (await getApiUrl()).replace(/\/+$/, '');
    const token = await user.getIdToken();
    // Timeout de red: si el servidor no responde, el guardado del evento no
    // se queda colgado (la notificación simplemente no sale).
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    try {
      const r = await fetch(`${apiUrl}/notify-athlete`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,   // ← lo que faltaba
        },
        body: JSON.stringify({ athleteId, coachId, ...data }),
        signal: controller.signal,
      });
      // El servidor descarta pushes en silencio (self/no-profile/opt-out/
      // no-token): se registra el motivo para poder diagnosticar desde los logs.
      const j = await r.json().catch(() => null);
      if (!j || !j.ok) console.warn('[coachNotify] push no enviado a', athleteId, '→', (j && j.reason) || `HTTP ${r.status}`);
    } finally {
      clearTimeout(timer);
    }
  } catch (e) {
    console.warn('Error notificando al atleta:', e.message);
  }
}

export async function getCoachFullName(uid) {
  const c = await getCachedProfile(uid);
  if (c?.nombre) return `${c.nombre} ${c.apellido || ''}`.trim();
  const s = await getDoc(doc(db, 'perfiles', uid));
  if (s.exists()) { const d = s.data(); return `${d.nombre || ''} ${d.apellido || ''}`.trim(); }
  return 'Entrenador';
}
