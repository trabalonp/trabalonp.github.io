// services/coachCache.js
import AsyncStorage from '@react-native-async-storage/async-storage';

const COACH_KEY    = 'coach_cache';
const COACH_TS_KEY = 'coach_cache_ts';
// TTL corto: las solicitudes de entrenamiento y las aceptaciones deben
// verse en segundos, no a los 5 minutos (antes TTL_MS = 5 min).
const TTL_MS       = 45 * 1000; // 45 segundos

// Mini bus de eventos: cuando llega un push de solicitud/aceptación se avisa
// a las pantallas suscritas para que refresquen EN EL MOMENTO (sin esperar
// al TTL ni a volver a entrar en la pantalla).
const listeners = new Set();
export function onCoachRefresh(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
export function notificarCoachRefresh() {
  listeners.forEach((fn) => { try { fn(); } catch (e) {} });
}

export async function getCachedCoach() {
  try {
    const json = await AsyncStorage.getItem(COACH_KEY);
    return json ? JSON.parse(json) : null;
  } catch { return null; }
}

export async function isCacheStale() {
  try {
    const ts = await AsyncStorage.getItem(COACH_TS_KEY);
    if (!ts) return true;
    return Date.now() - parseInt(ts) > TTL_MS;
  } catch { return true; }
}

export async function cacheCoach(data) {
  try {
    await AsyncStorage.setItem(COACH_KEY, JSON.stringify(data));
    await AsyncStorage.setItem(COACH_TS_KEY, String(Date.now()));
  } catch (e) { console.warn('Error al cachear coach:', e); }
}

export async function clearCoachCache() {
  try {
    await AsyncStorage.multiRemove([COACH_KEY, COACH_TS_KEY]);
  } catch (e) {}
}