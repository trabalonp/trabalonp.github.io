/* tests/_curvas-mocks.js — helper compartido (NO es un test).
   Carga los SERVICIOS REALES (analyticsEngine, curvasDigest, curvasStore,
   perfLog, SyncService) con un transformador ESM→CJS mínimo y mocks EN
   MEMORIA de Firestore / AsyncStorage / auth, al estilo de chat-sync-test.
   Si se ejecuta solo (`node tests/_curvas-mocks.js`) sale con código 0. */
'use strict';
const fs = require('fs');
const path = require('path');
const Module = require('module');

/* ── Transformador ESM→CJS mínimo ── */
function transformar(src) {
  const nombres = [];
  let out = src
    .replace(/^import\s+\{\s*([^}]+?)\s*\}\s+from\s+'([^']+)';?$/gm,
      (m, ids, mod) => `const { ${ids.split(',').map((s) => s.trim()).join(', ')} } = require('${mod}');`)
    .replace(/^import\s+\*\s+as\s+(\w+)\s+from\s+'([^']+)';?$/gm,
      (m, id, mod) => `const ${id} = require('${mod}');`)
    .replace(/^import\s+(\w+)\s+from\s+'([^']+)';?$/gm,
      (m, id, mod) => `const ${id} = require('${mod}').default || require('${mod}');`)
    .replace(/^export\s+async\s+function\s+(\w+)/gm, (m, n) => { nombres.push(n); return `async function ${n}`; })
    .replace(/^export\s+function\s+(\w+)/gm, (m, n) => { nombres.push(n); return `function ${n}`; })
    .replace(/^export\s+const\s+(\w+)/gm, (m, n) => { nombres.push(n); return `const ${n}`; });
  // Object.assign (no module.exports = {...}): los ciclos de require capturan
  // el MISMO objeto y ven las exportaciones al resolverse las llamadas.
  return out + `\nObject.assign(module.exports, { ${[...new Set(nombres)].join(', ')} });\n`;
}

/* ── Firestore simulado en memoria ── */
function crearFirestore() {
  const docs = new Map();     // ruta 'a/b/c' -> datos
  const lecturas = [];        // { tipo, path, n } por operación de lectura
  const escritas = [];        // { tipo, path } por operación de escritura
  let autoId = 0;
  const DEL = { __del: true };

  const fakeTs = (ms) => ({ toMillis: () => ms, toDate: () => new Date(ms), _ms: ms });
  const unir = (parts) => parts.filter((p) => p != null).join('/');
  const normalizar = (v) => {
    if (v == null) return v;
    if (typeof v.toMillis === 'function') return v.toMillis();
    if (v instanceof Date) return v.getTime();
    return v;
  };
  const cmp = (a, b) => {
    const x = normalizar(a);
    const y = normalizar(b);
    if (x === y) return 0;
    if (typeof x === 'number' && typeof y === 'number') return x - y;
    if (x == null) return -1;
    if (y == null) return 1;
    return String(x) < String(y) ? -1 : 1;
  };
  const opCmp = (v, op, w) => {
    const c = cmp(v, w);
    if (op === '>') return c > 0;
    if (op === '<') return c < 0;
    if (op === '>=') return c >= 0;
    if (op === '<=') return c <= 0;
    if (op === '!=') return c !== 0;
    return c === 0;
  };
  const setPath = (obj, clave, val) => {
    const parts = clave.split('.');
    let cur = obj;
    for (let i = 0; i < parts.length - 1; i++) {
      if (cur[parts[i]] == null || typeof cur[parts[i]] !== 'object') cur[parts[i]] = {};
      cur = cur[parts[i]];
    }
    cur[parts[parts.length - 1]] = val;
  };
  const delPath = (obj, clave) => {
    const parts = clave.split('.');
    let cur = obj;
    for (let i = 0; i < parts.length - 1; i++) {
      if (cur[parts[i]] == null) return;
      cur = cur[parts[i]];
    }
    delete cur[parts[parts.length - 1]];
  };
  const resolver = (base, val) => {
    if (val && val.__sts) return fakeTs(Date.now());
    if (val && val.__au) {
      const arr = Array.isArray(base) ? base.slice() : [];
      val.__au.forEach((v) => { if (!arr.includes(v)) arr.push(v); });
      return arr;
    }
    if (val && val.__ar) {
      const arr = Array.isArray(base) ? base.slice() : [];
      return arr.filter((v) => !val.__ar.includes(v));
    }
    return val;
  };
  // Clon profundo que PRESERVA los objetos con métodos (Timestamps/sentinelas):
  // JSON.stringify los despojaría de toMillis/toDate.
  const clonar = (v) => {
    if (v == null || typeof v !== 'object') return v;
    if (typeof v.toMillis === 'function' || typeof v.toDate === 'function' || v.__sts || v.__au || v.__ar || v.__del) return v;
    if (Array.isArray(v)) return v.map(clonar);
    const out = {};
    for (const k of Object.keys(v)) out[k] = clonar(v[k]);
    return out;
  };
  // lista de docs de una colección a partir del mapa de rutas
  const listar = (colPath) => {
    const pref = colPath + '/';
    const out = [];
    docs.forEach((data, p) => {
      if (!p.startsWith(pref)) return;
      const resto = p.slice(pref.length);
      if (resto.includes('/')) return; // subdocumentos no son docs de la colección
      out.push({ id: resto, data });
    });
    return out;
  };

  const api = {
    Timestamp: {
      fromDate: (d) => fakeTs(d.getTime()),
      fromMillis: (ms) => fakeTs(ms),
      now: () => fakeTs(Date.now()),
    },
    serverTimestamp: () => ({ __sts: true }),
    deleteField: () => DEL,
    arrayUnion: (...vals) => ({ __au: vals }),
    arrayRemove: (...vals) => ({ __ar: vals }),
    collection: (db, ...names) => ({ __col: true, parts: names }),
    doc: (db, ...names) => ({ parts: names }),
    where: (field, op, val) => ({ t: 'where', field, op, val }),
    orderBy: (field, dir) => ({ t: 'orderBy', field, dir: dir || 'asc' }),
    limit: (n) => ({ t: 'limit', n }),
    startAfter: (snapDoc) => ({ t: 'startAfter', doc: snapDoc }),
    query: (col, ...constraints) => ({ col, constraints }),

    getDocs: async (q) => {
      const colPath = unir(q.col.parts);
      let lista = listar(colPath);
      for (const p of q.constraints) {
        if (p.t === 'where') lista = lista.filter((d) => opCmp(d.data[p.field], p.op, p.val));
      }
      const ob = q.constraints.find((p) => p.t === 'orderBy');
      if (ob) {
        lista.sort((a, b) => cmp(a.data[ob.field], b.data[ob.field]) * (ob.dir === 'desc' ? -1 : 1));
      }
      const sa = q.constraints.find((p) => p.t === 'startAfter');
      if (sa && sa.doc) {
        const i = lista.findIndex((d) => d.id === sa.doc.id);
        if (i >= 0) lista = lista.slice(i + 1);
      }
      const lim = q.constraints.find((p) => p.t === 'limit');
      if (lim) lista = lista.slice(0, lim.n);
      lecturas.push({ tipo: 'getDocs', path: colPath, n: lista.length });
      const snapDocs = lista.map((d) => ({ id: d.id, data: () => clonar(d.data) }));
      return {
        docs: snapDocs,
        empty: lista.length === 0,
        size: lista.length,
        forEach: (fn) => { snapDocs.forEach(fn); },
      };
    },

    getDoc: async (ref) => {
      const p = unir(ref.parts);
      lecturas.push({ tipo: 'getDoc', path: p, n: docs.has(p) ? 1 : 0 });
      return {
        exists: () => docs.has(p),
        data: () => (docs.has(p) ? clonar(docs.get(p)) : undefined),
      };
    },

    setDoc: async (ref, data, opts) => {
      const p = unir(ref.parts);
      const merge = opts && opts.merge;
      const base = merge && docs.has(p) ? clonar(docs.get(p)) : {};
      for (const k of Object.keys(data)) base[k] = resolver(base[k], data[k]);
      docs.set(p, base);
      escritas.push({ tipo: 'setDoc', path: p });
    },

    updateDoc: async (ref, data) => {
      const p = unir(ref.parts);
      if (!docs.has(p)) throw new Error(`updateDoc: documento inexistente ${p}`);
      const base = clonar(docs.get(p));
      for (const k of Object.keys(data)) {
        const v = data[k];
        if (v === DEL) delPath(base, k);
        else if (v && (v.__au || v.__ar)) base[k] = resolver(base[k], v);
        else setPath(base, k, v);
      }
      docs.set(p, base);
      escritas.push({ tipo: 'updateDoc', path: p });
    },

    deleteDoc: async (ref) => {
      const p = unir(ref.parts);
      docs.delete(p);
      escritas.push({ tipo: 'deleteDoc', path: p });
    },

    addDoc: async (colRef, data) => {
      const id = 'doc' + (++autoId);
      const p = unir(colRef.parts) + '/' + id;
      docs.set(p, clonar(data));
      escritas.push({ tipo: 'addDoc', path: p });
      return { id };
    },

    // utilidades del test
    seedDoc: (p, data) => { docs.set(p, data); },
    leerDoc: (p) => (docs.has(p) ? clonar(docs.get(p)) : undefined),
    hayDoc: (p) => docs.has(p),
    lecturas,
    escritas,
    resetLogs: () => { lecturas.length = 0; escritas.length = 0; },
  };

  return api;
}

/* ── AsyncStorage simulado ── */
function crearStorage() {
  const store = new Map();
  const log = { getItem: [], setItem: [], removeItem: [] };
  const api = {
    getItem: async (k) => { log.getItem.push(k); return store.has(k) ? store.get(k) : null; },
    setItem: async (k, v) => { log.setItem.push(k); store.set(k, String(v)); },
    removeItem: async (k) => { log.removeItem.push(k); store.delete(k); },
    get: (k) => store.get(k),
    set: (k, v) => store.set(k, String(v)),
    log,
  };
  api.default = api; // los imports por defecto resuelven .default || modulo
  return api;
}

/* ── Cargador de los archivos REALES con stubs ── */
function cargarReales(opts = {}) {
  const APP = opts.raiz || path.join(__dirname, '..');
  const fsMock = opts.firestore || crearFirestore();
  const storage = opts.storage || crearStorage();
  const auth = opts.auth || { currentUser: { uid: 'u1' } };
  const fileSystem = opts.fileSystem || {};
  const fitsdk = opts.fitsdk || {};
  const REALS = opts.reales || ['analyticsEngine.js', 'curvasDigest.js', 'curvasStore.js', 'perfLog.js'];

  const STUBS = {
    'firebase/firestore': fsMock,
    '@react-native-async-storage/async-storage': storage,
  };

  const cache = {};
  function loadReal(file) {
    if (cache[file]) return cache[file];
    const src = fs.readFileSync(file, 'utf8');
    const mod = new Module(file, null);
    mod.filename = file;
    mod.paths = Module._nodeModulePaths(path.dirname(file));
    cache[file] = mod.exports;
    mod._compile(transformar(src), file);
    return mod.exports;
  }

  const origLoad = Module._load;
  Module._load = function (request, parent) {
    if (Object.prototype.hasOwnProperty.call(STUBS, request)) return STUBS[request];
    if (request.endsWith('firebaseConfig')) return { db: {}, auth };
    if (request.endsWith('appSettings')) return { CURVAS_DIGEST_ENABLED: true };
    if (request.endsWith('planReal')) return { resolverPlanReal: () => ({ dist: 0, dur: 0 }) };
    if (request.endsWith('expo-file-system/legacy')) return fileSystem;
    if (request.endsWith('@garmin/fitsdk')) return fitsdk;
    if (parent && parent.filename && (request.startsWith('./') || request.startsWith('../'))) {
      const res = path.resolve(path.dirname(parent.filename), request);
      const cand = res.endsWith('.js') ? res : res + '.js';
      if (REALS.some((n) => cand.endsWith(path.join('services', n))) && fs.existsSync(cand)) return loadReal(cand);
    }
    return origLoad.apply(this, arguments);
  };

  const PF = loadReal(path.join(APP, 'services', 'perfLog.js'));
  // Orden anti-ciclo: curvasStore primero (su carga dispara curvasDigest →
  // analyticsEngine → curvasStore parcial por namespace; curvasDigest termina
  // ANTES de que curvasStore desestructure sus exportaciones con nombre).
  const CS = loadReal(path.join(APP, 'services', 'curvasStore.js'));
  const AE = loadReal(path.join(APP, 'services', 'analyticsEngine.js'));
  const CD = loadReal(path.join(APP, 'services', 'curvasDigest.js'));

  return {
    AE, CD, CS, PF,
    fsMock, storage, auth,
    loadReal, APP,
    restore: () => { Module._load = origLoad; },
  };
}

module.exports = { transformar, crearFirestore, crearStorage, cargarReales };

if (require.main === module) {
  console.log('_curvas-mocks.js es un helper para los tests de curvas (no es un test).');
}
