/* tests/perf-contadores-test.js — BLOQUE D5 (contadores perfLog).
   Simula usuarios con 10/50/100/300 actividades y registra, para el camino
   LEGACY y para el camino DIGEST (ambos con el código real y un Firestore
   simulado): documentos leídos, bytes aproximados, puntos procesados y ms de
   procesamiento JS MEDIDOS EN NODE. NO se afirma nada sobre tiempos de
   dispositivo: solo se reporta lo medido aquí y los recuentos de lecturas.
   Uso: node tests/perf-contadores-test.js */
'use strict';
process.env.PERF_LOG = '1'; // activa los contadores ANTES de cargar perfLog
const { crearFirestore, crearStorage, cargarReales } = require('./_curvas-mocks');

let pasadas = 0;
const fallos = [];
function ok(cond, msg) {
  if (cond) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log('FALLO ' + msg); }
}
function eq(a, b, msg) {
  if (a === b) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log(`FALLO ${msg} (esperado ${JSON.stringify(b)}, obtenido ${JSON.stringify(a)})`); }
}

const PERFIL = {
  zonasFC: [{ titulo: 'Z1', min: 0, max: 120 }, { titulo: 'Z2', min: 121, max: 145 }, { titulo: 'Z3', min: 146, max: 165 }, { titulo: 'Z4', min: 166, max: 180 }, { titulo: 'Z5', min: 181, max: 220 }],
  zonasRitmo: [{ titulo: 'R1', min: '7:00', max: '5:01' }, { titulo: 'R2', min: '5:00', max: '4:01' }, { titulo: 'R3', min: '4:00', max: '0:01' }],
};

const PUNTOS_POR_ACT = 120; // 2 minutos a 1 Hz

function puntos(f) {
  const out = [];
  let t = f;
  for (let i = 0; i < PUNTOS_POR_ACT; i++) {
    out.push({
      timestamp: new Date(t).toISOString(),
      frecuencia: Math.round(140 + 15 * Math.sin(i / 20)),
      velocidad: Number((10 + 2 * Math.sin(i / 15)).toFixed(3)),
      cadencia: 170,
    });
    t += 1000;
  }
  return out;
}

function mesesEntre(desdeMs) {
  const ini = new Date(desdeMs);
  const fin = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  const out = [];
  let y = ini.getFullYear();
  let m = ini.getMonth();
  for (;;) {
    if (y > fin.getFullYear() || (y === fin.getFullYear() && m > fin.getMonth())) break;
    out.push(`${y}-${pad(m + 1)}`);
    m++;
    if (m > 11) { m = 0; y++; }
  }
  return out;
}

function crearEnv(N) {
  const fsMock = crearFirestore();
  const storage = crearStorage();
  const env = cargarReales({ auth: { currentUser: { uid: 'u1' } }, firestore: fsMock, storage });
  const { AE, CD, CS, PF } = env;
  const base = new Date(2026, 7, 1, 8, 0, 0).getTime(); // agosto 2026
  const acts = [];

  for (let i = 0; i < N; i++) {
    const id = 'w' + i;
    const f = base + i * 300000; // 5 min entre entrenos → N=300 cabe en agosto
    const pts = puntos(f);
    fsMock.seedDoc(`entrenamientos/${id}`, {
      userId: 'u1', fecha: fsMock.Timestamp.fromMillis(f), tipo: 'Running',
      estado: 'completo', duracion: PUNTOS_POR_ACT, distancia: 5,
    });
    fsMock.seedDoc(`entrenamientos/${id}/registros/data`, { puntos: pts });
    acts.push({ id, f, pts });
  }
  return { env, AE, CD, CS, PF, fsMock, storage, acts, base };
}

async function main() {
const resultados = [];

for (const N of [10, 50, 100, 300]) {

  console.log(`\n═══ N=${N} actividades ═══`);

  /* ── Camino LEGACY ── */
  {
    const { AE, PF, fsMock } = crearEnv(N);
    PF.reiniciar();
    const res = await AE.getStreamsStatsLegacy('u1', 'todo', PERFIL, { zonaAct: 'General' });
    const r = PF.resumen();
    const c = r.contadores;
    const resumenes = (c['streams.resumenes'] || {}).docs || 0;
    const registros = (c['streams.registros'] || {}).docs || 0;
    const puntosN = (c['streams.puntos'] || {}).docs || 0;
    const bytes = ((c['streams.resumenes'] || {}).bytes || 0) + ((c['streams.registros'] || {}).bytes || 0);
    const ms = ((r.tiempos['streams.procesoJs'] || {}).ms || 0).toFixed(1);
    ok(res.ok, `legacy: resultado ok (N=${N})`);
    eq(resumenes, N, `legacy: lee ${N} resúmenes (docs)`);
    eq(registros, N, `legacy: lee ${N} documentos registros/data`);
    eq(puntosN, N * PUNTOS_POR_ACT, `legacy: procesa ${N * PUNTOS_POR_ACT} puntos`);
    resultados.push({ N, camino: 'legacy', resumenes, registros, puntos: puntosN, bytes, ms });
    console.log(`   legacy   → resúmenes: ${resumenes} docs · registros: ${registros} docs · puntos: ${puntosN} · bytes≈${bytes} · procesoJs acumulado: ${ms} ms (Node)`);
  }

  /* ── Camino DIGEST (meses ya persistidos, backfillV=1) ── */
  {
    const { AE, CD, PF, fsMock, acts, base } = crearEnv(N);
    // Persiste el digest de cada actividad en su documento mensual (como si el
    // backfill ya hubiera terminado).
    const actsMes = {};
    for (const a of acts) actsMes[a.id] = CD.calcularDigest(a.pts, 'Running', a.f);
    fsMock.seedDoc('analyticsCurves/u1/months/2026-08', { v: 1, acts: actsMes });
    fsMock.seedDoc('analyticsCurves/u1', { v: 1, backfillV: 1, primerMes: '2026-08' });
    PF.reiniciar();

    const t0 = Date.now();
    const res = await AE.getStreamsStats('u1', 'todo', PERFIL, { zonaAct: 'General' });
    const ms = Date.now() - t0;

    const r = PF.resumen();
    const c = r.contadores;
    const resumenes = (c['streams.resumenes'] || {}).docs || 0;
    const registros = (c['streams.registros'] || {}).docs || 0;
    const puntosN = (c['streams.puntos'] || {}).docs || 0;
    const meses = (c['curvas.meses'] || {}).docs || 0;
    const bytes = (c['curvas.meses'] || {}).bytes || 0;
    const esperados = mesesEntre(new Date(2026, 7, 1).getTime()).length;

    ok(res.ok, `digest: resultado ok (N=${N})`);
    eq(resumenes, 0, `digest: CERO resúmenes del período leídos (N=${N})`);
    eq(registros, 0, `digest: CERO registros/data leídos (N=${N})`);
    eq(puntosN, 0, `digest: CERO puntos procesados (N=${N})`);
    eq(meses, esperados, `digest: lee ${esperados} documentos mensuales (08/2026 → hoy)`);
    resultados.push({ N, camino: 'digest', resumenes, registros, puntos: puntosN, meses, bytes, ms });
    console.log(`   digest   → meses: ${meses} docs · resúmenes: 0 · registros: 0 · puntos: 0 · bytes≈${bytes} · total llamada: ${ms} ms (Node)`);
  }
}

console.log('\n═══ Resumen de contadores (medido en Node, sin afirmar tiempos de dispositivo) ═══');
console.log('   N    | camino  | resúmenes | registros | puntos | meses | bytes≈   | ms (Node)');
for (const r of resultados) {
  const meses = r.meses != null ? String(r.meses).padStart(6) : '     —';
  const res = String(r.resumenes).padStart(9);
  const reg = String(r.registros).padStart(10);
  const pts = String(r.puntos).padStart(7);
  console.log(`   ${String(r.N).padStart(5)} | ${r.camino.padEnd(7)} | ${res} | ${reg} | ${pts} | ${meses} | ${String(r.bytes).padStart(8)} | ${String(r.ms).padStart(9)}`);
}

console.log(`\n${pasadas} comprobaciones OK, ${fallos.length} fallos.`);
if (fallos.length) {
  fallos.forEach((f) => console.log(' - ' + f));
  process.exit(1);
}
console.log('TEST PERF-CONTADORES: PASS');
}

main().catch((e) => { console.error('ERROR:', e); process.exit(1); });
