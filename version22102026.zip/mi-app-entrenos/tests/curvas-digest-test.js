/* tests/curvas-digest-test.js — BLOQUE D1 (digest de curvas vs legacy).
   Genera actividades sintéticas (carrera, ciclismo con potencia, pausas
   dt>120, puntos desordenados/ausentes, sin FC, cruce de medianoche) y
   compara la salida del CÓDIGO LEGACY REAL (getStreamsStatsLegacy sobre un
   Firestore simulado) frente a fusionarDigests(calcularDigest(...)):
     · curveRitmo/Vel/Fc/Pot/Cad: iguales bit a bit.
     · zoneFc / zoneFcDays: iguales (tolerancia 0,01 s).
     · zoneRt / zoneRtDays: diferencia por zona ≤ 1 % del total de segundos
       con ritmo (binning a 1 s/km); se documenta el máximo medido.
     · Cambiar las zonas del perfil entre llamadas NO requiere recalcular
       el digest (el digest no contiene zonas).
   Uso: node tests/curvas-digest-test.js */
'use strict';
process.env.PERF_LOG = '';
const fs = require('fs');
const path = require('path');
const { crearFirestore, crearStorage, cargarReales } = require('./_curvas-mocks');

let pasadas = 0;
const fallos = [];
function ok(cond, msg) {
  if (cond) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log('FALLO ' + msg); }
}
function eq(a, b, msg) {
  if (a === b) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log(`FALLO ${msg} (esperado ${JSON.stringify(b)}, obtenido ${JSON.stringify(a)})`); }
}

const UID = 'u1';
const { AE, CD, CS, fsMock, storage, auth } = cargarReales({ auth: { currentUser: { uid: UID } } });

const ts = (ms) => fsMock.Timestamp.fromMillis(ms);
const fms = (t) => (t && t.toMillis ? t.toMillis() : new Date(t).getTime());

async function main() {

function streamCorrida({ t0, seg, vBase, fcBase, jitterMs = 0, semilla = 7 }) {
  const pts = [];
  let s = semilla;
  const rnd = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648; };
  let t = t0;
  for (let i = 0; i < seg; i++) {
    const p = i / seg;
    let v = vBase * (0.8 + 0.4 * Math.sin(i / 91)) * (1 - 0.05 * p);
    v *= 1 + (rnd() - 0.5) * 0.04;
    v = Math.max(0.5, v);
    pts.push({
      timestamp: new Date(t).toISOString(),
      frecuencia: Math.round(fcBase + 14 * Math.sin(i / 137) + (rnd() - 0.5) * 3),
      velocidad: Number(v.toFixed(3)),
      cadencia: Math.round(168 + 6 * Math.sin(i / 41)),
      potencia: 0,
    });
    t += 1000 + (jitterMs ? (i % 4 === 0 ? jitterMs : 0) : 0);
  }
  return pts;
}

// Carrera que CRUZA medianoche y con pausa (dt > 120) en medio.
const t0Noche = new Date(2026, 7, 20, 23, 40, 0).getTime();
const corridaNoche = streamCorrida({ t0: t0Noche, seg: 1500, vBase: 11, fcBase: 152 });
// Pausa de 5 min entre el punto 600 y el 601 (dt > 120 → ignorado).
const corte = new Date(corridaNoche[600].timestamp).getTime();
for (let i = 601; i < corridaNoche.length; i++) {
  corridaNoche[i].timestamp = new Date(new Date(corridaNoche[i].timestamp).getTime() + 300000).toISOString();
}
// Puntos DESORDENADOS: se intercambian dos timestamps (dt <= 0 → ignorado).
const auxTs = corridaNoche[200].timestamp;
corridaNoche[200].timestamp = corridaNoche[201].timestamp;
corridaNoche[201].timestamp = auxTs;

// Ciclismo con potencia, cadencia y huecos sin FC.
function streamBici({ t0, seg, semilla = 23 }) {
  const pts = [];
  let s = semilla;
  const rnd = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648; };
  let t = t0;
  for (let i = 0; i < seg; i++) {
    const fase = Math.sin((i / seg) * Math.PI * 6);
    let v = 26 + 14 * fase;
    v *= 1 + (rnd() - 0.5) * 0.06;
    v = Math.max(6, v);
    const punto = {
      timestamp: new Date(t).toISOString(),
      velocidad: Number(v.toFixed(3)),
      potencia: Math.round(150 + 160 * Math.max(0, fase) + (rnd() - 0.5) * 20),
      cadencia: Math.round(85 + 10 * Math.sin(i / 53)),
    };
    if (i % 9 !== 0) punto.frecuencia = Math.round(115 + 1.6 * v); // algunos sin FC
    pts.push(punto);
    t += 1000;
  }
  return pts;
}
const bici = streamBici({ t0: new Date(2026, 7, 21, 8, 0, 0).getTime(), seg: 1200 });

// Carrera SIN FC y sin cadencia.
function streamSinFc(t0, seg) {
  const pts = [];
  let t = t0;
  for (let i = 0; i < seg; i++) {
    pts.push({
      timestamp: new Date(t).toISOString(),
      velocidad: Number((9 + 3 * Math.sin(i / 60)).toFixed(3)),
    });
    t += 1000;
  }
  return pts;
}
const sinFc = streamSinFc(new Date(2026, 7, 22, 7, 0, 0).getTime(), 600);

// Fuerza: sin velocidad (no aporta ritmo).
function streamFuerza(t0, seg) {
  const pts = [];
  let t = t0;
  for (let i = 0; i < seg; i++) {
    pts.push({
      timestamp: new Date(t).toISOString(),
      frecuencia: Math.round(95 + 20 * Math.sin(i / 30)),
      cadencia: 35,
    });
    t += 1000;
  }
  return pts;
}
const fuerza = streamFuerza(new Date(2026, 7, 23, 18, 0, 0).getTime(), 300);

// Series con cambios fuertes de ritmo.
function streamSeries(t0, seg, semilla = 11) {
  const pts = [];
  let s = semilla;
  const rnd = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648; };
  let t = t0;
  for (let i = 0; i < seg; i++) {
    const bloque = Math.floor(i / 120) % 2;
    let v = bloque ? 8.5 : 17.5;
    v *= 1 + (rnd() - 0.5) * 0.03;
    pts.push({
      timestamp: new Date(t).toISOString(),
      velocidad: Number(v.toFixed(3)),
      frecuencia: Math.round(128 + 2.6 * v),
      cadencia: Math.round(165 + 12 * (v / 17.5)),
    });
    t += 1000;
  }
  return pts;
}
const series = streamSeries(new Date(2026, 7, 24, 7, 0, 0).getTime(), 900);

// Cinta con jitter de 500 ms (dts fraccionarios → comprueba la tolerancia).
const cinta = streamCorrida({ t0: new Date(2026, 7, 25, 7, 0, 0).getTime(), seg: 600, vBase: 10.5, fcBase: 148, jitterMs: 500 });

const ACTIVIDADES = [
  { id: 'w1', tipo: 'Running', fecha: corridaNoche[0].timestamp, puntos: corridaNoche },
  { id: 'w2', tipo: 'Ciclismo', fecha: bici[0].timestamp, puntos: bici },
  { id: 'w3', tipo: 'Running', fecha: sinFc[0].timestamp, puntos: sinFc },
  { id: 'w4', tipo: 'Fuerza', fecha: fuerza[0].timestamp, puntos: fuerza },
  { id: 'w5', tipo: 'Running', fecha: series[0].timestamp, puntos: series },
  { id: 'w6', tipo: 'Running', fecha: cinta[0].timestamp, puntos: cinta },
];

const PERFIL = {
  zonasFC: [
    { titulo: 'Z1', min: 0, max: 120 },
    { titulo: 'Z2', min: 121, max: 145 },
    { titulo: 'Z3', min: 146, max: 165 },
    { titulo: 'Z4', min: 166, max: 180 },
    { titulo: 'Z5', min: 181, max: 220 },
  ],
  zonasRitmo: [
    { titulo: 'R1', min: '7:00', max: '5:31' },
    { titulo: 'R2', min: '5:30', max: '4:51' },
    { titulo: 'R3', min: '4:50', max: '4:16' },
    { titulo: 'R4', min: '4:15', max: '3:46' },
    { titulo: 'R5', min: '3:45', max: '0:01' },
  ],
};

// Otro perfil (zonas distintas): cambiar zonas NO debe recalcular el digest.
const PERFIL_B = {
  zonasFC: [
    { titulo: 'A', min: 0, max: 130 },
    { titulo: 'B', min: 131, max: 150 },
    { titulo: 'C', min: 151, max: 175 },
    { titulo: 'D', min: 176, max: 220 },
  ],
  zonasRitmo: [
    { titulo: 'A', min: '6:30', max: '5:01' },
    { titulo: 'B', min: '5:00', max: '4:31' },
    { titulo: 'C', min: '4:30', max: '0:01' },
  ],
};

/* ══════ Siembra del Firestore simulado ══════ */
for (const a of ACTIVIDADES) {
  fsMock.seedDoc(`entrenamientos/${a.id}`, {
    userId: UID,
    fecha: ts(fms(new Date(a.fecha))),
    tipo: a.tipo,
    estado: 'completo',
    duracion: a.puntos.length,
    distancia: 10,
  });
  fsMock.seedDoc(`entrenamientos/${a.id}/registros/data`, { puntos: a.puntos });
}

const PERIODOS = [
  ['todo', null],
  ['2y', AE.periodStart('2y').getTime()],
];

console.log('— 1) Cálculo del digest: casos límite —');
{
  const vacio = CD.calcularDigest([], 'Running', 123);
  eq(vacio.sig, '0||', 'sin puntos → sig "0||"');
  eq(JSON.stringify(vacio.win.ritmo), JSON.stringify([null, null, null, null, null, null, null, null, null]), 'sin puntos → win.ritmo todo null');
  eq(Object.keys(vacio.dias).length, 0, 'sin puntos → sin días');
  const uno = CD.calcularDigest([{ timestamp: '2026-08-20T08:00:00.000Z', frecuencia: 150, velocidad: 10 }], 'Running', 1);
  eq(JSON.stringify(uno.win.fc), JSON.stringify([null, null, null, null, null, null, null, null, null]), '1 punto → sin ventanas (el bucle arranca en i=1, igual que legacy)');
  // dt<=0 y dt>120 se ignoran (igual que legacy)
  const conHuecos = [
    { timestamp: new Date(1000000).toISOString(), frecuencia: 150, velocidad: 10 },
    { timestamp: new Date(1001000).toISOString(), frecuencia: 150, velocidad: 10 },
    { timestamp: new Date(1002000).toISOString(), frecuencia: 150, velocidad: 10 }, // +1 s → dt=1
    { timestamp: new Date(1002000).toISOString(), frecuencia: 150, velocidad: 10 }, // dt=0 → ignorado
    { timestamp: new Date(1004000).toISOString(), frecuencia: 150, velocidad: 10 }, // dt=2
    { timestamp: new Date(1130000).toISOString(), frecuencia: 150, velocidad: 10 }, // dt=126 → ignorado
    { timestamp: new Date(1131000).toISOString(), frecuencia: 150, velocidad: 10 }, // dt=1
  ];
  const dh = CD.calcularDigest(conHuecos, 'Running', 1);
  const dia = Object.values(dh.dias)[0];
  let segFc = 0;
  for (const k of Object.keys(dia.fc)) segFc += dia.fc[k];
  eq(segFc, 5, 'dt<=0 y dt>120 ignorados: solo 5 s de FC (1+1+2+1)');
  // bins de ritmo: 3,6 km/h → 1000 s/km; 1,8 → 2000; 0,9 → 4000 → clave "3600"
  const bins = [
    { timestamp: new Date(2000000).toISOString(), velocidad: 3.6 },
    { timestamp: new Date(2001000).toISOString(), velocidad: 3.6 },
    { timestamp: new Date(2002000).toISOString(), velocidad: 1.8 },
    { timestamp: new Date(2003000).toISOString(), velocidad: 0.9 },
  ];
  const dbins = CD.calcularDigest(bins, 'Running', 2);
  const rt = Object.values(dbins.dias)[0].rt;
  eq(rt['1000'], 1, '3,6 km/h → bin "1000" (1 s)');
  eq(rt['2000'], 1, '1,8 km/h → bin "2000" (1 s)');
  eq(rt['3600'], 1, '0,9 km/h (4000 s/km) → tope en la clave "3600"');
  // Ciclismo: no aporta ritmo, sí velocidad
  const dbici = CD.calcularDigest(bins, 'Ciclismo', 3);
  eq(Object.keys(dbici.dias).length, 0, 'ciclismo: sin dias (no aporta a fc/rt con estos puntos)');
  ok(dbici.win.vel.some((v) => v != null), 'ciclismo: win.vel con valores');
  eq(JSON.stringify(dbici.win.ritmo), JSON.stringify([null, null, null, null, null, null, null, null, null]), 'ciclismo: win.ritmo todo null');
  // El digest no depende de las zonas: solo f/tipo/sig/win/dias
  const dg = CD.calcularDigest(corridaNoche.slice(0, 120), 'Running', 1);
  eq(Object.keys(dg).sort().join(','), 'dias,f,sig,tipo,win', 'el digest contiene SOLO f/tipo/sig/win/dias (sin zonas)');
}

console.log('\n— 2) Curvas bit a bit y zonas con tolerancia: digest vs LEGACY REAL —');
for (const [period, desdeMs] of PERIODOS) {
  fsMock.resetLogs();
  const resL = await AE.getStreamsStatsLegacy(UID, period, PERFIL, { zonaAct: 'General' });
  const digests = ACTIVIDADES.map((a) => CD.calcularDigest(a.puntos, a.tipo, fms(new Date(a.fecha))));
  const resD = CD.fusionarDigests(digests, PERFIL, desdeMs);

  ok(resL.ok, `periodo ${period}: legacy devuelve ok`);
  eq(resD.ok, true, `periodo ${period}: digest devuelve ok`);

  for (const curva of ['curveRitmo', 'curveVel', 'curveFc', 'curvePot', 'curveCad']) {
    eq(JSON.stringify(resD[curva]), JSON.stringify(resL[curva]), `${period} ${curva}: IDÉNTICA bit a bit al legacy`);
  }

  // zoneFc: tolerancia 0,01 s por zona
  let peorFc = 0;
  for (let zi = 0; zi < resL.zoneFc.length; zi++) {
    const d = Math.abs(resL.zoneFc[zi].sec - resD.zoneFc[zi].sec);
    if (d > peorFc) peorFc = d;
  }
  ok(peorFc <= 0.01, `${period} zoneFc: diferencia máxima ${peorFc.toFixed(6)} s ≤ 0,01 s`);

  // zoneFcDays: tolerancia 0,01 s por día y zona
  const diasFc = new Set([...Object.keys(resL.zoneFcDays), ...Object.keys(resD.zoneFcDays)]);
  let peorFcD = 0;
  for (const dk of diasFc) {
    const a = resL.zoneFcDays[dk] || [];
    const b = resD.zoneFcDays[dk] || [];
    for (let zi = 0; zi < Math.max(a.length, b.length); zi++) {
      const d = Math.abs((a[zi] || 0) - (b[zi] || 0));
      if (d > peorFcD) peorFcD = d;
    }
  }
  ok(peorFcD <= 0.01, `${period} zoneFcDays: diferencia máxima ${peorFcD.toFixed(6)} s ≤ 0,01 s`);

  // zoneRt: diferencia por zona ≤ 1 % del total de segundos con ritmo
  const totalRt = resL.zoneRt.reduce((a, z) => a + z.sec, 0);
  let peorRt = 0;
  let peorRtPct = 0;
  for (let zi = 0; zi < resL.zoneRt.length; zi++) {
    const d = Math.abs(resL.zoneRt[zi].sec - resD.zoneRt[zi].sec);
    if (d > peorRt) peorRt = d;
    if (totalRt > 0) {
      const pct = (d / totalRt) * 100;
      if (pct > peorRtPct) peorRtPct = pct;
    }
  }
  ok(peorRtPct <= 1, `${period} zoneRt: peor zona a ${peorRtPct.toFixed(3)} % del total de ritmo (${peorRt.toFixed(2)} s de ${totalRt.toFixed(1)} s) ≤ 1 %`);

  const diasRt = new Set([...Object.keys(resL.zoneRtDays), ...Object.keys(resD.zoneRtDays)]);
  let peorRtD = 0;
  let peorRtDPct = 0;
  for (const dk of diasRt) {
    const a = resL.zoneRtDays[dk] || [];
    const b = resD.zoneRtDays[dk] || [];
    for (let zi = 0; zi < Math.max(a.length, b.length); zi++) {
      const d = Math.abs((a[zi] || 0) - (b[zi] || 0));
      if (d > peorRtD) peorRtD = d;
      if (totalRt > 0) {
        const pct = (d / totalRt) * 100;
        if (pct > peorRtDPct) peorRtDPct = pct;
      }
    }
  }
  ok(peorRtDPct <= 1, `${period} zoneRtDays: peor celda a ${peorRtDPct.toFixed(3)} % del total de ritmo ≤ 1 %`);
  console.log(`      [${period}] máximos medidos: zoneFc=${peorFc.toFixed(6)} s · zoneFcDays=${peorFcD.toFixed(6)} s · zoneRt=${peorRtPct.toFixed(3)} % · zoneRtDays=${peorRtDPct.toFixed(3)} % (total ritmo ${totalRt.toFixed(1)} s)`);
}

console.log('\n— 2b) Límites de zona FRACCIONARIOS: el binning a 1 s/km sí desvía (≤1 %) —');
{
  // Con límites enteros el bin no vuelca nunca (rep = clave+0,5 queda siempre
  // del mismo lado); con límites fraccionarios aparece la desviación real del
  // binning, que debe quedar ≤ 1 % del total de segundos con ritmo.
  const PERFIL_FRACC = {
    zonasFC: PERFIL.zonasFC,
    zonasRitmo: [
      { titulo: 'R1', min: 420.5, max: 331.5 },
      { titulo: 'R2', min: 331.4, max: 291.6 },
      { titulo: 'R3', min: 291.5, max: 256.4 },
      { titulo: 'R4', min: 256.3, max: 226.2 },
      { titulo: 'R5', min: 226.1, max: 1 },
    ],
  };
  const resL = await AE.getStreamsStatsLegacy(UID, 'todo', PERFIL_FRACC, { zonaAct: 'Running' });
  const digests = ACTIVIDADES.map((a) => CD.calcularDigest(a.puntos, a.tipo, fms(new Date(a.fecha))));
  const resD = CD.fusionarDigests(digests, PERFIL_FRACC, null);
  const totalRt = resL.zoneRt.reduce((a, z) => a + z.sec, 0);
  let peorRtPct = 0;
  for (let zi = 0; zi < resL.zoneRt.length; zi++) {
    const d = Math.abs(resL.zoneRt[zi].sec - resD.zoneRt[zi].sec);
    if (totalRt > 0) {
      const pct = (d / totalRt) * 100;
      if (pct > peorRtPct) peorRtPct = pct;
    }
  }
  ok(peorRtPct <= 1, `límites fraccionarios: peor zona a ${peorRtPct.toFixed(3)} % del total de ritmo (${totalRt.toFixed(1)} s) ≤ 1 %`);
  console.log(`      máximo medido con límites fraccionarios: ${peorRtPct.toFixed(3)} % (el binning a 1 s/km)`);
}

console.log('\n— 3) Cambiar las zonas del perfil NO requiere recalcular el digest —');
{
  const digests = ACTIVIDADES.map((a) => CD.calcularDigest(a.puntos, a.tipo, fms(new Date(a.fecha))));
  const r1 = CD.fusionarDigests(digests, PERFIL, null);
  const r2 = CD.fusionarDigests(digests, PERFIL_B, null); // mismas digests, otras zonas
  eq(JSON.stringify(r1.curveRitmo), JSON.stringify(r2.curveRitmo), 'las curvas no cambian al cambiar las zonas (mismos digests)');
  eq(JSON.stringify(r1.curveFc), JSON.stringify(r2.curveFc), 'la curva de FC no cambia al cambiar las zonas');
  ok(JSON.stringify(r1.zoneFc) !== JSON.stringify(r2.zoneFc), 'las zonas SÍ cambian (se aplican al leer, no al calcular)');
  ok(r2.zoneFc.length > 0 && r2.zoneRt.length > 0, 'el perfil B produce sus propias zonas al leer');
}

console.log('\n— 4) Fusión: filtro desdeMs y combinación entre actividades —');
{
  const digests = ACTIVIDADES.map((a) => CD.calcularDigest(a.puntos, a.tipo, fms(new Date(a.fecha))));
  const desde = fms(new Date(ACTIVIDADES[2].fecha)); // deja fuera w1 y w2
  const r = CD.fusionarDigests(digests, PERFIL, desde);
  const todos = CD.fusionarDigests(digests, PERFIL, null);
  // w1 (cruce de medianoche) tiene días de FC antes del corte → al quitar w1
  // sus días desaparecen del resultado filtrado.
  const dkAntes = '2026-08-20';
  ok(Object.keys(todos.zoneFcDays).includes(dkAntes) || Object.keys(todos.zoneFcDays).some((k) => k < '2026-08-21'), 'sin filtro: hay días de FC del 20/08 (cruce de medianoche de w1)');
  ok(!Object.keys(r.zoneFcDays).includes(dkAntes), 'con desdeMs: los días de w1 (anterior) desaparecen');
  ok(r.hasAny, 'fusión con actividades restantes: hasAny');
  const vacia = CD.fusionarDigests([], PERFIL, null);
  eq(vacia.hasAny, false, 'fusión sin digests: hasAny false, estructura completa');
  eq(JSON.stringify(vacia.curveRitmo), JSON.stringify([null, null, null, null, null, null, null, null, null]), 'fusión vacía: curvas a null');
}

console.log(`\n${pasadas} comprobaciones OK, ${fallos.length} fallos.`);
if (fallos.length) {
  fallos.forEach((f) => console.log(' - ' + f));
  process.exit(1);
}
console.log('TEST CURVAS-DIGEST: PASS');
}

main().catch((e) => { console.error('ERROR:', e); process.exit(1); });
