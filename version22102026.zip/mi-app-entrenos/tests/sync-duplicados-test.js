/* tests/sync-duplicados-test.js — BLOQUE D3 (importación FIT con menos lecturas).
   Sobre el syncFitFiles REAL con mocks de FileSystem/FIT-SDK/Firestore:
     · Con 10 archivos YA importados (índice local) no se hace NINGUNA
       consulta a Firestore.
     · Con 1 archivo nuevo, UNA SOLA consulta (checkDuplicate).
     · perfil/wellness solo se leen si hay algún archivo nuevo (carga
       perezosa, A7).
     · El índice fit_imported_v1_<uid> se actualiza tras la sync.
   Uso: node tests/sync-duplicados-test.js */
'use strict';
const path = require('path');
const { crearFirestore, crearStorage, cargarReales } = require('./_curvas-mocks');

let pasadas = 0;
const fallos = [];
function ok(cond, msg) {
  if (cond) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log('FALLO ' + msg); }
}
function eq(a, b, msg) {
  if (a === b) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log(`FALLO ${msg} (esperado ${JSON.stringify(b)}, obtenido ${JSON.stringify(a)})`); }
}

const NOMBRES = ['f1.fit', 'f2.fit', 'f3.fit', 'f4.fit', 'f5.fit', 'f6.fit', 'f7.fit', 'f8.fit', 'f9.fit', 'f10.fit'];

// Un "FIT" sintético de running sin records: parseFitFile devuelve una sesión
// con resumen y SIN registros (no escribe registros/data ni digest).
const fitsdk = {
  Stream: { fromByteArray: () => ({}) },
  Decoder: class {
    static isFIT() { return true; }
    read() {
      return {
        messages: {
          sessionMesgs: [{ startTime: new Date('2026-08-20T08:00:00Z'), totalDistance: 5000, totalTimerTime: 1500, avgHeartRate: 145, maxHeartRate: 180, sport: 'running', avgSpeed: 3.33, avgCadence: 80, totalAscent: 10, totalDescent: 5, totalCalories: 200 }],
          lapMesgs: [],
          recordMesgs: [],
        },
        errors: [],
      };
    }
  },
};

function crearEnv(indexNombres) {
  const fsMock = crearFirestore();
  const storage = crearStorage();
  storage.set('fit_folder_uri', 'folder:/fits');
  if (indexNombres.length) storage.set('fit_imported_v1_u1', JSON.stringify(indexNombres));
  const fileSystem = {
    StorageAccessFramework: { readDirectoryAsync: async () => NOMBRES.map((n) => 'file:/a/' + n) },
    EncodingType: { Base64: 'base64' },
    readAsStringAsync: async () => '',
  };
  const env = cargarReales({
    auth: { currentUser: { uid: 'u1' } },
    firestore: fsMock,
    storage,
    fileSystem,
    fitsdk,
  });
  const SS = env.loadReal(path.join(env.APP, 'services', 'SyncService.js'));
  return { env, SS, fsMock, storage };
}

const lecturasDe = (fsMock, tipo, prefijo) => fsMock.lecturas.filter((l) => l.tipo === tipo && l.path.startsWith(prefijo)).length;

async function main() {

console.log('— 1) 10 archivos ya importados: CERO consultas a Firestore —');
{
  const { SS, fsMock, storage } = crearEnv(NOMBRES);
  const res = await SS.syncFitFiles('u1');
  eq(res.synced, 0, 'nada nuevo que importar');
  eq(res.skipped, 10, '10 saltados por el índice local');
  eq(res.errors, 0, 'sin errores');
  eq(lecturasDe(fsMock, 'getDocs', 'entrenamientos'), 0, 'CERO getDocs sobre entrenamientos');
  eq(lecturasDe(fsMock, 'getDoc', 'perfiles/u1'), 0, 'CERO lecturas de perfil');
  eq(lecturasDe(fsMock, 'getDoc', 'wellness/u1'), 0, 'CERO lecturas de wellness');
}

console.log('\n— 2) 1 archivo nuevo: UNA sola consulta y perfil/wellness solo una vez —');
{
  const { SS, fsMock, storage } = crearEnv(NOMBRES.slice(0, 9)); // f10.fit es nuevo
  const res = await SS.syncFitFiles('u1');
  eq(res.synced, 1, 'se importa solo el archivo nuevo');
  eq(res.skipped, 9, 'los otros 9 salen por el índice');
  eq(lecturasDe(fsMock, 'getDocs', 'entrenamientos'), 1, 'UNA sola consulta a Firestore (checkDuplicate de f10.fit)');
  eq(lecturasDe(fsMock, 'getDoc', 'perfiles/u1'), 1, 'perfil leído UNA vez (carga perezosa)');
  eq(lecturasDe(fsMock, 'getDoc', 'wellness/u1'), 1, 'wellness leído UNA vez (carga perezosa)');
  eq(fsMock.escritas.filter((w) => w.tipo === 'addDoc').length, 1, 'un solo addDoc (el entreno nuevo)');
  const idx = JSON.parse(storage.get('fit_imported_v1_u1'));
  ok(Array.isArray(idx) && idx.includes('f10.fit'), 'el índice local incluye el archivo nuevo tras la sync');
  eq(idx.length, 10, 'el índice queda con los 10 nombres');
}

console.log('\n— 3) Todo duplicado vía índice: perfil/wellness NUNCA se leen —');
{
  // Índice completo + un duplicado REAL en Firestore (el índice no es la única
  // fuente: si el nombre no estuviera en el índice, Firestore decidiría).
  const { SS, fsMock, storage } = crearEnv(NOMBRES);
  fsMock.seedDoc('entrenamientos/dup1', { userId: 'u1', id_archivo: 'f1.fit', fecha: fsMock.Timestamp.fromMillis(Date.now()) });
  const res = await SS.syncFitFiles('u1');
  eq(res.synced, 0, 'todo sigue saltándose por el índice');
  eq(lecturasDe(fsMock, 'getDocs', 'entrenamientos'), 0, 'sin consultas Firestore');
  eq(lecturasDe(fsMock, 'getDoc', 'perfiles/u1'), 0, 'perfil no se lee');
}

console.log('\n— 4) Sin índice: la consulta Firestore sigue siendo la autoritativa —');
{
  const { SS, fsMock } = crearEnv([]); // índice vacío
  // todos duplicados en Firestore → checkDuplicate por archivo, sin importar
  for (const n of NOMBRES) {
    fsMock.seedDoc('entrenamientos/' + n, { userId: 'u1', id_archivo: n, fecha: fsMock.Timestamp.fromMillis(Date.now()) });
  }
  const res = await SS.syncFitFiles('u1');
  eq(res.skipped, 10, 'los 10 son duplicados según Firestore');
  eq(res.synced, 0, 'nada importado');
  eq(lecturasDe(fsMock, 'getDocs', 'entrenamientos'), 10, '10 consultas (una por archivo, sin índice)');
  eq(lecturasDe(fsMock, 'getDoc', 'perfiles/u1'), 0, 'perfil/wellness NO se leen si todo es duplicado (carga perezosa)');
}

console.log(`\n${pasadas} comprobaciones OK, ${fallos.length} fallos.`);
if (fallos.length) {
  fallos.forEach((f) => console.log(' - ' + f));
  process.exit(1);
}
console.log('TEST SYNC-DUPLICADOS: PASS');
}

main().catch((e) => { console.error('ERROR:', e); process.exit(1); });
