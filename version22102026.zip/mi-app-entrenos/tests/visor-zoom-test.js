/* tests/visor-zoom-test.js — REGRESIÓN: visor de imágenes con zoom y teclado
   en la descripción al editar un entreno.

   Correcciones:
     1) La previsualización de imágenes de la librería de archivos (y la de
        los adjuntos del entreno) ahora usa VisorImagenZoom: pellizco 1x–5x
        anclado al foco, pan con tope y doble toque 2.5x (misma mecánica que
        el chat de SocialScreen).
     2) Al editar un entreno, el teclado ya no tapa el recuadro de la
        descripción: el modal usa KeyboardAvoidingView behavior 'height' en
        Android y al enfocar la descripción se baja el scroll hasta ella.

   Uso: node tests/visor-zoom-test.js */
'use strict';
const fs = require('fs');
const path = require('path');

let pasadas = 0;
const fallos = [];
function ok(cond, msg) {
  if (cond) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log('FALLO ' + msg); }
}

const RAIZ = path.join(__dirname, '..');
const leer = (p) => fs.readFileSync(path.join(RAIZ, p), 'utf8');
const srcZoom = leer('components/VisorImagenZoom.js');
const srcArch = leer('components/ArchivosPicker.js');
const srcWdm = leer('screens/WorkoutDetailModal.js');

console.log('— 1) VisorImagenZoom: pellizco + doble toque —');
ok(/Gesture\.Pinch\(\)/.test(srcZoom), 'pellizco para el zoom');
ok(/const next = clamp\(s0 \* \(e\.scale \/ p0e\.value\), MINZ, MAXZ\)/.test(srcZoom), 'zoom acotado 1x–5x');
ok(/numberOfTaps\(2\)/.test(srcZoom) && /const next = 2\.5/.test(srcZoom), 'doble toque → 2.5x / vuelta a 1x');
ok(/tx\.value = clamp\(fx - \(p0fx\.value - p0x\.value\) \* ratio, -b\.maxX, b\.maxX\)/.test(srcZoom), 'zoom anclado al punto de los dedos (misma fórmula que el chat)');
ok(/contentFit="contain"/.test(srcZoom), 'imagen con contain (letterbox real)');

console.log('— 2) Librería de archivos y adjuntos usan el visor con zoom —');
ok(/import VisorImagenZoom from '\.\/VisorImagenZoom';/.test(srcArch), 'ArchivosPicker importa el visor con zoom');
ok(/<VisorImagenZoom visible=\{!!visor\} url=\{visor\?\.url\} nombre=\{visor\?\.nombre\}/.test(srcArch), 'la previsualización de imagen de la librería usa el zoom (el vídeo sigue embebido)');
ok(/import VisorImagenZoom from '\.\.\/components\/VisorImagenZoom';/.test(srcWdm), 'WorkoutDetailModal importa el visor con zoom');
ok(/<VisorImagenZoom visible=\{!!visorImg\} url=\{visorImg\?\.url\}/.test(srcWdm), 'las imágenes adjuntas del entreno también se amplían');

console.log('— 3) Teclado en la descripción al editar —');
ok(/behavior=\{Platform\.OS==='ios' \? 'padding' : 'height'\}/.test(srcWdm), 'KAV con height en Android (el teclado ya no tapa)');
ok(/const editScrollRef = useRef\(null\);/.test(srcWdm) && /ref=\{editScrollRef\}/.test(srcWdm), 'scroll del formulario con ref');
ok(/onFocus=\{\(\) => setTimeout\(\(\) => editScrollRef\.current\?\.scrollToEnd\(\{ animated: true \}\), 150\)\}/.test(srcWdm), 'al enfocar la descripción se baja hasta ella');

console.log('— 4) Chat de Social: MISMO visor con zoom que la librería (foto única) —');
const srcSocial = leer('screens/SocialScreen.js');
ok(/import VisorImagenZoom from '\.\.\/components\/VisorImagenZoom';/.test(srcSocial), 'SocialScreen importa el visor con zoom');
ok(/<VisorImagenZoom visible url=\{viewer\.url\} onClose=\{\(\) => setViewer\(null\)\} \/>/.test(srcSocial), 'las fotos del chat abren UNA foto con el visor de la librería (sin pase lateral ni contador)');
ok(/setViewer\(\{ url \}\);/.test(srcSocial), 'el visor recibe la URL remota de la foto tocada (fiable en Android)');
ok(!/urls=\{viewer\.urls\}/.test(srcSocial), 'ya no se pasa la lista de todas las fotos al visor (sin swipe entre fotos)');
ok(!/tappedIdx/.test(srcSocial), 'ya no se recogen todas las fotos del chat para el visor');

console.log('— 5) Chat: ventana de mensajes estilo WhatsApp (10 al abrir, caché intacta) —');
ok(/const VENTANA_INICIAL = 10;/.test(srcSocial) && /const PASO_VENTANA = 20;/.test(srcSocial), 'al abrir solo se pintan 10 mensajes; se amplían de 20 en 20');
ok(/posts\.slice\(Math\.max\(0, posts\.length - ventana\)\)/.test(srcSocial), 'la ventana corta por la cola del almacén');
ok(/if \(ventana < posts\.length\) \{/.test(srcSocial), 'al subir, primero se muestran los mensajes ya en caché');
ok(/setVentana\(\(v\) => Math\.min\(posts\.length, v \+ PASO_VENTANA\)\);/.test(srcSocial), 'se amplía la ventana desde la caché (instantáneo)');
ok(/setVentana\(\(v\) => Math\.min\(todos\.length, v \+ Math\.max\(0, todos\.length - antes\)\)\);/.test(srcSocial), 'el bloque antiguo del servidor se añade sin cortar lo visible');
ok(/ventana >= posts\.length/.test(srcSocial), 'el indicador de carga/inicio solo aparece al agotar la ventana');
ok(/const visibles = useMemo\(/.test(srcSocial) && /\[posts, ventana\]/.test(srcSocial), 'lista visible memorizada');

console.log('');
if (fallos.length) {
  console.log(`✗ ${fallos.length} comprobación(es) fallida(s)`);
  fallos.forEach((f) => console.log(' · ' + f));
  process.exit(1);
}
console.log(`${pasadas} comprobaciones OK`);
console.log('✅ visor-zoom-test: TODO VERDE');
