/* tests/crash-guards-test.js — REGRESIÓN: protecciones contra el pantallazo
   blanco y el borrado de pasos de un entreno.

   Síntoma que se corrige:
     · Al abrir un entreno la app se quedaba en blanco congelada; al
       reiniciarla, un entreno de fuerza aparecía sin ejercicios ni
       descripción (solo el título).
     · Protecciones: 1) la vista de un entreno NUNCA persiste una lista de
       pasos vacía; 2) FuerzaResumen no pinta ni persiste con lista vacía;
       3) un ErrorBoundary en App.js convierte un error de render en una
       pantalla con el mensaje del error y botón Reintentar (adiós blanco).

   Uso: node tests/crash-guards-test.js */
'use strict';
const fs = require('fs');
const path = require('path');

let pasadas = 0;
const fallos = [];
function ok(cond, msg) {
  if (cond) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log('FALLO ' + msg); }
}

const RAIZ = path.join(__dirname, '..');
const leer = (p) => fs.readFileSync(path.join(RAIZ, p), 'utf8');
const srcWdm = leer('screens/WorkoutDetailModal.js');
const srcRes = leer('components/PasosResumen.js');
const srcApp = leer('App.js');

console.log('— 1) La vista nunca borra los pasos —');
ok(/if \(!Array\.isArray\(next\) \|\| next\.length === 0\) return;/.test(srcWdm), 'WorkoutDetailModal: no se persisten pasos vacíos desde la vista');
ok(/if \(!Array\.isArray\(pasos\) \|\| pasos\.length === 0\) \{/.test(srcRes), 'FuerzaResumen: con lista vacía no pinta ni persiste nada');
ok(/Sin ejercicios configurados\./.test(srcRes), 'FuerzaResumen muestra un aviso en vez de romper');

console.log('— 2) Pantallazo blanco → pantalla de error controlada —');
ok(/class ErrorBoundary extends React\.Component/.test(srcApp), 'App.js tiene un ErrorBoundary');
ok(/static getDerivedStateFromError\(error\)/.test(srcApp), 'captura errores de render');
ok(/<ErrorBoundary>/.test(srcApp) && /<\/ErrorBoundary>/.test(srcApp), 'envuelve la navegación');
ok(/Reintentar/.test(srcApp), 'pantalla con botón Reintentar y el mensaje del error');

console.log('— 3) El modal de detalle se REMONTA por entreno (sin estado del anterior) —');
ok(/<WorkoutDetailModal[\s\S]{0,80}key=\{selectedWorkout\?\.id \|\| 'cerrado'\}/.test(leer('screens/CalendarScreen.js')), 'Calendario: key por id del entreno (el estado del entreno anterior no se reutiliza)');
ok(/<WorkoutDetailModal key=\{selectedWorkout\?\.id \|\| 'cerrado'\}/.test(leer('screens/HomeScreen.js')), 'Home: key por id del entreno');

console.log('');
if (fallos.length) {
  console.log(`✗ ${fallos.length} comprobación(es) fallida(s)`);
  fallos.forEach((f) => console.log(' · ' + f));
  process.exit(1);
}
console.log(`${pasadas} comprobaciones OK`);
console.log('✅ crash-guards-test: TODO VERDE');
