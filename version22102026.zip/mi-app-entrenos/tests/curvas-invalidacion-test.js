/* tests/curvas-invalidacion-test.js — BLOQUE D2 (invalidación y digest store,
   con mocks de Firestore/AsyncStorage). Comprueba sobre los módulos REALES:
     1) Editar la fecha mueve el digest de mes (quitar + pendiente + rebuild).
     2) Borrar lo elimina (quitarDigest).
     3) marcarPendiente + procesarPendientes reconstruye el digest.
     4) Reimportar el mismo archivo no duplica (misma clave acts.<id>).
     5) La firma de A4 (syncAnalyticsDays) no invalida con entrenos sin cambios
        y sí con uno nuevo.
     6) Un entrenador NO escribe digests del atleta.
     7) invalidarCurvasEntreno resetea la caché en memoria de los meses.
   Uso: node tests/curvas-invalidacion-test.js */
'use strict';
const { crearFirestore, crearStorage, cargarReales } = require('./_curvas-mocks');

let pasadas = 0;
const fallos = [];
function ok(cond, msg) {
  if (cond) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log('FALLO ' + msg); }
}
function eq(a, b, msg) {
  if (a === b) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log(`FALLO ${msg} (esperado ${JSON.stringify(b)}, obtenido ${JSON.stringify(a)})`); }
}

const auth = { currentUser: { uid: 'u1' } };
const { AE, CD, CS, fsMock, storage } = cargarReales({ auth });

const fA = new Date(2026, 7, 15, 8, 0, 0).getTime();   // 15/08/2026
const fB = new Date(2026, 10, 10, 8, 0, 0).getTime();  // 10/11/2026 (otro mes)

function puntos(seg, f, { velocidad = 10, frecuencia = 150, potencia = 0, cadencia = 90 } = {}) {
  const out = [];
  let t = f;
  for (let i = 0; i < seg; i++) {
    const p = { timestamp: new Date(t).toISOString(), velocidad, cadencia };
    if (frecuencia) p.frecuencia = frecuencia;
    if (potencia) p.potencia = potencia;
    out.push(p);
    t += 1000;
  }
  return out;
}

async function main() {

console.log('— 1) Editar la fecha mueve el digest de mes —');
{
  const pts = puntos(120, fA);
  fsMock.seedDoc('entrenamientos/w1', { userId: 'u1', fecha: fsMock.Timestamp.fromMillis(fA), tipo: 'Running', estado: 'completo', duracion: 120 });
  fsMock.seedDoc('entrenamientos/w1/registros/data', { puntos: pts });

  const digA = CD.calcularDigest(pts, 'Running', fA);
  const g1 = await CS.guardarDigest('u1', 'w1', digA);
  eq(g1.ok, true, 'guardarDigest inicial ok');
  ok(fsMock.leerDoc('analyticsCurves/u1/months/2026-08')?.acts?.w1, 'el digest está en el mes 2026-08');

  // Edición de fecha (lo que hace la app): invalida + pendiente + quitar
  await CS.marcarPendiente('u1', 'w1');
  await CS.quitarDigest('u1', 'w1', fA);
  fsMock.seedDoc('entrenamientos/w1', { userId: 'u1', fecha: fsMock.Timestamp.fromMillis(fB), tipo: 'Running', estado: 'completo', duracion: 120 });

  ok(!fsMock.leerDoc('analyticsCurves/u1/months/2026-08')?.acts?.w1, 'quitarDigest lo saca del mes antiguo');
  ok(Array.isArray(fsMock.leerDoc('analyticsCurves/u1')?.pendientes) && fsMock.leerDoc('analyticsCurves/u1').pendientes.includes('w1'), 'marcarPendiente añade w1 al meta');

  const res = await CS.procesarPendientes('u1', { max: 40 });
  eq(res.procesados, 1, 'procesarPendientes reconstruye 1 digest');
  const mesB = fsMock.leerDoc('analyticsCurves/u1/months/2026-11');
  ok(mesB && mesB.acts && mesB.acts.w1, 'el digest reconstruido está en el mes NUEVO (2026-11)');
  eq(mesB.acts.w1.f, fB, 'el digest reconstruido tiene la fecha NUEVA');
  ok(!(fsMock.leerDoc('analyticsCurves/u1').pendientes || []).includes('w1'), 'la pendiente sale del meta al procesarse');
}

console.log('\n— 2) Borrar lo elimina (quitarDigest) —');
{
  const pts = puntos(60, fA);
  const dg = CD.calcularDigest(pts, 'Running', fA);
  await CS.guardarDigest('u1', 'w2', dg);
  ok(fsMock.leerDoc('analyticsCurves/u1/months/2026-08')?.acts?.w2, 'w2 con digest en 2026-08');
  await CS.quitarDigest('u1', 'w2', fA);
  ok(!fsMock.leerDoc('analyticsCurves/u1/months/2026-08')?.acts?.w2, 'tras borrar, el digest desaparece');
  await CS.quitarDigest('u1', 'w-inexistente', fA); // documento inexistente tolerado
  ok(true, 'quitarDigest sobre documento inexistente no lanza');
}

console.log('\n— 3) marcarPendiente + procesarPendientes reconstruye (cambio de tipo) —');
{
  const pts = puntos(90, fB, { velocidad: 28, potencia: 200, cadencia: 88 });
  fsMock.seedDoc('entrenamientos/w3', { userId: 'u1', fecha: fsMock.Timestamp.fromMillis(fB), tipo: 'Running', estado: 'completo', duracion: 90 });
  fsMock.seedDoc('entrenamientos/w3/registros/data', { puntos: pts });

  // Digest VIEJO con el tipo equivocado
  const digViejo = CD.calcularDigest(pts, 'Running', fB);
  await CS.guardarDigest('u1', 'w3', digViejo);
  eq(fsMock.leerDoc('analyticsCurves/u1/months/2026-11').acts.w3.tipo, 'Running', 'digest viejo con tipo Running');

  // El usuario cambia el tipo a Ciclismo → pendiente
  fsMock.seedDoc('entrenamientos/w3', { userId: 'u1', fecha: fsMock.Timestamp.fromMillis(fB), tipo: 'Ciclismo', estado: 'completo', duracion: 90 });
  await CS.marcarPendiente('u1', 'w3');
  const res = await CS.procesarPendientes('u1', { max: 40 });
  eq(res.procesados, 1, 'procesarPendientes reconstruye w3');
  const act = fsMock.leerDoc('analyticsCurves/u1/months/2026-11').acts.w3;
  eq(act.tipo, 'Ciclismo', 'el digest reconstruido tiene el tipo NUEVO (Ciclismo)');
  ok(act.win.vel.some((v) => v != null), 'el digest de Ciclismo tiene curva de velocidad');
  eq(JSON.stringify(act.win.ritmo), JSON.stringify([null, null, null, null, null, null, null, null, null]), 'el digest de Ciclismo no tiene ritmo');
}

console.log('\n— 4) Reimportar el mismo archivo no duplica (misma clave acts.<id>) —');
{
  const pts = puntos(60, fA);
  const d1 = CD.calcularDigest(pts, 'Running', fA);
  const d2 = CD.calcularDigest(pts, 'Running', fA + 1000);
  await CS.guardarDigest('u1', 'w4', d1);
  await CS.guardarDigest('u1', 'w4', d2); // reimportación: misma clave
  const acts = fsMock.leerDoc('analyticsCurves/u1/months/2026-08').acts;
  eq(Object.keys(acts).filter((k) => k === 'w4').length, 1, 'una sola clave acts.w4 (sin duplicar)');
  eq(acts.w4.f, fA + 1000, 'la segunda escritura pisa la primera (misma clave)');
}

console.log('\n— 5) Firma A4: la sync incremental solo invalida si cambian los entrenos —');
{
  // Entorno limpio (solo los docs aa/ab/ac) para no mezclarse con w1..w4.
  const env2 = cargarReales({ auth: { currentUser: { uid: 'u1' } } });
  const AE2 = env2.AE;
  const fsm2 = env2.fsMock;
  const st2 = env2.storage;
  const AHORA = Date.now();
  st2.set('analyticsCache_v6_u1', JSON.stringify({ v: 6, oldDone: true, days: {}, lastSyncAt: AHORA - 10 * 86400000 }));
  fsm2.seedDoc('entrenamientos/aa', { userId: 'u1', fecha: fsm2.Timestamp.fromMillis(AHORA - 86400000), tipo: 'Running', estado: 'completo', duracion: 1800 });
  fsm2.seedDoc('entrenamientos/ab', { userId: 'u1', fecha: fsm2.Timestamp.fromMillis(AHORA - 72000000), tipo: 'Running', estado: 'completo', duracion: 3600 });
  fsm2.resetLogs();
  st2.log.removeItem.length = 0;

  const r1 = await AE2.syncAnalyticsDays('u1', {});
  eq(r1.n, 2, 'primera sync: 2 docs');
  eq(r1.streamsChanged, true, 'primera sync: sin firma guardada → invalida');
  const quita1 = st2.log.removeItem.filter((k) => k.startsWith('analyticsStreams_')).length;
  eq(quita1, 24, 'invalida las 24 claves de streams (6 períodos × 4 actividades)');
  ok(st2.get('analyticsStreamsSig_v6_u1'), 'la firma queda persistida');

  const r2 = await AE2.syncAnalyticsDays('u1', {});
  eq(r2.n, 2, 'segunda sync: los mismos 2 docs (solape de 3 días)');
  eq(r2.streamsChanged, false, 'segunda sync: SIN cambios → NO invalida');
  const quita2 = st2.log.removeItem.filter((k) => k.startsWith('analyticsStreams_')).length;
  eq(quita2, quita1, 'no se borra ninguna clave de streams adicional');

  // Un entreno NUEVO (no planificado) cambia la firma
  fsm2.seedDoc('entrenamientos/ac', { userId: 'u1', fecha: fsm2.Timestamp.fromMillis(AHORA - 60000), tipo: 'Running', estado: 'completo', duracion: 900 });
  const r3 = await AE2.syncAnalyticsDays('u1', {});
  eq(r3.n, 3, 'tercera sync: 3 docs (aparece el nuevo)');
  eq(r3.streamsChanged, true, 'con un entreno nuevo SÍ invalida');

  // Sin cambios de nuevo: no invalida
  const r4 = await AE2.syncAnalyticsDays('u1', {});
  eq(r4.streamsChanged, false, 'cuarta sync sin cambios: NO invalida');
}

console.log('\n— 6) Un entrenador NO escribe digests del atleta —');
{
  const dg = CD.calcularDigest(puntos(60, fA), 'Running', fA);
  auth.currentUser = { uid: 'coach' };
  const g = await CS.guardarDigest('u1', 'wX', dg);
  eq(g.ok, false, 'guardarDigest de un entrenador: ok false');
  eq(g.motivo, 'noPropietario', 'guardarDigest de un entrenador: motivo noPropietario');
  const b = await CS.backfill('u1', { force: true });
  eq(b.ok, false, 'backfill de un entrenador: ok false');
  eq(b.motivo, 'noPropietario', 'backfill de un entrenador: motivo noPropietario');
  const m = await CS.marcarPendiente('u1', 'wX');
  eq(m.ok, false, 'marcarPendiente de un entrenador: ok false');
  const p = await CS.procesarPendientes('u1', { max: 40 });
  eq(p.procesados, 0, 'procesarPendientes de un entrenador: 0 procesados');
  ok(!fsMock.leerDoc('analyticsCurves/u1/months/2026-08')?.acts?.wX, 'no hay escritura del entrenador en los meses');
  auth.currentUser = { uid: 'u1' };
}

console.log('\n— 7) invalidarCurvasEntreno resetea la caché en memoria de los meses —');
{
  fsMock.seedDoc('analyticsCurves/u1/months/2026-09', { v: 1, acts: {} });
  fsMock.seedDoc('analyticsCurves/u1/months/2026-10', { v: 1, acts: {} });
  fsMock.seedDoc('analyticsCurves/u1', { v: 1, backfillV: 1, primerMes: '2026-09' });
  fsMock.resetLogs();

  await CS.leerMeses('u1', new Date(2026, 8, 1).getTime());
  const lect1 = fsMock.lecturas.filter((l) => l.tipo === 'getDoc' && l.path.startsWith('analyticsCurves/u1/months')).length;
  ok(lect1 >= 2, `primera lectura: ${lect1} lecturas de meses (sept+oct…)`);

  await CS.leerMeses('u1', new Date(2026, 8, 1).getTime());
  const lect2 = fsMock.lecturas.filter((l) => l.tipo === 'getDoc' && l.path.startsWith('analyticsCurves/u1/months')).length;
  eq(lect2, lect1, 'segunda lectura: desde caché en memoria (sin nuevas lecturas)');

  AE.invalidarCurvasEntreno('u1');
  await CS.leerMeses('u1', new Date(2026, 8, 1).getTime());
  const lect3 = fsMock.lecturas.filter((l) => l.tipo === 'getDoc' && l.path.startsWith('analyticsCurves/u1/months')).length;
  eq(lect3, lect1 * 2, 'tras invalidarCurvasEntreno se vuelve a leer Firestore');
}

console.log('\n— 8) Backfill y reconciliación (4.5) —');
{
  const env3 = cargarReales({ auth: { currentUser: { uid: 'u1' } } });
  const CS3 = env3.CS;
  const fsm3 = env3.fsMock;
  const pts3 = puntos(60, fA);
  fsm3.seedDoc('entrenamientos/b1', { userId: 'u1', fecha: fsm3.Timestamp.fromMillis(fA), tipo: 'Running', estado: 'completo', duracion: 60 });
  fsm3.seedDoc('entrenamientos/b1/registros/data', { puntos: pts3 });
  fsm3.seedDoc('entrenamientos/b2', { userId: 'u1', fecha: fsm3.Timestamp.fromMillis(fA + 60000), tipo: 'Running', estado: 'completo', duracion: 60 });
  fsm3.seedDoc('entrenamientos/b2/registros/data', { puntos: pts3 });

  const b1 = await CS3.backfill('u1', { force: false });
  ok(b1.ok, 'backfill inicial ok');
  eq(b1.actas, 2, 'backfill calcula 2 digests');
  eq(b1.escritos, 1, 'las 2 actividades del mismo mes van en UNA sola escritura');
  const acts = fsm3.leerDoc('analyticsCurves/u1/months/2026-08').acts;
  ok(acts.b1 && acts.b2, 'los 2 digests están en el mes');
  eq(fsm3.leerDoc('analyticsCurves/u1').backfillV, 1, 'el meta queda con backfillV: 1');
  eq(fsm3.leerDoc('analyticsCurves/u1').primerMes, '2026-08', 'el meta guarda primerMes (para leerMeses con «todo»)');

  const b2 = await CS3.backfill('u1', { force: false });
  eq(b2.skip, 'ya', 'segundo backfill sin force: no hace nada (idempotente)');

  // Cambia el tipo de b1 → sin force no se toca; con force se reconcilia
  fsm3.seedDoc('entrenamientos/b1', { userId: 'u1', fecha: fsm3.Timestamp.fromMillis(fA), tipo: 'Ciclismo', estado: 'completo', duracion: 60 });
  await CS3.backfill('u1', { force: false });
  eq(fsm3.leerDoc('analyticsCurves/u1/months/2026-08').acts.b1.tipo, 'Running', 'sin force: el digest viejo queda (backfillV=1)');
  const b3 = await CS3.backfill('u1', { force: true });
  eq(b3.actas, 1, 'force reconcilia SOLO la actividad cambiada');
  eq(fsm3.leerDoc('analyticsCurves/u1/months/2026-08').acts.b1.tipo, 'Ciclismo', 'force: el digest se recalcula con el tipo nuevo');

  // Borrado del entreno + force: el digest huérfano se elimina del mes
  await fsm3.deleteDoc(fsm3.doc({}, 'entrenamientos', 'b2'));
  const b4 = await CS3.backfill('u1', { force: true });
  ok(b4.ok, 'backfill force tras borrado ok');
  ok(!fsm3.leerDoc('analyticsCurves/u1/months/2026-08').acts.b2, 'force elimina el digest del entreno borrado');
  ok(fsm3.leerDoc('analyticsCurves/u1/months/2026-08').acts.b1, 'el digest del entreno vivo se conserva');
}

console.log('\n— 9) Puntos de integración en las pantallas (fuente real) —');
{
  const fs = require('fs');
  const path = require('path');
  const RAIZ = path.join(__dirname, '..');
  const leer = (p) => fs.readFileSync(path.join(RAIZ, p), 'utf8');
  const srcWDM = leer('screens/WorkoutDetailModal.js');
  const srcCal = leer('screens/CalendarScreen.js');
  const srcSync = leer('services/SyncService.js');
  const srcEng = leer('services/analyticsEngine.js');

  ok(/where\('fecha', '>=', Timestamp\.fromDate\(start\)\)/.test(srcWDM) && /where\('fecha', '<=', Timestamp\.fromDate\(end\)\)/.test(srcWDM), 'A6: el modal consulta con rango de fechas');
  ok(/orderBy\('fecha', 'desc'\),[\s\S]{0,200}limit\(30\)/.test(srcWDM), 'A6: orderBy fecha desc + limit(30)');
  ok((srcWDM.match(/invalidarCurvasEnt\(/g) || []).length === 6, 'A5: la invalidación está en los 6 puntos de guardado/borrado del modal (764/847/865/868/979/992)');
  ok(/borrarSubdocumentos\(workout\.id\)/.test(srcWDM) && /borrarSubdocumentos\(p\.id\)/.test(srcWDM), 'H12: los dos borrados limpian detalles/data y registros/data');
  ok(/marcarPendiente\(u, wid\)/.test(srcWDM) && /quitarDigest\(u, wid, fms\)/.test(srcWDM), '4.6: el modal marca pendiente y quita el digest viejo');
  ok(/invalidarCurvasEntreno\(uidW\)/.test(srcCal) && /marcarPendiente\(uidW, m\.id\)/.test(srcCal), 'A5/4.6: el calendario invalida al mover la fecha');
  ok(/fit_imported_v1_/.test(srcSync), 'A7: índice local de importación FIT en SyncService');
  ok(/cargarPerfilWellness/.test(srcSync) && /perfilCargado/.test(srcSync), 'A7: carga perezosa de perfil/wellness');
  ok(/guardarDigest\(userId, docRef\.id, digest\)/.test(srcSync), '4.6: SyncService guarda el digest tras registros/data');
  ok(/export async function getStreamsStatsLegacy\(/.test(srcEng), 'legacy conservado con su nombre nuevo');
  ok(/computeStreamsStatsLegacy\(/.test(srcEng) && /const CACHE_V = 6;/.test(srcEng), 'motor: legacy interno + CACHE_V=6');
  ok(/if \(!CURVAS_DIGEST_ENABLED\)/.test(srcEng), 'el camino digest va detrás de CURVAS_DIGEST_ENABLED');
  ok(!/(if \(!force && c\) \{\s*return c\.val;\s*\}){2}/.test(srcEng), 'A2: ya no existe la doble condición de caché consecutiva');
}

console.log(`\n${pasadas} comprobaciones OK, ${fallos.length} fallos.`);
if (fallos.length) {
  fallos.forEach((f) => console.log(' - ' + f));
  process.exit(1);
}
console.log('TEST CURVAS-INVALIDACION: PASS');
}

main().catch((e) => { console.error('ERROR:', e); process.exit(1); });
