/* tests/pasos-mascara-test.js — REGRESIÓN: máscara de tiempo al escribir en
   los pasos de un entreno (misma mecánica que el tiempo de una marca
   personal: escribes números y los ":" se ponen solos).

   Campos cubiertos:
     · Duración (Tiempo) de un paso (StepEditor)          → mascaraTiempoPaso
     · Ritmo mín/máx de un paso (objetivo Ritmo)          → ídem (en Ciclismo
       el ritmo es km/h → campo libre, sin máscara)
     · Duración de la sesión (WorkoutDetailModal)         → ídem

   Uso: node tests/pasos-mascara-test.js */
'use strict';
const fs = require('fs');
const path = require('path');

let pasadas = 0;
const fallos = [];
function ok(cond, msg) {
  if (cond) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log('FALLO ' + msg); }
}
function eq(a, b, msg) {
  if (a === b) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log(`FALLO ${msg} (esperado ${JSON.stringify(b)}, obtenido ${JSON.stringify(a)})`); }
}

const RAIZ = path.join(__dirname, '..');
const leer = (p) => fs.readFileSync(path.join(RAIZ, p), 'utf8');
const src = leer('components/StepEditor.js');
const srcWdm = leer('screens/WorkoutDetailModal.js');

console.log('— 1) mascaraTiempoPaso: comportamiento real (eval del fuente) —');
{
  const i0 = src.indexOf('export function mascaraTiempoPaso');
  const i1 = src.indexOf('export function normalizeStep');
  ok(i0 > 0 && i1 > i0, 'se localiza mascaraTiempoPaso en el fuente');
  const codigo = src.slice(i0, i1).replace(/export function/g, 'function');
  const m = new Function(`${codigo}\nreturn mascaraTiempoPaso;`)();
  eq(m('4530'), '45:30', '"4530" → "45:30" (los ":" se ponen solos)');
  eq(m('12345'), '1:23:45', '"12345" → "1:23:45"');
  eq(m('430'), '4:30', '"430" → "4:30" (ritmo)');
  eq(m('123456'), '12:34:56', '"123456" → "12:34:56"');
  eq(m('45'), '45', 'con 1-2 dígitos no se toca ("45")');
  eq(m('4:3'), '4:3', 'borrar no te reescribe el campo ("4:30" → borras el 0 → "4:3")');
  eq(m('4:30'), '4:30', 'un valor ya formateado se queda igual');
  eq(m(''), '', 'vacío → vacío');
  eq(m('4:5'), '4:5', 'con 2 dígitos se respeta lo tecleado (borrar no reescribe)');
}

console.log('— 2) Campos que usan la máscara —');
ok(/const m = mascaraTiempoPaso\(t\);/.test(src) && /durTexto: m, durValor: mins/.test(src), 'Duración (Tiempo) del paso: máscara en vivo');
ok(/objMin: esCiclismo \? t : mascaraTiempoPaso\(t\)/.test(src) && /objMax: esCiclismo \? t : mascaraTiempoPaso\(t\)/.test(src), 'Ritmo mín/máx: máscara en vivo (y en Ciclismo campo libre km/h)');
ok(/esCiclismo=\{actividad === 'Ciclismo'\}/.test(src), 'StepCard recibe esCiclismo');
ok(/mascaraTiempoPaso\(t\)\)\} onBlur=/.test(srcWdm), 'Duración de la sesión (WorkoutDetailModal): misma máscara + autocompletado');
ok(/import StepEditor, \{ normalizeStep, mascaraTiempoPaso, formatTimeInput \}/.test(srcWdm), 'WorkoutDetailModal importa la máscara y el normalizador');

console.log('— 3) Autocompletado al SALIR del campo (escribir corto) —');
{
  const i0 = src.indexOf('export function formatTimeInput');
  const i1 = src.indexOf('export function mascaraTiempoPaso');
  const codigoFmt = src.slice(i0, i1).replace(/export function/g, 'function');
  const fmt = new Function(`${codigoFmt}\nreturn formatTimeInput;`)();
  eq(fmt('10'), '00:10:00', '"10" → "00:10:00" (10 minutos sin escribir todo)');
  eq(fmt('45'), '00:45:00', '"45" → "00:45:00"');
  eq(fmt('1:23'), '00:01:23', '"1:23" → "00:01:23"');
  eq(fmt('1:23:45'), '01:23:45', '"1:23:45" se queda igual');
  eq(fmt(''), null, 'vacío → null (no se toca)');

  const i2 = src.indexOf('export function normalizarRitmo');
  const i3 = src.indexOf('export function normalizeStep');
  const codigoRit = src.slice(i2, i3).replace(/export function/g, 'function');
  const rit = new Function(`${codigoRit}\nreturn normalizarRitmo;`)();
  eq(rit('10'), '10:00', 'ritmo "10" → "10:00" (10 min/km)');
  eq(rit('4:3'), '4:03', 'ritmo "4:3" → "4:03"');
  eq(rit('4:30'), '4:30', 'ritmo ya formateado se queda igual');
  eq(rit('1:2:3'), '1:02:03', 'ritmo "1:2:3" → "1:02:03"');
  eq(rit(''), '', 'vacío → vacío');
  ok(/const fmt = formatTimeInput\(raw\);/.test(src), 'Duración del paso: al salir se completa con formatTimeInput');
  ok(/normalizarRitmo\(p\.objMin/.test(src) && /normalizarRitmo\(p\.objMax/.test(src), 'Ritmos del paso: al salir se completan con normalizarRitmo');
  ok(/onBlur=\{\(\) => \{ const fmt = formatTimeInput\(durText\); if \(fmt != null\) setDurText\(fmt\); \}\}/.test(srcWdm), 'Duración de la sesión: al salir se completa solo');
  ok(/isNaN\(n\)\?null:Math\.round\(n\*60\)/.test(srcWdm), '"10" en la duración de la sesión = 10 minutos (antes eran 10 segundos)');
}

console.log('');
if (fallos.length) {
  console.log(`✗ ${fallos.length} comprobación(es) fallida(s)`);
  fallos.forEach((f) => console.log(' · ' + f));
  process.exit(1);
}
console.log(`${pasadas} comprobaciones OK`);
console.log('✅ pasos-mascara-test: TODO VERDE');
