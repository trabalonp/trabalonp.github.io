/* tests/zones-screen-test.js — REGRESIÓN de la pantalla de Zonas
   (screens/ZonesScreen.js).

   Defectos que se corrigen:
     1) Al añadir una actividad desde el menú "Actividad", la actividad NO
        aparecía en el slider de actividades con zonas propias. Causa:
        actsConZonas exigía length > 0, y como el usuario tenía las zonas
        GENÉRICAS vacías, la copia-semilla salía vacía y el chip nunca se
        pintaba. Ahora basta con que la actividad tenga un juego (aunque
        vacío) para la métrica activa.
     2) El botón "Quitar zonas de X" aparecía nada más añadir una actividad
        (recién añadida, sin guardar). Ahora solo sale para actividades cuyas
        zonas YA estaban guardadas al abrir la pantalla (o tras guardar).
     3) En Ciclismo los umbrales y las zonas de la pestaña Ritmo seguían en
        min/km. En Ciclismo las zonas de ritmo van en km/h (igual que
        services/planReal.js, WorkoutDetailModal, ActivityChart…): umbral
        "Velocidad umbral (km/h)", cálculo automático en km/h (a más %, más
        km/h) y valores mostrados con "km/h".
     4) "Calcular zonas automáticamente" dejaba a veces una zona con el
        mínimo y el máximo IGUALES (R2+/R4+/R5+ duplicaban el % de una
        vecina, o el redondeo los fundía). Ahora los % extra son propios y
        el cálculo garantiza que cada zona tenga rango.

   Uso: node tests/zones-screen-test.js */
'use strict';
const fs = require('fs');
const path = require('path');

let pasadas = 0;
const fallos = [];
function ok(cond, msg) {
  if (cond) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log('FALLO ' + msg); }
}
function eq(a, b, msg) {
  const ja = JSON.stringify(a), jb = JSON.stringify(b);
  if (ja === jb) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log(`FALLO ${msg} (esperado ${jb}, obtenido ${ja})`); }
}

const src = fs.readFileSync(path.join(__dirname, '..', 'screens', 'ZonesScreen.js'), 'utf8');

console.log('— 1) El slider incluye las actividades con zonas VACÍAS (recién añadidas) —');
ok(/const CICLISMO_OPTIONS = \['C1', 'C2', 'C3', 'C4', 'C5', 'C6'\]/.test(src), 'opciones C1..C6 para el ritmo de Ciclismo');
ok(/const actsConZonas = Object\.keys\(actividadZonas\)[\s\S]{0,200}hasOwnProperty\.call\(actividadZonas\[a\] \|\| \{\}, metricKey\)/.test(src), 'actsConZonas usa hasOwnProperty(metricKey) y NO exige length > 0 (antes la actividad nueva nunca salía en el slider)');
ok(!/\.filter\(a => \(actividadZonas\[a\]\?\[metricKey\] \|\| \[\]\)\.length > 0\)/.test(src), 'ya no queda el filtro viejo por length > 0');
ok(/\[act\]: \{ \.\.\.\(prev\[act\] \|\| \{\}\), \[metricKey\]: semilla \}/.test(src), 'agregarActividad solo escribe la métrica actual (el chip no aparece de más en otras pestañas)');

console.log('— 2) El botón "Quitar zonas de X" solo para actividades YA guardadas —');
ok(/editando && actActual && previas\[actActual\]\?\.\[metricKey\] && \(/.test(src), 'el botón Quitar se muestra solo si la métrica ya estaba guardada (previas)');
ok(/setPrevias\(metricasDeZonasActividad\(cached\.zonasActividad\)\)/.test(src) && /setPrevias\(metricasDeZonasActividad\(data\.zonasActividad\)\)/.test(src), 'previas se rellena al cargar (caché y Firestore)');
ok(/setPrevias\(metricasDeZonasActividad\(actividadZonas\)\);/.test(src), 'tras Guardar, lo que hay en pantalla pasa a contar como guardado');

console.log('— 3) Ciclismo: umbrales y zonas en km/h (no min/km) —');
ok(/const esCiclismo = actActual === 'Ciclismo'/.test(src), 'esCiclismo = actividad Ciclismo seleccionada');
ok(/const \[umbralCiclismo, setUmbralCiclismo\] = useState\(''\)/.test(src), 'umbral de velocidad propio para Ciclismo (km/h)');
ok(/setUmbralCiclismo\(cached\.umbralCiclismo \|\| ''\)/.test(src) && /setUmbralCiclismo\(data\.umbralCiclismo \|\| ''\)/.test(src), 'umbralCiclismo se carga de caché y Firestore');
ok(/umbralCiclismo,/.test(src), 'umbralCiclismo se guarda con las zonas');
ok(/label="Velocidad umbral \(km\/h\)"/.test(src), 'el campo de umbral de Ciclismo pide km/h');
ok(/label="Ritmo umbral \(R5\) min\/km"/.test(src), '…y el de las demás actividades sigue en min/km');
ok(/parseFloat\(String\(umbralCiclismo\)\.replace\(',', '\.'\)\)/.test(src), 'el cálculo automático lee la velocidad umbral como número (admite coma decimal)');
ok(/const kmh = \(porc\) => Math\.round\(u \* porc \* 10\) \/ 10/.test(src), 'el cálculo produce km/h con 1 decimal');
ok(/Introduce tu velocidad umbral en km\/h\./.test(src), 'aviso claro si falta la velocidad umbral');
ok(/tab === 'Ritmo'\) return esCiclismo \? `\$\{a\}–\$\{b\} km\/h` : `\$\{a\} – \$\{b\} \/km`/.test(src), 'la vista muestra km/h en Ciclismo y /km en el resto');
ok(/esCiclismo \? 'C' : tab === 'Ritmo' \? 'R' : 'Z'/.test(src), 'los nombres por posición de Ciclismo usan el prefijo C (C1, C2…)');
ok(/keyboardType=\{tab === 'Ritmo' \? \(esCiclismo \? 'decimal-pad' : 'default'\) : 'numeric'\}/.test(src), 'min/max de Ciclismo usan teclado decimal');
ok(/\(tab === 'Ritmo' && act === 'Ciclismo'\)[\s\S]{0,120}CICLISMO_OPTIONS\.map\(\(id\) => \(\{ id, min: '', max: '', label: id \}\)\)/.test(src), 'al añadir Ciclismo en Ritmo se siembran C1..C6 vacías (no se copian las genéricas en min/km)');
ok(/const ORDEN_RITMO = esCiclismo \? CICLISMO_OPTIONS : RITMO_OPTIONS/.test(src) && /tab === 'Ritmo' \? ORDEN_RITMO\.indexOf\(a\.id\)/.test(src), 'el menú "Agregar zona" ofrece y ordena C1..C6 en Ciclismo');
ok(/% = límite superior de la zona sobre \{tab === 'FC' \? 'la FC máxima' : tab === 'Ritmo' \? \(esCiclismo \? 'la velocidad umbral' : 'el umbral de ritmo'\) : 'el FTP'\}/.test(src), 'la ayuda de % menciona la velocidad umbral en Ciclismo');

console.log('— 4) Guardado sin el bug del error (err vs e) —');
ok(/Alert\.alert\('Error', `No se pudieron guardar las zonas\. \(\$\{err\.code \|\| err\.message\}\)`\)/.test(src), 'el mensaje de error usa err (antes e, que no existía → ReferenceError)');

console.log('— 5) metricasDeZonasActividad: comportamiento real (eval del fuente) —');
{
  const i0 = src.indexOf('function metricasDeZonasActividad');
  const i1 = src.indexOf('export default function ZonesScreen()');
  ok(i0 > 0 && i1 > i0, 'localiza metricasDeZonasActividad en el fuente');
  const fn = new Function(`${src.slice(i0, i1)}\nreturn metricasDeZonasActividad;`)();
  const m = fn({
    Running: { ritmo: [{ id: 'R1' }], fc: [], potencia: [] },
    Ciclismo: { ritmo: [] },
  });
  eq(m.Running, { fc: true, ritmo: true, potencia: true }, 'métricas presentes (aunque estén vacías) → true');
  eq(m.Ciclismo, { fc: false, ritmo: true, potencia: false }, 'solo la métrica que existe en el perfil → true');
  eq(fn(null), {}, 'zonasActividad nulo → objeto vacío (no revienta)');

  // Simulación del escenario del defecto: genéricas vacías + añadir actividad.
  // Antes: semilla = copia de genéricas vacías → length 0 → fuera del slider.
  // Ahora: la actividad entra en el slider por tener la clave, aunque esté vacía.
  const semillaGenericasVacias = [];
  const tieneClave = Object.prototype.hasOwnProperty.call({ ritmo: semillaGenericasVacias }, 'ritmo');
  ok(tieneClave, 'actividad recién añadida con genéricas vacías → tiene la clave ritmo → sale en el slider');
}

console.log('— 6) Cálculo automático: nunca min == max (guardas + % extra) —');
ok(/if \(i > 0 && minNum >= maxNum\) maxNum = Math\.round\(\(minNum \+ 0\.1\) \* 10\) \/ 10/.test(src), 'km/h: si min y max coinciden, el máximo sube 0,1 (la zona siempre tiene rango)');
ok(/if \(aSeg\(min\) <= aSeg\(max\)\)/.test(src), 'min/km: si el mínimo no es más lento que el máximo, se separa 1 segundo');
{
  const srcZonas = fs.readFileSync(path.join(__dirname, '..', 'services', 'zonas.js'), 'utf8');
  const i0 = srcZonas.indexOf('const PCT_RITMO_EXTRA');
  const codigo = srcZonas.slice(i0, srcZonas.indexOf(';', i0) + 1);
  const extra = new Function(`${codigo}\nreturn PCT_RITMO_EXTRA;`)();
  eq(extra['R2+'], 90, 'R2+ ya no duplica el 85 de R2');
  eq(extra['R4+'], 120, 'R4+ ya no duplica el 105 de R3+');
  eq(extra['R5+'], 140, 'R5+ ya no duplica el 115 de R4');
}

console.log('');
if (fallos.length) {
  console.log(`✗ ${fallos.length} comprobación(es) fallida(s)`);
  fallos.forEach((f) => console.log(' · ' + f));
  process.exit(1);
}
console.log(`${pasadas} comprobaciones OK`);
console.log('✅ zones-screen-test: TODO VERDE');
