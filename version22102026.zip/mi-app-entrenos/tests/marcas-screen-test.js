/* tests/marcas-screen-test.js — REGRESIÓN de la pantalla de Marcas
   (screens/MarcasScreen.js).

   Defectos que se corrigen:
     1) El "Gain" (Mejora) del detalle de una prueba se calculaba con la
        primera marca insertada o con "la anterior del historial". REGLA
        FINAL: se cogen las DOS MEJORES marcas de todas las registradas
        (las dos de menor tiempo; las dos de mayor valor en distancia/
        reps) y se muestra su diferencia. Sin fechas ni historiales.
     2) El formulario de añadir/editar resultado era un Modal opaco de
        Android: al abrir/cerrar el teclado asomaba el fondo blanco del
        diálogo (parpadeo). Ahora el modal es transparent y el formulario
        cubre la pantalla con el color del tema.

   Uso: node tests/marcas-screen-test.js */
'use strict';
const fs = require('fs');
const path = require('path');

let pasadas = 0;
const fallos = [];
function ok(cond, msg) {
  if (cond) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log('FALLO ' + msg); }
}
function eq(a, b, msg) {
  if (a === b) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log(`FALLO ${msg} (esperado ${JSON.stringify(b)}, obtenido ${JSON.stringify(a)})`); }
}

const src = fs.readFileSync(path.join(__dirname, '..', 'screens', 'MarcasScreen.js'), 'utf8');

console.log('— 1) Gain: las DOS MEJORES marcas y su diferencia —');
{
  const i0 = src.indexOf('const ordenados = [...vals].sort');
  ok(i0 > 0, 'se localiza el cálculo de la mejora en el fuente');
  const i1 = src.indexOf(';', src.indexOf('mejoraAbs')) + 1;
  const codigo = src.slice(i0, i1 + 1);
  const fn = new Function('vals', 'esMenorMejor', 'def', `${codigo}\nreturn mejoraAbs;`);
  const tiempo = () => true;   // menor es mejor (tiempo)
  const mayorMejor = () => false;
  const defFake = {};

  // El caso del usuario: 8:52 (532 s) y 9:04 (544 s) → 12 s de mejora
  eq(fn([544, 532], tiempo, defFake), 12, '[9:04, 8:52] → las dos mejores son 8:52 y 9:04 → gain 12 s');
  // Da igual el orden de llegada o las fechas: solo mandan los dos mejores
  eq(fn([532, 544], tiempo, defFake), 12, 'misma pareja en otro orden → 12 s');
  eq(fn([537, 544, 532], tiempo, defFake), 5, '[8:57, 9:04, 8:52] → dos mejores 8:52/8:57 → 5 s');
  eq(fn([544, 537, 532], tiempo, defFake), 5, '[9:04, 8:57, 8:52] → dos mejores 8:52/8:57 → 5 s');
  eq(fn([532], tiempo, defFake), 0, 'una sola marca → sin gain');
  eq(fn([10, 12, 14], mayorMejor, defFake), 2, 'mayor mejor (km/reps): 14 y 12 → gain 2');
  eq(fn([], tiempo, defFake), 0, 'sin marcas → sin gain');
}

console.log('— 2) Formulario: modal transparente (sin parpadeo blanco) —');
ok(/<Modal visible=\{!!form\} animationType="slide" transparent onRequestClose=\{cerrarForm\}>/.test(src), 'el formulario usa un Modal transparent (el fondo blanco del diálogo ya no asoma bajo el teclado)');
ok(/SystemUI\.setBackgroundColorAsync\(colors\.background\)/.test(fs.readFileSync(path.join(__dirname, '..', 'App.js'), 'utf8')), 'el fondo de la ventana Android sigue el color del tema');

console.log('');
if (fallos.length) {
  console.log(`✗ ${fallos.length} comprobación(es) fallida(s)`);
  fallos.forEach((f) => console.log(' · ' + f));
  process.exit(1);
}
console.log(`${pasadas} comprobaciones OK`);
console.log('✅ marcas-screen-test: TODO VERDE');
