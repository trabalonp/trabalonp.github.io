/* tests/plan-real-test.js — REGRESIÓN: comparativa DISTANCIA realizada /
   planificada en las tarjetas de HomeScreen y CalendarScreen.

   Síntoma que se corrige: en los recuadros de los entrenos el TIEMPO salía
   "1:05:30 / 1:00:00" (realizado / planificado) pero la DISTANCIA salía sola
   ("10.00 km"), sin su comparativa, porque el doc fusionado venía con
   planDist = null (fusiones antiguas sin zonas de ritmo, planes con pasos por
   "Zona ritmo", docs editados a mano…).

   Se prueba el código REAL:
     · services/planReal.js   → computePlanMetrics / resolverPlanReal / zonasRitmoDe
     · services/compliance.js → el color y la flecha con el plan resuelto
     · lib/matcher.js del servidor (computePlanMetrics, zonasRitmoDe exportada,
       y que la vía de porcentajes pase las zonas) + el pase de reparación de
       handlers/sync-intervals.js.
   Uso: node tests/plan-real-test.js */
'use strict';
const fs = require('fs');
const path = require('path');
const Module = require('module');

let fallos = 0;
const ok = (cond, msg) => {
  if (cond) console.log('ok   ' + msg);
  else { fallos++; console.log('FALLO: ' + msg); }
};

const APP = path.join(__dirname, '..');
const leer = (f) => fs.readFileSync(f, 'utf8');

/* ── Transformador ESM→CJS mínimo (los servicios usan import/export) ── */
function transformar(src) {
  const nombres = [];
  let out = src
    .replace(/^import\s+\{([^}]+?)\}\s+from\s+'([^']+)';?$/gm, (m, ids, mod) => {
      const partes = ids.split(',').map((s) => s.trim()).filter(Boolean)
        .map((s) => (s.includes(' as ') ? s.replace(/\s+as\s+/, ': ') : s));
      return `const { ${partes.join(', ')} } = require('${mod}');`;
    })
    .replace(/^import\s+(\w+)\s+from\s+'([^']+)';?$/gm, (m, id, mod) => `const ${id} = require('${mod}');`)
    .replace(/^export\s+function\s+(\w+)/gm, (m, n) => { nombres.push(n); return `function ${n}`; })
    .replace(/^export\s+const\s+(\w+)/gm, (m, n) => { nombres.push(n); return `const ${n}`; })
    .replace(/^export\s+async\s+function\s+(\w+)/gm, (m, n) => { nombres.push(n); return `async function ${n}`; });
  return out + `\nmodule.exports = { ${nombres.join(', ')} };\n`;
}

/* ── Stubs de los módulos que no son objeto de la prueba ── */
const STUBS = {
  react: { useCallback: (f) => f, useEffect: () => {}, useState: (v) => [v, () => {}] },
  'firebase/firestore': { doc: () => ({}), getDoc: async () => ({ exists: () => false, data: () => ({}) }) },
  '../firebaseConfig': { db: {}, auth: { currentUser: null } },
  './profileCache': { getCachedProfile: async () => null },
  './chartCache': { getZonasRitmo: () => null, setZonasRitmo: () => {} },
};
const REALS = ['planReal.js', 'compliance.js'];

const cache = {};
function loadReal(file) {
  if (cache[file]) return cache[file];
  const mod = new Module(file, null);
  mod.filename = file;
  mod.paths = Module._nodeModulePaths(path.dirname(file));
  cache[file] = mod.exports;
  mod._compile(transformar(fs.readFileSync(file, 'utf8')), file);
  cache[file] = mod.exports;
  return mod.exports;
}
const origLoad = Module._load;
Module._load = function (request, parent) {
  if (Object.prototype.hasOwnProperty.call(STUBS, request)) return STUBS[request];
  if (parent && parent.filename && (request.startsWith('./') || request.startsWith('../'))) {
    const res = path.resolve(path.dirname(parent.filename), request);
    const cand = res.endsWith('.js') ? res : res + '.js';
    if (REALS.some((n) => cand.endsWith(path.join('services', n))) && fs.existsSync(cand)) return loadReal(cand);
  }
  return origLoad.apply(this, arguments);
};

const { resolverPlanReal, computePlanMetrics, zonasRitmoDe } = loadReal(path.join(APP, 'services', 'planReal.js'));
const { complianceEntreno } = loadReal(path.join(APP, 'services', 'compliance.js'));

/* ── Datos de prueba ── */
// Zonas de ritmo del atleta (formato guardado en perfiles/{uid}.zonasRitmo)
const ZONAS = [
  { id: 'R1', titulo: 'R1', min: '5:30', max: '5:00' },   // medio 315 s/km
  { id: 'R2', titulo: 'R2', min: '4:40', max: '4:20' },   // medio 270 s/km
];
// Plan por ZONA de ritmo: 60 min a R2 → 3600/270 = 13.33 km (sin zonas: 0 km)
const PASOS_ZONA = [{ durTipo: 'Tiempo', durValor: 60, durUnidad: 'min', objetivo: 'Zona ritmo', objZona: 'R2' }];
// Plan por distancia: 3 × 2 km = 6 km
const PASOS_KM = [{ durTipo: 'Distancia', durValor: 2, durUnidad: 'km', repeticiones: 3 }];
// Series con ritmo manual: 6 × 5 min a 4:00-4:10 → 30 min y ~7.32 km
const PASOS_SERIE = [{
  durTipo: 'Tiempo', durValor: 5, durUnidad: 'min', repeticiones: 6,
  objetivo: 'Ritmo', objMin: '4:00', objMax: '4:10',
}];

const realizado = (over = {}) => ({
  id: 'r1', tipo: 'Running', estado: 'completo', titulo: 'Rodaje',
  distancia: 10, duracion: 3600, mergedFromPlanId: 'p1',
  planDist: null, planDur: 3600, ...over,
});

console.log('— 1) computePlanMetrics (misma lógica app ↔ servidor) —');
const mKm = computePlanMetrics(PASOS_KM, []);
ok(mKm.km === 6 && mKm.sec === 0, `pasos de distancia: 6 km (km=${mKm.km}, sec=${mKm.sec})`);
const mZona = computePlanMetrics(PASOS_ZONA, ZONAS);
ok(Math.abs(mZona.km - 3600 / 270) < 0.01 && mZona.sec === 3600, `pasos por zona de ritmo CON zonas: ${(mZona.km).toFixed(2)} km / 3600 s`);
const mZonaSin = computePlanMetrics(PASOS_ZONA, []);
ok(mZonaSin.km === 0 && mZonaSin.sec === 3600, 'pasos por zona SIN zonas: 0 km pero 3600 s (el origen del bug)');
const mSerie = computePlanMetrics(PASOS_SERIE, []);
ok(mSerie.sec === 1800 && Math.abs(mSerie.km - 1800 / 245) < 0.01, `series con ritmo manual: ${mSerie.sec} s / ${mSerie.km.toFixed(2)} km`);

console.log('— 1b) Ciclismo: zonas y objetivos de ritmo en km/h (no min/km) —');
const ZONAS_BICI = [{ id: 'C2', titulo: 'C2', min: '25', max: '28' }, { id: 'C3', titulo: 'C3', min: '28', max: '32' }];
const bici = (over = {}) => ({ durTipo: 'Tiempo', durValor: 60, durUnidad: 'min', objetivo: 'Zona ritmo', objZona: 'C3', ...over });
const mBici = computePlanMetrics([bici()], ZONAS_BICI, 'Ciclismo');
ok(mBici.sec === 3600 && Math.abs(mBici.km - 30) < 0.01, `60 min en zona C3 (28-32 km/h) → ${mBici.km.toFixed(2)} km (media armónica = 30 km/h)`);
const mBiciMal = computePlanMetrics([bici()], ZONAS_BICI);
ok(Math.abs(mBiciMal.km - 120) < 0.01, `sin el tipo se leían como min/km → ${mBiciMal.km.toFixed(0)} km imposibles (el bug que se corrige)`);
const mBiciManual = computePlanMetrics([{ durTipo: 'Tiempo', durValor: 30, durUnidad: 'min', objetivo: 'Ritmo', objMin: '30', objMax: '30' }], [], 'Ciclismo');
ok(mBiciManual.sec === 1800 && Math.abs(mBiciManual.km - 15) < 0.01, `objetivo manual 30 km/h durante 30 min → ${mBiciManual.km.toFixed(2)} km`);
const mRunMMS = computePlanMetrics([{ durTipo: 'Tiempo', durValor: 10, durUnidad: 'min', objetivo: 'Ritmo', objMin: '4:00', objMax: '4:00' }], [], 'Running');
ok(Math.abs(mRunMMS.km - 2.5) < 0.001, 'Running sigue en min/km: 10 min a 4:00/km → 2.50 km');
ok(resolverPlanReal({ id: 'b1', tipo: 'Ciclismo', estado: 'completo', distancia: 29, duracion: 3600, mergedFromPlanId: 'p2', planDist: null, planDur: 3600, pasos: [bici()] }, ZONAS_BICI).dist === 30,
  'resolverPlanReal usa w.tipo: doc de bici sin planDist → 30 km planificados');

console.log('— 2) zonasRitmoDe: específicas de la actividad antes que las genéricas —');
const perfil = { zonasRitmo: ZONAS, zonasActividad: { Ciclismo: { ritmo: [{ id: 'C1', titulo: 'C1', min: '2:00', max: '1:40' }] } } };
ok(zonasRitmoDe(perfil, 'Running') === ZONAS, 'Running sin zonas propias → las genéricas');
ok(zonasRitmoDe(perfil, 'Ciclismo').length === 1, 'Ciclismo → sus propias zonas');
ok(zonasRitmoDe(null, 'Running').length === 0, 'sin perfil → lista vacía (no revienta)');

console.log('— 3) resolverPlanReal: el bug (planDist ausente) y sus respaldos —');
const r1 = resolverPlanReal(realizado());
ok(r1.dist === null && r1.dur === 3600, 'CASO BUG: planDist null y sin pasos → solo hay tiempo (antes la distancia salía sola)');
const r2 = resolverPlanReal(realizado({ pasos: PASOS_KM }));
ok(r2.dist === 6 && r2.dur === 3600, `pasos de distancia → comparativa 10.00 km / ${r2.dist.toFixed(2)} km`);
const r3 = resolverPlanReal(realizado({ pasos: PASOS_ZONA }), ZONAS);
ok(Math.abs(r3.dist - 13.33) < 0.01 && r3.dur === 3600, `pasos por zona CON zonas → ${(r3.dist).toFixed(2)} km planificados`);
const r4 = resolverPlanReal(realizado({ pasos: PASOS_ZONA }), []);
ok(r4.dist === null && r4.dur === 3600, 'pasos por zona SIN zonas → sigue sin km (no se inventa nada)');
const r5 = resolverPlanReal(realizado({ planDist: 12.5, planDur: 3300, pasos: PASOS_KM }), ZONAS);
ok(r5.dist === 12.5 && r5.dur === 3300, 'lo que guardó el servidor manda: no lo pisa el recálculo');
const r6 = resolverPlanReal({ id: 'p9', tipo: 'Running', distancia: 15, duracion: 4500, pasos: [] });
ok(r6.dist === 15 && r6.dur === 4500, 'planificado sin pasos → su distancia/duración guardadas');
const r7 = resolverPlanReal(realizado({ distancia: 10, pasos: [] }), ZONAS);
ok(r7.dist === null, 'un realizado SIN plan de distancia nunca usa su distancia real como plan (nada de 100 % falso)');

console.log('— 4) complianceEntreno: la flecha mide contra la DISTANCIA cuando la hay —');
const c1 = complianceEntreno(realizado({ pasos: PASOS_KM }), new Date('2026-10-08T12:00:00'), resolverPlanReal(realizado({ pasos: PASOS_KM }), ZONAS));
ok(c1.kind === 'up' && Math.abs(c1.pct - (10 / 6) * 100) < 0.5, `10 km de 6 planificados → ⬆️ ${c1.pct.toFixed(0)} % (por distancia)`);
const c2 = complianceEntreno(realizado(), new Date('2026-10-08T12:00:00'));
ok(c2.kind === 'ok' && Math.abs(c2.pct - 100) < 0.01, 'sin plan de distancia → mide contra el tiempo (3600/3600 = ✅ 100 %)');
const c3 = complianceEntreno(realizado({ planDist: 12, planDur: 3600 }), new Date('2026-10-08T12:00:00'));
ok(c3.kind === 'ok' && Math.abs(c3.pct - (10 / 12) * 100) < 0.5, `planDist del doc intacto: 10/12 → ✅ ${c3.pct.toFixed(0)} % (dentro del 80-120)`);
const c3b = complianceEntreno(realizado({ planDist: 20, planDur: 3600 }), new Date('2026-10-08T12:00:00'));
ok(c3b.kind === 'down' && Math.abs(c3b.pct - 50) < 0.5, `planDist 20 km con 10 hechos → ⬇️ ${c3b.pct.toFixed(0)} %`);
const c4 = complianceEntreno({ id: 'x', tipo: 'Descanso', estado: 'completo' }, new Date('2026-10-08T12:00:00'));
ok(c4.kind === null, 'Descanso: jamás se evalúa');

let pendienteServer = false;
const resumen = () => {
  console.log('');
  if (fallos) { console.log(`✗ ${fallos} comprobación(es) fallida(s)`); process.exit(1); }
  console.log('✓ Todas las comprobaciones pasan');
};

/* ── 5) Servidor (Vercel): matcher + pase de reparación ── */
console.log('— 5) Servidor: matcher.js y la reparación de planDist —');
const rutaServer = require('./server-ruta')();
const fMatcher = path.join(rutaServer, 'lib', 'matcher.js');
const fSync = path.join(rutaServer, 'handlers', 'sync-intervals.js');
const hayServer = fs.existsSync(fMatcher) && fs.existsSync(fSync);
let matcher = null;
if (!hayServer) {
  // Sin el código del server a mano (server-extract/ o el repo hermano
  // ../mi-app-entrenos) la sección del servidor se salta: las comprobaciones
  // de la app (1-4 y 6) siguen corriendo igual.
  console.log('     ⚠ servidor no localizado (' + rutaServer + '): sección 5 saltada');
} else {
  try { matcher = require(fMatcher); } catch (e) { matcher = null; }
  if (!matcher) {
    console.log('     (no se pudo cargar lib/matcher.js: se comprueba solo el texto)');
  } else {
    ok(typeof matcher.zonasRitmoDe === 'function', 'matcher exporta zonasRitmoDe (antes NO: el pase de reparación lanzaba TypeError en silencio)');
    const zs = matcher.zonasRitmoDe(perfil, 'Ciclismo');
    ok(Array.isArray(zs) && zs.length === 1, 'zonasRitmoDe(perfil, tipo) resuelve las zonas de la actividad');
    const ms = matcher.computePlanMetrics(PASOS_KM, []);
    ok(ms.km === 6, 'computePlanMetrics del servidor = 6 km (mismas unidades que la app)');
  }
  const srcMatcher = leer(fMatcher);
  const srcSync2 = leer(fSync);
  const PASOS_BICI_SERVER = [{ durTipo: 'Tiempo', durValor: 60, durUnidad: 'min', objetivo: 'Zona ritmo', objZona: 'C3' }];
  ok(/candidatePorPct\(syncedData, planned, zonasRitmo\)/.test(srcMatcher), 'la vía de porcentajes del matcher pasa las zonas de ritmo');
  ok(/mergeWorkoutsAdmin\(admin, db, syncedDocId, syncedData, porPct\.P, zonasRitmo\)/.test(srcMatcher), 'la fusión por porcentajes guarda planDist con las zonas resueltas');
  ok(/zonasRitmoDe\(perfil, S\.tipo\)/.test(srcMatcher), 'reconcileRange usa las zonas de la actividad de cada entreno');
  ok(/zonasRitmoDe\(perfil, syncedData\.tipo\)/.test(srcMatcher), 'maybeMergeSyncedWithPlan usa las zonas de la actividad sincronizada');
  ok(/module\.exports = \{[\s\S]*zonasRitmoDe,[\s\S]*\};/.test(srcMatcher), 'zonasRitmoDe está en module.exports');
  const mBiciSrv = matcher.computePlanMetrics(PASOS_BICI_SERVER, ZONAS_BICI, 'Ciclismo');
  ok(Math.abs(mBiciSrv.km - 30) < 0.01 && mBiciSrv.sec === 3600, `servidor: 60 min en zona 28-32 km/h → ${mBiciSrv.km.toFixed(2)} km (km/h → seg/km)`);
  ok(/computePlanMetrics\(P\.pasos, zonasRitmo, P\.tipo \|\| S\.tipo\)/.test(srcMatcher), 'el matcher propaga la actividad en los 3 cálculos del plan');
  ok(/computePlanMetrics\(pasos, zonas, w\.tipo\)/.test(srcSync2), 'la reparación del server calcula con la actividad de cada doc');
}

// Fusión real de punta a punta con un Firestore simulado: el plan es un rodaje
// por TIEMPO en "Zona ritmo" (R2 = 4:40-4:20 → 270 s/km). Es el caso exacto
// del bug: sin las zonas del atleta, computePlanMetrics da 0 km y la fusión
// escribía planDur=3600 pero planDist=null → la tarjeta enseñaba el tiempo
// comparado y la distancia sola.
if (matcher && typeof matcher.maybeMergeSyncedWithPlan === 'function') {
  const admin = { firestore: { Timestamp: { fromDate: (d) => ({ __ts: d.getTime(), toDate: () => d }) } } };
  const ts = (h) => admin.firestore.Timestamp.fromDate(new Date(`2026-10-07T${h}:00:00`));
  const fusionar = async (perfil, tipo = 'Running') => {
    const docs = [{ id: 'p1', data: { userId: 'u1', tipo, titulo: tipo === 'Running' ? 'Rodaje R2' : 'Bici C3', fecha: ts('08'), pasos: tipo === 'Running' ? PASOS_ZONA : [{ durTipo: 'Tiempo', durValor: 60, durUnidad: 'min', objetivo: 'Zona ritmo', objZona: 'C3' }] } }];
    const writes = [];
    const col = {
      where() { return this; },
      get: async () => ({ forEach: (cb) => docs.forEach((d) => cb({ id: d.id, data: () => d.data })) }),
      doc: (id) => ({
        update: async (u) => writes.push({ id, u }),
        delete: async () => writes.push({ id, del: true }),
        collection: () => ({ doc: () => ({ set: async () => {}, update: async () => {} }) }),
      }),
    };
    const res = await matcher.maybeMergeSyncedWithPlan({
      admin, db: { collection: () => col }, uid: 'u1', perfil, syncedDocId: 'r1',
      syncedData: { id: 'r1', fecha: ts('08'), tipo, titulo: tipo === 'Running' ? 'Rodaje' : 'Bici', distancia: tipo === 'Running' ? 12.4 : 29.4, duracion: 3720 },
    });
    const up = (writes.find((w) => w.u && w.u.planDist !== undefined) || {}).u;
    return { res, up };
  };
  pendienteServer = true;
  (async () => {
    const sin = await fusionar({ zonasRitmo: [] });
    ok(sin.res.merged === true && sin.up.planDur === 3600 && sin.up.planDist === null,
      'reproduce el bug: sin zonas → fusión con planDur=3600 y planDist=null (distancia sin comparativa)');
    const con = await fusionar({ zonasRitmo: ZONAS });
    ok(con.res.merged === true && Math.abs(con.up.planDist - 13.33) < 0.01 && con.up.planDur === 3600,
      `corregido: con zonas → planDist=${con.up.planDist} km / planDur=${con.up.planDur} s (12.40 km / 13.33 km)`);
    const bici = await fusionar({ zonasActividad: { Ciclismo: { ritmo: ZONAS_BICI } } }, 'Ciclismo');
    ok(bici.res.merged === true && Math.abs(bici.up.planDist - 30) < 0.01,
      `servidor, bici por zonas en km/h → planDist=${bici.up.planDist} km (zonas de la actividad)`);
    resumen();
  })().catch((e) => { console.log('FALLO excepción en la fusión simulada:', e && e.message); process.exit(1); });
  const srcSync = leer(fSync);
  ok(/const \{ computePlanMetrics, zonasRitmoDe \} = require\('\.\.\/lib\/matcher'\);/.test(srcSync), 'sync-intervals importa computePlanMetrics y zonasRitmoDe');
  ok(!/if \(perfil && Array\.isArray\(perfil\.zonasRitmo\) && perfil\.zonasRitmo\.length\) \{/.test(srcSync), 'la reparación ya no se salta a los atletas sin zonas genéricas');
  ok(/hayZonas/.test(srcSync) && /zonasRitmoDe\(perfil, w\.tipo\)/.test(srcSync), 'la reparación calcula por doc con las zonas de su actividad');
  ok(/planDist\/planDur reparado en/.test(srcSync), 'la reparación sigue siendo idempotente y con log');
}

/* ── 6) Integración en las pantallas (Home / Calendario / modal) ── */
console.log('— 6) Integración en HomeScreen, CalendarScreen y el modal —');
const srcHome = leer(path.join(APP, 'screens', 'HomeScreen.js'));
ok(/import \{ resolverPlanReal, useZonasRitmoPorTipo \} from '\.\.\/services\/planReal';/.test(srcHome), 'HomeScreen importa el resolvedor de plan');
ok(/const plan=resolverPlanReal\(item, zonasRitmo\);/.test(srcHome), 'WorkoutRow resuelve el plan (no lee planDist a pelo)');
ok(/planDistTxt=esRealizado&&Number\(plan\.dist\)>0\?fmtDistance\(Number\(plan\.dist\)\):null/.test(srcHome), 'la comparativa de distancia usa el plan resuelto');
ok(/planDurTxt=esRealizado&&Number\(plan\.dur\)>0\?fmtTiempoCorto\(Number\(plan\.dur\)\):null/.test(srcHome), 'la comparativa de tiempo usa el mismo plan resuelto');
ok(/complianceEntreno\(item, new Date\(\), plan\)/.test(srcHome), 'el icono de cumplimiento recibe el plan resuelto');
ok(/<WorkoutRow key=\{e\.id\} item=\{e\} color=\{getWorkoutColor\(e\)\} zonasDe=\{zonasDe\}/.test(srcHome), 'las 3 secciones de la home pasan las zonas a las tarjetas');
ok(!/Number\(item\.planDist\)>0\?fmtDistance\(Number\(item\.planDist\)\)/.test(srcHome), 'ya no queda la lectura directa de item.planDist en la home');

const srcCal = leer(path.join(APP, 'screens', 'CalendarScreen.js'));
ok(/import \{ resolverPlanReal, useZonasRitmoPorTipo \} from '\.\.\/services\/planReal';/.test(srcCal), 'CalendarScreen importa el resolvedor de plan');
ok(/const zonasDe = useZonasRitmoPorTipo\(currentUserId\);/.test(srcCal), 'el calendario carga las zonas del atleta que se está viendo');
ok(/const plan = resolverPlanReal\(e, zonasDe\(e\.tipo\)\);/.test(srcCal), 'cada tarjeta del calendario resuelve su plan');
ok(/planDistTxt = esRealizado && Number\(plan\.dist\) > 0 \? fmtDistance\(Number\(plan\.dist\)\) : null/.test(srcCal), 'la comparativa de distancia del calendario usa el plan resuelto');
ok(/const comp = complianceEntreno\(e, new Date\(\), plan\);/.test(srcCal), 'el cumplimiento del calendario recibe el plan resuelto');
ok(/color: compDrag\.color,/.test(srcCal), 'el drag & drop lleva el color de cumplimiento (antes drag.color nacía undefined)');

const srcModal = leer(path.join(APP, 'screens', 'WorkoutDetailModal.js'));
ok(/import \{ resolverPlanReal, computePlanMetrics as metricsPlan \} from '\.\.\/services\/planReal';/.test(srcModal), 'el modal usa el módulo compartido (una sola copia de la lógica)');
ok(/const computePlanMetrics = \(pasos, zonasRitmo\) => metricsPlan\(pasos, zonasRitmo\);/.test(srcModal), 'computePlanMetrics del modal delega en services/planReal.js');
ok(!/function computePlanMetricsLegacy/.test(srcModal), 'sin duplicado muerto de la función');
ok(/const plan = resolverPlanReal\(p, ritmoZones[\s\S]{0,800}planDist: plan\.dist > 0 \? Math\.round\(plan\.dist \* 100\) \/ 100 : null/.test(srcModal), 'Traspasar a otro planificado guarda planDist con los respaldos');
ok(/if \(workout\.mergedFromPlanId\) \{[\s\S]{0,400}payload\.planDist/.test(srcModal), 'editar los pasos de un doc fusionado re-alinea planDist/planDur');
ok(/computePlanMetrics\(pasosNuevos, ritmoZones, actividad\)/.test(srcModal), 'el modal pasa la actividad (Ciclismo → km/h) al recalcular el plan');
ok(/resolverPlanReal\(p, ritmoZones, p\.tipo \|\| actividad \|\| w\.tipo\)/.test(srcModal), 'Traspasar resuelve el plan con la actividad del planificado');

// La sección 5 puede terminar en un async (la fusión simulada): el resumen se
// pinta al final de todo, haya o no servidor localizado.
if (!pendienteServer) resumen();
