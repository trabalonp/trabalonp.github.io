/* tests/libreria-edit-test.js — REGRESIÓN: editar una sesión de la librería
   y que los cambios se guarden de verdad.

   Defecto que se corrige:
     · AddWorkoutModal reseteaba su formulario con un effect dependiente de
       `initialDate`. El calendario pasaba `selectedDay ?? new Date()`: cada
       re-render del calendario (p. ej. al actualizarse la lista de entrenos
       por el listener en vivo) creaba una fecha NUEVA y el effect se volvía
       a ejecutar MIENTRAS editabas → título/pasos perdidos y libOrigenId a
       null → al darle a Guardar no se actualizaba la sesión de la librería,
       se creaba un entreno nuevo en el calendario. Los cambios "no aparecían"
       al volver a editar la sesión desde la librería.
     · Además, al guardar la edición se refleja al instante en el almacén
       local de la librería (libreriaStorePut) y LibreriaDrive re-sincroniza
       una vez con el servidor al montar.

   Uso: node tests/libreria-edit-test.js */
'use strict';
const fs = require('fs');
const path = require('path');

let pasadas = 0;
const fallos = [];
function ok(cond, msg) {
  if (cond) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log('FALLO ' + msg); }
}

const RAIZ = path.join(__dirname, '..');
const leer = (p) => fs.readFileSync(path.join(RAIZ, p), 'utf8');
const srcAdd = leer('screens/AddWorkoutModal.js');
const srcWdm = leer('screens/WorkoutDetailModal.js');
const srcCal = leer('screens/CalendarScreen.js');
const srcLib = leer('components/LibreriaDrive.js');

console.log('— 1) AddWorkoutModal: el formulario solo se resetea al ABRIR —');
ok(/const prevVisible = useRef\(false\);/.test(srcAdd), 'existe la guarda prevVisible');
ok(/if \(visible && !prevVisible\.current\) \{/.test(srcAdd), 'el reset va protegido por visible && !prevVisible.current (antes cualquier re-render lo disparaba)');
ok(/prevVisible\.current = visible;/.test(srcAdd), 'prevVisible se actualiza en cada pasada');

console.log('— 2) Calendario: initialDate estable —');
ok(/initialDate=\{selectedDay\}/.test(srcCal), 'el calendario pasa selectedDay tal cual (null estable), no selectedDay ?? new Date()');

console.log('— 3) El guardado de una sesión de librería refleja en el almacén local —');
ok(/libreriaStoreInit\(auth\.currentUser\?\.uid\)/.test(srcAdd) && /libreriaStorePut\(\{ \.\.\.\(libItemRef\.current \|\| \{\}\), \.\.\.upd \}\)/.test(srcAdd), 'AddWorkoutModal: tras updateDoc, put inmediato en el almacén local');
ok(/libreriaStoreInit\(auth\.currentUser\?\.uid\)/.test(srcWdm) && /libreriaStorePut\(\{ \.\.\.\(libItemRef\.current \|\| \{\}\), \.\.\.upd \}\)/.test(srcWdm), 'WorkoutDetailModal: tras updateDoc, put inmediato en el almacén local');
ok(/libItemRef\.current = item;/.test(srcAdd) && /libItemRef\.current = item;/.test(srcWdm), 'la sesión completa en edición queda en libItemRef (merge sin perder carpeta/usos)');

console.log('— 4) LibreriaDrive re-sincroniza con el servidor al montar —');
ok(/getDocs\(query\(collection\(db, 'libreria'\), where\('userId', '==', uid\)\)\)/.test(srcLib), 'lectura única del servidor al montar la librería');
ok(/if \(ups\.length\) await libreriaStorePut\(ups\);/.test(srcLib), 'los docs del servidor se funden en el almacén local');

console.log('— 5) Los ADJUNTOS (archivos/ejercicios) se guardan y cargan en la sesión —');
ok(/const upd = \{ tipo: actividad, titulo: titulo \|\| actividad, descripcion: descripcion \|\| '', pasos: pasosNuevos, archivos \};/.test(srcAdd), 'AddWorkoutModal: el guardado de la sesión incluye archivos (antes se perdían los ejercicios)');
ok(/const upd = \{ tipo: actividad, titulo: titulo \|\| actividad, descripcion: descripcion \|\| '', pasos: pasosNuevos, archivos \};/.test(srcWdm), 'WorkoutDetailModal: el guardado de la sesión incluye archivos');
ok(/setArchivos\(Array\.isArray\(item\.archivos\) \? item\.archivos : \[\]\);/.test(srcAdd) && /setArchivos\(Array\.isArray\(item\.archivos\) \? item\.archivos : \[\]\);/.test(srcWdm), 'al editar una sesión se cargan sus adjuntos');
ok(/pasos: pasos\.map\(normalizeStep\), archivos, timesUsed: 0/.test(srcAdd) && /pasos: pasos\.map\(normalizeStep\), archivos, timesUsed: 0/.test(srcWdm), 'las sesiones nuevas para la librería también guardan sus adjuntos');

console.log('');
if (fallos.length) {
  console.log(`✗ ${fallos.length} comprobación(es) fallida(s)`);
  fallos.forEach((f) => console.log(' · ' + f));
  process.exit(1);
}
console.log(`${pasadas} comprobaciones OK`);
console.log('✅ libreria-edit-test: TODO VERDE');
