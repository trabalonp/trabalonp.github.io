// tests/server-ruta.js — localiza el código del server para los tests, en
// este orden:
//   1) server-extract/mi-app-entrenos-main (copia dentro del repo, para CI)
//   2) ../mi-app-entrenos (el repo real del server, hermano de este repo)
//   3) la carpeta del server en Descargas (la que usa Pablo localmente;
//      desde la ronda de auditoría actual es la copia "(3)", la más nueva)
// Si no existe ninguno, devuelve la ruta local para que el test falle con un
// mensaje claro (o salte, según el test).
'use strict';
const fs = require('fs');
const path = require('path');

function rutaServer() {
  const local = path.join(__dirname, '..', 'server-extract', 'mi-app-entrenos-main');
  const hermano = path.join(__dirname, '..', '..', 'mi-app-entrenos');
  const descargas = path.join('C:\\', 'Users', 'FAMILIA', 'Downloads', 'mi-app-entrenos-main (3)', 'mi-app-entrenos-main');
  if (fs.existsSync(path.join(local, 'lib', 'firebase.js'))) return local;
  if (fs.existsSync(path.join(hermano, 'lib', 'firebase.js'))) return hermano;
  if (fs.existsSync(path.join(descargas, 'lib', 'firebase.js'))) return descargas;
  return local;
}

module.exports = rutaServer;
