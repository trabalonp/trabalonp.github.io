// tools/soften-sounds.js — suaviza los sonidos reales de WhatsApp a "burbuja":
//   · ataque en coseno alzado (quita el transitorio duro del "tic")
//   · filtro paso-bajo suave de un polo (redondea el timbre)
//   · cola con decaimiento extra (muere como una gota)
//   · volumen un pelín más bajo
// Entrada: assets/sounds/record-start.mp3 y record-stop.mp3
// Salida:  assets/sounds/record-start.wav y record-stop.wav (44,1 kHz · 16 bits · mono)
// Uso: node tools/soften-sounds.js
'use strict';
const fs = require('fs');
const path = require('path');
const { MPEGDecoder } = require(path.join(__dirname, '_sndtmp', 'node_modules', 'mpg123-decoder'));

const RATE = 44100;
const AMP = 0.85;          // volumen final
const LP_ALPHA = 0.32;     // suavidad del filtro (0..1; menor = más suave)
const ATTACK_MS = 14;      // ataque suave (coseno alzado)
const COLA_MS = 60;        // cola extra de caída suave

async function decodeMp3(file) {
  const buf = fs.readFileSync(file);
  const dec = new MPEGDecoder();
  await dec.ready;                 // espera a que el WASM esté listo
  const { channelData, samplesDecoded, sampleRate } = await dec.decode(new Uint8Array(buf));
  dec.free();
  const src = channelData[0];  // canal 0 (mono o izquierdo)
  // Resample simple (lineal) a RATE si hace falta
  if (sampleRate !== RATE) {
    const ratio = sampleRate / RATE;
    const n = Math.floor(samplesDecoded / ratio);
    const out = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const p = i * ratio;
      const i0 = Math.floor(p);
      const frac = p - i0;
      const a = src[i0] || 0;
      const b = src[i0 + 1] || a;
      out[i] = a + (b - a) * frac;
    }
    return out;
  }
  return src.slice(0, samplesDecoded);
}

function suavizar(x) {
  const n = x.length;
  const out = new Float32Array(n);
  let lp = 0;
  const attackN = Math.max(1, Math.floor((RATE * ATTACK_MS) / 1000));
  const colaN = Math.max(1, Math.floor((RATE * COLA_MS) / 1000));
  for (let i = 0; i < n; i++) {
    let v = x[i];
    // Paso-bajo de un polo
    lp += LP_ALPHA * (v - lp);
    v = lp;
    // Ataque suave (coseno alzado)
    const a = 0.5 - 0.5 * Math.cos(Math.PI * Math.min(1, i / attackN));
    // Cola: decaimiento extra en los últimos ms (muere como gota)
    let cola = 1;
    if (n - i < colaN) cola = Math.pow((n - i) / colaN, 1.8);
    out[i] = v * a * cola * AMP;
  }
  return out;
}

function peak(a) { let m = 0; for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i])); return m; }

function toWav(samples) {
  const n = samples.length;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write('RIFF', 0);
  buf.writeUInt32LE(36 + n * 2, 4);
  buf.write('WAVE', 8);
  buf.write('fmt ', 12);
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20);
  buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(RATE, 24);
  buf.writeUInt32LE(RATE * 2, 28);
  buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(16, 34);
  buf.write('data', 36);
  buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) {
    const v = Math.max(-1, Math.min(1, samples[i]));
    buf.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
  }
  return buf;
}

(async () => {
  const dir = path.join(__dirname, '..', 'assets', 'sounds');
  const start = suavizar(await decodeMp3(path.join(dir, 'record-start.mp3')));
  const stop = suavizar(await decodeMp3(path.join(dir, 'record-stop.mp3')));
  fs.writeFileSync(path.join(dir, 'record-start.wav'), toWav(start));
  fs.writeFileSync(path.join(dir, 'record-stop.wav'), toWav(stop));
  console.log('record-start.wav:', (start.length / RATE * 1000).toFixed(0) + ' ms · pico', peak(start).toFixed(2));
  console.log('record-stop.wav :', (stop.length / RATE * 1000).toFixed(0) + ' ms · pico', peak(stop).toFixed(2));
  console.log('✅ sonidos suavizados a burbuja en assets/sounds/');
})().catch((e) => { console.error('ERROR:', e.message); process.exit(1); });
