// tools/gen-record-sounds.js — genera los sonidos de grabación estilo WhatsApp.
//   · record-start.wav → una "gota" suave y redonda (inicio de grabación).
//   · record-stop.wav  → dos "gotas" descendentes (fin de grabación),
//     claramente distintas del de inicio.
// Sonido tipo "burbuja/agua": barrido de frecuencia DESCENDENTE con ataque
// en coseno alzado (sin transitorio duro), decaimiento exponencial y un
// armónico suave para redondear el timbre (nada de "xilófono").
// Salida: assets/sounds/record-start.wav y record-stop.wav (44,1 kHz · 16 bits · mono).
// Uso: node tools/gen-record-sounds.js
'use strict';
const fs = require('fs');
const path = require('path');

const RATE = 44100;

// Gota/burbuja: seno con pitch que baja (gotita de agua) + ataque suave y
// decaimiento exponencial. Devuelve un Float32Array (amplitud -1..1).
function bubble(freqIni, freqFin, durMs, amp, tauMs = 45, attackMs = 9) {
  const n = Math.floor((RATE * durMs) / 1000);
  const out = new Float32Array(n);
  const attackN = Math.max(1, Math.floor((RATE * attackMs) / 1000));
  const tau = Math.max(10, tauMs / 1000);
  let phase = 0;
  for (let i = 0; i < n; i++) {
    const t = i / RATE;
    const prog = i / n;
    // Descenso de frecuencia con curva suave (más natural que lineal)
    const f = freqFin + (freqIni - freqFin) * Math.pow(1 - prog, 1.6);
    phase += (2 * Math.PI * f) / RATE;
    const envA = 0.5 - 0.5 * Math.cos(Math.PI * Math.min(1, i / attackN));  // coseno alzado
    const envD = Math.exp(-t / tau);
    const fundamental = Math.sin(phase);
    const armonico = Math.sin(2 * phase);  // redondea el timbre
    out[i] = (fundamental + 0.22 * armonico) * amp * envA * envD;
  }
  return out;
}

function silencio(ms) {
  return new Float32Array(Math.floor((RATE * ms) / 1000));
}

function concat(...arrays) {
  const total = arrays.reduce((a, x) => a + x.length, 0);
  const out = new Float32Array(total);
  let p = 0;
  for (const a of arrays) { out.set(a, p); p += a.length; }
  return out;
}

// Evita el "clic" del corte final: fundido de salida suave.
function fadeOut(a, ms = 14) {
  const n = Math.min(a.length, Math.floor((RATE * ms) / 1000));
  for (let i = 0; i < n; i++) {
    const k = 1 - i / n;
    a[a.length - n + i] *= k * k;
  }
  return a;
}

// ¿Pico final por encima de 0.98? (clipping)
function peak(a) { let m = 0; for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i])); return m; }

function toWav(samples) {
  const n = samples.length;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write('RIFF', 0);
  buf.writeUInt32LE(36 + n * 2, 4);
  buf.write('WAVE', 8);
  buf.write('fmt ', 12);
  buf.writeUInt32LE(16, 16);          // tamaño del bloque fmt
  buf.writeUInt16LE(1, 20);           // PCM
  buf.writeUInt16LE(1, 22);           // mono
  buf.writeUInt32LE(RATE, 24);
  buf.writeUInt32LE(RATE * 2, 28);    // byte rate
  buf.writeUInt16LE(2, 32);           // block align
  buf.writeUInt16LE(16, 34);          // bits
  buf.write('data', 36);
  buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) {
    const v = Math.max(-1, Math.min(1, samples[i]));
    buf.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
  }
  return buf;
}

// ── START: una sola gotita suave y aguda (~115 ms) ──
const start = fadeOut(bubble(1250, 830, 115, 0.30, 46, 9), 18);

// ── STOP: dos gotas descendentes ("bloop-bloop" de agua) ──
const stop = concat(
  fadeOut(bubble(950, 640, 95, 0.28, 32, 8), 12),
  silencio(75),
  fadeOut(bubble(650, 400, 175, 0.30, 65, 10), 28)
);

const outDir = path.join(__dirname, '..', 'assets', 'sounds');
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'record-start.wav'), toWav(start));
fs.writeFileSync(path.join(outDir, 'record-stop.wav'), toWav(stop));

console.log('record-start.wav:', (start.length / RATE * 1000).toFixed(0) + ' ms · pico', peak(start).toFixed(2));
console.log('record-stop.wav :', (stop.length / RATE * 1000).toFixed(0) + ' ms · pico', peak(stop).toFixed(2));
console.log('✅ sonidos de grabación generados en assets/sounds/');
