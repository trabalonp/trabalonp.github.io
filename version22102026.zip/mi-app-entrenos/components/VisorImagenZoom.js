// components/VisorImagenZoom.js
// Visor de imagen a pantalla completa CON ZOOM (misma mecánica en toda la
// app: librería de archivos, adjuntos del entreno y fotos del chat).
//   · Pellizco: zoom 1x–5x anclado al punto exacto de los dedos, topado a
//     los bordes reales de la imagen (contentFit="contain").
//   · Pan con un dedo cuando hay zoom (tope en los bordes).
//   · Doble toque: 2.5x en el punto tocado / el siguiente vuelve a 1x.
//   · Varias fotos (prop `urls`): sin zoom, deslizar en horizontal pasa de
//     foto (la imagen sigue al dedo) y arrastrar hacia abajo cierra.
//   · La barra superior (nombre + contador + cerrar) se oculta al hacer zoom.
// Todo en el hilo de UI (worklets) para que el zoom sea fluido.
import React, { useMemo, useRef, useState } from 'react';
import { Dimensions, Modal, Text, TouchableOpacity, View } from 'react-native';
import { Gesture, GestureDetector, GestureHandlerRootView } from 'react-native-gesture-handler';
import Animated, { runOnJS, useAnimatedStyle, useSharedValue, withSpring, withTiming } from 'react-native-reanimated';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';

const MINZ = 1;
const MAXZ = 5;
const AnimatedImage = Animated.createAnimatedComponent(Image);

function clamp(v, lo, hi) {
  'worklet';
  return Math.min(hi, Math.max(lo, v));
}

export default function VisorImagenZoom({ visible, url, urls, initialIndex = 0, nombre, onClose, onRemove }) {
  const W = Dimensions.get('window').width;
  const H = Dimensions.get('window').height;
  const fotos = useMemo(() => (Array.isArray(urls) && urls.length ? urls : (url ? [url] : [])), [urls, url]);
  const [idx, setIdx] = useState(0);
  const idxRef = useRef(0);
  const scale = useSharedValue(1);
  const tx = useSharedValue(0);
  const ty = useSharedValue(0);
  const imgW = useSharedValue(0);      // tamaño natural de la imagen (onLoad)
  const imgH = useSharedValue(0);
  const p0s = useSharedValue(1);       // anclas del pellizco
  const p0x = useSharedValue(0);
  const p0y = useSharedValue(0);
  const p0fx = useSharedValue(0);
  const p0fy = useSharedValue(0);
  const p0e = useSharedValue(1);
  const pfx = useSharedValue(0);
  const pfy = useSharedValue(0);
  const pinchMuted = useSharedValue(false);
  const s0x = useSharedValue(0);       // anclas del pan
  const s0y = useSharedValue(0);
  const [showTop, setShowTop] = useState(true);

  const bounds = (s) => {
    'worklet';
    let dw = W;
    let dh = H;
    if (imgW.value > 0 && imgH.value > 0) {
      const fit = Math.min(W / imgW.value, H / imgH.value);
      dw = imgW.value * fit;
      dh = imgH.value * fit;
    }
    return {
      maxX: Math.max(0, (dw * s - W) / 2),
      maxY: Math.max(0, (dh * s - H) / 2),
    };
  };
  const resetZoom = () => {
    'worklet';
    const cfg = { damping: 17, stiffness: 170 };
    scale.value = withSpring(1, cfg);
    tx.value = withSpring(0, cfg);
    ty.value = withSpring(0, cfg);
  };
  const snapToBounds = () => {
    'worklet';
    const b = bounds(scale.value);
    tx.value = withTiming(clamp(tx.value, -b.maxX, b.maxX), { duration: 160 });
    ty.value = withTiming(clamp(ty.value, -b.maxY, b.maxY), { duration: 160 });
  };
  const springHome = () => {
    'worklet';
    const cfg = { damping: 18, stiffness: 200 };
    tx.value = withSpring(0, cfg);
    ty.value = withSpring(0, cfg);
  };
  const goIdx = (n) => {
    if (n < 0 || n >= fotos.length || n === idxRef.current) return;
    scale.value = 1; tx.value = 0; ty.value = 0;
    imgW.value = 0; imgH.value = 0;
    idxRef.current = n;
    setIdx(n);
  };

  // Pellizco con foco anclado: t = f − (f₀ − t₀)·ratio. El "salto al soltar"
  // se evita enmudeciendo el gesto en cuanto queda un solo dedo.
  const pinch = Gesture.Pinch()
    .onBegin(() => { pinchMuted.value = false; })
    .onTouchesUp((e) => { if (e.numberOfTouches <= 1) pinchMuted.value = true; })
    .onStart((e) => {
      pinchMuted.value = false;
      p0s.value = Math.max(0.01, scale.value);
      p0x.value = tx.value;
      p0y.value = ty.value;
      p0e.value = e.scale > 0 ? e.scale : 1;
      p0fx.value = e.focalX - W / 2;
      p0fy.value = e.focalY - H / 2;
      pfx.value = p0fx.value;
      pfy.value = p0fy.value;
    })
    .onUpdate((e) => {
      if (pinchMuted.value) return;
      const fx = e.focalX - W / 2;
      const fy = e.focalY - H / 2;
      // Foco no puede teletransportarse entre frames (>150px = artefacto)
      const jx = fx - pfx.value;
      const jy = fy - pfy.value;
      if (jx * jx + jy * jy > 22500) { pinchMuted.value = true; return; }
      pfx.value = fx;
      pfy.value = fy;
      const s0 = p0s.value;
      if (s0 <= 0) return;
      const next = clamp(s0 * (e.scale / p0e.value), MINZ, MAXZ);
      const ratio = next / s0;
      scale.value = next;
      const b = bounds(next);
      tx.value = clamp(fx - (p0fx.value - p0x.value) * ratio, -b.maxX, b.maxX);
      ty.value = clamp(fy - (p0fy.value - p0y.value) * ratio, -b.maxY, b.maxY);
      if (next > 1.02) runOnJS(setShowTop)(false);
    })
    .onEnd(() => {
      if (scale.value <= 1.02) { resetZoom(); runOnJS(setShowTop)(true); }
      else snapToBounds();
    });

  const pan = Gesture.Pan()
    .maxPointers(1)
    .minDistance(6)
    .onStart(() => { s0x.value = tx.value; s0y.value = ty.value; })
    .onUpdate((e) => {
      if (scale.value > 1.02) {
        const b = bounds(scale.value);
        tx.value = clamp(s0x.value + e.translationX, -b.maxX, b.maxX);
        ty.value = clamp(s0y.value + e.translationY, -b.maxY, b.maxY);
      } else if (fotos.length > 1) {
        // Sin zoom: la foto sigue al dedo para el swipe lateral
        tx.value = e.translationX;
        ty.value = e.translationY > 0 ? e.translationY : e.translationY * 0.3;
      }
    })
    .onEnd((e, success) => {
      if (!success) return;
      if (scale.value > 1.02) { snapToBounds(); return; }
      const dx = e.translationX;
      const dy = e.translationY;
      if (dy > 110 || e.velocityY > 900) { runOnJS(onClose)(); return; }
      if (fotos.length > 1 && Math.abs(dx) > Math.abs(dy)
          && (Math.abs(dx) > W * 0.28 || Math.abs(e.velocityX) > 650)) {
        runOnJS(goIdx)(idxRef.current + (dx < 0 ? 1 : -1));
        return;
      }
      springHome();
    });

  const doubleTap = Gesture.Tap()
    .numberOfTaps(2)
    .maxDuration(250)
    .maxDelay(250)
    .onEnd((e) => {
      if (scale.value > 1.02) { resetZoom(); runOnJS(setShowTop)(true); return; }
      const s0 = Math.max(0.01, scale.value);
      const next = 2.5;
      const ratio = next / s0;
      const ex = e.x - W / 2;
      const ey = e.y - H / 2;
      const b = bounds(next);
      scale.value = withTiming(next, { duration: 220 });
      tx.value = withTiming(clamp(ex - (ex - tx.value) * ratio, -b.maxX, b.maxX), { duration: 220 });
      ty.value = withTiming(clamp(ey - (ey - ty.value) * ratio, -b.maxY, b.maxY), { duration: 220 });
      runOnJS(setShowTop)(false);
    });

  const composed = Gesture.Simultaneous(pinch, pan, doubleTap);

  const imgStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: tx.value }, { translateY: ty.value }, { scale: scale.value }],
  }));

  if (!visible || fotos.length === 0) return null;
  const uri = fotos[Math.min(Math.max(idx, 0), fotos.length - 1)];
  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose}>
      <GestureHandlerRootView style={{ flex: 1, backgroundColor: 'rgba(4,10,20,0.97)' }}>
        <GestureDetector gesture={composed}>
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <AnimatedImage
              source={{ uri }}
              style={[{ width: W, height: H }, imgStyle]}
              contentFit="contain"
              onLoad={(e) => {
                imgW.value = (e && e.source && e.source.width) || 0;
                imgH.value = (e && e.source && e.source.height) || 0;
              }}
            />
          </View>
        </GestureDetector>
        {showTop && (
          <View style={{ position: 'absolute', top: 46, left: 14, right: 12, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <Text style={{ color: '#E8EDF5', flex: 1, fontSize: 14, fontWeight: '700' }} numberOfLines={1}>
              {nombre || ''}{fotos.length > 1 ? ` · ${Math.min(Math.max(idx, 0), fotos.length - 1) + 1}/${fotos.length}` : ''}
            </Text>
            {onRemove && (
              <TouchableOpacity onPress={onRemove} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }} style={{ backgroundColor: '#E05252CC', borderRadius: 18, padding: 6 }}>
                <Ionicons name="trash-outline" size={22} color="#fff" />
              </TouchableOpacity>
            )}
            <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }} style={{ backgroundColor: '#00000088', borderRadius: 18, padding: 6 }}>
              <Ionicons name="close-circle" size={30} color="#8FA8C8" />
            </TouchableOpacity>
          </View>
        )}
      </GestureHandlerRootView>
    </Modal>
  );
}
