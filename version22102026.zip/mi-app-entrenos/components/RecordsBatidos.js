// components/RecordsBatidos.js
// Tarjeta dorada para el detalle de un entreno: muestra las marcas personales
// que se batieron EN ESTE ENTRENO (prueba, marca, marca anterior y cuánto se
// mejoró). Datos: perfiles/<uid>.marcasBest (la mantiene el servidor con el
// workoutId de origen) + marcasDefs/marcasResults para el nombre de la prueba y
// la marca anterior. Sin datos → no se pinta nada.
// (Misma lógica y mismas props que antes: solo cambia el diseño.)
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Animated, Easing, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const GOLD = '#FFD166';
const GREEN = '#2DB37A';

function esTiempo(def) { return !!def && (def.tipo === 'dist' || def.unidadTipo === 'duracion'); }

function segATiempo(seg) {
  const total = Math.round(Number(seg) || 0);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const ss = total % 60;
  const p2 = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${p2(m)}:${p2(ss)}` : `${m}:${p2(ss)}`;
}

function fmtValor(def, valor) {
  const v = Number(valor);
  if (!Number.isFinite(v)) return '—';
  if (esTiempo(def)) return segATiempo(v);
  if (def.unidadTipo === 'peso') return `${v.toFixed(1)} kg`;
  if (def.unidadTipo === 'reps') return `${Math.round(v)}`;
  return `${v.toFixed(2)} km`;
}

// Cuánto se mejoró, en la unidad de la prueba
function fmtMejora(def, m) {
  if (esTiempo(def)) return m < 60 ? `${Math.round(m)} s` : segATiempo(m);
  if (def.unidadTipo === 'peso') return `${Number(m.toFixed(1))} kg`;
  if (def.unidadTipo === 'reps') return `${Math.round(m)}`;
  return `${m.toFixed(2)} km`;
}

function fechaDe(r) {
  try {
    if (!r || r.fecha == null) return null;
    const f = typeof r.fecha.toDate === 'function' ? r.fecha.toDate() : new Date(r.fecha);
    return isNaN(f.getTime()) ? null : f;
  } catch (e) { return null; }
}

/* ───────────── animaciones (ligeras) ───────────── */
function FadeIn({ delay = 0, children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, { toValue: 1, duration: 380, delay, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [v, delay]);
  return (
    <Animated.View style={[style, { opacity: v, transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [10, 0] }) }] }]}>
      {children}
    </Animated.View>
  );
}

// Reloj lineal 0→1 en bucle (un único bucle sin pausas)
function useReloj(duration) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.timing(v, { toValue: 1, duration, easing: Easing.linear, useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [v, duration]);
  return v;
}

// Onda suave periódica para el parpadeo de las estrellas
function onda(phi, a, b, n = 16) {
  const inR = [], outR = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    inR.push(t);
    outR.push(a + ((Math.sin(2 * Math.PI * (t + phi)) + 1) / 2) * (b - a));
  }
  return { inputRange: inR, outputRange: outR };
}

// Destello diagonal que cruza la cabecera y descansa un rato
function Destello({ ancho }) {
  const v = useReloj(4200);
  if (!ancho) return null;
  return (
    <Animated.View
      pointerEvents="none"
      style={{
        position: 'absolute', top: -20, height: 120, width: 34, backgroundColor: 'rgba(255,255,255,0.22)',
        transform: [
          { translateX: v.interpolate({ inputRange: [0, 0.3, 1], outputRange: [-80, ancho + 80, ancho + 80] }) },
          { rotate: '20deg' },
        ],
      }}
    />
  );
}

// Estrellita que titila
function Chispa({ x, y, fase, tam = 11 }) {
  const v = useReloj(2600);
  return (
    <Animated.View pointerEvents="none" style={{ position: 'absolute', left: x, top: y, opacity: v.interpolate(onda(fase, 0.2, 1)) }}>
      <Ionicons name="sparkles" size={tam} color={GOLD} />
    </Animated.View>
  );
}

// Trofeo que flota suavemente
function TrofeoFlota() {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(v, { toValue: 1, duration: 1700, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration: 1700, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [v]);
  return (
    <Animated.View style={{ transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [2.5, -2.5] }) }] }}>
      <Ionicons name="trophy" size={26} color={GOLD} />
    </Animated.View>
  );
}

/* ───────────── una fila por récord ───────────── */
function FilaRecord({ b, idx, ultimo, texto, tenue, borde, L }) {
  const esT = esTiempo(b.def);
  const mejora = b.prev != null ? (esT ? b.prev - b.valor : b.valor - b.prev) : null;
  return (
    <FadeIn delay={260 + idx * 110}>
      <View style={[st.fila, !ultimo && { borderBottomWidth: 1, borderBottomColor: borde }]}>
        <View style={st.medalla}>
          <Ionicons name="medal" size={18} color={GOLD} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[st.prueba, { color: texto }]} numberOfLines={1}>{b.def.titulo || b.defId}</Text>
          {b.prev != null && (
            <Text style={[st.antes, { color: tenue }]} numberOfLines={1}>
              {L('Antes', 'Before')}: {fmtValor(b.def, b.prev)}
            </Text>
          )}
        </View>
        <View style={{ alignItems: 'flex-end', gap: 4 }}>
          <Text style={st.valor}>{fmtValor(b.def, b.valor)}</Text>
          {mejora != null && mejora > 0 && (
            <View style={st.chipMejora}>
              <Ionicons name={esT ? 'arrow-down' : 'arrow-up'} size={11} color={GREEN} />
              <Text style={st.chipMejoraTxt}>{fmtMejora(b.def, mejora)}</Text>
            </View>
          )}
          {b.prev == null && (
            <View style={st.chipNueva}>
              <Ionicons name="sparkles" size={11} color={GOLD} />
              <Text style={st.chipNuevaTxt}>{L('Primera marca', 'First record')}</Text>
            </View>
          )}
        </View>
      </View>
    </FadeIn>
  );
}

export default function RecordsBatidos({ workoutId, defs = [], results = {}, bests = {}, theme = {}, L = (es, en) => es }) {
  const batidos = useMemo(() => {
    if (!workoutId || !bests || typeof bests !== 'object') return [];
    const defsArr = Array.isArray(defs) ? defs : [];
    const out = [];
    Object.keys(bests).forEach((defId) => {
      const b = bests[defId];
      if (!b || String(b.workoutId) !== String(workoutId)) return;
      const def = defsArr.find((d) => d.id === defId) || { id: defId, titulo: defId };
      const esT = esTiempo(def);
      const listaRaw = results[defId];
      const lista = Array.isArray(listaRaw) ? listaRaw : Object.values(listaRaw || {});

      // Valor a mostrar: el resultado registrado DE ESTE ENTRENO si existe;
      // si no, el mejor de TODOS los resultados (lo que muestra Marcas
      // personales). El valor extrapolado de marcasBest NO se usa (daba el
      // "4:23" en vez del 4:38 real).
      const delEntreno = lista
        .filter((r) => r && r.workoutId != null && String(r.workoutId) === String(workoutId))
        .map((r) => Number(r.valor)).filter(Number.isFinite);
      const todos = lista.map((r) => Number(r && r.valor)).filter(Number.isFinite);
      let valor;
      if (delEntreno.length) valor = esT ? Math.min(...delEntreno) : Math.max(...delEntreno);
      else if (todos.length) valor = esT ? Math.min(...todos) : Math.max(...todos);
      else valor = Number(b.valor);
      if (!Number.isFinite(valor)) return;

      // Marca ANTERIOR: la mejor con fecha ANTERIOR a este récord
      const fRecord = b.fecha ? fechaDe({ fecha: b.fecha }) : null;
      let prev = null;
      lista.forEach((r) => {
        const v = Number(r && r.valor);
        if (!Number.isFinite(v) || v === valor) return;
        const rf = fechaDe(r);
        if (fRecord && rf && !(rf.getTime() < fRecord.getTime())) return;
        if (prev == null) { prev = v; return; }
        if (esT) { if (v < prev) prev = v; } else if (v > prev) { prev = v; }
      });

      out.push({ defId, def, valor, prev });
    });
    return out;
  }, [workoutId, defs, results, bests]);

  const [anchoCab, setAnchoCab] = useState(0);
  const pop = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.spring(pop, { toValue: 1, useNativeDriver: true, speed: 14, bounciness: 9 }).start();
  }, [pop]);

  if (!batidos.length) return null;

  const texto = theme.text || '#fff';
  const tenue = theme.muted || '#8FA8C8';
  const borde = theme.border || '#1E3048';
  const fondo = theme.card || '#162032';

  return (
    <Animated.View
      style={[
        st.tarjeta,
        {
          backgroundColor: fondo,
          opacity: pop,
          transform: [
            { translateY: pop.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) },
            { scale: pop.interpolate({ inputRange: [0, 1], outputRange: [0.96, 1] }) },
          ],
        },
      ]}
    >
      {/* Cabecera dorada con trofeo flotante, chispas y un destello que la cruza */}
      <View style={st.cabecera} onLayout={(e) => setAnchoCab(e.nativeEvent.layout.width)}>
        <Destello ancho={anchoCab} />
        <View style={st.trofeoWrap}>
          <TrofeoFlota />
        </View>
        <Chispa x={62} y={7} fase={0.1} />
        <Chispa x={22} y={34} fase={0.5} tam={9} />
        <Chispa x={76} y={36} fase={0.8} tam={8} />
        <View style={{ flex: 1 }}>
          <Text style={st.titulo}>
            {batidos.length === 1 ? L('¡Récord batido!', 'Record broken!') : L('¡Récords batidos!', 'Records broken!')}
          </Text>
          <Text style={[st.sub, { color: tenue }]}>{L('en este entreno', 'in this workout')}</Text>
        </View>
        {batidos.length > 1 && (
          <View style={st.contador}>
            <Text style={st.contadorTxt}>{batidos.length}</Text>
          </View>
        )}
      </View>

      <View style={st.cuerpo}>
        {batidos.map((b, i) => (
          <FilaRecord key={b.defId} b={b} idx={i} ultimo={i === batidos.length - 1} texto={texto} tenue={tenue} borde={borde} L={L} />
        ))}
      </View>
    </Animated.View>
  );
}

const st = StyleSheet.create({
  tarjeta: { marginTop: 10, borderRadius: 20, borderWidth: 1.5, borderColor: GOLD + '99', overflow: 'hidden' },
  cabecera: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 14, paddingVertical: 14, backgroundColor: GOLD + '1F', overflow: 'hidden' },
  trofeoWrap: { width: 48, height: 48, borderRadius: 24, backgroundColor: GOLD + '2E', borderWidth: 1.5, borderColor: GOLD + '88', alignItems: 'center', justifyContent: 'center' },
  titulo: { color: GOLD, fontWeight: '800', fontSize: 17 },
  sub: { fontSize: 12, marginTop: 1 },
  contador: { minWidth: 28, height: 28, borderRadius: 14, paddingHorizontal: 8, backgroundColor: GOLD, alignItems: 'center', justifyContent: 'center' },
  contadorTxt: { color: '#3A2A00', fontWeight: '800', fontSize: 14 },
  cuerpo: { paddingHorizontal: 14, paddingVertical: 4 },
  fila: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12 },
  medalla: { width: 36, height: 36, borderRadius: 18, backgroundColor: GOLD + '22', alignItems: 'center', justifyContent: 'center' },
  prueba: { fontSize: 15, fontWeight: '700' },
  antes: { fontSize: 12, marginTop: 2 },
  valor: { color: GOLD, fontSize: 20, fontWeight: '800', fontVariant: ['tabular-nums'] },
  chipMejora: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 999, backgroundColor: GREEN + '22' },
  chipMejoraTxt: { color: GREEN, fontSize: 11, fontWeight: '800' },
  chipNueva: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 999, backgroundColor: GOLD + '22' },
  chipNuevaTxt: { color: GOLD, fontSize: 11, fontWeight: '800' },
});
