# Inventario de lecturas y escrituras de Firestore desde el cliente

> Auditoría de seguridad — ítem B1. Fecha del análisis: 2026-10-21.
> Alcance: TODAS las llamadas a Firestore desde el cliente (`screens/`, `services/`, `components/` y `App.js`).
> Método: grep de `setDoc|addDoc|updateDoc|deleteDoc|writeBatch|getDoc|getDocs|onSnapshot` + lectura de cada archivo citado.
> Todas las rutas y líneas citadas son reales y verificadas en el código actual.

## 0. Resumen de colecciones tocadas por el cliente

| Colección / subcolección | Escrituras | Lecturas | Escucha (onSnapshot) |
|---|---|---|---|
| `perfiles` | ✅ | ✅ | ✅ (doc del usuario / del atleta en contexto) |
| `perfiles/{uid}/notificaciones` | ✅ | ✅ | ✅ (contador no leídas) |
| `entrenamientos` | ✅ | ✅ | ❌ (solo getDocs/getDoc puntuales) |
| `entrenamientos/{id}/detalles/data` | ✅ | ✅ | ❌ |
| `entrenamientos/{id}/registros/data` | ✅ | ✅ | ❌ |
| `libreria` | ✅ | ✅ | ✅ (filtro `userId ==`) |
| `archivosLib` | ✅ | ✅ | ✅ (filtro `userId ==`) |
| `posts` | ✅ | ✅ | ✅ (3 listeners + listeners por doc) |
| `retos` | ✅ | ✅ | ❌ (solo getDocs) |
| `avatares` | ✅ | ✅ | ❌ |
| `wellness` | ❌ (solo lectura) | ✅ | ❌ |
| `fitness` | ❌ (solo lectura) | ✅ | ✅ (doc `fitness/{uid}`) |
| `analysis` | ✅ | ✅ | ❌ |
| `soporte` | ✅ | ❌ | ❌ |
| `intervals_connections` | ❌ | ✅ (una sola lectura) | ❌ |
| `ia_keys` | ❌ NO usada | ❌ | ❌ |
| `ia_feedback` | ❌ NO usada | ❌ | ❌ |
| `solicitudes` (colección) | ❌ NO usada | ❌ | ❌ |

---

## 1. `perfiles` (documentos por uid)

### Escrituras

| Operación | Quién escribe | Campos exactos | Fichero:línea |
|---|---|---|---|
| `setDoc(..., {merge:true})` | Propietario (uid propio) | `nombre, apellido, sexo, fechaNac, altura, unidadAltura, peso, unidadPeso, pais, ciudad, dni, telefono, email, foto` (base64; `foto` solo si se eligió) | `screens/ProfileScreen.js:648-653` |
| `deleteDoc` | Propietario (borrar cuenta) | — | `screens/ProfileScreen.js:707` |
| `setDoc(..., {merge:true})` | Propietario | `notificacionesActivadas` | `screens/SettingsScreen.js:298` |
| `setDoc(..., {merge:true})` | Propietario | `language` | `services/appSettings.js:30`, también `App.js:261` |
| `setDoc(..., {merge:true})` | Propietario | `expoPushToken` (token Expo del dispositivo) | `App.js:408` |
| `setDoc(..., {merge:true})` | **Entrenador sobre el perfil del atleta** (`currentUserId = athleteId \|\| user.uid`; sin verificación cliente de la relación) | `zonasFC, zonasRitmo, zonasPotencia, zonasActividad, umbralRitmo, umbralCiclismo, umbralFC, fcUmbral, fcReposo, umbralPotencia` | `screens/ZonesScreen.js:455-467` (athleteId en `:389-391`) |
| `setDoc(..., {merge:true})` | **Entrenador sobre el perfil del atleta** (ídem) | `marcasDefs, marcasResults, marcasMetrics` | `screens/MarcasScreen.js:608-610` (athleteId en `:560-561`) |
| `setDoc(..., {merge:true})` | **Cualquier usuario** (fallback de borrado de evento en Intervals.icu) | `pendingDeletes: arrayUnion(eid)` sobre el perfil del DUEÑO del entreno (`w.userId \|\| uid propio`) | `screens/WorkoutDetailModal.js:189` |

### Lecturas

- `getDoc(doc(db,'perfiles',uid))` con uid **arbitrario** (no solo el propio):
  - `screens/HomeScreen.js:355` (refresh propio o del atleta en contexto)
  - `screens/WorkoutDetailModal.js:549` (perfiles de los `asignados` de un evento), `:594-595` (zonas/marcas del dueño), `:888` (perfil propio para detectar entrenador), `:1050` (perfil al marcar asignado)
  - `services/coachNotify.js:49` (nombre del coach), `services/planReal.js:257`, `services/SyncService.js:35,806`, `services/avatarCache.js:253,292,342`
  - `components/StepEditor.js:385`, `components/WeeklyKmChart.js:112`, `components/PasosResumen.js:245`
  - `screens/ProfileScreen.js:565`, `screens/SettingsScreen.js:250,263`, `screens/MarcasScreen.js:598`, `screens/ZonesScreen.js:432`, `screens/CalendarScreen.js:528` (solo `fechaNac` para el cumpleaños), `screens/AnalysisScreen.js:273`
- `onSnapshot(doc(db,'perfiles',uid))` en vivo sobre `currentUserId` (el propio o **el atleta seleccionado por el entrenador**): `screens/HomeScreen.js:325-341`
- Queries de relación entrenador→atleta (lectura de perfiles ajenos):
  - `query(perfiles, where('entrenador','==',me.uid))` → `screens/SocialScreen.js:920, 932, 2889`

### Riesgo abierto (punto 5 del encargo)

**SÍ.** `perfiles` contiene `expoPushToken` (`App.js:408`) y datos personales: `dni`, `telefono`, `email`, `fechaNac`, `sexo`, `foto` (base64), `nombre`, `apellido`, `pais`, `ciudad`, `peso`, `altura` (`screens/ProfileScreen.js:648-653`). El patrón de acceso es `doc(db,'perfiles',<cualquier uid>)` sin ninguna verificación cliente de relación; cualquier usuario autenticado que pueda leer la colección puede leer el token push y los datos personales de cualquier otro usuario (además, `foto` base64 se descarga como respaldo en `services/avatarCache.js:292-300`). Las reglas deben cerrar esto (ver Conclusiones).

---

## 2. `perfiles/{uid}/notificaciones` (subcolección)

| Operación | Quién | Campos | Fichero:línea |
|---|---|---|---|
| `addDoc` | **Receptor** de un push de solicitud de entrenamiento (uid propio; se guarda el historial localmente) | `titulo, cuerpo, kind:'solicitud', data, leido:false, createdAt:serverTimestamp()` | `App.js:182-189` |
| `updateDoc` | Propietario | `leido: true` | `screens/NotificacionesScreen.js:134` |
| `writeBatch().update` | Propietario (marcar todas) | `leido: true` (tope 300 por pulsación) | `screens/NotificacionesScreen.js:175-179` |
| `writeBatch().delete` | Propietario (borrar todo el historial, lotes de 450) | — | `screens/AppSettingsScreen.js:277-283` |
| `deleteDoc` | Propietario | — | `screens/NotificacionesScreen.js:209` |

Lecturas:
- `getDocs` paginado `orderBy('createdAt','desc')` + `startAfter` + `limit(10)`: `screens/NotificacionesScreen.js:100-105`
- `getDocs where('leido','==',false) limit(300)`: `screens/NotificacionesScreen.js:175-176`
- `onSnapshot` contador de no leídas (`where('leido','==',false), limit(100)`): `screens/HomeScreen.js:299-300`

> Nota: las notificaciones de "entreno creado/movido/comentario/reto" NO las escribe el cliente; el push lo envía el servidor (`services/coachNotify.js:14-44` hace `fetch POST /notify-athlete`). El cliente solo guarda en esta subcolección el historial de solicitudes de coach (`App.js:182`).

---

## 3. `entrenamientos`

### Escrituras

| Operación | Quién escribe | Campos exactos | Fichero:línea |
|---|---|---|---|
| `addDoc` (crear entreno nuevo) | **Propietario** o **entrenador sobre el calendario del atleta**: `userId = athleteId \|\| uid propio`, `creadoPor = uid del que toca`. Se usa la **auth propia del entrenador**. | `userId, creadoPor, tipo, titulo, fecha (Timestamp), fechaStr, descripcion, archivos, pasos, estado:null, garminSynced:false, createdAt` (+ `asignados:[athleteId]` si es Evento) | `screens/AddWorkoutModal.js:321-348` |
| `addDoc` (reasignar fusión: resucitar planificado) | Usuario con permiso de edición | `userId, creadoPor, fecha, tipo, titulo, descripcion, pasos, estado:null, createdAt` | `screens/WorkoutDetailModal.js:961-971` |
| `addDoc` (separar fusión: nuevo planificado) | Usuario con permiso de edición | `userId, creadoPor, fecha, tipo, titulo, descripcion, pasos, estado:null, splitFromId, createdAt` | `screens/WorkoutDetailModal.js:1010-1023` |
| `addDoc` (importación manual de .fit) | Propietario | `userId, id_archivo, fecha, tipo, titulo, distancia, duracion, 'fc-media', estado:'completo', elevacion, desnivelPos, desnivelNeg, potenciaMedia, cadencia, esfuerzo, esfuerzoFuente` | `services/SyncService.js:53-71` |
| `updateDoc` (guardar datos de sesión) | Quien puede editar (ver :209-225) | `estado, duracion, duracionManual, distancia, 'fc-media', esfuerzo, esfuerzoManual, esfuerzoFuente, sensacion, cargaPercibida` | `screens/WorkoutDetailModal.js:764` |
| `updateDoc` (editar programado) | Quien puede editar | `tipo, titulo, descripcion, archivos, pasos, fecha` (+ `asignados` si es Evento; + `planDist, planDur` si venía fusionado) | `screens/WorkoutDetailModal.js:837-847` |
| `updateDoc` (toggle completado/incompleto) | Quien puede editar | `estado` | `screens/WorkoutDetailModal.js:868` |
| `updateDoc` (marcar tiene comentarios) | Quien comenta | `tieneComentarios: true` | `screens/WorkoutDetailModal.js:875` |
| `updateDoc` (reasignar a planificado) | Quien puede editar | `titulo, descripcion, pasos, tipo, mergedFromPlanId, planTitulo, planFecha, planDist, planDur, planMatchChecked` | `screens/WorkoutDetailModal.js:979-990` |
| `updateDoc` (separar fusión) | Quien puede editar | `titulo, descripcion, pasos` + `deleteField()` de `mergedFromPlanId, planTitulo, planFecha, planDist, planDur` | `screens/WorkoutDetailModal.js:1024-1033` |
| `updateDoc` (persistir pasos de fuerza) | Quien puede editar / dueño / apuntado | `pasos` (nunca lista vacía) | `screens/WorkoutDetailModal.js:1306` |
| `updateDoc` (completar con cronómetro) | Quien ejecuta el entreno | `estado:'completo'` (+ `duracion` si hay tiempo) | `components/PasosResumen.js:458-461` |
| `updateDoc` (drag & drop en calendario) | Quien puede mover (incl. **entrenador sobre entreno del atleta**) | `fecha (Timestamp), fechaStr` | `screens/CalendarScreen.js:771` |
| `updateDoc` (recalcular esfuerzos en bloque) | Propietario | `esfuerzo, esfuerzoFuente` | `services/SyncService.js:855` |
| `deleteDoc` | Quien puede editar (creador / coach en contexto / destinatario no-Evento) | — | `screens/WorkoutDetailModal.js:865` |
| `deleteDoc` (borrar planificado tras reasignar) | Quien puede editar | — | `screens/WorkoutDetailModal.js:992` |

### Lecturas

- `getDoc` por id (deep link de notificación): `screens/HomeScreen.js:249`
- `getDoc` fresco al abrir el modal: `screens/WorkoutDetailModal.js:604,643`
- `getDocs query(userId==, fecha>=, fecha<=, orderBy fecha desc)` (rango ±30 días): `screens/HomeScreen.js:414-415` y `screens/CalendarScreen.js:420-427`
- `getDocs query('asignados','array-contains',uid)` (**CONFIRMADO**: así consulta HomeScreen los eventos apuntados, sin rango de fechas — comentario explícito de que evita índice compuesto): `screens/HomeScreen.js:420-421`; igual en `screens/CalendarScreen.js:432-436`
- `getDocs query(userId==owner)` (historial de curvas): `screens/WorkoutDetailModal.js:456`
- `getDocs query(userId==, fecha>=, fecha<=)` (planes del día): `screens/WorkoutDetailModal.js:936-941`
- `getDocs query(userId==)` / `query(fecha>=, fecha<=)` (ranking de retos y analítica): `screens/SocialScreen.js:967-969`, `services/analyticsEngine.js:371-372,410-411,656,814`
- `getDocs query(userId==, id_archivo==)` (anti-duplicados FIT): `services/SyncService.js:133-139`

### Quién escribe qué (matriz de actores)

El candado de edición es **solo de cliente** (`screens/WorkoutDetailModal.js:202-225`):
- `creadoPor` se guarda al crear (`screens/AddWorkoutModal.js:328-333`); en docs antiguos sin `creadoPor`, si `userId` está en `asignados` se asume creador coach (`WorkoutDetailModal.js:216-218`).
- El atleta tiene acceso completo a TODO lo que no sea Evento aunque lo creara el coach; los Eventos creados por el coach NO los puede editar/mover/borrar el atleta.
- **El entrenador crea/edita/borra/mueve entrenos del atleta con su propia auth** (`AddWorkoutModal` recibe `athleteId`: `screens/HomeScreen.js:626`, `screens/CalendarScreen.js:1074-1079`). **No hay ninguna verificación cliente de que ese `athleteId` sea atleta suyo**: el write se limita a poner `userId: athleteId` y `creadoPor: auth.currentUser.uid`. La relación debe verificarla la regla.
- El `athleteId` viene de `AsyncStorage.getItem('currentAthleteId')` (`screens/HomeScreen.js:370-374`, `screens/CalendarScreen.js:507`), establecido por `CoachScreen.js:778`.

---

## 4. `entrenamientos/{id}/detalles/data`

| Operación | Quién | Campos exactos | Fichero:línea |
|---|---|---|---|
| `setDoc(...,{merge:true})` (guardar sesión) | Quien puede editar | `ritmo, 'fc-media', fcMax, elevacionMin, elevacionMax, cargaPercibida, esfuerzo, esfuerzoManual, esfuerzoFuente, enlace, sensacion, comentarios, cadencia, desnivelPos, temperatura` | `screens/WorkoutDetailModal.js:765` |
| `setDoc(...,{merge:true})` (comentar) | **Cualquier participante** (dueño/apuntado/creador/coach): se reescribe el array completo | `comentarios: [{texto, nombre, timestamp}]` | `screens/WorkoutDetailModal.js:872-874` |
| `setDoc(...,{merge:true})` (borrar comentario — cualquier usuario puede borrar cualquier comentario: filtro por `texto+nombre`, sin comprobar autoría) | Quien tiene el modal abierto | `comentarios: lista` | `screens/WorkoutDetailModal.js:918` |
| `setDoc` (importación .fit) | Propietario | `calorias, fcMax, ritmo, elevacionMin, elevacionMax, cadencia, desnivelPos, temperatura, esfuerzo, tss, esfuerzoFuente, notas, cargaPercibida, enlace, sensacion, descripcion, pasos, comentarios, vueltas, completado, hasRuta` | `services/SyncService.js:73-95` |
| `setDoc(...,{merge:true})` (recalcular esfuerzos) | Propietario | `esfuerzo, tss, esfuerzoFuente` | `services/SyncService.js:856-860` |

Lecturas: `getDoc` en `screens/HomeScreen.js:434`, `screens/CalendarScreen.js:461`, `screens/WorkoutDetailModal.js:623,674,684`, `services/SyncService.js:826`, `components/WeeklyKmChart.js:216`.

---

## 5. `entrenamientos/{id}/registros/data`

| Operación | Quién | Campos | Fichero:línea |
|---|---|---|---|
| `setDoc` (importación .fit) | Propietario | `puntos: parsed.registros` (muestras GPS/FC) | `services/SyncService.js:98-100` |

Lecturas: `getDoc` en `screens/WorkoutDetailModal.js:362,467,712`, `services/analyticsEngine.js:829-830`, `components/WeeklyKmChart.js:221`.
**Sin borrados ni updates desde el cliente** sobre esta subcolección.

---

## 6. `libreria` (plantillas de sesiones y carpetas)

**¿Tiene campo de propietario? SÍ: `userId`** (se establece en toda creación: `screens/AddWorkoutModal.js:388`, `screens/WorkoutDetailModal.js:1102`, `components/LibreriaDrive.js:174`).

| Operación | Quién | Campos exactos | Fichero:línea |
|---|---|---|---|
| `addDoc` (sesión plantilla) | Propietario (`userId: uid`) | `userId, carpeta, tipo, titulo, descripcion, pasos, archivos, timesUsed:0, createdAt` | `screens/AddWorkoutModal.js:388-395`; `screens/WorkoutDetailModal.js:1102-1108` |
| `addDoc` (carpeta) | Propietario | `userId, esCarpeta:true, nombre, carpeta, createdAt` | `components/LibreriaDrive.js:173-176` |
| `updateDoc` (editar sesión de librería) | Propietario | `tipo, titulo, descripcion, pasos, archivos` | `screens/AddWorkoutModal.js:300-301`; `screens/WorkoutDetailModal.js:815-816` |
| `updateDoc` (vincular plantilla al entreno guardado) | Propietario | `tipo, titulo, descripcion, pasos, archivos, workoutId` | `screens/AddWorkoutModal.js:351`; `screens/WorkoutDetailModal.js:766,849` |
| `updateDoc` (auto-vincular plantilla antigua) | Propietario | `workoutId` | `screens/WorkoutDetailModal.js:663` |
| `updateDoc` (contar uso) | Propietario | `timesUsed: increment(1)` | `screens/AddWorkoutModal.js:411` |
| `updateDoc` (renombrar carpeta) | Propietario | `nombre` | `components/LibreriaDrive.js:185` |
| `updateDoc` (mover a carpeta) | Propietario | `carpeta` | `components/LibreriaDrive.js:223` |
| `deleteDoc` (quitar del switch / borrar carpeta / borrar item) | Propietario | — | `screens/AddWorkoutModal.js:377`; `screens/WorkoutDetailModal.js:1095`; `components/LibreriaDrive.js:202,235` |

Lecturas y escucha:
- `getDocs query(libreria, where('userId','==',uid))`: `components/LibreriaDrive.js:83`
- `onSnapshot query(libreria, where('userId','==',uid))` (deltas → almacén local): `components/LibreriaDrive.js:92-108`
- `getDocs` con `userId+workoutId` y `userId+titulo+tipo`: `screens/WorkoutDetailModal.js:656-661`
- `getDocs` listado del picker: `components/LibreriaDrive.js:471-472`

> `services/libreriaStore.js` es **almacén local AsyncStorage únicamente** (0 llamadas a Firestore; clave `tj_libreria_v1_<uid>`). El listener en vivo vive en `components/LibreriaDrive.js`.

---

## 7. `archivosLib` (librería de archivos adjuntos)

| Operación | Quién | Campos exactos | Fichero:línea |
|---|---|---|---|
| `addDoc` (archivo subido) | Propietario (`userId: user.uid`) | `userId, nombre, tipo, url, size, contentType, carpeta, origen:'subida', createdAt` | `services/archivosUpload.js:91-102` |
| `addDoc` (carpeta) | Propietario | `userId, esCarpeta:true, nombre, carpeta, createdAt` | `components/ArchivosPicker.js:200-201` |
| `addDoc` (enlace de vídeo YouTube) | Propietario | `userId, tipo:'video', nombre, url, carpeta, size:null, createdAt` | `components/ArchivosPicker.js:328-329` |
| `updateDoc` (renombrar) | Propietario | `nombre` | `components/ArchivosPicker.js:255` |
| `updateDoc` (mover carpeta) | Propietario | `carpeta` | `components/ArchivosPicker.js:268` |
| `deleteDoc` (borrar carpeta / archivo) | Propietario (el binario R2 se borra antes vía servidor `/archivos/delete`) | — | `components/ArchivosPicker.js:211,234` |

Lecturas y escucha:
- `onSnapshot query(archivosLib, where('userId','==',user.uid))`: `components/ArchivosPicker.js:133-147`
- `services/archivosStore.js` es solo AsyncStorage (clave `tj_archivos_v1_<uid>`).

---

## 8. `posts` (tablón social)

**Cualquier usuario autenticado** puede crear posts y reaccionar/votar sobre CUALQUIER post (no hay filtro de audiencia en el cliente: todo el tablón es global).

### Escrituras

| Operación | Quién | Campos exactos | Fichero:línea |
|---|---|---|---|
| `addDoc` (mensaje nuevo) | Cualquier usuario (`me.uid`) | `autorUid, autorNombre, texto, media[], replyTo, encuesta {pregunta, opciones, votos:{}}, preview, reacciones:{}, createdAt` | `screens/SocialScreen.js:2621-2634` |
| `addDoc` (reenvío) | Cualquier usuario | `autorUid, autorNombre, texto, media[], reenviado:true, encuesta:null, preview, reacciones:{}, createdAt` | `screens/SocialScreen.js:566-576` |
| `updateDoc` (borrado lógico, respaldo sin servidor) | Cualquier usuario, sobre **cualquier post** | `eliminado:true, texto:'', media:[], encuesta:null, preview:null, reacciones:{}` (con media, el borrado normal pasa por el servidor `/social/delete-message`) | `screens/SocialScreen.js:603,630` |
| `updateDoc` (reacción) | Cualquier usuario, sobre **cualquier post** | **Nombres REALES de campos de reacciones**: mapa `reacciones` (objeto `emoji → array de uids`). Se escribe `reacciones.<emoji> = arrayUnion(me.uid)`, y si cambiaba de emoji `reacciones.<emojiAnterior> = arrayRemove(me.uid)` o `deleteField()` cuando quedaba 1 uid | `screens/SocialScreen.js:1084-1090` |
| `updateDoc` (voto de encuesta) | Cualquier usuario, sobre **cualquier post** | `encuesta.votos.<me.uid> = idxOpcion` (clave dinámica dentro del mapa `encuesta.votos`) | `screens/SocialScreen.js:1105` |

### Lecturas y escucha

- `getDocs` página inicial `orderBy('createdAt','desc') limit(60)`: `services/chatSync.js:39`
- `getDocs` incremental `where('createdAt','>',cursor) orderBy asc limit(300)` (máx. 5 lotes): `services/chatSync.js:50`
- `getDocs` zona antigua `where('createdAt','<',oldestAt) orderBy desc limit(50)`: `services/chatSync.js:67`
- `getDocs` ventana viva `orderBy('createdAt','desc') limit(120)`: `screens/SocialScreen.js:712`
- `onSnapshot where('createdAt','>',marca) orderBy asc`: `screens/SocialScreen.js:782-783`
- `onSnapshot orderBy('createdAt','desc') limit(120)`: `screens/SocialScreen.js:838-839`
- `onSnapshot(doc(posts,pe.id))` por cada encuesta cargada (máx. 12): `screens/SocialScreen.js:896-904`

> `services/chatSync.js` solo LEE posts (0 escrituras). El almacén local (`chatStore`) es AsyncStorage.

---

## 9. `retos`

| Operación | Quién | Campos exactos | Fichero:línea |
|---|---|---|---|
| `addDoc` (crear reto) | Cualquier usuario que tenga atletas (`perfiles where entrenador==me.uid`) | `creadorUid, creadorNombre, titulo, descripcion, metrica, invitados: [...uids], aceptados: [], inicio, fin, createdAt` (fechas ISO) | `screens/SocialScreen.js:2918-2929` |
| `updateDoc` (aceptar reto) | Cualquier usuario invitado | `aceptados: arrayUnion(me.uid)` | `screens/SocialScreen.js:1023` |
| `deleteDoc` (cancelar reto) | El creador (botón solo visible para él; el comentario del código confirma que las reglas exigen `resource.data.creadorUid`) | — | `screens/SocialScreen.js:1045` |

Lecturas:
- `query(where('creadorUid','in',[me.uid, coachUid]))`: `screens/SocialScreen.js:918`
- `query(where('invitados','array-contains',me.uid))`: `screens/SocialScreen.js:919`
- `query(perfiles, where('entrenador','==',r.creadorUid))` (invitados implícitos = atletas del creador): `screens/SocialScreen.js:932`
- Lecturas auxiliares para el ranking: `wellness/{uid}` (`:953`) y `entrenamientos` por rango de fechas (`:967-969`).

---

## 10. `avatares`

| Operación | Quién | Campos | Fichero:línea |
|---|---|---|---|
| `setDoc` | Propietario (al publicar su foto) | `url, updatedAt, size` | `services/avatarCache.js:213` |

Lecturas: `getDoc avatares/{uid}` (`:249,335`), `getDocs where(documentId in chunk)` (`:268`), y respaldo legacy `getDoc perfiles/{uid}` → `foto` base64 (`:292,342`).

---

## 11. `wellness`, `fitness`, `analysis`, `soporte`

- **`wellness`**: SOLO LECTURA desde el cliente. `getDoc(doc(db,'wellness',uid))` en `screens/HomeScreen.js:448`, `screens/CalendarScreen.js:493`, `screens/SocialScreen.js:953`, `screens/WorkoutDetailModal.js:702`, `services/analyticsEngine.js:427`, `services/SyncService.js:37,808`. Se lee el `wellness` de OTROS usuarios (ranking de retos por pasos/sueño: `SocialScreen.js:950-963`). **Ninguna escritura.**
- **`fitness`**: SOLO LECTURA desde el cliente. `onSnapshot(doc(db,'fitness',uid))` en `screens/HomeScreen.js:472` y `getDoc` en `:488`. Lo calcula/escribe el servidor. **Ninguna escritura.**
- **`analysis`**: lectura `getDoc(doc(db,'analysis',uid))` (`screens/AnalysisScreen.js:257`) y escritura `setDoc(doc(db,'analysis',uid), { charts }, { merge:true })` (`:334`). Solo el propio uid.
- **`soporte`**: `addDoc` con `userId, email, asunto, mensaje, createdAt` (`screens/SupportScreen.js:58-64`). Sin lecturas desde el cliente.

---

## 12. CoachScreen.js — detalle especial (punto 3 del encargo)

**`screens/CoachScreen.js` NO toca Firestore en absoluto.** Toda la lógica de entrenador pasa por el servidor HTTP `https://garmin-fit-server.onrender.com`:

- `GET /coach-screen-data/<uid>` → entrenador, atletas, solicitudes (`screens/CoachScreen.js:517`)
- `POST /solicitar-entrenador` → `{ atletaId: user.uid, entrenadorEmail }` (`:577-581`)
- `POST /gestionar-solicitud` → `{ solicitudId, entrenadorId: user.uid, accion }` (`:596-600`)
- `POST /eliminar-entrenador` → `{ atletaId: user.uid }` (`:623-627`)

El coach selecciona un atleta guardando su uid en AsyncStorage: `AsyncStorage.setItem('currentAthleteId', atleta.uid)` (`CoachScreen.js:778`). A partir de ahí:

- **Dashboard** (`HomeScreen`) usa `currentUserId = athleteId || user.uid` (`:229-231`) y:
  - escucha en vivo `perfiles/{atleta}` (`:325-341`),
  - consulta entrenamientos con `where('userId','==',currentUserId)` y **`where('asignados','array-contains',currentUserId)` — CONFIRMADO** (`:414-421`),
  - lee `wellness/{atleta}` (`:448`) y `fitness/{atleta}` (`:472`),
  - abre `AddWorkoutModal` con `athleteId={athleteId}` (`:626`).
- **AddWorkoutModal** con `athleteId` crea el entreno **con la auth del coach**: `userId: targetUserId (athleteId)`, `creadoPor: auth.currentUser.uid (coach)` (`screens/AddWorkoutModal.js:321-348`). Si es Evento, auto-apunta al atleta (`asignados:[athleteId]`, `:347`). Aviso al atleta vía servidor (`sendNotificationToAthlete`, `:355-366`).
- **Calendario** recibe `athleteId` de AsyncStorage (`CalendarScreen.js:507`) y pasa `athleteId` a `AddWorkoutModal` (`:1074-1079`); el drag & drop escribe `{fecha, fechaStr}` sobre el entreno del atleta con la auth del coach (`:771`).
- **WorkoutDetailModal** con `athleteId` permite al coach editar/borrar/mover los entrenos del atleta (`puedeEditarEntreno` incluye `esCoachContexto`, `:210,224`) y escribe detalles/datos con su propia auth.
- **Zonas y Marcas**: si hay `currentAthleteId`, SettingsScreen navega a `Zones`/`Marcas` con `athleteId` (`SettingsScreen.js:319,323`) y el COACH escribe los campos de zonas/marcas del perfil del atleta con su propia auth (`ZonesScreen.js:467`, `MarcasScreen.js:610`).

**Riesgo clave para las reglas**: en ninguna de estas rutas el cliente verifica que el `athleteId` sea atleta del coach. La verificación debe vivir en las reglas (consultando `perfiles/{athleteId}.entrenador == request.auth.uid`), porque hoy el único candado es de UI.

---

## 13. SocialScreen.js y chatSync.js — reacciones (punto 3 del encargo)

- `services/chatSync.js` **solo lee** `posts` (página inicial 60, incremental 300, zonas 50). No escribe.
- Las reacciones se escriben desde `screens/SocialScreen.js:1057-1092`. El esquema real es:
  - `post.reacciones` = mapa `{ "<emoji>": [uid, uid, ...] }` (una reacción por persona; al reaccionar se retira su uid del emoji anterior y se añade al nuevo).
  - `updateDoc` usa las claves dinámicas **`reacciones.<emoji>`** con `arrayUnion(me.uid)` (nueva), `arrayRemove(me.uid)` (quita) y **`deleteField()`** cuando el array del emoji anterior quedaba con 1 solo uid (`SocialScreen.js:1084-1090`).
  - No existe campo `likes` ni contadores numéricos de reacciones: todo se deriva de los arrays del mapa `reacciones`.
- Votos de encuesta: **`encuesta.votos.<uid>` = índice de opción** (clave dinámica, `SocialScreen.js:1105`).
- Borrado: `updateDoc` con `eliminado:true, texto:'', media:[], encuesta:null, preview:null, reacciones:{}` sobre CUALQUIER post (`:603,630`); con media va por el servidor (`POST /social/delete-message`, `:616-626`). El borrado físico (`deleteDoc`) NO se usa en posts.

---

## 14. Colecciones NO usadas por el cliente — confirmación explícita (punto 4 del encargo)

| Colección | ¿Usada? | Evidencia |
|---|---|---|
| `ia_keys` | **NO** | 0 coincidencias de `ia_keys` en todo el código (grep global, fuera de node_modules). Ningún `collection(db,'ia_keys')` ni `doc(db,'ia_keys',...)`. |
| `ia_feedback` | **NO** | 0 coincidencias. No se crea ni se lee desde el cliente. |
| `solicitudes` | **NO como colección Firestore** | Las "solicitudes" de coach son un ARRAY que devuelve el servidor (`/coach-screen-data`, `CoachScreen.js:521`) y se cachean en AsyncStorage (`services/coachCache.js`). El único "historial de solicitudes" local usa la clave AsyncStorage `solicitudes_historial_v1` (`App.js:176`). El historial persistente se guarda en `perfiles/{uid}/notificaciones` con `kind:'solicitud'` (`App.js:182-189`). |
| `intervals_connections` | **Solo lectura** | Única referencia: `getDoc(doc(db,'intervals_connections',uid))` en `screens/HomeScreen.js:485` (comprobar si hay conexión antes de `POST /sync-fitness`). Las credenciales se guardan por HTTP (`POST /intervals/save-credentials` vía `services/GarminSyncService.js:52-56`), no en Firestore. |

---

## 15. `perfiles` contiene `expoPushToken` y datos personales (punto 5 del encargo) — CONFIRMADO

1. **`expoPushToken`**: sí — `setDoc(doc(db,'perfiles',user.uid), { expoPushToken }, { merge:true })` en `App.js:404-408`.
2. **Datos personales**: sí — `nombre, apellido, sexo, fechaNac, altura, unidadAltura, peso, unidadPeso, pais, ciudad, dni, telefono, email, foto(base64)` (`screens/ProfileScreen.js:648-653`), más `language`, `notificacionesActivadas`, zonas/marcas, `entrenador` (relación) y `pendingDeletes`.
3. **Legibles por cualquier autenticado**: el patrón de acceso es `getDoc/onSnapshot(doc(db,'perfiles', <uid arbitrario>))` sin verificación cliente de relación:
   - `onSnapshot` en vivo sobre el perfil de CUALQUIER uid en contexto de atleta: `screens/HomeScreen.js:325-341`
   - `getDoc` sobre perfiles de `asignados`, autores, coaches, etc.: `screens/WorkoutDetailModal.js:549,594,595,888,1050`; `services/avatarCache.js:253,292,342`; `services/coachNotify.js:49`; `services/planReal.js:257`; `services/SyncService.js:35,806`; `components/StepEditor.js:385`; `components/WeeklyKmChart.js:112`; `components/PasosResumen.js:245`
   - queries `where('entrenador','==',uid)` devuelven los perfiles completos de los atletas (incluido `email`): `screens/SocialScreen.js:920,932,2889` y `CreaReto` (`:2889-2894` lee `nombre/email/apellido`).
   - `services/avatarCache.js:292-300` descarga la `foto` base64 de perfiles ajenos como respaldo legacy.

Si las reglas permiten `get` de `perfiles` a todo usuario autenticado (o la app falla si se cierra), quedan expuestos el token push (spam de notificaciones / suplantación de avisos si el servidor confía en el token), el DNI, el teléfono, el email y la fecha de nacimiento de cualquier usuario. **Riesgo abierto confirmado.**

---

## Conclusiones para las reglas

### `perfiles`
- **Crear/actualizar**: solo el dueño (`request.auth.uid == userId`) sobre SU doc, **excepto** los campos que el entrenador legítimo puede tocar: `zonasFC, zonasRitmo, zonasPotencia, zonasActividad, umbralRitmo, umbralCiclismo, umbralFC, fcUmbral, fcReposo, umbralPotencia` (`ZonesScreen.js:467`), `marcasDefs, marcasResults, marcasMetrics` (`MarcasScreen.js:610`) y `pendingDeletes` (`WorkoutDetailModal.js:189`) — para estos, exigir que `resource.data.entrenador == request.auth.uid` (o `get(...).data.entrenador == uid`) y restringir con `request.resource.data.diff()` para que el coach no pueda pisar `dni/telefono/email/expoPushToken/entrenador`.
- **Borrar**: solo el dueño (`ProfileScreen.js:707`).
- **Leer**: decidir conscientemente. La app necesita leer perfiles ajenos (nombres para comentarios, asignados, atletas del coach, foto legacy). Si se abre la lectura a todo autenticado, asumir que `dni`, `telefono`, `email`, `fechaNac`, `foto` y **`expoPushToken`** son públicos. Recomendado: (a) mover `expoPushToken` a una subcolección privada o a un doc con regla estricta, y (b) limitar `get` a `{uid == request.auth.uid} || resource.data.entrenador == uid || uid ∈ entrenamientos del usuario` o usar una función/colección de relación. Como mínimo, si se mantiene lectura abierta, sacar `dni/telefono/expoPushToken` de los perfiles públicos.

### `perfiles/{uid}/notificaciones`
- Todo (create/read/update/delete) solo `request.auth.uid == uid`. El cliente solo escribe el historial propio (`App.js:182`), marca leído (`NotificacionesScreen.js:134,175`) y borra (`:209`; `AppSettingsScreen.js:277-283`).

### `entrenamientos` (+ `detalles/data`, `registros/data`)
- **Crear**: autenticado. La app escribe `userId` y `creadoPor` (`AddWorkoutModal.js:328-348`, `SyncService.js:53`, `WorkoutDetailModal.js:961,1010`). Regla mínima: `request.resource.data.userId == request.auth.uid` (auto-import FIT, entreno propio) **o** (coach) `request.resource.data.creadoPor == request.auth.uid && get(/databases/$(database)/documents/perfiles/$(request.resource.data.userId)).data.entrenador == request.auth.uid`. NO confiar en el campo que manda el cliente: validar que `creadoPor == auth.uid` y que la relación coach-atleta existe en `perfiles`.
- **Actualizar/borrar**: la app permite editar a: dueño (`userId == uid`), apuntado no-Evento (`uid in asignados` y `tipo != 'Evento'`), y coach del dueño (`perfiles[userId].entrenador == uid`). Para Eventos, el atleta NO debe editar/mover/borrar aunque sea el dueño del doc (candado cliente en `WorkoutDetailModal.js:202-225`). El drag & drop (`CalendarScreen.js:771`) y las ediciones del coach (`WorkoutDetailModal.js:764-1033`) se hacen con la auth del coach, así que las reglas deben replicar: `request.auth.uid == resource.data.userId && (!(resource.data.tipo == 'Evento' && resource.data.userId in resource.data.asignados)) || request.auth.uid in resource.data.asignados && resource.data.tipo != 'Evento' || coachDel(resource.data.userId) == request.auth.uid`. Los `deleteField()` de `WorkoutDetailModal.js:1028-1032` obligan a que la regla de update permita eliminar esos campos concretos (o usar `allow update: ... && request.resource.data.diff(resource.data).affectedKeys().hasOnly([...])`).
- **Leer**: la app lee por `userId == uid` y por `asignados array-contains uid` (`HomeScreen.js:414-421`), más `getDoc` directo por id (`HomeScreen.js:249`, `WorkoutDetailModal.js:604`), `getDocs` por rango de fechas GLOBAL en retos (`SocialScreen.js:967-969`) y `userId==owner` para curvas (`WorkoutDetailModal.js:456`). Regla mínima coherente: `resource.data.userId == request.auth.uid || request.auth.uid in resource.data.asignados || coachDel(resource.data.userId) == request.auth.uid`; si el ranking de retos necesita leer entrenos de otros (`SocialScreen.js:969-971`), restringir esos campos o aceptar esa lectura (escribir en las reglas exactamente qué es público).
- `detalles/data` y `registros/data`: mismos actores que el doc padre.

### `libreria` y `archivosLib`
- `userId` es el campo de propietario en AMBAS (`AddWorkoutModal.js:388`, `LibreriaDrive.js:174`, `archivosUpload.js:92`, `ArchivosPicker.js:200`). Todo create/read/update/delete/onSnapshot filtrado por `where('userId','==',uid)` → regla simple: `request.auth.uid == resource.data.userId` (y en create, `request.resource.data.userId == request.auth.uid`).

### `posts`
- **Crear**: autenticado, con `autorUid == request.auth.uid` (la app lo pone a `me.uid`, `SocialScreen.js:2622`). Validar que nadie suplanta `autorUid/autorNombre`.
- **Actualizar**: hoy el cliente permite a CUALQUIER usuario: reaccionar a cualquier post (`reacciones.<emoji>` con arrayUnion/arrayRemove/deleteField, `:1084-1090`), votar (`encuesta.votos.<uid>`, `:1105`) y borrar lógicamente CUALQUIER post (`eliminado:true...`, `:603,630`). Decisión de reglas: (a) reacciones/votos solo sobre `reacciones.<emoji>` y `encuesta.votos.<request.auth.uid>` (permitir `affectedKeys()` restringido), (b) borrado lógico: o bien cualquiera (como hoy, estilo WhatsApp, riesgo de borrado ajeno) o solo `autorUid == request.auth.uid`. El borrado con media va por el servidor (`/social/delete-message`), pero el fallback directo (`:630`) obliga a decidir.
- **Leer**: global (el tablón es global, sin grupos). `get/onSnapshot` abierto a autenticados.
- Nota: el borrado FÍSICO de posts no lo hace el cliente; `removed` en los listeners se trata como purga (`SocialScreen.js:788-794`).

### `retos`
- **Crear**: autenticado; validar `creadorUid == request.auth.uid` y que los `invitados` sean atletas suyos (`perfiles[uid].entrenador == request.auth.uid`) — el cliente los elige de `perfiles where entrenador==me.uid` (`SocialScreen.js:2889`).
- **Actualizar**: solo el campo `aceptados` con `arrayUnion(request.auth.uid)` y solo si `request.auth.uid in invitados` (`SocialScreen.js:1023`).
- **Borrar**: solo `creadorUid == request.auth.uid` (`SocialScreen.js:1045`; el propio código lo confirma).
- **Leer**: `creadorUid in [uid, coach]` o `invitados array-contains uid` (`:918-919`). Coherente con reglas de lectura restringidas a creador+invitados+atletas.

### `avatares`
- `setDoc` solo sobre `avatares/{uid}` propio (`avatarCache.js:213`). Lectura abierta a autenticados (los usa el chat, `:268`).

### `wellness` / `fitness` / `analysis` / `soporte`
- `wellness` y `fitness`: el cliente SOLO LEE. `wellness` se lee de otros usuarios para retos de pasos/sueño (`SocialScreen.js:953`). Si se abre lectura, aceptar que `wellness/{uid}.days` (pasos/sueño) es visible a otros; alternativamente restringir a `uid == auth.uid || invitado/creador de reto`.
- `analysis`: solo `uid == request.auth.uid`.
- `soporte`: solo create para autenticados (`userId == request.auth.uid`); el cliente no lo lee.

### `intervals_connections`
- Solo lectura `getDoc` (`HomeScreen.js:485`) → `allow read: if request.auth.uid == userId;` y **ningún write** desde el cliente.

### `ia_keys`, `ia_feedback`, `solicitudes`
- No referenciadas desde el cliente: **sin reglas necesarias** (se pueden dejar cerradas `allow read, write: if false`).

### Observación transversal (auth del entrenador)
El modelo de confianza es "el coach actúa sobre el atleta con su propia auth, sin token de delegación". Toda regla de escritura cruzada debe verificar la relación en `perfiles/{atleta}.entrenador == request.auth.uid` (o estructura equivalente), porque el cliente NO lo comprueba (`AddWorkoutModal.js:321`, `WorkoutDetailModal.js:210-224`, `CalendarScreen.js:771`, `ZonesScreen.js:467`, `MarcasScreen.js:610`).
