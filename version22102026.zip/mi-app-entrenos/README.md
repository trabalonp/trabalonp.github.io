# Welcome to your Expo app 👋

This is an [Expo](https://expo.dev) project created with [`create-expo-app`](https://www.npmjs.com/package/create-expo-app).

## Get started

1. Install dependencies

   ```bash
   npm install
   ```

2. Start the app

   ```bash
   npx expo start
   ```

In the output, you'll find options to open the app in a

- [development build](https://docs.expo.dev/develop/development-builds/introduction/)
- [Android emulator](https://docs.expo.dev/workflow/android-studio-emulator/)
- [iOS simulator](https://docs.expo.dev/workflow/ios-simulator/)
- [Expo Go](https://expo.dev/go), a limited sandbox for trying out app development with Expo

You can start developing by editing the files inside the **app** directory. This project uses [file-based routing](https://docs.expo.dev/router/introduction).

## Get a fresh project

When you're ready, run:

```bash
npm run reset-project
```

This command will move the starter code to the **app-example** directory and create a blank **app** directory where you can start developing.

## Learn more

To learn more about developing your project with Expo, look at the following resources:

- [Expo documentation](https://docs.expo.dev/): Learn fundamentals, or go into advanced topics with our [guides](https://docs.expo.dev/guides).
- [Learn Expo tutorial](https://docs.expo.dev/tutorial/introduction/): Follow a step-by-step tutorial where you'll create a project that runs on Android, iOS, and the web.

## Índices de Firestore (NO desplegados)

`firestore.indexes.json` está INTENCIONADAMENTE vacío: los índices reales se
exportan desde tu proyecto (`firebase firestore:indexes` o la consola) y se
despliegan a mano con `firebase deploy --only firestore:indexes`.

Plantilla (verifica contra tu proyecto antes de desplegar; si no existen,
Firebase te dará el enlace exacto al fallar la consulta):

- Colección `analyticsCurves`: `userId` ASC + `updatedAt` DESC (leer meses).
- Colección `entrenamientos`: `userId` ASC + `mergedFromPlanId` ASC (reparación
  de planDist del servidor).
- Colección `entrenamientos`: `userId` ASC + `fecha` ASC + `createdAt` DESC
  (paginado de resúmenes en el motor de analíticas; en la app real el campo
  de orden puede variar — ajústalo al que use `analyticsEngine.js`).

Estas definiciones NO se despliegan automáticamente desde este repositorio.

## Reglas de Firestore nuevas (NO desplegadas)

`firestore.rules` se conserva intacto (reglas abiertas actuales). Las reglas
endurecidas del bloque B2 viven en **`firestore.rules.nuevo`** y **NO están
desplegadas**: revísalas y despliégalas a mano cuando estés seguro.

Para ejecutar las pruebas con el Emulator Suite (nunca contra producción):

```bash
npm install                                    # instala @firebase/rules-unit-testing (devDependency)
firebase emulators:start --only firestore      # arranca el emulador (puerto 8080)
node tests/rules/firestore-rules-test.js       # matriz propietario / entrenador vinculado (4 variantes) / NO vinculado / ajeno / anónimo
```

Si la librería no está instalada o el emulador no está arrancado, el test
imprime `SKIP` y sale con 0: nunca rompe la batería `node tests/*.js`.

Despliegue (solo tú, a mano, después de revisar):

```bash
firebase deploy --only firestore:rules         # despliega firestore.rules
```

Nota: el despliegue usa `firestore.rules`; para desplegar las nuevas, primero
revisa `firestore.rules.nuevo` y luego sustituye el contenido de
`firestore.rules` por el del fichero nuevo (o apunta `firebase.json` a él).

Decisiones y riesgos principales (detalle completo en los comentarios de
`firestore.rules.nuevo`):

- **Entrenamientos + detalles/registros**: lectura a propietario, entrenador
  vinculado (`esSuEntrenador`, reutilizada de las reglas actuales: variantes
  `entrenadorUid` string, `entrenador` string/mapa/lista) o apuntado;
  escritura a propietario o entrenador; los apuntados solo marcan
  `estado`/`duracion` al ejecutar; crear exige `userId` propio o atleta del
  entrenador con `creadoPor == uid`.
- **Posts**: crear con `autorUid == uid`; actualizar solo el autor, salvo
  reacciones (`reacciones`) y votos (`encuesta.votos`, sin poder cambiar
  `pregunta`/`opciones`): reaccionar/votar lo permite cualquier autenticado;
  editar texto o borrar lógicamente posts ajenos queda DENEGADO (el borrado
  con media sigue pasando por el servidor `/social/delete-message`).
- **Perfiles**: lectura abierta a autenticados (la app social la necesita);
  **riesgo abierto**: el perfil contiene `expoPushToken`, `dni`, `telefono`,
  `email`, `fechaNac` y `foto`; propuesta futura: separar
  `perfilesPrivados/{uid}`. El entrenador solo puede escribir las claves
  exactas de zonas/marcas (`zonasFC`, `zonasRitmo`, `zonasPotencia`,
  `zonasActividad`, `umbralRitmo`, `umbralCiclismo`, `umbralFC`, `fcUmbral`,
  `fcReposo`, `umbralPotencia`, `marcasDefs`, `marcasResults`,
  `marcasMetrics`) vía `affectedKeys().hasOnly([...])`.
- **analyticsCurves**: lectura propietario o su entrenador; escritura solo
  propietario.
- **wellness/fitness**: solo lectura desde el cliente (los escribe el backend
  con Admin). **analysis**: propietario + entrenador (lectura), propietario
  (escritura). **notificaciones**: solo el dueño del perfil. **soporte**:
  solo `addDoc` del autor. **intervals_connections**: lectura del doc propio,
  sin escritura.
- **ia_keys, ia_feedback, solicitudes** y cualquier colección no declarada:
  denegadas por el cierre final `match /{document=**}`.
- ⚠ **Queries del entrenador**: el evaluador de consultas de Firestore solo
  admite queries que puede probar con sus propias restricciones; las ramas
  con `get()`/`esSuEntrenador()` no son probables en una consulta, así que
  las queries del entrenador sobre el calendario del atleta
  (`where('userId','==',atleta)` en `HomeScreen.js:414-421` y
  `CalendarScreen.js:420-436`) pueden fallar con `permission-denied` al
  desplegar. Mitigación futura: custom claims de coach en el token o un
  campo `coachUid` en el documento. Pruébalo con un usuario coach antes de
  desplegar en producción.

## Join the community

Join our community of developers creating universal apps.

- [Expo on GitHub](https://github.com/expo/expo): View our open source platform and contribute.
- [Discord community](https://chat.expo.dev): Chat with Expo users and ask questions.
