// handlers/social/notify-message.js
/* Push de mensajes del chat social para que lleguen también con la app
   cerrada. El remitente llama aquí justo tras guardar el mensaje; el
   servidor calcula entrenador y atletas relacionados. */
const { getUid } = require('../../lib/auth');
const push = require('../../lib/push');
const admin = require('../../lib/firebase');
const db = admin.firestore();

function uidRelacionado(valor) {
  if (typeof valor === 'string') return valor.trim() || null;
  if (!valor || typeof valor !== 'object') return null;
  return valor.uid || valor.id || valor.userId || valor.entrenadorUid || null;
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método no permitido' });
  try {
    const uid = await getUid(req);
    const { messageId, texto, autorNombre } = req.body || {};
    const perfSnap = await db.collection('perfiles').doc(uid).get();
    const perfil = perfSnap.exists ? perfSnap.data() : {};
    const remitente = autorNombre || perfil.nombre || 'Alguien';
    const destinos = new Set();
    const coachUid = uidRelacionado(perfil.entrenador);
    if (coachUid) destinos.add(coachUid);

    // Compatibilidad con perfiles antiguos (entrenador: string) y nuevos
    // (entrenador: { uid }). Las consultas se deduplican en el Set.
    const consultas = [
      db.collection('perfiles').where('entrenador', '==', uid).get(),
      db.collection('perfiles').where('entrenador.uid', '==', uid).get(),
      db.collection('perfiles').where('entrenador.id', '==', uid).get(),
      db.collection('perfiles').where('entrenador.userId', '==', uid).get(),
    ];
    const snaps = await Promise.all(consultas);
    snaps.forEach((snap) => snap.forEach((d) => destinos.add(d.id)));
    destinos.delete(uid);

    const cuerpo = String(texto || '').trim() || '📎 adjunto';
    let enviados = 0;
    for (const dest of destinos) {
      await push.sendPushToUser(dest, remitente, cuerpo, { kind: 'chat', messageId: messageId || null });
      enviados++;
    }
    return res.json({ ok: true, enviados });
  } catch (e) {
    console.error('[notify-message] Error:', e.message);
    return res.status(Number(e.status) || 500).json({ error: e.message });
  }
};
