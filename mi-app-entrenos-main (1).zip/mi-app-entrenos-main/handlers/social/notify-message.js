// handlers/social/notify-message.js
/* Push de mensajes del chat social para que lleguen también con la app
   cerrada. El remitente llama aquí justo tras publicar.

   El Tablón es un chat ÚNICO para todo el equipo (colección `posts`
   compartida), así que el push llega a TODOS los perfiles registrados, no
   solo al entrenador y a los atletas directos del remitente: con la lógica
   anterior, A (atleta de B) avisaba a B pero C —entrenador de B— se quedaba
   sin aviso aunque el mensaje lo lee todo el equipo. Cada perfil decide con
   `notificacionesActivadas` (lo respeta lib/push.js) y el aviso queda en su
   historial de Notificaciones, filtrable por la categoría «Chat». */
const { getUid } = require('../../lib/auth');
const push = require('../../lib/push');
const admin = require('../../lib/firebase');
const db = admin.firestore();

function uidRelacionado(valor) {
  if (typeof valor === 'string') return valor.trim() || null;
  if (Array.isArray(valor)) {
    for (const v of valor) { const u = uidRelacionado(v); if (u) return u; }
    return null;
  }
  if (!valor || typeof valor !== 'object') return null;
  // Firestore Reference: en el admin SDK llega como DocumentReference con .id
  if (valor.id && (valor.path || valor.firestore || valor._path)) {
    const partes = String(valor.path || valor._path || '').split('/');
    return partes.length >= 2 ? partes[partes.length - 1] : valor.id;
  }
  return valor.uid || valor.id || valor.userId || valor.entrenadorUid || null;
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método no permitido' });
  try {
    const uid = await getUid(req);
    const { messageId, texto, autorNombre } = req.body || {};
    const perfSnap = await db.collection('perfiles').doc(uid).get();
    const perfil = perfSnap.exists ? perfSnap.data() : {};
    const remitente = autorNombre || perfil.nombre || 'Alguien';
    const entrenador = uidRelacionado(perfil.entrenador) || null;

    // Destinatarios: todos los perfiles registrados menos el remitente. El
    // propio sendPushToUser se salta a quien tenga las notificaciones
    // desactivadas y guarda el historial aunque el dispositivo aún no tenga
    // token de push.
    const snap = await db.collection('perfiles').get();
    const destinos = [];
    snap.forEach((d) => { if (d.id !== uid) destinos.push(d.id); });

    const cuerpo = String(texto || '').trim() || '📎 adjunto';
    // sendPushToUser nunca lanza (captura sus errores), así que el envío en
    // paralelo es seguro: con equipos grandes no encadena un cold start tras
    // otro como el bucle secuencial anterior.
    await Promise.all(destinos.map((dest) =>
      push.sendPushToUser(dest, remitente, cuerpo, { kind: 'chat', messageId: messageId || null })));

    // Trazabilidad: quién escribió y a cuántos se avisó. Es lo primero que
    // hay que mirar cuando "no llega" un aviso.
    console.log(`[notify-message] remitente=${uid} entrenador=${entrenador || 'NINGUNO'} destinos=${destinos.length}`);
    return res.json({ ok: true, enviados: destinos.length, entrenador, destinos });
  } catch (e) {
    console.error('[notify-message] Error:', e.message);
    return res.status(Number(e.status) || 500).json({ error: e.message });
  }
};