// api/social/delete-message.js
// Borrado de mensajes del Tablón CON limpieza de Cloudflare R2.
//
// Hasta ahora eliminar un mensaje era un borrado lógico desde la app
// (eliminado:true + media:[]): el archivo quedaba huérfano en R2 para
// siempre. Este endpoint hace las dos cosas de forma atómica y segura:
//
//   1) Comprueba con firebase-admin que el post existe y que QUIEN PIDE el
//      borrado es su autor (las reglas de Firestore permitían actualizar a
//      cualquiera; aquí se endurece).
//   2) Marca el post como eliminado (mismo parche que usaba la app).
//   3) Borra de R2 los objetos del mensaje (original + miniatura) SOLO si
//      ningún OTRO mensaje vivo los referencia: los reenvíos comparten la
//      misma URL de R2 y no deben romperse (consulta media.url == X sobre la
//      colección posts, sin índices compuestos).
//
// La app lo usa al "Eliminar" y, si el endpoint no está desplegado (404) o
// falla la red, hace el borrado lógico de siempre como respaldo: nada se
// rompe por no redeployar el servidor, simplemente la media no se limpia.
//
// Env vars: las mismas R2_* que presign.js + FIREBASE_SERVICE_ACCOUNT.
const admin = require('../../lib/firebase');
const { getUid } = require('../../lib/auth');
const { claveR2DeUrl, mediaUrlsDe, sigueReferenciada } = require('../../lib/socialMedia');

let S3Client = null;
let DeleteObjectCommand = null;
try {
  ({ S3Client, DeleteObjectCommand } = require('@aws-sdk/client-s3'));
} catch (e) {
  S3Client = null;   // sin SDK: solo borrado lógico (best-effort)
}

const MAX_POSTS = 25;
const PARCHE = { eliminado: true, texto: '', media: [], encuesta: null, preview: null, reacciones: {} };

function uidRelacionado(valor) {
  if (typeof valor === 'string') return valor.trim() || null;
  if (!valor || typeof valor !== 'object') return null;
  return valor.uid || valor.id || valor.userId || valor.entrenadorUid || null;
}

/**
 * Elimina de los historiales de notificaciones (perfiles/<uid>/notificaciones)
 * las notificaciones de CHAT de los mensajes borrados (data.messageId). Los
 * destinatarios se calculan igual que en notify-message.js: entrenador del
 * autor + perfiles que apuntan al autor como entrenador (sin el propio autor).
 */
async function limpiarNotificacionesDeMensaje(db, autorUid, postIds) {
  const destinos = new Set();
  try {
    const autorSnap = await db.collection('perfiles').doc(autorUid).get();
    if (autorSnap.exists) {
      const coach = uidRelacionado((autorSnap.data() || {}).entrenador);
      if (coach) destinos.add(coach);
    }
  } catch (e) {}
  try {
    const consultas = [
      db.collection('perfiles').where('entrenador', '==', autorUid).get(),
      db.collection('perfiles').where('entrenador.uid', '==', autorUid).get(),
      db.collection('perfiles').where('entrenador.id', '==', autorUid).get(),
      db.collection('perfiles').where('entrenador.userId', '==', autorUid).get(),
    ];
    const snaps = await Promise.all(consultas);
    snaps.forEach((snap) => snap.forEach((d) => destinos.add(d.id)));
  } catch (e) {}
  destinos.delete(autorUid);

  let borradas = 0;
  for (const destUid of destinos) {
    for (const id of postIds) {
      try {
        const q = await db.collection('perfiles').doc(destUid)
          .collection('notificaciones').where('data.messageId', '==', id).get();
        if (q.empty) continue;
        const batch = db.batch();
        q.forEach((d) => batch.delete(d.ref));
        await batch.commit();
        borradas += q.size;
      } catch (e) {
        console.warn('[delete-message] notificaciones', destUid, id, e.message);
      }
    }
  }
  return borradas;
}

function r2Client() {
  return new S3Client({
    region: process.env.R2_REGION || 'auto',
    endpoint: process.env.R2_ENDPOINT || `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: process.env.R2_ACCESS_KEY_ID,
      secretAccessKey: process.env.R2_SECRET_ACCESS_KEY,
    },
  });
}

function r2Configurado() {
  return !!(S3Client && process.env.R2_ACCOUNT_ID && process.env.R2_ACCESS_KEY_ID &&
    process.env.R2_SECRET_ACCESS_KEY && process.env.R2_BUCKET && process.env.R2_PUBLIC_URL);
}

/** ¿Queda algún post VIVO (distinto de exceptId) que referencie esta URL? */
async function otraReferenciaViva(db, url, exceptId) {
  const refs = [];
  for (const campo of ['media.url', 'media.thumbUrl']) {
    try {
      const snap = await db.collection('posts').where(campo, '==', url).limit(20).get();
      snap.docs.forEach((d) => refs.push({ id: d.id, eliminado: !!(d.data() || {}).eliminado }));
    } catch (e) {
      // Sin índice o sin permisos: por seguridad, NO se borra el objeto
      return true;
    }
  }
  return sigueReferenciada(refs, exceptId);
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método no permitido' });
  try {
    const uid = await getUid(req);
    const { postIds } = req.body || {};
    if (!Array.isArray(postIds) || postIds.length === 0 || postIds.length > MAX_POSTS ||
        !postIds.every((x) => typeof x === 'string' && x.trim())) {
      return res.status(400).json({ error: `postIds: array de 1..${MAX_POSTS} ids` });
    }

    const db = admin.firestore();
    const conR2 = r2Configurado();
    const resultados = [];
    let mediaBorrados = 0;
    let mediaOmitidos = 0;

    for (const id of postIds.map((x) => x.trim())) {
      const ref = db.collection('posts').doc(id);
      const snap = await ref.get();
      if (!snap.exists) { resultados.push({ id, ok: false, motivo: 'no-existe' }); continue; }
      const data = snap.data() || {};
      if (data.autorUid !== uid) { resultados.push({ id, ok: false, motivo: 'no-autor' }); continue; }

      const urls = mediaUrlsDe(data);
      await ref.update(PARCHE);   // borrado lógico (idéntico al de la app)

      // Las notificaciones de este mensaje (push de chat archivado en los
      // destinatarios) ya no deben aparecer: se eliminan de sus historiales.
      try { await limpiarNotificacionesDeMensaje(db, uid, [id]); } catch (e) {}

      let borrados = 0;
      for (const url of urls) {
        const key = claveR2DeUrl(url);
        if (!key) { continue; }                       // URL ajena a R2: no se toca
        if (await otraReferenciaViva(db, url, id)) {  // reenvíos u otros mensajes vivos
          mediaOmitidos++;
          continue;
        }
        if (!conR2) { mediaOmitidos++; continue; }
        try {
          await r2Client().send(new DeleteObjectCommand({ Bucket: process.env.R2_BUCKET, Key: key }));
          borrados++;
          mediaBorrados++;
        } catch (e) {
          console.error('[delete-message] R2:', key, e.message);
          mediaOmitidos++;
        }
      }
      resultados.push({ id, ok: true, mediaBorrados: borrados });
    }

    return res.json({ ok: true, resultados, mediaBorrados, mediaOmitidos, r2: conR2 });
  } catch (error) {
    const status = error.status || 500;
    if (status >= 500) console.error('[social/delete-message] Error:', error.message);
    return res.status(status).json({ error: error.message });
  }
};
