// handlers/archivos/presign.js
// URLs presignadas para subir ARCHIVOS DE ENTRENO (librería de archivos del
// coach/atleta) a Cloudflare R2, mismo patrón que social/presign pero con
// prefijo de clave propio: archivos/{uid}/… (el chat usa social/{uid}/…).
// La lectura es pública por R2_PUBLIC_URL; la librería de gimnasio vive
// bajo gym/… (la sube el dueño con scripts/gym/subir-gym-a-r2.js).
const { getUid } = require('../../lib/auth');

let S3Client, PutObjectCommand, getSignedUrl;
try {
  ({ S3Client, PutObjectCommand } = require('@aws-sdk/client-s3'));
  ({ getSignedUrl } = require('@aws-sdk/s3-request-presigner'));
} catch (e) {
  S3Client = null;
}

const MAX_BYTES = 25 * 1024 * 1024;   // 25 MB por archivo

function r2Client() {
  return new S3Client({
    region: process.env.R2_REGION || 'auto',
    endpoint: process.env.R2_ENDPOINT || `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: process.env.R2_ACCESS_KEY_ID,
      secretAccessKey: process.env.R2_SECRET_ACCESS_KEY,
    },
  });
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método no permitido' });
  try {
    const uid = await getUid(req);
    const { filename, contentType, size } = req.body || {};
    if (!filename) return res.status(400).json({ error: 'Falta filename' });
    if (Number(size) > MAX_BYTES) return res.status(413).json({ error: 'Archivo demasiado grande (máx 25 MB)' });
    if (!S3Client) return res.status(503).json({ error: 'Dependencias @aws-sdk no instaladas en Vercel' });
    if (!process.env.R2_ACCOUNT_ID || !process.env.R2_ACCESS_KEY_ID ||
        !process.env.R2_SECRET_ACCESS_KEY || !process.env.R2_BUCKET || !process.env.R2_PUBLIC_URL) {
      return res.status(503).json({ error: 'Almacenamiento R2 no configurado en el servidor' });
    }
    const ext = (String(filename).match(/\.([a-z0-9]+)$/i) || [, 'bin'])[1].toLowerCase();
    const key = `archivos/${uid}/${Date.now()}-${Math.random().toString(36).slice(2, 6)}.${ext}`;
    const cmd = new PutObjectCommand({
      Bucket: process.env.R2_BUCKET,
      Key: key,
      ContentType: contentType || 'application/octet-stream',
    });
    const uploadUrl = await getSignedUrl(r2Client(), cmd, { expiresIn: 300 });
    const publicUrl = `${String(process.env.R2_PUBLIC_URL).replace(/\/+$/, '')}/${key}`;
    return res.json({ ok: true, uploadUrl, key, publicUrl });
  } catch (error) {
    console.error('[archivos/presign] Error:', error.message);
    return res.status(Number(error.status) || 500).json({ error: error.message });
  }
};
