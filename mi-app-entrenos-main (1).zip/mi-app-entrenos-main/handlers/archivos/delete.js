// handlers/archivos/delete.js
// Borrado del BINARIO en Cloudflare R2 de un archivo de la librería de
// archivos ("Mis archivos"). Hasta ahora quitar un archivo de la librería
// solo borraba el doc de Firestore (`archivosLib`) y el objeto quedaba
// huérfano en el bucket para siempre. La app ahora: 1) llama a este
// endpoint y 2) SOLO si responde ok, borra el doc y la caché local.
//
// Mismo patrón que social/delete-message y archivos/presign:
//   · La app NUNCA ve las claves de R2: manda la URL pública del archivo
//     (la que guardó al subirlo) y el servidor la traduce a clave.
//   · Defensa en profundidad: solo se aceptan claves bajo el prefijo del
//     PROPIO usuario autenticado (`archivos/{uid}/…`). No se puede borrar
//     la librería fija de gimnasio (gym/…), la media del chat (social/…)
//     ni archivos de otros usuarios, aunque se conozca la URL.
//   · S3 DeleteObject es idempotente: borrar un objeto que ya no existe
//     responde 204, así que reintentar tras un fallo parcial no atasca.
//
// Env vars: las mismas R2_* que presign.js + FIREBASE_SERVICE_ACCOUNT.
const { getUid } = require('../../lib/auth');

let S3Client = null;
let DeleteObjectCommand = null;
try {
  ({ S3Client, DeleteObjectCommand } = require('@aws-sdk/client-s3'));
} catch (e) {
  S3Client = null;   // sin SDK: no se puede borrar (503 explícito)
}

function r2Client() {
  return new S3Client({
    region: process.env.R2_REGION || 'auto',
    endpoint: process.env.R2_ENDPOINT || `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: process.env.R2_ACCESS_KEY_ID,
      secretAccessKey: process.env.R2_SECRET_ACCESS_KEY,
    },
  });
}

/**
 * URL pública del archivo → clave R2. SOLO devuelve clave si la URL es de
 * este bucket (R2_PUBLIC_URL) Y la clave cae bajo `archivos/{uid}/…` del
 * usuario autenticado. Cualquier otra cosa (otro dominio, data-URI, gym/,
 * social/, otro uid, traversal "..") → null. Pura: se prueba sin red.
 */
function claveArchivosDeUrl(url, uid, baseOverride) {
  const base = String(baseOverride || process.env.R2_PUBLIC_URL || '').replace(/\/+$/, '');
  if (!base || !uid || !url || typeof url !== 'string') return null;
  const sinQuery = url.split('?')[0].split('#')[0];
  if (!sinQuery.startsWith(base + '/')) return null;
  let key;
  try { key = decodeURIComponent(sinQuery.slice(base.length + 1)); } catch (e) { return null; }
  if (!key || key.includes('..')) return null;
  const prefijo = `archivos/${uid}/`;
  return key.startsWith(prefijo) && key.length > prefijo.length ? key : null;
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método no permitido' });
  try {
    const uid = await getUid(req);
    const { url } = req.body || {};
    if (!url || typeof url !== 'string') return res.status(400).json({ error: 'Falta url' });

    // La validación de prefijo va ANTES de mirar la configuración de R2:
    // una URL ajena es 403 siempre, sin revelar nada del bucket.
    const key = claveArchivosDeUrl(url, uid);
    if (!key) return res.status(403).json({ error: 'Solo puedes borrar tus propios archivos (archivos/{uid}/…)' });

    if (!S3Client) return res.status(503).json({ error: 'Dependencias @aws-sdk no instaladas en Vercel' });
    if (!process.env.R2_ACCOUNT_ID || !process.env.R2_ACCESS_KEY_ID ||
        !process.env.R2_SECRET_ACCESS_KEY || !process.env.R2_BUCKET || !process.env.R2_PUBLIC_URL) {
      return res.status(503).json({ error: 'Almacenamiento R2 no configurado en el servidor' });
    }

    await r2Client().send(new DeleteObjectCommand({ Bucket: process.env.R2_BUCKET, Key: key }));
    return res.json({ ok: true, key });
  } catch (error) {
    const status = Number(error.status) || 500;
    if (status >= 500) console.error('[archivos/delete] Error:', error.message);
    return res.status(status).json({ error: error.message });
  }
};

// Exportada para tests (pura, sin red): node tests/archivos-delete-test.js
module.exports.claveArchivosDeUrl = claveArchivosDeUrl;
