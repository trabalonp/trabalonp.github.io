// handlers/archivos/config.js
// GET → devuelve la URL pública del bucket R2 para que la app pueda LEER
// (nunca escribir) los recursos públicos: el índice de la librería de
// gimnasio (gym/index.json), los gif/thumbs y los archivos subidos.
// La app nunca ve las claves de R2: solo el dominio público.
module.exports = async (req, res) => {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Método no permitido' });
  const base = String(process.env.R2_PUBLIC_URL || '').replace(/\/+$/, '');
  if (!base) return res.status(503).json({ error: 'Almacenamiento R2 no configurado en el servidor' });
  return res.json({ ok: true, publicUrl: base });
};
