// scripts/gym/nombresEs.js
/* Compone el nombre en español de cada ejercicio del dataset
   exercises-dataset (hasaneyldrm) usando glosarioEs.json.
   Reglas de orden: MOVIMIENTO → objetivo (de X) → modificador → postura →
   equipo, que es el orden natural en español ("curl de bíceps alterno
   sentado con mancuernas"). Los tokens desconocidos se dejan en inglés y
   el nombre se marca como parcial (para revisarlo después). */
const fs = require('fs');
const path = require('path');

const GLOS = JSON.parse(fs.readFileSync(path.join(__dirname, 'glosarioEs.json'), 'utf8'));

function limpiar(nombre) {
  return String(nombre || '')
    .replace(/[()]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function componerEs(nombre) {
  const toks = limpiar(nombre).split(' ').filter(Boolean);
  const grupos = { mov: [], tgt: [], mod: [], pos: [], eq: [] };
  const desconocidos = [];
  let i = 0;
  while (i < toks.length) {
    let hit = null;
    // Frases: de más largas a más cortas (máx 4 palabras)
    for (let n = Math.min(4, toks.length - i); n >= 2; n--) {
      const frase = toks.slice(i, i + n).join(' ');
      if (GLOS.frases[frase]) { hit = GLOS.frases[frase]; i += n; break; }
    }
    if (!hit) {
      const t = toks[i];
      if (GLOS.frases[t]) { hit = GLOS.frases[t]; }
      else if (GLOS.tokens[t]) { hit = GLOS.tokens[t]; }
      else { hit = [t, 'mov']; desconocidos.push(t); }
      i += 1;
    }
    const [txt, cat] = hit;
    if (cat === 'skip' || !txt) continue;
    (grupos[cat] || grupos.mov).push(txt);
  }
  const partes = [
    ...grupos.mov, ...grupos.tgt, ...grupos.mod, ...grupos.pos, ...grupos.eq,
  ];
  let es = partes.join(' ');
  es = es.charAt(0).toUpperCase() + es.slice(1);
  return { es, desconocidos };
}

module.exports = { componerEs };

// Uso directo: node scripts/gym/nombresEs.js /ruta/al/dataset
if (require.main === module) {
  const dir = process.argv[2];
  if (!dir) { console.error('Uso: node nombresEs.js /ruta/al/exercises-dataset'); process.exit(1); }
  const data = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'exercises.json'), 'utf8'));
  let completos = 0;
  const parcialEjemplos = [];
  const out = {};
  for (const ex of data) {
    const r = componerEs(ex.name);
    out[ex.id] = r.es;
    if (r.desconocidos.length === 0) completos++;
    else if (parcialEjemplos.length < 25) parcialEjemplos.push(`${ex.name} → ${r.es} [${r.desconocidos.join(',')}]`);
  }
  console.log(`Traducidos completos: ${completos}/${data.length} (${(100 * completos / data.length).toFixed(1)}%)`);
  console.log('Muestras:');
  for (const ex of data.slice(0, 18)) console.log('  ', ex.name, '→', out[ex.id]);
  console.log('Parciales (muestra):');
  for (const p of parcialEjemplos) console.log('  ', p);
}
