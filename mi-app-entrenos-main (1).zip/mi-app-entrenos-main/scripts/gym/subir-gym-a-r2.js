// scripts/gym/subir-gym-a-r2.js
/* ══════════════════════════════════════════════════════════════════════
   SUBE LA LIBRERÍA DE GIMNASIO (carpeta FIJA gym/…) A CLOUDFLARE R2
   desde un clon local de https://github.com/hasaneyldrm/exercises-dataset
   ──────────────────────────────────────────────────────────────────────
   USO (desde la raíz del servidor, con las variables R2 en el entorno o
   en un .env junto al script):
     node scripts/gym/subir-gym-a-r2.js /ruta/a/exercises-dataset [--dry]

   ESTRUCTURA QUE DEJA EN EL BUCKET (la que lee la app; los media con su
   nombre ORIGINAL del repo, para que también puedas subirlos a mano):
     gym/index.json        → [{id, n (EN), es (ES), bp, mg, eq, m, t}]
     gym/meta.json         → { version, ts, grupos: [{bp, es, n}] }
     gym/videos/{orig}.gif → animación (tal cual la carpeta videos/ del repo)
     gym/images/{orig}.jpg → miniatura 180×180 (tal cual images/ del repo)
     gym/ex/{id}.json      → detalle con instrucciones y pasos EN + ES y m/t

   MODO SIN R2 (solo generar los JSON para subida manual por panel):
     node scripts/gym/subir-gym-a-r2.js /ruta/al/dataset --json-only SALIDA

   Los nombres en español se componen con glosarioEs.json (nombresEs.js);
   los pasos/instrucciones ES vienen YA TRADUCIDOS en el dataset.
   Re-ejecutable: sobrescribe (PUT) y es idempotente.
   ══════════════════════════════════════════════════════════════════════ */
'use strict';
const fs = require('fs');
const path = require('path');

// .env opcional al lado del script o en la raíz del repo
for (const p of [path.join(__dirname, '.env'), path.join(__dirname, '..', '..', '.env')]) {
  try {
    for (const line of fs.readFileSync(p, 'utf8').split('\n')) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  } catch (e) { /* sin .env */ }
}

// El SDK de S3 solo hace falta para subir: en --json-only ni se carga.
let S3Client = null, PutObjectCommand = null;
try {
  ({ S3Client, PutObjectCommand } = require('@aws-sdk/client-s3'));
} catch (e) { /* sin deps: solo --json-only o --dry */ }
const { componerEs } = require('./nombresEs');

const GRUPOS_ES = {
  chest: 'Pecho', back: 'Espalda', shoulders: 'Hombros',
  'upper arms': 'Brazos (bíceps y tríceps)', 'lower arms': 'Antebrazos y agarre',
  waist: 'Abdomen y cintura', 'upper legs': 'Piernas', 'lower legs': 'Gemelos y tobillos',
  cardio: 'Cardio', neck: 'Cuello',
};
const ORDEN_GRUPOS = ['chest', 'back', 'shoulders', 'upper arms', 'lower arms', 'waist', 'upper legs', 'lower legs', 'cardio', 'neck'];

function cliente() {
  if (!S3Client) throw new Error('Faltan las dependencias @aws-sdk/client-s3 (npm install en el servidor)');
  for (const v of ['R2_ACCOUNT_ID', 'R2_ACCESS_KEY_ID', 'R2_SECRET_ACCESS_KEY', 'R2_BUCKET']) {
    if (!process.env[v]) throw new Error(`Falta la variable de entorno ${v}`);
  }
  return new S3Client({
    region: process.env.R2_REGION || 'auto',
    endpoint: process.env.R2_ENDPOINT || `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: { accessKeyId: process.env.R2_ACCESS_KEY_ID, secretAccessKey: process.env.R2_SECRET_ACCESS_KEY },
  });
}

async function put(s3, Key, Body, ContentType, dry) {
  if (dry) return;
  await s3.send(new PutObjectCommand({ Bucket: process.env.R2_BUCKET, Key, Body, ContentType }));
}

(async () => {
  const dir = process.argv[2];
  const dry = process.argv.includes('--dry');
  const ji = process.argv.indexOf('--json-only');
  const jsonOnly = ji > 0 ? (process.argv[ji + 1] || 'gym-json') : null;
  if (!dir) { console.error('Uso: node subir-gym-a-r2.js /ruta/a/exercises-dataset [--dry | --json-only SALIDA]'); process.exit(1); }
  if (jsonOnly) fs.mkdirSync(path.join(jsonOnly, 'ex'), { recursive: true });
  const data = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'exercises.json'), 'utf8'));
  const s3 = (dry || jsonOnly) ? null : cliente();
  console.log(`${dry ? '[DRY] ' : ''}Subiendo ${data.length} ejercicios a s3://${process.env.R2_BUCKET || '?'}/gym/ …`);

  const index = [];
  const porGrupo = {};
  let i = 0;
  for (const ex of data) {
    const { es } = componerEs(ex.name);
    const gifRel = ex.gif_url;      // p.ej. videos/0001-xxx.gif
    const thRel = ex.image;         // p.ej. images/0001-xxx.jpg
    index.push({ id: ex.id, n: ex.name, es, bp: ex.body_part, mg: ex.muscle_group, eq: ex.equipment, m: gifRel, t: thRel });
    porGrupo[ex.body_part] = (porGrupo[ex.body_part] || 0) + 1;

    const detalle = {
      id: ex.id, n: ex.name, es, m: gifRel, t: thRel,
      bp: ex.body_part, bp_es: GRUPOS_ES[ex.body_part] || ex.body_part,
      mg: ex.muscle_group, eq: ex.equipment,
      instructions: { es: ex.instructions?.es || '', en: ex.instructions?.en || '' },
      instruction_steps: { es: ex.instruction_steps?.es || [], en: ex.instruction_steps?.en || [] },
      attribution: ex.attribution || null,
    };
    if (jsonOnly) {
      fs.writeFileSync(path.join(jsonOnly, 'ex', `${ex.id}.json`), JSON.stringify(detalle));
    } else {
      await put(s3, `gym/${gifRel}`, fs.readFileSync(path.join(dir, gifRel)), 'image/gif', dry);
      await put(s3, `gym/${thRel}`, fs.readFileSync(path.join(dir, thRel)), 'image/jpeg', dry);
      await put(s3, `gym/ex/${ex.id}.json`, Buffer.from(JSON.stringify(detalle)), 'application/json', dry);
    }
    if (++i % 100 === 0) console.log(`  ${i}/${data.length}`);
  }

  const meta = {
    version: 1,
    ts: new Date().toISOString(),
    total: data.length,
    grupos: ORDEN_GRUPOS.filter((bp) => porGrupo[bp]).map((bp) => ({ bp, es: GRUPOS_ES[bp], n: porGrupo[bp] })),
  };
  if (jsonOnly) {
    fs.writeFileSync(path.join(jsonOnly, 'index.json'), JSON.stringify(index));
    fs.writeFileSync(path.join(jsonOnly, 'meta.json'), JSON.stringify(meta));
    console.log(`OK: JSON generados en ${jsonOnly}/ (index.json, meta.json, ex/ con ${data.length} ficheros).`);
    console.log('Súbelos al bucket bajo gym/ junto con las carpetas videos/ e images/ del repo.');
  } else {
    await put(s3, 'gym/index.json', Buffer.from(JSON.stringify(index)), 'application/json', dry);
    await put(s3, 'gym/meta.json', Buffer.from(JSON.stringify(meta)), 'application/json', dry);
    console.log(`OK: ${data.length} ejercicios + index.json + meta.json ${dry ? '(dry-run)' : 'subidos'}.`);
  }
  console.log('La app los lee en {R2_PUBLIC_URL}/gym/… como carpeta fija "Ejercicios de gimnasio".');
})().catch((e) => { console.error('ERROR:', e.message); process.exit(1); });
