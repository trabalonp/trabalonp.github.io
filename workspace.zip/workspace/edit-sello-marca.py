#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Sello de marca en la tarjeta compartible: logo circular + nombre de la app
("TEAM JORGE APP", tomado de app.json) arriba a la izquierda, en ambos modos
de contraste. Sustituye a la esquina de galería superior izquierda."""
import os

WS = os.environ.get("ARENA_WORKSPACE", os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(WS, "proyecto", "mi-app-entrenos", "screens", "SettingsScreen.js")

raw = open(P, "rb").read().decode("utf-8")
CRLF = "\r\n" in raw
s = raw.replace("\r\n", "\n") if CRLF else raw
n0 = len(s)

def rep(old, new, count=1):
    global s
    assert s.count(old) >= count, "NO ENCONTRADO: %r..." % old[:80]
    s = s.replace(old, new, count)

# ── 1) Campos de marca en cada paleta ──
rep("""    fallback: GREEN_DK,
    initial: '#FFFFFF',
  },""",
"""    fallback: GREEN_DK,
    initial: '#FFFFFF',
    brandRing: GREEN + '55',   // aro del logo de la app
    brandText: '#A9CBB0',      // nombre de la app
  },""")
rep("""    fallback: '#E8A33D',
    initial: '#FFFFFF',
  },""",
"""    fallback: '#E8A33D',
    initial: '#FFFFFF',
    brandRing: '#C05F3566',    // aro del logo de la app
    brandText: '#8A5E42',      // nombre de la app
  },""")

# ── 2) La esquina superior izquierda deja sitio al sello de marca ──
rep("""            <Path d="M16 46 L16 16 L46 16" fill="none" stroke={P.decor} strokeWidth={2.5} strokeOpacity={P.cornerOp} />
""",
"""            {/* (la esquina superior izquierda la ocupa el sello de marca) */}
""")

# ── 3) Sello de marca: logo circular + nombre de la app (arriba izquierda) ──
rep("""          </Svg>

          {/* ══ FOTO: la cumbre — aro punteado + anillo verde doble ══ */}
""",
"""          </Svg>

          {/* ══ SELLO DE MARCA: logo de la app + nombre, arriba a la
               izquierda, para saber de qué app viene la tarjeta ══ */}
          <View style={styles.shareBrand}>
            <Image
              source={require('../assets/images/icon.png')}   // expo.name → "Team Jorge App"
              style={[styles.shareBrandLogo, { borderColor: P.brandRing }]}
            />
            <Text style={[styles.shareBrandName, { color: P.brandText }]} numberOfLines={1}>
              TEAM JORGE APP
            </Text>
          </View>

          {/* ══ FOTO: la cumbre — aro punteado + anillo verde doble ══ */}
""")

# ── 4) Estilos del sello ──
rep("""  shareArt: { position: 'absolute', top: 0, left: 0 },
""",
"""  shareArt: { position: 'absolute', top: 0, left: 0 },
  shareBrand: {
    position: 'absolute', top: 16, left: 16,
    flexDirection: 'row', alignItems: 'center', gap: 8,
  },
  shareBrandLogo: { width: 26, height: 26, borderRadius: 13, borderWidth: 1 },
  shareBrandName: { fontSize: 10.5, fontWeight: '800', letterSpacing: 2.2 },
""")

out = s.replace("\n", "\r\n") if CRLF else s
open(P, "wb").write(out.encode("utf-8"))
print("OK: sello de marca añadido (%d → %d bytes, CRLF=%s)" % (n0, len(s), CRLF))
