# ZOOM-GESTOS — Visor de imágenes estilo WhatsApp (gestos en el hilo de UI)

Revisión de la propuesta de Duck.ai (GPT-5.6 Luna) del 21/09/2026 e
implementación en `screens/SocialScreen.js`. **Sin dependencias nativas
nuevas**: `react-native-gesture-handler`, `react-native-reanimated`,
`react-native-worklets`, `expo-image` y `expo-image-manipulator` YA están en
tu `package.json` y en el APK. Es un cambio de JS: vale con tu flujo normal
(copiar archivos + EAS Update / rebuild del APK).

## Qué decía Duck.ai y qué se hizo

| Propuesta Duck.ai | Veredicto | Implementación |
|---|---|---|
| Visor a pantalla completa en `Modal` con gestos nativos | ✅ Correcto | Se mantiene el `Modal` y se reconstruye el visor |
| `Gesture.Pinch/Pan/Tap` + `GestureDetector` (gesture-handler v2) | ✅ Correcto | Implementado: todo se calcula en el **hilo de UI** (worklets); el zoom no da tirones aunque el chat/red ocupen JS |
| `useSharedValue` + `useAnimatedStyle` + `withSpring` (reanimated) | ✅ Correcto | Implementado |
| `expo-image` con `contentFit="contain"` y caché `memory-disk` | ✅ Correcto | Implementado en visor **y** en burbujas (`transition` 120 ms) |
| Fórmula de pellizco `t = f − (f − t₀)·ratio` | ⚠️ Aproximada | Corregida por la **exacta** con ancla en el inicio del gesto: `t = f − (f₀ − t₀)·(s/s₀)`. El punto que agarras se queda pegado a los dedos sin deriva (verificado con test numérico: deriva ~1e-14) |
| `GestureHandlerRootView` en la raíz de la app | ✅ Ya lo tenías | Además: en Android el `Modal` crea otra ventana nativa, así que el visor lleva su **propio** `GestureHandlerRootView` dentro del `Modal` (detalle que Duck.ai no menciona y sin él los gestos mueren) |
| Dos URLs: `thumbnailUrl` + `originalUrl` | ✅ Correcto | Ahora es REAL: al enviar una foto >200 KB se genera una miniatura de 640 px (`expo-image-manipulator`, API nueva con fallback legacy) y se sube a R2 como segundo objeto. El mensaje guarda `thumbUrl`/`thumbSize`. La burbuja pinta la miniatura; el visor carga el original. Si la miniatura falla, el envío sigue adelante sin ella |
| Doble toque 2.5× / volver a 1× | ✅ | Implementado, anclado al punto tocado, con muelle |
| Zoom máx 3–4× | ✅ (orientativo) | Se mantiene 5× (lo que ya tenías); mín 1× |
| Pan solo con zoom | ✅ | Con zoom: pan 1:1 **limitado a los bordes reales de la imagen** (respeta el letterbox de `contain`; Duck.ai tip #7: se usa el aspect ratio real que da `onLoad`) |
| Cerrar con swipe hacia abajo | ✅ | Implementado: la imagen sigue al dedo y **el fondo se atenúa** mientras arrastras; umbral 110 px o velocidad |
| Swipe horizontal entre fotos | ✅ (tip #8) | La foto sigue al dedo; cambia al pasar del 28 % del ancho o con impulso; precarga de las fotos vecinas al abrir (sin spinner) |
| `Image.prefetch` | ➖ No aplica | Ya hay caché de disco propia (`cachedOrDownload`, con validación de imágenes corruptas y necesaria para "Compartir/Guardar"); hace de precarga |
| Animación de apertura desde la miniatura | ➖ Fuera de alcance | Transición compartida nativa; se puede añadir después si lo quieres |
| Librería `react-native-gesture-image-viewer` | ❌ Innecesaria | Con gesture-handler + reanimated (ya instalados) sale nativo y a medida; se eliminó del `package.json` `react-native-image-viewing` (estaba sin usar) |

## v2.1 — Fix "la imagen salta al soltar un dedo y luego vuelve"

**Síntoma que reportaste**: tras hacer zoom con los dedos, al soltar la imagen
se movía como queriendo ir a otro punto y luego volvía. En WhatsApp no pasa.

**Causa raíz** (verificada leyendo el fuente nativo de
react-native-gesture-handler 2.32 para Android, `ScaleGestureDetector.java`
y `PinchGestureHandler.kt`):

1. Al levantar UN dedo (`ACTION_POINTER_UP`) el detector de Android
   **recalcula el punto focal a la posición del dedo que queda** (excluye al
   que se levantó).
2. El handler de pellizco de RNGH **ignora `onScaleEnd` a propósito** (su
   detector lo dispara "demasiado pronto"): el gesto sigue `ACTIVE` hasta que
   se levanta el ÚLTIMO dedo (`ACTION_UP`).
3. Por tanto siguen llegando `onUpdate` **con el foco teletransportado**: la
   fórmula de anclaje `t = f − (f₀ − t₀)·ratio` aplica ese salto fielmente y
   la foto brinca; encima el dedo restante la sigue arrastrando 1:1. Al
   soltar del todo, `snapToBounds()` la devolvía ⇒ "va a un punto y vuelve".

**Solución (lo que hace WhatsApp: el gesto TERMINA al levantar un dedo)**:

- `onTouchesUp`: el orquestador de RNGH despacha los eventos de touches
  **antes** que los updates del gesto (garantizado en su fuente), así que en
  cuanto `numberOfTouches <= 1` el pellizco se **enmudece**: los updates
  siguientes se descartan hasta el próximo gesto. Cero salto.
- **Red de seguridad**: si el foco se "teletransporta" >150 px en un frame
  (imposible con dedos reales) también se enmudece — cubre 3+ dedos u otras
  plataformas.
- **Tope DURANTE el gesto**: el traslado va limitado a los bordes reales de
  la imagen también mientras pellizcas (antes solo se limitaba al soltar).
  Al soltar, la foto ya no se mueve nada (el snap es no-op). WhatsApp hace
  justo esto: tope duro en el borde, sin goma al soltar.
- **Reanclaje**: si apoyas un dedo nuevo quedando otro en pantalla
  (`onTouchesDown` con ≥2 touches), el gesto se reancla al estado actual
  (normalizando el `e.scale` acumulado con `p0e`) y puedes seguir zoomando
  sin levantar todos los dedos.
- `onBegin` des-enmudece en cada interacción nueva.

**Verificación**: simulación numérica `tests/focal-release-fix-test.js`
(28 aserciones OK) que reproduce la secuencia exacta de eventos que RNGH
despacha en Android: el update-artefacto se ignora, el dedo restante ya no
arrastra, el snap al soltar es no-op, el tope en bordes funciona, el
reanclaje es continuo, y la fórmula focal exacta (pan 1:1 a dos dedos,
anclaje del contenido bajo los dedos, clamp 1–5×) sigue intacta.

## v2.2 — Barra superior negra (cerrar + compartir) y sin numeración

Cambios pedidos sobre el visor:

- **Barra negra arriba**: los botones de cerrar (✕) y compartir viven ahora
  en una barra negra a ancho completo que cubre también la zona de la barra
  de estado (`paddingTop = insets.top`). Como el fondo del visor ya es negro,
  la barra se integra igual que en WhatsApp.
- **Se oculta con el zoom**: en cuanto `scale > 1.02` la barra se desliza
  hacia arriba y se desvanece (animación en el hilo de UI con
  `useAnimatedStyle` + `withTiming`, 150–220 ms); al volver a 1× (pellizco,
  doble toque o muelle) reaparece sola.
- **Sin numeración de fotos**: fuera el contador "3 / 12".
- **Compartir** (icono `share-outline`): abre el panel del sistema, que
  incluye "Guardar imagen". Mismo comportamiento que antes, icono y nombre
  nuevos.

## Cambio OBLIGATORIO en babel.config.js

Reanimated 4 mueve el plugin de Babel a `react-native-worklets`:

```js
plugins: ['react-native-worklets/plugin'],   // antes: 'react-native-reanimated/plugin'
```

El visor nuevo es el primer código de la app con worklets; con el plugin
viejo la compilación puede fallar o no transformar los worklets.

## Archivos a copiar (carpeta APP del ZIP)

1. `screens/SocialScreen.js` → sustituir
2. `babel.config.js` → sustituir (plugin de worklets)
3. `package.json` → **OBLIGATORIO desde el paquete WhatsApp**: añade
   `expo-audio ~57.0.5` (reproductor de audios en el chat) y quita
   `react-native-image-viewing` (sin usar)
4. `app.json` → añade el plugin `expo-audio` con `recordAudioAndroid: false`
   (solo reproducción, sin permiso de micrófono)
5. `services/chatSync.js` y `services/fechasChat.js` → NUEVOS (motor de
   sincronización por zonas y separadores de fecha; ver CHAT-SYNC-SETUP.md)

No hay cambios en el servidor ni en las reglas de Firestore (los campos
`thumbUrl`/`thumbSize` dentro de `media` pasan las reglas actuales).

## Despliegue

- App: copia los archivos, **`npm install`** (entra `expo-audio`, que es un
  módulo nativo) y lanza un **rebuild del APK / EAS Build**. Un EAS Update
  (OTA) sobre el APK actual seguiría funcionando para todo lo demás: el
  `require('expo-audio')` va protegido con `try/catch` y, si el binario no
  tiene el módulo, los audios muestran una tarjeta que los abre con el
  sistema en vez del reproductor interno.
- Servidor: nada.

## Qué probar

1. Toca una foto del chat → visor a pantalla completa.
2. Pellizco: el zoom se ancla donde están los dedos, fluido aunque el chat
   esté cargando; tope 5×; al soltar cerca de 1× vuelve con muelle.
   **PRUEBA DEL ARREGLO**: haz zoom y suelta los dedos de uno en uno —
   la foto NO debe moverse nada al soltar (ni salto ni "ida y vuelta").
   Arrastra a dos dedos hasta el borde: debe topar durante el gesto, sin
   rebote al soltar.
3. Con zoom: arrastra con un dedo; la imagen no se sale de sus bordes
   reales (ni por las bandas negras del letterbox).
4. Doble toque: 2.5× en el punto tocado; otro doble toque vuelve a 1×.
5. Sin zoom: swipe horizontal cambia de foto (**sin numeración**); swipe
   hacia abajo cierra y el fondo se va atenuando mientras arrastras.
6. Barra negra superior: ✕ cierra y el icono de compartir abre el panel del
   sistema. Haz un poco de zoom → la barra se oculta deslizándose; vuelve a
   1× (doble toque o pellizco) → la barra regresa sola.
7. Envía una foto NUEVA (>200 KB): debe subir también su miniatura (se ve
   `thumb-…` en el bucket de R2) y la burbuja del chat pinta la miniatura.
8. Fotos antiguas (sin miniatura): se siguen viendo igual (fallback al
   original).
