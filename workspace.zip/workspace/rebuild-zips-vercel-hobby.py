#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Reconstruye los ZIPs del servidor con la estructura de 1 sola función
(dispatcher api/[...path].js + handlers/), exigida por el límite de 12
Serverless Functions del plan Hobby de Vercel.

Hace 4 cosas:
  1. Regenera desde el árbol actual (LF verificado):
       - servidor-completo-para-vercel.zip        (raíz plana = repo GitHub)
       - mi-app-entrenos-server-CORREGIDO.zip     (carpeta mi-app-entrenos-main/)
  2. Actualiza la sección SERVER/ de fix-whatsapp-extras.zip:
       - quita SERVER/api/social/{link-preview,delete-message}.js (rutas viejas)
       - añade SERVER/api/[...path].js + SERVER/handlers/** completos
       - refresca SERVER/lib/{linkPreviewParse,socialMedia}.js
       - añade VERCEL-HOBBY-12-FUNCIONES.md y tests/dispatcher-test.js
       - refresca tests/link-preview-parse-test.js y WHATSAPP-EXTRAS.md
  3. Sincroniza el staging entrega-social/server/.
  4. Verifica: sin duplicados, hashes idénticos al árbol, nada de node_modules.
"""
import hashlib, os, shutil, zipfile

SRV = os.path.join('workspace-anterior', 'vercel-server', 'mi-app-entrenos-main')
DOC = 'VERCEL-HOBBY-12-FUNCIONES.md'
EXCLUIR_DIRS = {'node_modules', '.git', '.vercel'}

def blob(*p):
    with open(os.path.join(*p), 'rb') as f:
        return f.read()

def árbol_servidor():
    """{(ruta_relativa_posix): bytes} de todo el servidor, sin node_modules."""
    out = {}
    for root, dirs, files in os.walk(SRV):
        dirs[:] = [d for d in dirs if d not in EXCLUIR_DIRS]
        for fn in sorted(files):
            p = os.path.join(root, fn)
            rel = os.path.relpath(p, SRV).replace(os.sep, '/')
            data = blob(p)
            assert b'\r\n' not in data, 'CRLF inesperado en servidor: ' + rel
            out[rel] = data
    return out

ARBOL = árbol_servidor()
print('Archivos del servidor: %d' % len(ARBOL))
esperados_clave = ['api/[...path].js', 'vercel.json',
                   'handlers/social/link-preview.js',
                   'handlers/social/delete-message.js', 'handlers/social/presign.js',
                   'handlers/social/purge.js', 'lib/linkPreviewParse.js',
                   'lib/socialMedia.js', 'package.json', '.gitignore']
for e in esperados_clave:
    assert e in ARBOL, 'falta en el árbol: ' + e
assert not any(r.startswith('api/') and r != 'api/[...path].js' for r in ARBOL), \
    'quedan archivos sueltos en api/'
assert sum(1 for r in ARBOL if r.startswith('handlers/')) == 13, 'debe haber 13 handlers'

def sha(b):
    return hashlib.sha256(b).hexdigest()[:16]

# ── 1) ZIPs de servidor completo ────────────────────────────────────────────
def zip_servidor(nombre, prefijo=''):
    with zipfile.ZipFile(nombre, 'w', zipfile.ZIP_DEFLATED) as z:
        for rel in sorted(ARBOL):
            z.writestr(prefijo + rel, ARBOL[rel])
        z.writestr(prefijo + DOC, blob(DOC))
    n = len(zipfile.ZipFile(nombre).namelist())
    print('OK %-45s %2d entradas' % (nombre, n))

zip_servidor('servidor-completo-para-vercel.zip')
zip_servidor('mi-app-entrenos-server-CORREGIDO.zip', 'mi-app-entrenos-main/')

# ── 2) fix-whatsapp-extras.zip: sección SERVER/ nueva ───────────────────────
VIEJAS_SERVER = {'SERVER/api/social/link-preview.js', 'SERVER/api/social/delete-message.js'}
zname = 'fix-whatsapp-extras.zip'
src = zipfile.ZipFile(zname, 'r')
tmp = zname + '.tmp'
nuevas = {}
for rel, data in ARBOL.items():
    if rel.startswith('api/') or rel.startswith('handlers/') or \
       rel in ('lib/linkPreviewParse.js', 'lib/socialMedia.js', 'vercel.json'):
        nuevas['SERVER/' + rel] = data
nuevas[DOC] = blob(DOC)
nuevas['tests/dispatcher-test.js'] = blob('tests', 'dispatcher-test.js')
nuevas['tests/link-preview-parse-test.js'] = blob('tests', 'link-preview-parse-test.js')
nuevas['WHATSAPP-EXTRAS.md'] = blob('WHATSAPP-EXTRAS.md')

infos = src.infolist()
ultima = {it.filename: i for i, it in enumerate(infos)}
with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as out:
    vistos = set()
    for i, item in enumerate(infos):
        nombre_e = item.filename
        if ultima[nombre_e] != i:
            continue                          # duplicado viejo
        if nombre_e in VIEJAS_SERVER:
            continue                          # ruta anterior al dispatcher
        if nombre_e in nuevas:
            out.writestr(nombre_e, nuevas.pop(nombre_e))   # versión refrescada
        else:
            out.writestr(nombre_e, src.read(nombre_e))
        vistos.add(nombre_e)
    for nombre_e, data in nuevas.items():     # entradas nuevas
        if nombre_e not in vistos:
            out.writestr(nombre_e, data)
src.close()
shutil.move(tmp, zname)
print('OK %-45s %2d entradas' % (zname, len(zipfile.ZipFile(zname).namelist())))

# ── 3) Staging entrega-social/server ────────────────────────────────────────
st = os.path.join('entrega-social', 'server')
if os.path.isdir(st):
    shutil.rmtree(st)
os.makedirs(st)
for rel, data in ARBOL.items():
    p = os.path.join(st, rel.replace('/', os.sep))
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'wb') as f:
        f.write(data)
shutil.copy(DOC, os.path.join(st, DOC))
print('OK entrega-social/server sincronizado (%d archivos)' % (len(ARBOL) + 1))

# ── 4) Verificación final ───────────────────────────────────────────────────
fallos = 0
for z in ['servidor-completo-para-vercel.zip', 'mi-app-entrenos-server-CORREGIDO.zip',
          'fix-whatsapp-extras.zip']:
    with zipfile.ZipFile(z) as zf:
        nombres = zf.namelist()
        if len(nombres) != len(set(nombres)):
            print('DUPLICADOS en', z); fallos += 1
        if any('node_modules' in n for n in nombres):
            print('node_modules en', z); fallos += 1
        # hashes contra el árbol
        for rel, data in ARBOL.items():
            for cand in (rel, 'mi-app-entrenos-main/' + rel, 'SERVER/' + rel):
                if cand in nombres:
                    if sha(zf.read(cand)) != sha(data):
                        print('HASH DISTINTO', z, cand); fallos += 1
        if z == 'servidor-completo-para-vercel.zip':
            faltan = [e for e in esperados_clave + [DOC] if e not in nombres]
            if faltan:
                print('FALTAN en', z, faltan); fallos += 1
            viejas = [n for n in nombres if n.startswith('api/') and n != 'api/[...path].js']
            if viejas:
                print('RUTAS VIEJAS en', z, viejas); fallos += 1
        if z == 'fix-whatsapp-extras.zip':
            if VIEJAS_SERVER & set(nombres):
                print('rutas viejas SERVER aún presentes en', z); fallos += 1
            for e in ['SERVER/api/[...path].js', 'SERVER/vercel.json',
                      'SERVER/handlers/social/link-preview.js',
                      'SERVER/lib/linkPreviewParse.js', DOC, 'tests/dispatcher-test.js',
                      'firestore.rules', 'APP/services/avatarCache.js']:
                if e not in nombres:
                    print('FALTA en', z, e); fallos += 1
print('VERIFICACIÓN:', 'SIN FALLOS' if fallos == 0 else '%d FALLOS' % fallos)
raise SystemExit(1 if fallos else 0)
