#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regenera los ZIPs de entrega con el cambio a historial permanente:
- SocialScreen.js / chatStore.js nuevos (app)
- purge.js opcional desactivado por defecto (server)
- vercel.json FUERA (ya no hay cron)
Preserva el resto de entradas y sus bytes exactos.
"""
import io, os, shutil, zipfile

APP = 'proyecto/mi-app-entrenos'
SRV = 'workspace-anterior/vercel-server/mi-app-entrenos-main'

def blob(p):
    with open(p, 'rb') as f:
        return f.read()

SOCIAL = blob(os.path.join(APP, 'screens', 'SocialScreen.js'))
CHATSTORE = blob(os.path.join(APP, 'services', 'chatStore.js'))
PURGE = blob(os.path.join(SRV, 'api', 'social', 'purge.js'))
MD = blob('CHAT-SYNC-SETUP.md')

# zip -> { entrada: bytes_nuevos }; entradas en DROP se eliminan
PLAN = {
    'fix-chat-sync.zip': (
        {
            'APP/screens/SocialScreen.js': SOCIAL,
            'APP/services/chatStore.js': CHATSTORE,
            'SERVER/api/social/purge.js': PURGE,
            'CHAT-SYNC-SETUP.md': MD,
        },
        ['SERVER/vercel.json'],
    ),
    'servidor-completo-para-vercel.zip': (
        {'api/social/purge.js': PURGE},
        ['vercel.json'],
    ),
    'mi-app-entrenos-server-CORREGIDO.zip': (
        {'mi-app-entrenos-main/api/social/purge.js': PURGE},
        ['mi-app-entrenos-main/vercel.json'],
    ),
    'mi-app-entrenos-CORREGIDO.zip': (
        {'screens/SocialScreen.js': SOCIAL, 'services/chatStore.js': CHATSTORE},
        [],
    ),
    'mi-app-entrenos-PROYECTO-CORREGIDO.zip': (
        {'mi-app-entrenos/screens/SocialScreen.js': SOCIAL,
         'mi-app-entrenos/services/chatStore.js': CHATSTORE},
        [],
    ),
}

for zname, (repl, drop) in PLAN.items():
    src = zipfile.ZipFile(zname, 'r')
    tmp = zname + '.tmp'
    seen = set()
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as out:
        for item in src.infolist():
            if item.filename in drop:
                continue
            data = repl[item.filename] if item.filename in repl else src.read(item.filename)
            if item.filename in repl:
                seen.add(item.filename)
            out.writestr(item.filename, data)
        faltan = set(repl) - seen
        if faltan:
            raise SystemExit('%s: entradas no encontradas: %s' % (zname, sorted(faltan)))
    src.close()
    shutil.move(tmp, zname)
    n = len(zipfile.ZipFile(zname).namelist())
    print('OK %-45s %2d entradas (reemplazadas %d, eliminadas %d)' % (zname, n, len(seen), len(drop)))

# Staging antiguos: borrar vercel.json obsoleto y sincronizar SocialScreen viejo
if os.path.exists('entrega-server/vercel.json'):
    os.remove('entrega-server/vercel.json')
    print('OK entrega-server/vercel.json obsoleto eliminado')
p = 'entrega-social/app/screens/SocialScreen.js'
if os.path.exists(p):
    with open(p, 'wb') as f:
        f.write(SOCIAL)
    print('OK entrega-social/app/screens/SocialScreen.js sincronizado')
print('TODO OK')
