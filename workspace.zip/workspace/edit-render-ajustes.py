#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Rendimiento: Ajustes tardaba ~0,5 s en abrir porque la tarjeta oculta de
compartir (SVG completo + icono PNG de 438 KB + foto) se montaba en el primer
render de la pantalla. Cambios:
  1) La tarjeta se monta EN DIFERIDO con InteractionManager.runAfterInteractions
     (cuando la animación de apertura ya terminó): abrir Ajustes es inmediato.
  2) El sello usa assets/images/icon-small.png (128 px, 18 KB) en vez del
     icon.png de 1024 px/438 KB: el montaje diferido también es mucho más leve.
  3) Si se pulsa compartir antes del montaje (tap ultrarrápido), se monta al
     vuelo y se espera un tick antes de capturar.
"""
import os

WS = os.environ.get("ARENA_WORKSPACE", os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(WS, "proyecto", "mi-app-entrenos", "screens", "SettingsScreen.js")

raw = open(P, "rb").read().decode("utf-8")
CRLF = "\r\n" in raw
s = raw.replace("\r\n", "\n") if CRLF else raw
n0 = len(s)

def rep(old, new, count=1):
    global s
    assert s.count(old) >= count, "NO ENCONTRADO: %r..." % old[:90]
    s = s.replace(old, new, count)

# ── 1) Imports: useEffect e InteractionManager ──
rep("""import { useCallback, useMemo, useRef, useState } from 'react';
""",
"""import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
""")
rep("""import {
  Alert, Image, Modal,
""",
"""import {
  Alert, Image, InteractionManager, Modal,
""")

# ── 2) Montaje diferido de la tarjeta ──
rep("""  const [profile, setProfile] = useState(null);
""",
"""  const [profile, setProfile] = useState(null);

  // La tarjeta de compartir se monta DESPUÉS de que la pantalla termine de
  // abrirse: su artwork SVG y sus imágenes no frenan la entrada en Ajustes.
  const [cardMounted, setCardMounted] = useState(false);
  useEffect(() => {
    const task = InteractionManager.runAfterInteractions(() => setCardMounted(true));
    return () => task.cancel();
  }, []);
""")

# ── 3) Guard en compartir: monta al vuelo si aún no está ──
rep("""  const handleShareProfile = async () => {
    try {
      if (shareCardRef.current) {
""",
"""  const handleShareProfile = async () => {
    try {
      if (!shareCardRef.current) {          // tap ultrarrápido: montar y dar un tick
        setCardMounted(true);
        await new Promise((r) => setTimeout(r, 150));
      }
      if (shareCardRef.current) {
""")

# ── 4) Sello con la versión ligera del icono ──
rep("""              source={require('../assets/images/icon.png')}   // logo cuadrado de la app
""",
"""              source={require('../assets/images/icon-small.png')}  // logo ligero (128 px)
""")

# ── 5) Envolver el ViewShot en cardMounted ──
i0 = s.index("      <ViewShot\n")
i1 = s.index("      </ViewShot>\n") + len("      </ViewShot>\n")
bloque = s[i0:i1]
s = s[:i0] + "      {cardMounted && (\n" + bloque + "      )}\n" + s[i1:]

out = s.replace("\n", "\r\n") if CRLF else s
open(P, "wb").write(out.encode("utf-8"))
print("OK: SettingsScreen.js (%d → %d bytes, CRLF=%s)" % (n0, len(s), CRLF))
