#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""PAQUETE WHATSAPP 2 — enlaces + previsualizaciones, encuestas en vivo,
avatares con caché local y borrado de media en R2.

Ediciones sobre CRLF exacto con recuento verificado (cualquier fallo = abortar):
  · screens/SocialScreen.js  (chat: todo el paquete)
  · screens/ProfileScreen.js (publica avatar en R2 al guardar la foto)
  · firestore.rules          (colección ligera `avatares`)
"""
import sys

def leer(p):
    with open(p, 'rb') as f:
        return f.read().decode('utf-8')

def escribir(p, s):
    with open(p, 'wb') as f:
        f.write(s.encode('utf-8'))

def sust(src, viejo, nuevo, n=1, etiqueta=''):
    c = src.count(viejo)
    if c != n:
        raise SystemExit('FALLO [%s]: encontrado %d veces, esperaba %d' % (etiqueta, c, n))
    print('ok   %-52s (%d)' % (etiqueta, c))
    return src.replace(viejo, nuevo)

SOCIAL = 'proyecto/mi-app-entrenos/screens/SocialScreen.js'
PERFIL = 'proyecto/mi-app-entrenos/screens/ProfileScreen.js'
RULES  = 'firestore.rules'
CR = '\r\n'

# ══════════════════════ SocialScreen.js ══════════════════════
s = leer(SOCIAL)

# 1) Cabecera documentada
s = sust(s,
    '   · Eliminar = borrado lógico (eliminado:true): los demás ven "Mensaje' + CR +
    '     eliminado".' + CR,
    '   · Eliminar = borrado lógico (eliminado:true): los demás ven "Mensaje' + CR +
    '     eliminado". Si el mensaje tenía imagen/archivo, el borrado pasa por el' + CR +
    '     servidor (api/social/delete-message.js), que elimina TAMBIÉN el objeto' + CR +
    '     de Cloudflare R2 — solo si ningún otro mensaje vivo lo referencia (los' + CR +
    '     reenvíos comparten URL y no se rompen). Sin servidor desplegado, la app' + CR +
    '     hace el borrado lógico de siempre como respaldo.' + CR +
    '   · Enlaces PINCHABLES en el texto (azul + subrayado, patrón WhatsApp) y' + CR +
    '     PREVISUALIZACIÓN Open Graph generada en el lado del EMISOR: al enviar,' + CR +
    '     la app pide los metadatos al servidor (api/social/link-preview.js, con' + CR +
    '     protección SSRF) y los adjunta al mensaje (campo preview); el receptor' + CR +
    '     pinta la tarjeta (imagen + título + dominio) sin descargar nada.' + CR +
    '     Mensajes antiguos sin preview: se piden una vez y se cachean 7 días' + CR +
    '     (services/linkPreview.js).' + CR +
    '   · Encuestas estilo WhatsApp: resultados EN VIVO (listener propio por' + CR +
    '     documento: los votos de los demás llegan al instante aunque la' + CR +
    '     encuesta sea antigua), voto optimista en pantalla, barras de color por' + CR +
    '     opción e insignia "GANANDO" en la líder (recuento en' + CR +
    '     services/encuestas.js).' + CR +
    '   · Foto de perfil en la burbuja con CACHÉ LOCAL (services/avatarCache.js,' + CR +
    '     patrón WhatsApp): la foto se descarga UNA vez a disco y se pinta desde' + CR +
    '     ahí; solo se vuelve a descargar cuando la persona cambia su foto (doc' + CR +
    '     ligero avatares/<uid> con la URL en R2; los perfiles antiguos sin doc' + CR +
    '     usan un respaldo con TTL de 6 h).' + CR,
    1, 'cabecera')

# 2) olvidarMediaLocal tras la caché de disco
s = sust(s,
    '  inflight.set(url, pr);' + CR +
    '  pr.catch(() => {}).then(() => inflight.delete(url));' + CR +
    '  return pr;' + CR +
    '}' + CR,
    '  inflight.set(url, pr);' + CR +
    '  pr.catch(() => {}).then(() => inflight.delete(url));' + CR +
    '  return pr;' + CR +
    '}' + CR +
    CR +
    '/* Al eliminar un mensaje con media se olvidan sus archivos locales: las' + CR +
    '   imágenes/audios borrados dejan de ocupar espacio en el dispositivo. */' + CR +
    'function olvidarMediaLocal(urls) {' + CR +
    '  for (const u of (urls || [])) {' + CR +
    '    try {' + CR +
    '      diskCache.delete(u);' + CR +
    '      const f = localFor(u);' + CR +
    '      FileSystem.deleteAsync(f, { idempotent: true }).catch(() => {});' + CR +
    '      FileSystem.deleteAsync(f + \'.part\', { idempotent: true }).catch(() => {});' + CR +
    '    } catch (e) {}' + CR +
    '  }' + CR +
    '}' + CR,
    1, 'olvidarMediaLocal')

# 3) votarEncuesta antes de responder()
s = sust(s,
    '  const responder = (post) => {',
    '  /* Voto de encuesta (patrón WhatsApp): optimista EN PANTALLA al instante' + CR +
    '     (antes el voto no se reflejaba hasta refrescar), persistido en el' + CR +
    '     almacén local y en Firestore. El listener en vivo de encuestas (más' + CR +
    '     abajo) devuelve los votos de los demás aunque la encuesta sea antigua. */' + CR +
    '  const votarEncuesta = useCallback((post, idxOpcion) => {' + CR +
    '    if (!post || !post.encuesta) return;' + CR +
    '    const votos = { ...(post.encuesta.votos || {}), [me.uid]: idxOpcion };' + CR +
    '    const nuevo = { ...post, encuesta: { ...post.encuesta, votos } };' + CR +
    '    setPosts((ps) => ps.map((x) => (x.id === post.id ? nuevo : x)));' + CR +
    '    chatStorePut(nuevo).catch(() => {});' + CR +
    '    updateDoc(doc(db, \'posts\', post.id), { [`encuesta.votos.${me.uid}`]: idxOpcion })' + CR +
    '      .catch((e) => console.warn(\'[social] voto:\', e.message));' + CR +
    '  }, [me.uid]);' + CR +
    CR +
    '  const responder = (post) => {',
    1, 'votarEncuesta')

# 4) eliminarVarios: servidor (borra R2) + respaldo lógico + limpieza local
viejo_elim = (
    "      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: async () => {" + CR +
    '        try {' + CR +
    "          const parche = { eliminado: true, texto: '', media: [], encuesta: null, reacciones: {} };" + CR +
    "          for (const post of list) await updateDoc(doc(db, 'posts', post.id), parche);" + CR +
    '          await chatStorePut(list.map((p) => ({ ...p, ...parche })));' + CR +
    '          setPosts(await chatStoreAll());' + CR +
    '        } catch (e) {}' + CR +
    '      } },')
nuevo_elim = (
    "      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: async () => {" + CR +
    "        const parche = { eliminado: true, texto: '', media: [], encuesta: null, preview: null, reacciones: {} };" + CR +
    '        // URLs de R2 de la media (original + miniatura) de los mensajes' + CR +
    '        const urls = [];' + CR +
    '        for (const post of list) for (const m of (post.media || [])) {' + CR +
    '          if (m && m.url) urls.push(m.url);' + CR +
    '          if (m && m.thumbUrl) urls.push(m.thumbUrl);' + CR +
    '        }' + CR +
    '        // Con media, el borrado pasa por el SERVIDOR: marca eliminado Y borra' + CR +
    '        // los objetos de R2 que ningún otro mensaje vivo referencie (los' + CR +
    '        // reenvíos comparten URL y no se rompen).' + CR +
    '        let hechoEnServidor = false;' + CR +
    '        if (urls.length) {' + CR +
    '          try {' + CR +
    "            const apiUrl = (await getApiUrl()).replace(/\\/+$/, '');" + CR +
    '            const token = await me.getIdToken();' + CR +
    '            const r = await fetch(`${apiUrl}/social/delete-message`, {' + CR +
    "              method: 'POST'," + CR +
    "              headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }," + CR +
    '              body: JSON.stringify({ postIds: list.map((p) => p.id) }),' + CR +
    '            });' + CR +
    '            const d = await r.json().catch(() => null);' + CR +
    '            hechoEnServidor = !!(r.ok && d && d.ok);' + CR +
    '          } catch (e) { hechoEnServidor = false; }' + CR +
    '        }' + CR +
    '        if (!hechoEnServidor) {' + CR +
    '          // Respaldo (servidor sin desplegar o mensajes solo de texto):' + CR +
    '          // borrado lógico directo, como siempre' + CR +
    "          try { for (const post of list) await updateDoc(doc(db, 'posts', post.id), parche); } catch (e) {}" + CR +
    '        }' + CR +
    '        try {' + CR +
    '          await chatStorePut(list.map((p) => ({ ...p, ...parche })));' + CR +
    '          olvidarMediaLocal(urls);   // libera el disco local de la media borrada' + CR +
    '          setPosts(await chatStoreAll());' + CR +
    '        } catch (e) {}' + CR +
    '      } },')
s = sust(s, viejo_elim, nuevo_elim, 1, 'eliminarVarios')

# 5) Effects: avatares + encuestas en vivo (tras el listener principal)
s = sust(s,
    '  }, [tab, reloadFromStore]);' + CR,
    '  }, [tab, reloadFromStore]);' + CR +
    CR +
    '  /* Fotos de perfil (patrón WhatsApp): la caché se inicializa una vez y se' + CR +
    '     sincroniza con debounce cuando cambian los autores visibles. No descarga' + CR +
    '     nada si nada cambió: lee los docs ligeros avatares/<uid> (url) y solo' + CR +
    '     baja el archivo cuando la URL es nueva. */' + CR +
    '  useEffect(() => { avatarCacheInit(); }, []);' + CR +
    '  useEffect(() => {' + CR +
    "    if (tab !== 'tablon' || posts.length === 0) return undefined;" + CR +
    '    const uids = [...new Set(posts.map((p) => p.autorUid).filter(Boolean))];' + CR +
    '    const t = setTimeout(() => { sincronizarAvatares(uids, me.uid).catch(() => {}); }, 600);' + CR +
    '    return () => clearTimeout(t);' + CR +
    '  }, [posts, tab]);' + CR +
    CR +
    '  /* Encuestas EN VIVO (WhatsApp): el listener principal solo cubre mensajes' + CR +
    '     nuevos (createdAt > lastSync), así que los votos en encuestas antiguas' + CR +
    '     no llegaban. Aquí se suscribe por documento a las encuestas cargadas' + CR +
    '     (máx. 12): cada voto de cualquier persona entra al instante. La clave' + CR +
    '     del effect es la huella (id + si tiene encuesta), de modo que los votos' + CR +
    '     recibidos NO re-suscriben (evita bucles). */' + CR +
    '  useEffect(() => {' + CR +
    "    if (tab !== 'tablon') return undefined;" + CR +
    '    const conEnc = posts.filter((p) => p.encuesta && !p.eliminado).slice(-12);' + CR +
    '    if (conEnc.length === 0) return undefined;' + CR +
    '    let vivo = true;' + CR +
    '    const unsubs = [];' + CR +
    '    for (const pe of conEnc) {' + CR +
    '      try {' + CR +
    "        const u = onSnapshot(doc(db, 'posts', pe.id), (snap) => {" + CR +
    '          if (!vivo || !snap.exists()) return;' + CR +
    '          const nuevo = { id: pe.id, ...snap.data() };' + CR +
    '          chatStorePut(nuevo).catch(() => {});' + CR +
    '          setPosts((ps) => ps.map((x) => (x.id === nuevo.id ? { ...x, ...nuevo } : x)));' + CR +
    '        }, () => {});' + CR +
    '        unsubs.push(u);' + CR +
    '      } catch (e) {}' + CR +
    '    }' + CR +
    "    return () => { vivo = false; for (const u of unsubs) { try { u(); } catch (e) {} } };" + CR +
    "  }, [posts.map((p) => `${p.id}:${p.encuesta ? 'e' : ''}`).join('|'), tab]);" + CR,
    1, 'effects avatares + encuestas')

# 6) onRefresh: refresco forzado de avatares
s = sust(s,
    '      await reloadFromStore();' + CR +
    '      await loadRetos();' + CR,
    '      const all = await reloadFromStore();' + CR +
    '      await loadRetos();' + CR +
    '      // Refresco forzado de fotos de perfil (solo descarga las que cambiaron)' + CR +
    '      sincronizarAvatares([...new Set(all.map((x) => x.autorUid).filter(Boolean))], me.uid, { force: true }).catch(() => {});' + CR,
    1, 'onRefresh avatares')

# 7) Burbuja: firma + onVote
s = sust(s,
    'function Burbuja({ p, me, c, loc, isLight, onLongPress, onOpenImage, selected, highlighted, onTapReply }) {',
    'function Burbuja({ p, me, c, loc, isLight, onLongPress, onOpenImage, selected, highlighted, onTapReply, onVote }) {',
    1, 'firma Burbuja')

# 8) Avatar rama eliminado
s = sust(s,
    '        {!mio && (' + CR +
    '          <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: colorDe(p.autorUid), alignItems: \'center\', justifyContent: \'center\', marginRight: 7, alignSelf: \'flex-end\', opacity: 0.45 }}>' + CR +
    "            <Text style={{ color: '#fff', fontWeight: '800', fontSize: 14 }}>{(p.autorNombre || '?').charAt(0).toUpperCase()}</Text>" + CR +
    '          </View>' + CR +
    '        )}',
    '        {!mio && <AvatarChat uid={p.autorUid} nombre={p.autorNombre} dim />}',
    1, 'avatar eliminado')

# 9) Avatar rama normal
s = sust(s,
    '      {!mio && (' + CR +
    '        <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: colorDe(p.autorUid), alignItems: \'center\', justifyContent: \'center\', marginRight: 7, alignSelf: \'flex-end\' }}>' + CR +
    "          <Text style={{ color: '#fff', fontWeight: '800', fontSize: 14 }}>{(p.autorNombre || '?').charAt(0).toUpperCase()}</Text>" + CR +
    '        </View>' + CR +
    '      )}',
    '      {!mio && <AvatarChat uid={p.autorUid} nombre={p.autorNombre} />}',
    1, 'avatar normal')

# 10) Anchura de burbuja con encuesta
s = sust(s,
    "        style={{ maxWidth: '78%', borderRadius: 14, backgroundColor: mio ? c.bubbleOwn : c.bubbleOther,",
    "        style={{ maxWidth: p.encuesta ? '94%' : '78%', borderRadius: 14, backgroundColor: mio ? c.bubbleOwn : c.bubbleOther,",
    1, 'ancho burbuja encuesta')

# 11) Texto con enlaces + previsualización
s = sust(s,
    '        {!!p.texto && <Text style={{ color: c.txtBubble, fontSize: 15, lineHeight: 21 }}>{p.texto}</Text>}',
    '        <VistaPrevia p={p} c={c} isLight={isLight} />' + CR +
    '        {!!p.texto && <TextoEnlaces texto={p.texto} c={c} isLight={isLight} />}',
    1, 'texto enlaces + preview')

# 12) Encuesta con isLight + onVotar
s = sust(s,
    '        {p.encuesta && <EncuestaBurbuja p={p} c={c} me={me} />}',
    '        {p.encuesta && <EncuestaBurbuja p={p} c={c} me={me} isLight={isLight} onVotar={onVote} />}',
    1, 'props EncuestaBurbuja')

# 13) Componentes nuevos (AvatarChat, TextoEnlaces, VistaPrevia) antes de FotoBurbuja
marcador_foto = '/* ── Imagen de burbuja: pinta la MINIATURA 640 px (thumbUrl) con expo-image'
nuevos = (
    '/* ── Avatar del chat (patrón WhatsApp, services/avatarCache.js): pinta la' + CR +
    '      foto desde el DISCO local (se descargó una sola vez); si la persona' + CR +
    '      cambia su foto, la caché la vuelve a bajar y este componente se' + CR +
    '      redibuja solo (useAvatar). Sin foto (o archivo dañado): inicial' + CR +
    '      coloreada de siempre. ── */' + CR +
    'function AvatarChat({ uid, nombre, dim }) {' + CR +
    '  const uri = useAvatar(uid);' + CR +
    '  const [falla, setFalla] = useState(false);' + CR +
    '  useEffect(() => { setFalla(false); }, [uri]);' + CR +
    "  const base = { width: 32, height: 32, borderRadius: 16, marginRight: 7, alignSelf: 'flex-end', overflow: 'hidden', opacity: dim ? 0.45 : 1 };" + CR +
    '  if (uri && !falla) {' + CR +
    '    return (' + CR +
    '      <View style={[base, { backgroundColor: colorDe(uid) }]}>' + CR +
    '        <ExpoImage source={{ uri }} style={{ width: 32, height: 32 }} contentFit="cover" cachePolicy="memory-disk" transition={120} onError={() => setFalla(true)} />' + CR +
    '      </View>' + CR +
    '    );' + CR +
    '  }' + CR +
    '  return (' + CR +
    "    <View style={[base, { backgroundColor: colorDe(uid), alignItems: 'center', justifyContent: 'center' }]}>" + CR +
    "      <Text style={{ color: '#fff', fontWeight: '800', fontSize: 14 }}>{(nombre || '?').charAt(0).toUpperCase()}</Text>" + CR +
    '    </View>' + CR +
    '  );' + CR +
    '}' + CR +
    CR +
    '/* ── Texto con enlaces pinchables (WhatsApp): las URLs del mensaje se' + CR +
    '      detectan (services/enlaces.js, puro y con tests), se pintan en azul +' + CR +
    '      subrayado y al tocarlas se abren en el navegador. La pulsación larga' + CR +
    '      sigue llegando al Pressable padre (selección del mensaje). ── */' + CR +
    'function TextoEnlaces({ texto, c, isLight }) {' + CR +
    '  const segs = useMemo(() => segmentar(texto), [texto]);' + CR +
    "  const colorLink = isLight ? '#027EB5' : '#53BDEB';" + CR +
    '  const abrir = (u) => { try { Linking.openURL(normalizarUrl(u)); } catch (e) {} };' + CR +
    '  return (' + CR +
    '    <Text style={{ color: c.txtBubble, fontSize: 15, lineHeight: 21 }}>' + CR +
    '      {segs.map((sg, i) => (sg.url ? (' + CR +
    "        <Text key={i} style={{ color: colorLink, textDecorationLine: 'underline' }} onPress={() => abrir(sg.v)}>{sg.v}</Text>" + CR +
    '      ) : (' + CR +
    '        <Text key={i}>{sg.v}</Text>' + CR +
    '      )))}' + CR +
    '    </Text>' + CR +
    '  );' + CR +
    '}' + CR +
    CR +
    '/* ── Tarjeta de previsualización de enlace (WhatsApp): miniatura + título +' + CR +
    '      descripción + dominio, tocables. Los datos viajan ADJUNTOS al mensaje' + CR +
    '      (campo preview, generados por quien lo envía); los mensajes antiguos' + CR +
    '      sin preview lo piden una sola vez al servidor y lo cachean 7 días' + CR +
    '      (services/linkPreview.js). Con fotos/archivos en el mensaje no se' + CR +
    '      muestra (WhatsApp solo despliega enlaces de texto). ── */' + CR +
    'function VistaPrevia({ p, c, isLight }) {' + CR +
    "  const urlTxt = useMemo(() => primeraUrl(p.texto || ''), [p.texto]);" + CR +
    '  const [prev, setPrev] = useState(() => ((p.preview && (p.preview.titulo || p.preview.imagen)) ? p.preview : null));' + CR +
    '  useEffect(() => {' + CR +
    '    setPrev((p.preview && (p.preview.titulo || p.preview.imagen)) ? p.preview : null);' + CR +
    '  }, [p.preview]);' + CR +
    '  useEffect(() => {' + CR +
    '    if (prev || !urlTxt || (p.media || []).length) return undefined;' + CR +
    '    let vivo = true;' + CR +
    '    obtenerPreview(urlTxt).then((r) => { if (vivo && r) setPrev(r); }).catch(() => {});' + CR +
    '    return () => { vivo = false; };' + CR +
    '  }, [urlTxt, prev, p.media]);' + CR +
    '  if (!urlTxt || (p.media || []).length) return null;' + CR +
    '  if (!prev || (!prev.titulo && !prev.imagen)) return null;' + CR +
    "  const colorLink = isLight ? '#027EB5' : '#53BDEB';" + CR +
    '  const dominio = prev.dominio || dominioDe(prev.url || urlTxt);' + CR +
    '  const abrir = () => { try { Linking.openURL(normalizarUrl(prev.url || urlTxt)); } catch (e) {} };' + CR +
    '  return (' + CR +
    '    <TouchableOpacity onPress={abrir} activeOpacity={0.85}' + CR +
    "      style={{ minWidth: 235, maxWidth: 300, marginTop: 2, marginBottom: 5, borderRadius: 12, overflow: 'hidden', backgroundColor: isLight ? '#00000008' : '#FFFFFF10', borderWidth: 1, borderColor: isLight ? '#00000014' : '#FFFFFF1A' }}>" + CR +
    '      {!!prev.imagen && (' + CR +
    "        <ExpoImage source={{ uri: prev.imagen }} style={{ width: '100%', height: 130, backgroundColor: isLight ? '#0000000A' : '#FFFFFF10' }} contentFit=\"cover\" cachePolicy=\"memory-disk\" transition={150} />" + CR +
    '      )}' + CR +
    '      <View style={{ paddingHorizontal: 10, paddingVertical: 8, gap: 3 }}>' + CR +
    "        {!!prev.titulo && <Text numberOfLines={2} style={{ color: c.txtBubble, fontWeight: '800', fontSize: 13.5, lineHeight: 18 }}>{prev.titulo}</Text>}" + CR +
    '        {!!prev.descripcion && <Text numberOfLines={2} style={{ color: c.mut, fontSize: 12, lineHeight: 16 }}>{prev.descripcion}</Text>}' + CR +
    "        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 1 }}>" + CR +
    '          <Ionicons name="link-outline" size={11} color={colorLink} />' + CR +
    "          <Text numberOfLines={1} style={{ color: colorLink, fontSize: 11, fontWeight: '700' }}>{dominio}</Text>" + CR +
    '        </View>' + CR +
    '      </View>' + CR +
    '    </TouchableOpacity>' + CR +
    '  );' + CR +
    '}' + CR +
    CR)
s = sust(s, marcador_foto, nuevos + marcador_foto, 1, 'componentes AvatarChat/TextoEnlaces/VistaPrevia')

# 14) EncuestaBurbuja completa (sustitución por marcas)
ini = s.index('/* ── Encuesta dentro de la burbuja ── */')
fin = s.index('/* ── Visor a pantalla completa con ZOOM (pellizco + doble toque) ── */')
encuesta_nueva = (
    '/* ── Encuesta dentro de la burbuja (WhatsApp): cuadro MÁS ANCHO (la burbuja' + CR +
    '      sube a 94% cuando hay encuesta), barra de color por opción, insignia' + CR +
    '      "GANANDO" en la líder (empates: varias), check en tu voto, recuento y' + CR +
    '      porcentajes EN VIVO. Tocar vota; tocar otra opción cambia el voto. ── */' + CR +
    'function EncuestaBurbuja({ p, c, me, isLight, onVotar }) {' + CR +
    '  const enc = p.encuesta || {};' + CR +
    '  const opciones = enc.opciones || [];' + CR +
    '  const r = contarVotos(enc, me);' + CR +
    '  return (' + CR +
    '    <View style={{ minWidth: 255, marginTop: 6, marginBottom: 2, gap: 6 }}>' + CR +
    "      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>" + CR +
    '        <Ionicons name="stats-chart" size={15} color={c.acc} />' + CR +
    "        <Text style={{ color: c.txtBubble, fontWeight: '800', fontSize: 14, flex: 1 }}>{enc.pregunta || 'Encuesta'}</Text>" + CR +
    '      </View>' + CR +
    '      {opciones.map((op, i) => {' + CR +
    '        const color = colorOpcion(i);' + CR +
    '        const n = r.porOpcion[i] || 0;' + CR +
    '        const pct = r.porcentajes[i] || 0;' + CR +
    '        const lider = n > 0 && r.lideres.indexOf(i) >= 0;' + CR +
    '        const mio = r.mio === i;' + CR +
    '        return (' + CR +
    '          <TouchableOpacity key={i} activeOpacity={0.8} onPress={() => { if (onVotar) onVotar(p, i); }}' + CR +
    "            style={{ borderRadius: 11, borderWidth: lider ? 1.8 : 1.2, borderColor: lider ? color : (mio ? c.acc : (isLight ? '#00000022' : '#FFFFFF2E')), backgroundColor: isLight ? '#FFFFFFCC' : '#0C1425CC', overflow: 'hidden' }}>" + CR +
    "            <View style={{ position: 'absolute', top: 0, bottom: 0, left: 0, width: `${pct}%`, backgroundColor: color + (lider ? '66' : '33') }} />" + CR +
    "            <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 9, gap: 7 }}>" + CR +
    "              <Text style={{ flex: 1, color: c.txtBubble, fontSize: 13, fontWeight: lider ? '800' : '600' }} numberOfLines={2}>{op}</Text>" + CR +
    '              {lider && (' + CR +
    '                <View style={{ backgroundColor: color, borderRadius: 999, paddingHorizontal: 6, paddingVertical: 1.5 }}>' + CR +
    "                  <Text style={{ color: '#fff', fontSize: 9, fontWeight: '800', letterSpacing: 0.4 }}>GANANDO</Text>" + CR +
    '                </View>' + CR +
    '              )}' + CR +
    '              {mio && <Ionicons name="checkmark-circle" size={16} color={c.acc} />}' + CR +
    "              <Text style={{ color: c.mut, fontSize: 11.5, fontWeight: '700' }}>{n > 0 ? `${pct}% · ${n}` : '—'}</Text>" + CR +
    '            </View>' + CR +
    '          </TouchableOpacity>' + CR +
    '        );' + CR +
    '      })}' + CR +
    '      <Text style={{ color: c.mut, fontSize: 11 }}>' + CR +
    "        {r.total === 1 ? '1 voto' : `${r.total} votos`} · {r.mio != null ? 'toca otra opción para cambiar tu voto' : 'toca una opción para votar'}" + CR +
    '      </Text>' + CR +
    '    </View>' + CR +
    '  );' + CR +
    '}' + CR +
    CR)
print('ok   %-52s (%d)' % ('EncuestaBurbuja reemplazada', 1))
s = s[:ini] + encuesta_nueva + s[fin:]

# 15) publicar(): preview del emisor + campo en el doc y copia local
s = sust(s,
    '      const iso = new Date().toISOString();' + CR +
    '      const encFinal = encuesta && encuesta.pregunta.trim()',
    '      // Previsualización de enlace estilo WhatsApp: se genera en el lado del' + CR +
    '      // EMISOR (el servidor obtiene el Open Graph y se adjunta al mensaje;' + CR +
    '      // los receptores no descargan nada). Tope de 3.5 s: si no llega, el' + CR +
    '      // mensaje se envía igual sin preview.' + CR +
    '      let preview = null;' + CR +
    '      const urlEnTexto = primeraUrl(texto);' + CR +
    '      if (urlEnTexto && mediaUp.length === 0) {' + CR +
    '        try { preview = await previewParaEnvio(urlEnTexto, me); } catch (e) { preview = null; }' + CR +
    '      }' + CR +
    '      const iso = new Date().toISOString();' + CR +
    '      const encFinal = encuesta && encuesta.pregunta.trim()',
    1, 'publicar preview')

s = sust(s,
    '        encuesta: encFinal,' + CR +
    '        reacciones: {},' + CR +
    '        createdAt: iso,',
    '        encuesta: encFinal,' + CR +
    '        preview: preview || null,' + CR +
    '        reacciones: {},' + CR +
    '        createdAt: iso,',
    2, 'campo preview (addDoc + copia local)')

# 16) reenviarVarios: arrastra el preview del original
s = sust(s,
    '          reenviado: true,' + CR +
    '          encuesta: null,' + CR +
    '          reacciones: {},' + CR +
    '          createdAt: iso,' + CR +
    '        });',
    '          reenviado: true,' + CR +
    '          encuesta: null,' + CR +
    '          preview: post.preview || null,' + CR +
    '          reacciones: {},' + CR +
    '          createdAt: iso,' + CR +
    '        });',
    1, 'reenvío arrastra preview (addDoc)')
s = sust(s,
    '          reenviado: true, encuesta: null, reacciones: {}, createdAt: iso,',
    '          reenviado: true, encuesta: null, preview: post.preview || null, reacciones: {}, createdAt: iso,',
    1, 'reenvío arrastra preview (copia local)')

# 17) Uso de Burbuja en la lista: onVote
s = sust(s,
    '                        onTapReply={irAMensaje}' + CR +
    '                        onLongPress={() => toggleSel(p.id)} onOpenImage={openImage} />',
    '                        onTapReply={irAMensaje} onVote={votarEncuesta}' + CR +
    '                        onLongPress={() => toggleSel(p.id)} onOpenImage={openImage} />',
    1, 'onVote en la lista')

escribir(SOCIAL, s)

# ══════════════════════ ProfileScreen.js ══════════════════════
p = leer(PERFIL)
p = sust(p,
    "import { cacheProfile, clearProfileCache, getCachedProfile, invalidateProfileCache } from '../services/profileCache';",
    "import { cacheProfile, clearProfileCache, getCachedProfile, invalidateProfileCache } from '../services/profileCache';" + CR +
    "import { publicarMiAvatar } from '../services/avatarCache';",
    1, 'perfil: import avatarCache')

p = sust(p,
    '      await cacheProfile(uid, dataToSave);' + CR +
    '      await invalidateProfileCache(uid);' + CR,
    '      await cacheProfile(uid, dataToSave);' + CR +
    '      await invalidateProfileCache(uid);' + CR +
    '      if (fotoBase64) {' + CR +
    '        // Avatar estilo WhatsApp: sube la foto a R2 y publica avatares/<uid>' + CR +
    '        // (doc ligero). Los demás teléfonos la descargan UNA vez y solo' + CR +
    '        // vuelven a bajarla cuando cambie. Si el servidor no está desplegado' + CR +
    '        // no pasa nada: el chat usa el respaldo legacy (base64 de perfiles).' + CR +
    "        publicarMiAvatar(fotoBase64, user).catch((e) => console.warn('[perfil] avatar:', e && e.message));" + CR +
    '      }' + CR,
    1, 'perfil: publica avatar al guardar')

escribir(PERFIL, p)

# ══════════════════════ firestore.rules (LF) ══════════════════════
r = leer(RULES)
viejo_rules = (
    '    match /posts/{postId} {\n'
    '      allow read: if request.auth != null;\n'
    '      allow create: if request.auth != null\n'
    '                    && request.resource.data.autorUid == request.auth.uid;\n'
    '      allow update, delete: if request.auth != null;\n'
    '    }\n')
nuevo_rules = viejo_rules + (
    '\n'
    '    // Fotos de perfil del chat (patrón WhatsApp): documento ligero con la\n'
    '    // URL de la foto en R2. Todos los autenticados leen (el chat pinta las\n'
    '    // fotos); escribe únicamente el dueño. La foto en sí vive en R2 y se\n'
    '    // descarga una sola vez por teléfono (avatares/<uid> solo avisa de\n'
    '    // cambios: si la URL no varía, no se descarga nada).\n'
    '    match /avatares/{userId} {\n'
    '      allow read: if request.auth != null;\n'
    '      allow write: if request.auth != null && request.auth.uid == userId;\n'
    '    }\n')
c = r.count(viejo_rules)
if c != 1:
    raise SystemExit('FALLO [rules posts]: %d' % c)
r = r.replace(viejo_rules, nuevo_rules)
print('ok   %-52s (1)' % 'firestore.rules: avatares')
escribir(RULES, r)

# Servidor: el parche de borrado también limpia `preview`
DM = 'workspace-anterior/vercel-server/mi-app-entrenos-main/api/social/delete-message.js'
d = leer(DM)
d = sust(d,
    "const PARCHE = { eliminado: true, texto: '', media: [], encuesta: null, reacciones: {} };",
    "const PARCHE = { eliminado: true, texto: '', media: [], encuesta: null, preview: null, reacciones: {} };",
    1, 'servidor: PARCHE limpia preview')
escribir(DM, d)

# ══════════════════════ Verificación CRLF ══════════════════════
for f in (SOCIAL, PERFIL):
    data = open(f, 'rb').read()
    lf_sueltos = data.count(b'\n') - data.count(b'\r\n')
    if lf_sueltos != 0:
        raise SystemExit('FALLO: %s tiene %d LF sueltos (mezcla de finales)' % (f, lf_sueltos))
    print('ok   %s: CRLF consistente' % f)

print('\nTODO OK')
