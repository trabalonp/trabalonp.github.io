#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Historial permanente: quita la caducidad automática del Tablón.

- SocialScreen.js: ya no escribe expiraAt al publicar/reenviar; textos y
  comentarios actualizados. (CRLF)
- chatStore.js: comentario actualizado. (CRLF)
- purge.js: pasa a ser herramienta opcional DESACTIVADA por defecto
  (RETENTION_DAYS env; 0/ausente = no borra nada). (LF)
- vercel.json del servidor: se elimina (el cron ya no es necesario).
"""
import io, os, sys

def load(p):
    with io.open(p, 'r', encoding='utf-8', newline='') as f:
        return f.read()

def save(p, s):
    with io.open(p, 'w', encoding='utf-8', newline='') as f:
        f.write(s)

def rep(text, old, new, label):
    n = text.count(old)
    if n == 0 and new and text.count(new) >= 1:
        print('  (ya aplicado: %s)' % label)   # idempotente al reejecutar
        return text
    if n != 1:
        raise SystemExit('FALLO %s: %d ocurrencias (esperaba 1)' % (label, n))
    return text.replace(old, new)

APP = 'proyecto/mi-app-entrenos'
SRV = 'workspace-anterior/vercel-server/mi-app-entrenos-main'

# ─────────────────────────── SocialScreen.js (CRLF) ───────────────────────────
p = os.path.join(APP, 'screens', 'SocialScreen.js')
s = load(p)

s = rep(s,
"   · Listener en vivo con docChanges(): added/modified se fusionan en el\r\n"
"     almacén local; removed (purga por caducidad) se ignora a propósito.\r\n"
"   · Caducidad tipo WhatsApp: cada mensaje nace con expiraAt = +30 días y el\r\n"
"     servidor (cron api/social/purge) lo borra de Firestore al caducar; los\r\n"
"     dispositivos que lo recibieron LO CONSERVAN en su copia local.\r\n"
"   · Eliminar = borrado lógico (eliminado:true): los demás ven \"Mensaje\r\n"
"     eliminado\" sin confundirlo con la caducidad.\r\n",
"   · Listener en vivo con docChanges(): added/modified se fusionan en el\r\n"
"     almacén local; removed se ignora a propósito (defensivo: el servidor\r\n"
"     ya no purga mensajes).\r\n"
"   · Historial PERMANENTE: los mensajes no caducan. La sincronización\r\n"
"     incremental ya garantiza que nunca se descarga el chat entero, así que\r\n"
"     el tamaño del historial no aumenta el coste. El endpoint de purga\r\n"
"     (api/social/purge) queda como herramienta opcional, desactivada.\r\n"
"   · Eliminar = borrado lógico (eliminado:true): los demás ven \"Mensaje\r\n"
"     eliminado\".\r\n", 'header')

s = rep(s,
"const DIAS_RETENCION = 30;   // el servidor purga lo anterior; el local lo conserva\r\n",
"", 'const DIAS_RETENCION')

s = rep(s,
"          createdAt: iso,\r\n"
"          expiraAt: Timestamp.fromDate(new Date(Date.now() + DIAS_RETENCION * 86400000)),\r\n"
"        });\r\n",
"          createdAt: iso,\r\n"
"        });\r\n", 'expiraAt reenvío')

s = rep(s,
"     4) Listener en vivo con docChanges(): added/modified se fusionan en el\r\n"
"        almacén; removed (purga por caducidad en el servidor) se IGNORA a\r\n"
"        propósito: la copia local se conserva, como en WhatsApp. */\r\n",
"     4) Listener en vivo con docChanges(): added/modified se fusionan en el\r\n"
"        almacén; removed se IGNORA a propósito: la copia local se conserva\r\n"
"        (el servidor no purga; solo aplicaría ante borrados manuales). */\r\n", 'comentario sync')

s = rep(s,
"  /* Listener en vivo: solo mensajes NUEVOS o MODIFICADOS desde la marca de\r\n"
"     agua. docChanges() da added/modified/removed; removed = caducidad purgada\r\n"
"     en el servidor → se ignora (la copia local permanece). */\r\n",
"  /* Listener en vivo: solo mensajes NUEVOS o MODIFICADOS desde la marca de\r\n"
"     agua. docChanges() da added/modified/removed; removed se ignora: ya no\r\n"
"     hay purga por caducidad y la copia local permanece. */\r\n", 'comentario listener')

s = rep(s,
"                  {L(`Inicio del historial · lo que caduca en el servidor (${DIAS_RETENCION} días) sigue guardado en este dispositivo`, `Start of history · what expires on the server (${DIAS_RETENCION} days) stays on this device`)}\r\n",
"                  {L('Inicio del historial · este es el primer mensaje del chat', 'Start of history · this is the first message of the chat')}\r\n", 'inicio del historial')

s = rep(s,
"        createdAt: iso,\r\n"
"        // CADUCIDAD (TTL): el servidor purgará este mensaje a los 30 días;\r\n"
"        // cada dispositivo conserva su copia local para siempre.\r\n"
"        expiraAt: Timestamp.fromDate(new Date(Date.now() + DIAS_RETENCION * 86400000)),\r\n"
"      });\r\n"
"      // Copia local inmediata: sobrevive a la purga del servidor\r\n",
"        createdAt: iso,\r\n"
"        // Sin caducidad: el historial es permanente (la sincronización es\r\n"
"        // incremental y nunca descarga todo el chat, así que el tamaño no\r\n"
"        // aumenta el coste de uso).\r\n"
"      });\r\n"
"      // Copia local inmediata: se pinta sin esperar al listener\r\n", 'expiraAt publicar')

if 'DIAS_RETENCION' in s or 'expiraAt' in s:
    raise SystemExit('FALLO: quedan referencias a DIAS_RETENCION/expiraAt en SocialScreen.js')
save(p, s)
print('OK SocialScreen.js')

# ─────────────────────────── chatStore.js (CRLF) ───────────────────────────
p = os.path.join(APP, 'services', 'chatStore.js')
s = load(p)
s = rep(s,
"   · Cuando el servidor purga un mensaje caducado (> 1 mes, TTL/cron), el\r\n"
"     listener recibe \"removed\" y NO lo borramos de aquí: la copia local\r\n"
"     sigue visible en el dispositivo, exactamente como se pidió.\r\n",
"   · El servidor NO purga mensajes (historial permanente); los eventos\r\n"
"     \"removed\" del listener se ignoran igualmente por seguridad, así la\r\n"
"     copia local nunca desaparece del dispositivo.\r\n", 'comentario chatStore')
save(p, s)
print('OK chatStore.js')

# ─────────────────────────── purge.js (LF) ───────────────────────────
p = os.path.join(SRV, 'api', 'social', 'purge.js')
s = load(p)

s = rep(s,
"""// api/social/purge.js
// PURGA DE CADUCIDAD DEL CHAT (patrón WhatsApp/temp-chat):
// los mensajes del Tablón nacen con `expiraAt` = createdAt + 30 días. Este
// cron diario elimina de Firestore (y de Cloudflare R2) todo lo caducado.
// Las copias LOCALES de cada dispositivo NO se tocan: quien recibió el
// mensaje lo sigue viendo en su historial (el listener de la app ignora los
// "removed" de caducidad a propósito).
//
// Seguridad: Vercel envía automáticamente `Authorization: Bearer <CRON_SECRET>`
// cuando el planificador invoca el cron (ver vercel.json). Sin ese secreto
// coincidiendo, 401. Crea CRON_SECRET en Vercel → Settings → Environment
// Variables (cadena aleatoria de 16+ caracteres).
//
// Doble criterio de purga (por si una de las dos vías falla):
//   1) expiraAt (Timestamp) < ahora          → mensajes de versiones nuevas
//   2) createdAt (ISO string) < ahora - 31 d → mensajes LEGACY sin expiraAt
""",
"""// api/social/purge.js
// HERRAMIENTA DE PURGA DEL CHAT — OPCIONAL y DESACTIVADA POR DEFECTO.
//
// El Tablón tiene ahora historial PERMANENTE: con la sincronización
// incremental (onSnapshot + createdAt > lastSync + paginación hacia atrás)
// la app nunca descarga el chat entero, así que el tamaño del historial no
// aumenta el coste ni la lentitud. La caducidad automática ya no es
// necesaria. Este endpoint queda dormido como herramienta de mantenimiento
// (p. ej. derecho al olvido, o si algún día se quisiera de nuevo un chat
// de mensajes temporales).
//
// Para ACTIVAR la purga harían falta 3 cosas:
//   1) RETENTION_DAYS=31 en Vercel → Environment Variables (días de vida
//      + margen; 0 o ausente = DESACTIVADO, no borra nada)
//   2) CRON_SECRET (cadena aleatoria de 16+ caracteres)
//   3) Un cron en vercel.json apuntando a /api/social/purge, p. ej.:
//      { "crons": [{ "path": "/api/social/purge", "schedule": "0 4 * * *" }] }
//
// Seguridad: Vercel envía `Authorization: Bearer <CRON_SECRET>` en cada
// invocación programada; sin ese secreto coincidiendo, 401.
//
// Doble criterio de purga (solo cuando está activada):
//   1) expiraAt (Timestamp) < ahora → mensajes antiguos que nacieron con caducidad
//   2) createdAt (ISO string) < ahora - RETENTION_DAYS → el resto
// Las copias LOCALES de cada dispositivo NO se tocan nunca.
""", 'cabecera purge')

s = rep(s,
"""  if (!secreto || auth !== `Bearer ${secreto}`) {
    return res.status(401).json({ error: 'No autorizado' });
  }

  try {
""",
"""  if (!secreto || auth !== `Bearer ${secreto}`) {
    return res.status(401).json({ error: 'No autorizado' });
  }

  // Retención configurable. Por defecto DESACTIVADA: el historial del chat
  // es permanente y este endpoint no borra nada salvo RETENTION_DAYS > 0.
  const dias = Number(process.env.RETENTION_DAYS || 0);
  if (!Number.isFinite(dias) || dias <= 0) {
    console.log('[purge] desactivado (RETENTION_DAYS ausente o 0): no se borra nada');
    return res.json({ ok: true, disabled: true, message: 'Purga desactivada: define RETENTION_DAYS > 0 para activarla' });
  }

  try {
""", 'gate RETENTION_DAYS')

s = rep(s,
"const DIAS_RETENCION = 31;      // 30 días de vida + 1 de margen\n",
"", 'const DIAS_RETENCION purge')

s = rep(s,
"    const corteIso = new Date(ahora - DIAS_RETENCION * 86400000).toISOString();",
"    const corteIso = new Date(ahora - dias * 86400000).toISOString();", 'corteIso')

s = rep(s,
"    // 1) Caducidad explícita (Timestamp)\n",
"    // 1) Caducidad explícita (mensajes antiguos que nacieron con expiraAt)\n", 'comentario criterio 1')
s = rep(s,
"    // 2) Legacy sin expiraAt: por fecha ISO de creación\n",
"    // 2) Sin expiraAt: por fecha ISO de creación (corte = RETENTION_DAYS)\n", 'comentario criterio 2')

if 'DIAS_RETENCION' in s:
    raise SystemExit('FALLO: queda DIAS_RETENCION en purge.js')
save(p, s)
print('OK purge.js')

# ─────────────────────────── vercel.json ───────────────────────────
p = os.path.join(SRV, 'vercel.json')
if os.path.exists(p):
    os.remove(p)
    print('OK vercel.json eliminado (el cron ya no es necesario)')

print('TODO OK')
