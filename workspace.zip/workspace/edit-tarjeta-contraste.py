#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tarjeta compartible dual: sigue el modo de contraste de la app.
  NOCHE → "LA CIMA" (diseño actual: carbón + auroras verdes + estrellas)
  DÍA   → "EL AMANECER" (crema cálido + curvas terracota + sol dorado +
          terreno ocre + ruta verde azulado→coral + pájaros)
Aplica los cambios sobre proyecto/mi-app-entrenos/screens/SettingsScreen.js
preservando los finales de línea originales (CRLF)."""
import os
import re

WS = os.environ.get("ARENA_WORKSPACE", os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(WS, "proyecto", "mi-app-entrenos", "screens", "SettingsScreen.js")

raw = open(P, "rb").read().decode("utf-8")
CRLF = "\r\n" in raw
s = raw.replace("\r\n", "\n") if CRLF else raw
n0 = len(s)

def rep(old, new, count=1):
    global s
    assert s.count(old) >= count, "NO ENCONTRADO: %r..." % old[:80]
    s = s.replace(old, new, count)

# ── 1) PALETAS duales (nivel de módulo, tras las constantes de color) ──
rep("""const INK       = '#0C1310';  // carbón del fondo de la tarjeta
const CREAM     = '#EAF7E6';  // blanco cálido para estrellas y ruta
""",
"""const INK       = '#0C1310';  // carbón del fondo de la tarjeta
const CREAM     = '#EAF7E6';  // blanco cálido para estrellas y ruta

/* ── Paletas duales: la tarjeta sigue el modo de contraste de la app ──
   NOCHE = "LA CIMA": carbón + auroras verdes + cielo estrellado.
   DÍA   = "EL AMANECER": cielo crema, curvas de nivel terracota, sol dorado
           tras la foto, terreno ocre, ruta verde azulado→coral y pájaros
           en lugar de estrellas. Familias de color DISTINTAS (cálida vs
           verde): no es el mismo esquema aclarado, es su propio mapa. ── */
const PALETAS = {
  noche: {
    cardBg: INK,
    sky: ['#0C1B13', INK, '#050806'],
    glow: ['#5FCE73', 0.26, '#3E9B52', 0.10],
    blobB: ['#3E9B52', 0.15],
    blobC: ['#A7E89B', 0.07],
    topo: GREEN,
    topoOp: [0.38, 0.28, 0.20, 0.14, 0.09],
    ridgeFill: [['#081109', 0.5], ['#060C08', 0.65]],
    ridgeStroke: GREEN,
    ridgeBoost: 1,
    ruta: [GREEN_DK, GREEN, CREAM],
    rutaDot: CREAM,
    rutaDotOp: 0.35,
    waypointFill: INK,
    waypointStroke: GREEN,
    pulse: CREAM,
    huella: GREEN,
    bandera: GREEN_LT,
    decor: GREEN,
    dotOp: 0.15,
    cornerOp: 0.7,
    vignette: ['#000000', 0.46],
    astro: CREAM,            // color de las estrellas (noche)
    ave: '#8A6A52',          // (sin uso en noche)
    name: '#F4F8F2',
    underline: GREEN,
    underline2: GREEN + '70',
    pillBg: '#FFFFFF0D',
    pillBorder: '#FFFFFF1F',
    email: '#AEC4B4',
    emailIcon: '#8FAF97',
    dashed: GREEN + '59',
    ringOut: GREEN_LT,
    ringOutBorder: GREEN_DK,
    ringIn: INK,
    fallback: GREEN_DK,
    initial: '#FFFFFF',
  },
  dia: {
    cardBg: '#FFF8EC',
    sky: ['#FFFDF6', '#FDEED4', '#F8DCB4'],
    glow: ['#F6A821', 0.32, '#E8890C', 0.12],
    blobB: ['#E4572E', 0.10],
    blobC: ['#FFC94D', 0.16],
    topo: '#C05F35',
    topoOp: [0.46, 0.34, 0.25, 0.17, 0.11],
    ridgeFill: [['#E3B98D', 0.55], ['#D19E6C', 0.62]],
    ridgeStroke: '#A9552D',
    ridgeBoost: 1.6,
    ruta: ['#0E6E64', '#128C7E', '#E4572E'],
    rutaDot: '#5B3A26',
    rutaDotOp: 0.30,
    waypointFill: '#FFF8EC',
    waypointStroke: '#0E6E64',
    pulse: '#E4572E',
    huella: '#B0714E',
    bandera: '#E4572E',
    decor: '#C05F35',
    dotOp: 0.20,
    cornerOp: 0.65,
    vignette: ['#7A4A28', 0.14],
    astro: '#E8A33D',        // (sin uso en día)
    ave: '#8A6A52',          // color de los pájaros (amanecer)
    name: '#4A2E1C',
    underline: '#E4572E',
    underline2: '#E4572E66',
    pillBg: '#FFFFFFA6',
    pillBorder: '#C05F3540',
    email: '#8A5E42',
    emailIcon: '#C05F35',
    dashed: '#C05F3559',
    ringOut: '#F5B942',
    ringOutBorder: '#B0714E',
    ringIn: '#FFF8EC',
    fallback: '#E8A33D',
    initial: '#FFFFFF',
  },
};
""")

# ── 2) TOPO_OP pasa a vivir en la paleta ──
rep("""const TOPO_RADII = [96, 124, 154, 186, 222];
const TOPO_OP    = [0.38, 0.28, 0.20, 0.14, 0.09];
""",
"""const TOPO_RADII = [96, 124, 154, 186, 222];
""")

# ── 3) Hooks: systemScheme + cardLight + paleta activa ──
rep("""  const lang = appSettings.language;            // re-renderiza al cambiar idioma
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
""",
"""  const lang = appSettings.language;            // re-renderiza al cambiar idioma
  const systemScheme = useColorScheme();
  const theme = getThemeColors(appSettings.themeMode, systemScheme);
  // La tarjeta compartible sigue el modo de contraste de la app:
  // día (o dispositivo en claro) → "EL AMANECER"; si no → "LA CIMA" noche.
  const cardLight = appSettings.themeMode === 'day' || (appSettings.themeMode === 'device' && systemScheme === 'light');
  const P = PALETAS[cardLight ? 'dia' : 'noche'];
""")

# ── 4) Memo del cielo: estrellas (noche) o pájaros (día), único por nombre ──
rep("""  const estrellas = useMemo(() => {
    const rnd = mulberry32(hashStr(firstName + '|cielo'));
    const out = [];
    while (out.length < 18) {
      const x = 14 + rnd() * (CARD_W - 28);
      const y = 14 + rnd() * 246;                       // solo zona de cielo
      if (Math.hypot(x - CARD_W / 2, y - 158) < 112) continue;  // no tapar la foto
      out.push({ x, y, r: 0.7 + rnd() * 1.1, o: 0.10 + rnd() * 0.38 });
    }
    return out;
  }, [firstName]);
""",
"""  const cielo = useMemo(() => {
    const rnd = mulberry32(hashStr(firstName + '|cielo'));
    const out = [];
    if (!cardLight) {
      // NOCHE: estrellas (solo zona de cielo, sin tapar la foto)
      while (out.length < 18) {
        const x = 14 + rnd() * (CARD_W - 28);
        const y = 14 + rnd() * 246;
        if (Math.hypot(x - CARD_W / 2, y - 158) < 112) continue;
        out.push({ x, y, r: 0.7 + rnd() * 1.1, o: 0.10 + rnd() * 0.38 });
      }
      return out;
    }
    // DÍA: pájaros que cruzan el cielo del amanecer (también únicos por nombre)
    while (out.length < 5) {
      const x = 30 + rnd() * (CARD_W - 60);
      const y = 20 + rnd() * 205;
      if (Math.hypot(x - CARD_W / 2, y - 158) < 120) continue;  // no tapar la foto
      out.push({ x, y, s: 0.7 + rnd() * 0.8, rot: -9 + rnd() * 18, o: 0.30 + rnd() * 0.35 });
    }
    return out;
  }, [firstName, cardLight]);
""")

# ── 5) <Defs>: degradados gobernados por la paleta ──
m = re.search(r"            <Defs>.*?            </Defs>\n", s, re.DOTALL)
assert m, "bloque <Defs> no encontrado"
s = s[:m.start()] + """            <Defs>
              <LinearGradient id="tjBg" x1="0" y1="0" x2="0.35" y2="1">
                <Stop offset="0" stopColor={P.sky[0]} />
                <Stop offset="0.55" stopColor={P.sky[1]} />
                <Stop offset="1" stopColor={P.sky[2]} />
              </LinearGradient>
              <RadialGradient id="tjGlow" cx="0.5" cy="0.5" r="0.5">
                <Stop offset="0" stopColor={P.glow[0]} stopOpacity={P.glow[1]} />
                <Stop offset="0.55" stopColor={P.glow[2]} stopOpacity={P.glow[3]} />
                <Stop offset="1" stopColor={P.glow[2]} stopOpacity="0" />
              </RadialGradient>
              <RadialGradient id="tjAuroraB" cx="0.5" cy="0.5" r="0.5">
                <Stop offset="0" stopColor={P.blobB[0]} stopOpacity={P.blobB[1]} />
                <Stop offset="1" stopColor={P.blobB[0]} stopOpacity="0" />
              </RadialGradient>
              <RadialGradient id="tjAuroraC" cx="0.5" cy="0.5" r="0.5">
                <Stop offset="0" stopColor={P.blobC[0]} stopOpacity={P.blobC[1]} />
                <Stop offset="1" stopColor={P.blobC[0]} stopOpacity="0" />
              </RadialGradient>
              <LinearGradient id="tjRuta" gradientUnits="userSpaceOnUse" x1="0" y1="500" x2={CARD_W} y2="350">
                <Stop offset="0" stopColor={P.ruta[0]} />
                <Stop offset="0.5" stopColor={P.ruta[1]} />
                <Stop offset="1" stopColor={P.ruta[2]} />
              </LinearGradient>
              <RadialGradient id="tjVig" cx="0.5" cy="0.45" r="0.78">
                <Stop offset="0.55" stopColor={P.vignette[0]} stopOpacity="0" />
                <Stop offset="1" stopColor={P.vignette[0]} stopOpacity={P.vignette[1]} />
              </RadialGradient>
            </Defs>
""" + s[m.end():]

# ── 6) Cielo: estrellas o pájaros según modo ──
rep("""            {/* Cielo estrellado (único por nombre) */}
            {estrellas.map((s, i) => (
              <Circle key={`st-${i}`} cx={s.x} cy={s.y} r={s.r} fill={CREAM} fillOpacity={s.o} />
            ))}
""",
"""            {/* Cielo (único por nombre): estrellas de noche, pájaros al amanecer */}
            {cardLight
              ? cielo.map((b, i) => (
                  <G
                    key={`ave-${i}`}
                    transform={`translate(${b.x.toFixed(1)} ${b.y.toFixed(1)}) rotate(${b.rot.toFixed(1)}) scale(${b.s.toFixed(2)})`}
                    opacity={b.o}
                  >
                    <Path d="M-7 0 Q-3.5 -4.6 0 -0.6 Q3.5 -4.6 7 0" fill="none" stroke={P.ave} strokeWidth={1.3} strokeLinecap="round" />
                  </G>
                ))
              : cielo.map((s, i) => (
                  <Circle key={`st-${i}`} cx={s.x} cy={s.y} r={s.r} fill={P.astro} fillOpacity={s.o} />
                ))}
""")

# ── 7) Anillos topográficos ──
rep("""                fill="none" stroke={GREEN}
                strokeWidth={i === 0 ? 1.6 : 1.1}
                strokeOpacity={TOPO_OP[i]}
""",
"""                fill="none" stroke={P.topo}
                strokeWidth={i === 0 ? 1.6 : 1.1}
                strokeOpacity={P.topoOp[i]}
""")

# ── 8) Rellenos de terreno ──
rep("""            <Path d={ridgePath(432, 15, seedPhase * 1.3 + 2.1, true)} fill="#081109" fillOpacity={0.5} />
            <Path d={ridgePath(466, 18, seedPhase * 0.8 + 4.4, true)} fill="#060C08" fillOpacity={0.65} />
""",
"""            <Path d={ridgePath(432, 15, seedPhase * 1.3 + 2.1, true)} fill={P.ridgeFill[0][0]} fillOpacity={P.ridgeFill[0][1]} />
            <Path d={ridgePath(466, 18, seedPhase * 0.8 + 4.4, true)} fill={P.ridgeFill[1][0]} fillOpacity={P.ridgeFill[1][1]} />
""")

# ── 9) Curvas de nivel del terreno ──
rep("""                fill="none" stroke={GREEN} strokeWidth={rg.w} strokeOpacity={rg.o}
""",
"""                fill="none" stroke={P.ridgeStroke} strokeWidth={rg.w} strokeOpacity={Math.min(0.45, rg.o * P.ridgeBoost)}
""")

# ── 10) Ruta GPS: punteado, waypoints y pulso final ──
rep("""            <Path d={RUTA_GPS} fill="none" stroke={CREAM} strokeWidth={1.2} strokeOpacity={0.35} strokeDasharray="1 11" strokeLinecap="round" />
            <Circle cx={152} cy={420} r={3} fill={INK} stroke={GREEN} strokeWidth={1.4} strokeOpacity={0.85} />
            <Circle cx={262} cy={448} r={3} fill={INK} stroke={GREEN} strokeWidth={1.4} strokeOpacity={0.85} />
            <Circle cx={396} cy={360} r={9} fill="none" stroke={CREAM} strokeWidth={1} strokeOpacity={0.35} />
            <Circle cx={396} cy={360} r={3.4} fill={CREAM} />
""",
"""            <Path d={RUTA_GPS} fill="none" stroke={P.rutaDot} strokeWidth={1.2} strokeOpacity={P.rutaDotOp} strokeDasharray="1 11" strokeLinecap="round" />
            <Circle cx={152} cy={420} r={3} fill={P.waypointFill} stroke={P.waypointStroke} strokeWidth={1.4} strokeOpacity={0.85} />
            <Circle cx={262} cy={448} r={3} fill={P.waypointFill} stroke={P.waypointStroke} strokeWidth={1.4} strokeOpacity={0.85} />
            <Circle cx={396} cy={360} r={9} fill="none" stroke={P.pulse} strokeWidth={1} strokeOpacity={0.35} />
            <Circle cx={396} cy={360} r={3.4} fill={P.pulse} />
""")

# ── 11) Huellas ──
rep("""                  <Ellipse cx={0} cy={0} rx={4.4} ry={7.2} fill={GREEN} transform="rotate(-7)" />
                  <Ellipse cx={0.8} cy={10.6} rx={3.3} ry={4.3} fill={GREEN} transform="rotate(-4 0.8 10.6)" />
""",
"""                  <Ellipse cx={0} cy={0} rx={4.4} ry={7.2} fill={P.huella} transform="rotate(-7)" />
                  <Ellipse cx={0.8} cy={10.6} rx={3.3} ry={4.3} fill={P.huella} transform="rotate(-4 0.8 10.6)" />
""")

# ── 12) Bandera de cima ──
rep("""            <Path d="M266 96 L266 66" stroke={GREEN_LT} strokeWidth={2} strokeLinecap="round" strokeOpacity={0.9} />
            <Path d="M267.5 67 L286 73.5 L267.5 80 Z" fill={GREEN_LT} fillOpacity={0.92} />
            <Circle cx={266} cy={97.5} r={2} fill={GREEN_LT} />
""",
"""            <Path d="M266 96 L266 66" stroke={P.bandera} strokeWidth={2} strokeLinecap="round" strokeOpacity={0.9} />
            <Path d="M267.5 67 L286 73.5 L267.5 80 Z" fill={P.bandera} fillOpacity={0.92} />
            <Circle cx={266} cy={97.5} r={2} fill={P.bandera} />
""")

# ── 13) Matriz de puntos ──
rep("""                  fill={GREEN} fillOpacity={0.15}
""",
"""                  fill={P.decor} fillOpacity={P.dotOp}
""")

# ── 14) Esquinas de galería ──
rep("""            <Path d="M16 46 L16 16 L46 16" fill="none" stroke={GREEN} strokeWidth={2.5} strokeOpacity={0.7} />
            <Path
              d={`M${CARD_W - 16} ${CARD_H - 46} L${CARD_W - 16} ${CARD_H - 16} L${CARD_W - 46} ${CARD_H - 16}`}
              fill="none" stroke={GREEN} strokeWidth={2.5} strokeOpacity={0.7}
            />
""",
"""            <Path d="M16 46 L16 16 L46 16" fill="none" stroke={P.decor} strokeWidth={2.5} strokeOpacity={P.cornerOp} />
            <Path
              d={`M${CARD_W - 16} ${CARD_H - 46} L${CARD_W - 16} ${CARD_H - 16} L${CARD_W - 46} ${CARD_H - 16}`}
              fill="none" stroke={P.decor} strokeWidth={2.5} strokeOpacity={P.cornerOp}
            />
""")

# ── 15) Fondo de la tarjeta ──
rep("""        <View style={styles.shareCard}>
""",
"""        <View style={[styles.shareCard, { backgroundColor: P.cardBg }]}>
""")

# ── 16) Aros de la foto ──
rep("""          <View style={styles.shareAvatarWrap}>
            <View style={styles.shareAvatarDashed} />
            <View style={styles.shareAvatarRingOut}>
              <View style={styles.shareAvatarRingIn}>
""",
"""          <View style={styles.shareAvatarWrap}>
            <View style={[styles.shareAvatarDashed, { borderColor: P.dashed }]} />
            <View style={[styles.shareAvatarRingOut, { backgroundColor: P.ringOut, borderColor: P.ringOutBorder }]}>
              <View style={[styles.shareAvatarRingIn, { backgroundColor: P.ringIn }]}>
""")

# ── 17) Avatar con inicial (fallback) ──
rep("""                  <View style={[styles.shareAvatarImg, styles.shareAvatarFallback]}>
                    <Text style={styles.shareAvatarInitial}>{initial}</Text>
                  </View>
""",
"""                  <View style={[styles.shareAvatarImg, styles.shareAvatarFallback, { backgroundColor: P.fallback }]}>
                    <Text style={[styles.shareAvatarInitial, { color: P.initial }]}>{initial}</Text>
                  </View>
""")

# ── 18) Nombre + subrayados ──
rep("""          <Text style={[styles.shareName, { fontSize: nameSize(firstName) }]} numberOfLines={1}>
""",
"""          <Text style={[styles.shareName, { fontSize: nameSize(firstName), color: P.name }]} numberOfLines={1}>
""")
rep("""          <View style={styles.shareUnderline} />
          <View style={styles.shareUnderline2} />
""",
"""          <View style={[styles.shareUnderline, { backgroundColor: P.underline }]} />
          <View style={[styles.shareUnderline2, { backgroundColor: P.underline2 }]} />
""")

# ── 19) Píldora del correo ──
rep("""            <View style={styles.shareEmailPill}>
              <Ionicons name="mail-outline" size={12} color="#8FAF97" />
              <Text style={styles.shareEmailText} numberOfLines={1}>{user?.email}</Text>
            </View>
""",
"""            <View style={[styles.shareEmailPill, { backgroundColor: P.pillBg, borderColor: P.pillBorder }]}>
              <Ionicons name="mail-outline" size={12} color={P.emailIcon} />
              <Text style={[styles.shareEmailText, { color: P.email }]} numberOfLines={1}>{user?.email}</Text>
            </View>
""")

# ── 20) Comentarios de cabecera actualizados ──
rep("""/* ── Tarjeta compartible: artwork 4:5 "LA CIMA" (paleta de marca) ──
   Mapa topográfico donde la foto es la cumbre: anillos de nivel, cielo
   estrellado, terreno en capas, ruta GPS brillante y huellas que ascienden.
   Sin textos de marca: solo nombre de pila y correo. ── */
""",
"""/* ── Tarjeta compartible: artwork 4:5 con DOS modos según el contraste ──
   Mapa topográfico donde la foto es la cumbre: anillos de nivel, cielo,
   terreno en capas, ruta GPS brillante y huellas que ascienden.
   NOCHE → "LA CIMA" (verdes sobre carbón, estrellas).
   DÍA   → "EL AMANECER" (terracotas/dorados sobre crema, pájaros).
   Sin textos de marca: solo nombre de pila y correo. ── */
""")
rep("""      {/* ── TARJETA OCULTA PARA COMPARTIR ("LA CIMA") ──
""",
"""      {/* ── TARJETA OCULTA PARA COMPARTIR ("LA CIMA" / "EL AMANECER") ──
          El artwork sigue el modo de contraste de la app (cardLight).
""")
rep("""          {/* ══ ARTWORK "LA CIMA" (SVG): mapa topográfico cuya cumbre es la
               foto — anillos de nivel, cielo estrellado, auroras, terreno en
               capas, ruta GPS con brillo, huellas ascendiendo y bandera.
               El nombre semilla el mapa: cada persona tiene el suyo. ══ */}
""",
"""          {/* ══ ARTWORK (SVG): mapa topográfico cuya cumbre es la foto —
               anillos de nivel, cielo (estrellas o pájaros), auroras/sol,
               terreno en capas, ruta GPS con brillo, huellas y bandera.
               El nombre semilla el mapa y el contraste elige la paleta:
               noche = "LA CIMA" verde; día = "EL AMANECER" cálido. ══ */}
""")

# ── Escritura preserving CRLF ──
out = s.replace("\n", "\r\n") if CRLF else s
open(P, "wb").write(out.encode("utf-8"))
print("OK: SettingsScreen.js actualizado (%d → %d bytes, CRLF=%s)" % (n0, len(s), CRLF))

# Sanity: no deben quedar usos huérfanos
for bad in ["TOPO_OP", "estrellas.map"]:
    assert bad not in s, "quedan referencias a " + bad
print("Sanity OK: sin referencias huérfanas")
