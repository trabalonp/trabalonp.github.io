# PAQUETE WHATSAPP 2 — enlaces, encuestas en vivo, avatares en caché y borrado en R2

> **ACTUALIZACIÓN (deploy Vercel):** el plan Hobby limita a 12 funciones y el
> servidor ya tenía 13 archivos en `api/`. Los handlers se han MOVIDO a
> `handlers/` y se ha creado un dispatcher único `api/[...path].js` (las URLs
> públicas no cambian). Los endpoints de este documento
> (`api/social/link-preview.js`, `api/social/delete-message.js`) viven ahora en
> `handlers/social/`. Instrucciones completas: **VERCEL-HOBBY-12-FUNCIONES.md**.

Cuatro mejoras pedidas, todas con el patrón real de WhatsApp investigado en su
documentación y comportamiento público:

1. **Enlaces pinchables + previsualización** (tarjeta con imagen/título/dominio).
2. **Encuestas arregladas**: el voto se actualiza al instante, resultados EN VIVO,
   cuadro más ancho y la opción que va ganando marcada con color ("GANANDO").
3. **Foto de perfil en cada mensaje con caché local**: se descarga UNA vez y
   solo se vuelve a descargar si la persona cambia su foto.
4. **Eliminar un mensaje con imagen/archivo borra también el archivo de
   Cloudflare R2** (sin romper reenvíos).

---

## 1) Enlaces y previsualizaciones

**Cómo lo hace WhatsApp** (investigado): el cliente del **emisor** detecta las
URL del texto mientras escribes, obtiene los metadatos **Open Graph** de la
página (`og:title`, `og:description`, `og:image`) y los **adjunta al propio
mensaje**; quien lo recibe pinta la tarjeta sin volver a pedir nada. Los
enlaces se pintan en azul + subrayado y se abren al tocarlos.

**Implementación:**

- `services/enlaces.js` (puro, con tests): detección de URLs `http(s)://` y
  `www.`, con la puntuación final de frase (`.` `,` `?`…) y los paréntesis sin
  balancear FUERA del enlace, igual que WhatsApp. Segmenta el texto para
  pintar los enlaces sin romper nada alrededor.
- En la burbuja, `TextoEnlaces` pinta cada URL en azul (`#53BDEB` oscuro /
  `#027EB5` claro) + subrayado; al tocarla se abre con `Linking.openURL`.
- **Emisor** (`publicar` en SocialScreen): si el mensaje tiene un enlace y no
  lleva fotos/archivos, pide la preview al servidor (tope 3.5 s) y la guarda
  en el post de Firestore (campo `preview`). Si el servidor no responde, el
  mensaje se envía igual sin preview.
- **Receptor** (`VistaPrevia`): pinta la tarjeta (imagen 130 px + título +
  descripción + dominio) desde el campo `preview`. Los mensajes ANTIGUOS sin
  ese campo piden la preview una sola vez y la cachean 7 días en el
  dispositivo (`services/linkPreview.js`, single-flight, fallos cacheados 1 h).
- **Servidor** `api/social/link-preview.js`: hace de crawler (la app no puede
  por CORS), sigue redirecciones (máx. 4), lee solo HTML/imágenes y hasta
  600 KB, y extrae `og:title/og:description/og:image/og:site_name` con
  respaldo en `twitter:*`, `<title>` y `meta description`. **Protección SSRF**:
  solo destinos públicos (nada de localhost, 10/8, 192.168/16, 169.254/16
  —metadata de nube—, CGNAT, IPv6 locales), validando también cada redirección
  por DNS. La lógica pura está en `lib/linkPreviewParse.js` (con tests).
- Los reenvíos arrastran el `preview` del mensaje original.

## 2) Encuestas en vivo

**Qué fallaba:** al votar se escribía en Firestore y en el almacén local, pero
NO se actualizaba la lista en pantalla (`posts`), así que la encuesta parecía
no reaccionar hasta refrescar. Además, el listener principal solo escucha
mensajes NUEVOS (`createdAt > lastSync`): los votos de los demás en encuestas
anteriores nunca llegaban en vivo.

**Arreglos:**

- **Voto optimista**: `votarEncuesta` actualiza la pantalla al instante,
  persiste en local y escribe en Firestore. Un guard de 5 s (`votosRecientes`
  + `protegerVoto`) impide que un eco lento del servidor revierta el voto
  recién hecho (parpadeo hacia atrás).
- **Resultados en vivo**: listener propio por documento para las encuestas
  cargadas (máx. 12): cada voto de cualquier persona entra al instante,
  aunque la encuesta sea antigua. La suscripción no se recrea con cada voto
  (la clave del effect es la huella id+encuesta, no los datos).
- **Recuento puro** en `services/encuestas.js` (con tests): porcentajes,
  líderes (los empates marcan varias opciones) y votos inválidos ignorados.
- **Cuadro más ancho y más bonito**: la burbuja con encuesta sube a 94% de
  ancho (antes 78%) y la encuesta tiene ancho mínimo 255 px. Cada opción es
  una fila redondeada con su **color** (paleta estable de 6), barra de
  progreso del porcentaje, `pct% · n votos`, **check azul en tu voto** e
  insignia **"GANANDO"** en la opción líder (borde y relleno más fuertes en
  su color). Pie con el total de votos y ayuda contextual.

## 3) Fotos de perfil con caché local (patrón WhatsApp)

**Cómo lo hace WhatsApp** (investigado): descarga la miniatura del contacto
**una sola vez**, la guarda en el dispositivo y la pinta desde la caché; solo
vuelve a descargarla cuando recibe un **aviso de que la foto cambió**
(presence/push), nunca en cada apertura del chat.

**Implementación** (`services/avatarCache.js`):

- Nueva colección ligera **`avatares/<uid>` = { url (R2), updatedAt, size }**
  (~200 bytes). Es el "aviso de cambio": al abrir el Tablón se leen SOLO esos
  docs pequeños. Si la `url` no cambió → **cero descargas**, la foto se pinta
  desde el disco (`documentDirectory/avatars-v1/`). Si cambió → se baja el
  archivo nuevo (single-flight, `.part` + move atómico) y se sustituye.
- **Al guardar la foto de perfil** (ProfileScreen) se sube el JPEG a R2
  (endpoint `presign` existente) y se escribe `avatares/<uid>`: los demás
  teléfonos lo ven en su próxima sincronización y refrescan solo esa foto.
- **Migración automática**: la primera vez que abres el chat con esta versión,
  tu propio doc `avatares` se publica solo desde tu foto actual. Los perfiles
  antiguos de OTRAS personas (foto solo en base64 dentro de `perfiles`) usan
  un respaldo con **TTL de 6 h**: se lee el perfil como mucho cada 6 h, se
  cachea la foto a disco con un hash y, si el hash no cambia, no se vuelve a
  leer. En cuanto esa persona abra la app nueva y guarde su perfil, pasa al
  mecanismo ligero definitivo.
- `useAvatar(uid)`: hook reactivo — la burbuja se redibuja sola cuando la
  caché recibe una foto nueva. Sin foto (o archivo dañado): la inicial
  coloreada de siempre. Las fotos se ven en las burbujas de los demás
  (WhatsApp no muestra tu propio avatar en grupos).
- Sincronización con debounce (600 ms) y tope interno (como mucho una pasada
  completa cada 90 s; el pull-to-refresh fuerza una).
- ** firestore.rules**: bloque nuevo `match /avatares/{userId}` (leer:
  autenticado; escribir: solo el dueño). **Hay que publicarlas.**

## 4) Eliminar mensaje = eliminar archivo en R2

- Nuevo endpoint **`api/social/delete-message.js`** (autenticado con el token
  de Firebase):
  1. Verifica con `firebase-admin` que el post existe y que **quien borra es
     su autor** (más estricto que las reglas actuales de `posts`).
  2. Marca el borrado lógico de siempre (`eliminado:true`, vacía texto/media/
     encuesta/preview/reacciones).
  3. Borra de R2 el objeto original y la miniatura **solo si ningún OTRO
     mensaje vivo los referencia** (los reenvíos comparten la misma URL de R2
     y no deben romperse). La comprobación usa `where('media.url','==',…)` y
     `where('media.thumbUrl','==',…)`: igualdad simple, **sin índices
     compuestos**. Solo se borran claves del prefijo `social/` del bucket del
     chat (`lib/socialMedia.js`, con tests); jamás otras rutas.
- La app (`eliminarVarios`): si los mensajes tienen media, llama al endpoint;
  si el servidor no está desplegado o falla la red, hace el **borrado lógico
  de siempre como respaldo** (nada se rompe por no redeployar). Además libera
  el disco local (`olvidarMediaLocal`) de las imágenes/audios borrados.

---

## Despliegue (una sola vez)

1. **Servidor (Vercel)**: aplica la reestructuración del dispatcher (ver
   `VERCEL-HOBBY-12-FUNCIONES.md`): borra los 13 archivos de `api/`, sube
   `api/[...path].js` + la carpeta `handlers/` completa + `lib/` actualizada
   (incluye `linkPreviewParse.js` con `hostSeguro` y `socialMedia.js`).
   **Sin variables nuevas** (usa las R2_* y FIREBASE_SERVICE_ACCOUNT
   existentes) y sin dependencias nuevas (Node ≥ 18 con fetch nativo).
2. **Reglas de Firestore**: pega el `firestore.rules` actualizado en Firebase
   Console → Firestore → Rules → Publish (añade la colección `avatares`).
3. **App**: `screens/SocialScreen.js`, `screens/ProfileScreen.js` y los 4
   servicios nuevos (`enlaces.js`, `encuestas.js`, `linkPreview.js`,
   `avatarCache.js`). **No hay dependencias nativas nuevas**: vale OTA
   (EAS Update) sin rebuild. (El audio del paquete anterior sí necesitaba el
   rebuild con `expo-audio`; esto no.)

## Comportamiento sin desplegar (respaldos)

- Sin servidor nuevo: los enlaces siguen siendo pinchables (todo local); las
  previews simplemente no aparecen; eliminar sigue siendo borrado lógico (la
  media queda en R2, como hasta ahora).
- Sin reglas nuevas: las fotos de perfil siguen funcionando por el respaldo
  legacy (base64 de `perfiles` con TTL 6 h); la migración automática del doc
  propio espera a que las reglas estén publicadas.

## Tests (todo verificado desde Node)

| Test | Qué cubre | Resultado |
|---|---|---|
| `tests/enlaces-test.js` | Segmentación de URLs (puntuación, paréntesis, www, queries, emails), invariantes de texto, dominios, recuento de votos, líderes/empates, votos inválidos, paleta | **43 asserts OK** |
| `tests/delete-media-test.js` | Claves R2 válidas/rechazadas, traversal, URLs sin duplicar, protección de reenvíos | **20 asserts OK** |
| `tests/link-preview-parse-test.js` | SSRF (IPv4/IPv6 privadas, metadata, CGNAT), entidades HTML, Open Graph en cualquier orden de atributos, URLs relativas | **40 asserts OK** |
| `tests/chat-sync-test.js` | Sin regresión del motor de sincronización | 55 asserts OK |
| `tests/focal-release-fix-test.js` | Sin regresión del zoom | 28 asserts OK |
