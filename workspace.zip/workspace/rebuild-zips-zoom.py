#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regenera los ZIPs de entrega con el visor de gestos (hilo de UI) +
miniaturas 640 px + babel worklets:
- SocialScreen.js nuevo (app)
- babel.config.js con react-native-worklets/plugin
- package.json sin react-native-image-viewing
- fix-zoom-gestos.zip nuevo (cambio actual + doc)
Preserva el resto de entradas y sus bytes exactos.
"""
import hashlib, os, shutil, zipfile

APP = os.path.join('proyecto', 'mi-app-entrenos')

def blob(*p):
    with open(os.path.join(*p), 'rb') as f:
        return f.read()

SOCIAL = blob(APP, 'screens', 'SocialScreen.js')
BABEL = blob(APP, 'babel.config.js')
PKG = blob(APP, 'package.json')
DOC = blob('ZOOM-GESTOS.md')

# zip -> (reemplazos, eliminaciones, adiciones)
PLAN = {
    'fix-chat-sync.zip': (
        {'APP/screens/SocialScreen.js': SOCIAL},
        [], {},
    ),
    'archivos-corregidos.zip': (
        {'screens/SocialScreen.js': SOCIAL, 'package.json': PKG},
        [], {'babel.config.js': BABEL},
    ),
    'mi-app-entrenos-CORREGIDO.zip': (
        {'screens/SocialScreen.js': SOCIAL, 'package.json': PKG, 'babel.config.js': BABEL},
        [], {},
    ),
    'mi-app-entrenos-PROYECTO-CORREGIDO.zip': (
        {'mi-app-entrenos/screens/SocialScreen.js': SOCIAL,
         'mi-app-entrenos/package.json': PKG,
         'mi-app-entrenos/babel.config.js': BABEL},
        [], {},
    ),
}

for zname, (repl, drop, add) in PLAN.items():
    src = zipfile.ZipFile(zname, 'r')
    tmp = zname + '.tmp'
    seen = set()
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as out:
        for item in src.infolist():
            if item.filename in drop:
                continue
            if item.filename in repl:
                out.writestr(item.filename, repl[item.filename])
                seen.add(item.filename)
            else:
                out.writestr(item.filename, src.read(item.filename))
        for name, data in add.items():
            if name not in seen:
                out.writestr(name, data)
                seen.add(name)
        faltan = set(repl) - seen
        if faltan:
            raise SystemExit('%s: entradas no encontradas: %s' % (zname, sorted(faltan)))
    src.close()
    shutil.move(tmp, zname)
    n = len(zipfile.ZipFile(zname).namelist())
    print('OK %-45s %2d entradas (actualizadas %d)' % (zname, n, len(seen)))

# ZIP del cambio actual
with zipfile.ZipFile('fix-zoom-gestos.zip', 'w', zipfile.ZIP_DEFLATED) as out:
    out.writestr('APP/screens/SocialScreen.js', SOCIAL)
    out.writestr('APP/babel.config.js', BABEL)
    out.writestr('APP/package.json', PKG)
    out.writestr('ZOOM-GESTOS.md', DOC)
print('OK fix-zoom-gestos.zip creado (4 entradas)')

# Staging antiguo sincronizado
p = os.path.join('entrega-social', 'app', 'screens', 'SocialScreen.js')
if os.path.exists(p):
    with open(p, 'wb') as f:
        f.write(SOCIAL)
    print('OK entrega-social/app/screens/SocialScreen.js sincronizado')

# Verificación: los bytes de SocialScreen en cada ZIP == archivo canónico
h = hashlib.sha256(SOCIAL).hexdigest()
for zname, entries in [
    ('fix-chat-sync.zip', ['APP/screens/SocialScreen.js']),
    ('archivos-corregidos.zip', ['screens/SocialScreen.js']),
    ('mi-app-entrenos-CORREGIDO.zip', ['screens/SocialScreen.js']),
    ('mi-app-entrenos-PROYECTO-CORREGIDO.zip', ['mi-app-entrenos/screens/SocialScreen.js']),
    ('fix-zoom-gestos.zip', ['APP/screens/SocialScreen.js']),
]:
    with zipfile.ZipFile(zname) as z:
        for e in entries:
            assert hashlib.sha256(z.read(e)).hexdigest() == h, (zname, e)
print('OK hashes verificados en los 5 ZIPs')
print('TODO OK')
