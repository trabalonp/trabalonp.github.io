/* Simulación 1:1 de la lógica del pellizco de FocalViewer (fix "salto al
   soltar") reproduciendo los eventos que RNGH 2.32 despacha en Android:
   - ACTION_POINTER_UP  → onTouchesUp(numberOfTouches=1) + update con el FOCO
     TELETRANSPORTADO al dedo restante (scale congelado)
   - ACTION_MOVE        → updates con foco = dedo restante (la foto lo seguiría)
   - ACTION_UP          → onEnd (snapToBounds)
   Verifica: cero salto al soltar, clamp durante el gesto, reanclaje suave,
   red anti-teletransporte y que la fórmula exacta sigue intacta.
   Uso: node tests/focal-release-fix-test.js */
'use strict';
let fallos = 0;
const ok = (cond, msg) => { if (!cond) { fallos++; console.log('FALLO: ' + msg); } else console.log('ok   ' + msg); };
const near = (a, b, tol) => Math.abs(a - b) <= (tol || 1e-9);

const clamp = (v, lo, hi) => Math.min(Math.max(v, lo), hi);
const MINZ = 1, MAXZ = 5;

function makeViewer(boxW, boxH, imgW, imgH) {
  const sv = (v) => ({ value: v });
  const scale = sv(1), tx = sv(0), ty = sv(0);
  const _imgW = sv(imgW), _imgH = sv(imgH), _boxW = sv(boxW), _boxH = sv(boxH);
  const p0s = sv(1), p0x = sv(0), p0y = sv(0), p0fx = sv(0), p0fy = sv(0);
  const p0e = sv(1), pfx = sv(0), pfy = sv(0), lastE = sv(1), pinchMuted = sv(false);

  const bounds = (s) => {
    let dw = _boxW.value, dh = _boxH.value;
    if (_imgW.value > 0 && _imgH.value > 0) {
      const fit = Math.min(_boxW.value / _imgW.value, _boxH.value / _imgH.value);
      dw = _imgW.value * fit; dh = _imgH.value * fit;
    }
    return { maxX: Math.max(0, (dw * s - _boxW.value) / 2), maxY: Math.max(0, (dh * s - _boxH.value) / 2) };
  };
  // snapToBounds: destino del withTiming al soltar
  const snapTarget = () => { const b = bounds(scale.value); return { x: clamp(tx.value, -b.maxX, b.maxX), y: clamp(ty.value, -b.maxY, b.maxY) }; };

  const api = {
    scale, tx, ty, pinchMuted, bounds, snapTarget,
    onBegin() { pinchMuted.value = false; },
    onTouchesUp(e) { if (e.numberOfTouches <= 1) pinchMuted.value = true; },
    onTouchesDown(e) {
      if (!pinchMuted.value || e.numberOfTouches < 2) return;
      const ts = e.allTouches;
      if (!ts || ts.length < 2) return;
      let sx = 0, sy = 0;
      for (let i = 0; i < ts.length; i++) { sx += ts[i].x; sy += ts[i].y; }
      p0s.value = Math.max(0.01, scale.value);
      p0x.value = tx.value; p0y.value = ty.value;
      p0e.value = lastE.value > 0 ? lastE.value : 1;
      p0fx.value = sx / ts.length - _boxW.value / 2;
      p0fy.value = sy / ts.length - _boxH.value / 2;
      pfx.value = p0fx.value; pfy.value = p0fy.value;
      pinchMuted.value = false;
    },
    onStart(e) {
      pinchMuted.value = false;
      p0s.value = Math.max(0.01, scale.value);
      p0x.value = tx.value; p0y.value = ty.value;
      p0e.value = e.scale > 0 ? e.scale : 1;
      p0fx.value = e.focalX - _boxW.value / 2;
      p0fy.value = e.focalY - _boxH.value / 2;
      pfx.value = p0fx.value; pfy.value = p0fy.value;
    },
    onUpdate(e) {
      lastE.value = e.scale;
      if (pinchMuted.value) return;
      const fx = e.focalX - _boxW.value / 2;
      const fy = e.focalY - _boxH.value / 2;
      const jx = fx - pfx.value, jy = fy - pfy.value;
      if (jx * jx + jy * jy > 22500) { pinchMuted.value = true; return; }
      pfx.value = fx; pfy.value = fy;
      const s0 = p0s.value;
      if (s0 <= 0) return;
      const next = clamp(s0 * (e.scale / p0e.value), MINZ, MAXZ);
      const ratio = next / s0;
      scale.value = next;
      const b = bounds(next);
      tx.value = clamp(fx - (p0fx.value - p0x.value) * ratio, -b.maxX, b.maxX);
      ty.value = clamp(fy - (p0fy.value - p0y.value) * ratio, -b.maxY, b.maxY);
    },
    // invariante: el punto del CONTENIDO bajo el foco no se mueve
    contentPointFocal(e) {
      const fx = e.focalX - _boxW.value / 2, fy = e.focalY - _boxH.value / 2;
      return { cx: (fx - tx.value) / scale.value, cy: (fy - ty.value) / scale.value };
    },
  };
  return api;
}

const BOX_W = 390, BOX_H = 844;          // pantalla típica
const IMG_W = 1080, IMG_H = 1440;        // foto 3:4 → fit = 390/1080; dw=390, dh=520

/* ── Escenario A: pellizco normal + soltar UN dedo (el bug del usuario) ── */
{
  const v = makeViewer(BOX_W, BOX_H, IMG_W, IMG_H);
  v.onBegin();
  // activación: e.scale == 1 exacto (RNGH hace resetProgress al activar)
  const e0 = { scale: 1.0, focalX: 195, focalY: 422 };
  v.onStart(e0); v.onUpdate(e0);
  const t0 = { tx: v.tx.value, ty: v.ty.value };
  ok(near(t0.tx, 0) && near(t0.ty, 0), 'A1 activación sin salto');

  // zoom a ~2.5 desplazando los dedos (foco se mueve, scale sube)
  const frames = [
    { scale: 1.2, focalX: 180, focalY: 400 },
    { scale: 1.5, focalX: 170, focalY: 380 },
    { scale: 1.9, focalX: 160, focalY: 370 },
    { scale: 2.2, focalX: 150, focalY: 360 },
    { scale: 2.5, focalX: 145, focalY: 355 },
  ];
  for (const f of frames) v.onUpdate(f);
  ok(near(v.scale.value, 2.5), 'A2 zoom 2.5x aplicado');
  const b = v.bounds(2.5);
  ok(Math.abs(v.tx.value) <= b.maxX + 1e-9 && Math.abs(v.ty.value) <= b.maxY + 1e-9, 'A3 dentro de bordes durante el gesto');
  // invariante focal: mismo punto de contenido bajo el foco que al inicio
  const cLast = v.contentPointFocal(frames[frames.length - 1]);
  const cFirst = { cx: (195 - BOX_W / 2 - t0.tx) / 1, cy: (422 - BOX_H / 2 - t0.ty) / 1 };
  ok(near(cLast.cx, cFirst.cx, 1e-6) && near(cLast.cy, cFirst.cy, 1e-6), 'A4 anclaje focal exacto (contenido bajo los dedos)');

  const antes = { s: v.scale.value, tx: v.tx.value, ty: v.ty.value };

  // ⚡ ACTION_POINTER_UP: RNGH despacha PRIMERO onTouchesUp(numberOfTouches=1)
  v.onTouchesUp({ numberOfTouches: 1 });
  // ...y DESPUÉS el update artefacto: foco teleportado al dedo restante
  v.onUpdate({ scale: 2.5, focalX: 60, focalY: 700 });   // salto de ~350px
  ok(v.pinchMuted.value, 'A5 enmudecido al quedar 1 dedo');
  ok(near(v.scale.value, antes.s) && near(v.tx.value, antes.tx) && near(v.ty.value, antes.ty), 'A6 CERO salto con el update artefacto');

  // ACTION_MOVE del dedo restante (RNGH: foco = ese dedo, scale congelado)
  for (let i = 1; i <= 5; i++) v.onUpdate({ scale: 2.5, focalX: 60 + i * 8, focalY: 700 - i * 6 });
  ok(near(v.tx.value, antes.tx) && near(v.ty.value, antes.ty), 'A7 el dedo restante ya NO arrastra la foto');

  // ACTION_UP → onEnd → snapToBounds: destino == posición actual (nada se mueve)
  const dest = v.snapTarget();
  ok(near(dest.x, v.tx.value) && near(dest.y, v.ty.value), 'A8 al soltar: snap no-op (la foto se queda quieta)');
}

/* ── Escenario B: clamp durante el gesto (zoom anclado al borde + arrastre) ── */
{
  const v = makeViewer(BOX_W, BOX_H, IMG_W, IMG_H);
  v.onBegin();
  // ancla del pellizco cerca del borde izquierdo (foco x=60)
  const e0 = { scale: 1.0, focalX: 60, focalY: 422 };
  v.onStart(e0); v.onUpdate(e0);
  // zoom progresivo a 5x arrastrando el centroide hacia la derecha:
  // la fórmula empuja tx contra el borde y el clamp lo topa en cada frame
  v.onUpdate({ scale: 2.0, focalX: 130, focalY: 422 });
  const b2 = v.bounds(2.0);
  ok(near(v.tx.value, b2.maxX), 'B1a topa en el borde ya a 2x');
  v.onUpdate({ scale: 3.0, focalX: 200, focalY: 422 });
  v.onUpdate({ scale: 4.0, focalX: 270, focalY: 422 });
  v.onUpdate({ scale: 5.0, focalX: 340, focalY: 422 });
  const b5 = v.bounds(5.0);
  ok(near(v.tx.value, b5.maxX), 'B1b topado exacto en el borde a 5x');
  // seguir empujando: no se sale más
  for (let i = 1; i <= 4; i++) {
    v.onUpdate({ scale: 5.0, focalX: 345 + i * 6, focalY: 422 });
    const bb = v.bounds(v.scale.value);
    ok(Math.abs(v.tx.value) <= bb.maxX + 1e-9, 'B2 frame ' + i + ' dentro de bordes');
  }
  ok(near(v.tx.value, b5.maxX), 'B2b sigue pegado al borde');
  const dest = v.snapTarget();
  ok(near(dest.x, v.tx.value) && near(dest.y, v.ty.value), 'B3 al soltar no hay rebote (ya estaba topado)');
}

/* ── Escenario C: reanclaje — dedo nuevo apoyado sin levantar el otro ── */
{
  const v = makeViewer(BOX_W, BOX_H, IMG_W, IMG_H);
  v.onBegin();
  const e0 = { scale: 1.0, focalX: 195, focalY: 422 };
  v.onStart(e0); v.onUpdate(e0);
  v.onUpdate({ scale: 2.0, focalX: 190, focalY: 420 });
  v.onUpdate({ scale: 3.0, focalX: 185, focalY: 418 });   // lastE = 3.0
  v.onTouchesUp({ numberOfTouches: 1 });                  // se silencia
  v.onUpdate({ scale: 3.0, focalX: 90, focalY: 700 });    // artefacto ignorado
  const antes = { s: v.scale.value, tx: v.tx.value, ty: v.ty.value };
  // el usuario apoya OTRO dedo (quedan 2 en pantalla) → onTouchesDown reancla
  v.onTouchesDown({ numberOfTouches: 2, allTouches: [{ x: 90, y: 700 }, { x: 290, y: 300 }] });
  ok(!v.pinchMuted.value, 'C1 reactivado al apoyar el dedo nuevo');
  // primer update tras reanclaje: detector rearranca → e.scale sigue ~3.0,
  // foco = centroide de los 2 dedos
  v.onUpdate({ scale: 3.0, focalX: 190, focalY: 500 });
  ok(near(v.scale.value, antes.s) && near(v.tx.value, antes.tx) && near(v.ty.value, antes.ty), 'C2 reanclaje continuo (sin salto de escala ni traslado)');
  // y ahora sí, zoom desde el nuevo ancla
  v.onUpdate({ scale: 3.6, focalX: 190, focalY: 500 });
  ok(v.scale.value > antes.s, 'C3 el zoom vuelve a responder tras reanclar');
}

/* ── Escenario D: red anti-teletransporte (sin onTouchesUp, p. ej. otro orden) ── */
{
  const v = makeViewer(BOX_W, BOX_H, IMG_W, IMG_H);
  v.onBegin();
  const e0 = { scale: 1.0, focalX: 195, focalY: 422 };
  v.onStart(e0); v.onUpdate(e0);
  v.onUpdate({ scale: 2.5, focalX: 160, focalY: 380 });
  const antes = { tx: v.tx.value, ty: v.ty.value };
  // SIN onTouchesUp: llega directo el update con foco teleportado (>60px)
  v.onUpdate({ scale: 2.5, focalX: 60, focalY: 700 });
  ok(v.pinchMuted.value, 'D1 la red detecta el teletransporte del foco');
  ok(near(v.tx.value, antes.tx) && near(v.ty.value, antes.ty), 'D2 y lo ignora (cero salto)');
}

/* ── Escenario E: regresión de la fórmula exacta (pan 1:1 a dos dedos) ── */
{
  const v = makeViewer(BOX_W, BOX_H, IMG_W, IMG_H);
  v.onBegin();
  const e0 = { scale: 1.0, focalX: 195, focalY: 422 };
  v.onStart(e0); v.onUpdate(e0);
  v.onUpdate({ scale: 3.0, focalX: 195, focalY: 422 });   // zoom centrado
  const t0 = v.tx.value;
  // scale constante, foco se mueve Δ → tx debe moverse exactamente Δ (1:1)
  const d = 12; // desplazamientos pequeños para no chocar con el borde
  v.onUpdate({ scale: 3.0, focalX: 195 - d, focalY: 422 });
  ok(near(v.tx.value, t0 - d, 1e-9), 'E1 pan a dos dedos 1:1');
  // dedos quietos: zoom anclado en el foco (f constante ⇒ el punto bajo f no se mueve)
  const f = 195 - d - BOX_W / 2;
  const contenidoAntes = (f - v.tx.value) / v.scale.value;
  v.onUpdate({ scale: 3.4, focalX: 195 - d, focalY: 422 });
  const contenidoDespues = (f - v.tx.value) / v.scale.value;
  ok(near(contenidoAntes, contenidoDespues, 1e-9), 'E2 zoom con dedos quietos ancla en el foco');
  ok(v.scale.value >= MINZ && v.scale.value <= MAXZ, 'E3 clamp 1x–5x');
}

/* ── Escenario F: swipe de foto a scale=1 no se ve afectado (pan intacto) ── */
{
  const v = makeViewer(BOX_W, BOX_H, IMG_W, IMG_H);
  v.onBegin();
  v.onTouchesUp({ numberOfTouches: 0 });   // al soltar el dedo del swipe
  ok(v.pinchMuted.value, 'F1 mute en swipe normal es inocuo');
  v.onBegin();
  ok(!v.pinchMuted.value, 'F2 la siguiente interacción des-enmudece');
}

/* ── Escenario G: margen de la red anti-teletransporte (150px) ── */
{
  const v = makeViewer(BOX_W, BOX_H, IMG_W, IMG_H);
  v.onBegin();
  const e0 = { scale: 1.0, focalX: 195, focalY: 422 };
  v.onStart(e0); v.onUpdate(e0);
  // movimiento legítimo rápido del centroide (100px/frame): NO debe enmudecer
  v.onUpdate({ scale: 1.4, focalX: 260, focalY: 422 });   // Δ≈65px
  v.onUpdate({ scale: 1.4, focalX: 295, focalY: 508 });   // Δ≈95px
  ok(!v.pinchMuted.value, 'G1 saltos legítimos ≤150px no enmudecen');
  // artefacto de levantar un dedo (foco teleportado >150px): SÍ
  v.onUpdate({ scale: 1.4, focalX: 60, focalY: 780 });    // Δ≈360px
  ok(v.pinchMuted.value, 'G2 teletransporte >150px enmudece');
}

console.log(fallos === 0 ? '\nTODOS LOS TESTS OK' : '\nHAY ' + fallos + ' FALLOS');
process.exit(fallos === 0 ? 0 : 1);
