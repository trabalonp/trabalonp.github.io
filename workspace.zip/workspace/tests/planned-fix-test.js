// Test del fix de syncPlannedUpdates (zonas null + 404 recreate)
process.chdir(__dirname);
const path = require('path');
const M = require(path.join(__dirname, '..', 'workspace-anterior', 'vercel-server', 'mi-app-entrenos-main', 'lib', 'uploadWorkouts.js'));

const ts = (ms) => ({ toDate: () => new Date(ms), toMillis: () => ms });

function makeDoc(id, data) {
  const store = { ...data };
  return {
    id,
    data: () => ({ ...store }),
    ref: { update: async (u) => { Object.assign(store, u); docUpdates.push({ id, u }); } },
    _store: store,
  };
}
let docUpdates = [];

// Entreno tipo el del usuario: pasos con objetivo "Zona ritmo" (antes crash)
const wZonas = makeDoc('DOC_ZONAS', {
  userId: 'u1', titulo: 'Series Z4', tipo: 'Running',
  fecha: ts(Date.parse('2026-09-22T09:00:00Z')), duracion: 3600, descripcion: '',
  pasos: [
    { tipo: 'Calentamiento', durTipo: 'Tiempo', durValor: 15, objetivo: '', repeticiones: 1, hijos: [] },
    { tipo: 'Series', durTipo: 'Tiempo', durValor: 5, objetivo: 'Zona ritmo', objZona: 'Z4', repeticiones: 4, hijos: [] },
  ],
  intervalsEventId: 137598491, intervalsSentHash: 'VIEJO',
});
// Entreno cuyo evento fue borrado en icu (PUT -> 404)
const w404 = makeDoc('DOC_404', {
  userId: 'u1', titulo: 'Rodaje borrado', tipo: 'Running',
  fecha: ts(Date.parse('2026-09-23T09:00:00Z')), duracion: 1800, descripcion: '',
  pasos: [], intervalsEventId: 135694222, intervalsSentHash: 'VIEJO',
});
// Entreno normal sin cambios (hash igual) -> no debe tocarse
const wOk = makeDoc('DOC_OK', {
  userId: 'u1', titulo: 'DESCANSO', tipo: 'Descanso',
  fecha: ts(Date.parse('2026-09-24T09:00:00Z')), duracion: 600, descripcion: '',
  pasos: [], intervalsEventId: 111, intervalsSentHash: null,
});
wOk._store.intervalsSentHash = M.planHash({ id: 'DOC_OK', ...wOk.data() });

const docs = [wZonas, w404, wOk];

const fetchCalls = [];
global.fetch = async (url, opts) => {
  fetchCalls.push({ url, method: opts.method, body: opts.body });
  if (opts.method === 'PUT' && String(url).includes('/events/135694222')) {
    return { ok: false, status: 404, text: async () => '{"status":404,"error":"Event not found"}' };
  }
  if (opts.method === 'PUT') return { ok: true, status: 200, text: async () => '' };
  if (opts.method === 'POST' && String(url).includes('bulk?upsert=true')) {
    const arr = JSON.parse(opts.body);
    return { ok: true, status: 200, json: async () => arr.map((e, i) => ({ ...e, id: 999000 + i })) };
  }
  if (String(url).includes('bulk-delete')) return { ok: true, status: 200 };
  return { ok: true, status: 200, json: async () => [] };
};

const admin = { firestore: { Timestamp: { fromDate: (d) => ts(d.getTime()) } } };
const db = {
  collection: (name) => ({
    doc: (id) => ({
      get: async () => {
        if (name === 'perfiles') {
          return {
            exists: true,
            data: () => ({
              pendingDeletes: [],
              zonasRitmo: [
                { nombre: 'Z1', min: '6:30', max: '7:30' },
                { nombre: 'Z2', min: '5:30', max: '6:00' },
                { nombre: 'Z3', min: '4:45', max: '5:15' },
                { nombre: 'Z4', min: '4:10', max: '4:30' },
              ],
              zonasFC: [], zonasPotencia: [],
            }),
          };
        }
        const d = docs.find((x) => x.id === id);
        return { exists: !!d, data: () => d.data() };
      },
      update: async (u) => { const d = docs.find((x) => x.id === id); Object.assign(d._store, u); docUpdates.push({ id, u }); },
    }),
    where: () => ({ where: () => ({ get: async () => ({ docs }) }) }),
  }),
};

(async () => {
  const res = await M.syncPlannedUpdates({ admin, db, connection: { apiKey: 'k', athleteId: 42 }, uid: 'u1' });
  console.log('resultado:', JSON.stringify(res));

  const putZonas = fetchCalls.find((c) => c.method === 'PUT' && c.url.includes('137598491'));
  console.log('PUT zonas enviado:', !!putZonas);
  const body = JSON.parse(putZonas.body);
  console.log('descripcion del PUT:\n' + body.description);
  if (!/4:10\/km-4:30\/km/.test(body.description)) throw new Error('FALTA el rango de ritmo Z4 en la descripcion');

  const post404 = fetchCalls.find((c) => c.method === 'POST' && c.url.includes('bulk?upsert=true'));
  console.log('POST recreate tras 404:', !!post404);
  if (!post404) throw new Error('No se recreó el evento 404');
  if (w404._store.intervalsEventId !== 999000) throw new Error('intervalsEventId no actualizado tras recreate: ' + w404._store.intervalsEventId);
  console.log('DOC_404 nuevo intervalsEventId:', w404._store.intervalsEventId, 'hash guardado:', !!w404._store.intervalsSentHash);

  if (wZonas._store.intervalsSentHash === 'VIEJO') throw new Error('hash de DOC_ZONAS no actualizado');
  const touchedOk = docUpdates.some((u) => u.id === 'DOC_OK');
  if (touchedOk) throw new Error('DOC_OK (sin cambios) fue modificado');

  // buildPlannedPayload sin zonas (compat hacia atrás) no debe crashear
  const p = M.buildPlannedPayload({ id: 'x', titulo: 'T', tipo: 'Running', fecha: new Date(), pasos: [{ tipo: 'Series', durTipo: 'Tiempo', durValor: 3, objetivo: 'Zona ritmo', objZona: 'Z4', repeticiones: 1, hijos: [] }] });
  console.log('payload sin zonas OK, desc:', JSON.stringify(p.description));

  console.log('\n✅ TODO OK');
})().catch((e) => { console.error('❌', e); process.exit(1); });
