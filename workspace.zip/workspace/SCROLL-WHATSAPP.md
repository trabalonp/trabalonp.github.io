# Scroll estilo WhatsApp + botón ↓ "ir al final" — SOLUCIONADO

Ronda de corrección del Tablón (`screens/SocialScreen.js`). Dos entregas en
una: **(1)** el chat ya no te arrastra al último mensaje y **(2)** nuevo
botón flotante ↓ para volver al final de un toque.

## 1) El problema de los saltos al último mensaje

Síntomas denunciados (todos con la misma raíz):

| Acción                          | Pasaba                                            |
|---------------------------------|---------------------------------------------------|
| Votar una opción de una encuesta| El viewport saltaba al final del chat             |
| Ir a "Retos" y volver           | El viewport saltaba al final del chat             |
| Seleccionar un mensaje (largo)  | El viewport saltaba al final del chat             |
| Recibir mensajes leyendo arriba | Te arrastraban abajo (misma causa, no denunciada) |

### Causas

1. **`onContentSizeChange` hacía `scrollToEnd` CIEGO**: cualquier cambio de
   altura del contenido (el voto redibuja la burbuja de la encuesta, la
   selección cambia el estilo, una imagen termina de cargar…) se interpretaba
   como "mensaje nuevo" y mandaba el viewport al final.
2. **El efecto de sincronización se re-ejecuta al cambiar de pestaña**
   (`[tab]`): al volver de "Retos" ejecutaba `reloadFromStore(); alFinal();`
   sin condición.
3. **El ScrollView se desmonta al pasar a "Retos"**: al volver, remontaba y
   el `onContentSizeChange` ciego (punto 1) remataba el salto.

### La política nueva (criterio WhatsApp)

El viewport **solo** se mueve al final cuando:

- Se abre el chat por primera vez en la sesión → al último mensaje.
- **Tú** envías o reenvías un mensaje → siempre al final (bandera
  `forzarFinalRef`, colocada ANTES del `setPosts` para que se consuma de
  forma determinista).
- Llega un mensaje nuevo **y ya estabas al final** (tolerancia de ~70 px).

Y **no** se mueve cuando:

- Cambia la altura de una burbuja (voto de encuesta, reacción, selección,
  carga de imagen): `onContentSizeChange` ahora solo reacciona si AUMENTA
  el número de mensajes (`posts.length > prevCountRef`).
- Llegan mensajes mientras lees historial: no se te interrumpe; se suman a
  la insignia del botón ↓.
- Vuelves de "Retos": al salir se guarda `{y, h}` (`restaurarRef`) y al
  volver, cuando el layout reproduce el alto anterior (`h >= rest.h*0.98`),
  se restaura la posición EXACTA. Los eventos intermedios del remontaje se
  ignoran (`onScroll` retorna mientras `restaurarRef` esté activo).
- Haces pull-to-refresh: refresco ya no tira al final (antes también lo
  hacía por el punto 1); los nuevos caen en la insignia.

La paginación hacia atrás (zonas de 50) conserva su lógica propia
(`pendingFix`), que ahora también sincroniza el contador de mensajes para
que el prepend no cuente como "no vistos".

## 2) Botón ↓ flotante (como el de WhatsApp)

- **Cuándo aparece**: siempre que NO estás al final y el chat desborda la
  pantalla (margen de 120 px para no mostrarlo en chats cortos). Se oculta
  solo al llegar abajo.
- **Dónde**: abajo a la derecha, justo **encima de la isla flotante** de
  envío (sube con ella cuando sale el teclado; cuando hay un mensaje
  seleccionado queda entre la barra de reacciones y la isla).
- **Diseño**: el mismo que las fichas de fecha del chat — círculo de
  `rgba(0,0,0,0.42)` con icono blanco (`chevron-down`, `#FFFFFFF2`), 42×42,
  borde sutil blanco y sombra/elevación como el FAB de WhatsApp. Al pulsar:
  `pressed` oscurece el círculo.
- **Insignia de no vistos**: contador azul (`c.acc`) arriba a la derecha del
  círculo con los mensajes que llegaron mientras leías arriba (tope "99+").
  Se limpia al pulsar el botón o al llegar abajo haciendo scroll.
- **Acción**: `scrollToEnd({ animated: true })` — viaje animado al final.

## Archivos modificados

- `proyecto/mi-app-entrenos/screens/SocialScreen.js` (único archivo de app
  tocado; CRLF como siempre).
- `tests/chat-scroll-test.js` (NUEVO): simulación 1:1 de la política con 13
  escenarios (primera apertura, mensajes entrando arriba/abajo, voto de
  encuesta, selección, envío propio, vuelta de Retos con y sin mensajes
  nuevos, paginación, refresh, FAB, chat corto) + verificación a nivel de
  fuente. **58 aserciones**.
- `tests/dispatcher-test.js`: +5 aserciones de regresión del servidor
  (requires literales y `vercel.json`) → **43 aserciones**.

## Y el error "presign HTTP 404 … NOT_FOUND" al mandar imágenes

Eso NO era de la app: era del servidor desplegado en Vercel (dos fallos del
deploy del dispatcher: routing de un solo segmento y bundle sin `handlers/`
por el require dinámico). Está corregido y documentado en
**`VERCEL-HOBBY-12-FUNCIONES.md` → sección "RONDA 2"**. Hay que subir a
GitHub el nuevo `vercel.json` y el `api/[...path].js` actualizado (los ZIPs
de servidor ya llevan todo).

## Despliegue

- **App**: solo cambia `SocialScreen.js` → vale con OTA (EAS Update /
  `npx expo publish` según tu flujo). No añade dependencias nuevas.
- **Servidor**: ver `VERCEL-HOBBY-12-FUNCIONES.md` (subir `vercel.json` +
  `api/[...path].js` + `handlers/` completos y comprobar
  `GET /api/social/presign → 405 JSON`).

## Verificación rápida en el móvil

1. Abre el Tablón → carga abajo (normal).
2. Sube a mitad del chat → aparece el botón ↓.
3. Vota una encuesta → **no** salta; el botón ↓ sigue ahí.
4. Mantén pulsado un mensaje (selección) → **no** salta.
5. Vete a "Retos" y vuelve → **misma posición** exacta.
6. Que alguien envíe un mensaje mientras estás arriba → no salta; la
   insignia del ↓ suma 1. Pulsa ↓ → viaja al final y la insignia se limpia.
7. Envía tú un mensaje desde arriba → sí viaja al final (WhatsApp también).
8. Envía una imagen → ya sin error 404 (tras el deploy del servidor).
