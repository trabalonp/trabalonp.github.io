#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Corrige los 2 fallos detectados en producción tras el deploy del dispatcher:

A) ROUTING: el builder actual de Vercel (proyecto sin framework) registra
   api/[...path].js como ruta de UN SOLO SEGMENTO (^/api/([^/]+)$) y añade
   ^/api(/.*)?$ -> 404. Por eso /api/social/presign devolvía el 404 de la
   plataforma ("The page could not be found NOT_FOUND"). Solución: vercel.json
   con un rewrite /api/:path* -> /api/[...path]?path=:path* que el CLI coloca
   ANTES de la regla 404 (verificado con `vercel build` local).

B) BUNDLE: el require dinámico `require(RUTAS[clave])` es invisible para el
   trazador (nft) de Vercel: el .func se desplegaba SIN handlers/ ni lib/
   ("Cannot find module '../handlers/notify-athlete.js'"). Solución: mapa de
   thunks con require LITERAL (el trazador los detecta; la carga sigue siendo
   perezosa: cada handler solo se carga cuando llega su primera petición).
"""
import io, os

SRV = os.path.join('workspace-anterior', 'vercel-server', 'mi-app-entrenos-main')
DISP = os.path.join(SRV, 'api', '[...path].js')

# ── 1) vercel.json (LF, en la raíz del repo del servidor) ────────────────────
vercel_json = '''{
  "rewrites": [
    {
      "source": "/api/:path*",
      "destination": "/api/[...path]?path=:path*"
    }
  ]
}
'''
with io.open(os.path.join(SRV, 'vercel.json'), 'w', encoding='utf-8', newline='\n') as f:
    f.write(vercel_json)
print('OK vercel.json creado')

# ── 2) dispatcher: thunks con require literal ────────────────────────────────
with io.open(DISP, 'r', encoding='utf-8', newline='') as f:
    src = f.read()
assert '\r\n' not in src, 'el dispatcher debe usar LF'

VIEJO_MAPA = """const RUTAS = {
  'notify-athlete':            '../handlers/notify-athlete.js',
  'sync-fitness':              '../handlers/sync-fitness.js',
  'sync-intervals':            '../handlers/sync-intervals.js',
  'sync-intervals-detail':     '../handlers/sync-intervals-detail.js',
  'upload-to-intervals':       '../handlers/upload-to-intervals.js',
  'intervals/delete-event':    '../handlers/intervals/delete-event.js',
  'intervals/disconnect':      '../handlers/intervals/disconnect.js',
  'intervals/save-credentials': '../handlers/intervals/save-credentials.js',
  'intervals/status':          '../handlers/intervals/status.js',
  'social/delete-message':     '../handlers/social/delete-message.js',
  'social/link-preview':       '../handlers/social/link-preview.js',
  'social/presign':            '../handlers/social/presign.js',
  'social/purge':              '../handlers/social/purge.js',
};"""

NUEVO_MAPA = """// OJO: los require DEBEN ser literales (thunks) para que el trazador de
// Vercel (nft) los detecte y empaquete handlers/ + lib/ dentro de la
// función. Con `require(variable)` el bundle se desplegaba sin los
// handlers ("Cannot find module '../handlers/...'"). La carga sigue siendo
// perezosa: cada thunk solo se ejecuta cuando llega su primera petición.
const RUTAS = {
  'notify-athlete':              () => require('../handlers/notify-athlete.js'),
  'sync-fitness':                () => require('../handlers/sync-fitness.js'),
  'sync-intervals':              () => require('../handlers/sync-intervals.js'),
  'sync-intervals-detail':       () => require('../handlers/sync-intervals-detail.js'),
  'upload-to-intervals':         () => require('../handlers/upload-to-intervals.js'),
  'intervals/delete-event':      () => require('../handlers/intervals/delete-event.js'),
  'intervals/disconnect':        () => require('../handlers/intervals/disconnect.js'),
  'intervals/save-credentials':  () => require('../handlers/intervals/save-credentials.js'),
  'intervals/status':            () => require('../handlers/intervals/status.js'),
  'social/delete-message':       () => require('../handlers/social/delete-message.js'),
  'social/link-preview':         () => require('../handlers/social/link-preview.js'),
  'social/presign':              () => require('../handlers/social/presign.js'),
  'social/purge':                () => require('../handlers/social/purge.js'),
};"""

assert VIEJO_MAPA in src, 'mapa RUTAS no encontrado'
src = src.replace(VIEJO_MAPA, NUEVO_MAPA)

VIEJO_CALL = """    const clave = rutaDe(req);
    const modulo = RUTAS[clave];
    if (!modulo) {
      console.log(`[dispatcher] ruta /api/${clave} no existe`);
      return res.status(404).json({ error: 'Ruta no encontrada' });
    }
    const handler = require(modulo);
    return await handler(req, res);"""

NUEVO_CALL = """    const clave = rutaDe(req);
    const cargar = RUTAS[clave];
    if (!cargar) {
      console.log(`[dispatcher] ruta /api/${clave} no existe`);
      return res.status(404).json({ error: 'Ruta no encontrada' });
    }
    const handler = cargar();
    return await handler(req, res);"""

assert VIEJO_CALL in src, 'llamada al handler no encontrada'
src = src.replace(VIEJO_CALL, NUEVO_CALL)

# ── 3) comentario de cabecera: documentar el rewrite de vercel.json ──────────
VIEJA_CAB = """// El wrapper reproduce el contrato (req, res) del runtime Node de Vercel
// que los handlers ya usaban: req.method, req.headers, req.body (JSON),
// req.query, y res.status().json() / res.json() / res.send() /
// res.setHeader() / res.end(). Los handlers se cargan de forma perezosa:
// una ruta que no usa nunca paga su coste de arranque."""
NUEVA_CAB = VIEJA_CAB.replace('una ruta que no usa nunca', 'una ruta que no se usa nunca')
# (la cabecera real puede variar; se busca el párrafo del wrapper)
if VIEJA_CAB not in src:
    VIEJA_CAB = """// El wrapper reproduce el contrato (req, res) del runtime Node de Vercel
// que los handlers ya usaban: req.method, req.headers, req.body (JSON),
// req.query, y res.status().json() / res.json() / res.send() /
// res.setHeader() / res.end(). Los handlers se cargan de forma perezosa:
// una ruta que no se usa nunca paga su coste de arranque."""
    NUEVA_CAB = VIEJA_CAB
assert VIEJA_CAB in src, 'cabecera no encontrada'
src = src.replace(VIEJA_CAB, NUEVA_CAB + """
//
// IMPORTANTE — vercel.json (raíz del repo) es OBLIGATORIO junto a este
// archivo: el builder de Vercel para proyectos sin framework registra el
// catch-all del directorio api/ como ruta de UN SOLO segmento
// (^/api/([^/]+)$) y responde 404 de plataforma al resto de rutas /api/x/y.
// El rewrite de vercel.json (/api/:path* -> /api/[...path]?path=:path*)
// devuelve el emparejamiento completo de varios segmentos ANTES de la
// regla 404. Sin él, /api/social/presign y compañía devuelven
// "The page could not be found NOT_FOUND\".""")

with io.open(DISP, 'w', encoding='utf-8', newline='\n') as f:
    f.write(src)
print('OK dispatcher parcheado (thunks + cabecera)')

# ── 4) comprobaciones finales ────────────────────────────────────────────────
with io.open(DISP, 'r', encoding='utf-8', newline='') as f:
    out = f.read()
assert '\r\n' not in out
assert out.count("() => require('../handlers/") == 13, 'debe haber 13 thunks'
assert "require(modulo)" not in out
print('OK verificaciones LF + 13 thunks')
