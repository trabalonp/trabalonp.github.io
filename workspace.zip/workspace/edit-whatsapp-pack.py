#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Paquete WhatsApp: barra negra auto-oculta en el visor (sin numeración),
separadores de fecha, salto al mensaje citado, fondo sin velo blanco,
zonas automáticas (sin botón de descargar el chat) y audios reproducibles
en el chat (expo-audio). Preserva CRLF."""
import io, sys

P = 'proyecto/mi-app-entrenos/screens/SocialScreen.js'
src = io.open(P, 'r', encoding='utf-8', newline='').read()
assert '\r\n' in src

def crlf(s):
    return s.replace('\r\n', '\n').replace('\n', '\r\n')

REPL = []
def r(old, new, count=1):
    REPL.append((crlf(old), crlf(new), count))

# ── P1: cabecera, burbujas + novedades ──
r("""   · Burbujas (propias derecha verde / demás izquierda con avatar y nombre de
     color), hora abajo-derecha, reacciones con pulsación larga (una por
     persona, pills con contador), responder/reenviar/eliminar al seleccionar,
     citas y marca de reenviado.""",
"""   · Burbujas (propias derecha verde / demás izquierda con avatar y nombre de
     color), hora abajo-derecha, reacciones con pulsación larga (una por
     persona, pills con contador), responder/reenviar/eliminar al seleccionar,
     citas y marca de reenviado. Tocar la CITA salta al mensaje original si
     está cargado (destello azul); si no está, no hace nada.
   · Separadores de fecha estilo WhatsApp entre mensajes de días distintos:
     HOY / AYER / nombre del día (últimos 7 días) / "15 de marzo de 2024",
     en una píldora negra semitransparente centrada.
   · Audios reproducibles DENTRO del chat (expo-audio: play/pause, barra de
     progreso con seek, duración; uno a la vez) y archivos en tarjeta grande
     estilo WhatsApp (icono, nombre, extensión · tamaño).
   · Fondo del tablón tal cual se subió: sin velo blanco encima.""")

# ── P2: cabecera, sincronización por zonas automáticas ──
r("""   · Sincronización INCREMENTAL: al abrir solo se piden los mensajes
     posteriores al último sincronizado (where createdAt > lastSync); el
     historial antiguo se pagina hacia atrás en bloques de 50
     ("Cargar anteriores"). Nunca se descarga todo el chat.""",
"""   · Sincronización INCREMENTAL: al abrir solo se piden los mensajes
     posteriores al último sincronizado (where createdAt > lastSync); el
     historial antiguo se pagina hacia atrás AUTOMÁTICAMENTE por zonas de
     50 al rozar el borde superior (sin botón de "descargar el chat de la
     nube"). Motor en services/chatSync.js, verificado por
     tests/chat-sync-test.js. Nunca se descarga todo el chat.""")

# ── P3: require protegido de expo-audio ──
r("""import * as Sharing from 'expo-sharing';""",
"""import * as Sharing from 'expo-sharing';
// Reproductor de audio del chat (expo-audio, SDK 57). require PROTEGIDO: si
// el bundle llega por OTA a un binario antiguo sin el módulo nativo, la app
// sigue funcionando y los audios se abren con el panel del sistema.
let AudioLib = null;
try { AudioLib = require('expo-audio'); } catch (e) { AudioLib = null; }""")

# ── P4: imports de servicios nuevos ──
r("""import { chatStoreInit, chatStoreAll, chatStorePut, chatStoreMeta, chatStoreSetMeta } from '../services/chatStore';""",
"""import { chatStoreInit, chatStoreAll, chatStorePut, chatStoreMeta, chatStoreSetMeta } from '../services/chatStore';
import { gapSync, loadOlderZone } from '../services/chatSync';
import { claveDia, esAudioMedia, extDe, fmtDur, fmtSeparador, fmtSize } from '../services/fechasChat';""")

# ── P5: estado del destello ──
r("""  const [replyTo, setReplyTo] = useState(null);""",
"""  const [replyTo, setReplyTo] = useState(null);
  const [highlightId, setHighlightId] = useState(null);   // destello al saltar a un mensaje citado""")

# ── P6: refs de posiciones y temporizador ──
r("""  const pendingFix = useRef(null);     // { prevH, prevOff } al prepender antiguos""",
"""  const pendingFix = useRef(null);     // { prevH, prevOff } al prepender antiguos
  const posRef = useRef(new Map());    // id de mensaje -> { y } medido en el contenido
  const hlTimer = useRef(null);        // temporizador del destello""")

# ── P7: responder guarda id + salto al mensaje citado ──
r("""  const responder = (post) => {
    setReplyTo({ nombre: post.autorNombre, texto: post.texto || (post.media?.length ? '📎 ' + L('adjunto', 'attachment') : post.encuesta ? '📊 ' + L('encuesta', 'poll') : '') });
    setSelIds([]);
  };""",
"""  const responder = (post) => {
    // Se guarda también el id: tocar la cita salta al mensaje original
    setReplyTo({ id: post.id, nombre: post.autorNombre, texto: post.texto || (post.media?.length ? '📎 ' + L('adjunto', 'attachment') : post.encuesta ? '📊 ' + L('encuesta', 'poll') : '') });
    setSelIds([]);
  };

  /* Saltar al mensaje citado (WhatsApp): si el original está cargado hace
     scroll hasta él y lo destella 1.6 s; si no existe (cita antigua sin id
     o mensaje de una zona aún no cargada) NO hace nada. */
  const irAMensaje = useCallback((id) => {
    if (!id) return;
    if (!posts.some((x) => x.id === id)) return;
    const m = posRef.current.get(id);
    if (m) scrollRef.current?.scrollTo({ y: Math.max(0, m.y - insets.top - 70), animated: true });
    setHighlightId(id);
    if (hlTimer.current) clearTimeout(hlTimer.current);
    hlTimer.current = setTimeout(() => setHighlightId(null), 1600);
  }, [posts, insets.top]);""")

# ── P8: gapSync inline -> servicio chatSync ──
r("""  const gapSync = useCallback(async () => {
    const meta = await chatStoreMeta();
    let cursor = meta.lastSync || null;
    if (!cursor) {
      // Primera vez: página inicial con lo más reciente (no todo el historial)
      const snap = await getDocs(query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(60)));
      const docs = snap.docs.map((d) => ({ id: d.id, ...d.data() })).reverse();
      if (docs.length) {
        await chatStorePut(docs);
        await chatStoreSetMeta({ oldestAt: docs[0].createdAt, hasMore: snap.docs.length === 60 });
      }
      cursor = docs.length ? docs[docs.length - 1].createdAt : new Date(0).toISOString();
    }
    // Incremental: solo lo posterior al último sincronizado, en lotes de 300
    let guard = 0;
    while (guard++ < 5) {
      const snap = await getDocs(query(collection(db, 'posts'), where('createdAt', '>', cursor), orderBy('createdAt', 'asc'), limit(300)));
      const docs = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      if (docs.length) {
        await chatStorePut(docs);
        cursor = docs[docs.length - 1].createdAt;
      }
      if (snap.docs.length < 300) break;
    }
    await chatStoreSetMeta({ lastSync: cursor });
  }, []);""",
"""  // gapSync (primera página de 60 + incremental where createdAt > lastSync)
  // vive en services/chatSync.js: aislado y verificado por
  // tests/chat-sync-test.js contra un Firestore simulado.""")

# ── P9: cargarAnteriores usa loadOlderZone ──
r("""  // Paginación hacia atrás: bloques de 50 más antiguos que lo ya recibido.
  // Mantiene la posición del scroll (no te teletransporta al final).
  const cargarAnteriores = useCallback(async () => {
    if (loadingOld) return;
    setLoadingOld(true);
    try {
      const meta = await chatStoreMeta();
      if (!meta.oldestAt) { setHasMoreOld(false); return; }
      const snap = await getDocs(query(collection(db, 'posts'), where('createdAt', '<', meta.oldestAt), orderBy('createdAt', 'desc'), limit(50)));
      const docs = snap.docs.map((d) => ({ id: d.id, ...d.data() })).reverse();
      const mas = snap.docs.length === 50;
      await chatStorePut(docs);
      await chatStoreSetMeta({ oldestAt: docs.length ? docs[0].createdAt : meta.oldestAt, hasMore: mas });
      setHasMoreOld(mas);
      pendingFix.current = { prevH: contentH.current, prevOff: offsetRef.current };
      setPosts(await chatStoreAll());
    } catch (e) {
      console.warn('[social] antiguos:', e.message);
    } finally {
      setLoadingOld(false);
    }
  }, [loadingOld]);""",
"""  // Paginación AUTOMÁTICA por zonas (patrón WhatsApp del documento duck.ai):
  // bloques de 50 más antiguos, disparados al rozar el borde superior del
  // scroll — sin botón de "descargar el chat". Mantiene la posición.
  const cargarAnteriores = useCallback(async () => {
    if (loadingOld) return;
    setLoadingOld(true);
    try {
      const { hasMore } = await loadOlderZone();
      setHasMoreOld(hasMore);
      pendingFix.current = { prevH: contentH.current, prevOff: offsetRef.current };
      setPosts(await chatStoreAll());
    } catch (e) {
      console.warn('[social] antiguos:', e.message);
    } finally {
      setLoadingOld(false);
    }
  }, [loadingOld]);""")

# ── P10: deps del effect de sincronización ──
r("""  }, [tab, gapSync, reloadFromStore]);""",
"""  }, [tab, reloadFromStore]);""")

# ── P11: fondo sin velo blanco ──
r("""      {bgUri ? (
        <>
          <Image source={{ uri: bgUri }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} resizeMode="cover" />
          <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: c.bg, opacity: 0.78 }} />
        </>
      ) : null}""",
"""      {bgUri ? (
        /* Fondo TAL CUAL se subió: sin velo blanco ni tinte encima */
        <Image source={{ uri: bgUri }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} resizeMode="cover" />
      ) : null}""")

# ── P12: zonas automáticas en onScroll ──
r("""            onScroll={(e) => { offsetRef.current = e.nativeEvent.contentOffset.y; }}""",
"""            onScroll={(e) => {
              offsetRef.current = e.nativeEvent.contentOffset.y;
              // Zonas automáticas estilo WhatsApp: al rozar el borde superior
              // se carga el siguiente bloque de 50 (sin ningún botón).
              if (offsetRef.current < 220 && hasMoreOld && !loadingOld) cargarAnteriores();
            }}""")

# ── P13: fuera el botón de "Cargar mensajes anteriores" ──
r("""            {posts.length > 0 && (
              hasMoreOld ? (
                <TouchableOpacity onPress={cargarAnteriores} disabled={loadingOld} style={{ alignSelf: 'center', flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 10, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 999, backgroundColor: c.card, borderWidth: 1, borderColor: c.border }}>
                  {loadingOld ? <ActivityIndicator size="small" color={c.acc} /> : <Ionicons name="cloud-download-outline" size={15} color={c.acc} />}
                  <Text style={{ color: c.acc, fontWeight: '700', fontSize: 12 }}>{L('Cargar mensajes anteriores', 'Load older messages')}</Text>
                </TouchableOpacity>
              ) : (
                <Text style={{ color: c.mut, fontSize: 10, textAlign: 'center', marginBottom: 8 }}>
                  {L('Inicio del historial · este es el primer mensaje del chat', 'Start of history · this is the first message of the chat')}
                </Text>
              )
            )}""",
"""            {posts.length > 0 && (
              hasMoreOld ? (
                loadingOld ? (
                  <View style={{ alignSelf: 'center', marginVertical: 8 }}>
                    <ActivityIndicator size="small" color={c.acc} />
                  </View>
                ) : null
              ) : (
                <Text style={{ color: c.mut, fontSize: 10, textAlign: 'center', marginBottom: 8 }}>
                  {L('Inicio del historial · este es el primer mensaje del chat', 'Start of history · this is the first message of the chat')}
                </Text>
              )
            )}""")

# ── P14: separadores de fecha + medición + destello + salto a citas ──
r("""            ) : posts.map((p) => (
              <SocialErrorBoundary key={p.id}>
                <Burbuja p={p} me={me.uid} c={c} loc={loc} isLight={isLight}
                  selected={selIds.includes(p.id)}
                  onLongPress={() => toggleSel(p.id)} onOpenImage={openImage} />
              </SocialErrorBoundary>
            ))}""",
"""            ) : posts.map((p, i) => {
              // Separador de fecha estilo WhatsApp entre mensajes de días
              // distintos: HOY / AYER / nombre del día / fecha con mes y año.
              const prev = posts[i - 1];
              const nuevoDia = !prev || claveDia(prev.createdAt) !== claveDia(p.createdAt);
              return (
                <React.Fragment key={p.id}>
                  {nuevoDia && (
                    <View style={{ alignItems: 'center', marginVertical: 9 }}>
                      <View style={{ backgroundColor: 'rgba(0,0,0,0.42)', borderRadius: 16, paddingHorizontal: 14, paddingVertical: 6, maxWidth: '85%' }}>
                        <Text style={{ color: '#FFFFFFF2', fontSize: 12, fontWeight: '700', letterSpacing: 0.3 }}>{fmtSeparador(p.createdAt, loc, L)}</Text>
                      </View>
                    </View>
                  )}
                  <View onLayout={(ev) => { posRef.current.set(p.id, { y: ev.nativeEvent.layout.y }); }}>
                    <SocialErrorBoundary>
                      <Burbuja p={p} me={me.uid} c={c} loc={loc} isLight={isLight}
                        selected={selIds.includes(p.id)} highlighted={highlightId === p.id}
                        onTapReply={irAMensaje}
                        onLongPress={() => toggleSel(p.id)} onOpenImage={openImage} />
                    </SocialErrorBoundary>
                  </View>
                </React.Fragment>
              );
            })}""")

# ── P15: firma de Burbuja ──
r("""function Burbuja({ p, me, c, loc, isLight, onLongPress, onOpenImage, selected }) {""",
"""function Burbuja({ p, me, c, loc, isLight, onLongPress, onOpenImage, selected, highlighted, onTapReply }) {""")

# ── P16: borde de burbuja con destello ──
r("""        style={{ maxWidth: '78%', borderRadius: 14, backgroundColor: mio ? c.bubbleOwn : c.bubbleOther, borderWidth: selected ? 2.5 : (isLight ? 1 : 0), borderColor: selected ? '#8AB4F8' : c.border, paddingHorizontal: 10, paddingVertical: 7, overflow: 'hidden' }}>""",
"""        style={{ maxWidth: '78%', borderRadius: 14, backgroundColor: mio ? c.bubbleOwn : c.bubbleOther, borderWidth: selected || highlighted ? 2.5 : (isLight ? 1 : 0), borderColor: selected || highlighted ? '#8AB4F8' : c.border, paddingHorizontal: 10, paddingVertical: 7, overflow: 'hidden' }}>""")

# ── P17: cita tocable que salta al original ──
r("""        {p.replyTo && (
          <View style={{ backgroundColor: isLight ? '#00000010' : '#FFFFFF14', borderLeftWidth: 3, borderLeftColor: c.acc, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 5, marginBottom: 5 }}>
            <Text style={{ color: c.acc, fontWeight: '800', fontSize: 12 }}>{p.replyTo.nombre}</Text>
            <Text style={{ color: c.mut, fontSize: 12 }} numberOfLines={2}>{p.replyTo.texto}</Text>
          </View>
        )}""",
"""        {p.replyTo && (
          /* Tocar la cita salta al mensaje original si está cargado */
          <Pressable onPress={() => { if (onTapReply) onTapReply(p.replyTo.id); }}
            style={{ backgroundColor: isLight ? '#00000010' : '#FFFFFF14', borderLeftWidth: 3, borderLeftColor: c.acc, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 5, marginBottom: 5 }}>
            <Text style={{ color: c.acc, fontWeight: '800', fontSize: 12 }}>{p.replyTo.nombre}</Text>
            <Text style={{ color: c.mut, fontSize: 12 }} numberOfLines={2}>{p.replyTo.texto}</Text>
          </Pressable>
        )}""")

# ── P18: ChipArchivo recibe isLight ──
r("""            : <ChipArchivo key={i} m={m} c={c} />""",
"""            : <ChipArchivo key={i} m={m} c={c} isLight={isLight} />""")

# ── P19: tarjeta de archivo grande + reproductor de audio ──
r("""/* ── Chip de archivo ── */
function ChipArchivo({ m, c }) {
  return (
    <TouchableOpacity onPress={() => { if (m.url) Linking.openURL(m.url); }} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 5, padding: 8, borderRadius: 9, backgroundColor: '#00000012' }}>
      <Ionicons name="document-attach-outline" size={18} color={c.mut} />
      <Text style={{ color: c.txtBubble, flex: 1, fontSize: 13 }} numberOfLines={1}>{m.nombre || 'archivo'}</Text>
      <Ionicons name="download-outline" size={16} color={c.mut} />
    </TouchableOpacity>
  );
}""",
"""/* ── Tarjeta de archivo estilo WhatsApp: más ancha y más alta que el chip
      viejo (icono por tipo, nombre, extensión · tamaño). Los AUDIOS se
      reproducen dentro del propio chat (expo-audio, uno a la vez) y el
      resto de archivos se abre con el visor del sistema. ── */
function ChipArchivo({ m, c, isLight }) {
  if (esAudioMedia(m)) return <AudioBurbuja m={m} c={c} isLight={isLight} />;
  const meta = [extDe(m.nombre) || 'ARCHIVO', fmtSize(m.size)].filter(Boolean).join(' · ');
  return (
    <TouchableOpacity onPress={() => { if (m.url) Linking.openURL(m.url); }}
      style={{ flexDirection: 'row', alignItems: 'center', gap: 11, minWidth: 240, maxWidth: 300, minHeight: 66, marginTop: 6, marginBottom: 2, paddingHorizontal: 12, paddingVertical: 10, borderRadius: 14, backgroundColor: isLight ? '#0000000D' : '#FFFFFF14' }}>
      <View style={{ width: 40, height: 48, borderRadius: 8, backgroundColor: '#D35400', alignItems: 'center', justifyContent: 'center' }}>
        <Ionicons name="document-text-outline" size={22} color="#fff" />
      </View>
      <View style={{ flex: 1, gap: 3 }}>
        <Text style={{ color: c.txtBubble, fontSize: 14, fontWeight: '700' }} numberOfLines={2}>{m.nombre || 'archivo'}</Text>
        {!!meta && <Text style={{ color: c.mut, fontSize: 11 }} numberOfLines={1}>{meta}</Text>}
      </View>
      <Ionicons name="download-outline" size={18} color={c.mut} />
    </TouchableOpacity>
  );
}

/* ── Audio en el chat (WhatsApp): botón play/pause, barra de progreso con
      seek al tocar y duración. Solo suena UN audio a la vez; el archivo se
      baja a disco la primera vez (misma caché single-flight que imágenes). ── */
let playerActivo = null;
let modoAudioOk = false;
async function asegurarModoAudio() {
  if (modoAudioOk || !AudioLib) return;
  modoAudioOk = true;
  try { await AudioLib.setAudioModeAsync({ playsInSilentMode: true }); } catch (e) {}
}

function AudioBurbuja({ m, c, isLight }) {
  const caja = { flexDirection: 'row', alignItems: 'center', gap: 11, minWidth: 250, maxWidth: 300, marginTop: 6, marginBottom: 2, paddingHorizontal: 11, paddingVertical: 9, borderRadius: 14, backgroundColor: isLight ? '#0000000D' : '#FFFFFF14' };
  if (!AudioLib || !m.url) {
    // Binario sin expo-audio (OTA antigua) o sin URL: tarjeta que lo abre
    return (
      <TouchableOpacity onPress={() => { if (m.url) Linking.openURL(m.url); }} style={caja}>
        <View style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: '#8E44AD', alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="musical-notes-outline" size={20} color="#fff" />
        </View>
        <View style={{ flex: 1, gap: 3 }}>
          <Text style={{ color: c.txtBubble, fontSize: 14, fontWeight: '700' }} numberOfLines={1}>{m.nombre || 'Audio'}</Text>
          <Text style={{ color: c.mut, fontSize: 11 }} numberOfLines={1}>{['AUDIO', fmtSize(m.size)].filter(Boolean).join(' · ')}</Text>
        </View>
        <Ionicons name="play-circle-outline" size={22} color={c.mut} />
      </TouchableOpacity>
    );
  }
  return <ReproductorAudio m={m} c={c} isLight={isLight} caja={caja} />;
}

function ReproductorAudio({ m, c, isLight, caja }) {
  const [localUri, setLocalUri] = useState(() => diskCache.get(m.url) || null);
  const [bajando, setBajando] = useState(false);
  const [barW, setBarW] = useState(1);
  const cargada = useRef(false);
  const player = AudioLib.useAudioPlayer(null, { updateInterval: 250 });
  const status = AudioLib.useAudioPlayerStatus(player);

  // Al desmontar: si este audio sonaba, se detiene (nunca se queda sonando)
  useEffect(() => () => {
    if (playerActivo === player) playerActivo = null;
    try { player.pause(); } catch (e) {}
  }, []);

  const toggle = async () => {
    try {
      await asegurarModoAudio();
      let uri = localUri;
      if (!uri) {
        setBajando(true);
        try { uri = diskCache.get(m.url) || (await cachedOrDownload(m.url)); } finally { setBajando(false); }
        if (!uri) return;
        setLocalUri(uri);
      }
      if (!cargada.current) { player.replace({ uri }); cargada.current = true; }
      if (status && status.playing) { player.pause(); return; }
      // Un solo audio a la vez, como WhatsApp
      if (playerActivo && playerActivo !== player) { try { playerActivo.pause(); } catch (e) {} }
      playerActivo = player;
      if (status && status.didJustFinish) { try { await player.seekTo(0); } catch (e) {} }
      player.play();
    } catch (e) {}
  };

  const dur = status && status.duration > 0 ? status.duration : 0;
  const cur = status && status.currentTime > 0 ? Math.min(status.currentTime, dur || status.currentTime) : 0;
  const pct = dur > 0 ? Math.max(0, Math.min(1, cur / dur)) : 0;
  const playing = !!(status && status.playing);

  const seek = (ev) => {
    if (!dur) return;
    const x = ev && ev.nativeEvent ? ev.nativeEvent.locationX : 0;
    try { player.seekTo(Math.max(0, Math.min(1, x / (barW || 1))) * dur); } catch (e) {}
  };

  return (
    <View style={caja}>
      <TouchableOpacity onPress={toggle} style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: c.acc, alignItems: 'center', justifyContent: 'center' }}>
        {bajando ? <ActivityIndicator size="small" color="#fff" />
          : <Ionicons name={playing ? 'pause' : 'play'} size={playing ? 20 : 22} color="#fff" style={playing ? undefined : { marginLeft: 3 }} />}
      </TouchableOpacity>
      <View style={{ flex: 1, gap: 5 }}>
        <Text style={{ color: c.txtBubble, fontSize: 13, fontWeight: '700' }} numberOfLines={1}>{m.nombre || 'Audio'}</Text>
        <Pressable onPress={seek} onLayout={(e) => setBarW(e.nativeEvent.layout.width || 1)}
          style={{ height: 6, borderRadius: 3, backgroundColor: isLight ? '#00000022' : '#FFFFFF30', overflow: 'hidden' }}>
          <View style={{ width: `${Math.round(pct * 100)}%`, height: 6, borderRadius: 3, backgroundColor: c.acc }} />
        </Pressable>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Text style={{ color: c.mut, fontSize: 11 }}>{fmtDur(cur)}</Text>
          <Text style={{ color: c.mut, fontSize: 11 }}>{dur > 0 ? fmtDur(dur) : fmtSize(m.size) || 'AUDIO'}</Text>
        </View>
      </View>
    </View>
  );
}""")

# ── P20: docblock del visor ──
r("""   · expo-image: decodificación y caché memoria/disco eficientes; se
     precargan las fotos vecinas para que el swipe no muestre spinner.""",
"""   · expo-image: decodificación y caché memoria/disco eficientes; se
     precargan las fotos vecinas para que el swipe no muestre spinner.
   · Barra superior NEGRA (cerrar + compartir, sin numeración de fotos):
     se oculta en cuanto se hace un poco de zoom y vuelve al regresar a 1x.""")

# ── P21: insets en FocalViewer ──
r("""function FocalViewer({ urls, initialIndex, onClose }) {
  const [idx, setIdx] = useState(initialIndex || 0);""",
"""function FocalViewer({ urls, initialIndex, onClose }) {
  const insets = useSafeAreaInsets();
  const [idx, setIdx] = useState(initialIndex || 0);""")

# ── P22: descargar -> compartir + estilo animado de la barra ──
r("""  // Descargar: panel del sistema (incluye "Guardar imagen").
  const handleDownload = async () => {
    try {
      const u = urls[idx];
      const local = diskCache.get(u) || (await cachedOrDownload(u));
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(local, { dialogTitle: 'Guardar imagen' });
      }
    } catch (e) {}
  };""",
"""  // Compartir: panel del sistema (incluye "Guardar imagen").
  const compartir = async () => {
    try {
      const u = urls[idx];
      const local = diskCache.get(u) || (await cachedOrDownload(u));
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(local, { dialogTitle: 'Compartir imagen' });
      }
    } catch (e) {}
  };

  /* Barra superior NEGRA estilo WhatsApp (cerrar + compartir): se desliza
     fuera de pantalla y se desvanece en cuanto hay zoom, y vuelve sola al
     regresar a 1x. La animación vive en el hilo de UI (useAnimatedStyle). */
  const barStyle = useAnimatedStyle(() => {
    const vis = scale.value <= 1.02;
    return {
      opacity: withTiming(vis ? 1 : 0, { duration: 150 }),
      transform: [{ translateY: withTiming(vis ? 0 : -170, { duration: 220 }) }],
    };
  });""")

# ── P23: barra negra en el JSX (sin contador) ──
r("""          {/* Barra superior: cerrar, descargar, contador */}
          <View pointerEvents="box-none" style={{ position: 'absolute', top: 44, left: 14, right: 14, zIndex: 2, flexDirection: 'row', alignItems: 'center' }}>
            <TouchableOpacity onPress={onClose} style={{ padding: 8 }}><Ionicons name="close-circle" size={30} color="#fff" /></TouchableOpacity>
            <View style={{ flex: 1 }} />
            <TouchableOpacity onPress={handleDownload} style={{ padding: 8, marginRight: 6 }}><Ionicons name="download-outline" size={26} color="#fff" /></TouchableOpacity>
            <Text style={{ color: '#ffffffcc', fontWeight: '700' }}>{idx + 1} / {urls.length}</Text>
          </View>""",
"""          {/* Barra superior NEGRA: cerrar + compartir, SIN numeración de
              fotos. Se oculta sola con un poco de zoom y vuelve a 1x. */}
          <Reanimated.View pointerEvents="box-none" style={[{ position: 'absolute', top: 0, left: 0, right: 0, zIndex: 3, backgroundColor: '#000000', paddingTop: Math.max(insets.top, 24) + 8, paddingBottom: 10, paddingHorizontal: 8, flexDirection: 'row', alignItems: 'center' }, barStyle]}>
            <TouchableOpacity onPress={onClose} style={{ padding: 10 }} hitSlop={6}><Ionicons name="close" size={28} color="#fff" /></TouchableOpacity>
            <View style={{ flex: 1 }} />
            <TouchableOpacity onPress={compartir} style={{ padding: 10 }} hitSlop={6}><Ionicons name="share-outline" size={25} color="#fff" /></TouchableOpacity>
          </Reanimated.View>""")

# ── P24: icono de audio en la previsualización del compositor ──
r("""                <View style={{ width: 62, height: 62, alignItems: 'center', justifyContent: 'center', backgroundColor: c.bg }}>
                  <Ionicons name="document-outline" size={20} color={c.mut} />
                </View>""",
"""                <View style={{ width: 62, height: 62, alignItems: 'center', justifyContent: 'center', backgroundColor: c.bg }}>
                  <Ionicons name={esAudioMedia(m) ? 'musical-notes-outline' : 'document-outline'} size={20} color={c.mut} />
                </View>""")

fallos = 0
for i, (old, new, cnt) in enumerate(REPL, 1):
    n = src.count(old)
    if n != cnt:
        fallos += 1
        print('FALLO P%d: encontrado %d veces (esperaba %d): %r' % (i, n, cnt, old[:70]))
        continue
    src = src.replace(old, new)

if fallos:
    sys.exit('ABORTADO: %d patrones no casan' % fallos)

io.open(P, 'w', encoding='utf-8', newline='').write(src)
print('OK SocialScreen.js editado (%d reemplazos)' % len(REPL))
