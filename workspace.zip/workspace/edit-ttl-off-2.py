#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Parte 2: purge.js opcional (RETENTION_DAYS, desactivado por defecto) + vercel.json fuera."""
import io, os

def load(p):
    with io.open(p, 'r', encoding='utf-8', newline='') as f:
        return f.read()

def save(p, s):
    with io.open(p, 'w', encoding='utf-8', newline='') as f:
        f.write(s)

def rep(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit('FALLO %s: %d ocurrencias (esperaba 1)' % (label, n))
    return text.replace(old, new)

SRV = 'workspace-anterior/vercel-server/mi-app-entrenos-main'
p = os.path.join(SRV, 'api', 'social', 'purge.js')
s = load(p)

s = rep(s,
"""// api/social/purge.js
// PURGA DE CADUCIDAD DEL CHAT (patrón WhatsApp/temp-chat):
// los mensajes del Tablón nacen con `expiraAt` = createdAt + 30 días. Este
// cron diario elimina de Firestore (y de Cloudflare R2) todo lo caducado.
// Las copias LOCALES de cada dispositivo NO se tocan: quien recibió el
// mensaje lo sigue viendo en su historial (el listener de la app ignora los
// "removed" de caducidad a propósito).
//
// Seguridad: Vercel envía automáticamente `Authorization: Bearer <CRON_SECRET>`
// cuando el planificador invoca el cron (ver vercel.json). Sin ese secreto
// coincidiendo, 401. Crea CRON_SECRET en Vercel → Settings → Environment
// Variables (cadena aleatoria de 16+ caracteres).
//
// Doble criterio de purga (por si una de las dos vías falla):
//   1) expiraAt (Timestamp) < ahora          → mensajes de versiones nuevas
//   2) createdAt (ISO string) < ahora - 31 d → mensajes LEGACY sin expiraAt
""",
"""// api/social/purge.js
// HERRAMIENTA DE PURGA DEL CHAT — OPCIONAL y DESACTIVADA POR DEFECTO.
//
// El Tablón tiene ahora historial PERMANENTE: con la sincronización
// incremental (onSnapshot + createdAt > lastSync + paginación hacia atrás)
// la app nunca descarga el chat entero, así que el tamaño del historial no
// aumenta el coste ni la lentitud. La caducidad automática ya no es
// necesaria. Este endpoint queda dormido como herramienta de mantenimiento
// (p. ej. derecho al olvido, o si algún día se quisiera de nuevo un chat
// de mensajes temporales).
//
// Para ACTIVAR la purga harían falta 3 cosas:
//   1) RETENTION_DAYS=31 en Vercel → Environment Variables (días de vida
//      + margen; 0 o ausente = DESACTIVADO, no borra nada)
//   2) CRON_SECRET (cadena aleatoria de 16+ caracteres)
//   3) Un cron en vercel.json apuntando a /api/social/purge, p. ej.:
//      { "crons": [{ "path": "/api/social/purge", "schedule": "0 4 * * *" }] }
//
// Seguridad: Vercel envía `Authorization: Bearer <CRON_SECRET>` en cada
// invocación programada; sin ese secreto coincidiendo, 401.
//
// Doble criterio de purga (solo cuando está activada):
//   1) expiraAt (Timestamp) < ahora → mensajes antiguos que nacieron con caducidad
//   2) createdAt (ISO string) < ahora - RETENTION_DAYS → el resto
// Las copias LOCALES de cada dispositivo NO se tocan nunca.
""", 'cabecera purge')

s = rep(s,
"""  if (!secreto || auth !== `Bearer ${secreto}`) {
    return res.status(401).json({ error: 'No autorizado' });
  }

  try {
""",
"""  if (!secreto || auth !== `Bearer ${secreto}`) {
    return res.status(401).json({ error: 'No autorizado' });
  }

  // Retención configurable. Por defecto DESACTIVADA: el historial del chat
  // es permanente y este endpoint no borra nada salvo RETENTION_DAYS > 0.
  const dias = Number(process.env.RETENTION_DAYS || 0);
  if (!Number.isFinite(dias) || dias <= 0) {
    console.log('[purge] desactivado (RETENTION_DAYS ausente o 0): no se borra nada');
    return res.json({ ok: true, disabled: true, message: 'Purga desactivada: define RETENTION_DAYS > 0 para activarla' });
  }

  try {
""", 'gate RETENTION_DAYS')

s = rep(s,
"const DIAS_RETENCION = 31;      // 30 días de vida + 1 de margen\n",
"", 'const DIAS_RETENCION purge')

s = rep(s,
"    const corteIso = new Date(ahora - DIAS_RETENCION * 86400000).toISOString();",
"    const corteIso = new Date(ahora - dias * 86400000).toISOString();", 'corteIso')

s = rep(s,
"    // 1) Caducidad explícita (Timestamp)\n",
"    // 1) Caducidad explícita (mensajes antiguos que nacieron con expiraAt)\n", 'comentario criterio 1')

s = rep(s,
"    // 2) Legacy sin expiraAt: por fecha ISO de creación\n",
"    // 2) Sin expiraAt: por fecha ISO de creación (corte = RETENTION_DAYS)\n", 'comentario criterio 2')

if 'DIAS_RETENCION' in s:
    raise SystemExit('FALLO: queda DIAS_RETENCION en purge.js')
save(p, s)
print('OK purge.js')

p = os.path.join(SRV, 'vercel.json')
if os.path.exists(p):
    os.remove(p)
    print('OK vercel.json eliminado (el cron ya no es necesario)')

print('TODO OK')
