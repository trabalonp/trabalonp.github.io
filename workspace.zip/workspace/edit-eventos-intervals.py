#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fix: los EVENTOS se subían a Intervals.icu como entreno de fuerza.
Causa: SPORT_MAP no tiene 'Evento' → type caía a 'Workout', que en
Intervals.icu es el tipo de gimnasio/fuerza (y es obligatorio un deporte
real en categorías RACE_A/B/C).
Arreglo (lib/uploadWorkouts.js):
  · eventSport(): deporte explícito > palabras clave del título > Run.
  · buildPayload(): construcción de payload compartida y exportada.
  · Endpoint oficial recomendado: POST /athlete/{id}/events/bulk?upsert=true
    con external_id = id de Firestore (upsert: sin duplicados al resincronizar).
"""
import os

WS = os.environ.get("ARENA_WORKSPACE", os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(WS, "workspace-anterior", "vercel-server", "mi-app-entrenos-main", "lib", "uploadWorkouts.js")

raw = open(P, "rb").read().decode("utf-8")
CRLF = "\r\n" in raw
s = raw.replace("\r\n", "\n") if CRLF else raw
n0 = len(s)

def rep(old, new, count=1):
    global s
    assert s.count(old) >= count, "NO ENCONTRADO: %r..." % old[:90]
    s = s.replace(old, new, count)

# ── 1) eventSport(): deporte real para eventos (nunca 'Workout' = fuerza) ──
rep("""  Triatlón: 'Workout',
  Otro:     'Workout',
};
""",
"""  Triatlón: 'Workout',
  Otro:     'Workout',
};

/* Deporte para EVENTOS (categoría RACE_A): Intervals.icu exige un deporte
   real en las carreras y 'Workout' es su tipo de gimnasio/fuerza, así que
   nunca vale para un evento. Orden: campo explícito > palabras clave del
   título > Run (cross, carreras, maratones… el caso por defecto). */
function eventSport(w) {
  const expl = w.deporteEvento || w.deporte || w.disciplina;
  if (expl && SPORT_MAP[expl]) return SPORT_MAP[expl];
  const t = `${w.titulo || ''} ${w.descripcion || ''}`;
  if (/bici|ciclista|ciclismo|gran fondo|marcha ciclista|bike/i.test(t)) return 'Ride';
  if (/nataci|traves|aguas abiertas|swim/i.test(t)) return 'Swim';
  if (/triatl|duatl|acuatl/i.test(t)) return 'Other';
  return 'Run';
}
""")

# ── 2) buildPayload(): compartido entre sync y endpoint manual ──
rep("""async function uploadPendingWorkouts({ admin, db, connection, uid }) {
""",
"""/* Payload de calendario Intervals.icu según el tipo del documento:
   Descanso → NOTE · Evento → RACE_A (con deporte real) · resto → WORKOUT. */
function buildPayload(w, zones, warn) {
  const start = w.fecha?.toDate ? w.fecha.toDate() : new Date(w.fecha);
  const est = estimateSeconds(w.pasos);
  const durSecs = w.duracion || (est > 0 ? est : 3600);
  const end = new Date(start.getTime() + durSecs * 1000);
  const raw = w.titulo || w.tipo || 'Entrenamiento';
  const name = raw.startsWith('*') ? raw.slice(1).trim() : raw;
  const freeText = w.descripcion || '';
  const stepsDesc = buildStepsDescription(w.pasos, zones, warn);
  const sport = w.tipo === 'Evento' ? eventSport(w) : (SPORT_MAP[w.tipo] || 'Workout');

  let payload;
  if (w.tipo === 'Descanso') {
    payload = {
      category: 'NOTE', name,
      description: freeText || name,
      start_date_local: localIso(start),
      end_date_local: localIso(end),
    };
  } else if (w.tipo === 'Evento') {
    payload = {
      category: 'RACE_A', type: sport, name,
      description: freeText,
      start_date_local: localIso(start),
      end_date_local: localIso(end),
    };
  } else {
    const fullDesc = [stepsDesc, stepsDesc && freeText ? '' : null, freeText]
      .filter(Boolean).join('\\n');
    payload = {
      category: 'WORKOUT', type: sport, name,
      start_date_local: localIso(start),
      end_date_local: localIso(end),
      moving_time: durSecs,
      description: fullDesc,
    };
  }
  return { payload, stepsDesc };
}

async function uploadPendingWorkouts({ admin, db, connection, uid }) {
""")

# ── 3) El bucle usa buildPayload + endpoint bulk con upsert y external_id ──
rep("""      const start = w.fecha?.toDate ? w.fecha.toDate() : new Date(w.fecha);
      const est = estimateSeconds(w.pasos);
      const durSecs = w.duracion || (est > 0 ? est : 3600);
      const end = new Date(start.getTime() + durSecs * 1000);
      const raw = w.titulo || w.tipo || 'Entrenamiento';
      const name = raw.startsWith('*') ? raw.slice(1).trim() : raw;
      const freeText = w.descripcion || '';
      const stepsDesc = buildStepsDescription(w.pasos, zones, (msg) => console.warn(`[uploadWorkouts] ${w.id}: ${msg}`));
      const sport = SPORT_MAP[w.tipo] || 'Workout';

      let payload;
      if (w.tipo === 'Descanso') {
        payload = {
          category: 'NOTE', name,
          description: freeText || name,
          start_date_local: localIso(start),
          end_date_local: localIso(end),
        };
      } else if (w.tipo === 'Evento') {
        payload = {
          category: 'RACE_A', type: sport, name,
          description: freeText,
          start_date_local: localIso(start),
          end_date_local: localIso(end),
        };
      } else {
        const fullDesc = [stepsDesc, stepsDesc && freeText ? '' : null, freeText]
          .filter(Boolean).join('\\n');
        payload = {
          category: 'WORKOUT', type: sport, name,
          start_date_local: localIso(start),
          end_date_local: localIso(end),
          moving_time: durSecs,
          description: fullDesc,
        };
      }

      const res = await fetch(`${BASE}/athlete/${aid}/events`, {
        method: 'POST', headers, body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const t = await res.text().catch(() => '');
        console.warn(`[uploadWorkouts] Error ${w.id} (${w.tipo}): HTTP ${res.status} ${t.slice(0, 200)}`);
        continue;
      }
      const c = await res.json().catch(() => ({}));
""",
"""      const { payload, stepsDesc } = buildPayload(w, zones, (msg) => console.warn(`[uploadWorkouts] ${w.id}: ${msg}`));
      payload.external_id = w.id;   // upsert por nuestro id: sin duplicados al resincronizar

      // Endpoint oficial recomendado por Intervals.icu (guía "Uploading
      // planned workouts"): /events/bulk?upsert=true con external_id.
      const res = await fetch(`${BASE}/athlete/${aid}/events/bulk?upsert=true`, {
        method: 'POST', headers, body: JSON.stringify([payload]),
      });
      if (!res.ok) {
        const t = await res.text().catch(() => '');
        console.warn(`[uploadWorkouts] Error ${w.id} (${w.tipo}): HTTP ${res.status} ${t.slice(0, 200)}`);
        continue;
      }
      const arr = await res.json().catch(() => []);
      const c = (Array.isArray(arr) ? (arr.find((x) => x && x.external_id === w.id) || arr[0]) : arr) || {};
""")

# ── 4) Exportaciones nuevas ──
rep("""module.exports = { uploadPendingWorkouts };
""",
"""module.exports = { uploadPendingWorkouts, buildPayload, eventSport, localIso, loadAppZones };
""")

out = s.replace("\n", "\r\n") if CRLF else s
open(P, "wb").write(out.encode("utf-8"))
print("OK: lib/uploadWorkouts.js (%d → %d bytes, CRLF=%s)" % (n0, len(s), CRLF))
