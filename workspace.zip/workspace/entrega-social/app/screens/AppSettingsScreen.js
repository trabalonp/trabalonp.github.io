// screens/AppSettingsScreen.js
import React, { useEffect, useState } from 'react';
import { Alert, Modal, ScrollView, StyleSheet, Text, TouchableOpacity, View, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { getSocialBg, setSocialBg, clearSocialBg } from '../services/socialBg';
import { useNavigation } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import SystemBars from '../components/SystemBars';
import { getThemeColors, loadSettings, saveSettings, t, useAppSettings } from '../services/appSettings';

const NAVY = '#0D1B2A', CARD = '#162032', BLUE = '#4A90E2', BORDER = '#1E3048';

const PICKER_TITLES = {
  language: 'appsettings.language',
  units: 'appsettings.units',
  dateFormat: 'appsettings.dateFormat',
};

export default function AppSettingsScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const [picker, setPicker] = useState(null); // 'language' | 'units' | 'dateFormat'

  // Fondo del Tablón: 100% local (nunca se sube a la nube)
  const [bgSet, setBgSet] = useState(false);
  const lang = settings.language;
  const L = (es, en) => (lang === 'en' ? en : es);
  useEffect(() => { (async () => { try { setBgSet(!!(await getSocialBg())); } catch (e) {} })(); }, []);
  const pickBg = async () => {
    // quality: 1 -> la imagen se guarda TAL CUAL se subió (sin recomprimir)
    const r = await ImagePicker.launchImageLibraryAsync({ quality: 1 });
    if (r.canceled || !r.assets?.length) return;
    try { await setSocialBg(r.assets[0].uri); setBgSet(true); } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };
  const removeBg = async () => { await clearSocialBg(); setBgSet(false); };
  const handleBg = () => {
    const opts = [];
    if (bgSet) opts.push({ text: L('Quitar fondo', 'Remove background'), style: 'destructive', onPress: removeBg });
    opts.push({ text: bgSet ? L('Cambiar imagen', 'Change image') : L('Elegir imagen', 'Choose image'), onPress: pickBg });
    opts.push({ text: L('Cancelar', 'Cancel'), style: 'cancel' });
    Alert.alert(L('Fondo del Tablón', 'Chat background'),
      L('La imagen se guarda SOLO en tu teléfono; nunca se sube a la nube.',
        'The image is stored ONLY on your phone; never uploaded to the cloud.'), opts);
  };

  // OPTIONS dentro del componente: las etiquetas traducidas se recalculan al cambiar idioma.
  // Idioma y unidades quedan literales a propósito (se entienden en ambos idiomas).
  const OPTIONS = {
    language: [
      { value: 'es', label: 'Español' },
      { value: 'en', label: 'English' },
    ],
    units: [
      { value: 'metric',   label: t('units.metric')   },
      { value: 'imperial', label: t('units.imperial') },
    ],
    dateFormat: [
      { value: 'largo',      label: t('fmt.largo')      },
      { value: 'dd/mm/yyyy', label: t('fmt.ddmmyyyy')   },
      { value: 'mm/dd/yyyy', label: t('fmt.mmddyyyy')   },
      { value: 'yyyy-mm-dd', label: t('fmt.yyyymmdd')   },
    ],
  };

  const currentLabel = (key) => {
    const opt = (OPTIONS[key] || []).find(o => o.value === settings[key]);
    return opt ? opt.label : '';
  };
  const choose = (value) => {
    saveSettings({ [picker]: value });
    setPicker(null);
  };
  const handleUpdate = async () => {
    await loadSettings();
    Alert.alert(t('appsettings.updated'), t('appsettings.updatedMsg'));
  };

  const Row = ({ icon, label, value, onPress }) => (
    <TouchableOpacity style={[st.row, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={onPress} activeOpacity={0.8}>
      <Ionicons name={icon} size={20} color={BLUE} />
      <View style={{ flex: 1 }}>
        <Text style={[st.rowLabel, { color: theme.text }]}>{label}</Text>
      </View>
      <Text style={st.rowValue} numberOfLines={1}>{value}</Text>
      <Ionicons name="chevron-forward" size={16} color="#4A6080" />
    </TouchableOpacity>
  );

  return (
    <View style={[st.container, { backgroundColor: theme.background }]}>
      <View style={[st.header, { backgroundColor: theme.card, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={24} color="#8FA8C8" />
        </TouchableOpacity>
        <Text style={[st.headerTitle, { color: theme.text }]}>{t('appsettings.title')}</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={[st.scroll, { paddingBottom: Math.max(40, insets.bottom + 16) }]}>
        <Row
          icon="language-outline"
          label={t('appsettings.language')}
          value={currentLabel('language')}
          onPress={() => setPicker('language')}
        />
        <Row
          icon="swap-horizontal-outline"
          label={t('appsettings.units')}
          value={currentLabel('units')}
          onPress={() => setPicker('units')}
        />
        <Row
          icon="calendar-outline"
          label={t('appsettings.dateFormat')}
          value={currentLabel('dateFormat')}
          onPress={() => setPicker('dateFormat')}
        />

        <Row
          icon="image-outline"
          label={L('Fondo del Tablón', 'Chat background')}
          value={bgSet ? L('Puesto', 'Set') : L('Sin poner', 'Not set')}
          onPress={handleBg}
        />

        <TouchableOpacity style={st.updateBtn} onPress={handleUpdate}>
          <Ionicons name="refresh" size={18} color="#fff" />
          <Text style={st.updateBtnText}>{t('appsettings.update')}</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Modal de selección: lista completa de opciones con check en la activa */}
      <Modal visible={!!picker} transparent animationType="fade" onRequestClose={() => setPicker(null)}>
        <View style={st.overlay}>
          <TouchableOpacity style={st.overlayClose} activeOpacity={1} onPress={() => setPicker(null)} />
          <View style={[st.pickerBox, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <Text style={[st.pickerTitle, { color: theme.muted }]}>{picker ? t(PICKER_TITLES[picker]) : ''}</Text>
            <ScrollView bounces={false} style={st.pickerScroll}>
              {(OPTIONS[picker] || []).map(o => (
                <TouchableOpacity
                  key={o.value}
                  style={[st.opt, { borderBottomColor: theme.border }, settings[picker] === o.value && [st.optActive, { backgroundColor: theme.input }]]}
                  onPress={() => choose(o.value)}
                >
                  <Text style={[st.optText, { color: theme.text }, settings[picker] === o.value && st.optTextActive]}>{o.label}</Text>
                  {settings[picker] === o.value && <Ionicons name="checkmark-circle" size={18} color={BLUE} />}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
        <SystemBars />
      </Modal>
    </View>
  );
}

const st = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 56, paddingBottom: 16,
    borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  scroll: { padding: 16, paddingBottom: 40, gap: 10 },
  row: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: CARD, borderRadius: 12, borderWidth: 1, borderColor: BORDER,
    paddingHorizontal: 14, paddingVertical: 14,
  },
  rowLabel: { color: '#fff', fontSize: 15, fontWeight: '600' },
  rowValue: { color: '#8FA8C8', fontSize: 13, maxWidth: 150 },
  updateBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: BLUE, borderRadius: 12, paddingVertical: 14, marginTop: 8,
  },
  updateBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  overlay: { flex: 1, backgroundColor: '#00000088', justifyContent: 'center', alignItems: 'center' },
  overlayClose: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
  pickerBox: {
    width: '80%', backgroundColor: '#1B1B1D', borderRadius: 12,
    overflow: 'hidden', paddingVertical: 6, zIndex: 10,
  },
  pickerTitle: {
    color: '#8FA8C8', fontSize: 12, fontWeight: '700',
    paddingHorizontal: 16, paddingTop: 10, paddingBottom: 6,
    textTransform: 'uppercase', letterSpacing: 0.6,
  },
  pickerScroll: { maxHeight: 340 },
  opt: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: '#2A2A2D',
  },
  optActive: { backgroundColor: '#2A4060' },
  optText: { color: '#fff', fontSize: 14 },
  optTextActive: { fontWeight: '700' },
});
