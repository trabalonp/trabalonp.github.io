#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SocialScreen.js — política de scroll estilo WhatsApp + FAB "ir abajo".

CORRIGE (los 3 saltos denunciados):
  1) Votar en una encuesta → onContentSizeChange hacía scrollToEnd CIEGO con
     cualquier cambio de altura (el voto cambia la altura de la burbuja unos
     px) → ahora solo se sigue el chat cuando crece el NÚMERO de mensajes.
  2) Ir a "Retos" y volver → el effect de sync se re-ejecutaba con alFinal()
     incondicional + el ScrollView remontaba con scrollToEnd ciego → ahora:
     al salir se guarda {y,h} y al volver se RESTAURA la posición exacta;
     el effect solo fuerza el final en la PRIMERA carga de la sesión.
  3) Seleccionar un mensaje (pulsación larga) → el cambio de estilo altera
     la altura → mismo arreglo que (1).

AÑADE:
  · FAB circular ↓ a la derecha, encima de la isla flotante, con el mismo
    aspecto que las fichas de fecha (rgba(0,0,0,0.42) + blanco), estilo
    WhatsApp, con insignia de mensajes no vistos y scroll animado al final.
  · Regla WhatsApp completa: mensajes nuevos solo arrastran el viewport si
    el usuario YA estaba al final; si está leyendo historial, no se le
    interrumpe (se acumulan en la insignia del FAB).
  · Mensaje propio (enviar/reenviar) y primera apertura: SIEMPRE al final.

Verificado por tests/chat-scroll-test.js (simulación 1:1 de la política).
"""
import io, os

APP = os.path.join('proyecto', 'mi-app-entrenos')
P = os.path.join(APP, 'screens', 'SocialScreen.js')

with io.open(P, 'r', encoding='utf-8', newline='') as f:
    s = f.read()
assert '\r\n' in s
n0 = s.count('\r\n')

def C(t):
    """Convierte un bloque escrito con \n a CRLF (convención del proyecto app)."""
    return t.replace('\n', '\r\n')

def reemplaza(viejo, nuevo, etiqueta):
    global s
    v, n = C(viejo), C(nuevo)
    assert s.count(v) == 1, 'patrón no único o ausente: ' + etiqueta
    s = s.replace(v, n)
    print('OK', etiqueta)

# ── 0) Cabecera: nueva viñeta descriptiva ────────────────────────────────────
reemplaza(
"""   RETOS: coach crea con métrica, periodo y atletas invitados; invitados""",
"""   · Scroll estilo WhatsApp: el viewport SOLO sigue el chat si ya estaba
     abajo. Votar una encuesta, reaccionar, seleccionar un mensaje o recibir
     mensajes mientras lees historial ya NO te arrastran al último mensaje;
     al volver de la pestaña "Retos" se restaura la posición exacta. Cuando
     NO estás abajo aparece un botón circular ↓ sobre la isla flotante
     (mismo diseño que las fichas de fecha, con insignia de no vistos).
   RETOS: coach crea con métrica, periodo y atletas invitados; invitados""",
'cabecera')

# ── 1) Refs y estados nuevos ─────────────────────────────────────────────────
reemplaza(
"""  const pendingFix = useRef(null);     // { prevH, prevOff } al prepender antiguos
""",
"""  const pendingFix = useRef(null);     // { prevH, prevOff } al prepender antiguos
  const enElFinalRef = useRef(true);   // ¿el viewport está al final del chat?
  const prevCountRef = useRef(0);      // nº de mensajes en el último cambio de contenido
  const forzarFinalRef = useRef(false);// el próximo crecimiento FUERZA ir al final (mensaje propio)
  const restaurarRef = useRef(null);   // { y, h } guardado al salir a "Retos": se restaura al volver
  const primeraCargaRef = useRef(true);// primera carga del chat en esta sesión de la pantalla
  const [mostrarIrAbajo, setMostrarIrAbajo] = useState(false);  // visibilidad del FAB ↓
  const mostrarIrAbajoRef = useRef(false);                      // espejo del FAB (evita setState por evento)
  const [nuevosSinVer, setNuevosSinVer] = useState(0);          // insignia de no vistos del FAB ↓
""",
'refs/estados')

# ── 2) alFinal suave/forzado + irAlFinal del FAB + efecto guardar posición ───
reemplaza(
"""  const alFinal = () => setTimeout(() => scrollRef.current?.scrollToEnd({ animated: false }), 60);
""",
"""  /* Scroll estilo WhatsApp: alFinal() solo baja si el usuario YA está al
     final (suave: no interrumpe la lectura del historial); alFinal(true)
     lo fuerza siempre (mensajes propios y primera apertura del chat). */
  const alFinal = (forzar = false) => setTimeout(() => {
    if (forzar || enElFinalRef.current) scrollRef.current?.scrollToEnd({ animated: false });
  }, 60);

  /* FAB ↓ (círculo sobre la isla): vuelve al último mensaje con animación
     y limpia la cuenta de mensajes no vistos. */
  const irAlFinal = () => {
    setNuevosSinVer(0);
    scrollRef.current?.scrollToEnd({ animated: true });
  };

  /* Al pasar a la pestaña "Retos" el ScrollView se desmonta: se guarda la
     posición exacta y se restaura al volver (WhatsApp no te tira al último
     mensaje cuando regresas a una conversación). */
  useEffect(() => {
    if (tab !== 'tablon') restaurarRef.current = { y: offsetRef.current, h: contentH.current };
  }, [tab]);
""",
'alFinal + irAlFinal + guardado de posición')

# ── 3) Effect de sincronización: solo fuerza el final la primera vez ─────────
reemplaza(
"""        await chatStoreInit();
        await reloadFromStore();
        setLoading(false);
        alFinal();
        await gapSync();
        if (!alive) return;
        await reloadFromStore();
        alFinal();
""",
"""        await chatStoreInit();
        await reloadFromStore();
        setLoading(false);
        if (primeraCargaRef.current) {
          // Primera apertura del chat: sí se va al último mensaje (WhatsApp).
          // Al VOLVER de "Retos" esto no se ejecuta: restaurarRef devuelve
          // el viewport a la posición guardada (ver onContentSizeChange).
          primeraCargaRef.current = false;
          forzarFinalRef.current = true;
          alFinal(true);
        }
        await gapSync();
        if (!alive) return;
        await reloadFromStore();
        alFinal();   // suave: solo sigue el final si el usuario ya estaba ahí
""",
'effect de sync')

# ── 4) reenviarVarios: reenvío propio = siempre al final ─────────────────────
reemplaza(
"""      await chatStorePut(nuevos);
      await chatStoreSetMeta({ lastSync: new Date().toISOString() });
      setPosts(await chatStoreAll());
      alFinal();
""",
"""      await chatStorePut(nuevos);
      await chatStoreSetMeta({ lastSync: new Date().toISOString() });
      setPosts(await chatStoreAll());
      forzarFinalRef.current = true;   // reenvío propio: siempre al final
      alFinal(true);
""",
'reenviarVarios')

# ── 5) onScroll: criterio "al final" + visibilidad del FAB ───────────────────
reemplaza(
"""            onScroll={(e) => {
              offsetRef.current = e.nativeEvent.contentOffset.y;
              // Zonas automáticas estilo WhatsApp: al rozar el borde superior
              // se carga el siguiente bloque de 50 (sin ningún botón).
              if (offsetRef.current < 220 && hasMoreOld && !loadingOld) cargarAnteriores();
            }}
""",
"""            onScroll={(e) => {
              const ev = e.nativeEvent;
              offsetRef.current = ev.contentOffset.y;
              // Remontaje en curso (se vuelve de "Retos"): no se evalúa nada
              // hasta que onContentSizeChange restaure la posición guardada.
              if (restaurarRef.current) return;
              // "Estar al final" con tolerancia de ~70 px (criterio WhatsApp):
              // solo en ese caso los mensajes nuevos arrastran el viewport.
              const dist = ev.contentSize.height - ev.layoutMeasurement.height - ev.contentOffset.y;
              enElFinalRef.current = dist <= 70;
              if (enElFinalRef.current && nuevosSinVer !== 0) setNuevosSinVer(0);
              // FAB ↓: visible si NO se está al final y el chat desborda la pantalla
              const fab = !enElFinalRef.current && ev.contentSize.height > ev.layoutMeasurement.height + 120;
              if (fab !== mostrarIrAbajoRef.current) { mostrarIrAbajoRef.current = fab; setMostrarIrAbajo(fab); }
              // Zonas automáticas estilo WhatsApp: al rozar el borde superior
              // se carga el siguiente bloque de 50 (sin ningún botón).
              if (offsetRef.current < 220 && hasMoreOld && !loadingOld) cargarAnteriores();
            }}
""",
'onScroll')

# ── 6) onContentSizeChange: la política completa (el núcleo del arreglo) ─────
reemplaza(
"""            onContentSizeChange={(w, h) => {
              // Al PREPENDER historial antiguo mantiene la posición del scroll;
              // en cualquier otro cambio (mensaje nuevo, teclado…) va al final.
              const fix = pendingFix.current;
              contentH.current = h;
              if (fix) {
                pendingFix.current = null;
                scrollRef.current?.scrollTo({ y: Math.max(0, h - fix.prevH + fix.prevOff), animated: false });
              } else {
                scrollRef.current?.scrollToEnd({ animated: false });
              }
            }}
""",
"""            onContentSizeChange={(w, h) => {
              contentH.current = h;
              // Al PREPENDER historial antiguo mantiene el viewport en el
              // mismo mensaje (el contenido crece por arriba).
              const fix = pendingFix.current;
              if (fix) {
                pendingFix.current = null;
                prevCountRef.current = posts.length;
                scrollRef.current?.scrollTo({ y: Math.max(0, h - fix.prevH + fix.prevOff), animated: false });
                return;
              }
              // Al VOLVER de la pestaña "Retos": restaura la posición guardada
              // en cuanto el layout ha reproducido el alto que tenía al salir.
              // Mientras se remonta NUNCA se hace scrollToEnd (era el salto).
              const rest = restaurarRef.current;
              if (rest) {
                if (h >= rest.h * 0.98) {
                  restaurarRef.current = null;
                  prevCountRef.current = posts.length;
                  scrollRef.current?.scrollTo({ y: rest.y, animated: false });
                }
                return;
              }
              // Solo se "sigue el chat" cuando AUMENTAN los mensajes. Un
              // cambio de altura por votar una encuesta, reaccionar,
              // seleccionar un mensaje o cargarse una imagen YA NO mueve el
              // viewport (ese era el salto molesto al último mensaje).
              const nuevos = posts.length - prevCountRef.current;
              prevCountRef.current = posts.length;
              if (nuevos <= 0) return;
              if (forzarFinalRef.current || enElFinalRef.current) {
                // Mensaje propio / primera apertura, o ya se estaba abajo:
                // se sigue la conversación hasta el final.
                forzarFinalRef.current = false;
                scrollRef.current?.scrollToEnd({ animated: false });
              } else {
                // Leyendo historial: no se interrumpe; los no vistos se
                // acumulan en la insignia del FAB ↓.
                setNuevosSinVer((n) => n + nuevos);
              }
            }}
""",
'onContentSizeChange')

# ── 7) FAB ↓ + onPublicado forzado ────────────────────────────────────────────
reemplaza(
"""            <ComposerIsland c={c} L={L} replyTo={replyTo} onCancelReply={() => setReplyTo(null)}
              onPublicado={() => { reloadFromStore().then(() => alFinal()); }} />
""",
"""            {mostrarIrAbajo && (
              <View pointerEvents="box-none" style={{ flexDirection: 'row', justifyContent: 'flex-end', paddingRight: 6, marginBottom: 8 }}>
                {/* FAB ↓ estilo WhatsApp: círculo con el MISMO aspecto que las
                    fichas de fecha del chat (negro translúcido + blanco) e
                    insignia con los mensajes no vistos mientras se lee arriba */}
                <Pressable
                  onPress={irAlFinal}
                  style={({ pressed }) => ({
                    width: 42, height: 42, borderRadius: 21,
                    backgroundColor: pressed ? 'rgba(0,0,0,0.58)' : 'rgba(0,0,0,0.42)',
                    alignItems: 'center', justifyContent: 'center',
                    borderWidth: 1, borderColor: 'rgba(255,255,255,0.16)',
                    elevation: 3, shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 3, shadowOffset: { width: 0, height: 1 },
                  })}
                >
                  <Ionicons name="chevron-down" size={24} color="#FFFFFFF2" />
                  {nuevosSinVer > 0 && (
                    <View style={{ position: 'absolute', top: -7, right: -7, minWidth: 20, height: 20, paddingHorizontal: 5, borderRadius: 10, backgroundColor: c.acc, alignItems: 'center', justifyContent: 'center' }}>
                      <Text style={{ color: '#FFFFFF', fontSize: 11, fontWeight: '800' }}>{nuevosSinVer > 99 ? '99+' : nuevosSinVer}</Text>
                    </View>
                  )}
                </Pressable>
              </View>
            )}
            <ComposerIsland c={c} L={L} replyTo={replyTo} onCancelReply={() => setReplyTo(null)}
              onPublicado={() => { forzarFinalRef.current = true; reloadFromStore().then(() => alFinal(true)); }} />
""",
'FAB + onPublicado')

with io.open(P, 'w', encoding='utf-8', newline='') as f:
    f.write(s)

n1 = s.count('\r\n')
assert '\n' not in s.replace('\r\n', ''), 'quedan LF sueltos'
print('OK escrito: %s — líneas CRLF antes %d, ahora %d' % (P, n0, n1))
