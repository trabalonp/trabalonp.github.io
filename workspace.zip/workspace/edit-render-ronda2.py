#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Rendimiento ronda 2:
  A) Las gráficas se 'borraban' al cambiar de pestaña: con bottom-tabs, al
     ocultar la pantalla el onLayout dispara con tamaño 0 y el chart se
     vaciaba. Ahora se ignora cualquier layout con tamaño 0 (se conserva el
     último válido).
  B) El montaje diferido de la tarjeta se retrasa 700 ms extra tras la
     animación de entrada, para que el pequeño hitch del montaje no se
     perciba justo al abrir Ajustes.
"""
import os

WS = os.environ.get("ARENA_WORKSPACE", os.path.dirname(os.path.abspath(__file__)))
BASE = os.path.join(WS, "proyecto", "mi-app-entrenos")

def edit(path, pairs):
    raw = open(path, "rb").read().decode("utf-8")
    crlf = "\r\n" in raw
    s = raw.replace("\r\n", "\n") if crlf else raw
    for old, new in pairs:
        assert s.count(old) >= 1, "NO ENCONTRADO en %s: %r" % (path, old[:80])
        s = s.replace(old, new)
    out = s.replace("\n", "\r\n") if crlf else s
    open(path, "wb").write(out.encode("utf-8"))
    print("OK:", os.path.relpath(path, WS))

GUARD_SIZE = (
    "onLayout={(e) => setSize({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height })}",
    "onLayout={(e) => {\n"
    "          // Si la pestaña se oculta, el layout viene con tamaño 0: lo ignoramos\n"
    "          // para que la gráfica no se 'borre' durante el cambio de pantalla.\n"
    "          const { width, height } = e.nativeEvent.layout;\n"
    "          if (width > 0 && height > 0) setSize({ w: width, h: height });\n"
    "        }}",
)

edit(os.path.join(BASE, "components", "FitnessChart.js"), [GUARD_SIZE])
edit(os.path.join(BASE, "components", "ActivityChart.js"), [
    GUARD_SIZE,
    (
        "onLayout={(e) => setWidth(e.nativeEvent.layout.width)}",
        "onLayout={(e) => { const w = e.nativeEvent.layout.width; if (w > 0) setWidth(w); }}",
    ),
])
edit(os.path.join(BASE, "screens", "SettingsScreen.js"), [
    (
        """  const [cardMounted, setCardMounted] = useState(false);
  useEffect(() => {
    const task = InteractionManager.runAfterInteractions(() => setCardMounted(true));
    return () => task.cancel();
  }, []);""",
        """  const [cardMounted, setCardMounted] = useState(false);
  useEffect(() => {
    let alive = true;
    let t = null;
    const task = InteractionManager.runAfterInteractions(() => {
      // 700 ms de margen tras la animación: el montaje no se percibe al abrir
      t = setTimeout(() => { if (alive) setCardMounted(true); }, 700);
    });
    return () => { alive = false; if (t) clearTimeout(t); task.cancel(); };
  }, []);""",
    ),
])
