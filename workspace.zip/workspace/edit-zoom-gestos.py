#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Visor de imágenes estilo WhatsApp con gestos en el hilo de UI
(gesture-handler + reanimated) + miniaturas reales de 640 px (expo-image-
manipulator) + expo-image en burbujas y visor.

Cambios:
  screens/SocialScreen.js : imports, comentario cabecera, makeThumb,
                            publicar (sube thumbUrl), FotoBurbuja (expo-image
                            + miniatura), FocalViewer NUEVO (UI thread).
  babel.config.js         : plugin reanimated 4 -> react-native-worklets/plugin
  package.json            : fuera react-native-image-viewing (sin usar)
Preserva finales de línea (CRLF en .js de la app, LF en package.json).
"""
import os, sys

APP = os.path.join('proyecto', 'mi-app-entrenos')
SOCIAL = os.path.join(APP, 'screens', 'SocialScreen.js')
BABEL = os.path.join(APP, 'babel.config.js')
PKG = os.path.join(APP, 'package.json')

def crlf(s):
    return s.replace('\n', '\r\n')

def read(p):
    with open(p, 'r', encoding='utf-8', newline='') as f:
        return f.read()

def write(p, s):
    with open(p, 'w', encoding='utf-8', newline='') as f:
        f.write(s)

def rep(content, old, new, tag, to_crlf=True):
    o = crlf(old) if to_crlf else old
    n = crlf(new) if to_crlf else new
    cnt = content.count(o)
    if cnt != 1:
        raise SystemExit('FALLO [%s]: encontrado %d veces (esperaba 1)' % (tag, cnt))
    return content.replace(o, n)

src = read(SOCIAL)

# ── A. Comentario de cabecera ────────────────────────────────────────────
src = rep(src, """   · Imágenes: la burbuja muestra una MINIATURA (640 px) para que el chat no
     laguee; el original solo se carga en el visor a pantalla completa, que
     tiene ZOOM (pellizco + doble toque).""",
"""   · Imágenes (patrón WhatsApp real): al enviar se genera y sube también una
     MINIATURA de 640 px; la burbuja pinta la miniatura (expo-image, caché
     memoria+disco) y el visor a pantalla completa carga el ORIGINAL con
     gestos en el hilo de UI (gesture-handler + reanimated): pellizco anclado
     a los dedos, pan 1:1, doble toque 2.5x, swipe entre fotos y swipe abajo
     para cerrar.""", 'cabecera')

# ── B. Import RN: fuera Animated (solo lo usaba el visor viejo) ──────────
src = rep(src, """import {
  ActivityIndicator, Alert, Animated, Dimensions, Image, Keyboard, Linking,""",
"""import {
  ActivityIndicator, Alert, Dimensions, Image, Keyboard, Linking,""", 'import-rn')

# ── C. Nuevos imports ─────────────────────────────────────────────────────
src = rep(src, "import * as Sharing from 'expo-sharing';",
"""import * as Sharing from 'expo-sharing';
import * as ImageManipulator from 'expo-image-manipulator';
import { Image as ExpoImage } from 'expo-image';
import { Gesture, GestureDetector, GestureHandlerRootView } from 'react-native-gesture-handler';
import Reanimated, {
  clamp, interpolate, runOnJS, useAnimatedStyle, useSharedValue,
  withSpring, withTiming,
} from 'react-native-reanimated';""", 'imports-nuevos')

# ── D. makeThumb (antes de presign) ──────────────────────────────────────
src = rep(src, "async function presign(me, filename, contentType, size) {",
"""/* ── Miniatura 640 px estilo WhatsApp: la burbuja del chat pinta esta copia
      ligera; el original solo se descarga en el visor a pantalla completa.
      API nueva por contexto (SDK 52+) con fallback al método legacy. ── */
const THUMB_W = 640;
const THUMB_MIN_BYTES = 200 * 1024;   // por debajo de esto no compensa miniatura
async function makeThumb(uri) {
  const save = { compress: 0.72, format: ImageManipulator.SaveFormat.JPEG };
  if (typeof ImageManipulator.manipulate === 'function') {
    const ctx = ImageManipulator.manipulate(uri);
    ctx.resize({ width: THUMB_W });
    const ref = await ctx.renderAsync();
    const out = await ref.saveAsync(save);
    return out.uri;
  }
  const out = await ImageManipulator.manipulateAsync(uri, [{ resize: { width: THUMB_W } }], save);
  return out.uri;
}

async function presign(me, filename, contentType, size) {""", 'makethumb')

# ── E. publicar: generar y subir la miniatura (2 URLs por imagen) ────────
src = rep(src, """        mediaUp.push({ tipo: item.tipo, url: d.publicUrl, nombre: item.nombre, size: item.size });""",
"""        const entry = { tipo: item.tipo, url: d.publicUrl, nombre: item.nombre, size: item.size };
        // Miniatura estilo WhatsApp (dos URLs): la burbuja pintará thumbUrl y
        // el visor cargará el original. Si algo falla, seguimos sin miniatura
        // (la burbuja usa el original) y el envío NO se rompe.
        if (item.tipo === 'imagen' && (item.size || 0) > THUMB_MIN_BYTES) {
          try {
            const thumbUri = await makeThumb(item.uri);
            const tinfo = await FileSystem.getInfoAsync(thumbUri);
            const dt = await presign(me, `thumb-${item.nombre || 'foto'}.jpg`, 'image/jpeg', tinfo.size || 0);
            await FileSystem.uploadAsync(dt.uploadUrl, thumbUri, {
              httpMethod: 'PUT',
              headers: { 'Content-Type': 'image/jpeg' },
              mimeType: 'image/jpeg',
              uploadType: BIN_UPLOAD,
            });
            entry.thumbUrl = dt.publicUrl;
            entry.thumbSize = tinfo.size || 0;
          } catch (e) { /* sin miniatura: la burbuja usará el original */ }
        }
        mediaUp.push(entry);""", 'publicar-thumb')

# ── F. FotoBurbuja: miniatura + expo-image ───────────────────────────────
src = rep(src, """/* ── Imagen de burbuja: caché de disco + tap para el visor ── */
function FotoBurbuja({ m, c, isLight, onPress }) {
  const [cached, setCached] = useState(null);
  useEffect(() => {
    if (!m.url) return undefined;
    let alive = true;
    cachedOrDownload(m.url).then((u) => { if (alive) setCached(u); }).catch(() => { if (alive) setCached(m.url); });
    return () => { alive = false; };
  }, [m.url]);""",
"""/* ── Imagen de burbuja: pinta la MINIATURA 640 px (thumbUrl) con expo-image
      (decodificación y caché memoria+disco eficientes); el tap abre el visor
      con el ORIGINAL. Mensajes antiguos sin thumbUrl: se usa el original. ── */
function FotoBurbuja({ m, c, isLight, onPress }) {
  const [cached, setCached] = useState(null);
  const showUrl = m.thumbUrl || m.url;
  useEffect(() => {
    if (!showUrl) return undefined;
    let alive = true;
    cachedOrDownload(showUrl).then((u) => { if (alive) setCached(u); }).catch(() => { if (alive) setCached(showUrl); });
    return () => { alive = false; };
  }, [showUrl]);""", 'fotoburbuja-1')

src = rep(src, """  const uri = cached || m.url;
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.85}>
      <Image source={{ uri }} style={{ width: 220, height: 220, borderRadius: 10, marginTop: 5, backgroundColor: isLight ? '#00000010' : '#FFFFFF10' }} resizeMode="cover" />
    </TouchableOpacity>
  );
}""",
"""  const uri = cached || showUrl;
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.85}>
      <ExpoImage source={{ uri }} style={{ width: 220, height: 220, borderRadius: 10, marginTop: 5, backgroundColor: isLight ? '#00000010' : '#FFFFFF10' }} contentFit="cover" cachePolicy="memory-disk" transition={120} />
    </TouchableOpacity>
  );
}""", 'fotoburbuja-2')

# ── G. FocalViewer NUEVO: desde el marcador hasta el final del archivo ───
i = src.find('VISOR FOCAL estilo WhatsApp/Telegram')
if i < 0:
    raise SystemExit('FALLO [visor]: marcador no encontrado')
start = src.rfind('/*', 0, i)
if start < 0:
    raise SystemExit('FALLO [visor]: inicio de comentario no encontrado')

NEW_VIEWER = """/* ══════════════ VISOR FOCAL estilo WhatsApp/Telegram (HILO DE UI) ══════════════
   Gesture Handler + Reanimated: pellizco, pan y doble toque se calculan en el
   hilo de UI (worklets), así el zoom no da tirones aunque el hilo JS esté
   ocupado (listas del chat, red, etc.) — el "mecanismo de zoom perfecto" de
   WhatsApp.
   · Pellizco: fórmula exacta de anclaje focal t = f − (f₀ − t₀)·(s/s₀): el
     punto bajo los dedos se queda bajo los dedos y el traslado a dos dedos
     va 1:1. Límites 1x–5x.
   · Pan: 1:1 con tope en los bordes REALES de la imagen (se respeta el
     letterbox del contentFit="contain"; nada de arrastrar por la zona negra).
   · Sin zoom: swipe horizontal pasa de foto (la imagen sigue al dedo) y
     swipe hacia abajo cierra (el fondo se atenúa siguiendo al dedo).
   · Doble toque: zoom 2.5x anclado al punto tocado / el siguiente vuelve a
     1x con muelle.
   · expo-image: decodificación y caché memoria/disco eficientes; se
     precargan las fotos vecinas para que el swipe no muestre spinner.
   OJO: en Android el Modal crea una ventana nativa nueva, por eso el
   contenido va envuelto en su propio GestureHandlerRootView. */
const MINZ = 1;
const MAXZ = 5;
const AnimatedImage = Reanimated.createAnimatedComponent(ExpoImage);

function FocalViewer({ urls, initialIndex, onClose }) {
  const [idx, setIdx] = useState(initialIndex || 0);
  const [uri, setUri] = useState(null);

  /* Estado compartido: vive en el hilo de UI; los gestos lo leen/escriben
     sin pasar por JS (por eso el zoom es perfectamente fluido). */
  const scale = useSharedValue(1);
  const tx = useSharedValue(0);
  const ty = useSharedValue(0);
  const imgW = useSharedValue(0);      // tamaño natural de la imagen (onLoad)
  const imgH = useSharedValue(0);
  const boxW = useSharedValue(Dimensions.get('window').width);
  const boxH = useSharedValue(Dimensions.get('window').height);
  const p0s = useSharedValue(1);       // anclas del pellizco: scale/translate
  const p0x = useSharedValue(0);       // y foco en el momento de empezar
  const p0y = useSharedValue(0);
  const p0fx = useSharedValue(0);
  const p0fy = useSharedValue(0);
  const s0x = useSharedValue(0);       // anclas del pan
  const s0y = useSharedValue(0);

  useEffect(() => {
    let alive = true;
    const u = urls[idx];
    setUri(null);
    imgW.value = 0; imgH.value = 0;
    cachedOrDownload(u).then((l) => { if (alive) setUri(l); }).catch(() => { if (alive) setUri(u); });
    // Precarga las vecinas: el swipe lateral no muestra spinner
    if (urls[idx - 1]) cachedOrDownload(urls[idx - 1]).catch(() => {});
    if (urls[idx + 1]) cachedOrDownload(urls[idx + 1]).catch(() => {});
    return () => { alive = false; };
  }, [idx, urls]);

  const goIdx = (n) => {
    if (n < 0 || n >= urls.length || n === idx) return;
    scale.value = 1; tx.value = 0; ty.value = 0;
    setIdx(n);
  };

  /* Límites reales: con contentFit="contain" la imagen ocupa dw×dh dentro del
     contenedor (letterbox). El pan solo llega hasta el borde de lo que se ve. */
  const bounds = (s) => {
    'worklet';
    let dw = boxW.value;
    let dh = boxH.value;
    if (imgW.value > 0 && imgH.value > 0) {
      const fit = Math.min(boxW.value / imgW.value, boxH.value / imgH.value);
      dw = imgW.value * fit;
      dh = imgH.value * fit;
    }
    return {
      maxX: Math.max(0, (dw * s - boxW.value) / 2),
      maxY: Math.max(0, (dh * s - boxH.value) / 2),
    };
  };
  const snapToBounds = () => {
    'worklet';
    const b = bounds(scale.value);
    tx.value = withTiming(clamp(tx.value, -b.maxX, b.maxX), { duration: 160 });
    ty.value = withTiming(clamp(ty.value, -b.maxY, b.maxY), { duration: 160 });
  };
  const springHome = () => {
    'worklet';
    const cfg = { damping: 18, stiffness: 200 };
    tx.value = withSpring(0, cfg);
    ty.value = withSpring(0, cfg);
  };
  const resetZoom = () => {
    'worklet';
    const cfg = { damping: 17, stiffness: 170 };
    scale.value = withSpring(1, cfg);
    tx.value = withSpring(0, cfg);
    ty.value = withSpring(0, cfg);
  };

  /* ── Pellizco: zoom anclado al punto exacto de los dedos ── */
  const pinch = Gesture.Pinch()
    .onStart((e) => {
      p0s.value = scale.value;
      p0x.value = tx.value;
      p0y.value = ty.value;
      p0fx.value = e.focalX - boxW.value / 2;
      p0fy.value = e.focalY - boxH.value / 2;
    })
    .onUpdate((e) => {
      const s0 = p0s.value;
      if (s0 <= 0) return;
      const next = clamp(s0 * e.scale, MINZ, MAXZ);
      const ratio = next / s0;
      scale.value = next;
      // t = f − (f₀ − t₀)·ratio: el contenido que estaba bajo el foco inicial
      // sigue bajo el foco actual (zoom + traslado de dos dedos exactos).
      tx.value = (e.focalX - boxW.value / 2) - (p0fx.value - p0x.value) * ratio;
      ty.value = (e.focalY - boxH.value / 2) - (p0fy.value - p0y.value) * ratio;
    })
    .onEnd(() => {
      if (scale.value <= 1.02) resetZoom();
      else snapToBounds();
    });

  /* ── Arrastre: pan con zoom / paging y cierre sin zoom ── */
  const pan = Gesture.Pan()
    .maxPointers(1)          // a dos dedos manda el pellizco
    .minDistance(6)
    .onStart(() => {
      s0x.value = tx.value;
      s0y.value = ty.value;
    })
    .onUpdate((e) => {
      if (scale.value > 1.02) {
        const b = bounds(scale.value);
        tx.value = clamp(s0x.value + e.translationX, -b.maxX, b.maxX);
        ty.value = clamp(s0y.value + e.translationY, -b.maxY, b.maxY);
      } else {
        // Sin zoom: la foto sigue al dedo (goma si no hay más fotos o arriba)
        tx.value = urls.length > 1 ? e.translationX : e.translationX * 0.3;
        ty.value = e.translationY > 0 ? e.translationY : e.translationY * 0.3;
      }
    })
    .onEnd((e, success) => {
      if (!success) return;                 // cancelado por el pellizco
      if (scale.value > 1.02) { snapToBounds(); return; }
      const dx = e.translationX;
      const dy = e.translationY;
      if (dy > 110 || e.velocityY > 900) { runOnJS(onClose)(); return; }
      if (urls.length > 1 && Math.abs(dx) > Math.abs(dy)
          && (Math.abs(dx) > boxW.value * 0.28 || Math.abs(e.velocityX) > 650)) {
        runOnJS(goIdx)(idx + (dx < 0 ? 1 : -1));
        return;
      }
      springHome();
    });

  /* ── Doble toque: 2.5x en el punto tocado / vuelta a 1x ── */
  const doubleTap = Gesture.Tap()
    .numberOfTaps(2)
    .maxDuration(250)
    .maxDelay(250)
    .onEnd((e) => {
      if (scale.value > 1.02) { resetZoom(); return; }
      const s0 = Math.max(0.01, scale.value);
      const next = 2.5;
      const ratio = next / s0;
      const ex = e.x - boxW.value / 2;
      const ey = e.y - boxH.value / 2;
      const b = bounds(next);
      scale.value = withTiming(next, { duration: 220 });
      tx.value = withTiming(clamp(ex - (ex - tx.value) * ratio, -b.maxX, b.maxX), { duration: 220 });
      ty.value = withTiming(clamp(ey - (ey - ty.value) * ratio, -b.maxY, b.maxY), { duration: 220 });
    });

  const composed = Gesture.Simultaneous(pinch, pan, doubleTap);

  const imgStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: tx.value },
      { translateY: ty.value },
      { scale: scale.value },
    ],
  }));
  // El fondo se atenúa mientras arrastras hacia abajo para cerrar:
  const bgStyle = useAnimatedStyle(() => ({
    opacity: scale.value > 1.02
      ? 0.96
      : interpolate(ty.value, [0, 320], [0.96, 0.3], 'clamp'),
  }));

  // Descargar: panel del sistema (incluye "Guardar imagen").
  const handleDownload = async () => {
    try {
      const u = urls[idx];
      const local = diskCache.get(u) || (await cachedOrDownload(u));
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(local, { dialogTitle: 'Guardar imagen' });
      }
    } catch (e) {}
  };

  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose}>
      {/* Android: el Modal abre una ventana nativa aparte; los gestos
          necesitan su propio GestureHandlerRootView dentro. */}
      <GestureHandlerRootView style={{ flex: 1 }}>
        <View
          style={{ flex: 1 }}
          onLayout={(e) => {
            const { width, height } = e.nativeEvent.layout;
            if (width > 0 && height > 0) { boxW.value = width; boxH.value = height; }
          }}
        >
          <Reanimated.View style={[{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#000' }, bgStyle]} />
          {uri ? (
            <GestureDetector gesture={composed}>
              <AnimatedImage
                source={{ uri }}
                style={[{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }, imgStyle]}
                contentFit="contain"
                cachePolicy="memory-disk"
                onLoad={(e) => {
                  const w = (e && e.source && e.source.width) || 0;
                  const h = (e && e.source && e.source.height) || 0;
                  if (w > 0 && h > 0) { imgW.value = w; imgH.value = h; }
                }}
              />
            </GestureDetector>
          ) : (
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
              <ActivityIndicator color="#fff" />
            </View>
          )}
          {/* Barra superior: cerrar, descargar, contador */}
          <View pointerEvents="box-none" style={{ position: 'absolute', top: 44, left: 14, right: 14, zIndex: 2, flexDirection: 'row', alignItems: 'center' }}>
            <TouchableOpacity onPress={onClose} style={{ padding: 8 }}><Ionicons name="close-circle" size={30} color="#fff" /></TouchableOpacity>
            <View style={{ flex: 1 }} />
            <TouchableOpacity onPress={handleDownload} style={{ padding: 8, marginRight: 6 }}><Ionicons name="download-outline" size={26} color="#fff" /></TouchableOpacity>
            <Text style={{ color: '#ffffffcc', fontWeight: '700' }}>{idx + 1} / {urls.length}</Text>
          </View>
        </View>
      </GestureHandlerRootView>
      <SystemBars />
    </Modal>
  );
}
"""

src = src[:start] + crlf(NEW_VIEWER)
write(SOCIAL, src)
print('OK SocialScreen.js actualizado (%d bytes)' % len(src.encode('utf-8')))

# ── babel.config.js (CRLF): plugin de worklets para Reanimated 4 ─────────
b = read(BABEL)
b2 = rep(b, "'react-native-reanimated/plugin'", "'react-native-worklets/plugin'", 'babel-plugin')
write(BABEL, b2)
print('OK babel.config.js actualizado')

# ── package.json (LF): fuera librería de visor sin usar ──────────────────
p = read(PKG)
p2 = rep(p, """    "victory-native": "^41.20.2",
    "react-native-image-viewing": "^0.2.2"
""", """    "victory-native": "^41.20.2"
""", 'pkg-image-viewing', to_crlf=False)
write(PKG, p2)
print('OK package.json actualizado')

# ── Validación rápida de JSON y de finales de línea ──────────────────────
import json
json.loads(read(PKG))
print('OK package.json es JSON válido')
s = read(SOCIAL)
assert '\r\n' in s and 'useSharedValue' in s and 'Gesture.Simultaneous' in s
lines = s.split('\r\n')
print('OK SocialScreen.js: %d líneas CRLF' % len(lines))
print('TODO OK')
