# MANIFIESTO DE ENTREGA — qué archivo va dónde y cuál es su estado
> ⚠️ **DESACTUALIZADO (solo histórico)**: la estructura del servidor cambió
> después a **1 sola función** (`api/[...path].js` + `handlers/` + `vercel.json`).
> Lo vigente: `VERCEL-HOBBY-12-FUNCIONES.md` (incluida su sección RONDA 2,
> que arregla el error "presign HTTP 404 NOT_FOUND") y `SCROLL-WHATSAPP.md`
> (posición del scroll + botón ↓). ZIPs al día: `servidor-completo-para-vercel.zip`
> y `fix-scroll-fab-presign.zip`.

Generado el 2026-09-20. Dos bloques: SERVIDOR (Vercel) y APP (Expo).
Regla práctica: **sobrescribe TODO el conjunto** (es coherente entre sí);
las marcas NUEVO/MODIFICADO te dicen qué cambia respecto a lo que tienes hoy.

---

## A) SERVIDOR DE VERCEL — `mi-app-entrenos-server-CORREGIDO.zip` (20 archivos)
Sustituye en tu repo del servidor (rama que despliega Vercel) y haz push.
Respecto a lo que hay AHORA en producción (deployment dpl_H3XJ…), cambian 4:

| Archivo | Estado vs producción | Qué aporta |
|---|---|---|
| `api/social/presign.js` | **NUEVO** | Subidas de imágenes/archivos del Tablón a R2 (URLs presignadas) |
| `package.json` | **MODIFICADO** | Añade `@aws-sdk/client-s3` y `@aws-sdk/s3-request-presigner` |
| `lib/push.js` | **MODIFICADO** | `sendPushToUser` con `data` (lleva el `workoutId` del deep link) |
| `api/notify-athlete.js` | **MODIFICADO** | Push con textos por idioma del atleta + `workoutId` + log con sufijo |

Idénticos a producción (sobrescribir es inofensivo, mantienen todo coherente):
`.gitignore`, `api/intervals/disconnect.js`, `api/intervals/save-credentials.js`,
`api/intervals/status.js`, `api/sync-fitness.js`, `api/sync-intervals.js`,
`api/sync-intervals-detail.js`, `api/upload-to-intervals.js`, `lib/auth.js`,
`lib/firebase.js`, `lib/fitness.js`, `lib/intervals.js`, `lib/intervalsDetail.js`,
`lib/matcher.js`, `lib/uploadWorkouts.js`, `lib/wellness.js`.

Después del push: **Settings → Environment Variables** (pega
`VERCEL-ENV-VARIABLES.txt`) y asegúrate de que el deploy nuevo las recoge
(si el deploy ya existía, botón **Redeploy**).

---

## B) APP EXPO — `archivos-corregidos.zip` (30) o carpeta completa `mi-app-entrenos-PROYECTO-CORREGIDO.zip` (77)
Reconstruye APK / publica update después de copiar.

### NUEVOS (4) — no existen en tu proyecto actual
| Archivo | Qué es |
|---|---|
| `screens/SocialScreen.js` | Pestaña Social: Tablón (posts, imágenes/archivos R2, reacciones, encuestas) + Retos (ranking en vivo + historial) |
| `components/ShareProfileCard.js` | Tarjeta de compartir aislada (noche/día) que solo se carga al pulsar compartir |
| `services/coachNotify.js` | Envío de notificaciones con Bearer token y payload estructurado |
| `services/deepLink.js` | Puente del deep link (tocar push → abre el entreno) |

### MODIFICADOS (26)
| Archivo | Cambio principal |
|---|---|
| `App.js` | Pestaña Messages→**Social** (megáfono); ref de navegación + escucha de toques de push; sync de idioma al perfil |
| `screens/SettingsScreen.js` | Tarjeta fuera del render (carga bajo demanda) → Ajustes abre rápido |
| `screens/HomeScreen.js` | Consume el deep link y abre la ficha del entreno; trazas `[deeplink]` |
| `screens/WorkoutDetailModal.js` | Avisos movido/modificado/comentario bidireccionales con nombre; permisos: eventos bloqueados, resto acceso completo |
| `screens/CalendarScreen.js` | Aviso al mover con drag & drop; arrastre bloqueado solo en eventos ajenos |
| `screens/AddWorkoutModal.js` | Aviso de creado/evento con el día; `workoutId` en el payload |
| `screens/LoginScreen.js`, `screens/ProfileScreen.js`, `screens/CoachScreen.js`, `screens/ZonesScreen.js`, `screens/AnalysisScreen.js`, `screens/SyncSettingsScreen.js`, `screens/AppSettingsScreen.js` | Ajustes y fixes acumulados de chats anteriores (esfuerzo, zonas, permisos, i18n…) |
| `components/FitnessChart.js`, `components/ActivityChart.js` | Gráficas sin parpadeo al cambiar de pestaña (guardia de layout 0) |
| `components/WeeklyKmChart.js`, `components/EsfuerzoBadge.js`, `components/ActivityIcon.js`, `components/MonthPickerModal.js`, `components/StepEditor.js`, `components/SystemBars.js` | Fixes acumulados anteriores |
| `services/appSettings.js` | Guarda el idioma en el perfil (para push en el idioma del atleta) |
| `services/SyncService.js`, `services/analyticsEngine.js` | Fixes acumulados anteriores |
| `app.json` | Configuración acumulada (fuentes, iconos…) |
| `assets/fonts/Kalam-Bold.ttf` | Fuente manuscrita de la tarjeta y nombres |

### Sin tocar (van iguales en el ZIP de carpeta completa)
Resto de pantallas/servicios/assets/iconos nuevos (`icon.png`…), `google-services.json`, etc.

---

## C) Orden de despliegue recomendado
1. Vercel: variables de entorno (`VERCEL-ENV-VARIABLES.txt`) → subir server → deploy.
2. Firestore: reglas de `posts` y `retos` (en `SOCIAL-SETUP.md`) → Publish.
3. App: copiar los 30 (o la carpeta completa) → APK/update.
4. Probar: push con deep link, tablón con foto/PDF, encuesta, reto de 7 días.
