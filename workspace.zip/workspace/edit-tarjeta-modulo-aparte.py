#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Rendimiento ronda 3 (definitivo): la tarjeta de compartir se EXTRAE a
components/ShareProfileCard.js y SettingsScreen ya no la carga al entrar:
  · Se eliminan de SettingsScreen: constantes, paletas, generadores, memos,
    JSX del ViewShot, estilos share* e imports que solo usaba la tarjeta
    (ViewShot, react-native-svg, expo-font, InteractionManager, useEffect,
    useMemo).
  · handleShareProfile hace require('../components/ShareProfileCard') la
    PRIMERA vez que se pulsa compartir y monta el componente entonces;
    después espera el montaje y captura. Entrar/volver a Ajustes = coste 0.
"""
import os
import re

WS = os.environ.get("ARENA_WORKSPACE", os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(WS, "proyecto", "mi-app-entrenos", "screens", "SettingsScreen.js")

raw = open(P, "rb").read().decode("utf-8")
CRLF = "\r\n" in raw
s = raw.replace("\r\n", "\n") if CRLF else raw
n0 = len(s)

def rep(old, new, count=1):
    global s
    assert s.count(old) >= count, "NO ENCONTRADO: %r..." % old[:90]
    s = s.replace(old, new, count)

# ── 1) Imports: fuera lo que solo usaba la tarjeta ──
rep("""import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
""", """import { useCallback, useRef, useState } from 'react';
""")
rep("""import {
  Alert, Image, InteractionManager, Modal,
""", """import {
  Alert, Image, Modal,
""")
rep("""import ViewShot from 'react-native-view-shot';
import Svg, {
  Circle, Defs, Ellipse, G, LinearGradient, Path, RadialGradient, Rect, Stop,
} from 'react-native-svg';
import { useFonts } from 'expo-font';
""", """""")

# ── 2) Fuera el bloque de módulo (constantes + paletas + generadores) ──
m = re.search(r"/\* ── Tarjeta compartible:.*?\n\];\n", s, re.DOTALL)
assert m, "bloque de módulo de la tarjeta no encontrado"
s = s[:m.start()] + """/* ── La tarjeta compartible ("LA CIMA" / "EL AMANECER") vive ahora en un
   componente aislado: components/ShareProfileCard.js. NO se carga al entrar
   en Ajustes: se requiere (require) solo al pulsar el botón de compartir,
   y se monta en ese momento. Abrir y volver a Ajustes no paga sus diseños. ── */
""" + s[m.end():]

# ── 3) Dentro del componente: fuera useFonts, cardLight/P, nameSize, memos ──
rep("""  useFonts({ 'Kalam-Bold': require('../assets/fonts/Kalam-Bold.ttf') });
""", """""")
rep("""  // La tarjeta compartible sigue el modo de contraste de la app:
  // día (o dispositivo en claro) → "EL AMANECER"; si no → "LA CIMA" noche.
  const cardLight = appSettings.themeMode === 'day' || (appSettings.themeMode === 'device' && systemScheme === 'light');
  const P = PALETAS[cardLight ? 'dia' : 'noche'];
""", """""")
rep("""  // El nombre se escala solo si es largo para que nunca se salga del arte
  const nameSize = (s) => ((s || '').length > 13 ? 22 : (s || '').length > 10 ? 26 : (s || '').length > 8 ? 30 : 34);
""", """""")
m = re.search(r"  /\* ── Semilla del artwork:.*?\}, \[firstName, cardLight\]\);\n", s, re.DOTALL)
assert m, "memos seedPhase/cielo no encontrados"
s = s[:m.start()] + s[m.end():]

# ── 4) Fuera el montaje diferido (ya no hace falta: montaje bajo demanda) ──
rep("""
  // La tarjeta de compartir se monta DESPUÉS de que la pantalla termine de
  // abrirse: su artwork SVG y sus imágenes no frenan la entrada en Ajustes.
  const [cardMounted, setCardMounted] = useState(false);
  useEffect(() => {
    let alive = true;
    let t = null;
    const task = InteractionManager.runAfterInteractions(() => {
      // 700 ms de margen tras la animación: el montaje no se percibe al abrir
      t = setTimeout(() => { if (alive) setCardMounted(true); }, 700);
    });
    return () => { alive = false; if (t) clearTimeout(t); task.cancel(); };
  }, []);
""", """""")

# ── 5) handleShareProfile: require + montaje bajo demanda ──
rep("""  /* ── Compartir tarjeta de perfil ── */
  const handleShareProfile = async () => {
    try {
      if (!shareCardRef.current) {          // tap ultrarrápido: montar y dar un tick
        setCardMounted(true);
        await new Promise((r) => setTimeout(r, 150));
      }
      if (shareCardRef.current) {
        const uri = await shareCardRef.current.capture({
          format: 'png',
          quality: 1,
          pixelRatio: 3,   // 400×520 pt → PNG de 1200×1560 px, nítido al compartir
        });
        await Sharing.shareAsync(uri);
      }
    } catch (e) {
      Alert.alert(L('Error', 'Error'), L('No se pudo compartir la tarjeta', 'Could not share the card'));
    }
  };
""", """  /* ── Compartir tarjeta de perfil ──
     El componente de la tarjeta se carga (require) y se monta SOLO al pulsar
     este botón: entrar o volver a Ajustes no carga ningún diseño. Una vez
     montada, permanece lista para compartir de nuevo al instante. */
  const [ShareCardComp, setShareCardComp] = useState(null);
  const handleShareProfile = async () => {
    try {
      if (!shareCardRef.current) {
        const C = require('../components/ShareProfileCard').default;  // carga diferida
        setShareCardComp(() => C);
        // espera el montaje (máx ~1 s; en la práctica mucho menos)
        for (let i = 0; i < 20 && !shareCardRef.current; i++) {
          await new Promise((r) => setTimeout(r, 50));
        }
      }
      if (shareCardRef.current) {
        const uri = await shareCardRef.current.capture({
          format: 'png',
          quality: 1,
          pixelRatio: 3,   // 400×520 pt → PNG de 1200×1560 px, nítido al compartir
        });
        await Sharing.shareAsync(uri);
      }
    } catch (e) {
      Alert.alert(L('Error', 'Error'), L('No se pudo compartir la tarjeta', 'Could not share the card'));
    }
  };
""")

# ── 6) JSX: el ViewShot enorme → render condicional del componente ──
m = re.search(r"      \{cardMounted && \(\n      <ViewShot\n.*?      </ViewShot>\n      \)\}\n", s, re.DOTALL)
assert m, "bloque ViewShot no encontrado"
s = s[:m.start()] + """      {/* ── TARJETA COMPARTIBLE: se carga y monta solo al compartir ── */}
      {ShareCardComp && (
        <ShareCardComp
          ref={shareCardRef}
          photo={profilePhoto}
          photoURL={user?.photoURL}
          initial={initial}
          firstName={firstName}
          email={user?.email}
        />
      )}
""" + s[m.end():]

# ── 7) Estilos share*: fuera (viven en el componente) ──
m = re.search(r"  // ── Tarjeta para compartir:.*?shareEmailText: \{ color: '#AEC4B4', fontSize: 11\.5, letterSpacing: 0\.4 \},\n", s, re.DOTALL)
assert m, "bloque de estilos share* no encontrado"
s = s[:m.start()] + s[m.end():]

out = s.replace("\n", "\r\n") if CRLF else s
open(P, "wb").write(out.encode("utf-8"))
print("OK: SettingsScreen.js adelgazado (%d → %d bytes, CRLF=%s)" % (n0, len(s), CRLF))
for bad in ["ViewShot", "react-native-svg", "PALETAS", "cardMounted", "topoRing", "shareEmailPill"]:
    assert bad not in s, "quedan restos: " + bad
print("Sanity OK: sin restos de la tarjeta en SettingsScreen")
