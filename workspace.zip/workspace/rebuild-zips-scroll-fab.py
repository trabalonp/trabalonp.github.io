#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Genera fix-scroll-fab-presign.zip — paquete de la RONDA ACTUAL:

  APP   : SocialScreen.js con la política de scroll estilo WhatsApp (sin
          saltos al votar/seleccionar/volver de Retos) + FAB ↓ circular con
          insignia de no vistos. Se incluyen también los archivos acumulados
          de rondas anteriores para que el ZIP sea autocontenido.
  SERVER: api/[...path].js con requires literales (bundle trazable) y el
          NUEVO vercel.json que arregla el routing multissegmento (el error
          "presign HTTP 404 NOT_FOUND" al enviar imágenes).
  DOCS  : SCROLL-WHATSAPP.md (nuevo) y VERCEL-HOBBY-12-FUNCIONES.md (con la
          sección RONDA 2).
  TESTS : chat-scroll-test.js (nuevo, 58 aserciones) y dispatcher-test.js
          (ampliado, 43 aserciones).

Ejecutar DESPUÉS de rebuild-zips-extras.py y rebuild-zips-vercel-hobby.py.
"""
import hashlib, io, os, zipfile

APP = os.path.join('proyecto', 'mi-app-entrenos')
SRV = os.path.join('workspace-anterior', 'vercel-server', 'mi-app-entrenos-main')

def blob(*p):
    with open(os.path.join(*p), 'rb') as f:
        return f.read()

ENTRADAS = {
    # ── app (CRLF obligatorio) ──
    'APP/screens/SocialScreen.js':    (blob(APP, 'screens', 'SocialScreen.js'), 'crlf'),
    'APP/screens/ProfileScreen.js':   (blob(APP, 'screens', 'ProfileScreen.js'), 'crlf'),
    'APP/services/enlaces.js':        (blob(APP, 'services', 'enlaces.js'), 'crlf'),
    'APP/services/encuestas.js':      (blob(APP, 'services', 'encuestas.js'), 'crlf'),
    'APP/services/linkPreview.js':    (blob(APP, 'services', 'linkPreview.js'), 'crlf'),
    'APP/services/avatarCache.js':    (blob(APP, 'services', 'avatarCache.js'), 'crlf'),
    'APP/services/chatStore.js':      (blob(APP, 'services', 'chatStore.js'), 'crlf'),
    'APP/services/chatSync.js':       (blob(APP, 'services', 'chatSync.js'), 'crlf'),
    'APP/services/fechasChat.js':     (blob(APP, 'services', 'fechasChat.js'), 'crlf'),
    # ── servidor (LF obligatorio) ──
    'SERVER/api/[...path].js':        (blob(SRV, 'api', '[...path].js'), 'lf'),
    'SERVER/vercel.json':             (blob(SRV, 'vercel.json'), 'lf'),
    # ── docs y tests ──
    'SCROLL-WHATSAPP.md':             (blob('SCROLL-WHATSAPP.md'), None),
    'VERCEL-HOBBY-12-FUNCIONES.md':   (blob('VERCEL-HOBBY-12-FUNCIONES.md'), None),
    'tests/chat-scroll-test.js':      (blob('tests', 'chat-scroll-test.js'), None),
    'tests/dispatcher-test.js':       (blob('tests', 'dispatcher-test.js'), None),
}

# Verificaciones de convención antes de empaquetar
for nombre, (data, conv) in ENTRADAS.items():
    if conv == 'crlf':
        assert b'\r\n' in data and b'\n' not in data.replace(b'\r\n', b''), 'CRLF roto: ' + nombre
    elif conv == 'lf':
        assert b'\r\n' not in data, 'LF esperado: ' + nombre

Z = 'fix-scroll-fab-presign.zip'
with zipfile.ZipFile(Z, 'w', zipfile.ZIP_DEFLATED) as z:
    for nombre in sorted(ENTRADAS):
        z.writestr(nombre, ENTRADAS[nombre][0])

# Verificación final: sin duplicados, hashes idénticos al árbol
def sha(b):
    return hashlib.sha256(b).hexdigest()[:16]

with zipfile.ZipFile(Z) as z:
    nombres = z.namelist()
    assert len(nombres) == len(set(nombres)) == len(ENTRADAS), 'entradas inesperadas'
    assert not any('node_modules' in n for n in nombres)
    for nombre, (data, _) in ENTRADAS.items():
        assert sha(z.read(nombre)) == sha(data), 'hash distinto: ' + nombre
print('OK %-40s %2d entradas (hashes verificados)' % (Z, len(nombres)))
