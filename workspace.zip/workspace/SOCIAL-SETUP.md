# MONTAJE DE LA PESTAÑA SOCIAL — PASO A PASO COMPLETO
Tablón (texto + imágenes + archivos + reacciones + encuestas) y Retos (ranking en vivo + historial).
Almacenamiento de archivos: **Cloudflare R2** (gratis: 10 GB y descargas ilimitadas a 0 €).

---

## FASE 1 — Cloudflare R2 (≈5 minutos, todo gratis)
1. Entra en **dash.cloudflare.com** y crea cuenta (plan **Free**; pide tarjeta pero
   no cobra nada: el plan gratuito de R2 no consume saldo).
2. En el menú lateral: **R2 Object Storage** → si es tu primera vez, acepta las
   condiciones del servicio.
3. **Create bucket** → nombre: `team-jorge-social` → ubicación: **Automatic** → **Create**.
4. Haz clic en el bucket → pestaña **Settings**:
   - Baja hasta **Public Development URL** → **Enable** → escribe `allow` → **Allow**.
     Aparecerá tu URL pública tipo `https://pub-abcdef12345.r2.dev` → **CÓPIALA** (es `R2_PUBLIC_URL`).
     (Es la URL de desarrollo de r2.dev, válida para esto; si algún día quieres
     dominio propio, se añade en *Custom Domains* y solo cambias esa variable.)
5. Vuelve a la página **R2 Object Storage** (overview) → botón **Manage R2 API Tokens**
   → **Create API token**:
   - Permisos: **Object Read & Write**.
   - Apply to: **Only objects in a specific bucket** → `team-jorge-social`.
   - **Create API Token** → te muestra **Access Key ID** y **Secret Access Key**
     (el secret SOLO se ve una vez: cópialo ahora).
6. Tu **Account ID**: en la página de R2, columna derecha ("Account ID"), o en
   dash.cloudflare.com → cualquier página → sidebar derecho. Es un hexadecimal
   tipo `f0397f66...` → cópialo.

## FASE 2 — Variables en Vercel + deploy del servidor
1. Vercel → proyecto **mi-app-entrenos** → **Settings → Environment Variables**, crea:
   | Variable | Valor |
   |---|---|
   | `R2_ACCOUNT_ID` | tu Account ID |
   | `R2_ACCESS_KEY_ID` | Access Key ID del token |
   | `R2_SECRET_ACCESS_KEY` | Secret Access Key del token |
   | `R2_BUCKET` | `team-jorge-social` |
   | `R2_PUBLIC_URL` | `https://pub-abcdef12345.r2.dev` (tu URL pública) |
   (opcional `R2_ENDPOINT`/`R2_REGION` si migras a otro proveedor S3 en el futuro)
   → Apply a **Production** → Save.
2. Sube al repo del servidor (o carpeta que despliegues) estos ficheros:
   - **`api/social/presign.js`** (NUEVO)
   - **`package.json`** (MODIFICADO: añade `@aws-sdk/client-s3` y `@aws-sdk/s3-request-presigner`)
   El resto de ficheros del servidor no cambian para esta función.
3. Vercel detecta el push y despliega (instala las dependencias nuevas). Comprueba
   en el deployment que no haya error de build.

## FASE 3 — Reglas de Firestore (Firebase Console → Firestore → Rules)
Pega esto DENTRO de tu bloque `service cloud.firestore { match /databases/{database}/documents { ... } }`,
junto a las reglas que ya tienes:
```
match /posts/{postId} {
  allow read: if request.auth != null;
  allow create: if request.auth != null && request.resource.data.autorUid == request.auth.uid;
  allow update, delete: if request.auth != null;
}
match /retos/{retoId} {
  allow read: if request.auth != null;
  allow create: if request.auth != null && request.resource.data.creadorUid == request.auth.uid;
  allow update, delete: if request.auth != null && request.auth.uid == resource.data.creadorUid;
}
```
→ **Publish**.

## FASE 4 — App
1. Copia en tu proyecto:
   - **`screens/SocialScreen.js`** (NUEVO)
   - **`App.js`** (MODIFICADO: la pestaña "Messages" pasa a ser "Social" con icono de megáfono)
   (No hay que instalar nada: `expo-image-picker` y `expo-document-picker` ya están en tu package.json.)
2. Reconstruye el APK / publica el update con tu flujo habitual.

## FASE 5 — Prueba de extremo a extremo
1. Con un atleta: pestaña **Social → Tablón** → publica un texto con una foto y un
   archivo PDF → debe verse en el feed al momento (la foto carga desde tu URL r2.dev).
2. Reacciona con 🔥 y crea una encuesta de 2 opciones; con el otro usuario vota →
   porcentajes actualizados.
3. Con el coach: **Social → Retos → Crear reto** (km, 7 días) → con el atleta
   sincroniza un entreno → el ranking del reto suma sus km; al pasar los días,
   el reto pasa a **Historial** con su ganador.

## SOLUCIÓN DE PROBLEMAS
| Síntoma | Causa / arreglo |
|---|---|
| Publicar falla con "Almacenamiento R2 no configurado" (503) | Falta alguna variable en Vercel o no redeployaste después de añadirlas |
| La foto no se ve en el feed (cuadro roto) | No activaste **Public Development URL** o `R2_PUBLIC_URL` está mal copiado |
| Subida da 403 | Access Key/Secret mal copiados, o el token no tiene permiso sobre ese bucket |
| Archivo > 25 MB | Límite puesto a propósito en `presign.js` (cambiable en `MAX_BYTES`) |
| No veo el botón "Crear reto" | Tu usuario no tiene atletas (no eres coach en Firestore) |
