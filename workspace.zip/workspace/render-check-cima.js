/* Render de verificación: tarjetas NOCHE y DÍA en SVG puro → PNG (2×2).
   Replica el artwork y la maquetación de SettingsScreen.js (paletas duales).
   Uso: NODE_PATH=/tmp/render/node_modules node render-check-cima.js [salida.png] */
const fs = require('fs');
const path = require('path');
const { Resvg } = require('@resvg/resvg-js');

const CARD_W = 400, CARD_H = 520;
const GREEN = '#7BC86C', GREEN_DK = '#2F6B3A', GREEN_LT = '#8FE08A', INK = '#0C1310', CREAM = '#EAF7E6';

const PALETAS = {
  noche: {
    cardBg: INK,
    sky: ['#0C1B13', INK, '#050806'],
    glow: ['#5FCE73', 0.26, '#3E9B52', 0.10],
    blobB: ['#3E9B52', 0.15],
    blobC: ['#A7E89B', 0.07],
    topo: GREEN,
    topoOp: [0.38, 0.28, 0.20, 0.14, 0.09],
    ridgeFill: [['#081109', 0.5], ['#060C08', 0.65]],
    ridgeStroke: GREEN,
    ridgeBoost: 1,
    ruta: [GREEN_DK, GREEN, CREAM],
    rutaDot: CREAM,
    rutaDotOp: 0.35,
    waypointFill: INK,
    waypointStroke: GREEN,
    pulse: CREAM,
    huella: GREEN,
    bandera: GREEN_LT,
    decor: GREEN,
    dotOp: 0.15,
    cornerOp: 0.7,
    vignette: ['#000000', 0.46],
    astro: CREAM,
    ave: '#8A6A52',
    name: '#F4F8F2',
    underline: GREEN,
    underline2: 'rgba(123,200,108,0.44)',
    dashed: 'rgba(123,200,108,0.35)',
    ringOut: GREEN_LT,
    ringOutBorder: GREEN_DK,
    ringIn: INK,
    fallback: GREEN_DK,
    email: '#AEC4B4',
    emailIcon: '#8FAF97',
    pillBg: 'rgba(255,255,255,0.05)',
    pillBorder: 'rgba(255,255,255,0.12)',
    brandText: '#F4F8F2',
    brandUnder: GREEN,
  },
  dia: {
    cardBg: '#FFF8EC',
    sky: ['#FFFDF6', '#FDEED4', '#F8DCB4'],
    glow: ['#F6A821', 0.32, '#E8890C', 0.12],
    blobB: ['#E4572E', 0.10],
    blobC: ['#FFC94D', 0.16],
    topo: '#C05F35',
    topoOp: [0.46, 0.34, 0.25, 0.17, 0.11],
    ridgeFill: [['#E3B98D', 0.55], ['#D19E6C', 0.62]],
    ridgeStroke: '#A9552D',
    ridgeBoost: 1.6,
    ruta: ['#0E6E64', '#128C7E', '#E4572E'],
    rutaDot: '#5B3A26',
    rutaDotOp: 0.30,
    waypointFill: '#FFF8EC',
    waypointStroke: '#0E6E64',
    pulse: '#E4572E',
    huella: '#B0714E',
    bandera: '#E4572E',
    decor: '#C05F35',
    dotOp: 0.20,
    cornerOp: 0.65,
    vignette: ['#7A4A28', 0.14],
    astro: '#E8A33D',
    ave: '#8A6A52',
    name: '#4A2E1C',
    underline: '#E4572E',
    underline2: 'rgba(228,87,46,0.40)',
    dashed: 'rgba(192,95,53,0.35)',
    ringOut: '#F5B942',
    ringOutBorder: '#B0714E',
    ringIn: '#FFF8EC',
    fallback: '#E8A33D',
    email: '#8A5E42',
    emailIcon: '#C05F35',
    pillBg: 'rgba(255,255,255,0.65)',
    pillBorder: 'rgba(192,95,53,0.25)',
    brandText: '#4A2E1C',
    brandUnder: '#E4572E',
  },
};

const hashStr = (s) => { let h = 2166136261; for (let i = 0; i < (s || '').length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const mulberry32 = (a) => () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const spline = (pts, close) => {
  const n = pts.length;
  const at = (i) => pts[close ? (i + n) % n : Math.min(Math.max(i, 0), n - 1)];
  let d = `M${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`;
  for (let i = 0; i < (close ? n : n - 1); i++) {
    const p0 = at(i - 1), p1 = at(i), p2 = at(i + 1), p3 = at(i + 2);
    const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C${c1x.toFixed(1)} ${c1y.toFixed(1)},${c2x.toFixed(1)} ${c2y.toFixed(1)},${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`;
  }
  return close ? d + ' Z' : d;
};
const topoRing = (cx, cy, r, ph, wob = 0.13) => {
  const pts = [];
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    const k = 1 + wob * (Math.sin(a * 2 + ph) * 0.6 + Math.sin(a * 3 - ph * 1.7) * 0.4);
    pts.push([cx + Math.cos(a) * r * k, cy + Math.sin(a) * r * k * 0.86]);
  }
  return spline(pts, true);
};
const TOPO_RADII = [96, 124, 154, 186, 222];
const ridgePath = (y0, amp, ph, close) => {
  const pts = [];
  for (let x = -20; x <= CARD_W + 20; x += 24) pts.push([x, y0 + Math.sin(x * 0.016 + ph) * amp + Math.sin(x * 0.043 + ph * 1.7) * amp * 0.4]);
  const d = spline(pts, false);
  return close ? `${d} L${CARD_W + 20} ${CARD_H + 20} L-20 ${CARD_H + 20} Z` : d;
};
const RIDGES = [
  { y: 372, amp: 10, o: 0.22, w: 1.4 },
  { y: 402, amp: 12, o: 0.18, w: 1.2 },
  { y: 432, amp: 15, o: 0.14, w: 1.1 },
  { y: 466, amp: 18, o: 0.11, w: 1.0 },
];
const RUTA_GPS = 'M-10 468 C 50 460 92 414 152 420 C 212 426 210 458 262 448 C 314 438 348 372 412 356';
const TRAIL = { ax: 40, ay: 503, bx: 172, by: 393 };
const HUELLAS = [
  { t: 0.00, side: -1, o: 0.50, s: 1.00 },
  { t: 0.22, side: +1, o: 0.40, s: 0.94 },
  { t: 0.44, side: -1, o: 0.31, s: 0.88 },
  { t: 0.66, side: +1, o: 0.23, s: 0.82 },
  { t: 0.88, side: -1, o: 0.15, s: 0.76 },
];
const nameSize = (s) => ((s || '').length > 13 ? 22 : (s || '').length > 10 ? 26 : (s || '').length > 8 ? 30 : 34);

function cieloDe(firstName, light) {
  const rnd = mulberry32(hashStr(firstName + '|cielo'));
  const out = [];
  if (!light) {
    while (out.length < 18) {
      const x = 14 + rnd() * (CARD_W - 28);
      const y = 14 + rnd() * 246;
      if (Math.hypot(x - CARD_W / 2, y - 158) < 112) continue;
      out.push({ x, y, r: 0.7 + rnd() * 1.1, o: 0.10 + rnd() * 0.38 });
    }
    return out;
  }
  while (out.length < 5) {
    const x = 30 + rnd() * (CARD_W - 60);
    const y = 20 + rnd() * 205;
    if (Math.hypot(x - CARD_W / 2, y - 158) < 120) continue;
    out.push({ x, y, s: 0.7 + rnd() * 0.8, rot: -9 + rnd() * 18, o: 0.30 + rnd() * 0.35 });
  }
  return out;
}

function cardSVG(firstName, email, photoDataUri, uid, light) {
  const P = PALETAS[light ? 'dia' : 'noche'];
  const seedPhase = (hashStr(firstName) % 628) / 100;
  const cielo = cieloDe(firstName, light);
  const fsz = nameSize(firstName);
  const initial = firstName.charAt(0).toUpperCase();
  let s = `<svg width="${CARD_W}" height="${CARD_H}" viewBox="0 0 ${CARD_W} ${CARD_H}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<defs>
  <linearGradient id="tjBg${uid}" x1="0" y1="0" x2="0.35" y2="1"><stop offset="0" stop-color="${P.sky[0]}"/><stop offset="0.55" stop-color="${P.sky[1]}"/><stop offset="1" stop-color="${P.sky[2]}"/></linearGradient>
  <radialGradient id="tjGlow${uid}" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stop-color="${P.glow[0]}" stop-opacity="${P.glow[1]}"/><stop offset="0.55" stop-color="${P.glow[2]}" stop-opacity="${P.glow[3]}"/><stop offset="1" stop-color="${P.glow[2]}" stop-opacity="0"/></radialGradient>
  <radialGradient id="tjAuroraB${uid}" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stop-color="${P.blobB[0]}" stop-opacity="${P.blobB[1]}"/><stop offset="1" stop-color="${P.blobB[0]}" stop-opacity="0"/></radialGradient>
  <radialGradient id="tjAuroraC${uid}" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stop-color="${P.blobC[0]}" stop-opacity="${P.blobC[1]}"/><stop offset="1" stop-color="${P.blobC[0]}" stop-opacity="0"/></radialGradient>
  <linearGradient id="tjRuta${uid}" gradientUnits="userSpaceOnUse" x1="0" y1="500" x2="${CARD_W}" y2="350"><stop offset="0" stop-color="${P.ruta[0]}"/><stop offset="0.5" stop-color="${P.ruta[1]}"/><stop offset="1" stop-color="${P.ruta[2]}"/></linearGradient>
  <radialGradient id="tjVig${uid}" cx="0.5" cy="0.45" r="0.78"><stop offset="0.55" stop-color="${P.vignette[0]}" stop-opacity="0"/><stop offset="1" stop-color="${P.vignette[0]}" stop-opacity="${P.vignette[1]}"/></radialGradient>
  <clipPath id="clipPhoto${uid}"><circle cx="200" cy="152" r="65"/></clipPath>
  <clipPath id="clipLogo${uid}"><rect x="26" y="24" width="40" height="40" rx="10"/></clipPath>
</defs>
<rect width="${CARD_W}" height="${CARD_H}" fill="url(#tjBg${uid})"/>
<circle cx="200" cy="158" r="205" fill="url(#tjGlow${uid})"/>
<circle cx="54" cy="474" r="170" fill="url(#tjAuroraB${uid})"/>
<circle cx="368" cy="492" r="150" fill="url(#tjAuroraC${uid})"/>`;
  if (light) {
    for (const b of cielo) s += `\n<g transform="translate(${b.x.toFixed(1)} ${b.y.toFixed(1)}) rotate(${b.rot.toFixed(1)}) scale(${b.s.toFixed(2)})" opacity="${b.o.toFixed(2)}"><path d="M-7 0 Q-3.5 -4.6 0 -0.6 Q3.5 -4.6 7 0" fill="none" stroke="${P.ave}" stroke-width="1.3" stroke-linecap="round"/></g>`;
  } else {
    for (const st of cielo) s += `\n<circle cx="${st.x.toFixed(1)}" cy="${st.y.toFixed(1)}" r="${st.r.toFixed(1)}" fill="${P.astro}" fill-opacity="${st.o.toFixed(2)}"/>`;
  }
  TOPO_RADII.forEach((r, i) => {
    s += `\n<path d="${topoRing(200, 158, r, seedPhase + i * 0.8)}" fill="none" stroke="${P.topo}" stroke-width="${i === 0 ? 1.6 : 1.1}" stroke-opacity="${P.topoOp[i]}"${i === TOPO_RADII.length - 1 ? ' stroke-dasharray="3 7"' : ''}/>`;
  });
  s += `\n<path d="${ridgePath(432, 15, seedPhase * 1.3 + 2.1, true)}" fill="${P.ridgeFill[0][0]}" fill-opacity="${P.ridgeFill[0][1]}"/>`;
  s += `\n<path d="${ridgePath(466, 18, seedPhase * 0.8 + 4.4, true)}" fill="${P.ridgeFill[1][0]}" fill-opacity="${P.ridgeFill[1][1]}"/>`;
  RIDGES.forEach((rg, i) => {
    s += `\n<path d="${ridgePath(rg.y, rg.amp, seedPhase * (1 + i * 0.25) + i * 2.1, false)}" fill="none" stroke="${P.ridgeStroke}" stroke-width="${rg.w}" stroke-opacity="${Math.min(0.45, rg.o * P.ridgeBoost).toFixed(2)}"/>`;
  });
  s += `\n<path d="${RUTA_GPS}" fill="none" stroke="url(#tjRuta${uid})" stroke-width="8" stroke-opacity="0.10" stroke-linecap="round"/>`;
  s += `\n<path d="${RUTA_GPS}" fill="none" stroke="url(#tjRuta${uid})" stroke-width="4.5" stroke-opacity="0.22" stroke-linecap="round"/>`;
  s += `\n<path d="${RUTA_GPS}" fill="none" stroke="url(#tjRuta${uid})" stroke-width="2" stroke-linecap="round"/>`;
  s += `\n<path d="${RUTA_GPS}" fill="none" stroke="${P.rutaDot}" stroke-width="1.2" stroke-opacity="${P.rutaDotOp}" stroke-dasharray="1 11" stroke-linecap="round"/>`;
  s += `\n<circle cx="152" cy="420" r="3" fill="${P.waypointFill}" stroke="${P.waypointStroke}" stroke-width="1.4" stroke-opacity="0.85"/>`;
  s += `\n<circle cx="262" cy="448" r="3" fill="${P.waypointFill}" stroke="${P.waypointStroke}" stroke-width="1.4" stroke-opacity="0.85"/>`;
  s += `\n<circle cx="396" cy="360" r="9" fill="none" stroke="${P.pulse}" stroke-width="1" stroke-opacity="0.35"/>`;
  s += `\n<circle cx="396" cy="360" r="3.4" fill="${P.pulse}"/>`;
  for (const h of HUELLAS) {
    const x = TRAIL.ax + (TRAIL.bx - TRAIL.ax) * h.t + h.side * 5.6;
    const y = TRAIL.ay + (TRAIL.by - TRAIL.ay) * h.t + h.side * 7;
    const rot = 47 + (h.side > 0 ? 5 : -4);
    s += `\n<g transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${rot}) scale(${h.s})" opacity="${h.o}"><ellipse cx="0" cy="0" rx="4.4" ry="7.2" fill="${P.huella}" transform="rotate(-7)"/><ellipse cx="0.8" cy="10.6" rx="3.3" ry="4.3" fill="${P.huella}" transform="rotate(-4 0.8 10.6)"/></g>`;
  }
  s += `\n<path d="M266 96 L266 66" stroke="${P.bandera}" stroke-width="2" stroke-linecap="round" stroke-opacity="0.9"/>`;
  s += `\n<path d="M267.5 67 L286 73.5 L267.5 80 Z" fill="${P.bandera}" fill-opacity="0.92"/>`;
  s += `\n<circle cx="266" cy="97.5" r="2" fill="${P.bandera}"/>`;
  for (let row = 0; row < 4; row++) for (let col = 0; col < 5; col++) s += `\n<circle cx="${CARD_W - 88 + col * 13}" cy="${30 + row * 13}" r="1.4" fill="${P.decor}" fill-opacity="${P.dotOp}"/>`;
  s += `\n<path d="M16 46 L16 16 L46 16" fill="none" stroke="${P.decor}" stroke-width="2.5" stroke-opacity="${P.cornerOp}"/>`;
  s += `\n<path d="M384 474 L384 504 L354 504" fill="none" stroke="${P.decor}" stroke-width="2.5" stroke-opacity="${P.cornerOp}"/>`;
  s += `\n<rect width="${CARD_W}" height="${CARD_H}" fill="url(#tjVig${uid})"/>`;
  /* ── Sello de marca: logo circular + nombre de la app (arriba izq.) ── */
  s += `\n<image xlink:href="${ICON}" x="26" y="24" width="40" height="40" clip-path="url(#clipLogo${uid})" preserveAspectRatio="xMidYMid slice"/>`;
  s += `\n<text x="78" y="47" font-family="Kalam" font-weight="700" font-size="19" letter-spacing="2" fill="${P.brandText}">TEAM JORGE</text>`;
  s += `\n<rect x="78" y="54" width="64" height="3" rx="1.5" fill="${P.brandUnder}"/>`;
  /* ── Foto (la cumbre) ── */
  s += `\n<circle cx="200" cy="152" r="86" fill="none" stroke="${P.dashed}" stroke-width="1.5" stroke-dasharray="5 5"/>`;
  s += `\n<circle cx="200" cy="152" r="74" fill="${P.ringOut}" stroke="${P.ringOutBorder}" stroke-width="1"/>`;
  s += `\n<circle cx="200" cy="152" r="70" fill="${P.ringIn}"/>`;
  if (photoDataUri) {
    s += `\n<image xlink:href="${photoDataUri}" x="135" y="87" width="130" height="130" clip-path="url(#clipPhoto${uid})" preserveAspectRatio="xMidYMid slice"/>`;
  } else {
    s += `\n<circle cx="200" cy="152" r="65" fill="${P.fallback}"/>`;
    s += `\n<text x="200" y="171" text-anchor="middle" font-family="Kalam" font-size="54" font-weight="700" fill="#fff">${initial}</text>`;
  }
  /* ── Nombre + subrayados ── */
  const nameTop = 66 + 172 + 26;               // 264
  const nameBaseline = nameTop + fsz * 0.84;
  s += `\n<text x="200" y="${nameBaseline.toFixed(1)}" text-anchor="middle" font-family="Kalam" font-weight="700" font-size="${fsz}" letter-spacing="4" fill="${P.name}">${firstName.toUpperCase()}</text>`;
  const u1 = nameTop + fsz * 1.2 + 13;         // ~318
  s += `\n<rect x="134" y="${u1.toFixed(1)}" width="132" height="3.5" rx="1.75" fill="${P.underline}" transform="rotate(-1.2 200 ${(u1 + 1.75).toFixed(1)})"/>`;
  s += `\n<rect x="163" y="${(u1 + 7.5).toFixed(1)}" width="74" height="2.5" rx="1.25" fill="${P.underline2}" transform="rotate(-1.2 200 ${(u1 + 8.75).toFixed(1)})"/>`;
  /* ── Píldora del correo ── */
  const pillW = 28 + 12 + 7 + email.length * 6.15;
  const pillX = 200 - pillW / 2, pillY = CARD_H - 26 - 30;
  s += `\n<rect x="${pillX.toFixed(1)}" y="${pillY}" width="${pillW.toFixed(1)}" height="30" rx="15" fill="${P.pillBg}" stroke="${P.pillBorder}" stroke-width="1"/>`;
  const iconX = pillX + 14, iconY = pillY + 9;
  s += `\n<g transform="translate(${iconX.toFixed(1)} ${iconY}) scale(0.5)" fill="none" stroke="${P.emailIcon}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="3"/><path d="m2 7 10 6L22 7"/></g>`;
  s += `\n<text x="${(iconX + 19).toFixed(1)}" y="${pillY + 19}" font-family="Inter" font-size="11.5" letter-spacing="0.4" fill="${P.email}">${email}</text>`;
  s += `\n</svg>`;
  return s;
}

const WS = process.env.ARENA_WORKSPACE || '/home/user';
const avatar = 'data:image/jpeg;base64,' + fs.readFileSync(path.join(WS, 'uploads/avatar-b64.txt'), 'utf8').trim();
const ICON = 'data:image/png;base64,' + fs.readFileSync(path.join(WS, 'uploads/icon-b64.txt'), 'utf8').trim();

const inner = (svg) => svg.replace(/^<svg[^>]*>/, '').replace(/<\/svg>$/, '');
const cards = [
  { svg: cardSVG('Jorge', 'jorge@ejemplo.com', avatar, '1', false), x: 30, y: 64, label: 'Jorge · NOCHE “LA CIMA”', color: '#9BE08F' },
  { svg: cardSVG('Jorge', 'jorge@ejemplo.com', avatar, '2', true), x: 470, y: 64, label: 'Jorge · DÍA “EL AMANECER”', color: '#F0B26B' },
  { svg: cardSVG('Alejandra', 'alejandra@ejemplo.com', null, '3', false), x: 30, y: 640, label: 'Alejandra (inicial) · NOCHE', color: '#9BE08F' },
  { svg: cardSVG('Alejandra', 'alejandra@ejemplo.com', null, '4', true), x: 470, y: 640, label: 'Alejandra (inicial) · DÍA', color: '#F0B26B' },
];

const W = 900, H = 1210;
let combined = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<rect width="${W}" height="${H}" fill="#0B0F0D"/>
<text x="${W / 2}" y="38" text-anchor="middle" font-family="Inter" font-size="19" font-weight="700" fill="#F4F8F2">Tarjeta compartible · sigue el modo de contraste de la app</text>`;
for (const c of cards) {
  combined += `\n<g transform="translate(${c.x} ${c.y})">${inner(c.svg)}</g>`;
  combined += `\n<text x="${c.x + 200}" y="${c.y - 14}" text-anchor="middle" font-family="Inter" font-size="14" fill="${c.color}">${c.label}</text>`;
}
combined += `\n</svg>`;

const opts = {
  background: '#0B0F0D',
  fitTo: { mode: 'width', value: 1350 },
  font: {
    fontDirs: ['/tmp/render/node_modules/@fontsource/inter/files', path.join(WS, 'proyecto/mi-app-entrenos/assets/fonts')],
    defaultFontFamily: 'Inter',
    serifFamily: 'Inter',
    sansSerifFamily: 'Inter',
  },
};
const out = process.argv[2] || '/tmp/render/tarjeta-contraste-check.png';
const png = new Resvg(combined, opts).render().asPng();
fs.writeFileSync(out, png);
console.log('PNG escrito:', out, png.length, 'bytes');
