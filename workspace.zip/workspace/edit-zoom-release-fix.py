#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fix "la imagen salta al soltar un dedo y luego vuelve" en FocalViewer.

Causa (RNGH 2.32 Android, verificado en el fuente nativo):
- ScaleGestureDetector recalcula el foco excluyendo el dedo levantado
  (ACTION_POINTER_UP) y llama a onScaleEnd... que PinchGestureHandler IGNORA.
- El pellizco sigue ACTIVE hasta el ultimo ACTION_UP y el orquestador sigue
  despachando onUpdate con el foco TELETRANSPORTADO al dedo restante: la foto
  salta y ademas la arrastra ese dedo; al soltar del todo, snapToBounds la
  devuelve => "se mueve como queriendo ir a otro punto y luego vuelve".

Solucion (comportamiento WhatsApp):
1) onTouchesUp: en cuanto queda 1 touch, enmudecer el pellizco (los eventos
   de touches se despachan ANTES que los updates; lo garantiza el
   GestureHandlerOrchestrator). El gesto termina logicamente ahi.
2) Red de seguridad: si el foco se teletransporta >60px en un frame, enmudecer.
3) Clamp del traslado a los bordes reales DURANTE el gesto: al soltar ya no
   hay nada que rebotar (WhatsApp topa en el borde, no hace goma al soltar).
4) onTouchesDown: si se apoya un dedo nuevo quedando otro en pantalla,
   reanclar el pellizco al estado actual (p0e normaliza el e.scale acumulado).
5) onBegin: des-enmudecer en cada interaccion nueva.
"""
import io, sys

PATH = 'proyecto/mi-app-entrenos/screens/SocialScreen.js'

with io.open(PATH, 'r', encoding='utf-8', newline='') as f:
    src = f.read()

lines = src.split('\r\n')
assert len(lines) > 100, 'fichero inesperadamente corto o sin CRLF'

def find(pred, start=0, end=None):
    end = len(lines) if end is None else end
    for i in range(start, end):
        if pred(lines[i]):
            return i
    raise SystemExit('no encontrado desde %d: %s' % (start, pred))

# ── 1) Nuevos shared values tras p0fy ────────────────────────────────────────
i_p0fy = find(lambda l: l.strip() == 'const p0fy = useSharedValue(0);')
new_vals = [
    '  const p0e = useSharedValue(1);       // e.scale acumulado en el anclaje',
    '  const pfx = useSharedValue(0);       // foco del frame anterior (anti-salto)',
    '  const pfy = useSharedValue(0);',
    '  const lastE = useSharedValue(1);     // ultimo e.scale visto',
    '  const pinchMuted = useSharedValue(false); // pellizco enmudecido al soltar 1 dedo',
]
lines[i_p0fy + 1:i_p0fy + 1] = new_vals

# ── 2) Sustituir el bloque del pellizco completo ─────────────────────────────
i_pinch = find(lambda l: l.strip() == 'const pinch = Gesture.Pinch()')
i_comment = i_pinch - 1  # /* ── Pellizco: ... ── */
assert 'Pellizco' in lines[i_comment], lines[i_comment]
i_end = find(lambda l: l == '    });', i_pinch)          # cierre del .onEnd
assert any('onEnd' in lines[j] for j in range(i_pinch, i_end)), 'bloque pinch raro'

pinch_new = '''  /* ── Pellizco: zoom anclado al punto exacto de los dedos ──
     FIX "salto al soltar" (comportamiento WhatsApp): en Android RNGH NO
     termina el pellizco al levantar UN dedo — el handler ignora onScaleEnd y
     sigue ACTIVE despachando onUpdate con el FOCO TELETRANSPORTADO al dedo
     que queda (su ScaleGestureDetector recalcula el foco excluyendo el dedo
     levantado). La foto saltaba a otro punto, la arrastraba el dedo restante
     y al soltar del todo el snap la devolvía ("va y vuelve"). Los eventos de
     touches se despachan ANTES que los updates (garantizado por el
     GestureHandlerOrchestrator): en cuanto queda 1 touch enmudecemos el
     gesto — termina ahí, como en WhatsApp. Además el traslado va topado a
     los bordes reales DURANTE el gesto: al soltar no rebota nada. */
  const pinch = Gesture.Pinch()
    .onBegin(() => {
      pinchMuted.value = false;   // interaccion nueva: oidos abiertos
    })
    .onTouchesDown((e) => {
      // Si apoyas un dedo nuevo quedando otro en pantalla (pellizco ya
      // enmudecido), reanclamos el gesto al estado actual en vez de exigir
      // levantar todos los dedos primero.
      if (!pinchMuted.value || e.numberOfTouches < 2) return;
      const ts = e.allTouches;
      if (!ts || ts.length < 2) return;
      let sx = 0;
      let sy = 0;
      for (let i = 0; i < ts.length; i++) { sx += ts[i].x; sy += ts[i].y; }
      p0s.value = Math.max(0.01, scale.value);
      p0x.value = tx.value;
      p0y.value = ty.value;
      p0e.value = lastE.value > 0 ? lastE.value : 1;
      p0fx.value = sx / ts.length - boxW.value / 2;
      p0fy.value = sy / ts.length - boxH.value / 2;
      pfx.value = p0fx.value;
      pfy.value = p0fy.value;
      pinchMuted.value = false;
    })
    .onTouchesUp((e) => {
      // Queda 1 dedo (o ninguno): el pellizco termina AQUI, como en WhatsApp.
      // Sin esto RNGH seguiria mandando updates con el foco en el dedo
      // restante y la imagen daria el salto.
      if (e.numberOfTouches <= 1) pinchMuted.value = true;
    })
    .onStart((e) => {
      pinchMuted.value = false;
      p0s.value = Math.max(0.01, scale.value);
      p0x.value = tx.value;
      p0y.value = ty.value;
      p0e.value = e.scale > 0 ? e.scale : 1;
      p0fx.value = e.focalX - boxW.value / 2;
      p0fy.value = e.focalY - boxH.value / 2;
      pfx.value = p0fx.value;
      pfy.value = p0fy.value;
    })
    .onUpdate((e) => {
      lastE.value = e.scale;
      if (pinchMuted.value) return;
      const fx = e.focalX - boxW.value / 2;
      const fy = e.focalY - boxH.value / 2;
      // Red de seguridad: el foco no puede teletransportarse de un frame a
      // otro; si lo hace es el artefacto de levantar un dedo -> enmudecer.
      const jx = fx - pfx.value;
      const jy = fy - pfy.value;
      if (jx * jx + jy * jy > 3600) { pinchMuted.value = true; return; }
      pfx.value = fx;
      pfy.value = fy;
      const s0 = p0s.value;
      if (s0 <= 0) return;
      const next = clamp(s0 * (e.scale / p0e.value), MINZ, MAXZ);
      const ratio = next / s0;
      scale.value = next;
      // t = f − (f₀ − t₀)·ratio: el contenido que estaba bajo el foco inicial
      // sigue bajo el foco actual (zoom + traslado de dos dedos exactos),
      // topado a los bordes reales: nada se sale y "vuelve" al soltar.
      const b = bounds(next);
      tx.value = clamp(fx - (p0fx.value - p0x.value) * ratio, -b.maxX, b.maxX);
      ty.value = clamp(fy - (p0fy.value - p0y.value) * ratio, -b.maxY, b.maxY);
    })
    .onEnd(() => {
      if (scale.value <= 1.02) resetZoom();
      else snapToBounds();
    });'''.split('\n')

lines[i_comment:i_end + 1] = pinch_new

# ── 3) Ampliar la viñeta del pellizco en la cabecera ─────────────────────────
i_hdr = find(lambda l: l.strip() == 'va 1:1. Límites 1x–5x.')
lines[i_hdr:i_hdr + 1] = [
    '     va 1:1. Límites 1x–5x. Al levantar UN dedo el gesto se enmudece (fix',
    '     del "salto al soltar": RNGH movería el foco al dedo restante y la foto',
    '     saltaría) y el traslado va topado a los bordes durante el gesto → al',
    '     soltar no rebota nada.',
]

out = '\r\n'.join(lines)
with io.open(PATH, 'w', encoding='utf-8', newline='') as f:
    f.write(out)

# verificaciones minimas
for needle in ['pinchMuted', '.onTouchesUp(', '.onTouchesDown(', 'p0e.value', 'jx * jx + jy * jy > 3600']:
    assert needle in out, needle
assert out.count('const pinch = Gesture.Pinch()') == 1
assert '\r\r' not in out and '\n\n\n\n' not in out
print('OK — SocialScreen.js parcheado (fix salto al soltar)')
