#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regenera los ZIPs de entrega con el PAQUETE WHATSAPP:
- Visor: barra negra superior auto-oculta (cerrar + compartir), sin numeración
- Chat: separadores de fecha, salto a citas, zonas automáticas (sin botón),
  fondo sin velo blanco, tarjeta de archivo grande y audios reproducibles
- expo-audio en package.json/app.json + servicios chatSync/fechasChat + test
Preserva los bytes exactos del resto de entradas."""
import hashlib, os, shutil, zipfile

APP = os.path.join('proyecto', 'mi-app-entrenos')

def blob(*p):
    with open(os.path.join(*p), 'rb') as f:
        return f.read()

SOCIAL   = blob(APP, 'screens', 'SocialScreen.js')
APPSET   = blob(APP, 'screens', 'AppSettingsScreen.js')
PKG      = blob(APP, 'package.json')
APPJSON  = blob(APP, 'app.json')
SYNC     = blob(APP, 'services', 'chatSync.js')
FECHAS   = blob(APP, 'services', 'fechasChat.js')
STORE    = blob(APP, 'services', 'chatStore.js')
TEST     = blob('tests', 'chat-sync-test.js')
ZOOMDOC  = blob('ZOOM-GESTOS.md')
CHATDOC  = blob('CHAT-SYNC-SETUP.md')

PLAN = {
    'fix-chat-sync.zip': (
        {'APP/screens/SocialScreen.js': SOCIAL, 'CHAT-SYNC-SETUP.md': CHATDOC},
        {'APP/services/chatSync.js': SYNC, 'APP/services/fechasChat.js': FECHAS},
    ),
    'fix-zoom-gestos.zip': (
        {'APP/screens/SocialScreen.js': SOCIAL, 'APP/package.json': PKG, 'ZOOM-GESTOS.md': ZOOMDOC},
        {'APP/app.json': APPJSON, 'APP/services/chatSync.js': SYNC, 'APP/services/fechasChat.js': FECHAS},
    ),
    'archivos-corregidos.zip': (
        {'screens/SocialScreen.js': SOCIAL, 'screens/AppSettingsScreen.js': APPSET,
         'package.json': PKG, 'app.json': APPJSON},
        {'services/chatSync.js': SYNC, 'services/fechasChat.js': FECHAS},
    ),
    'mi-app-entrenos-CORREGIDO.zip': (
        {'screens/SocialScreen.js': SOCIAL, 'screens/AppSettingsScreen.js': APPSET,
         'package.json': PKG, 'app.json': APPJSON},
        {'services/chatSync.js': SYNC, 'services/fechasChat.js': FECHAS},
    ),
    'mi-app-entrenos-PROYECTO-CORREGIDO.zip': (
        {'mi-app-entrenos/screens/SocialScreen.js': SOCIAL,
         'mi-app-entrenos/screens/AppSettingsScreen.js': APPSET,
         'mi-app-entrenos/package.json': PKG, 'mi-app-entrenos/app.json': APPJSON},
        {'mi-app-entrenos/services/chatSync.js': SYNC, 'mi-app-entrenos/services/fechasChat.js': FECHAS},
    ),
}

for zname, (repl, add) in PLAN.items():
    src = zipfile.ZipFile(zname, 'r')
    tmp = zname + '.tmp'
    seen = set()
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as out:
        for item in src.infolist():
            if item.filename in repl:
                out.writestr(item.filename, repl[item.filename])
                seen.add(item.filename)
            else:
                out.writestr(item.filename, src.read(item.filename))
        for name, data in add.items():
            if name not in seen:
                out.writestr(name, data)
                seen.add(name)
        faltan = set(repl) - seen
        if faltan:
            raise SystemExit('%s: entradas no encontradas: %s' % (zname, sorted(faltan)))
    src.close()
    shutil.move(tmp, zname)
    n = len(zipfile.ZipFile(zname).namelist())
    print('OK %-45s %2d entradas (tocado %d)' % (zname, n, len(seen)))

# ZIP del cambio actual (paquete WhatsApp)
with zipfile.ZipFile('fix-whatsapp-pack.zip', 'w', zipfile.ZIP_DEFLATED) as out:
    out.writestr('APP/screens/SocialScreen.js', SOCIAL)
    out.writestr('APP/screens/AppSettingsScreen.js', APPSET)
    out.writestr('APP/services/chatSync.js', SYNC)
    out.writestr('APP/services/fechasChat.js', FECHAS)
    out.writestr('APP/services/chatStore.js', STORE)
    out.writestr('APP/package.json', PKG)
    out.writestr('APP/app.json', APPJSON)
    out.writestr('tests/chat-sync-test.js', TEST)
    out.writestr('ZOOM-GESTOS.md', ZOOMDOC)
    out.writestr('CHAT-SYNC-SETUP.md', CHATDOC)
print('OK fix-whatsapp-pack.zip creado (10 entradas)')

# Staging sincronizado
st = os.path.join('entrega-social', 'app')
for rel, data in [
    (os.path.join('screens', 'SocialScreen.js'), SOCIAL),
    (os.path.join('screens', 'AppSettingsScreen.js'), APPSET),
    ('package.json', PKG),
    ('app.json', APPJSON),
    (os.path.join('services', 'chatSync.js'), SYNC),
    (os.path.join('services', 'fechasChat.js'), FECHAS),
    (os.path.join('services', 'chatStore.js'), STORE),
]:
    p = os.path.join(st, rel)
    if os.path.isdir(os.path.dirname(p)):
        with open(p, 'wb') as f:
            f.write(data)
print('OK entrega-social sincronizado')

# Verificación de hashes en todos los ZIPs
checks = {
    'fix-chat-sync.zip': {'APP/screens/SocialScreen.js': SOCIAL, 'APP/services/chatSync.js': SYNC,
                          'APP/services/fechasChat.js': FECHAS, 'CHAT-SYNC-SETUP.md': CHATDOC},
    'fix-zoom-gestos.zip': {'APP/screens/SocialScreen.js': SOCIAL, 'APP/package.json': PKG,
                            'APP/app.json': APPJSON, 'ZOOM-GESTOS.md': ZOOMDOC},
    'archivos-corregidos.zip': {'screens/SocialScreen.js': SOCIAL, 'screens/AppSettingsScreen.js': APPSET,
                                'package.json': PKG, 'app.json': APPJSON,
                                'services/chatSync.js': SYNC, 'services/fechasChat.js': FECHAS},
    'mi-app-entrenos-CORREGIDO.zip': {'screens/SocialScreen.js': SOCIAL, 'screens/AppSettingsScreen.js': APPSET,
                                      'package.json': PKG, 'app.json': APPJSON,
                                      'services/chatSync.js': SYNC, 'services/fechasChat.js': FECHAS,
                                      'services/chatStore.js': STORE},
    'mi-app-entrenos-PROYECTO-CORREGIDO.zip': {'mi-app-entrenos/screens/SocialScreen.js': SOCIAL,
                                               'mi-app-entrenos/screens/AppSettingsScreen.js': APPSET,
                                               'mi-app-entrenos/package.json': PKG,
                                               'mi-app-entrenos/app.json': APPJSON,
                                               'mi-app-entrenos/services/chatSync.js': SYNC,
                                               'mi-app-entrenos/services/fechasChat.js': FECHAS},
    'fix-whatsapp-pack.zip': {'APP/screens/SocialScreen.js': SOCIAL, 'APP/screens/AppSettingsScreen.js': APPSET,
                              'APP/services/chatSync.js': SYNC, 'APP/services/fechasChat.js': FECHAS,
                              'APP/package.json': PKG, 'APP/app.json': APPJSON,
                              'tests/chat-sync-test.js': TEST},
}
for zname, entries in checks.items():
    with zipfile.ZipFile(zname) as z:
        for e, data in entries.items():
            assert hashlib.sha256(z.read(e)).hexdigest() == hashlib.sha256(data).hexdigest(), (zname, e)
print('OK hashes verificados en los 6 ZIPs')
print('TODO OK')
