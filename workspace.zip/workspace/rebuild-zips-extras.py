#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regenera los ZIPs de entrega con el PAQUETE WHATSAPP 2:
- Enlaces pinchables + previsualización Open Graph (lado emisor, como WhatsApp)
- Encuestas en vivo (voto optimista, listener por documento, "GANANDO" a color)
- Fotos de perfil con caché local (colección ligera `avatares`, patrón WhatsApp)
- Eliminar mensaje con media → borra también el objeto en Cloudflare R2
Preserva los bytes exactos del resto de entradas y verifica hashes al final.

ORDEN DE EJECUCIÓN: este script primero y rebuild-zips-vercel-hobby.py
DESPUÉS (regenera los ZIPs de servidor y completa la sección SERVER/ de
fix-whatsapp-extras.zip con el dispatcher, los handlers y la guía)."""
import hashlib, os, shutil, zipfile

APP = os.path.join('proyecto', 'mi-app-entrenos')
SRV = os.path.join('workspace-anterior', 'vercel-server', 'mi-app-entrenos-main')

def blob(*p):
    with open(os.path.join(*p), 'rb') as f:
        return f.read()

SOCIAL  = blob(APP, 'screens', 'SocialScreen.js')
PERFIL  = blob(APP, 'screens', 'ProfileScreen.js')
ENLACES = blob(APP, 'services', 'enlaces.js')
ENCUES  = blob(APP, 'services', 'encuestas.js')
LINKPR  = blob(APP, 'services', 'linkPreview.js')
AVATAR  = blob(APP, 'services', 'avatarCache.js')
RULES   = blob('firestore.rules')
DOC     = blob('WHATSAPP-EXTRAS.md')
T_ENL   = blob('tests', 'enlaces-test.js')
T_DEL   = blob('tests', 'delete-media-test.js')
T_LPP   = blob('tests', 'link-preview-parse-test.js')
S_DISP  = blob(SRV, 'api', '[...path].js')
S_VERCEL = blob(SRV, 'vercel.json')
S_LPREV = blob(SRV, 'handlers', 'social', 'link-preview.js')
S_DELMS = blob(SRV, 'handlers', 'social', 'delete-message.js')
S_LPP   = blob(SRV, 'lib', 'linkPreviewParse.js')
S_MEDIA = blob(SRV, 'lib', 'socialMedia.js')

SERVICIOS_NUEVOS = {
    'services/enlaces.js': ENLACES,
    'services/encuestas.js': ENCUES,
    'services/linkPreview.js': LINKPR,
    'services/avatarCache.js': AVATAR,
}

PLAN = {
    # ZIPs de arreglos acumulativos: SocialScreen al día + servicios nuevos
    'fix-chat-sync.zip': (
        {'APP/screens/SocialScreen.js': SOCIAL},
        {'APP/screens/ProfileScreen.js': PERFIL,
         'APP/services/enlaces.js': ENLACES, 'APP/services/encuestas.js': ENCUES,
         'APP/services/linkPreview.js': LINKPR, 'APP/services/avatarCache.js': AVATAR},
    ),
    'fix-zoom-gestos.zip': (
        {'APP/screens/SocialScreen.js': SOCIAL},
        {'APP/screens/ProfileScreen.js': PERFIL,
         'APP/services/enlaces.js': ENLACES, 'APP/services/encuestas.js': ENCUES,
         'APP/services/linkPreview.js': LINKPR, 'APP/services/avatarCache.js': AVATAR},
    ),
    'fix-whatsapp-pack.zip': (
        {'APP/screens/SocialScreen.js': SOCIAL},
        {'APP/screens/ProfileScreen.js': PERFIL,
         'APP/services/enlaces.js': ENLACES, 'APP/services/encuestas.js': ENCUES,
         'APP/services/linkPreview.js': LINKPR, 'APP/services/avatarCache.js': AVATAR},
    ),
    # Proyecto app completo (rutas planas)
    'archivos-corregidos.zip': (
        {'screens/SocialScreen.js': SOCIAL, 'screens/ProfileScreen.js': PERFIL},
        dict(SERVICIOS_NUEVOS),
    ),
    'mi-app-entrenos-CORREGIDO.zip': (
        {'screens/SocialScreen.js': SOCIAL, 'screens/ProfileScreen.js': PERFIL},
        dict(SERVICIOS_NUEVOS),
    ),
    # Proyecto app completo (carpeta mi-app-entrenos/)
    'mi-app-entrenos-PROYECTO-CORREGIDO.zip': (
        {'mi-app-entrenos/screens/SocialScreen.js': SOCIAL,
         'mi-app-entrenos/screens/ProfileScreen.js': PERFIL},
        {('mi-app-entrenos/' + k): v for k, v in SERVICIOS_NUEVOS.items()},
    ),
    # NOTA: los ZIPs de servidor completo (servidor-completo-para-vercel.zip y
    # mi-app-entrenos-server-CORREGIDO.zip) se regeneran con
    # rebuild-zips-vercel-hobby.py (estructura dispatcher: 1 sola función).
}

def sha(b):
    return hashlib.sha256(b).hexdigest()[:16]

for zname, (repl, add) in PLAN.items():
    src = zipfile.ZipFile(zname, 'r')
    tmp = zname + '.tmp'
    seen = set()
    infos = src.infolist()
    # Desduplicar: si una entrada aparece varias veces, se conserva la ÚLTIMA
    ultima = {}
    for i, item in enumerate(infos):
        ultima[item.filename] = i
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as out:
        for i, item in enumerate(infos):
            if ultima[item.filename] != i:
                continue                      # duplicado viejo: se descarta
            if item.filename in repl:
                out.writestr(item.filename, repl[item.filename])
            else:
                out.writestr(item.filename, src.read(item.filename))
            seen.add(item.filename)
        for name, data in add.items():
            if name not in seen:
                out.writestr(name, data)
                seen.add(name)
        faltan = set(repl) - seen
        if faltan:
            raise SystemExit('%s: entradas no encontradas: %s' % (zname, sorted(faltan)))
    src.close()
    shutil.move(tmp, zname)
    n = len(zipfile.ZipFile(zname).namelist())
    print('OK %-45s %2d entradas (tocado %d)' % (zname, n, len(seen)))

# ZIP del cambio actual (paquete WhatsApp 2)
with zipfile.ZipFile('fix-whatsapp-extras.zip', 'w', zipfile.ZIP_DEFLATED) as out:
    out.writestr('APP/screens/SocialScreen.js', SOCIAL)
    out.writestr('APP/screens/ProfileScreen.js', PERFIL)
    out.writestr('APP/services/enlaces.js', ENLACES)
    out.writestr('APP/services/encuestas.js', ENCUES)
    out.writestr('APP/services/linkPreview.js', LINKPR)
    out.writestr('APP/services/avatarCache.js', AVATAR)
    out.writestr('SERVER/api/[...path].js', S_DISP)
    out.writestr('SERVER/vercel.json', S_VERCEL)
    for _rel in sorted(os.listdir(os.path.join(SRV, 'handlers'))):
        _p = os.path.join(SRV, 'handlers', _rel)
        if os.path.isfile(_p):
            out.writestr('SERVER/handlers/' + _rel, blob(SRV, 'handlers', _rel))
        else:
            for _sub in sorted(os.listdir(_p)):
                out.writestr('SERVER/handlers/%s/%s' % (_rel, _sub), blob(SRV, 'handlers', _rel, _sub))
    out.writestr('SERVER/lib/linkPreviewParse.js', S_LPP)
    out.writestr('SERVER/lib/socialMedia.js', S_MEDIA)
    out.writestr('firestore.rules', RULES)
    out.writestr('tests/enlaces-test.js', T_ENL)
    out.writestr('tests/delete-media-test.js', T_DEL)
    out.writestr('tests/link-preview-parse-test.js', T_LPP)
    out.writestr('WHATSAPP-EXTRAS.md', DOC)
print('OK fix-whatsapp-extras.zip creado (%d entradas)' % len(zipfile.ZipFile('fix-whatsapp-extras.zip').namelist()))

# Staging sincronizado
st = os.path.join('entrega-social', 'app')
for rel, data in [
    (os.path.join('screens', 'SocialScreen.js'), SOCIAL),
    (os.path.join('screens', 'ProfileScreen.js'), PERFIL),
    (os.path.join('services', 'enlaces.js'), ENLACES),
    (os.path.join('services', 'encuestas.js'), ENCUES),
    (os.path.join('services', 'linkPreview.js'), LINKPR),
    (os.path.join('services', 'avatarCache.js'), AVATAR),
]:
    p = os.path.join(st, rel)
    if os.path.isdir(os.path.dirname(p)):
        with open(p, 'wb') as f:
            f.write(data)
print('OK entrega-social sincronizado')

# Verificación de hashes en TODOS los ZIPs
checks = {
    'fix-whatsapp-extras.zip': {
        'APP/screens/SocialScreen.js': SOCIAL, 'APP/screens/ProfileScreen.js': PERFIL,
        'APP/services/enlaces.js': ENLACES, 'APP/services/encuestas.js': ENCUES,
        'APP/services/linkPreview.js': LINKPR, 'APP/services/avatarCache.js': AVATAR,
        'SERVER/api/[...path].js': S_DISP,
        'SERVER/vercel.json': S_VERCEL,
        'SERVER/handlers/social/link-preview.js': S_LPREV,
        'SERVER/handlers/social/delete-message.js': S_DELMS,
        'SERVER/lib/linkPreviewParse.js': S_LPP, 'SERVER/lib/socialMedia.js': S_MEDIA,
        'firestore.rules': RULES, 'WHATSAPP-EXTRAS.md': DOC,
    },
    'fix-whatsapp-pack.zip': {'APP/screens/SocialScreen.js': SOCIAL, 'APP/services/avatarCache.js': AVATAR},
    'fix-chat-sync.zip': {'APP/screens/SocialScreen.js': SOCIAL, 'APP/services/enlaces.js': ENLACES},
    'fix-zoom-gestos.zip': {'APP/screens/SocialScreen.js': SOCIAL, 'APP/services/encuestas.js': ENCUES},
    'archivos-corregidos.zip': {'screens/SocialScreen.js': SOCIAL, 'screens/ProfileScreen.js': PERFIL,
                                'services/linkPreview.js': LINKPR},
    'mi-app-entrenos-CORREGIDO.zip': {'screens/SocialScreen.js': SOCIAL, 'screens/ProfileScreen.js': PERFIL,
                                      'services/avatarCache.js': AVATAR},
    'mi-app-entrenos-PROYECTO-CORREGIDO.zip': {'mi-app-entrenos/screens/SocialScreen.js': SOCIAL,
                                               'mi-app-entrenos/screens/ProfileScreen.js': PERFIL,
                                               'mi-app-entrenos/services/enlaces.js': ENLACES},
}
fallos = 0
for zname in PLAN:
    with zipfile.ZipFile(zname) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            print('DUPLICADOS en %s' % zname); fallos += 1
with zipfile.ZipFile('fix-whatsapp-extras.zip') as z:
    names = z.namelist()
    if len(names) != len(set(names)):
        print('DUPLICADOS en fix-whatsapp-extras.zip'); fallos += 1
for zname, entradas in checks.items():
    with zipfile.ZipFile(zname) as z:
        for name, data in entradas.items():
            try:
                got = z.read(name)
            except KeyError:
                print('FALTA %s en %s' % (name, zname)); fallos += 1; continue
            if sha(got) != sha(data):
                print('HASH DISTINTO %s en %s' % (name, zname)); fallos += 1
print('Verificación de hashes:', 'TODO OK' if fallos == 0 else '%d FALLOS' % fallos)
raise SystemExit(1 if fallos else 0)
