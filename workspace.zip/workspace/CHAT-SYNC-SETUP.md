# CHAT SINCRONIZADO ESTILO WHATSAPP — VERIFICACIÓN E IMPLANTACIÓN

Documento de la entrega "chat sync" (Tablón de la pestaña Social · **historial permanente, sin caducidad automática**).

---

## 1. ¿Es real lo que decía el chat de Duck.ai? SÍ, verificado en la documentación oficial

| Afirmación de Duck.ai | Veredicto | Fuente oficial |
|---|---|---|
| `onSnapshot()` entrega solo cambios tras la primera snapshot, con `docChanges()` de tipo `added` / `modified` / `removed` | ✅ REAL | https://firebase.google.com/docs/firestore/query-data/listen |
| Paginación con `limit()` + cursores (`startAfter` / rangos) sin re-descargar todo | ✅ REAL | https://firebase.google.com/docs/firestore/query-data/query-cursors |
| Sincronización incremental con `where(createdAt > últimaSync)` | ✅ REAL (y no necesita índice compuesto: rango y ordenación sobre el MISMO campo usan el índice simple que Firestore crea solo) | https://firebase.google.com/docs/firestore/query-data/queries |
| Política TTL: Firestore borra solo los docs caducados, normalmente dentro de las 24 h siguientes a `expiraAt`, por collection group | ✅ REAL | https://firebase.google.com/docs/firestore/ttl |
| La caché interna de Firestore NO sirve como copia permanente: hay que guardar en local (SQLite/AsyncStorage) | ✅ REAL (la caché offline se puede limpiar; el patrón "local-first" es el recomendado por Expo) | https://docs.expo.dev/guides/local-first/ |
| Con `limit()`, un `removed` puede significar "salió de la ventana" y no "lo borraron" → conviene borrado lógico | ✅ REAL y aplicado: eliminar = `eliminado: true` ("Mensaje eliminado"), y el `removed` de caducidad se ignora a propósito para conservar la copia local | https://firebase.google.com/docs/firestore/query-data/listen |
| Vercel cron para tareas privadas | ✅ REAL: si defines `CRON_SECRET`, Vercel lo envía SOLO él como cabecera `Authorization: Bearer …` en cada invocación programada | https://vercel.com/docs/cron-jobs/manage-cron-jobs |
| SQLite con `expo-sqlite` como base local | ⚠️ REAL pero opcional aquí: exige añadir dependencia nativa y rebuild. Se implantó el mismo patrón con **AsyncStorage** (ya instalado en tu app, sin rebuild y válido para el volumen de un chat de equipo). El almacén (`services/chatStore.js`) está diseñado con funciones conmutables por si algún día quieres SQLite. | https://docs.expo.dev/versions/latest/sdk/sqlite/ |

**Matices importantes que Duck.ai no contó bien y aquí sí están resueltos:**
- Un listener con `where(createdAt > X)` no actualiza reacciones/votos de mensajes ANTIGUOS (fuera de la ventana). Aquí: las acciones optimistas se persisten en el local al momento y el pull-to-refresh refresca la ventana reciente (120 docs) sin bajar todo.
- El TTL de Firestore no es instantáneo (±24 h) y hay que activarlo en la consola de Google Cloud. **Decisión final: NO se usa caducidad automática.** Con la sincronización incremental el coste ya no depende del tamaño del historial (ver §2.1), así que borrar mensajes solo aportaría pérdida de historial. El endpoint `api/social/purge` se conserva como herramienta opcional **desactivada por defecto** (`RETENTION_DAYS`).

---

## 2. Arquitectura implantada

```
DISPOSITIVO (app Expo)                          SERVIDOR
┌───────────────────────────────┐      ┌──────────────────────────────┐
│ chatStore (AsyncStorage)      │      │ Firestore  posts/{id}        │
│  · historial COMPLETO recibido│      │  · createdAt (ISO)           │
│  · se pinta al instante,      │      │  · historial PERMANENTE:     │
│    sin red                    │      │    sin caducidad (la purga   │
│                               │      │    es una herramienta        │
│ Listener onSnapshot           │◄────┤    opcional desactivada)     │
│  where createdAt > lastSync   │      │                              │
│  docChanges: added/modified   │      │ Cloudflare R2 (imágenes)     │
│  removed → SE IGNORA          │      └──────────────────────────────┘
│   (defensivo: el local conserva)
│                               │
│ gapSync al abrir:             │
│  solo mensajes > lastSync     │
│  (lotes de 300)               │
│ ZONAS AUTOMÁTICAS:            │
│  bloques de 50 hacia atrás    │
│  al rozar el borde superior   │
│  (sin botón de descargar)     │
└───────────────────────────────┘
```

Comportamiento resultante (lo que pediste):
1. **Abrir el chat no descarga todo**: pinta el almacén local al instante y luego pide SOLO lo posterior a `lastSync`.
2. **Primera vez en un dispositivo**: solo los 60 mensajes más recientes; el resto se carga POR ZONAS de 50 **automáticamente** al acercar el scroll al borde superior (manteniendo la posición). Ya NO existe el botón de "Cargar mensajes anteriores" (la opción de descargarse el chat de la nube desapareció de la interfaz).
3. **Mensajes nuevos / editados / reacciones** llegan en vivo por `docChanges()` y se fusionan sin duplicados.
4. **Historial permanente**: los mensajes ya NO caducan. Todos los dispositivos ven el mismo historial completo paginando hacia atrás, como en WhatsApp.
5. **Eliminar un mensaje** = borrado lógico: los demás ven "🚫 Mensaje eliminado".

### 2.1 ¿Por qué ya no hace falta borrar mensajes antiguos?

El problema original era que **cada apertura leía la base de datos entera**, cada vez más grande. Eso ya está resuelto por el diseño de sincronización:

| Situación | Docs leídos | ¿Depende del tamaño total del historial? |
|---|---|---|
| Abrir el chat (usuario habitual) | solo los mensajes nuevos desde `lastSync` | NO |
| Dispositivo nuevo / primera vez | los 60 más recientes | NO |
| "Cargar mensajes anteriores" | 50 por pulsación, y solo si el usuario sube | NO |
| Listener en vivo | solo los cambios (`docChanges`) | NO |

- Firestore cobra **por documento leído/escrito**, no por el tamaño de la colección: tener 100.000 mensajes antiguos guardados no cuesta nada mientras no se lean.
- Las consultas `orderBy(createdAt) + limit` van por índice: tardan lo mismo con 100 que con 1.000.000 de docs.
- Lo único que crece es el **almacenamiento**, que es lo más barato del sistema: ~1 KB por mensaje → 500 mensajes/día ≈ 180 MB/año ≈ céntimos al mes (Firestore: 1 GB gratis y después 0,18 $/GB/mes; R2: 10 GB gratis y después 0,015 $/GB/mes).
- Extra: sin purga, el cron deja de gastar escrituras diarias de Firestore y el sistema tiene **una pieza móvil menos** (nada de `CRON_SECRET`, ni `vercel.json`, ni logs de cron que vigilar).

En consecuencia: la app **ya no escribe `expiraAt`** en los mensajes nuevos, y los antiguos que lo lleven se quedan inertes (ningún proceso los borra). `api/social/purge.js` sigue existiendo como herramienta de mantenimiento **desactivada por defecto** (derecho al olvido, o si algún día quisieras volver a mensajes temporales): solo actúa si defines `RETENTION_DAYS > 0`.

---

## 3. Despliegue PASO A PASO

### A) Servidor (GitHub → Vercel) — ya no es necesario
El chat no necesita nada nuevo en el servidor: **no hay cron, ni `CRON_SECRET`, ni `vercel.json`**. Si ya copiaste el `vercel.json` con el bloque `crons` en un intento anterior, bórralo del repo (o deja el archivo sin el bloque `crons`).

Opcional — dejar dormida la herramienta de purga por si algún día la necesitas:
1. Copia `api/social/purge.js` a tu repo (rama `main`). Sin variables no borra nada; responde `{"ok":true,"disabled":true,...}`.
2. Para **activarla** en el futuro harían falta las 3 piezas: `RETENTION_DAYS=31` + `CRON_SECRET` (cadena aleatoria 16+ caracteres) en Vercel → Settings → Environment Variables, y un `vercel.json` con:
   ```json
   { "crons": [{ "path": "/api/social/purge", "schedule": "0 4 * * *" }] }
   ```
   Vercel enviará él solo `Authorization: Bearer <CRON_SECRET>` en cada invocación programada; sin ese secreto, 401.

### B) App (Expo)
1. Copia estos archivos del ZIP:
   - `services/chatStore.js`  (almacén local)
   - `services/chatSync.js`   (NUEVO: motor gapSync + zonas de 50)
   - `services/fechasChat.js` (NUEVO: separadores de fecha y utilidades puras)
   - `screens/SocialScreen.js`
   - `package.json` y `app.json` (añaden `expo-audio` para los audios en el chat)
2. La sincronización en sí **no añade dependencias**. El `expo-audio` de los audios SÍ es un módulo nativo: tras `npm install` toca rebuild del APK (ver ZOOM-GESTOS.md §Despliegue). Por OTA sobre el APK viejo la app funciona igual y los audios se abren con el panel del sistema.
3. La primera apertura migra sola la caché antigua del Tablón al almacén nuevo (no se pierde lo visible).

### C) TTL nativo de Firestore: NO lo actives
Con historial permanente, el TTL nativo de Google borraría justo lo que queremos conservar. Si en algún momento llegaste a activarlo para la colección `posts`, desactívalo:
```bash
gcloud firestore fields ttl update expiraAt --collection-group=posts --disable-ttl
```
Si nunca lo activaste (lo normal), no hay nada que hacer. Los mensajes antiguos que aún llevan `expiraAt` son inocuos: sin política TTL y sin purga activa, ese campo no lo lee nadie.

### D) Reglas de Firestore
No cambian: `posts` ya permite create firmada por el autor y update por autenticados (reacciones/votes/borrado lógico). El endpoint de purga (si llegaras a activarlo) usa firebase-admin, que ignora las reglas.

---

## 4. Archivos de esta entrega
| Archivo | Tipo | Qué hace |
|---|---|---|
| `services/chatStore.js` | app | Almacén local persistente del chat + meta de sincronización + migración de la caché vieja |
| `services/chatSync.js` | app (NUEVO) | Motor de sincronización aislado y testeable: primera página de 60, gapSync incremental (lotes de 300) y `loadOlderZone()` (zonas de 50) |
| `services/fechasChat.js` | app (NUEVO) | Separadores de fecha estilo WhatsApp (HOY/AYER/día/fecha con año) + fmtSize/fmtDur/detección de audios. Funciones puras, testeadas |
| `tests/chat-sync-test.js` | test (NUEVO) | Verifica el motor REAL contra Firestore y AsyncStorage simulados: 55 aserciones (`node tests/chat-sync-test.js`) |
| `screens/SocialScreen.js` | app | Listener docChanges + zonas automáticas al hacer scroll + borrado lógico + separadores + salto a citas. Ya NO escribe `expiraAt` |
| `api/social/purge.js` | server (OPCIONAL) | Herramienta de purga **desactivada por defecto**. Solo borra si defines `RETENTION_DAYS > 0` + `CRON_SECRET` |
| ~~`vercel.json`~~ | — | **Fuera de la entrega**: sin caducidad no hace falta cron. Si lo copiaste antes, elimínalo del repo |

---

## 5. Verificación del patrón Duck.ai (ronda "paquete WhatsApp", 21/09)

Todo lo que describía el archivo `duck.ai_2026-09-21_17-14-37.txt` está
implantado y **verificado con test automático** sobre los archivos reales
(`node tests/chat-sync-test.js` → 55 aserciones OK):

| Punto del documento Duck.ai | Estado |
|---|---|
| Base de datos local en el teléfono (no re-descargar lo ya visto) | ✅ `services/chatStore.js` (AsyncStorage, conmutable a SQLite) |
| Listener en tiempo real que solo entrega cambios (`docChanges`) | ✅ `onSnapshot` con `added`/`modified` fusionados; `removed` ignorado a propósito (conserva la copia local) |
| `unsubscribe()` al salir de la pantalla | ✅ en la limpieza del `useEffect` (`alive = false; unsub()`) |
| Sincronización incremental `where(createdAt > últimaSync)` | ✅ `gapSync()`; el test prueba 0 lecturas sin novedades y lotes 300/300/100 con 700 nuevos |
| Primera apertura: solo los últimos N (no todo el historial) | ✅ página inicial de 60; test: primera lectura = 60 docs de 1203 |
| Paginación hacia atrás por bloques con cursor | ✅ `loadOlderZone()`: zonas de 50 con `where createdAt < oldestAt`; test: 9 zonas completan 440 antiguos sin duplicados y con `hasMore` correcto |
| Sin índices compuestos | ✅ rango y orden sobre el MISMO campo (`createdAt`) = índice simple automático |
| Borrado lógico (`deleted: true`) en vez de físico | ✅ `eliminado: true` + "Mensaje eliminado" |
| Chat temporal con TTL + copia local permanente | ⚠️ Implantado como **opcional desactivada** (decisión tuya: historial permanente). El endpoint `api/social/purge` solo actúa con `RETENTION_DAYS > 0`; el local conserva igualmente todo (eviction a 4000 msgs) |
| SQLite local (`expo-sqlite`) | ➖ Sustituido por AsyncStorage (mismo patrón, sin rebuild). El almacén está encapsulado para cambiarlo sin tocar nada más |

Cambios de interfaz de esta ronda relacionados con el chat:
- **Fuera el botón "Cargar mensajes anteriores"** (la opción de descargarse
  el chat de la nube): las zonas de 50 se cargan SOLAS al rozar el borde
  superior, con spinner discreto y manteniendo la posición del scroll.
- **Separadores de fecha** estilo WhatsApp entre mensajes de días distintos
  (píldora negra semitransparente centrada): HOY · AYER · día de la semana
  (últimos 7 días) · "15 de marzo de 2024".
- **Tocar la cita de una respuesta** salta al mensaje original si está
  cargado (destello azul 1.6 s); si no existe, no hace nada. Las respuestas
  nuevas guardan el `id` del citado; las antiguas (sin id) simplemente no
  saltan.
- **Fondo del tablón sin velo blanco**: la imagen se ve tal cual se subió
  (además el picker ya no recomprime: `quality: 1`).
