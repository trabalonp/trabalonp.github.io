# Error "No more than 12 Serverless Functions" — SOLUCIONADO

## Qué ha pasado

El plan **Hobby (gratis) de Vercel** limita cada deployment a **12 Serverless
Functions**. Vercel convierte **cada archivo `.js` dentro de `/api`** en una
función independiente, y el proyecto ya tenía **13**:

```
api/notify-athlete.js            api/intervals/delete-event.js
api/sync-fitness.js              api/intervals/disconnect.js
api/sync-intervals.js            api/intervals/save-credentials.js
api/sync-intervals-detail.js     api/intervals/status.js
api/upload-to-intervals.js       api/social/presign.js
api/social/purge.js              api/social/link-preview.js     ← nuevo (WhatsApp extras)
                                 api/social/delete-message.js   ← nuevo (WhatsApp extras)
```

Al añadir `link-preview.js` y `delete-message.js` (ronda WhatsApp) se superó
el límite y el deploy falló en la fase "Deploying outputs".

## La solución: 1 sola función (dispatcher)

- Los 13 handlers se **mueven** de `api/` a una carpeta nueva `handlers/`
  (fuera de `api/`, por lo que Vercel NO los cuenta como funciones).
  El código de cada handler es **idéntico**; solo cambia su ubicación.
- Se crea **`api/[...path].js`**: una función catch-all que recibe todas las
  peticiones `/api/*` y las reparte al handler que corresponda. Reproduce el
  contrato `(req, res)` del runtime de Vercel (req.method, req.headers,
  req.body JSON, req.query, res.status().json()…).

**Resultado: 1 Serverless Function en vez de 13.** Las URLs públicas NO
cambian: la app sigue llamando exactamente a las mismas rutas
(`/api/social/presign`, `/api/social/link-preview`, `/api/intervals/status`…).
**La app no necesita ningún cambio ni nueva OTA por este motivo.**

### Estructura nueva del repo del servidor

```
mi-app-entrenos/  (repo de GitHub)
├── api/
│   └── [...path].js          ← ÚNICA función (dispatcher)
├── handlers/                 ← los 13 handlers de siempre (movidos)
│   ├── notify-athlete.js
│   ├── sync-fitness.js
│   ├── sync-intervals.js
│   ├── sync-intervals-detail.js
│   ├── upload-to-intervals.js
│   ├── intervals/
│   │   ├── delete-event.js
│   │   ├── disconnect.js
│   │   ├── save-credentials.js
│   │   └── status.js
│   └── social/
│       ├── delete-message.js
│       ├── link-preview.js
│       ├── presign.js
│       └── purge.js
├── lib/                      ← sin cambios de ubicación
├── vercel.json               ← NUEVO: rewrite /api/:path* (imprescindible,
│                                sin él las rutas de 2+ segmentos dan 404)
├── package.json              ← sin cambios
└── .gitignore
```

## ⚠️ RONDA 2 — 2 fallos detectados en el deploy real (CORREGIDOS)

Tras subir la reestructura a GitHub, el deploy pasó a Ready con 1 sola
función… pero al enviar una imagen por el Tablón la app recibió:

```
Error: presign HTTP 404: The page could not be found NOT_FOUND cdg1::…
```

Investigado contra la URL pública y reproducido localmente con
`vercel build` (CLI 59.24.0). Eran 2 fallos independientes:

### Fallo A — el catch-all de Vercel solo emparejaba 1 segmento

En proyectos SIN framework, el builder actual de Vercel genera para
`api/[...path].js` esta tabla de rutas (salida real de `vercel build`):

```json
{ "src": "^/api/([^/]+)$",  "dest": "/api/[...path]?...path=$1" }  ← SOLO 1 segmento
{ "src": "^/api(/.*)?$",    "status": 404 }                        ← el resto: 404 de plataforma
```

Es decir: `/api/notify-athlete` sí llegaba al dispatcher, pero TODAS las
rutas de 2 segmentos (`/api/social/presign`, `/api/social/link-preview`,
`/api/intervals/status`…) caían en el 404 de la plataforma ("The page
could not be found NOT_FOUND"). Estaba roto el envío de imágenes, los
previews de enlaces, el borrado de mensajes Y la sincronización Garmin.

**Solución — `vercel.json` en la raíz del repo** (archivo NUEVO, hay que
subirlo a GitHub):

```json
{
  "rewrites": [
    { "source": "/api/:path*", "destination": "/api/[...path]?path=:path*" }
  ]
}
```

El CLI traduce ese rewrite a una regla `^/api(?:/((?:[^/]+?)(?:/(?:[^/]+?))*))?$`
colocada ANTES de la regla 404: cualquier `/api/con/cuantos/segmentos`
llega al dispatcher con `req.query.path = "con/cuantos/segmentos"`.
Verificado con `vercel build` local + invocación directa del bundle.
Sigue siendo 1 sola Serverless Function (los rewrites no crean funciones).

### Fallo B — el bundle se desplegaba sin `handlers/`

El dispatcher usaba `require(RUTAS[clave])` (require DINÁMICO con
variable). El trazador de archivos de Vercel (`@vercel/nft`) solo detecta
`require('…')` con texto literal: el `.func` subido a producción contenía
únicamente `api/[...path].js` y, al recibir una ruta válida, reventaba con
`Cannot find module '../handlers/notify-athlete.js'` (HTTP 500).

**Solución:** el mapa `RUTAS` ahora asocia cada ruta a un THUNK con
require literal:

```js
const RUTAS = {
  'social/presign': () => require('../handlers/social/presign.js'),
  …
};
…
const handler = RUTAS[clave]();   // carga perezosa intacta
```

`nft` detecta los 13 requires literales y empaqueta `handlers/`, `lib/` y
sus dependencias (`firebase-admin`, `@aws-sdk/client-s3`…). Bundle final
verificado: ~18 MB (límite 250 MB), un solo deploy.

## BUG EXTRA encontrado y corregido de paso

Revisando el código se detectó que `api/social/link-preview.js` usaba una
función `hostSeguro()` que **no estaba definida ni importada en ningún sitio**
(se perdió al generar el archivo). En producción, cada petición de preview
habría reventado con `ReferenceError` y devuelto `preview: null` siempre:
los enlaces se habrían podido pinchar pero **sin tarjeta de previsualización**.

Corrección aplicada:

- `lib/linkPreviewParse.js` ahora incluye y exporta `hostSeguro(url)`:
  valida protocolo (solo http/https), bloquea `localhost`/`.local`/
  `.internal`, IPs literales privadas (loopback, 10/8, 172.16/12, 192.168/16,
  169.254 metadata de nube, CGNAT, IPv6) y resuelve el DNS comprobando que
  ninguna dirección sea privada (anti-SSRF completo).
- `handlers/social/link-preview.js` la importa de la librería.
- Tests ampliados: `tests/link-preview-parse-test.js` (51 aserciones) y nuevo
  `tests/dispatcher-test.js` (38 aserciones) que simula el runtime de Vercel
  y recorre las 13 rutas: 404 en rutas desconocidas, 405 por método, 401 por
  auth, purge con CRON_SECRET, SSRF bloqueado, JSON inválido → 400, etc.

## Cómo desplegarlo (paso a paso)

Opción recomendada — sustituir el contenido del repo:

1. Descarga `servidor-completo-para-vercel.zip` (contenido = raíz del repo,
   plano) y descomprímelo en una carpeta vacía.
2. En GitHub (github.com/trabalonp/mi-app-entrenos):
   - **Borra** las carpetas `api/intervals/` y `api/social/` y los 5 archivos
     sueltos de `api/` (notify-athlete.js, sync-fitness.js, sync-intervals.js,
     sync-intervals-detail.js, upload-to-intervals.js). En `api/` solo debe
     quedar `[...path].js`.
   - **Sube** el archivo `api/[...path].js`, el archivo `vercel.json`
     (raíz del repo, NUEVO), la carpeta `handlers/` completa y la carpeta
     `lib/` completa (sobrescribe `lib/linkPreviewParse.js`: ahora incluye
     `hostSeguro`).
   - `package.json` y `.gitignore` no cambian (puedes sobrescribirlos igual).
   - ⚠️ Comprueba en GitHub que la carpeta `handlers/` se ha subido COMPLETA
     (13 archivos). Al arrastrar carpetas en la web de GitHub a veces se
     cuela solo parte; si faltara, el deploy daría 500 "Cannot find module
     '../handlers/…'".
3. Commit + push a `main`. Vercel desplegará solo.
4. Verifica en Vercel → proyecto → Deployments: el deploy debe pasar a
   **Ready** y en Functions debe aparecer **1 única función**.

Comprobaciones rápidas tras el deploy (desde el navegador o curl):

- `https://mi-app-entrenos.vercel.app/api/social/presign` por GET →
  `{"error":"Método no permitido"}` (405). ⚠️ Si devuelve "The page could
  not be found NOT_FOUND" falta el `vercel.json` (fallo A).
- `https://mi-app-entrenos.vercel.app/api/no-existe` → `{"error":"Ruta no encontrada"}` (404 JSON)
- `https://mi-app-entrenos.vercel.app/api/x/y` (2 segmentos inventados) →
  `{"error":"Ruta no encontrada"}` (404 JSON del dispatcher, NO el 404 de
  plataforma). Es la prueba definitiva del rewrite.
- `https://mi-app-entrenos.vercel.app/api/notify-athlete` → 401/`{"error":"No autorizado"}`.
  Si devuelve 500 `Cannot find module '../handlers/…'` falta la carpeta
  `handlers/` en el repo (fallo B).
- En la app: enviar una imagen por el Tablón → debe subir sin error 404.
- En la app: enviar un enlace → debe aparecer la tarjeta de previsualización.

## Alternativa (si no quieres reestructurar)

Pagar el plan Pro (20 $/mes) o borrar endpoints. No compensa: el dispatcher
es el patrón estándar para Hobby, no añade latencia apreciable (el reparto es
una tabla hash + require perezoso) y deja sitio para las próximas 11 rutas
que se quieran añadir… o para seguir así indefinidamente (todas las rutas
nuevas se añaden al mapa `RUTAS` del dispatcher y como archivo en `handlers/`).

## Nota sobre el cron de purga

`/api/social/purge` sigue existiendo a través del dispatcher (ruta atendida
en el mapa). El `vercel.json` creado por el fallo A solo tiene `rewrites`;
si algún día se activa un cron, se añade ahí la clave `"crons"` con la misma
ruta `/api/social/purge` (la URL pública no cambia).
