#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fix 2: Notas/Triatlón/Otro también se subían como 'Workout' (gimnasio/fuerza
en Intervals.icu). Semántica correcta según el enum de deportes de la API:
  · Nota/Notas  → category NOTE (como Descanso): no es un entreno.
  · Triatlón    → type 'Other' (Intervals no tiene disciplina de triatlón).
  · Otro        → type 'Other'.
  · Fuerza      → type 'WeightTraining' (el tipo de fuerza real del enum).
  · fallback    → 'Other' en vez de 'Workout'.
"""
import os

WS = os.environ.get("ARENA_WORKSPACE", os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(WS, "workspace-anterior", "vercel-server", "mi-app-entrenos-main", "lib", "uploadWorkouts.js")

raw = open(P, "rb").read().decode("utf-8")
CRLF = "\r\n" in raw
s = raw.replace("\r\n", "\n") if CRLF else raw
n0 = len(s)

def rep(old, new, count=1):
    global s
    assert s.count(old) >= count, "NO ENCONTRADO: %r..." % old[:90]
    s = s.replace(old, new, count)

# ── 1) SPORT_MAP con los tipos reales del enum de Intervals.icu ──
rep("""const SPORT_MAP = {
  Running:  'Run',
  Ciclismo: 'Ride',
  Natación: 'Swim',
  Fuerza:   'Workout',
  Triatlón: 'Workout',
  Otro:     'Workout',
};
""",
"""/* Deportes de la app → disciplinas de Intervals.icu (enum de su API:
   Ride, Run, Swim, Walk, Hike, WeightTraining, Workout, VirtualRide,
   VirtualRun, Other). 'Workout' es su tipo genérico de gimnasio, así que
   solo se usa si alguien lo pide explícitamente; el fallback es 'Other'. */
const SPORT_MAP = {
  Running:  'Run',
  Ciclismo: 'Ride',
  Natación: 'Swim',
  Fuerza:   'WeightTraining',   // fuerza real (mancuerna), no el genérico
  Triatlón: 'Other',             // Intervals no tiene disciplina de triatlón
  Otro:     'Other',
};
""")

# ── 2) Las notas van como NOTE, igual que los descansos ──
rep("""  let payload;
  if (w.tipo === 'Descanso') {
    payload = {
      category: 'NOTE', name,
      description: freeText || name,
      start_date_local: localIso(start),
      end_date_local: localIso(end),
    };
  } else if (w.tipo === 'Evento') {
""",
"""  let payload;
  if (w.tipo === 'Descanso' || w.tipo === 'Notas' || w.tipo === 'Nota') {
    // Una nota no es un entreno: categoría NOTE (marcador en el calendario)
    payload = {
      category: 'NOTE', name,
      description: freeText || name,
      start_date_local: localIso(start),
      end_date_local: localIso(end),
    };
  } else if (w.tipo === 'Evento') {
""")

# ── 3) Fallback general: 'Other' en vez del gimnasio 'Workout' ──
rep("""  const sport = w.tipo === 'Evento' ? eventSport(w) : (SPORT_MAP[w.tipo] || 'Workout');
""",
"""  const sport = w.tipo === 'Evento' ? eventSport(w) : (SPORT_MAP[w.tipo] || 'Other');
""")

out = s.replace("\n", "\r\n") if CRLF else s
open(P, "wb").write(out.encode("utf-8"))
print("OK: lib/uploadWorkouts.js (%d → %d bytes, CRLF=%s)" % (n0, len(s), CRLF))
