#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Sello de marca al estilo de la tarjeta original: logo cuadrado redondeado +
"TEAM JORGE" manuscrito (Kalam-Bold) con subrayado de color, arriba a la
izquierda, y se recupera la esquina de galería superior izquierda.
Sin apellidos y sin "ATLETA TEAM JORGE" (ya no existen en el diseño)."""
import os

WS = os.environ.get("ARENA_WORKSPACE", os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(WS, "proyecto", "mi-app-entrenos", "screens", "SettingsScreen.js")

raw = open(P, "rb").read().decode("utf-8")
CRLF = "\r\n" in raw
s = raw.replace("\r\n", "\n") if CRLF else raw
n0 = len(s)

def rep(old, new, count=1):
    global s
    assert s.count(old) >= count, "NO ENCONTRADO: %r..." % old[:80]
    s = s.replace(old, new, count)

# ── 1) Paletas: el sello pasa a ser logo cuadrado + texto manuscrito + subrayado ──
rep("""    brandRing: GREEN + '55',   // aro del logo de la app
    brandText: '#A9CBB0',      // nombre de la app
""",
"""    brandText: '#F4F8F2',      // "TEAM JORGE" manuscrito (noche)
    brandUnder: GREEN,         // subrayado del sello
""")
rep("""    brandRing: '#C05F3566',    // aro del logo de la app
    brandText: '#8A5E42',      // nombre de la app
""",
"""    brandText: '#4A2E1C',      // "TEAM JORGE" manuscrito (día)
    brandUnder: '#E4572E',     // subrayado del sello
""")

# ── 2) Se recupera la esquina de galería superior izquierda (como en la original) ──
rep("""            {/* (la esquina superior izquierda la ocupa el sello de marca) */}
""",
"""            <Path d="M16 46 L16 16 L46 16" fill="none" stroke={P.decor} strokeWidth={2.5} strokeOpacity={P.cornerOp} />
""")

# ── 3) Sello al estilo original: logo cuadrado redondeado + manuscrito subrayado ──
rep("""          {/* ══ SELLO DE MARCA: logo de la app + nombre, arriba a la
               izquierda, para saber de qué app viene la tarjeta ══ */}
          <View style={styles.shareBrand}>
            <Image
              source={require('../assets/images/icon.png')}   // expo.name → "Team Jorge App"
              style={[styles.shareBrandLogo, { borderColor: P.brandRing }]}
            />
            <Text style={[styles.shareBrandName, { color: P.brandText }]} numberOfLines={1}>
              TEAM JORGE APP
            </Text>
          </View>
""",
"""          {/* ══ SELLO DE MARCA (estilo de la tarjeta original): logo cuadrado
               redondeado + "TEAM JORGE" manuscrito con su subrayado, arriba a
               la izquierda. Solo la marca de la app: sin apellidos y sin
               "ATLETA TEAM JORGE". ══ */}
          <View style={styles.shareBrand}>
            <Image
              source={require('../assets/images/icon.png')}   // logo cuadrado de la app
              style={styles.shareBrandLogo}
            />
            <View>
              <Text style={[styles.shareBrandName, { color: P.brandText }]} numberOfLines={1}>
                TEAM JORGE
              </Text>
              <View style={[styles.shareBrandUnder, { backgroundColor: P.brandUnder }]} />
            </View>
          </View>
""")

# ── 4) Estilos del sello nuevos ──
rep("""  shareBrand: {
    position: 'absolute', top: 16, left: 16,
    flexDirection: 'row', alignItems: 'center', gap: 8,
  },
  shareBrandLogo: { width: 26, height: 26, borderRadius: 13, borderWidth: 1 },
  shareBrandName: { fontSize: 10.5, fontWeight: '800', letterSpacing: 2.2 },
""",
"""  shareBrand: {
    position: 'absolute', top: 24, left: 26,
    flexDirection: 'row', alignItems: 'center', gap: 12,
  },
  shareBrandLogo: { width: 40, height: 40, borderRadius: 10 },  // cuadrado redondeado
  shareBrandName: {
    fontFamily: 'Kalam-Bold',   // manuscrita, como en la tarjeta original
    fontSize: 19, letterSpacing: 2, lineHeight: 21,
  },
  shareBrandUnder: { height: 3, width: 64, borderRadius: 1.5, marginTop: 3 },
""")

out = s.replace("\n", "\r\n") if CRLF else s
open(P, "wb").write(out.encode("utf-8"))
print("OK: sello estilo original (%d → %d bytes, CRLF=%s)" % (n0, len(s), CRLF))
