#!/usr/bin/env node
/**
 * tools/medir-documentos.js — Auditoría A8: medición del tamaño de los
 * documentos de Firestore de la colección `entrenamientos`.
 *
 * ⚠️ SOLO LECTURA: este script únicamente hace lecturas (`get()`) contra
 * Firestore. NO escribe, NO actualiza y NO borra NADA en la base de datos.
 *
 * Qué hace
 * --------
 * 1. Inicializa el Admin SDK con el MISMO módulo del backend
 *    (lib/firebase.js, sin modificarlo). Ese módulo exige la variable de
 *    entorno FIREBASE_SERVICE_ACCOUNT (JSON de la cuenta de servicio). Si no
 *    está definida (o el JSON es inválido), el script imprime un mensaje
 *    claro y sale con código 2, SIN mostrar credenciales ni el detalle del
 *    error original (que podría contener fragmentos del JSON).
 * 2. Toma una MUESTRA configurable (por defecto 200 documentos) de la
 *    colección `entrenamientos` mediante limit(N).get() — solo lectura.
 * 3. Para cada documento mide bytes APROXIMADOS (Buffer.byteLength del JSON
 *    serializado con UTF-8):
 *      · resumen   → datos del doc principal `entrenamientos/<id>`
 *      · detalles  → `entrenamientos/<id>/detalles/data` (si existe)
 *      · registros → `entrenamientos/<id>/registros/data` (si existe)
 *    y además cuenta:
 *      · el nº de puntos de `registros/data.puntos`
 *      · cuántos resúmenes llevan el campo `registros` embebido en el propio
 *        doc principal (y cuántos elementos suman en total si son arrays).
 * 4. Imprime por consola un resumen legible: nº de docs muestreados,
 *    percentiles p50/p95 y máximo de bytes por bloque, media/máximo de
 *    puntos y nº de resúmenes con `registros` embebido. Cada documento se
 *    procesa en un try/catch propio: un error en un doc no detiene el resto.
 *
 * Uso
 * ---
 *   node tools/medir-documentos.js            # muestra por defecto: 200
 *   node tools/medir-documentos.js 500        # muestra de 500 documentos
 *   MUESTRA=500 node tools/medir-documentos.js
 *
 * Credenciales (nunca se hardcodean aquí):
 *   FIREBASE_SERVICE_ACCOUNT='{"type":"service_account",...}' \
 *     node tools/medir-documentos.js
 */

'use strict';

// ─────────────────────────────────────────────────────────────────────────────
// 1) Admin SDK vía lib/firebase.js (se usa TAL CUAL, sin modificarlo)
// ─────────────────────────────────────────────────────────────────────────────
let admin;
try {
  admin = require('../lib/firebase.js');
} catch (err) {
  // NO se imprime el error original: su mensaje podría incluir fragmentos del
  // JSON de credenciales (JSON.parse de Node moderno incluye el texto de
  // entrada en el mensaje del SyntaxError).
  const variableUsada = 'FIREBASE_SERVICE_ACCOUNT'; // la que lee lib/firebase.js
  if (err && err.message === `Falta la variable ${variableUsada}`) {
    console.error(`[medir-documentos] No se puede inicializar Firebase Admin: falta la variable de entorno ${variableUsada}.`);
  } else {
    console.error('[medir-documentos] No se puede inicializar Firebase Admin: revisa la variable de entorno de credenciales (ausente o JSON inválido).');
  }
  console.error(`Define ${variableUsada} (o la variable que use lib/firebase.js) para ejecutar esta herramienta.`);
  process.exit(2);
}

const db = admin.firestore();

// ─────────────────────────────────────────────────────────────────────────────
// Utilidades
// ─────────────────────────────────────────────────────────────────────────────

/** Bytes → texto legible (B / KB / MB). */
function formatBytes(n) {
  if (!Number.isFinite(n) || n < 0) return '—';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

/** Percentil por rango más cercano (nearest-rank) sobre un array ordenado. */
function percentile(sorted, p) {
  if (!sorted.length) return null;
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.ceil((p / 100) * sorted.length) - 1));
  return sorted[idx];
}

/** Tamaño de muestra: primer argumento de CLI o variable de entorno MUESTRA. */
function parseMuestra(argCli, envVal) {
  const raw = argCli !== undefined ? argCli : envVal;
  const n = Number.parseInt(String(raw ?? '').trim(), 10);
  if (!Number.isInteger(n) || n < 1) {
    return { n: 200, aviso: Boolean(raw) };
  }
  return { n, aviso: false };
}

// ─────────────────────────────────────────────────────────────────────────────
// Medición
// ─────────────────────────────────────────────────────────────────────────────
async function main() {
  const { n, aviso } = parseMuestra(process.argv[2], process.env.MUESTRA);
  if (aviso) {
    console.warn(`[medir-documentos] Muestra inválida ("${process.argv[2] || process.env.MUESTRA}"); se usa el valor por defecto (200).`);
  }

  console.log('=== medir-documentos (auditoría A8) — SOLO LECTURA, no escribe nada en Firestore ===');
  console.log(`Colección: entrenamientos | Muestra solicitada: ${n} | Documentos leídos con getDocs(limit(N))`);

  const snap = await db.collection('entrenamientos').limit(n).get();

  const resumenBytes = [];
  const detalleBytes = [];
  const registrosBytes = [];
  const puntosPorDoc = []; // nº de puntos por doc que TIENE registros/data
  let conRegistrosEmbebido = 0; // docs cuyo resumen lleva el campo `registros`
  let elementosEmbebidos = 0;   // suma de elementos si ese campo es un array
  let errores = 0;

  for (const doc of snap.docs) {
    try {
      // ── Resumen: datos del documento principal ──
      const data = doc.data() || {};
      resumenBytes.push(Buffer.byteLength(JSON.stringify(data), 'utf8'));

      // ¿El resumen lleva `registros` embebido?
      if (Object.prototype.hasOwnProperty.call(data, 'registros')) {
        conRegistrosEmbebido += 1;
        if (Array.isArray(data.registros)) elementosEmbebidos += data.registros.length;
      }

      // ── Detalles: subdoc entrenamientos/<id>/detalles/data ──
      const detSnap = await doc.ref.collection('detalles').doc('data').get();
      if (detSnap.exists) {
        detalleBytes.push(Buffer.byteLength(JSON.stringify(detSnap.data()), 'utf8'));
      }

      // ── Registros: subdoc entrenamientos/<id>/registros/data ──
      const regSnap = await doc.ref.collection('registros').doc('data').get();
      if (regSnap.exists) {
        const regData = regSnap.data() || {};
        registrosBytes.push(Buffer.byteLength(JSON.stringify(regData), 'utf8'));
        const puntos = Array.isArray(regData.puntos) ? regData.puntos : [];
        puntosPorDoc.push(puntos.length);
      }
    } catch (e) {
      errores += 1;
      const detalle = String(e && e.message ? e.message : e).slice(0, 120);
      console.warn(`[medir-documentos] Error al medir ${doc.id}: ${detalle}`);
      // Se continúa con el siguiente documento.
    }
  }

  const total = snap.docs.length;
  console.log(`Documentos muestreados: ${total} | analizados sin error: ${total - errores} | errores: ${errores}`);
  console.log('');

  if (total === 0) {
    console.log('La colección `entrenamientos` no devolvió documentos en esta muestra (¿colección vacía o credenciales apuntando a otro proyecto?).');
    return;
  }

  resumenBytes.sort((a, b) => a - b);
  detalleBytes.sort((a, b) => a - b);
  registrosBytes.sort((a, b) => a - b);

  console.log('Bytes por documento (aproximados: Buffer.byteLength del JSON serializado en UTF-8):');
  console.log('  Resumen (doc principal entrenamientos/<id>):');
  console.log(`    docs=${resumenBytes.length}  p50=${formatBytes(percentile(resumenBytes, 50))}  p95=${formatBytes(percentile(resumenBytes, 95))}  máx=${formatBytes(percentile(resumenBytes, 100))}`);
  console.log('  Detalles (subdoc detalles/data):');
  console.log(`    docs=${detalleBytes.length}  p50=${formatBytes(percentile(detalleBytes, 50))}  p95=${formatBytes(percentile(detalleBytes, 95))}  máx=${formatBytes(percentile(detalleBytes, 100))}`);
  console.log('  Registros (subdoc registros/data):');
  console.log(`    docs=${registrosBytes.length}  p50=${formatBytes(percentile(registrosBytes, 50))}  p95=${formatBytes(percentile(registrosBytes, 95))}  máx=${formatBytes(percentile(registrosBytes, 100))}`);

  const sumaPuntos = puntosPorDoc.reduce((a, b) => a + b, 0);
  const mediaPuntos = puntosPorDoc.length ? sumaPuntos / puntosPorDoc.length : 0;
  const maxPuntos = puntosPorDoc.length ? Math.max(...puntosPorDoc) : 0;
  console.log('');
  console.log('Puntos de registros/data.puntos:');
  console.log(`    docs con registros/data=${puntosPorDoc.length}  media=${mediaPuntos.toFixed(1)}  máx=${maxPuntos}`);

  const pctEmbebido = total ? ((conRegistrosEmbebido / total) * 100).toFixed(1) : '0.0';
  console.log(`Resúmenes con campo \`registros\` embebido: ${conRegistrosEmbebido} de ${total} (${pctEmbebido} %)${elementosEmbebidos > 0 ? ` — elementos totales: ${elementosEmbebidos}` : ''}`);

  console.log('');
  console.log('Notas: percentiles por rango más cercano (nearest-rank) y calculados solo sobre los documentos que tienen el bloque correspondiente. Script 100 % solo lectura.');
}

main().catch((err) => {
  console.error('[medir-documentos] Error fatal:', String(err && err.message ? err.message : err).slice(0, 200));
  process.exit(1);
});
