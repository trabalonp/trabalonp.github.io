// api/sync-intervals.js
const admin = require('../lib/firebase');
const { getUid } = require('../lib/auth');
const {
  getConnection,
  fetchActivities,
  mapIntervalsSport,
  paceFromSpeed,
} = require('../lib/intervals');
const { fetchAndStoreDetail, DETAIL_VERSION } = require('../lib/intervalsDetail');
const { uploadPendingWorkouts } = require('../lib/uploadWorkouts');
const { fetchAndStoreWellness } = require('../lib/wellness');
const { sendPushForSync, notifyCoachAfterSync } = require('../lib/push');

const db = admin.firestore();
const MAX_DETAIL_OPS = 8;

function toISODate(date) {
  return date.toISOString().split('T')[0];
}

function parseStartDate(activity) {
  const candidates = [
    activity.start_time,
    activity.start_time_local,
    activity.start_date,
    activity.startDate,
    activity.date,
  ];
  for (const c of candidates) {
    if (!c) continue;
    const d = new Date(c);
    if (!isNaN(d.getTime())) return d;
  }
  return null;
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método no permitido' });
  }

  try {
    const uid = await getUid(req);
    const connection = await getConnection(uid);

    const now = new Date();
    const defaultOldest = new Date(now);
    defaultOldest.setDate(now.getDate() - 30);

    const oldest = req.body?.oldest || connection.lastSyncDate || toISODate(defaultOldest);
    const newest = req.body?.newest || toISODate(now);

    console.log(`[sync-intervals] uid=${uid} oldest=${oldest} newest=${newest}`);

    // ── 1) Subir a Intervals.icu los entrenos de la app pendientes ──
    let uploaded = 0;
    try {
      uploaded = await uploadPendingWorkouts({ admin, db, connection, uid });
      if (uploaded > 0) console.log(`[sync-intervals] Entrenos subidos a Intervals.icu: ${uploaded}`);
    } catch (e) {
      console.warn('[sync-intervals] Error subiendo pendientes:', e.message);
    }

    // ── 2) Bajar actividades ──
    const activities = await fetchActivities(connection, oldest, newest);

    if (!Array.isArray(activities)) {
      console.error('[sync-intervals] Respuesta no es array:', JSON.stringify(activities).slice(0, 300));
      return res.status(502).json({ error: 'Respuesta inesperada de Intervals.icu' });
    }

    console.log(`[sync-intervals] Actividades recibidas: ${activities.length}`);

    let synced = 0;
    let skipped = 0;
    let detailOps = 0;
    const errorsList = [];

    for (const activity of activities) {
      const activityId = activity?.id ?? 'sin-id';

      try {
        const fileId = `intervals_${activityId}`;
        const docRef = db.collection('entrenamientos').doc(fileId);
        const existing = await docRef.get();

        if (existing.exists) {
          skipped++;
          if (detailOps < MAX_DETAIL_OPS) {
            const detSnap = await docRef.collection('detalles').doc('data').get();
            const det = detSnap.exists ? detSnap.data() : null;
            const needsDetail =
              !det ||
              det.detailVersion !== DETAIL_VERSION ||
              det.hasRuta !== true ||
              (!det.vueltasSource && (!Array.isArray(det.vueltas) || det.vueltas.length === 0));
            if (needsDetail) {
              await fetchAndStoreDetail({ admin, db, connection, docRef, activityId });
              detailOps++;
            }
          }
          continue;
        }

        const startDate = parseStartDate(activity);
        if (!startDate) {
          console.error(`[sync-intervals] Actividad ${activityId} sin fecha válida`);
          errorsList.push({ id: activityId, error: 'Sin fecha válida' });
          continue;
        }

        const tipo = mapIntervalsSport(activity.type || activity.sport);
        const titulo = activity.name || activity.title || tipo;

        const distanciaMetros = Number(activity.distance ?? 0);
        const distancia = Number((distanciaMetros / 1000).toFixed(2));
        const duracion = Number(activity.moving_time ?? activity.elapsed_time ?? activity.duration ?? 0);
        const fcMedia = Number(activity.avg_hr ?? activity.average_heartrate ?? 0);
        const fcMax = Number(activity.max_hr ?? activity.max_heart_rate ?? 0);
        const potenciaMedia = Number(activity.avg_watts ?? activity.average_watts ?? 0);
        const elevacion = Number(activity.elevation_gain ?? activity.total_elevation_gain ?? 0);
        const calorias = Number(activity.calories ?? 0);
        const avgSpeed = Number(
          activity.avg_speed ?? activity.average_speed ?? (duracion > 0 ? distanciaMetros / duracion : 0)
        );

        await docRef.set({
          userId: uid,
          id_archivo: fileId,
          source: 'intervals.icu',
          intervalsId: String(activityId),
          fecha: admin.firestore.Timestamp.fromDate(startDate),
          tipo,
          titulo,
          distancia,
          duracion,
          'fc-media': fcMedia,
          estado: 'completo',
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        await docRef.collection('detalles').doc('data').set({
          calorias,
          fcMax,
          ritmo: paceFromSpeed(avgSpeed),
          elevacionMin: 0,
          elevacionMax: 0,
          cadencia: Number(activity.avg_cadence ?? activity.cadence ?? 0),
          desnivelPos: elevacion,
          temperatura: Number(activity.avg_temp ?? activity.temperature ?? 0),
          potenciaMedia,
          tss: 0,
          notas: '',
          cargaPercibida: '',
          enlace: '',
          descripcion: activity.description || '',
          pasos: [],
          comentarios: [],
          vueltas: [],
          completado: false,
          garminSynced: false,
        }, { merge: true });

        synced++;

        if (detailOps < MAX_DETAIL_OPS) {
          await fetchAndStoreDetail({ admin, db, connection, docRef, activityId });
          detailOps++;
        }
      } catch (err) {
        console.error(`[sync-intervals] Error en actividad ${activityId}:`, err.message);
        errorsList.push({ id: activityId, error: err.message });
      }
    }

    if (synced > 0 || errorsList.length === 0) {
      await db.collection('intervals_connections').doc(uid).update({
        lastSyncDate: toISODate(now),
        lastSyncAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    }

    // ── 3) Recalcular serie Fitness/Fatigue/Form ──
    try {
      const { computeAndStoreFitness } = require('../lib/fitness');
      const fit = await computeAndStoreFitness({ admin, db, connection, uid });
      if (fit) console.log(`[sync-intervals] fitness recalculado: ${fit.days} días`);
    } catch (e) {
      console.warn('[sync-intervals] Error calculando fitness:', e.message);
    }

    // ── 4) NUEVO: wellness diario (sueño, FC reposo, VO2max, FC máx., kcal) ──
    let wellnessDays = 0;
    try {
      const wres = await fetchAndStoreWellness({ admin, db, connection, uid, activities, oldest, newest });
      wellnessDays = wres.days;
      if (wellnessDays > 0) console.log(`[sync-intervals] wellness guardado: ${wellnessDays} días`);
    } catch (e) {
      console.warn('[sync-intervals] Error wellness:', e.message);
    }

    await sendPushForSync(uid, synced, skipped, errorsList.length, activities.length);
    await notifyCoachAfterSync(uid, synced);

    return res.json({
      synced,
      skipped,
      subidos: uploaded,
      wellnessDays,
      errors: errorsList.length,
      errorDetails: errorsList.slice(0, 5),
      total: activities.length,
      detallesRellenados: detailOps,
      oldest,
      newest,
    });
  } catch (error) {
    console.error('[sync-intervals] Error global:', error);
    const status = error.status || 500;
    return res.status(status).json({
      error: error.message || 'Error sincronizando Intervals.icu',
    });
  }
};
