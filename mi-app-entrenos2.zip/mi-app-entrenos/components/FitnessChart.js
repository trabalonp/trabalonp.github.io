// components/FitnessChart.js
import React, { useMemo, useRef, useState } from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { CartesianChart, Line, Area } from 'victory-native';
import { Canvas, Path, Skia } from '@shopify/react-native-skia';
import * as ScreenOrientation from 'expo-screen-orientation';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getThemeColors, useAppSettings } from '../services/appSettings';
import SystemBars from './SystemBars';

// Colores de las tres métricas
const C_FIT  = '#56718D'; // Condición física (CTL)
const C_FAT  = '#64A9E8'; // Fatiga (ATL)
const C_FORM = '#E8A33D'; // Forma (CTL−ATL)
const BLUE   = '#4A90E2';
const SERIES_COLORS = [C_FIT, C_FAT, C_FORM];

const PAD_L = 46, PAD_R = 12, PAD_T = 10, PAD_B = 24;
const MAX_DAYS = 365;     // tope de 1 año de datos
const MAX_PTS = 160;      // diezmado normal
const MAX_PTS_TODO = 400; // "Todo" muestra todos los puntos diarios
const TIP_W = 190;        // ancho del tooltip de pantalla completa

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function niceStep(range, count) {
  const raw = range / Math.max(1, count);
  const mag = Math.pow(10, Math.floor(Math.log10(raw || 1)));
  const norm = raw / mag;
  return (norm >= 5 ? 10 : norm >= 2 ? 5 : norm >= 1 ? 2 : 1) * mag;
}
function fmtValor(v, conSigno = false) {
  if (v == null) return '—';
  const n = Math.round(v);
  return conSigno && n > 0 ? `+${n}` : `${n}`;
}
function isoWeekKey(d) {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  const week = Math.ceil((((date - yearStart) / 86400000) + 1) / 7);
  return `${date.getUTCFullYear()}-W${String(week).padStart(2, '0')}`;
}
function bucketKeyFor(dayKeyStr, bucket) {
  const d = new Date(dayKeyStr + 'T00:00:00');
  if (bucket === 'semana') return isoWeekKey(d);
  if (bucket === 'mes')    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  return dayKeyStr; // 'todo' y 'dia' => diario
}
// ── Aproximación 1: agrega días en bloques y promedia ctl/atl/form ──
function aggregateByBucket(days, bucket) {
  const map = new Map();
  for (const p of days) {
    const k = bucketKeyFor(p.d, bucket);
    let b = map.get(k);
    if (!b) { b = { ctlS: 0, ctlN: 0, atlS: 0, atlN: 0, formS: 0, formN: 0, last: p.d }; map.set(k, b); }
    b.ctlS += p.ctl;   b.ctlN++;
    b.atlS += p.atl;   b.atlN++;
    b.formS += p.form; b.formN++;
    if (p.d > b.last) b.last = p.d;
  }
  return [...map.entries()]
    .sort((a, b) => (a[0] < b[0] ? -1 : 1))
    .map(([k, b]) => ({
      x: 0,
      ctl:  b.ctlN  ? b.ctlS  / b.ctlN  : 0,
      atl:  b.atlN  ? b.atlS  / b.atlN  : 0,
      form: b.formN ? b.formS / b.formN : 0,
      d: b.last,
    }));
}
// ── Aproximación 2: si aún hay demasiados puntos, fusiona consecutivos promediando ──
function decimate(arr, max) {
  if (arr.length <= max) return arr.map((p, i) => ({ ...p, x: i }));
  const step = Math.ceil(arr.length / max);
  const out = [];
  for (let i = 0; i < arr.length; i += step) {
    const chunk = arr.slice(i, i + step);
    const n = chunk.length;
    out.push({
      x: out.length,
      ctl:  chunk.reduce((s, p) => s + p.ctl, 0)  / n,
      atl:  chunk.reduce((s, p) => s + p.atl, 0)  / n,
      form: chunk.reduce((s, p) => s + p.form, 0) / n,
      d: chunk[chunk.length - 1].d,
    });
  }
  return out;
}
// ── Geometría de la vista ampliada: paths Skia + ys en px precalculados ──
function buildFullGeom(data, width, height) {
  const n = data.length;
  const iw = width - PAD_L - PAD_R;
  const ih = height - PAD_T - PAD_B;
  const vals = data.flatMap(p => [p.ctl, p.atl, p.form]);
  let yMin = Math.min(...vals), yMax = Math.max(...vals);
  if (yMin > 0) yMin = 0;
  if (yMax < 10) yMax = 10;
  const pad = (yMax - yMin) * 0.08; yMin -= pad; yMax += pad;
  const xStep = n > 1 ? iw / (n - 1) : iw;
  const py = (v) => PAD_T + ih - ((v - yMin) / (yMax - yMin || 1)) * ih;
  const ysPx = [
    data.map(p => py(p.ctl)),
    data.map(p => py(p.atl)),
    data.map(p => py(p.form)),
  ];
  const paths = [0, 1, 2].map(s => {
    const p = Skia.Path.Make();
    let started = false;
    for (let i = 0; i < n; i++) {
      const X = PAD_L + i * xStep;
      const Y = ysPx[s][i];
      if (!started) { p.moveTo(X, Y); started = true; } else p.lineTo(X, Y);
    }
    return p;
  });
  const yStep = niceStep(yMax - yMin, 4);
  const yTicks = [];
  for (let v = Math.ceil(yMin / yStep) * yStep; v <= yMax; v += yStep) yTicks.push({ v, y: py(v) });
  return { n, xStep, ysPx, paths, yTicks, ih };
}
// ── Marco ESTÁTICO memoizado: NO se re-pinta al arrastrar (movimiento fluido) ──
const FitnessFrame = React.memo(({ geom, width, height, gridColor = 'rgba(143,168,200,0.14)', axisColor = 'rgba(143,168,200,0.25)', labelColor = '#8FA8C8' }) => (
  <View style={{ width, height }} pointerEvents="none">
    {geom.yTicks.map((t, i) => (
      <React.Fragment key={`y${i}`}>
        <View pointerEvents="none" style={{ position: 'absolute', left: PAD_L, right: PAD_R, top: t.y, height: 1, backgroundColor: gridColor }} />
        <Text pointerEvents="none" style={{ position: 'absolute', left: 0, width: PAD_L - 8, top: t.y - 7, textAlign: 'right', fontSize: 10, color: labelColor }}>
          {Math.round(t.v)}
        </Text>
      </React.Fragment>
    ))}
    <View pointerEvents="none" style={{ position: 'absolute', left: PAD_L, right: PAD_R, top: height - PAD_B, height: 1, backgroundColor: axisColor }} />
    <Canvas style={{ position: 'absolute', top: 0, left: 0, width, height }} pointerEvents="none">
      {geom.paths.map((p, i) => (
        <Path key={i} path={p} color={SERIES_COLORS[i]} strokeWidth={1.6} style="stroke" />
      ))}
    </Canvas>
  </View>
));
// ── Vista ampliada: marco memoizado + marcador ligero por encima ──
function FullFitnessChart({ data, onClose, L, theme }) {
  const insets = useSafeAreaInsets();
  const isLight = theme.background === '#F4F7FB';
  const gridColor   = isLight ? 'rgba(21,34,56,0.10)' : 'rgba(143,168,200,0.14)';
  const axisColor   = isLight ? 'rgba(21,34,56,0.28)' : 'rgba(143,168,200,0.25)';
  const markerColor = isLight ? 'rgba(21,34,56,0.5)'  : 'rgba(255,255,255,0.55)';
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [activeIdx, setActiveIdx] = useState(null);
  const geom = useMemo(
    () => (size.w > 0 && size.h > 0 ? buildFullGeom(data, size.w, size.h) : null),
    [data, size.w, size.h]
  );
  const geomRef = useRef(null);
  geomRef.current = geom;
  const pickRef = useRef(() => {});
  pickRef.current = (x) => {
    const g = geomRef.current;
    if (!g) return;
    const idx = Math.round((x - PAD_L) / (g.xStep || 1));
    setActiveIdx(clamp(idx, 0, g.n - 1));
  };
  const handleTouch = (e) => pickRef.current(e.nativeEvent.locationX);
  const pxAt = (i) => PAD_L + i * (geom?.xStep || 0);
  const point = activeIdx != null ? data[activeIdx] : null;
  // Tooltip: a la derecha del dedo; si se sale por el borde derecho, flip a la izquierda
  let tipLeft = 4;
  if (geom && activeIdx != null && size.w > 0) {
    const cand = pxAt(activeIdx) + 12;
    tipLeft = (cand + TIP_W > size.w - 4) ? (pxAt(activeIdx) - 12 - TIP_W) : cand;
    tipLeft = clamp(tipLeft, 4, size.w - TIP_W - 4);
  }
  const fmtDay = (key) => {
    if (!key) return '';
    const d = new Date(key + 'T00:00:00');
    return d.toLocaleDateString(localeSafe(), { day: 'numeric', month: 'short' });
  };
  return (
    <View style={[st.fullWrap, {
      backgroundColor: theme.background,
      paddingTop: Math.max(36, insets.top + 12),
      paddingLeft: 14 + insets.left,
      paddingRight: 14 + insets.right,
      paddingBottom: Math.max(10, insets.bottom),
    }]}>
      <View style={st.fullHeader}>
        <View style={{ flex: 1 }}>
          <Text style={[st.fullTitle, { color: theme.text }]}>{L('Progreso de entrenamiento', 'Training progress')}</Text>
          <Text style={[st.fullSub, { color: theme.muted }]} numberOfLines={1}>
            {point
              ? `${L('Condición', 'Fitness')} ${fmtValor(point.ctl)} · ${L('Fatiga', 'Fatigue')} ${fmtValor(point.atl)} · ${L('Forma', 'Form')} ${fmtValor(point.form, true)}`
              : L('Toca o desliza sobre la gráfica para ver los datos', 'Touch or slide over the chart to see the data')}
          </Text>
        </View>
        <TouchableOpacity onPress={onClose}>
          <Ionicons name="close-circle" size={32} color={theme.muted} />
        </TouchableOpacity>
      </View>
      <View
        style={{ flex: 1 }}
        onLayout={(e) => setSize({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height })}
        onTouchStart={handleTouch}
        onTouchMove={handleTouch}
      >
        {geom && (
          <>
            <FitnessFrame geom={geom} width={size.w} height={size.h} gridColor={gridColor} axisColor={axisColor} labelColor={theme.muted} />
            {activeIdx != null && (
              <>
                <View pointerEvents="none" style={{ position: 'absolute', top: PAD_T, height: geom.ih, left: pxAt(activeIdx) - 0.5, width: 1, backgroundColor: markerColor }} />
                {SERIES_COLORS.map((c, s) => (
                  <View key={s} pointerEvents="none" style={{
                    position: 'absolute',
                    left: pxAt(activeIdx) - 5,
                    top: geom.ysPx[s][activeIdx] - 5,
                    width: 10, height: 10, borderRadius: 5,
                    backgroundColor: c, borderWidth: 2, borderColor: theme.background,
                  }} />
                ))}
                <View pointerEvents="none" style={[st.tip, { left: tipLeft, top: clamp(Math.min(...SERIES_COLORS.map((_, s) => geom.ysPx[s][activeIdx])) - 84, 4, size.h - 96), backgroundColor: isLight ? 'rgba(255,255,255,0.96)' : 'rgba(10,18,32,0.95)', borderColor: theme.border }]}>
                  <View style={st.tipRow}><View style={[st.tipDot, { backgroundColor: C_FIT }]} /><Text style={[st.tipLine, { color: theme.text }]}>{L('Condición', 'Fitness')}: {fmtValor(point.ctl)}</Text></View>
                  <View style={st.tipRow}><View style={[st.tipDot, { backgroundColor: C_FAT }]} /><Text style={[st.tipLine, { color: theme.text }]}>{L('Fatiga', 'Fatigue')}: {fmtValor(point.atl)}</Text></View>
                  <View style={st.tipRow}><View style={[st.tipDot, { backgroundColor: C_FORM }]} /><Text style={[st.tipLine, { color: theme.text }]}>{L('Forma', 'Form')}: {fmtValor(point.form, true)}</Text></View>
                </View>
              </>
            )}
          </>
        )}
      </View>
      {geom && (
        <View style={st.fullXLabels}>
          <Text style={[st.xLabel, { color: theme.muted }]}>{fmtDay(data[0]?.d)}</Text>
          <Text style={[st.xLabel, { color: theme.muted }]}>{fmtDay(data[Math.floor(data.length / 2)]?.d)}</Text>
          <Text style={[st.xLabel, { color: theme.muted }]}>{fmtDay(data[data.length - 1]?.d)}</Text>
        </View>
      )}
    </View>
  );
}
// locale sin import circular: lee el idioma del módulo de ajustes
import { getSettingsSnapshot } from '../services/appSettings';
function localeSafe() { return getSettingsSnapshot().language === 'en' ? 'en-US' : 'es-ES'; }
// ── Tarjeta de métrica: color, valor grande y nombre centrados, sin iconos ──
function StatTile({ label, value, color, filled, theme: providedTheme }) {
  const settings = useAppSettings();
  const theme = providedTheme || getThemeColors(settings.themeMode, useColorScheme());
  const valueColor = color === C_FIT
    ? '#fff'
    : theme.background === '#F4F7FB' && (color === C_FAT || color === C_FORM)
    ? '#7A8798'
      : '#fff';
  return (
    <View
      style={[
        st.tile,
        {
          backgroundColor: filled ? color : color + '1A',
          borderColor: filled ? color : color + '55',
        },
      ]}
    >
      <Text style={[st.tileValue, { color: valueColor }]}>{value}</Text>
      <Text style={[st.tileLabel, { color: filled ? '#fff' : color }]}>{label}</Text>
    </View>
  );
}
export default function FitnessChart({ days, theme: providedTheme }) {
  const settings = useAppSettings();
  const lang = settings.language;            // re-renderiza al cambiar idioma
  const theme = providedTheme || getThemeColors(settings.themeMode, useColorScheme());
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción
  const [bucket, setBucket] = useState('dia');
  const [pickerOpen, setPickerOpen] = useState(false);
  const [fullOpen, setFullOpen] = useState(false);
  const BUCKETS = [
    { key: 'todo',   label: L('Todo', 'All')   },
    { key: 'dia',    label: L('Día', 'Day')    },
    { key: 'semana', label: L('Semana', 'Week') },
    { key: 'mes',    label: L('Mes', 'Month')  },
  ];
  // Serie recortada a 1 año
  const full = useMemo(() => {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - MAX_DAYS);
    const cutKey = `${cutoff.getFullYear()}-${String(cutoff.getMonth() + 1).padStart(2, '0')}-${String(cutoff.getDate()).padStart(2, '0')}`;
    return (days || [])
      .filter(d => d.d >= cutKey)
      .map((d, i) => ({ x: i, ctl: d.ctl ?? 0, atl: d.atl ?? 0, form: d.form ?? 0, d: d.d }));
  }, [days]);
  // Serie que se pinta: agregada por bucket + diezmada si hace falta
  const data = useMemo(() => {
    if (!full.length) return [];
    const agg = aggregateByBucket(full, bucket);
    return decimate(agg, bucket === 'todo' ? MAX_PTS_TODO : MAX_PTS);
  }, [full, bucket]);
  const chart = useMemo(() => {
    if (data.length < 2) return null;
    const vals = data.flatMap(p => [p.ctl, p.atl, p.form]);
    let yMin = Math.min(...vals);
    let yMax = Math.max(...vals);
    if (yMin > 0) yMin = 0;
    if (yMax < 10) yMax = 10;
    const pad = (yMax - yMin) * 0.08;
    return { yMin: yMin - pad, yMax: yMax + pad };
  }, [data]);
  const openFull = async () => {
    setFullOpen(true);
    try { await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_LEFT); } catch (e) {}
  };
  const closeFull = async () => {
    setFullOpen(false);
    try { await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP); } catch (e) {}
  };
  if (!full.length) return null;
  // Los tiles SIEMPRE con el último día real del historial (ya recortado a 1 año)
  const last = full[full.length - 1];
  const mid  = data[Math.floor(data.length / 2)] || last;
  const currentLabel = BUCKETS.find(b => b.key === bucket)?.label || L('Día', 'Day');
  const fmtDay = (key) => {
    if (!key) return '';
    const d = new Date(key + 'T00:00:00');
    return d.toLocaleDateString(localeSafe(), { day: 'numeric', month: 'short' });
  };
  return (
    <View style={[st.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
      {/* Título + desplegable a su derecha */}
      <View style={st.titleRow}>
        <Text style={[st.title, { color: theme.text }]}>{L('Progreso de entrenamiento', 'Training progress')}</Text>
        <TouchableOpacity style={[st.metricBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => setPickerOpen(true)}>
          <Text style={[st.metricText, { color: theme.muted }]}>{currentLabel}</Text>
          <Ionicons name="chevron-expand" size={14} color="#8FA8C8" />
        </TouchableOpacity>
      </View>
      {/* Tres tarjetas de color, textos centrados */}
      <View style={st.tilesRow}>
        <StatTile label={L('Fatiga', 'Fatigue')}     value={fmtValor(last?.atl)}        color={C_FAT}  theme={theme} />
        <StatTile label={L('Condición', 'Fitness')}   value={fmtValor(last?.ctl)}        color={C_FIT}  filled theme={theme} />
        <StatTile label={L('Forma', 'Form')}          value={fmtValor(last?.form, true)} color={C_FORM} theme={theme} />
      </View>
      {/* Gráfica PMC con la serie aproximada */}
      {chart ? (
        <>
          <View style={[st.chartRow, { backgroundColor: theme.card }]}>
            <View style={[st.yAxis, { height: 170 }]}>
              <Text style={[st.yLabel, { color: theme.muted }]}>{Math.round(chart.yMax)}</Text>
              <Text style={[st.yLabel, { color: theme.muted }]}>{Math.round((chart.yMax + chart.yMin) / 2)}</Text>
              <Text style={[st.yLabel, { color: theme.muted }]}>{Math.round(chart.yMin)}</Text>
            </View>
            <View style={[st.chart, { height: 170, backgroundColor: theme.card }]}>
              <CartesianChart
                data={data}
                xKey="x"
                yKeys={['ctl', 'atl', 'form']}
                yDomain={[chart.yMin, chart.yMax]}
              >
                {({ points }) => (
                  <>
                    <Area points={points.ctl}  color={C_FIT}  opacity={0.18} />
                    <Area points={points.atl}  color={C_FAT}  opacity={0.18} />
                    <Area points={points.form} color={C_FORM} opacity={0.15} />
                    <Line points={points.ctl}  color={C_FIT}  strokeWidth={2.2} curve="monotone" />
                    <Line points={points.atl}  color={C_FAT}  strokeWidth={2.2} curve="monotone" />
                    <Line points={points.form} color={C_FORM} strokeWidth={2.2} curve="monotone" />
                  </>
                )}
              </CartesianChart>
            </View>
          </View>
          <View style={st.xLabels}>
            <Text style={[st.xLabel, { color: theme.muted }]}>{fmtDay(data[0]?.d)}</Text>
            <Text style={[st.xLabel, { color: theme.muted }]}>{fmtDay(mid?.d)}</Text>
            <Text style={[st.xLabel, { color: theme.muted }]}>{fmtDay(data[data.length - 1]?.d)}</Text>
          </View>
        </>
      ) : (
        <View style={st.noData}>
          <Text style={st.noDataText}>{L('No hay puntos suficientes para este intervalo.', 'Not enough points for this interval.')}</Text>
        </View>
      )}
      {/* Leyenda + botón de ampliar ABAJO, al lado de "Forma" */}
      <View style={st.legendRow}>
        <View style={st.legend}>
          <View style={st.legendItem}>
            <View style={[st.legendLine, { backgroundColor: C_FIT }]} />
            <Text style={st.legendText}>{L('Fitness', 'Fitness')}</Text>
          </View>
          <View style={st.legendItem}>
            <View style={[st.legendLine, { backgroundColor: C_FAT }]} />
            <Text style={st.legendText}>{L('Fatiga', 'Fatigue')}</Text>
          </View>
          <View style={st.legendItem}>
            <View style={[st.legendLine, { backgroundColor: C_FORM }]} />
            <Text style={st.legendText}>{L('Forma', 'Form')}</Text>
          </View>
        </View>
        <TouchableOpacity style={st.expandBtn} onPress={openFull} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Ionicons name="expand-outline" size={18} color="#8FA8C8" />
        </TouchableOpacity>
      </View>
      {/* Desplegable de bucket */}
      <Modal visible={pickerOpen} transparent animationType="fade" onRequestClose={() => setPickerOpen(false)}>
        <TouchableOpacity style={pk.overlay} activeOpacity={1} onPress={() => setPickerOpen(false)}>
          <View style={[pk.box, { backgroundColor: theme.card }]}>
            {BUCKETS.map(b => (
              <TouchableOpacity
                key={b.key}
                style={[pk.opt, { borderBottomColor: theme.border }, bucket === b.key && [pk.optActive, { backgroundColor: BLUE + '22' }]]}
                onPress={() => { setBucket(b.key); setPickerOpen(false); }}
              >
                <Text style={[pk.optText, { color: theme.text }, bucket === b.key && pk.optTextActive]}>{b.label}</Text>
                {bucket === b.key && <Ionicons name="checkmark" size={16} color={BLUE} />}
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
        <SystemBars />
      </Modal>
      {/* Vista ampliada apaisada */}
      <Modal visible={fullOpen} animationType="fade" transparent={false} onRequestClose={closeFull}>
        {fullOpen && <FullFitnessChart data={data} onClose={closeFull} L={L} theme={theme} />}
        <SystemBars />
      </Modal>
    </View>
  );
}
const st = StyleSheet.create({
  card: {
    margin: 16, marginBottom: 8,
    backgroundColor: '#162032', borderRadius: 14,
    borderWidth: 1, borderColor: '#1E3048', padding: 14,
  },
  titleRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    marginBottom: 12, gap: 8,
  },
  title: { color: '#fff', fontSize: 15, fontWeight: '700', flex: 1 },
  metricBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: '#0D1B2A', borderRadius: 6, borderWidth: 1, borderColor: '#1E3048',
    paddingHorizontal: 10, paddingVertical: 7, gap: 6, minWidth: 92,
  },
  metricText: { color: '#8FA8C8', fontSize: 12, fontWeight: '600', flex: 1, textAlign: 'left' },
  // ── Tarjetas de métricas ──
  tilesRow: { flexDirection: 'row', gap: 8, marginBottom: 14 },
  tile: {
    flex: 1, borderRadius: 12, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
    paddingVertical: 14, paddingHorizontal: 6, gap: 4,
  },
  tileValue: { color: '#fff', fontSize: 24, fontWeight: '800' },
  tileLabel: {
    fontSize: 11, fontWeight: '700', letterSpacing: 0.6,
    textTransform: 'uppercase', textAlign: 'center',
  },
  // ── Gráfica pequeña ──
  chartRow: { flexDirection: 'row', gap: 6 },
  yAxis: { justifyContent: 'space-between', alignItems: 'flex-end', width: 26, paddingVertical: 2 },
  yLabel: { color: '#5A708C', fontSize: 9 },
  chart: { flex: 1 },
  xLabels: { flexDirection: 'row', justifyContent: 'space-between', marginLeft: 32, marginTop: 6 },
  xLabel: { color: '#5A708C', fontSize: 9 },
  noData: { paddingVertical: 30, alignItems: 'center' },
  noDataText: { color: '#4A6080', fontSize: 12 },
  legendRow: { flexDirection: 'row', alignItems: 'center', marginTop: 10 },
  legend: { flex: 1, flexDirection: 'row', justifyContent: 'center', gap: 16 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  legendLine: { width: 14, height: 3, borderRadius: 2 },
  legendText: { color: '#8FA8C8', fontSize: 11 },
  expandBtn: { padding: 6 },
  // ── Vista ampliada ──
  fullWrap: { flex: 1, backgroundColor: '#0A1220', paddingTop: 36, paddingHorizontal: 14, paddingBottom: 10 },
  fullHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  fullTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  fullSub: { color: '#8FA8C8', fontSize: 12, marginTop: 2 },
  fullXLabels: { flexDirection: 'row', justifyContent: 'space-between', marginLeft: 32, marginTop: 6 },
  tip: {
    position: 'absolute', width: TIP_W,
    backgroundColor: 'rgba(10,18,32,0.95)', borderRadius: 6,
    borderWidth: 1, borderColor: '#3A4A63',
    paddingHorizontal: 10, paddingVertical: 7,
  },
  tipRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  tipDot: { width: 8, height: 8, borderRadius: 4 },
  tipLine: { color: '#E8EEF6', fontSize: 12, lineHeight: 18 },
});
const pk = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: '#00000088', justifyContent: 'center', alignItems: 'center' },
  box: { width: '60%', backgroundColor: '#1B1B1D', borderRadius: 10, overflow: 'hidden', paddingVertical: 6 },
  opt: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: '#2A2A2D',
  },
  optActive: { backgroundColor: '#2A4060' },
  optText: { color: '#fff', fontSize: 14 },
  optTextActive: { fontWeight: '700' },
});
