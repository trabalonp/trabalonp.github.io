// components/ActivityChart.js
import React, { useMemo, useRef, useState } from 'react';
import {
  View, Text, StyleSheet, Modal, TouchableOpacity, useColorScheme,
} from 'react-native';
import { Canvas, Path, Skia } from '@shopify/react-native-skia';
import { Ionicons } from '@expo/vector-icons';
import * as ScreenOrientation from 'expo-screen-orientation';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getThemeColors, useAppSettings } from '../services/appSettings';
import SystemBars from './SystemBars';

const PAD_L = 46, PAD_R = 12, PAD_T = 10, PAD_B = 24;
const MAX_PTS = 400;
const SMALL_H = 190;
const TIP_W = 196; // ancho del tooltip (debe coincidir con st.tip.width)

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function decimateIndices(n, max) {
  if (n <= max) return Array.from({ length: n }, (_, i) => i);
  const step = Math.ceil(n / max);
  const idx = [];
  for (let i = 0; i < n; i += step) idx.push(i);
  if (idx[idx.length - 1] !== n - 1) idx.push(n - 1);
  return idx;
}
function niceStep(range, count) {
  const raw = range / Math.max(1, count);
  const mag = Math.pow(10, Math.floor(Math.log10(raw || 1)));
  const norm = raw / mag;
  return (norm >= 5 ? 10 : norm >= 2 ? 5 : norm >= 1 ? 2 : 1) * mag;
}
function fmtDur(sec) {
  if (sec == null || sec < 0) return '—';
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  return h > 0
    ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
    : `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}
function fmtPace(speedKmh) {
  if (!speedKmh || speedKmh <= 0) return '—';
  const pace = 60 / speedKmh;
  const m = Math.floor(pace);
  const s = Math.round((pace - m) * 60);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}
function paceToSpeed(paceStr) {
  if (!paceStr) return null;
  const p = String(paceStr).split(':').map(Number);
  const sec = p.length === 2 ? p[0] * 60 + p[1] : p[0];
  return sec > 0 ? 3600 / sec : null;
}

// ── Geometría + paths (línea continua, sin cortes) ──
function buildGeom(xs, ys, width, height, opts = {}) {
  const xMin = xs[0], xMax = xs[xs.length - 1];
  let pool = ys.filter(v => Number.isFinite(v));
  if (opts.hideZero) pool = pool.filter(v => v > 0);
  if (pool.length < 2) pool = ys.filter(v => Number.isFinite(v));
  let yMin = Math.min(...pool), yMax = Math.max(...pool);
  if (opts.zeroFloor) yMin = Math.min(yMin, 0);
  if (yMax === yMin) { yMax += 1; yMin -= 1; }
  const pad = (yMax - yMin) * 0.08;
  yMin -= pad; yMax += pad;
  const iw = width - PAD_L - PAD_R;
  const ih = height - PAD_T - PAD_B;
  const px = (i) => PAD_L + ((xs[i] - xMin) / (xMax - xMin || 1)) * iw;
  const pyRaw = (v) => PAD_T + ih - ((v - yMin) / (yMax - yMin || 1)) * ih;
  const py = (i) => clamp(pyRaw(ys[i]), PAD_T, PAD_T + ih);
  const pyv = (v) => clamp(pyRaw(v), PAD_T, PAD_T + ih);
  const yStep = niceStep(yMax - yMin, opts.dense ? 5 : 3);
  const yTicks = [];
  for (let v = Math.ceil(yMin / yStep) * yStep; v <= yMax; v += yStep) yTicks.push(v);
  const xCount = opts.dense ? 6 : 3;
  const xTicks = [];
  for (let i = 0; i <= xCount; i++) {
    const v = xMin + ((xMax - xMin) / xCount) * i;
    xTicks.push({ v, px: PAD_L + ((v - xMin) / (xMax - xMin || 1)) * iw });
  }
  const line = Skia.Path.Make();
  const area = Skia.Path.Make();
  let started = false;
  for (let i = 0; i < xs.length; i++) {
    if (!Number.isFinite(ys[i])) continue;
    const X = px(i), Y = py(i);
    if (!started) { line.moveTo(X, Y); area.moveTo(X, Y); started = true; }
    else { line.lineTo(X, Y); area.lineTo(X, Y); }
  }
  if (started) {
    area.lineTo(px(xs.length - 1), PAD_T + ih);
    area.lineTo(px(0), PAD_T + ih);
    area.close();
  }
  return { xMin, xMax, yMin, yMax, iw, ih, px, py, pyv, yTicks, xTicks, line, area };
}

// ── Marco: rejilla, ejes, bandas y canvas estático (memoizado) ──
const ChartFrame = React.memo(({ geom, width, height, color, zones, yFmt, xUnit, gridColor = 'rgba(143,168,200,0.14)', axisColor = 'rgba(143,168,200,0.25)', labelColor = '#8FA8C8' }) => (
  <View style={{ width, height }}>
    {zones?.map((z, i) => {
      const top = geom.pyv(Math.min(z.to, geom.yMax));
      const bot = geom.pyv(Math.max(z.from, geom.yMin));
      if (bot <= PAD_T || top >= height - PAD_B) return null;
      return (
        <View key={i} pointerEvents="none" style={{
          position: 'absolute', left: PAD_L, right: PAD_R, top,
          height: Math.max(0, bot - top), backgroundColor: z.color, opacity: 0.10,
        }} />
      );
    })}
    {geom.yTicks.map((v, i) => (
      <React.Fragment key={`y${i}`}>
        <View pointerEvents="none" style={{
          position: 'absolute', left: PAD_L, right: PAD_R,
          top: geom.pyv(v), height: 1, backgroundColor: gridColor,
        }} />
        <Text pointerEvents="none" style={{
          position: 'absolute', left: 0, width: PAD_L - 8,
          top: geom.pyv(v) - 7, textAlign: 'right', fontSize: 10, color: labelColor,
        }}>{yFmt(v)}</Text>
      </React.Fragment>
    ))}
    {geom.xTicks.map((t, i) => (
      <React.Fragment key={`x${i}`}>
        <View pointerEvents="none" style={{
          position: 'absolute', top: PAD_T, height: geom.ih, left: t.px, width: 1,
          backgroundColor: gridColor,
        }} />
        <Text pointerEvents="none" style={{
          position: 'absolute', bottom: 2,
          left: clamp(t.px - 22, 0, width - 48), width: 48,
          textAlign: 'center', fontSize: 10, color: labelColor,
        }}>{`${Math.round(t.v)} ${xUnit}`}</Text>
      </React.Fragment>
    ))}
    <View pointerEvents="none" style={{
      position: 'absolute', left: PAD_L, right: PAD_R,
      top: height - PAD_B, height: 1, backgroundColor: axisColor,
    }} />
    <Canvas style={{ position: 'absolute', top: 0, left: 0, width, height }} pointerEvents="none">
      <Path path={geom.area} color={color} opacity={0.16} />
      <Path path={geom.line} color={color} strokeWidth={1.4} style="stroke" />
    </Canvas>
  </View>
));

// ── Gráfica pequeña (sin interacción) ──
const SmallCard = React.memo(({ metric, xs, onExpand }) => {
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const isLight = theme.background === '#F4F7FB';
  const [width, setWidth] = useState(0);
  const geom = useMemo(
    () => (width > 0 ? buildGeom(xs, metric.ys, width, SMALL_H, { hideZero: metric.hideZero, zeroFloor: metric.zeroFloor }) : null),
    [xs, metric, width]
  );
  return (
    <View style={[st.card, { backgroundColor: theme.card, borderColor: theme.border }]} onLayout={(e) => setWidth(e.nativeEvent.layout.width)}>
      <View style={st.cardHeader}>
        <Text style={[st.cardTitle, { color: theme.text }]}>{metric.title}</Text>
        <TouchableOpacity onPress={onExpand} style={st.expandBtn} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Ionicons name="expand-outline" size={18} color="#8FA8C8" />
        </TouchableOpacity>
      </View>
      {geom && (
        <ChartFrame geom={geom} width={width} height={SMALL_H} color={metric.color} zones={metric.zones} yFmt={metric.yFmt} xUnit="km" gridColor={isLight ? 'rgba(21,34,56,0.10)' : 'rgba(143,168,200,0.14)'} axisColor={isLight ? 'rgba(21,34,56,0.28)' : 'rgba(143,168,200,0.25)'} labelColor={theme.muted} />
      )}
    </View>
  );
});

// ── Pantalla completa: toque/deslizamiento con dato concreto y tooltip con flip ──
function FullChart({ xs, ys, tSec, color, title, unit, yFmt, zones, onClose }) {
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const insets = useSafeAreaInsets();
  const isLight = theme.background === '#F4F7FB';
  const markerColor = isLight ? 'rgba(21,34,56,0.5)' : 'rgba(255,255,255,0.55)';
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [activeIdx, setActiveIdx] = useState(null);
  const geom = useMemo(
    () => (size.w > 0 && size.h > 0 ? buildGeom(xs, ys, size.w, size.h, { dense: true, hideZero: true }) : null),
    [xs, ys, size.w, size.h]
  );
  const geomRef = useRef(null);
  geomRef.current = geom;
  const pickRef = useRef(() => {});
  pickRef.current = (x) => {
    const g = geomRef.current;
    if (!g) return;
    const xv = g.xMin + ((clamp(x, PAD_L, PAD_L + g.iw) - PAD_L) / g.iw) * (g.xMax - g.xMin);
    let lo = 0, hi = xs.length - 1;
    while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (xs[mid] < xv) lo = mid; else hi = mid; }
    const i = (xv - xs[lo] < xs[hi] - xv) ? lo : hi;
    setActiveIdx(i);
  };
  const handleTouch = (e) => {
    pickRef.current(e.nativeEvent.locationX);
  };

  // ── Posición del tooltip: derecha del dedo; si no cabe, flip a la izquierda ──
  let tipLeft = 4;
  if (geom && activeIdx != null && size.w > 0) {
    const pxv = geom.px(activeIdx);
    let candidate = pxv + 12;                 // intento: a la derecha del dedo
    if (candidate + TIP_W > size.w - 4) {     // si se sale por el borde derecho…
      candidate = pxv - 12 - TIP_W;           // …flip a la izquierda del dedo
    }
    tipLeft = clamp(candidate, 4, size.w - TIP_W - 4);
  }

  return (
    <View style={[st.fullWrap, {
      backgroundColor: theme.background,
      paddingTop: Math.max(36, insets.top + 12),
      paddingLeft: 14 + insets.left,
      paddingRight: 14 + insets.right,
      paddingBottom: Math.max(10, insets.bottom),
    }]}>
      <View style={st.fullHeader}>
        <View style={{ flex: 1 }}>
          <Text style={[st.fullTitle, { color: theme.text }]}>{title}</Text>
          <Text style={[st.fullSub, { color: theme.muted }]} numberOfLines={1}>
            {activeIdx != null
              ? `${yFmt(ys[activeIdx])} ${unit} · ${xs[activeIdx].toFixed(2)} km · ${fmtDur(tSec[activeIdx])}`
              : 'Toca o desliza sobre la gráfica para ver el dato concreto'}
          </Text>
        </View>
        <TouchableOpacity onPress={onClose}>
          <Ionicons name="close-circle" size={32} color={theme.muted} />
        </TouchableOpacity>
      </View>
      <View
        style={{ flex: 1 }}
        onLayout={(e) => setSize({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height })}
        onTouchStart={handleTouch}
        onTouchMove={handleTouch}
      >
        {geom && (
          <>
            <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, width: size.w, height: size.h }}>
              <ChartFrame geom={geom} width={size.w} height={size.h} color={color} zones={zones} yFmt={yFmt} xUnit="km" gridColor={isLight ? 'rgba(21,34,56,0.10)' : 'rgba(143,168,200,0.14)'} axisColor={isLight ? 'rgba(21,34,56,0.28)' : 'rgba(143,168,200,0.25)'} labelColor={theme.muted} />
            </View>
            {activeIdx != null && (
              <>
                <View pointerEvents="none" style={{
                  position: 'absolute', top: PAD_T, height: geom.ih,
                  left: geom.px(activeIdx) - 0.5, width: 1,
                  backgroundColor: markerColor,
                }} />
                <View pointerEvents="none" style={{
                  position: 'absolute',
                  left: geom.px(activeIdx) - 5, top: geom.py(activeIdx) - 5,
                  width: 10, height: 10, borderRadius: 5,
                  backgroundColor: color, borderWidth: 2, borderColor: theme.background,
                }} />
                <View pointerEvents="none" style={[st.tip, {
                  left: tipLeft,
                  top: clamp(geom.py(activeIdx) - 92, 4, size.h - 100),
                  backgroundColor: isLight ? 'rgba(255,255,255,0.96)' : 'rgba(10,18,32,0.95)',
                  borderColor: theme.border,
                }]}>
                  <Text style={[st.tipLine, { color: theme.text }]}>{title}: {yFmt(ys[activeIdx])} {unit}</Text>
                  <Text style={[st.tipLine, { color: theme.text }]}>Distancia: {xs[activeIdx].toFixed(2)} km</Text>
                  <Text style={[st.tipLine, { color: theme.text }]}>Duración: {fmtDur(tSec[activeIdx])}</Text>
                </View>
              </>
            )}
          </>
        )}
      </View>
    </View>
  );
}

// ── Componente público: 5 gráficas + modal apaisado ──
export default function ActivityChart({ registros, cadenceUnit, fcZones, ritmoZones, tipo }) {
  const [fullKey, setFullKey] = useState(null);
  const data = useMemo(() => {
    if (!registros || registros.length < 2) return null;
    const idxs = decimateIndices(registros.length, MAX_PTS);
    const t0 = new Date(registros[idxs[0]].timestamp).getTime();
    return {
      xs:   idxs.map(i => registros[i].distancia),
      tSec: idxs.map(i => (new Date(registros[i].timestamp).getTime() - t0) / 1000),
      alt:  idxs.map(i => registros[i].altitud ?? 0),
      hr:   idxs.map(i => registros[i].frecuencia ?? 0),
      cad:  idxs.map(i => registros[i].cadencia ?? 0),
      pow:  idxs.map(i => registros[i].potencia ?? 0),
      spd:  idxs.map(i => registros[i].velocidad ?? 0),
    };
  }, [registros]);
  const fcBands = useMemo(() => (fcZones || [])
    .filter(z => Number.isFinite(z.min) && Number.isFinite(z.max))
    .map(z => ({ from: z.min, to: z.max, color: '#E05252' })), [fcZones]);
  const paceBands = useMemo(() => (ritmoZones || [])
    .map(z => {
      const s1 = paceToSpeed(z.min), s2 = paceToSpeed(z.max);
      if (!s1 || !s2) return null;
      return { from: Math.min(s1, s2), to: Math.max(s1, s2), color: '#4A90E2' };
    })
    .filter(Boolean), [ritmoZones]);
  const metrics = useMemo(() => (data ? [
    { key: 'alt', title: 'Altitud', unit: 'm', color: '#7BC86C', ys: data.alt, yFmt: (v) => `${Math.round(v * 10) / 10}`, zones: null },
    { key: 'hr', title: 'Frecuencia Cardíaca', unit: 'ppm', color: '#FF7878', ys: data.hr, yFmt: (v) => `${Math.round(v)}`, zones: fcBands },
    { key: 'cad', title: 'Cadencia', unit: cadenceUnit || 'ppm', color: '#E8A33D', ys: data.cad, yFmt: (v) => `${Math.round(v)}`, zones: null },
    { key: 'pow', title: 'Potencia', unit: 'W', color: '#C9CFD6', ys: data.pow, yFmt: (v) => `${Math.round(v)}`, zones: null, zeroFloor: true },
    { key: 'spd', title: tipo === 'Ciclismo' ? 'Velocidad' : 'Ritmo', unit: tipo === 'Ciclismo' ? 'km/h' : '/km', color: '#4A90E2', ys: data.spd, yFmt: tipo === 'Ciclismo' ? ((v) => `${Math.round(v * 10) / 10}`) : fmtPace, zones: tipo === 'Ciclismo' ? null : paceBands, hideZero: true },
  ] : []), [data, fcBands, paceBands, cadenceUnit, tipo]);
  const openFull = async (key) => {
    setFullKey(key);
    try { await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_LEFT); } catch (e) {}
  };
  const closeFull = async () => {
    setFullKey(null);
    try { await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP); } catch (e) {}
  };
  if (!data) return null;
  const fullMetric = metrics.find(m => m.key === fullKey) || null;
  return (
    <View>
      {metrics.map(m => (
        <SmallCard key={m.key} metric={m} xs={data.xs} onExpand={() => openFull(m.key)} />
      ))}
      <Modal visible={!!fullMetric} animationType="fade" transparent={false} onRequestClose={closeFull}>
        {fullMetric && (
          <FullChart
            xs={data.xs}
            ys={fullMetric.ys}
            tSec={data.tSec}
            color={fullMetric.color}
            title={fullMetric.title}
            unit={fullMetric.unit}
            yFmt={fullMetric.yFmt}
            zones={fullMetric.zones}
            onClose={closeFull}
          />
        )}
        <SystemBars />
      </Modal>
    </View>
  );
}

const st = StyleSheet.create({
  card: {
    backgroundColor: '#162032', borderRadius: 12, marginBottom: 14,
    borderWidth: 1, borderColor: '#1E3048', overflow: 'hidden',
  },
  cardHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 12, paddingTop: 10, paddingBottom: 6,
  },
  cardTitle: { color: '#fff', fontSize: 14, fontWeight: '700' },
  expandBtn: { padding: 6 },
  fullWrap: { flex: 1, backgroundColor: '#0A1220', paddingTop: 36, paddingHorizontal: 14, paddingBottom: 10 },
  fullHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  fullTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  fullSub: { color: '#8FA8C8', fontSize: 12, marginTop: 2 },
  tip: {
    position: 'absolute', width: TIP_W,
    backgroundColor: 'rgba(10,18,32,0.95)', borderRadius: 6,
    borderWidth: 1, borderColor: '#3A4A63',
    paddingHorizontal: 10, paddingVertical: 7,
  },
  tipLine: { color: '#E8EEF6', fontSize: 12, lineHeight: 18 },
});
