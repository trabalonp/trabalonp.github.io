// components/WeeklyKmChart.js
import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, ActivityIndicator, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../firebaseConfig';
import { getZonasRitmo, setZonasRitmo, getResumen, setResumen } from '../services/chartCache';
import { getThemeColors, t, useAppSettings, getDayLetters, locale } from '../services/appSettings';
import SystemBars from './SystemBars';

const BLUE='#4A90E2', WHITE='#E8EDF5', CARD='#162032', BORDER='#1E3048', NAVY='#0D1B2A';
const GREEN='#2DB37A', RED='#E05252';
const CHART_H=170;
// Claves internas (no traducidas) para no romper la lógica; la etiqueta sale de t()
const METRIC_KEYS = ['distancia', 'duracion', 'carga', 'resumen'];

function weekRange(offset){
  const now=new Date(); const dayIdx=(now.getDay()+6)%7;
  const monday=new Date(now); monday.setDate(now.getDate()-dayIdx-offset*7); monday.setHours(0,0,0,0);
  const sunday=new Date(monday); sunday.setDate(monday.getDate()+6); sunday.setHours(23,59,59,999);
  return { monday, sunday };
}
const toKey=d=>{const p=n=>String(n).padStart(2,'0');return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`;};
function paceToSec(v){ if(v==null||v==='')return null; if(typeof v==='number')return v; const s=String(v).trim(); const m=s.match(/^(\d+):(\d{1,2})$/); if(m)return parseInt(m[1],10)*60+parseInt(m[2],10); const n=Number(s); return Number.isFinite(n)&&n>0?n:null; }
function fmtHours(h){ if(!h||h<=0)return '0m'; const mins=Math.round(h*60); if(mins<60)return `${mins}m`; return `${Math.floor(mins/60)}h ${mins%60}m`; }
function fmtTimeSec(s){ if(!s||s<=0)return '0s'; const mins=Math.floor(s/60); const sec=Math.round(s%60); if(mins<60)return `${mins}m ${sec}s`; return `${Math.floor(mins/60)}h ${mins%60}m`; }
const pctColor=(p)=> p>=100 ? GREEN : RED;

function findZone(list, sel){
  if(!Array.isArray(list) || sel==null || sel==='') return null;
  const s=String(sel).trim();
  let z=list.find(x=>String(x?.label ?? x?.nombre ?? '').trim()===s);
  if(z) return z;
  const ns=(s.match(/(\d+)/)||[])[1];
  if(ns!=null){
    z=list.find(x=>{ const nl=(String(x?.label ?? x?.nombre ?? '').match(/(\d+)/)||[])[1]; return nl===ns; });
    if(z) return z;
    const n=parseInt(ns,10);
    if(Number.isFinite(n) && list[n-1]) return list[n-1];
  }
  return null;
}
function zoneBoundsPace(z){
  const a=paceToSec(z?.min ?? z?.desde ?? z?.from ?? z?.lo);
  const b=paceToSec(z?.max ?? z?.hasta ?? z?.to ?? z?.hi);
  if(a==null||b==null)return null;
  return { lo:Math.min(a,b), hi:Math.max(a,b) };
}
function zoneLabel(z,i){ return z.label || z.nombre || `R${i}`; }
function resolvePaceSec(step, zones){
  if(step.objetivo==='Ritmo'&&step.objMin&&step.objMax){
    const a=paceToSec(step.objMin), b=paceToSec(step.objMax);
    if(a!=null&&b!=null) return (a+b)/2;
  }
  if(step.objetivo==='Zona ritmo'&&step.objZona){
    const z=findZone(zones, step.objZona);
    if(z){ const b=zoneBoundsPace(z); if(b) return (b.lo+b.hi)/2; }
  }
  return null;
}
function convertKm(val,u){
  if(u==='mi')return val*1.609344; if(u==='m')return val/1000; if(u==='yd')return val*0.0009144; return val;
}
function planStep(step, zones){
  const tipo=step.durTipo||(step.unidad&&['km','m','mi','yd'].includes(step.unidad)?'Distancia':(step.valor!=null&&step.valor!==''?'Tiempo':null));
  const val=Number(step.durValor??step.valor);
  let sec=0, km=0;
  if(Number.isFinite(val)&&val>0){
    if(tipo==='Distancia') km=convertKm(val, step.durUnidad||step.unidad||'km');
    else if(tipo==='Botón de vuelta') km=convertKm(val, step.durUnidad||step.unidad||'m');
    else sec=val*60;
  }
  const pace=resolvePaceSec(step, zones);
  if(km===0&&sec>0&&pace) km=sec/pace;
  if(sec===0&&km>0&&pace) sec=km*pace;
  const reps=Number(step.repeticiones)||1;
  let totSec=sec*reps, totKm=km*reps;
  (step.hijos||[]).forEach(k=>{ const r=planStep(k,zones); totSec+=r.sec*reps; totKm+=r.km*reps; });
  return { sec:totSec, km:totKm };
}
function planOfWorkout(w, zones){
  if(!Array.isArray(w.pasos)||!w.pasos.length) return { sec:0, km:0 };
  let sec=0, km=0;
  w.pasos.forEach(p=>{ const r=planStep(p,zones); sec+=r.sec; km+=r.km; });
  return { sec, km };
}

export default function WeeklyKmChart({ entrenamientos, wellness, weekOffset=0, userId, theme: providedTheme }) {
  const uid = userId || auth.currentUser?.uid;
  const settings = useAppSettings(); // re-renderiza al cambiar idioma/unidades/tema
  const theme = providedTheme || getThemeColors(settings.themeMode, useColorScheme());
  const [metric,setMetric]=useState('distancia');
  const [pickerOpen,setPickerOpen]=useState(false);
  const [zonesRitmo,setZonesRitmoState]=useState(() => getZonasRitmo(userId || auth.currentUser?.uid) || []);
  const [extra,setExtra]=useState(null);
  const [loadingExtra,setLoadingExtra]=useState(false);
  const { monday, sunday } = useMemo(()=>weekRange(weekOffset),[weekOffset]);

  useEffect(()=>{
    if(!uid) return;
    const cached=getZonasRitmo(uid);
    if(cached){ setZonesRitmoState(cached); return; }
    setZonesRitmoState([]);
    (async()=>{ try{
      const s=await getDoc(doc(db,'perfiles',uid));
      if(s.exists()){
        const z=Array.isArray(s.data().zonasRitmo)?s.data().zonasRitmo:[];
        setZonasRitmo(uid, z); setZonesRitmoState(z);
      }
    }catch(e){} })();
  },[uid]);

  const inWeek=(f)=>{ const d=f.toDate?f.toDate():new Date(f); return d>=monday&&d<=sunday; };
  const weekKeys=useMemo(()=>{ const ks=[]; for(let i=0;i<7;i++){ const d=new Date(monday); d.setDate(monday.getDate()+i); ks.push(toKey(d)); } return ks; },[monday]);

  const days=useMemo(()=>{
    const arr=[];
    for(let i=0;i<7;i++){
      const ds=new Date(monday); ds.setDate(monday.getDate()+i);
      const de=new Date(ds); de.setDate(ds.getDate()+1);
      const key=toKey(ds);
      if(metric==='carga'){
        const wd=(wellness&&wellness[key])||null;
        arr.push({ completado: wd?.load??0, planificado: 0 });
        continue;
      }
      const inDay=(entrenamientos||[]).filter(w=>{
        if(!w.fecha)return false; const f=w.fecha.toDate?w.fecha.toDate():new Date(w.fecha);
        return f>=ds&&f<de&&w.tipo!=='Descanso'&&w.tipo!=='Evento';
      });
      let plan=0, compl=0;
      for(const w of inDay){
        const pl=planOfWorkout(w, zonesRitmo);
        if(metric==='distancia'){ plan+=pl.km; if(w.estado==='completo') compl+=(w.distancia||0); }
        else if(metric==='duracion'){ plan+=pl.sec/3600; if(w.estado==='completo') compl+=((w.duracion||0)/3600); }
      }
      arr.push({ completado:compl, planificado:plan });
    }
    return arr;
  },[entrenamientos, wellness, monday, metric, zonesRitmo]);

  const totals=useMemo(()=>({
    completado: days.reduce((s,d)=>s+d.completado,0),
    planificado: days.reduce((s,d)=>s+d.planificado,0),
  }),[days]);
  const pct = totals.planificado>0 ? Math.round((totals.completado/totals.planificado)*100) : null;
  const weekLoad=useMemo(()=>weekKeys.reduce((s,k)=>s+((wellness&&wellness[k]?.load)||0),0),[weekKeys,wellness]);
  const weekSteps=useMemo(()=>weekKeys.reduce((s,k)=>s+((wellness&&wellness[k]?.steps)||0),0),[weekKeys,wellness]);
  const weekRamp=useMemo(()=>{ for(let i=weekKeys.length-1;i>=0;i--){ const r=wellness&&wellness[weekKeys[i]]?.ramp; if(r!=null) return r; } return null; },[weekKeys,wellness]);
  const totalsHora=useMemo(()=>{
    let c=0,p=0;
    (entrenamientos||[]).forEach(w=>{ if(!w.fecha||!inWeek(w.fecha)||w.tipo==='Descanso'||w.tipo==='Evento')return;
      p+=planOfWorkout(w,zonesRitmo).sec/3600; if(w.estado==='completo') c+=(w.duracion||0)/3600; });
    return {c,p};
  },[entrenamientos,monday,sunday,zonesRitmo]);
  const totalsKm=useMemo(()=>{
    let c=0,p=0;
    (entrenamientos||[]).forEach(w=>{ if(!w.fecha||!inWeek(w.fecha)||w.tipo==='Descanso'||w.tipo==='Evento')return;
      p+=planOfWorkout(w,zonesRitmo).km; if(w.estado==='completo') c+=(w.distancia||0); });
    return {c,p};
  },[entrenamientos,monday,sunday,zonesRitmo]);
  const pctHora=totalsHora.p>0?Math.round(totalsHora.c/totalsHora.p*100):null;
  const pctKm=totalsKm.p>0?Math.round(totalsKm.c/totalsKm.p*100):null;

  const weekKey=toKey(monday);
  useEffect(()=>{
    if(metric!=='resumen') return;
    if(!uid) return;
    const cached=getResumen(uid, weekKey);
    if(cached){ setExtra(cached); setLoadingExtra(false); return; }
    if(!zonesRitmo.length){ setExtra({ zoneSec:[], kcal:0, altura:0 }); return; }
    let cancelled=false;
    setLoadingExtra(true);
    (async()=>{
      const bounds=zonesRitmo.map(zoneBoundsPace);
      const slowIdx=bounds.reduce((bi,b,i)=> (b && (!bounds[bi] || b.hi>bounds[bi].hi)) ? i : bi, 0);
      const fastIdx=bounds.reduce((bi,b,i)=> (b && (!bounds[bi] || b.lo<bounds[bi].lo)) ? i : bi, 0);
      const zoneSec=zonesRitmo.map(()=>0);
      let kcal=0, altura=0;
      const completed=(entrenamientos||[]).filter(w=>w.estado==='completo'&&w.fecha&&inWeek(w.fecha)&&w.tipo!=='Descanso'&&w.tipo!=='Evento');
      for(const w of completed){
        try{
          const d=await getDoc(doc(db,'entrenamientos',w.id,'detalles','data'));
          if(d.exists()){ kcal+=(d.data().calorias||0); altura+=(d.data().desnivelPos||0); }
        }catch(e){}
        if(w.tipo==='Running'){
          try{
            const r=await getDoc(doc(db,'entrenamientos',w.id,'registros','data'));
            if(r.exists()){
              const pts=r.data().puntos||[];
              for(let i=1;i<pts.length;i++){
                const v=Number(pts[i].velocidad);
                const dt=(new Date(pts[i].timestamp)-new Date(pts[i-1].timestamp))/1000;
                if(!Number.isFinite(v)||v<=0||dt<=0||dt>120)continue;
                const pace=v>7?3600/v:1000/v;
                let idx=-1;
                for(let zi=0;zi<bounds.length;zi++){ const b=bounds[zi]; if(b&&pace>=b.lo&&pace<=b.hi){ idx=zi; break; } }
                if(idx===-1) idx = pace>(bounds[slowIdx]?.hi??Infinity) ? slowIdx : fastIdx;
                zoneSec[idx]+=dt;
              }
            }
          }catch(e){}
        }
      }
      if(!cancelled){
        const val={ zoneSec, kcal, altura };
        setResumen(uid, weekKey, val);
        setExtra(val);
        setLoadingExtra(false);
      }
    })();
    return ()=>{ cancelled=true; };
  },[metric, weekKey, uid, entrenamientos, zonesRitmo]);

  const step=useMemo(()=>{
    const max=Math.max(...days.map(d=>Math.max(d.completado,d.planificado)),0.01);
    if(max<=0.5)return 0.1; if(max<=5)return 1; if(max<=20)return 5; if(max<=60)return 10; if(max<=200)return 20; return 50;
  },[days]);
  const niceMax=useMemo(()=>{ const max=Math.max(...days.map(d=>Math.max(d.completado,d.planificado)),0.01); return Math.ceil(max/step)*step||step; },[days,step]);
  const ticks=useMemo(()=>{ const t=[]; for(let v=niceMax;v>=0;v-=step)t.push(v); return t; },[niceMax,step]);

  const fmtDistVal=(km)=> settings.units==='imperial' ? `${(km*0.621371).toFixed(2)} mi` : `${(km||0).toFixed(2)} km`;
  const fmtVal=(v)=> metric==='distancia'?fmtDistVal(v): metric==='duracion'?fmtHours(v): `${Math.round(v)}`;
  const zoneTotal=(extra?.zoneSec||[]).reduce((a,b)=>a+b,0);
  const title=weekOffset===0?t('chart.thisWeek'):t('chart.lastWeek');
  const dayLetters=getDayLetters();

  return (
    <View style={[st.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
      <View style={st.titleRow}>
        <Text style={[st.title, { color: theme.text }]}>{title}</Text>
        <TouchableOpacity style={[st.metricBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={()=>setPickerOpen(true)}>
          <Text style={[st.metricText, { color: theme.muted }]}>{t(`chart.metric.${metric}`)}</Text>
          <Ionicons name="chevron-expand" size={14} color="#8FA8C8" />
        </TouchableOpacity>
      </View>

      {metric==='resumen' ? (
        <View>
          <View style={st.resRow}>
            <Text style={[st.resLabel, { color: theme.muted }]}>{t('chart.res.hour')}</Text>
            <Text style={[st.resVal, { color: theme.text }]}>{fmtHours(totalsHora.c)} / {fmtHours(totalsHora.p)}</Text>
            <Text style={[st.resPct,{color:pctHora!=null?pctColor(pctHora):'#8FA8C8'}]}>{pctHora!=null?`${pctHora} %`:'—'}</Text>
          </View>
          <View style={st.resRow}>
            <Text style={[st.resLabel, { color: theme.muted }]}>{t('chart.res.dist')}</Text>
            <Text style={[st.resVal, { color: theme.text }]}>{fmtDistVal(totalsKm.c)} / {fmtDistVal(totalsKm.p)}</Text>
            <Text style={[st.resPct,{color:pctKm!=null?pctColor(pctKm):'#8FA8C8'}]}>{pctKm!=null?`${pctKm} %`:'—'}</Text>
          </View>
          <View style={st.resRow}>
            <Text style={[st.resLabel, { color: theme.muted }]}>{t('chart.res.load')}</Text>
            <Text style={[st.resVal, { color: theme.text }]}>{Math.round(weekLoad)}</Text>
            <Text style={[st.resPct,{color:'#8FA8C8'}]}>—</Text>
          </View>
          <View style={st.resRow}>
            <Text style={[st.resLabel, { color: theme.muted }]}>{t('chart.res.kcal')}</Text>
            <Text style={[st.resVal, { color: theme.text }]}>{loadingExtra?'…':Math.round(extra?.kcal||0)}</Text>
            <Text style={[st.resPct,{color:'#8FA8C8'}]}>—</Text>
          </View>
          <View style={st.resRow}>
            <Text style={[st.resLabel, { color: theme.muted }]}>{t('chart.res.alt')}</Text>
            <Text style={[st.resVal, { color: theme.text }]}>{loadingExtra?'…':`${Math.round(extra?.altura||0)} m`}</Text>
            <Text style={[st.resPct,{color:'#8FA8C8'}]}>—</Text>
          </View>
          <View style={st.resRow}>
            <Text style={[st.resLabel, { color: theme.muted }]}>{t('chart.res.steps')}</Text>
            <Text style={[st.resVal, { color: theme.text }]}>{weekSteps.toLocaleString(locale())}</Text>
            <Text style={[st.resPct,{color:'#8FA8C8'}]}>—</Text>
          </View>
          <View style={st.resRow}>
            <Text style={[st.resLabel, { color: theme.muted }]}>{t('chart.res.ramp')}</Text>
            <Text style={[st.resVal, { color: theme.text }]}>{weekRamp!=null?weekRamp.toFixed(1):'—'}</Text>
            <Text style={[st.resPct,{color:'#8FA8C8'}]}>—</Text>
          </View>
          <Text style={[st.zonesTitle, { color: theme.muted }]}>{t('chart.zonesTitle')}</Text>
          {loadingExtra ? (<ActivityIndicator color={BLUE} style={{marginVertical:10}} />) : (
            (extra?.zoneSec||[]).map((sec,i)=>{
              const p=zoneTotal>0?Math.round((sec/zoneTotal)*100):0;
              return (
                <View key={i} style={[st.zoneRow, { borderBottomColor: theme.border }]}>
                  <Text style={[st.zoneName, { color: theme.text }]}>{zoneLabel(zonesRitmo[i], i)}</Text>
                  <View style={[st.zoneBarBg, { backgroundColor: theme.input }]}><View style={[st.zoneBar,{width:`${Math.min(p,100)}%`}]} /></View>
                  <Text style={[st.zoneTime, { color: theme.muted }]}>{fmtTimeSec(sec)}</Text>
                  <Text style={[st.zonePct, { color: theme.text }]}>{p}%</Text>
                </View>
              );
            })
          )}
        </View>
      ) : (
        <View>
          <View style={[st.summaryBox, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <View style={st.summaryCol}>
              <Text style={[st.summaryLabel, { color: theme.muted }]}>{t('chart.planned')}</Text>
              <Text style={[st.summaryValue, { color: theme.text }]}>{metric==='carga'?'—':fmtVal(totals.planificado)}</Text>
            </View>
            <View style={st.summaryDivider} />
            <View style={st.summaryCol}>
              <Text style={[st.summaryLabel, { color: theme.muted }]}>{t('chart.completed')}</Text>
              <Text style={[st.summaryValue, { color: theme.text }]}>{fmtVal(totals.completado)}</Text>
              {pct!=null && (<Text style={[st.summaryPct,{color:pctColor(pct)}]}>{pct} %</Text>)}
            </View>
          </View>
          <View style={[st.chartRow, { backgroundColor: theme.card }]}>
            <View style={[st.yAxis,{height:CHART_H}]}>
              {ticks.map(v=>(<Text key={v} style={[st.yLabel, { color: theme.muted }]}>{metric==='distancia'?v.toFixed(0):v}</Text>))}
            </View>
            <View style={[st.chartArea,{height:CHART_H, backgroundColor: theme.card}]}>
              {ticks.map((v,i)=>(<View key={i} style={[st.gridLine,{top:(i/Math.max(ticks.length-1,1))*CHART_H}]} />))}
              <View style={st.barsRow}>
                {days.map((d,i)=>(
                  <View key={i} style={st.barCol}>
                    <View style={[st.barWhite,{height:(d.planificado/niceMax)*CHART_H}]} />
                    <View style={[st.barBlue,{height:(d.completado/niceMax)*CHART_H}]} />
                  </View>
                ))}
              </View>
            </View>
          </View>
          <View style={st.daysRow}>{dayLetters.map((l,i)=>(<Text key={i} style={[st.dayLabel, { color: theme.muted }]}>{l}</Text>))}</View>
          <View style={st.legend}>
            <View style={st.legendItem}><View style={[st.legendBox,{backgroundColor:BLUE}]} /><Text style={[st.legendText, { color: theme.muted }]}>{t('chart.completed')}</Text></View>
            <View style={st.legendItem}><View style={[st.legendBox,{backgroundColor:WHITE,borderWidth:1,borderColor:theme.border}]} /><Text style={[st.legendText, { color: theme.muted }]}>{t('chart.planned')}</Text></View>
          </View>
        </View>
      )}

      <Modal visible={pickerOpen} transparent animationType="fade" onRequestClose={()=>setPickerOpen(false)}>
        <TouchableOpacity style={[pk.overlay,{backgroundColor:theme.overlay}]} activeOpacity={1} onPress={()=>setPickerOpen(false)}>
          <View style={[pk.box,{backgroundColor:theme.card,borderWidth:1,borderColor:theme.border}]}>
            {METRIC_KEYS.map(m=>(
              <TouchableOpacity key={m} style={[pk.opt,{borderBottomColor:theme.border},metric===m&&[pk.optActive,{backgroundColor:BLUE+'22'}]]} onPress={()=>{setMetric(m);setPickerOpen(false);}}>
                <Text style={[pk.optText,{color:metric===m?BLUE:theme.text},metric===m&&pk.optTextActive]}>{t(`chart.metric.${m}`)}</Text>
                {metric===m&&<Ionicons name="checkmark" size={18} color={BLUE} />}
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
        <SystemBars />
      </Modal>
    </View>
  );
}

const st=StyleSheet.create({
  card:{margin:16,marginBottom:8,backgroundColor:CARD,borderRadius:14,borderWidth:1,borderColor:BORDER,padding:14},
  titleRow:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:10},
  title:{color:'#fff',fontSize:15,fontWeight:'700'},
  metricBtn:{flexDirection:'row',alignItems:'center',gap:4,paddingHorizontal:8,paddingVertical:4,borderRadius:6,backgroundColor:NAVY,borderWidth:1,borderColor:BORDER},
  metricText:{color:'#8FA8C8',fontSize:12,fontWeight:'600'},
  summaryBox:{flexDirection:'row',borderWidth:1,borderColor:BORDER,borderRadius:10,backgroundColor:'#0A1220',paddingVertical:12,marginBottom:14},
  summaryCol:{flex:1,alignItems:'center'},
  summaryDivider:{width:1,backgroundColor:BORDER},
  summaryLabel:{color:'#8FA8C8',fontSize:12},
  summaryValue:{color:'#fff',fontSize:18,fontWeight:'800',marginTop:4},
  summaryPct:{fontSize:11,fontWeight:'700',marginTop:2},
  chartRow:{flexDirection:'row',gap:6},
  yAxis:{justifyContent:'space-between',alignItems:'flex-end',width:26,paddingVertical:2},
  yLabel:{color:'#5A708C',fontSize:9},
  chartArea:{flex:1,position:'relative'},
  gridLine:{position:'absolute',left:0,right:0,height:1,backgroundColor:'rgba(143,168,200,0.12)'},
  barsRow:{position:'absolute',top:0,bottom:0,left:0,right:0,flexDirection:'row'},
  barCol:{flex:1,position:'relative'},
  barWhite:{position:'absolute',bottom:0,left:'24%',right:'24%',backgroundColor:WHITE,borderRadius:2},
  barBlue:{position:'absolute',bottom:0,left:'24%',right:'24%',backgroundColor:BLUE,borderRadius:2},
  daysRow:{flexDirection:'row',marginLeft:32,marginTop:6},
  dayLabel:{flex:1,textAlign:'center',color:'#5A708C',fontSize:9},
  legend:{flexDirection:'row',justifyContent:'center',gap:18,marginTop:10},
  legendItem:{flexDirection:'row',alignItems:'center',gap:6},
  legendBox:{width:12,height:12,borderRadius:2},
  legendText:{color:'#8FA8C8',fontSize:11},
  resRow:{flexDirection:'row',alignItems:'center',paddingVertical:8,borderBottomWidth:1,borderBottomColor:BORDER},
  resLabel:{color:'#8FA8C8',fontSize:13,width:56},
  resVal:{color:'#fff',fontSize:14,fontWeight:'700',flex:1},
  resPct:{fontSize:12,fontWeight:'700',width:60,textAlign:'right'},
  zonesTitle:{color:'#8FA8C8',fontSize:12,fontWeight:'700',marginTop:12,marginBottom:6},
  zoneRow:{flexDirection:'row',alignItems:'center',gap:8,marginBottom:6},
  zoneName:{color:'#fff',fontSize:11,fontWeight:'700',width:30},
  zoneBarBg:{flex:1,height:8,borderRadius:4,backgroundColor:'#0A1220',overflow:'hidden'},
  zoneBar:{height:8,borderRadius:4,backgroundColor:GREEN},
  zoneTime:{color:'#8FA8C8',fontSize:11,width:52,textAlign:'right'},
  zonePct:{color:'#fff',fontSize:11,fontWeight:'700',width:40,textAlign:'right'},
});
const pk=StyleSheet.create({
  overlay:{flex:1,backgroundColor:'#00000088',justifyContent:'center',alignItems:'center'},
  box:{width:'70%',backgroundColor:'#1B1B1D',borderRadius:10,overflow:'hidden',paddingVertical:6},
  opt:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingHorizontal:16,paddingVertical:14,borderBottomWidth:1,borderBottomColor:'#2A2A2D'},
  optActive:{backgroundColor:'#2A4060'},
  optText:{color:'#fff',fontSize:14},
  optTextActive:{fontWeight:'700'},
});
