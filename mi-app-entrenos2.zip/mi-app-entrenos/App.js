// App.js
import React, { useEffect, useState } from 'react';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { onAuthStateChanged } from 'firebase/auth';
import { Ionicons } from '@expo/vector-icons';
import { auth, db } from './firebaseConfig';
import { doc, setDoc } from 'firebase/firestore';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import {
  View,
  ActivityIndicator,
  StyleSheet,
  Alert,
  Platform,
  Pressable,
  Text,
  useColorScheme,
  StatusBar,
} from 'react-native';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import LoginScreen        from './screens/LoginScreen';
import HomeScreen         from './screens/HomeScreen';
import CalendarScreen     from './screens/CalendarScreen';
import AnalysisScreen     from './screens/AnalysisScreen';
import SettingsScreen     from './screens/SettingsScreen';
import SyncSettingsScreen from './screens/SyncSettingsScreen';
import GarminLoginScreen  from './screens/GarminLoginScreen';
import ProfileScreen      from './screens/ProfileScreen';
import ZonesScreen        from './screens/ZonesScreen';
import DonationScreen     from './screens/DonationScreen';
import CoachScreen        from './screens/CoachScreen';
import AppSettingsScreen  from './screens/AppSettingsScreen';
import SupportScreen      from './screens/SupportScreen';
import SystemBars         from './components/SystemBars';
import { getThemeColors, useAppSettings } from './services/appSettings';

const Stack = createNativeStackNavigator();
const Tab   = createBottomTabNavigator();

const NAVY   = '#0D1B2A';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';

// Tema oscuro: evita fondos blancos por defecto en transiciones y modales
const NAV_THEME = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: NAVY,
    card: NAVY,
  },
};

function EmptyScreen() {
  const settings = useAppSettings();
  const colors = getThemeColors(settings.themeMode, useColorScheme());
  return <View style={{ flex: 1, backgroundColor: colors.background }} />;
}

function MainTabs() {
  const insets = useSafeAreaInsets();
  const settings = useAppSettings();
  const colors = getThemeColors(settings.themeMode, useColorScheme());
  const bottomPad = insets.bottom; // sin botones (iPad home, etc.) => 0 y la barra queda a ras
  const BAR_CONTENT_H = 52; // altura útil de la barra (sin la franja de botones del sistema)
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.tab,
          borderTopColor: colors.border,
          borderTopWidth: 1,
          height: BAR_CONTENT_H + bottomPad,
          paddingBottom: bottomPad,
          paddingTop: 0,
        },
        tabBarActiveTintColor:   BLUE,
        tabBarInactiveTintColor: '#4A6080',
        tabBarShowLabel: false,
        // Caja explícita mayor que el icono: evita recortes del wrapper interno
        // (31x28 dp por defecto) y centra el icono con el mismo aire arriba/abajo.
        tabBarIconStyle: { width: 42, height: 42 },
        // Evita que el Dynamic Type (iPad con texto grande) agrande el glifo
        // fuera de su caja y lo recorte.
        tabBarAllowFontScaling: false,
        // Sin ripple negro al pulsar (feedback solo de opacidad)
        tabBarButton: (props) => (
          <Pressable
            {...props}
            android_ripple={{ color: 'transparent' }}
            style={(state) => [
              props.style,
              { opacity: state.pressed ? 0.55 : 1, backgroundColor: 'transparent' },
            ]}
          />
        ),
        tabBarIcon: ({ color, focused }) => {
          const icons = {
            Dashboard: focused ? 'home'        : 'home-outline',
            Calendar:  focused ? 'calendar'    : 'calendar-outline',
            Analisis:  focused ? 'stats-chart' : 'stats-chart-outline',
            Messages:  focused ? 'chatbubble'  : 'chatbubble-outline',
            Settings:  focused ? 'settings'    : 'settings-outline',
          };
          return (
            <Ionicons
              name={icons[route.name]}
              size={30}
              color={color}
              // lineHeight mayor que el size: en iOS el glifo de la fuente de
              // iconos se recortaba por debajo con lineHeight ajustado.
              // marginTop: pequeño descenso óptico pedido a mano.
              style={{ lineHeight: 38, marginTop: 2 }}
            />
          );
        },
      })}
    >
      <Tab.Screen name="Dashboard" component={HomeScreen}     />
      <Tab.Screen name="Calendar"  component={CalendarScreen} />
      <Tab.Screen name="Analisis"  component={AnalysisScreen} />
      <Tab.Screen name="Messages"  component={EmptyScreen}    />
      <Tab.Screen name="Settings"  component={SettingsScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  const settings = useAppSettings();
  const systemScheme = useColorScheme();
  const colors = getThemeColors(settings.themeMode, systemScheme);
  const [user,    setUser]    = useState(null);
  const [loading, setLoading] = useState(true);

  // Barra negra tras la barra de estado (SystemBars): iconos siempre claros
  useEffect(() => {
    StatusBar.setBarStyle('light-content', true);
    if (Platform.OS === 'android') StatusBar.setBackgroundColor('#000000', true);
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return unsub;
  }, []);

  useEffect(() => {
    if (user) {
      registerForPushNotificationsAsync();
    }
  }, [user]);

  async function registerForPushNotificationsAsync() {
    console.log('📱 Iniciando registro de notificaciones...');
    if (!Device.isDevice) {
      console.log('❌ No es un dispositivo físico');
      return;
    }
    console.log('📱 Dispositivo físico detectado');
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    console.log('🔔 Estado actual de permisos:', existingStatus);
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
      console.log('🔔 Permiso solicitado, resultado:', status);
    }
    if (finalStatus !== 'granted') {
      console.log('❌ Permiso denegado');
      Alert.alert(
        'Permiso requerido',
        'Para recibir notificaciones de sincronización, activa los permisos en Ajustes.'
      );
      return;
    }
    console.log('🔔 Permiso concedido, obteniendo token...');
    try {
      const expoPushToken = (await Notifications.getExpoPushTokenAsync()).data;
      console.log('✅ Token obtenido:', expoPushToken);
      try {
        console.log('💾 Guardando token en Firestore para:', user.uid);
        await setDoc(doc(db, 'perfiles', user.uid), { expoPushToken }, { merge: true });
        console.log('✅ Token guardado correctamente en Firestore');
      } catch (e) {
        console.error('❌ Error al guardar token:', e);
        Alert.alert('Error', 'No se pudo guardar el token de notificaciones: ' + e.message);
      }
    } catch (error) {
      console.error('❌ Error al obtener token:', error);
      Alert.alert('Error', 'No se pudo obtener el token de notificación: ' + error.message);
      return;
    }
    if (Platform.OS === 'android') {
      Notifications.setNotificationChannelAsync('default', {
        name: 'Notificaciones generales',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
      });
    }
  }

  if (loading) {
    return (
      <GestureHandlerRootView style={{ flex: 1 }}>
        <SafeAreaProvider>
          <View style={[styles.splash, { backgroundColor: colors.background }]}>
            <ActivityIndicator size="large" color={BLUE} />
          </View>
          <StatusBar barStyle="light-content" backgroundColor="#000000" translucent={false} />
          <SystemBars />
        </SafeAreaProvider>
      </GestureHandlerRootView>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
        <SafeAreaProvider>
          <NavigationContainer theme={{ ...NAV_THEME, colors: { ...NAV_THEME.colors, background: colors.background, card: colors.card, border: colors.border, text: colors.text, primary: BLUE } }}>
            <StatusBar barStyle="light-content" backgroundColor="#000000" translucent={false} />
          <Stack.Navigator
            screenOptions={{
              headerShown: false,
              contentStyle: { backgroundColor: colors.background },
            }}
          >
            {user ? (
              <Stack.Group>
                <Stack.Screen name="Main"         component={MainTabs}           />
                <Stack.Screen name="SyncSettings" component={SyncSettingsScreen} />
                <Stack.Screen name="GarminLogin"  component={GarminLoginScreen}  />
                <Stack.Screen name="Profile"      component={ProfileScreen}      />
                <Stack.Screen name="Coach"        component={CoachScreen}        />
                <Stack.Screen name="Zones"        component={ZonesScreen}        />
                <Stack.Screen name="Donaciones"   component={DonationScreen}     />
                <Stack.Screen name="AppSettings"  component={AppSettingsScreen}  />
                <Stack.Screen name="Support"      component={SupportScreen}      />
              </Stack.Group>
            ) : (
              <Stack.Screen name="Login" component={LoginScreen} />
            )}
          </Stack.Navigator>
        </NavigationContainer>
        <SystemBars />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  splash: {
    flex: 1,
    backgroundColor: NAVY,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
