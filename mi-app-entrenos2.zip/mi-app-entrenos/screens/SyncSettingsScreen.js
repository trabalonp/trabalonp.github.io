// screens/SyncSettingsScreen.js
import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, Alert, ActivityIndicator, Linking, TextInput,
  useColorScheme,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as FileSystem from 'expo-file-system/legacy';
import { auth } from '../firebaseConfig';
import { getThemeColors, useAppSettings } from '../services/appSettings';
import { resetSyncFolder, syncFitFiles, recalcularEsfuerzos } from '../services/SyncService';
import {
  getIntervalsStatus,
  saveIntervalsCredentials,
  disconnectIntervals,
} from '../services/GarminSyncService';

const { StorageAccessFramework } = FileSystem;

const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const GREEN  = '#2DB37A';
const RED    = '#E05252';
const BORDER = '#1E3048';
const AMBER  = '#F5A623';
const FOLDER_KEY = 'fit_folder_uri';

export default function SyncSettingsScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const appSettings = useAppSettings();
  const lang = appSettings.language;            // re-renderiza al cambiar idioma
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción

  // ── Intervals.icu ──
  const [intStatus, setIntStatus] = useState('unknown'); // unknown | connected | disconnected
  const [athleteName, setAthleteName] = useState(null);
  const [athleteId, setAthleteId] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [saving, setSaving] = useState(false);
  const [disconnecting, setDisconnecting] = useState(false);
  const [checking, setChecking] = useState(true);
  // ── Guías desplegables ──
  const [openGuideInt, setOpenGuideInt] = useState(false);
  const [openGuideFit, setOpenGuideFit] = useState(false);
  // ── Carpeta .fit (plan B) ──
  const [folderUri, setFolderUri] = useState(null);
  const [loadingFolder, setLoadingFolder] = useState(false);
  const [fileCount, setFileCount] = useState(null);
  const [syncingFolder, setSyncingFolder] = useState(false);
  const [folderProgress, setFolderProgress] = useState('');

  // Pasos de las guías, traducidos (dentro del componente para usar L)
  const STEPS_INTERVALS = [
    {
      icon: 'create-outline',
      color: BLUE,
      title: L('Crea tu cuenta en Intervals.icu', 'Create your Intervals.icu account'),
      desc: L('Entra en intervals.icu y crea una cuenta gratuita.', 'Go to intervals.icu and create a free account.'),
    },
    {
      icon: 'download-outline',
      color: GREEN,
      title: L('Activa la descarga desde Garmin', 'Enable downloads from Garmin'),
      desc: L('En Settings → bloque Garmin, marca "Download activities". Tus actividades terminadas bajarán solas desde Garmin Connect.', 'In Settings → Garmin block, tick "Download activities". Your finished activities will download automatically from Garmin Connect.'),
    },
    {
      icon: 'key-outline',
      color: AMBER,
      title: L('Copia tu Athlete ID y tu API key', 'Copy your Athlete ID and API key'),
      desc: L('En Settings → Developer Settings genera tu API key y copia también tu Athlete ID (ej: i12345).', 'In Settings → Developer Settings generate your API key and copy your Athlete ID too (e.g. i12345).'),
    },
    {
      icon: 'link-outline',
      color: BLUE,
      title: L('Pégalos aquí y conecta', 'Paste them here and connect'),
      desc: L('Introduce ambos datos abajo y pulsa "Conectar". La app validará las credenciales y quedará vinculada.', 'Enter both values below and tap "Connect". The app will validate the credentials and link the account.'),
    },
  ];
  const STEPS_FIT = [
    {
      icon: 'download-outline',
      color: AMBER,
      title: L('Descarga el archivo .fit', 'Download the .fit file'),
      desc: L('En connect.garmin.com, abre la actividad y descarga el archivo original (.fit).', 'On connect.garmin.com, open the activity and download the original file (.fit).'),
    },
    {
      icon: 'folder-outline',
      color: BLUE,
      title: L('Colócalo en una carpeta', 'Put it in a folder'),
      desc: L('Mueve el .fit a una carpeta de Descargas (ej: Descargas/Garmin).', 'Move the .fit into a Downloads folder (e.g. Downloads/Garmin).'),
    },
    {
      icon: 'sync-outline',
      color: GREEN,
      title: L('Sincroniza la carpeta aquí', 'Sync the folder here'),
      desc: L('Selecciona la carpeta y pulsa "Sincronizar carpeta ahora". Solo se importarán archivos nuevos.', 'Select the folder and tap "Sync folder now". Only new files will be imported.'),
    },
  ];

  const checkStatus = useCallback(async () => {
    setChecking(true);
    const data = await getIntervalsStatus();
    if (data.connected) {
      setIntStatus('connected');
      setAthleteName(data.athleteName || null);
    } else {
      setIntStatus('disconnected');
      setAthleteName(null);
    }
    setChecking(false);
  }, []);

  useEffect(() => {
    checkStatus();
    AsyncStorage.getItem(FOLDER_KEY).then(uri => {
      if (uri) {
        setFolderUri(uri);
        countFiles(uri);
      }
    });
  }, [checkStatus]);

  const countFiles = async (uri) => {
    try {
      const entries = await StorageAccessFramework.readDirectoryAsync(uri);
      const fits = entries.filter(u => {
        const n = u.toLowerCase();
        return n.endsWith('.fit') || n.includes('.fit%');
      });
      setFileCount(fits.length);
    } catch {
      setFileCount(null);
    }
  };

  // ── Conectar Intervals.icu ──
  const handleConnect = async () => {
    if (!athleteId.trim() || !apiKey.trim()) {
      Alert.alert(L('Faltan datos', 'Missing data'), L('Introduce tu Athlete ID y tu API key de Intervals.icu.', 'Enter your Athlete ID and your Intervals.icu API key.'));
      return;
    }
    setSaving(true);
    try {
      const data = await saveIntervalsCredentials(athleteId.trim(), apiKey.trim());
      setAthleteName(data.athleteName || null);
      setIntStatus('connected');
      setApiKey('');
      Alert.alert(
        L('Conectado', 'Connected'),
        L('Intervals.icu vinculado correctamente', 'Intervals.icu linked successfully') + (data.athleteName ? ` (${data.athleteName})` : '') + '.'
      );
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDisconnect = () => {
    Alert.alert(
      L('Desconectar Intervals.icu', 'Disconnect Intervals.icu'),
      L('¿Seguro que quieres desconectar tu cuenta? Podrás volver a conectarla cuando quieras.', 'Are you sure you want to disconnect? You can reconnect it anytime.'),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Desconectar', 'Disconnect'),
          style: 'destructive',
          onPress: async () => {
            setDisconnecting(true);
            try {
              await disconnectIntervals();
              setIntStatus('disconnected');
              setAthleteName(null);
            } catch (e) {
              Alert.alert(L('Error', 'Error'), e.message);
            } finally {
              setDisconnecting(false);
            }
          },
        },
      ]
    );
  };

  // ── Carpeta .fit ──
  const handleSelectFolder = async () => {
    setLoadingFolder(true);
    try {
      const result = await StorageAccessFramework.requestDirectoryPermissionsAsync();
      if (!result.granted) { setLoadingFolder(false); return; }
      await AsyncStorage.setItem(FOLDER_KEY, result.directoryUri);
      setFolderUri(result.directoryUri);
      await countFiles(result.directoryUri);
      Alert.alert(L('Carpeta guardada', 'Folder saved'), L('La carpeta se ha guardado correctamente.', 'The folder has been saved successfully.'));
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally {
      setLoadingFolder(false);
    }
  };

  const handleResetFolder = () => {
    Alert.alert(L('Borrar carpeta', 'Delete folder'), L('¿Quieres eliminar la carpeta guardada?', 'Do you want to remove the saved folder?'), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      {
        text: L('Borrar', 'Delete'),
        style: 'destructive',
        onPress: async () => {
          await resetSyncFolder();
          setFolderUri(null);
          setFileCount(null);
        },
      },
    ]);
  };

  const handleSyncFolder = async () => {
    const userId = auth.currentUser?.uid;
    if (!userId) return;
    if (!folderUri) {
      Alert.alert(L('Sin carpeta', 'No folder'), L('Selecciona primero una carpeta con archivos .fit.', 'Select a folder with .fit files first.'));
      return;
    }
    setSyncingFolder(true);
    setFolderProgress(L('Preparando…', 'Preparing…'));
    try {
      const result = await syncFitFiles(userId, (msg) => setFolderProgress(msg), lang);
      if (result.cancelled) {
        Alert.alert(L('Cancelado', 'Cancelled'), result.message || L('No hay carpeta configurada.', 'No folder configured.'));
      } else {
        Alert.alert(
          L('Importación completada', 'Import completed'),
          `${result.synced} ${L('nuevos', 'new')} · ${result.skipped} ${L('existentes', 'existing')} · ${result.errors} ${L('errores', 'errors')}`
        );
      }
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally {
      setSyncingFolder(false);
      setFolderProgress('');
    }
  };

  // ── Mantenimiento: recalcular el esfuerzo (TSS) de lo ya guardado ──
  const [recalculando, setRecalculando] = useState(false);
  const [recalculoMsg, setRecalculoMsg] = useState('');
  const handleRecalcularEsfuerzo = () => {
    const userId = auth.currentUser?.uid;
    if (!userId) return;
    Alert.alert(
      L('Recalcular esfuerzo', 'Recalculate effort'),
      L(
        'Vuelve a calcular el esfuerzo (TSS) de tus entrenos guardados usando la duración, la distancia, la FC y tus umbrales de Zonas. No modifica los entrenos sincronizados desde intervals.icu (ésos usan el TSS real de intervals.icu) ni los que hayas editado a mano.',
        'Recalculates the effort (TSS) of your saved workouts using duration, distance, HR and your Zones thresholds. Workouts synced from intervals.icu (which use the real intervals.icu TSS) and manually edited ones are not modified.'
      ),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Recalcular', 'Recalculate'),
          onPress: async () => {
            setRecalculando(true);
            setRecalculoMsg(L('Preparando…', 'Preparing…'));
            try {
              const r = await recalcularEsfuerzos(userId, (msg) => setRecalculoMsg(msg));
              Alert.alert(
                L('Esfuerzo recalculado', 'Effort recalculated'),
                `${r.actualizados} ${L('actualizados', 'updated')} · ${r.intactos} ${L('sin cambios', 'unchanged')} · ${r.sinDatos} ${L('sin datos suficientes', 'not enough data')} · ${r.omitidos} ${L('de intervals.icu (los corrige el servidor)', 'from intervals.icu (fixed by the server)')}`
              );
            } catch (e) {
              Alert.alert(L('Error', 'Error'), e.message);
            } finally {
              setRecalculando(false);
              setRecalculoMsg('');
            }
          },
        },
      ]
    );
  };

  const folderName = folderUri
    ? decodeURIComponent(folderUri.split('%3A').pop().split(':').pop())
    : null;

  return (
    <View style={[s.container, { backgroundColor: theme.background }]}>
      <View style={[s.header, { borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.backBtn}>
          <Ionicons name="chevron-back" size={24} color="#8FA8C8" />
        </TouchableOpacity>
        <Text style={[s.headerTitle, { color: theme.text }]}>{L('Sincronización', 'Sync')}</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={[s.scrollContent, { paddingBottom: Math.max(40, insets.bottom + 16) }]} showsVerticalScrollIndicator={false}>
        {/* ══════════ BLOQUE 1: INTERVALS.ICU ══════════ */}
        <Text style={[s.sectionTitle, { color: theme.text }]}>{L('Sincronización automática (Intervals.icu)', 'Automatic sync (Intervals.icu)')}</Text>
        {intStatus === 'connected' ? (
          <View style={[s.statusCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <View style={s.statusLeft}>
              <Ionicons name="checkmark-circle" size={24} color={GREEN} />
              <View style={{ flex: 1 }}>
                <Text style={[s.statusTitle, { color: theme.text }]}>{L('Intervals.icu conectado', 'Intervals.icu connected')}</Text>
                {athleteName && (
                  <Text style={[s.statusSub, { color: theme.muted }]} numberOfLines={1}>{athleteName}</Text>
                )}
              </View>
            </View>
            <TouchableOpacity onPress={handleDisconnect} style={s.resetBtn} disabled={disconnecting}>
              {disconnecting
                ? <ActivityIndicator size="small" color={RED} />
                : <Ionicons name="trash-outline" size={18} color={RED} />}
            </TouchableOpacity>
          </View>
        ) : (
          <View style={[s.statusCard, { backgroundColor: theme.card }, s.statusCardWarn]}>
            <Ionicons name="warning-outline" size={22} color={AMBER} />
            <Text style={[s.statusWarnText, { color: theme.muted }]}>
              {checking
                ? L('Comprobando conexión…', 'Checking connection…')
                : L('Sin conectar. Sigue los pasos y pega tus datos abajo.', 'Not connected. Follow the steps and paste your details below.')}
            </Text>
          </View>
        )}
        {intStatus !== 'connected' && (
          <>
            <Text style={[s.label, { color: theme.muted }]}>Athlete ID</Text>
            <TextInput
              value={athleteId}
              onChangeText={setAthleteId}
              style={[s.input, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]}
              placeholder="i12345"
              placeholderTextColor="#4A6080"
              autoCapitalize="none"
              autoCorrect={false}
            />
            <Text style={[s.label, { color: theme.muted }]}>API Key</Text>
            <TextInput
              style={[s.input, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]}
              value={apiKey}
              onChangeText={setApiKey}
              placeholder={L('Pega aquí tu API key', 'Paste your API key here')}
              placeholderTextColor="#4A6080"
              autoCapitalize="none"
              autoCorrect={false}
              secureTextEntry
            />
            <TouchableOpacity
              style={[s.primaryBtn, saving && s.disabled]}
              onPress={handleConnect}
              disabled={saving}
              activeOpacity={0.85}
            >
              {saving ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Ionicons name="link-outline" size={20} color="#fff" />
                  <Text style={s.primaryBtnText}>{L('Conectar Intervals.icu', 'Connect Intervals.icu')}</Text>
                </>
              )}
            </TouchableOpacity>
          </>
        )}
        <TouchableOpacity
          style={[s.primaryBtn, { backgroundColor: '#2A4060', marginTop: 8 }]}
          onPress={() => Linking.openURL('https://intervals.icu/settings')}
          activeOpacity={0.85}
        >
          <Ionicons name="globe-outline" size={20} color="#fff" />
          <Text style={s.primaryBtnText}>{L('Abrir ajustes de Intervals.icu', 'Open Intervals.icu settings')}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={s.guideHeader} onPress={() => setOpenGuideInt(v => !v)} activeOpacity={0.8}>
          <Ionicons name="help-circle-outline" size={18} color={BLUE} />
          <Text style={[s.guideTitle, { color: theme.text }]}>{L('¿Cómo funciona Intervals.icu?', 'How does Intervals.icu work?')}</Text>
          <Ionicons name={openGuideInt ? 'chevron-up' : 'chevron-down'} size={18} color={theme.muted} />
        </TouchableOpacity>
        {openGuideInt && STEPS_INTERVALS.map((step, i) => (
          <View key={`int-${i}`} style={[s.stepCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <View style={[s.stepIconWrap, { backgroundColor: step.color + '22', borderColor: step.color }]}>
              <Ionicons name={step.icon} size={20} color={step.color} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[s.stepNum, { color: theme.muted }]}>{L('Paso', 'Step')} {i + 1}</Text>
              <Text style={[s.stepTitle, { color: theme.text }]}>{step.title}</Text>
              <Text style={[s.stepDesc, { color: theme.muted }]}>{step.desc}</Text>
            </View>
          </View>
        ))}

        {/* ══════════ BLOQUE 2: CARPETA .FIT (PLAN B) ══════════ */}
        <Text style={[s.sectionTitle, { marginTop: 24, color: theme.text }]}>{L('Importación manual (archivos .fit)', 'Manual import (.fit files)')}</Text>
        {folderUri ? (
          <View style={[s.statusCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <View style={s.statusLeft}>
              <Ionicons name="folder-open-outline" size={24} color={BLUE} />
              <View style={{ flex: 1 }}>
                <Text style={[s.statusTitle, { color: theme.text }]}>{L('Carpeta configurada', 'Folder configured')}</Text>
                <Text style={[s.statusSub, { color: theme.muted }]} numberOfLines={1}>{folderName}</Text>
                {fileCount != null && (
                  <Text style={[s.statusCount, { color: GREEN }]}>
                    {L(
                      `${fileCount} archivo${fileCount !== 1 ? 's' : ''} .fit en la carpeta`,
                      `${fileCount} .fit file${fileCount !== 1 ? 's' : ''} in the folder`
                    )}
                  </Text>
                )}
              </View>
            </View>
            <TouchableOpacity onPress={handleResetFolder} style={s.resetBtn}>
              <Ionicons name="trash-outline" size={18} color={RED} />
            </TouchableOpacity>
          </View>
        ) : (
          <View style={[s.statusCard, { backgroundColor: theme.card, borderColor: theme.border }, s.statusCardWarn]}>
            <Ionicons name="warning-outline" size={22} color={AMBER} />
            <Text style={[s.statusWarnText, { color: theme.muted }]}>{L('Sin carpeta configurada (opcional).', 'No folder configured (optional).')}</Text>
          </View>
        )}
        <TouchableOpacity
          style={[s.primaryBtn, { backgroundColor: '#2A4060', marginTop: 8 }, loadingFolder && s.disabled]}
          onPress={handleSelectFolder}
          disabled={loadingFolder}
          activeOpacity={0.85}
        >
          {loadingFolder ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <Ionicons name="folder-open-outline" size={20} color="#fff" />
              <Text style={s.primaryBtnText}>
                {folderUri ? L('Cambiar carpeta .fit', 'Change .fit folder') : L('Seleccionar carpeta .fit', 'Select .fit folder')}
              </Text>
            </>
          )}
        </TouchableOpacity>
        <TouchableOpacity
          style={[s.primaryBtn, { backgroundColor: GREEN, marginTop: 8 }, syncingFolder && s.disabled]}
          onPress={handleSyncFolder}
          disabled={syncingFolder || !folderUri}
          activeOpacity={0.85}
        >
          {syncingFolder ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <Ionicons name="sync-outline" size={20} color="#fff" />
              <Text style={s.primaryBtnText}>{L('Sincronizar carpeta ahora', 'Sync folder now')}</Text>
            </>
          )}
        </TouchableOpacity>
        {syncingFolder && !!folderProgress && (
          <View style={[s.progressBox, { backgroundColor: theme.input, borderColor: theme.border }]}>
            <ActivityIndicator size="small" color={BLUE} />
            <Text style={[s.progressText, { color: theme.muted }]} numberOfLines={1}>{folderProgress}</Text>
          </View>
        )}
        {/* ══════════ MANTENIMIENTO: ESFUERZO (TSS) ══════════ */}
        <Text style={[s.sectionTitle, { marginTop: 24, color: theme.text }]}>{L('Esfuerzo (TSS)', 'Effort (TSS)')}</Text>
        <TouchableOpacity
          style={[s.primaryBtn, { backgroundColor: '#2A4060', marginTop: 8 }, recalculando && s.disabled]}
          onPress={handleRecalcularEsfuerzo}
          disabled={recalculando}
          activeOpacity={0.85}
        >
          {recalculando ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <Ionicons name="refresh-outline" size={20} color="#fff" />
              <Text style={s.primaryBtnText}>{L('Recalcular esfuerzo de mis entrenos', 'Recalculate effort of my workouts')}</Text>
            </>
          )}
        </TouchableOpacity>
        {recalculando && !!recalculoMsg && (
          <View style={[s.progressBox, { backgroundColor: theme.input, borderColor: theme.border }]}>
            <ActivityIndicator size="small" color={BLUE} />
            <Text style={[s.progressText, { color: theme.muted }]} numberOfLines={1}>{recalculoMsg}</Text>
          </View>
        )}
        <TouchableOpacity style={s.guideHeader} onPress={() => setOpenGuideFit(v => !v)} activeOpacity={0.8}>
          <Ionicons name="folder-open-outline" size={18} color={GREEN} />
          <Text style={[s.guideTitle, { color: theme.text }]}>{L('Pasos de la importación manual', 'Manual import steps')}</Text>
          <Ionicons name={openGuideFit ? 'chevron-up' : 'chevron-down'} size={18} color={theme.muted} />
        </TouchableOpacity>
        {openGuideFit && STEPS_FIT.map((step, i) => (
          <View key={`fit-${i}`} style={[s.stepCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <View style={[s.stepIconWrap, { backgroundColor: step.color + '22', borderColor: step.color }]}>
              <Ionicons name={step.icon} size={20} color={step.color} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[s.stepNum, { color: theme.muted }]}>{L('Paso', 'Step')} {i + 1}</Text>
              <Text style={[s.stepTitle, { color: theme.text }]}>{step.title}</Text>
              <Text style={[s.stepDesc, { color: theme.muted }]}>{step.desc}</Text>
            </View>
          </View>
        ))}
        <View style={[s.infoBox, { backgroundColor: theme.input, borderColor: theme.border }]}>
          <Ionicons name="information-circle-outline" size={18} color={BLUE} />
          <Text style={[s.infoText, { color: theme.muted }]}>
            {L(
              'La vía recomendada es Intervals.icu: tus actividades de Garmin llegan solas y el botón ↻ del Dashboard las trae a la app. La carpeta .fit es solo un plan B para actividades sueltas que no aparezcan en Intervals.icu.',
              'The recommended way is Intervals.icu: your Garmin activities arrive automatically and the ↻ button on the Dashboard brings them into the app. The .fit folder is only a plan B for isolated activities that do not appear in Intervals.icu.'
            )}
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container:  { flex: 1, backgroundColor: NAVY },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 56, paddingBottom: 14,
    borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  backBtn:     { padding: 4 },
  headerTitle: { color: '#fff', fontSize: 17, fontWeight: '700' },
  scrollContent: { padding: 16, gap: 12, paddingBottom: 40 },
  sectionTitle: { color: '#fff', fontSize: 16, fontWeight: '800', marginTop: 4 },
  // Estado
  statusCard: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: CARD, borderRadius: 12, padding: 16,
    borderWidth: 1, borderColor: GREEN + '60', gap: 12,
  },
  statusCardWarn: { borderColor: AMBER + '60', gap: 10 },
  statusLeft:     { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  statusTitle:    { color: '#fff', fontWeight: '700', fontSize: 14 },
  statusSub:      { color: '#8FA8C8', fontSize: 12, marginTop: 2 },
  statusCount:    { color: GREEN, fontSize: 12, marginTop: 2, fontWeight: '600' },
  statusWarnText: { color: AMBER, fontSize: 13, flex: 1 },
  resetBtn:       { padding: 8 },
  // Formulario
  label: { color: '#8FA8C8', fontSize: 13, marginBottom: 4, marginTop: 4 },
  input: {
    backgroundColor: CARD, borderRadius: 8, borderWidth: 1, borderColor: BORDER,
    padding: 12, color: '#fff', fontSize: 14,
  },
  // Botones
  primaryBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    backgroundColor: BLUE, borderRadius: 12,
    paddingVertical: 16, gap: 10,
  },
  disabled:       { opacity: 0.6 },
  primaryBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  progressBox: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: '#0D2040', borderRadius: 8,
    borderWidth: 1, borderColor: BLUE, paddingHorizontal: 14, paddingVertical: 10,
  },
  progressText: { color: BLUE, fontSize: 13, flex: 1 },
  // Guía
  guideTitle: { color: '#fff', fontSize: 16, fontWeight: '700', flex: 1 },
  guideHeader: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    marginTop: 10, paddingVertical: 10, paddingHorizontal: 4,
  },
  stepCard: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 14,
    backgroundColor: CARD, borderRadius: 12, padding: 14,
    borderWidth: 1, borderColor: BORDER,
  },
  stepIconWrap: {
    width: 44, height: 44, borderRadius: 22, borderWidth: 1.5,
    alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
  stepNum:   { color: '#4A6080', fontSize: 11, fontWeight: '600', marginBottom: 2 },
  stepTitle: { color: '#fff', fontSize: 14, fontWeight: '700', marginBottom: 4 },
  stepDesc:  { color: '#8FA8C8', fontSize: 13, lineHeight: 18 },
  // Info
  infoBox: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 10,
    backgroundColor: BLUE + '15', borderRadius: 10, padding: 14,
    borderWidth: 1, borderColor: BLUE + '40',
  },
  infoText: { color: '#8FA8C8', fontSize: 13, lineHeight: 18, flex: 1 },
});
