// screens/LoginScreen.js
import React, { useRef, useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, Image,
  StyleSheet, ActivityIndicator,
  KeyboardAvoidingView, Platform, ScrollView, useColorScheme, Animated,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFonts } from 'expo-font';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
} from 'firebase/auth';
import { auth } from '../firebaseConfig';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getThemeColors } from '../services/appSettings';

const APP_ICON = require('../assets/images/icon.png');

const BLUE    = '#4A90E2';
const ERROR   = '#E05252';
const GREEN   = '#2DB37A';

const ERRORS = {
  'auth/invalid-email':         'El formato del email no es válido.',
  'auth/wrong-password':        'Contraseña incorrecta. Inténtalo de nuevo.',
  'auth/user-not-found':        'No existe ninguna cuenta con este email.',
  'auth/email-already-in-use':  'Ese email ya tiene una cuenta registrada.',
  'auth/weak-password':         'La contraseña debe tener al menos 6 caracteres.',
  'auth/invalid-credential':    'Email o contraseña incorrectos.',
  'auth/too-many-requests':     'Demasiados intentos. Espera unos minutos.',
  'auth/network-request-failed':'Sin conexión a internet.',
};




// ── Animaciones del logo: en cada toque una aleatoria distinta a la anterior ──
const ANIM_TYPES = ['water', 'bounce', 'spin', 'pulse', 'shake', 'flip', 'jelly', 'float'];
const ANIM_DUR = { water: 750, bounce: 900, spin: 800, pulse: 700, shake: 650, flip: 900, jelly: 800, float: 1100 };

// Construye los transforms de la pegatina según la animación y el driver v (0→1)
function buildTransforms(type, v) {
  const t = [];
  switch (type) {
    case 'water': // ondulación como superficie de agua
      t.push({ rotate: v.interpolate({ inputRange: [0, 0.22, 0.5, 0.78, 1], outputRange: ['-5deg', '-8deg', '-2.5deg', '-6deg', '-5deg'] }) });
      t.push({ scaleX: v.interpolate({ inputRange: [0, 0.22, 0.5, 0.78, 1], outputRange: [1, 1.12, 0.94, 1.04, 1] }) });
      t.push({ scaleY: v.interpolate({ inputRange: [0, 0.22, 0.5, 0.78, 1], outputRange: [1, 0.88, 1.08, 0.96, 1] }) });
      break;
    case 'bounce': // rebote con squash & stretch
      t.push({ translateY: v.interpolate({ inputRange: [0, 0.3, 0.55, 0.75, 0.9, 1], outputRange: [0, -36, 0, -16, 0, 0] }) });
      t.push({ scaleX: v.interpolate({ inputRange: [0, 0.3, 0.55, 0.75, 0.9, 1], outputRange: [1, 0.96, 1.14, 0.97, 1.04, 1] }) });
      t.push({ scaleY: v.interpolate({ inputRange: [0, 0.3, 0.55, 0.75, 0.9, 1], outputRange: [1, 1.06, 0.86, 1.04, 0.96, 1] }) });
      t.push({ rotate: '-5deg' });
      break;
    case 'spin': // vuelta completa con pulso
      t.push({ rotate: v.interpolate({ inputRange: [0, 1], outputRange: ['-5deg', '355deg'] }) });
      t.push({ scale: v.interpolate({ inputRange: [0, 0.5, 1], outputRange: [1, 1.15, 1] }) });
      break;
    case 'pulse': // latido doble
      t.push({ scale: v.interpolate({ inputRange: [0, 0.25, 0.5, 0.75, 1], outputRange: [1, 1.18, 0.95, 1.1, 1] }) });
      t.push({ rotate: '-5deg' });
      break;
    case 'shake': // temblor lateral con balanceo
      t.push({ translateX: v.interpolate({ inputRange: [0, 0.15, 0.35, 0.55, 0.75, 0.9, 1], outputRange: [0, -14, 12, -9, 6, -3, 0] }) });
      t.push({ rotate: v.interpolate({ inputRange: [0, 0.15, 0.35, 0.55, 0.75, 0.9, 1], outputRange: ['-5deg', '-9deg', '-1deg', '-8deg', '-2deg', '-6deg', '-5deg'] }) });
      break;
    case 'flip': // voltereta 3D en Y
      t.push({ perspective: 600 });
      t.push({ rotateY: v.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] }) });
      t.push({ scale: v.interpolate({ inputRange: [0, 0.5, 1], outputRange: [1, 0.88, 1] }) });
      t.push({ rotate: '-5deg' });
      break;
    case 'jelly': // gelatina (skew amortiguado)
      t.push({ skewX: v.interpolate({ inputRange: [0, 0.2, 0.45, 0.7, 1], outputRange: ['0deg', '12deg', '-9deg', '5deg', '0deg'] }) });
      t.push({ scaleY: v.interpolate({ inputRange: [0, 0.2, 0.45, 0.7, 1], outputRange: [1, 0.9, 1.06, 0.97, 1] }) });
      t.push({ rotate: '-5deg' });
      break;
    default: // float: levitación suave con vaivén
      t.push({ translateY: v.interpolate({ inputRange: [0, 0.3, 0.55, 0.8, 1], outputRange: [0, -18, -12, -16, 0] }) });
      t.push({ rotate: v.interpolate({ inputRange: [0, 0.3, 0.55, 0.8, 1], outputRange: ['-5deg', '-2deg', '-7deg', '-3deg', '-5deg'] }) });
  }
  return t;
}

export default function LoginScreen() {
  const insets = useSafeAreaInsets();
  // El login SIGUE SIEMPRE el modo claro/oscuro del dispositivo
  // (aquí aún no se puede elegir tema dentro de la app).
  const systemScheme = useColorScheme();
  const theme = getThemeColors('device', systemScheme);
  const isLight = systemScheme === 'light';
  const accent = isLight ? '#2F6B3A' : '#7BC86C'; // verde del logo, adaptado al tema

  // Fuente manuscrita para el título (OFL, Google Fonts)
  useFonts({ 'Kalam-Bold': require('../assets/fonts/Kalam-Bold.ttf') });

  // ── Toque del logo: animación aleatoria distinta a la anterior ──
  const drv = useRef(new Animated.Value(0)).current;
  const [animType, setAnimType] = useState('water');
  const lastAnim = useRef(null);
  const playRandomAnim = () => {
    let next = ANIM_TYPES[Math.floor(Math.random() * ANIM_TYPES.length)];
    if (next === lastAnim.current) {
      next = ANIM_TYPES[(ANIM_TYPES.indexOf(next) + 1) % ANIM_TYPES.length];
    }
    lastAnim.current = next;
    setAnimType(next);
    drv.setValue(0);
    Animated.timing(drv, { toValue: 1, duration: ANIM_DUR[next], useNativeDriver: true }).start();
  };

  const [email,       setEmail]       = useState('');
  const [password,    setPassword]    = useState('');
  const [loading,     setLoading]     = useState(false);
  const [isNew,       setIsNew]       = useState(false);
  const [error,       setError]       = useState('');
  const [showPass,    setShowPass]    = useState(false);
  const [resetSent,   setResetSent]   = useState(false);

  // El botón principal solo se activa con email y contraseña rellenos
  const canSubmit = email.trim().length > 0 && password.trim().length > 0;

  const handleAuth = async () => {
    setError('');
    if (!email.trim())    { setError('Introduce tu email.'); return; }
    if (!password.trim()) { setError('Introduce tu contraseña.'); return; }

    try {
      setLoading(true);
      if (isNew) {
        await createUserWithEmailAndPassword(auth, email.trim(), password);
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), password);
      }
    } catch (err) {
      setError(ERRORS[err.code] || `Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async () => {
    if (!email.trim()) { setError('Introduce tu email para recuperar la contraseña.'); return; }
    try {
      setLoading(true);
      await sendPasswordResetEmail(auth, email.trim());
      setResetSent(true);
      setError('');
    } catch (err) {
      setError(ERRORS[err.code] || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: theme.background }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        contentContainerStyle={[
          st.container,
          {
            backgroundColor: theme.background,
            paddingTop: Math.max(60, insets.top + 24),
            paddingBottom: Math.max(60, insets.bottom + 24),
          },
        ]}
        keyboardShouldPersistTaps="handled"
      >
        {/* ══════════ ARTWORK: icono + decoraciones + título a mano ══════════ */}
        <View style={st.art}>
          {/* Aros discontinuos girados (pista de atletismo) */}
          <View style={[st.ring,  { borderColor: accent + '59' }]} />
          <View style={[st.ring2, { borderColor: BLUE + '4D' }]} />

          {/* Huellas decorativas en diagonal */}
          <Ionicons name="footsteps" size={26} color={accent + 'B3'} style={st.fp1} />
          <Ionicons name="footsteps" size={20} color={accent + '80'} style={st.fp2} />
          <Ionicons name="footsteps" size={16} color={accent + '59'} style={st.fp3} />

          {/* Destellos */}
          <Ionicons name="sparkles" size={22} color={BLUE}        style={st.sp1} />
          <Ionicons name="sparkles" size={16} color={accent}      style={st.sp2} />

          {/* Líneas de velocidad */}
          <View style={[st.dash, st.dash1, { backgroundColor: BLUE + 'AA' }]} />
          <View style={[st.dash, st.dash2, { backgroundColor: accent + '99' }]} />
          <View style={[st.dash, st.dash3, { backgroundColor: BLUE + '66' }]} />

          {/* Puntitos de confeti */}
          <View style={[st.dot, st.dot1, { backgroundColor: accent }]} />
          <View style={[st.dot, st.dot2, { backgroundColor: BLUE }]} />
          <View style={[st.dot, st.dot3, { backgroundColor: accent + '88' }]} />

          {/* Pegatina blanca con el icono: ondula al tocar el área */}
          <Animated.View
            style={[
              st.sticker,
              { borderColor: theme.border },
              { transform: buildTransforms(animType, drv) },
            ]}
          >
            <Image source={APP_ICON} style={st.icon} resizeMode="contain" />
          </Animated.View>

          {/* Título escrito a mano */}
          <Text style={[st.title, { color: theme.text, fontFamily: 'Kalam-Bold' }]}>
            TEAM JORGE
          </Text>

          {/* Subrayado a mano alzada */}
          <View style={[st.underline,  { backgroundColor: accent }]} />
          <View style={[st.underline2, { backgroundColor: accent + '77' }]} />

          {/* Toque de agua: toda el área hace ondular el cuadrado del logo */}
          <TouchableOpacity
            activeOpacity={1}
            onPress={playRandomAnim}
            style={StyleSheet.absoluteFill}
          />
        </View>

        {/* ══════════ FORMULARIO ══════════ */}
        <View style={st.form}>
          {/* Error global */}
          {!!error && (
            <View style={[st.errorBox, { backgroundColor: ERROR + '14', borderColor: ERROR + '55' }]}>
              <Ionicons name="alert-circle" size={16} color={ERROR} />
              <Text style={st.errorText}>{error}</Text>
            </View>
          )}

          {/* Reset enviado */}
          {resetSent && (
            <View style={[st.successBox, { backgroundColor: GREEN + '14', borderColor: GREEN + '55' }]}>
              <Ionicons name="mail" size={16} color={GREEN} />
              <Text style={st.successText}>
                Email de recuperación enviado. Revisa tu bandeja.
              </Text>
            </View>
          )}

          <Text style={[st.fieldLabel, { color: theme.muted }]}>Correo Electrónico</Text>
          <TextInput
            style={[
              st.input,
              { backgroundColor: theme.input, borderColor: theme.border, color: theme.text },
              !!error && st.inputError,
            ]}
            value={email}
            onChangeText={(v) => { setEmail(v); setError(''); }}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            placeholder="tucorreo@ejemplo.com"
            placeholderTextColor={theme.muted + '99'}
          />

          <Text style={[st.fieldLabel, { color: theme.muted, marginTop: 16 }]}>Contraseña</Text>
          <View style={st.passWrapper}>
            <TextInput
              style={[
                st.input, st.inputPass,
                { backgroundColor: theme.input, borderColor: theme.border, color: theme.text },
                !!error && st.inputError,
              ]}
              value={password}
              onChangeText={(v) => { setPassword(v); setError(''); }}
              secureTextEntry={!showPass}
              placeholder="••••••••"
              placeholderTextColor={theme.muted + '99'}
            />
            <TouchableOpacity
              style={st.eyeBtn}
              onPress={() => setShowPass(!showPass)}
            >
              <Ionicons
                name={showPass ? 'eye-off-outline' : 'eye-outline'}
                size={20}
                color={theme.muted}
              />
            </TouchableOpacity>
          </View>

          {/* Botón principal */}
          <TouchableOpacity
            style={[st.btnPrimary, (loading || !canSubmit) && st.disabled]}
            onPress={handleAuth}
            disabled={loading || !canSubmit}
            activeOpacity={0.85}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={st.btnPrimaryText}>
                {isNew ? 'Registrarse' : 'Inicio de sesión'}
              </Text>
            )}
          </TouchableOpacity>

          {/* Botón secundario */}
          <TouchableOpacity
            style={[st.btnSecondary, { backgroundColor: theme.card }]}
            onPress={() => { setIsNew(!isNew); setError(''); setResetSent(false); }}
            activeOpacity={0.85}
          >
            <Text style={st.btnSecondaryText}>
              {isNew ? 'Inicio de sesión' : 'Registrarse'}
            </Text>
          </TouchableOpacity>

          {/* Recuperar contraseña */}
          {!isNew && (
            <TouchableOpacity onPress={handleReset} style={st.resetBtn}>
              <Text style={st.resetText}>¿Has olvidado tu contraseña?</Text>
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const st = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center', paddingHorizontal: 28, paddingVertical: 60,
  },

  // ── Artwork ──
  art: { alignItems: 'center', marginBottom: 40, marginTop: 4 },
  ring: {
    position: 'absolute', width: 212, height: 212, borderRadius: 106,
    borderWidth: 2, borderStyle: 'dashed', top: -20,
    transform: [{ rotate: '12deg' }],
  },
  ring2: {
    position: 'absolute', width: 252, height: 252, borderRadius: 126,
    borderWidth: 1.5, borderStyle: 'dashed', top: -36,
    transform: [{ rotate: '-9deg' }],
  },
  fp1: { position: 'absolute', top: 8,   right: 24, transform: [{ rotate: '24deg' }] },
  fp2: { position: 'absolute', top: 48,  right: 2,  transform: [{ rotate: '38deg' }] },
  fp3: { position: 'absolute', top: 88,  right: -8, transform: [{ rotate: '52deg' }] },
  sp1: { position: 'absolute', top: -8,  left: 30,  transform: [{ rotate: '-14deg' }] },
  sp2: { position: 'absolute', top: 64,  left: 4,   transform: [{ rotate: '18deg' }] },
  dash:  { position: 'absolute', height: 4, borderRadius: 2, left: -2 },
  dash1: { width: 34, top: 70 },
  dash2: { width: 24, top: 84 },
  dash3: { width: 16, top: 98 },
  dot:  { position: 'absolute', width: 7, height: 7, borderRadius: 4 },
  dot1: { top: 24,  left: 72 },
  dot2: { top: 100, right: 62 },
  dot3: { top: -12, right: 92 },
  sticker: {
    width: 148, height: 148, borderRadius: 30,
    backgroundColor: '#FFFFFF', borderWidth: 1, padding: 10,
    transform: [{ rotate: '-5deg' }],
    elevation: 8,
    shadowColor: '#000', shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.25, shadowRadius: 10,
  },
  icon: { width: '100%', height: '100%' },
  title: {
    marginTop: 20, fontSize: 42, fontWeight: '700',
    letterSpacing: 1, textAlign: 'center',
    transform: [{ rotate: '-2deg' }],
  },
  underline: {
    width: 196, height: 4, borderRadius: 2, marginTop: 8,
    transform: [{ rotate: '-2deg' }],
  },
  underline2: {
    width: 148, height: 3, borderRadius: 2, marginTop: 3, marginLeft: 34,
    transform: [{ rotate: '-1deg' }],
  },

  // ── Formulario ──
  form: { gap: 4 },

  errorBox: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    borderRadius: 10, padding: 12, borderWidth: 1, marginBottom: 12,
  },
  errorText: { color: ERROR, fontSize: 13, flex: 1 },

  successBox: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    borderRadius: 10, padding: 12, borderWidth: 1, marginBottom: 12,
  },
  successText: { color: GREEN, fontSize: 13, flex: 1 },

  fieldLabel: { fontSize: 14, marginBottom: 8 },

  input: {
    borderRadius: 8, paddingHorizontal: 16, paddingVertical: 14,
    fontSize: 15, borderWidth: 1,
  },
  inputError: { borderColor: ERROR },
  passWrapper: { position: 'relative' },
  inputPass:   { paddingRight: 48 },
  eyeBtn: {
    position: 'absolute', right: 14, top: 0, bottom: 0,
    justifyContent: 'center',
  },

  btnPrimary: {
    backgroundColor: BLUE, borderRadius: 8,
    paddingVertical: 16, alignItems: 'center', marginTop: 24,
  },
  disabled:       { opacity: 0.5 },
  btnPrimaryText: { color: '#FFF', fontSize: 16, fontWeight: '700' },

  btnSecondary: {
    borderRadius: 8, borderWidth: 1, borderColor: BLUE,
    paddingVertical: 16, alignItems: 'center', marginTop: 10,
  },
  btnSecondaryText: { color: BLUE, fontSize: 16, fontWeight: '700' },

  resetBtn:  { alignItems: 'flex-start', marginTop: 16 },
  resetText: { color: BLUE, fontSize: 14 },
});
