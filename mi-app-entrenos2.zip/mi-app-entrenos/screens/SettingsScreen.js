// screens/SettingsScreen.js
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import * as Sharing from 'expo-sharing';
import SystemBars from '../components/SystemBars';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { useCallback, useRef, useState } from 'react';
import {
  Alert, Image, Modal,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
  useColorScheme,
} from 'react-native';
import ViewShot from 'react-native-view-shot';
import Svg, {
  Circle, Defs, G, LinearGradient, Path, RadialGradient, Rect, Stop,
  Text as SvgText,
} from 'react-native-svg';
import { useFonts } from 'expo-font';
import { auth, db } from '../firebaseConfig';
import { cacheProfile, getCachedProfile } from '../services/profileCache';
import { getThemeColors, saveSettings, useAppSettings } from '../services/appSettings';

const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';

/* ── Tarjeta compartible: formato artwork 4:5 y paleta de marca (logo) ── */
const APP_ICON  = require('../assets/images/icon.png');
const CARD_W    = 400;   // puntos; se captura con pixelRatio 3 → 1200×1560 px
const CARD_H    = 520;
const GREEN     = '#7BC86C';  // verde claro del logo (tema noche)
const GREEN_DK  = '#2F6B3A';  // verde oscuro del logo
const GREEN_LT  = '#8FE08A';  // verde vivo para el anillo
const INK       = '#0C1310';  // carbón del fondo de la tarjeta

export default function SettingsScreen() {
  const user = auth.currentUser;
  const navigation = useNavigation();
  const shareCardRef = useRef();
  const appSettings = useAppSettings();
  const lang = appSettings.language;            // re-renderiza al cambiar idioma
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  useFonts({ 'Kalam-Bold': require('../assets/fonts/Kalam-Bold.ttf') });
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción

  // Menú con etiquetas traducidas (las claves y el orden no cambian)
  const MENU_ITEMS = [
    { key: 'perfil',     label: L('Perfil', 'Profile'),                 icon: 'person-outline' },
    { key: 'sync',       label: L('Sincronización', 'Sync'),            icon: 'sync-outline' },
    { key: 'zonas',      label: L('Zonas', 'Zones'),                    icon: 'pulse-outline' },
    { key: 'donaciones', label: L('Donaciones', 'Donations'),           icon: 'cafe' },
    { key: 'entrenador', label: L('Mi Entrenador', 'My Coach'),         icon: 'people-outline' },
    { key: 'ajustes',    label: L('Ajustes', 'Settings'), icon: 'options-outline' },
    { key: 'soporte',    label: L('Soporte', 'Support'),                icon: 'help-circle-outline' },
  ];

  /* ── Compartir tarjeta de perfil ── */
  const handleShareProfile = async () => {
    try {
      if (shareCardRef.current) {
        const uri = await shareCardRef.current.capture({
          format: 'png',
          quality: 1,
          pixelRatio: 3,   // 400×520 pt → PNG de 1200×1560 px, nítido al compartir
        });
        await Sharing.shareAsync(uri);
      }
    } catch (e) {
      Alert.alert(L('Error', 'Error'), L('No se pudo compartir la tarjeta', 'Could not share the card'));
    }
  };

  const [athleteId, setAthleteId] = useState(null);
  useFocusEffect(
    useCallback(() => {
      AsyncStorage.getItem('currentAthleteId').then(setAthleteId);
    }, [])
  );

  // Estado local para el switch
  const [notifs, setNotifs] = useState(true);
  const [themePickerOpen, setThemePickerOpen] = useState(false);
  const [profile, setProfile] = useState(null);

  /* ── Obtener perfil desde Firestore y la preferencia de notificaciones ── */
  const fetchProfile = useCallback(async () => {
    if (!user) return;
    const cached = await getCachedProfile(user.uid);
    if (cached) {
      setProfile(cached);
      if (cached.notificacionesActivadas !== undefined) {
        setNotifs(cached.notificacionesActivadas);
      }
      try {
        const snap = await getDoc(doc(db, 'perfiles', user.uid));
        if (snap.exists()) {
          const data = snap.data();
          setProfile(data);
          await cacheProfile(user.uid, data);
          if (data.notificacionesActivadas !== undefined) {
            setNotifs(data.notificacionesActivadas);
          }
        }
      } catch (e) {}
      return;
    }
    try {
      const snap = await getDoc(doc(db, 'perfiles', user.uid));
      if (snap.exists()) {
        const data = snap.data();
        setProfile(data);
        await cacheProfile(user.uid, data);
        if (data.notificacionesActivadas !== undefined) {
          setNotifs(data.notificacionesActivadas);
        }
      } else {
        setProfile(null);
      }
    } catch (e) {
      console.log('Error al cargar perfil:', e);
    }
  }, [user]);

  useFocusEffect(
    useCallback(() => {
      const load = async () => {
        const cached = await getCachedProfile(user.uid);
        if (cached) {
          setProfile(cached);
          if (cached.notificacionesActivadas !== undefined) {
            setNotifs(cached.notificacionesActivadas);
          }
        }
        fetchProfile();
      };
      load();
    }, [fetchProfile])
  );

  const handleToggleNotifs = async (value) => {
    setNotifs(value);
    try {
      await setDoc(doc(db, 'perfiles', user.uid), { notificacionesActivadas: value }, { merge: true });
    } catch (error) {
      Alert.alert(L('Error', 'Error'), L('No se pudo guardar la preferencia de notificaciones', 'Could not save the notification preference'));
      setNotifs(!value);
    }
  };

  const handleMenuItem = (key) => {
    if (key === 'perfil') {
      navigation.navigate('Profile');
      return;
    }
    if (key === 'sync') {
      navigation.navigate('SyncSettings');
      return;
    }
    if (key === 'entrenador') {
      navigation.navigate('Coach');
      return;
    }
    if (key === 'zonas') {
      navigation.navigate('Zones', { athleteId });
      return;
    }
    if (key === 'donaciones') {
      navigation.navigate('Donaciones');
      return;
    }
    if (key === 'ajustes') {
      navigation.navigate('AppSettings'); // ← pantalla de idioma/unidades/fecha
      return;
    }
    if (key === 'soporte') {
      navigation.navigate('Support'); // ← pantalla de soporte (correo a trabalonp@gmail.com)
      return;
    }
    Alert.alert(L('Próximamente', 'Coming soon'), L(`La sección "${key}" estará disponible pronto.`, `The "${key}" section will be available soon.`));
  };

  /* ── Datos para el header ── */
  const profilePhoto = profile?.foto;
  const firstName = profile?.nombre?.trim().split(' ')[0] || user?.displayName || 'Atleta';
  const apellido = profile?.apellido || '';
  const initial = firstName.charAt(0).toUpperCase();
  // El nombre se escala solo si es largo para que nunca se salga del arte
  const nameSize = (s) => ((s || '').length > 12 ? 24 : (s || '').length > 9 ? 28 : 34);

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header con foto / inicial y nombre + email */}
        <View style={styles.header}>
          <View style={styles.avatar}>
            {profilePhoto ? (
              <Image source={{ uri: `data:image/jpeg;base64,${profilePhoto}` }} style={styles.avatarImg} />
            ) : user?.photoURL ? (
              <Image source={{ uri: user.photoURL }} style={styles.avatarImg} />
            ) : (
              <Text style={styles.avatarInitial}>{initial}</Text>
            )}
          </View>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={[styles.userName, { color: theme.text }]}>{firstName}</Text>
              <TouchableOpacity onPress={handleShareProfile} style={{ marginLeft: 8 }}>
                <Ionicons name="share-outline" size={22} color={BLUE} />
              </TouchableOpacity>
            </View>
            <Text style={[styles.userEmail, { color: theme.muted }]}>{user?.email}</Text>
          </View>
        </View>

        {/* Menú */}
        <View style={[styles.menuCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
          {MENU_ITEMS.map((item, index) => (
            <TouchableOpacity
              key={item.key}
              style={[
                styles.menuRow,
                index < MENU_ITEMS.length - 1 && styles.menuRowBorder,
                index < MENU_ITEMS.length - 1 && { borderBottomColor: theme.border },
              ]}
              onPress={() => handleMenuItem(item.key)}
              activeOpacity={0.7}
            >
              <Ionicons name={item.icon} size={20} color={theme.muted} />
              <Text style={[styles.menuLabel, { color: theme.text }]}>{item.label}</Text>
              <Ionicons name="chevron-forward" size={18} color={theme.navText} />
            </TouchableOpacity>
          ))}
        </View>

        {/* Switch de notificaciones funcional */}
        <View style={[styles.menuCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.menuRow}>
            <Ionicons name="notifications-outline" size={20} color={theme.muted} />
            <Text style={[styles.menuLabel, { color: theme.text }]}>{L('Activar Notificaciones', 'Enable Notifications')}</Text>
            <Switch
              value={notifs}
              onValueChange={handleToggleNotifs}
              trackColor={{ false: theme.border, true: BLUE }}
              thumbColor="#fff"
            />
          </View>
          <TouchableOpacity style={styles.menuRow} onPress={() => setThemePickerOpen(true)}>
            <Ionicons name="contrast-outline" size={20} color={BLUE} />
            <Text style={[styles.menuLabel, { color: theme.text }]}>{L('Contraste', 'Contrast')}</Text>
            <Text style={[styles.themeValue, { color: theme.muted }]}>{appSettings.themeMode === 'day' ? L('Día', 'Day') : appSettings.themeMode === 'device' ? L('Dispositivo', 'Device') : L('Noche', 'Night')}</Text>
            <Ionicons name="chevron-forward" size={18} color={theme.navText} />
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Menú desplegable de contraste: usa el tema activo (claro/oscuro) */}
      <Modal visible={themePickerOpen} transparent animationType="fade" onRequestClose={() => setThemePickerOpen(false)}>
        <View style={[styles.overlay, { backgroundColor: theme.overlay }]}>
          <TouchableOpacity style={styles.overlayClose} activeOpacity={1} onPress={() => setThemePickerOpen(false)} />
          <View style={[styles.themePicker, { backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border }]}>
            <Text style={[styles.pickerTitle, { color: theme.muted }]}>{L('Contraste', 'Contrast')}</Text>
            {[
              ['day', L('Día', 'Day')],
              ['night', L('Noche', 'Night')],
              ['device', L('Dispositivo', 'Device')],
            ].map(([value, label]) => {
              const activo = appSettings.themeMode === value;
              return (
                <TouchableOpacity
                  key={value}
                  style={[styles.themeOption, { borderBottomColor: theme.border }, activo && [styles.themeOptionActive, { backgroundColor: BLUE + '22' }]]}
                  onPress={() => { saveSettings({ themeMode: value }); setThemePickerOpen(false); }}
                >
                  <Text style={[styles.themeOptionText, { color: theme.text }, activo && { color: BLUE, fontWeight: '700' }]}>{label}</Text>
                  {activo && <Ionicons name="checkmark-circle" size={18} color={BLUE} />}
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
        <SystemBars />
      </Modal>

      {/* ── TARJETA OCULTA PARA COMPARTIR ──
          El ViewShot mide EXACTAMENTE lo que mide la tarjeta (CARD_W×CARD_H):
          así el PNG sale recortado al arte y sin franjas negras laterales. */}
      <ViewShot
        ref={shareCardRef}
        options={{ format: 'png', quality: 1, pixelRatio: 3 }}
        style={styles.shareCardWrapper}
      >
        <View style={styles.shareCard}>
          {/* ══ FONDO ARTÍSTICO (SVG): degradado carbón→verde, halo bajo la
               foto, carriles de pista, líneas de velocidad, rejilla de
               puntos, rúbrica fantasma vertical, esquinas y viñeta ══ */}
          <Svg width={CARD_W} height={CARD_H} style={styles.shareArt}>
            <Defs>
              <LinearGradient id="tjBg" x1="0" y1="0" x2="1" y2="1">
                <Stop offset="0" stopColor="#12211A" />
                <Stop offset="0.5" stopColor={INK} />
                <Stop offset="1" stopColor="#070B09" />
              </LinearGradient>
              <RadialGradient id="tjGlow" cx="0.5" cy="0.5" r="0.5">
                <Stop offset="0" stopColor="#5FCE73" stopOpacity="0.32" />
                <Stop offset="0.6" stopColor="#3E9B52" stopOpacity="0.12" />
                <Stop offset="1" stopColor="#3E9B52" stopOpacity="0" />
              </RadialGradient>
              <RadialGradient id="tjVig" cx="0.5" cy="0.45" r="0.78">
                <Stop offset="0.55" stopColor="#000000" stopOpacity="0" />
                <Stop offset="1" stopColor="#000000" stopOpacity="0.48" />
              </RadialGradient>
            </Defs>

            <Rect width={CARD_W} height={CARD_H} fill="url(#tjBg)" />
            <Circle cx={CARD_W / 2} cy={210} r={190} fill="url(#tjGlow)" />

            {/* Carriles de pista concéntricos asomando por abajo-derecha */}
            {[70, 102, 134, 166, 198, 230].map((r, i) => (
              <Circle
                key={`pista-${r}`}
                cx={CARD_W + 34} cy={CARD_H + 26} r={r}
                fill="none" stroke={GREEN}
                strokeWidth={i === 2 ? 2 : 1.2}
                strokeOpacity={0.17 - i * 0.02}
                strokeDasharray={i === 4 ? '5 9' : undefined}
              />
            ))}
            {/* Ecos de la misma curva, arriba-izquierda, casi imperceptibles */}
            {[120, 152, 184].map((r, i) => (
              <Circle
                key={`eco-${r}`}
                cx={-34} cy={-24} r={r}
                fill="none" stroke={GREEN} strokeWidth={1}
                strokeOpacity={0.06 + i * 0.02}
              />
            ))}

            {/* Líneas de velocidad diagonales arriba-derecha */}
            <Path d={`M${CARD_W - 96} -8 L${CARD_W - 150} 120`} stroke={GREEN} strokeWidth={2} strokeOpacity={0.30} />
            <Path d={`M${CARD_W - 72} -8 L${CARD_W - 126} 120`} stroke={GREEN} strokeWidth={2} strokeOpacity={0.18} />
            <Path d={`M${CARD_W - 48} -8 L${CARD_W - 102} 120`} stroke={GREEN} strokeWidth={2} strokeOpacity={0.10} />

            {/* Rejilla de puntos (textura) abajo-izquierda */}
            {Array.from({ length: 5 }).map((_, row) =>
              Array.from({ length: 7 }).map((__, col) => (
                <Circle
                  key={`dot-${row}-${col}`}
                  cx={26 + col * 14} cy={CARD_H - 100 + row * 14} r={1.5}
                  fill={GREEN} fillOpacity={0.16}
                />
              ))
            )}

            {/* Rúbrica fantasma vertical con la fuente manuscrita del logo */}
            <G transform={`rotate(-90 36 ${CARD_H / 2})`}>
              <SvgText
                x={36} y={CARD_H / 2}
                fill="#FFFFFF" fillOpacity={0.05}
                fontSize={54} fontFamily="Kalam-Bold" textAnchor="middle"
              >
                TEAM JORGE
              </SvgText>
            </G>

            {/* Esquinas enmarcadas, como passe-partout de galería */}
            <Path d="M16 46 L16 16 L46 16" fill="none" stroke={GREEN} strokeWidth={2.5} strokeOpacity={0.85} />
            <Path
              d={`M${CARD_W - 16} ${CARD_H - 46} L${CARD_W - 16} ${CARD_H - 16} L${CARD_W - 46} ${CARD_H - 16}`}
              fill="none" stroke={GREEN} strokeWidth={2.5} strokeOpacity={0.85}
            />

            <Rect width={CARD_W} height={CARD_H} fill="url(#tjVig)" />
          </Svg>

          {/* ══ CABECERA: pegatina con el logo + firma manuscrita ══ */}
          <View style={styles.shareHeader}>
            <View style={styles.shareLogoSticker}>
              <Image source={APP_ICON} style={styles.shareLogoImg} resizeMode="contain" />
            </View>
            <View>
              <Text style={styles.shareBrand}>TEAM JORGE</Text>
              <View style={styles.shareBrandUnder} />
            </View>
          </View>

          {/* ══ FOTO: aro punteado exterior + anillo verde doble ══ */}
          <View style={styles.shareAvatarWrap}>
            <View style={styles.shareAvatarDashed} />
            <View style={styles.shareAvatarRingOut}>
              <View style={styles.shareAvatarRingIn}>
                {profilePhoto ? (
                  <Image
                    source={{ uri: `data:image/jpeg;base64,${profilePhoto}` }}
                    style={styles.shareAvatarImg}
                  />
                ) : user?.photoURL ? (
                  <Image source={{ uri: user.photoURL }} style={styles.shareAvatarImg} />
                ) : (
                  <View style={[styles.shareAvatarImg, styles.shareAvatarFallback]}>
                    <Text style={styles.shareAvatarInitial}>{initial}</Text>
                  </View>
                )}
              </View>
            </View>
          </View>

          {/* ══ NOMBRE a dos tintas + subrayado a mano ══ */}
          <Text style={[styles.shareName, { fontSize: nameSize(firstName) }]} numberOfLines={1}>
            {firstName}
          </Text>
          {!!apellido && (
            <Text style={[styles.shareLastName, { fontSize: nameSize(apellido) }]} numberOfLines={1}>
              {apellido}
            </Text>
          )}
          <View style={styles.shareUnderline} />
          <View style={styles.shareUnderline2} />
          <Text style={styles.shareTagline}>{L('ATLETA TEAM JORGE', 'TEAM JORGE ATHLETE')}</Text>

          {/* ══ PIE: píldora con el correo ══ */}
          <View style={styles.shareFooter}>
            <View style={styles.shareEmailPill}>
              <Ionicons name="mail-outline" size={12} color="#9DB8A4" />
              <Text style={styles.shareEmailText} numberOfLines={1}>{user?.email}</Text>
            </View>
          </View>
        </View>
      </ViewShot>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 20, paddingTop: 60, paddingBottom: 24, gap: 16,
  },
  avatar: {
    width: 56, height: 56, borderRadius: 28,
    backgroundColor: BLUE, alignItems: 'center', justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarImg:     { width: 56, height: 56 },
  avatarInitial: { color: '#fff', fontSize: 22, fontWeight: '800' },
  userName:      { color: '#fff', fontSize: 18, fontWeight: '700' },
  userEmail:     { color: '#8FA8C8', fontSize: 13, marginTop: 2 },
  menuCard: {
    backgroundColor: CARD, marginHorizontal: 16,
    marginBottom: 12, borderRadius: 12,
    borderWidth: 1, borderColor: BORDER, overflow: 'hidden',
  },
  menuRow: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 16, gap: 14,
  },
  menuRowBorder: { borderBottomWidth: 1, borderBottomColor: BORDER },
  menuLabel: { flex: 1, color: '#fff', fontSize: 15 },
  themeValue: { color: '#8FA8C8', fontSize: 13, marginRight: 4 },
  overlay: { flex: 1, backgroundColor: '#00000088', justifyContent: 'center', alignItems: 'center' },
  overlayClose: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
  themePicker: { width: '80%', backgroundColor: CARD, borderRadius: 12, overflow: 'hidden', paddingVertical: 6 },
  pickerTitle: { color: '#8FA8C8', fontSize: 12, fontWeight: '700', paddingHorizontal: 16, paddingTop: 10, paddingBottom: 6, textTransform: 'uppercase' },
  themeOption: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: BORDER },
  themeOptionActive: { backgroundColor: '#2A4060' },
  themeOptionText: { color: '#fff', fontSize: 14 },
  // ── Tarjeta para compartir: artwork 4:5, se captura tal cual ──
  shareCardWrapper: {
    position: 'absolute',
    top: -1200,                 // fuera de pantalla; ya no sobra ancho alrededor
    left: 0,
    width: CARD_W,
    height: CARD_H,
    backgroundColor: 'transparent',
    overflow: 'hidden',
  },
  shareCard: {
    width: CARD_W,
    height: CARD_H,
    backgroundColor: INK,
    alignItems: 'center',
    overflow: 'hidden',
  },
  shareArt: { position: 'absolute', top: 0, left: 0 },
  shareHeader: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    alignSelf: 'stretch', paddingHorizontal: 28, paddingTop: 28,
  },
  shareLogoSticker: {
    width: 40, height: 40, borderRadius: 10,
    backgroundColor: '#F4F6F2', alignItems: 'center', justifyContent: 'center',
    // leve giro de pegatina colocada a mano
    transform: [{ rotate: '-3deg' }],
    shadowColor: '#000', shadowOpacity: 0.35, shadowRadius: 6, shadowOffset: { width: 0, height: 3 },
  },
  shareLogoImg: { width: 32, height: 32 },
  shareBrand: {
    color: '#F2F5F0', fontSize: 18, fontFamily: 'Kalam-Bold', letterSpacing: 1,
  },
  shareBrandUnder: {
    height: 3, width: 66, backgroundColor: GREEN, borderRadius: 2,
    marginTop: 1, transform: [{ rotate: '-1.5deg' }],
  },
  shareAvatarWrap: {
    width: 172, height: 172, marginTop: 24,
    alignItems: 'center', justifyContent: 'center',
  },
  shareAvatarDashed: {
    position: 'absolute', width: 172, height: 172, borderRadius: 86,
    borderWidth: 1.5, borderStyle: 'dashed', borderColor: GREEN + '59',
  },
  shareAvatarRingOut: {
    width: 148, height: 148, borderRadius: 74,
    backgroundColor: GREEN_LT, borderWidth: 1, borderColor: GREEN_DK,
    alignItems: 'center', justifyContent: 'center',
  },
  shareAvatarRingIn: {
    width: 140, height: 140, borderRadius: 70, backgroundColor: INK,
    alignItems: 'center', justifyContent: 'center',
  },
  shareAvatarImg: { width: 130, height: 130, borderRadius: 65 },
  shareAvatarFallback: { backgroundColor: GREEN_DK, alignItems: 'center', justifyContent: 'center' },
  shareAvatarInitial: { color: '#fff', fontSize: 54, fontWeight: '800', fontFamily: 'Kalam-Bold' },
  shareName: {
    color: '#F5F8F4', fontWeight: '900', letterSpacing: 1.5,
    textTransform: 'uppercase', marginTop: 18,
    maxWidth: CARD_W - 56, textAlign: 'center',
  },
  shareLastName: {
    color: GREEN, fontWeight: '900', letterSpacing: 1.5,
    textTransform: 'uppercase', marginTop: -2,
    maxWidth: CARD_W - 56, textAlign: 'center',
  },
  shareUnderline: {
    height: 4, width: 118, backgroundColor: GREEN, borderRadius: 3,
    marginTop: 10, transform: [{ rotate: '-1.5deg' }],
  },
  shareUnderline2: {
    height: 3, width: 68, backgroundColor: GREEN + '77', borderRadius: 3,
    marginTop: 3, transform: [{ rotate: '-1.5deg' }],
  },
  shareTagline: {
    color: '#9DB8A4', fontSize: 11, fontWeight: '600',
    letterSpacing: 4, marginTop: 12, textTransform: 'uppercase',
  },
  shareFooter: { position: 'absolute', bottom: 26, alignSelf: 'center', maxWidth: CARD_W - 48 },
  shareEmailPill: {
    flexDirection: 'row', alignItems: 'center', gap: 7,
    backgroundColor: '#FFFFFF10', borderWidth: 1, borderColor: '#FFFFFF1A',
    borderRadius: 999, paddingHorizontal: 14, paddingVertical: 7,
  },
  shareEmailText: { color: '#B9CBBE', fontSize: 11.5, letterSpacing: 0.4 },
});
