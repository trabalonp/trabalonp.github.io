// screens/ZonesScreen.js
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import SystemBars from '../components/SystemBars';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  useColorScheme,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { auth, db } from '../firebaseConfig';
import { cacheProfile, getCachedProfile } from '../services/profileCache';
import { getThemeColors, L, useAppSettings } from '../services/appSettings';

const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';
const RED    = '#E05252';
const FC_OPTIONS = [
  ['1', 'Z1 Recuperación'], ['2', 'Z2 Aeróbico'], ['3', 'Z3 Tempo'],
  ['4', 'Z4 SubUmbral'], ['5', 'Z5A SuperUmbral'],
  ['6', 'Z5B Capacidad Aeróbica'], ['7', 'Z5C Capacidad Anaeróbica'],
];
const RITMO_OPTIONS = ['R0', 'R1', 'R1+', 'R2', 'R2+', 'R3', 'R3+', 'R4', 'R4+', 'R5', 'R5+', 'R6'];
const POWER_OPTIONS = ['1', '2', '3', '4', '5', '6'].map(id => [`${id}`, `Z${id}`]);

export default function ZonesScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const insets = useSafeAreaInsets();
  const athleteId = route.params?.athleteId;    // si viene del entrenador
  const user = auth.currentUser;
  const currentUserId = athleteId || user?.uid;
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());

  const [tab, setTab] = useState('FC'); // 'FC', 'Ritmo', 'Potencia'
  const [loading, setLoading] = useState(true);
  const [fcZones, setFcZones] = useState([]);
  const [ritmoZones, setRitmoZones] = useState([]);
  const [potenciaZones, setPotenciaZones] = useState([]);
  const [umbralRitmo, setUmbralRitmo] = useState(''); // min/km para R5
  const [umbralFC, setUmbralFC] = useState('');       // FC máxima (¡no es el umbral!)
  const [fcUmbral, setFcUmbral] = useState('');       // FC umbral (LTHR), para el esfuerzo/hrTSS
  const [umbralPotencia, setUmbralPotencia] = useState('');
  const [zonePickerOpen, setZonePickerOpen] = useState(false);

  // Cargar zonas desde el perfil (caché → Firestore)
  useEffect(() => {
    (async () => {
      const cached = await getCachedProfile(currentUserId);
      if (cached) {
        setFcZones(cached.zonasFC || []);
        setRitmoZones(cached.zonasRitmo || []);
        setPotenciaZones(cached.zonasPotencia || []);
        setUmbralRitmo(cached.umbralRitmo || '');
        setUmbralFC(cached.umbralFC || '');
        setFcUmbral(cached.fcUmbral || '');
        setUmbralPotencia(cached.umbralPotencia || '');
      }
      try {
        const snap = await getDoc(doc(db, 'perfiles', currentUserId));
        if (snap.exists()) {
          const data = snap.data();
          setFcZones(data.zonasFC || []);
          setRitmoZones(data.zonasRitmo || []);
          setPotenciaZones(data.zonasPotencia || []);
          setUmbralRitmo(data.umbralRitmo || '');
          setUmbralFC(data.umbralFC || '');
          setFcUmbral(data.fcUmbral || '');
          setUmbralPotencia(data.umbralPotencia || '');
        }
      } catch (e) {}
      setLoading(false);
    })();
  }, [currentUserId]);

  // Guardar zonas en Firestore y caché
  const saveZones = async () => {
    try {
      const data = {
        zonasFC: fcZones,
        zonasRitmo: ritmoZones,
        zonasPotencia: potenciaZones,
        umbralRitmo,
        umbralFC,
        fcUmbral,
        umbralPotencia,
      };
      await setDoc(doc(db, 'perfiles', currentUserId), data, { merge: true });
      await cacheProfile(currentUserId, { ...data });   // actualiza caché local
      Alert.alert('Guardado', 'Las zonas se han actualizado correctamente.');
    } catch (err) {
      Alert.alert('Error', 'No se pudieron guardar las zonas.');
    }
  };

  const activeZones = tab === 'FC' ? fcZones : tab === 'Ritmo' ? ritmoZones : potenciaZones;
  const zoneOptions = tab === 'FC' ? FC_OPTIONS : tab === 'Ritmo' ? RITMO_OPTIONS.map(label => [label, label]) : POWER_OPTIONS;

  // Añadir exclusivamente una zona que aún no exista.
  const addZone = () => {
    setZonePickerOpen(true);
  };
  const addSelectedZone = (id, label) => {
    if (activeZones.some(z => String(z.id) === String(id) || z.label === label)) {
      setZonePickerOpen(false);
      return;
    }
    const newZone = { id, min: '', max: '', label };
    const nextZones = [...activeZones, newZone].sort((a, b) => {
      const ai = tab === 'Ritmo' ? RITMO_OPTIONS.indexOf(a.label) : Number.parseInt(a.id, 10);
      const bi = tab === 'Ritmo' ? RITMO_OPTIONS.indexOf(b.label) : Number.parseInt(b.id, 10);
      return (ai < 0 ? 999 : ai) - (bi < 0 ? 999 : bi);
    });
    if (tab === 'FC') setFcZones(nextZones);
    else if (tab === 'Ritmo') setRitmoZones(nextZones);
    else setPotenciaZones(nextZones);
    setZonePickerOpen(false);
  };

  // Actualizar un campo de una zona
  const updateZone = (id, field, value) => {
    if (tab === 'FC') {
      setFcZones(fcZones.map(z => z.id === id ? { ...z, [field]: value } : z));
    } else if (tab === 'Ritmo') {
      setRitmoZones(ritmoZones.map(z => z.id === id ? { ...z, [field]: value } : z));
    } else {
      setPotenciaZones(potenciaZones.map(z => z.id === id ? { ...z, [field]: value } : z));
    }
  };

  // Borrar zona: pide confirmación para evitar borrados accidentales.
  // Recibe la zona completa (no sólo el id) para poder nombrarla en el aviso.
  const deleteZone = (zone) => {
    if (!zone) return;
    const id = zone.id;
    const nombre = zone.label || (tab === 'Ritmo' ? String(id) : L(`Zona ${id}`, `Zone ${id}`));
    const pregunta = tab === 'FC'
      ? { es: '¿Quieres eliminar la zona de frecuencia cardíaca', en: 'Do you want to delete the heart rate zone' }
      : tab === 'Ritmo'
        ? { es: '¿Quieres eliminar la zona de ritmo', en: 'Do you want to delete the pace zone' }
        : { es: '¿Quieres eliminar la zona de potencia', en: 'Do you want to delete the power zone' };
    Alert.alert(
      L('Eliminar zona', 'Delete zone'),
      L(`${pregunta.es} "${nombre}"?`, `${pregunta.en} "${nombre}"?`),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Eliminar', 'Delete'),
          style: 'destructive',
          onPress: () => {
            if (tab === 'FC') setFcZones(list => list.filter(item => item.id !== id));
            else if (tab === 'Ritmo') setRitmoZones(list => list.filter(item => item.id !== id));
            else setPotenciaZones(list => list.filter(item => item.id !== id));
          },
        },
      ],
      { cancelable: true }
    );
  };

  // Calcular zonas de FC automáticamente (basado en FC máxima)
  const calcFcZones = () => {
    if (!umbralFC) {
      Alert.alert('Falta FC máxima', 'Introduce tu frecuencia cardíaca máxima.');
      return;
    }
    const max = parseInt(umbralFC);
    const calculated = [
      { id: '1', min: 0, max: Math.round(max * 0.6), label: 'Z1 Recuperación' },
      { id: '2', min: Math.round(max * 0.6), max: Math.round(max * 0.7), label: 'Z2 Aeróbico' },
      { id: '3', min: Math.round(max * 0.7), max: Math.round(max * 0.8), label: 'Z3 Tempo' },
      { id: '4', min: Math.round(max * 0.8), max: Math.round(max * 0.9), label: 'Z4 SubUmbral' },
      { id: '5', min: Math.round(max * 0.9), max: Math.round(max * 0.95), label: 'Z5A SuperUmbral' },
      { id: '6', min: Math.round(max * 0.95), max: Math.round(max * 0.98), label: 'Z5B Capacidad Aeróbica' },
      { id: '7', min: Math.round(max * 0.98), max: max, label: 'Z5C Capacidad Anaeróbica' },
    ];
    setFcZones(fcZones.map(zone => {
      const next = calculated.find(z => String(z.id) === String(zone.id) || z.label === zone.label);
      return next ? { ...zone, min: next.min, max: next.max, label: zone.label || next.label } : zone;
    }));
  };

  // Calcular zonas de Ritmo automáticamente (basado en umbral R5)
  const calcRitmoZones = () => {
    if (!umbralRitmo) {
      Alert.alert('Falta umbral', 'Introduce tu ritmo umbral (R5) en min/km.');
      return;
    }
    const [min, sec] = umbralRitmo.split(':').map(Number);
    const umbralSeg = min * 60 + sec;
    const porcentajes = [0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 1.0, 1.05, 1.10, 1.15, 1.20, 1.30, 1.50];
    const labels = ['R0', 'R1', 'R1+', 'R2', 'R2+', 'R3', 'R3+', 'R4', 'R4+', 'R5', 'R5+', 'R6'];
    const calculated = labels.map((label, i) => {
      const p = porcentajes[i];
      return {
        id: label,
        min: i > 0 ? formatRitmo(porcentajes[i - 1]) : '00:00',
        max: formatRitmo(p),
        label,
      };
    });
    setRitmoZones(ritmoZones.map(zone => {
      const next = calculated.find(z => String(z.id) === String(zone.id) || z.label === zone.label);
      return next ? { ...zone, min: next.min, max: next.max, label: zone.label || next.label } : zone;
    }));
  };

  // Calcular zonas de Potencia automáticamente (basado en umbral FTP)
  const calcPotenciaZones = () => {
    if (!umbralPotencia) {
      Alert.alert('Falta umbral', 'Introduce tu umbral de potencia en vatios.');
      return;
    }
    const umbral = parseInt(umbralPotencia);
    const calculated = [
      { id: '1', min: 0, max: Math.round(umbral * 0.55), label: 'Z1 Recuperación' },
      { id: '2', min: Math.round(umbral * 0.55), max: Math.round(umbral * 0.75), label: 'Z2 Aeróbico' },
      { id: '3', min: Math.round(umbral * 0.75), max: Math.round(umbral * 0.90), label: 'Z3 Tempo' },
      { id: '4', min: Math.round(umbral * 0.90), max: Math.round(umbral * 1.05), label: 'Z4 Umbral' },
      { id: '5', min: Math.round(umbral * 1.05), max: Math.round(umbral * 1.20), label: 'Z5 VO2 Max' },
      { id: '6', min: Math.round(umbral * 1.20), max: 9999, label: 'Z6 Anaeróbico' },
    ];
    setPotenciaZones(potenciaZones.map(zone => {
      const next = calculated.find(z => String(z.id) === String(zone.id) || z.label === zone.label);
      return next ? { ...zone, min: next.min, max: next.max, label: zone.label || next.label } : zone;
    }));
  };

  const formatRitmo = (porc) => {
    const [min, sec] = umbralRitmo.split(':').map(Number);
    const umbralSeg = min * 60 + sec;
    const seg = umbralSeg / porc;
    const m = Math.floor(seg / 60);
    const s = Math.round(seg % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  if (loading) {
    return (
      <View style={[styles.center, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={BLUE} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <View style={[styles.header, { borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={24} color="#8FA8C8" />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: theme.text }]}>Zonas</Text>
        <TouchableOpacity onPress={saveZones}>
          <Text style={styles.saveBtn}>Guardar</Text>
        </TouchableOpacity>
      </View>

      {/* Pestañas */}
      <View style={[styles.tabs, { borderBottomColor: theme.border }]}>
        {['FC', 'Ritmo', 'Potencia'].map(t => (
          <TouchableOpacity key={t} style={[styles.tab, tab === t && styles.tabActive]} onPress={() => setTab(t)}>
            <Text style={[styles.tabText, { color: theme.muted }, tab === t && [styles.tabTextActive, { color: theme.text }]]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
      >
        {tab === 'FC' && (
          <View>
            <Text style={[styles.label, { color: theme.muted }]}>FC máxima</Text>
            <TextInput style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={umbralFC} onChangeText={setUmbralFC} placeholder="190" keyboardType="numeric" />
            <Text style={[styles.label, { color: theme.muted, marginTop: 10 }]}>FC umbral (LTHR) — opcional</Text>
            <TextInput style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={fcUmbral} onChangeText={setFcUmbral} placeholder="170" keyboardType="numeric" />
            <Text style={[styles.label, { color: theme.muted, fontSize: 11, marginTop: 4, opacity: 0.8 }]}>
              La FC que aguantas 1 hora a ritmo fuerte. Se usa para calcular el esfuerzo (hrTSS) de los entrenos importados desde el móvil; si la dejas vacía se estima como el 90 % de tu FC máxima.
            </Text>
            <TouchableOpacity style={styles.calcBtn} onPress={calcFcZones}>
              <Text style={styles.calcBtnText}>Calcular zonas automáticamente</Text>
            </TouchableOpacity>
            {fcZones.map((zone, index) => (
              <View key={zone.id} style={[styles.zoneCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
                <View style={styles.zoneRow}>
                  <Text style={[styles.zoneLabel, { color: theme.text }]}>{zone.label || `Zona ${index + 1}`}</Text>
                  <TouchableOpacity onPress={() => deleteZone(zone)}>
                    <Ionicons name="trash-outline" size={18} color={RED} />
                  </TouchableOpacity>
                </View>
                <View style={styles.row}>
                  <Text style={[styles.zoneField, { color: theme.muted }]}>Min</Text>
                  <TextInput style={[styles.zoneInput, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]} value={zone.min.toString()} onChangeText={v => updateZone(zone.id, 'min', v)} keyboardType="numeric" />
                  <Text style={[styles.zoneField, { color: theme.muted }]}>Max</Text>
                  <TextInput style={[styles.zoneInput, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]} value={zone.max.toString()} onChangeText={v => updateZone(zone.id, 'max', v)} keyboardType="numeric" />
                </View>
              </View>
            ))}
            <TouchableOpacity style={styles.addBtn} onPress={addZone}>
              <Ionicons name="add-circle-outline" size={20} color={BLUE} />
              <Text style={styles.addBtnText}>Agregar zona</Text>
            </TouchableOpacity>
          </View>
        )}

        {tab === 'Ritmo' && (
          <View>
            <Text style={[styles.label, { color: theme.muted }]}>Ritmo umbral (R5) min/km</Text>
            <TextInput style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={umbralRitmo} onChangeText={setUmbralRitmo} placeholder="02:52" />
            <TouchableOpacity style={styles.calcBtn} onPress={calcRitmoZones}>
              <Text style={styles.calcBtnText}>Calcular zonas automáticamente</Text>
            </TouchableOpacity>
            {ritmoZones.map((zone, index) => (
              <View key={zone.id} style={[styles.zoneCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
                <View style={styles.zoneRow}>
                  <Text style={[styles.zoneLabel, { color: theme.text }]}>{zone.label}</Text>
                  <TouchableOpacity onPress={() => deleteZone(zone)}>
                    <Ionicons name="trash-outline" size={18} color={RED} />
                  </TouchableOpacity>
                </View>
                <View style={styles.row}>
                  <Text style={[styles.zoneField, { color: theme.muted }]}>Min</Text>
                  <TextInput style={[styles.zoneInput, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]} value={zone.min} onChangeText={v => updateZone(zone.id, 'min', v)} placeholder="00:00" />
                  <Text style={[styles.zoneField, { color: theme.muted }]}>Max</Text>
                  <TextInput style={[styles.zoneInput, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]} value={zone.max} onChangeText={v => updateZone(zone.id, 'max', v)} placeholder="00:00" />
                </View>
              </View>
            ))}
            <TouchableOpacity style={styles.addBtn} onPress={addZone}>
              <Ionicons name="add-circle-outline" size={20} color={BLUE} />
              <Text style={styles.addBtnText}>Agregar zona</Text>
            </TouchableOpacity>
          </View>
        )}

        {tab === 'Potencia' && (
          <View>
            <Text style={[styles.label, { color: theme.muted }]}>Umbral de potencia (W)</Text>
            <TextInput style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={umbralPotencia} onChangeText={setUmbralPotencia} placeholder="250" keyboardType="numeric" />
            <TouchableOpacity style={styles.calcBtn} onPress={calcPotenciaZones}>
              <Text style={styles.calcBtnText}>Calcular zonas automáticamente</Text>
            </TouchableOpacity>
            {potenciaZones.map((zone, index) => (
              <View key={zone.id} style={[styles.zoneCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
                <View style={styles.zoneRow}>
                  <Text style={[styles.zoneLabel, { color: theme.text }]}>{zone.label || `Zona ${index + 1}`}</Text>
                  <TouchableOpacity onPress={() => deleteZone(zone)}>
                    <Ionicons name="trash-outline" size={18} color={RED} />
                  </TouchableOpacity>
                </View>
                <View style={styles.row}>
                  <Text style={[styles.zoneField, { color: theme.muted }]}>Min</Text>
                  <TextInput style={[styles.zoneInput, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]} value={zone.min.toString()} onChangeText={v => updateZone(zone.id, 'min', v)} keyboardType="numeric" />
                  <Text style={[styles.zoneField, { color: theme.muted }]}>Max</Text>
                  <TextInput style={[styles.zoneInput, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]} value={zone.max.toString()} onChangeText={v => updateZone(zone.id, 'max', v)} keyboardType="numeric" />
                </View>
              </View>
            ))}
            <TouchableOpacity style={styles.addBtn} onPress={addZone}>
              <Ionicons name="add-circle-outline" size={20} color={BLUE} />
              <Text style={styles.addBtnText}>Agregar zona</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
      <Modal visible={zonePickerOpen} transparent animationType="fade" onRequestClose={() => setZonePickerOpen(false)}>
        <View style={[styles.modalOverlay, { backgroundColor: theme.overlay }]}>
          <View style={[styles.zonePicker, { backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border }]}>
            <Text style={[styles.zonePickerTitle, { color: theme.text }]}>Añadir zona de {tab}</Text>
            <ScrollView>
              {zoneOptions.map(([id, label]) => {
                const exists = activeZones.some(z => String(z.id) === String(id) || z.label === label);
                return (
                  <TouchableOpacity
                    key={id}
                    disabled={exists}
                    style={[styles.zoneOption, { borderBottomColor: theme.border }, exists && styles.zoneOptionDisabled]}
                    onPress={() => addSelectedZone(id, label)}
                  >
                    <Text style={[styles.zoneOptionText, { color: theme.text }]}>{label}</Text>
                    <Text style={styles.zoneOptionState}>{exists ? 'Añadida' : 'Añadir'}</Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => setZonePickerOpen(false)}>
              <Text style={[styles.cancelBtnText, { color: theme.muted }]}>Cancelar</Text>
            </TouchableOpacity>
          </View>
        </View>
        <SystemBars />
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: NAVY,
  },
  // Sin SafeAreaView: el header queda a paddingTop 56 desde el borde superior,
  // igual que DonationScreen, aprovechando el espacio que antes dejaba vacío.
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 56, paddingBottom: 16,
    borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  saveBtn: { color: BLUE, fontSize: 16, fontWeight: '600' },
  tabs: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: BORDER },
  tab: { flex: 1, paddingVertical: 14, alignItems: 'center' },
  tabActive: { borderBottomWidth: 2, borderBottomColor: BLUE },
  tabText: { color: '#8FA8C8', fontSize: 15, fontWeight: '600' },
  tabTextActive: { color: '#fff', fontWeight: '700' },
  scroll: { flex: 1, padding: 16 },
  label: { color: '#8FA8C8', fontSize: 14, marginBottom: 8 },
  input: { backgroundColor: CARD, borderRadius: 8, borderWidth: 1, borderColor: BORDER, padding: 12, color: '#fff', marginBottom: 16 },
  calcBtn: { backgroundColor: BLUE, padding: 12, borderRadius: 8, alignItems: 'center', marginBottom: 16 },
  calcBtnText: { color: '#fff', fontWeight: '600' },
  zoneCard: { backgroundColor: CARD, borderRadius: 8, padding: 12, marginBottom: 10, borderWidth: 1, borderColor: BORDER },
  zoneRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  zoneLabel: { color: '#fff', fontWeight: '600', fontSize: 16 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  zoneField: { color: '#8FA8C8', width: 30 },
  zoneInput: { flex: 1, backgroundColor: NAVY, borderRadius: 6, borderWidth: 1, borderColor: BORDER, padding: 8, color: '#fff', textAlign: 'center' },
  addBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 12, padding: 12 },
  addBtnText: { color: BLUE, fontWeight: '600' },
  modalOverlay: { flex: 1, backgroundColor: '#00000088', justifyContent: 'center', padding: 24 },
  zonePicker: { maxHeight: '75%', backgroundColor: CARD, borderRadius: 12, padding: 16, borderWidth: 1, borderColor: BORDER },
  zonePickerTitle: { color: '#fff', fontSize: 17, fontWeight: '700', marginBottom: 12 },
  zoneOption: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: BORDER },
  zoneOptionDisabled: { opacity: 0.4 },
  zoneOptionText: { color: '#fff', fontSize: 14 },
  zoneOptionState: { color: BLUE, fontSize: 12, fontWeight: '600' },
  cancelBtn: { alignItems: 'center', paddingTop: 14 },
  cancelBtnText: { color: '#8FA8C8', fontWeight: '600' },
});
