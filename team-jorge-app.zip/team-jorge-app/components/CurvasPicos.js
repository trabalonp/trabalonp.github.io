// components/CurvasPicos.js
/* ══════════════════════════════════════════════════════════════════════
   GRÁFICAS AL ESTILO intervals.icu (ver investigación duck.ai 26/09):
   · CURVA DE FC POR DURACIÓN: mejor FC media móvil para muchas duraciones
     (5 s … 60 min), eje X LOGARÍTMICO, línea con puntos.
   · TIEMPO ACUMULADO POR FC: distribución acumulada T(≥ h) = suma de los
     dt con FC ≥ h; eje X = ppm con FRANJAS DE ZONA, eje Y = tiempo acum.
   · CURVA DE RITMO POR DISTANCIA: mejor ritmo medio para cada distancia
     (0.2 … 21.1 km): eje X log (km), eje Y INVERTIDO (min/km; más rápido
     = más arriba). En ciclismo: mejor velocidad media por distancia.
   · MEJORES ESFUERZOS: tabla por distancia (tiempo + ritmo o km/h).
   Todo se calcula desde los `registros` (equivalente a los streams de
   intervals.icu), descartando huecos > 30 s (reloj parado).
   CurvaSkia: línea+área+puntos con el lenguaje visual de ActivityChart y
   modo INTERACTIVO (toque → marcador + tooltip) para pantalla completa,
   como las gráficas del apartado Detalles.
   ══════════════════════════════════════════════════════════════════════ */
import React, { useEffect, useMemo, useState } from 'react';
import { Modal, Text, TouchableOpacity, View, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Canvas, Path, Skia } from '@shopify/react-native-skia';
import * as ScreenOrientation from 'expo-screen-orientation';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import SystemBars from './SystemBars';

const PAD_L = 46, PAD_R = 12, PAD_T = 14, PAD_B = 24;
const TIP_W = 140; // ancho del tooltip (debe coincidir con cp.tip.width)
const GAP_MAX_S = 30;

/* ═══ DOS ESCALAS: LÍNEA DEL ENTRENO COMPLETA, LÍNEA DE MEDIA REDUCIDA ═════
   · La línea DEL ENTRENO (Curva FC / Curva ritmo) se calcula con la escala
     COMPLETA de siempre: una ventana cada 10 s (hasta 1 h) y una distancia
     cada 5 m (hasta 50 km). Sin generalizar: salen TODOS los puntos.
     RONDA 43: la escalera de distancia ARRANCA EN 1 km (como la curva de
     ritmo de intervals.icu) y la distancia acumulada que consume se suaviza
     (ver suavizarKm): comentario propio más abajo.
   · La línea de MEDIA histórica es una referencia suave y se queda TAL CUAL
     estaba (RONDA 41): escala logarítmica por tramos + adelgazarEscala.
   · Para que la escala completa NO vuelva a bloquear el hilo JS (causa del
     crasheo original: mejoresEsfuerzos era O(distancias × muestras) = hasta
     288 M de iteraciones seguidas), esa función lleva ahora paso adaptativo
     con presupuesto acotado — ver su comentario más abajo.
   ═══════════════════════════════════════════════════════════════════════ */
const MAX_MUESTRAS = 20000;   // ≈ 5,5 h a 1 Hz; por encima se fusionan muestras
export const VENTANAS_FC = [5, 10, 15, 30, 60, 120, 300, 600, 1200, 1800, 3600];
export const DISTS_CURVA_RUN = [0.2, 0.4, 0.8, 1, 1.5, 2, 3, 5, 8, 10, 15, 21.1];
export const DISTS_CURVA_BIKE = [1, 2, 5, 10, 20, 40, 60];
export const DISTS_TABLA_RUN = [0.4, 0.8, 1.5, 1.609, 3, 5, 10];
export const DISTS_TABLA_BIKE = [5, 10, 20, 40];

/* ── Escala COMPLETA de la línea del entreno (idéntica a la original:
      1 ventana cada 10 s hasta 1 h; 1 distancia cada 5 m hasta 50 km) ── */
export const duracionesCada10s = (maxSec) => {
  const max = Math.min(3600, Math.floor(Number(maxSec) || 0));
  const out = [];
  for (let s = 10; s <= max; s += 10) out.push(s);
  return out;
};
/* RONDA 43: la escalera de distancia ARRANCA EN 1 km (salvo entrenos de menos
   de 1 km, que siguen empezando en 5 m). Medido con la geometría real de
   CurvaSkia: con arranque en 5 m el dominio del eje log quedaba
   [0.005, máx] y las marcas 500 m/1 km/2 km/5 km caían al 58/67/75/87 % del
   ancho (toda la información útil apretada en el tercio final, exactamente el
   defecto de la captura frente a intervals.icu, cuya curva de ritmo empieza
   en 1 km). De 1 km en adelante la escalera SIGUE siendo completa: un punto
   cada 5 m, sin generalizar. Debajo de ~500 m el ruido del GPS además domina
   (ver suavizarKm). */
export const INICIO_CURVA_KM = 1;
export const distanciasCada5m = (maxKm) => {
  const max = Math.min(50, Math.floor((Number(maxKm) || 0) * 200) / 200);
  const inicioM = max >= INICIO_CURVA_KM ? INICIO_CURVA_KM * 1000 : 5;
  const out = [];
  for (let m = inicioM; m <= Math.round(max * 1000); m += 5) out.push(m / 1000);
  return out;
};

/* ── Escalas REDUCIDAS, SOLO para la línea de media histórica (RONDA 41).
   Logarítmicas por tramos: finas donde la curva cambia rápido y más gruesas
   donde es casi plana, que es lo que pide un eje X en log. Rematan en el
   mismo primer y último valor que la escala completa para que los extremos
   del eje no se muevan. ── */
/* [tope en segundos, paso en segundos] — de 10 s en 10 s hasta 10 min, de 30 s
   hasta 30 min y de 60 s hasta 1 h. Máx. 130 ventanas (completa: 360). */
const TRAMOS_DURACION = [[600, 10], [1800, 30], [3600, 60]];
export const duracionesReducidas = (maxSec) => {
  const max = Math.min(3600, Math.floor(Number(maxSec) || 0));
  const out = [];
  let anterior = 0;
  for (let i = 0; i < TRAMOS_DURACION.length; i++) {
    const tope = TRAMOS_DURACION[i][0], paso = TRAMOS_DURACION[i][1];
    if (max <= anterior) break;
    const fin = Math.min(max, tope);
    for (let s = anterior + paso; s <= fin; s += paso) out.push(s);
    anterior = tope;
  }
  const cola = Math.floor(max / 10) * 10;
  if (cola > 0 && (!out.length || cola > out[out.length - 1])) out.push(cola);
  return out;
};
/* [tope en metros, paso en metros] — cada 5 m hasta 200 m y progresivamente
   más grueso. Máx. 342 distancias (completa: 10 000). */
const TRAMOS_DISTANCIA_M = [[200, 5], [500, 10], [2000, 25], [5000, 50], [10000, 100], [21100, 250], [50000, 500]];
export const distanciasReducidas = (maxKm) => {
  const maxM = Math.min(50000, Math.floor((Number(maxKm) || 0) * 1000));
  const out = [];
  let anterior = 0;
  for (let i = 0; i < TRAMOS_DISTANCIA_M.length; i++) {
    const tope = TRAMOS_DISTANCIA_M[i][0], paso = TRAMOS_DISTANCIA_M[i][1];
    if (maxM <= anterior) break;
    const fin = Math.min(maxM, tope);
    for (let m = anterior + paso; m <= fin; m += paso) out.push(m / 1000);
    anterior = tope;
  }
  const colaM = Math.min(50000, Math.round(Math.min(50, Math.floor((Number(maxKm) || 0) * 200) / 200) * 1000));
  if (colaM >= 5 && (!out.length || colaM > Math.round(out[out.length - 1] * 1000))) out.push(colaM / 1000);
  return out;
};
/* Reduce una escala ya generada a como mucho `max` valores repartidos por todo
   el rango (en nuestras escaleras el índice ya es casi logarítmico). Conserva
   siempre el primer y el último valor para no mover los extremos del eje. */
export const adelgazarEscala = (lista, max) => {
  if (!Array.isArray(lista)) return [];
  if (lista.length <= max) return lista;
  const paso = Math.ceil(lista.length / max);
  const out = [];
  for (let i = 0; i < lista.length; i += paso) out.push(lista[i]);
  if (out[out.length - 1] !== lista[lista.length - 1]) out.push(lista[lista.length - 1]);
  return out;
};
/* Escalas de la LÍNEA DE MEDIA: idénticas a las de la RONDA 41 (reducida y
   adelgazada → ~45 ventanas / ≤71 distancias). La media no cambia.
   RONDA 43: a la escala de distancia se le quita SOLO la cola izquierda
   (< 1 km) para que la línea de media no arrastre el dominio del eje log de
   vuelta a 5 m; los VALORES de cada distancia conservada son bit a bit los
   mismos de la RONDA 41/42 (se recorta la lista, no se recalcula nada). */
export const duracionesParaMedia = (maxSec) => adelgazarEscala(duracionesReducidas(maxSec), 60);
export const distanciasParaMedia = (maxKm) => {
  const lista = adelgazarEscala(distanciasReducidas(maxKm), 70);
  if (!(maxKm >= INICIO_CURVA_KM)) return lista;
  const out = lista.filter((d) => d >= INICIO_CURVA_KM);
  return out.length ? out : lista;
};

export const fmtVentana = (w) => (w >= 3600 ? `${Math.round(w / 3600)} h` : w >= 60 ? `${Math.round(w / 60)} m` : `${w} s`);
export const fmtPace = (secKm) => {
  if (!secKm || !Number.isFinite(secKm) || secKm <= 0) return '—';
  const m = Math.floor(secKm / 60), s2 = Math.round(secKm % 60);
  return s2 === 60 ? `${m + 1}:00` : `${m}:${String(s2).padStart(2, '0')}`;
};
export const fmtTiempo = (sec) => {
  const t = Math.round(sec || 0);
  const h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s2 = t % 60;
  const p2 = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${p2(m)}:${p2(s2)}` : `${m}:${p2(s2)}`;
};
export const fmtAcum = (sec) => {
  const t = Math.round(sec || 0);
  if (t < 60) return `${t}s`;
  if (t < 3600) return `${Math.round(t / 60)}m`;
  const h = Math.floor(t / 3600), m = Math.round((t % 3600) / 60);
  return m ? `${h}h${String(m).padStart(2, '0')}m` : `${h}h`;
};
export const labelDist = (d) => (d === 1.609 ? '1 mi' : d < 1 ? `${Math.round(d * 1000)} m` : `${d} km`);

const tsDe = (r) => new Date(r.timestamp).getTime();

/* Los FIT no siempre traen una muestra exactamente cada segundo y las
   versiones antiguas además reducían el stream a 1000 puntos. Para las
   gráficas interpolamos únicamente huecos razonables (<=30 s), de modo que
   cada segundo del entrenamiento tiene un valor temporal regular. No se
   rellenan pausas largas ni se modifica el stream original del mapa. */
export function remuestrearPorSegundo(regs) {
  if (!Array.isArray(regs) || regs.length < 2) return regs || [];
  const src = regs.map((r) => ({ r, t: tsDe(r) })).filter((x) => Number.isFinite(x.t)).sort((a, b) => a.t - b.t);
  if (src.length < 2) return regs;
  const out = [];
  let j = 0;
  const tStart = Math.ceil(src[0].t / 1000) * 1000;
  const tEnd = Math.floor(src[src.length - 1].t / 1000) * 1000;
  const keys = ['distancia', 'altitud', 'frecuencia', 'cadencia', 'potencia', 'velocidad', 'lat', 'lon'];
  for (let t = tStart; t <= tEnd; t += 1000) {
    while (j + 1 < src.length && src[j + 1].t < t) j++;
    const a = src[j], b = src[Math.min(j + 1, src.length - 1)];
    if (!a || !b) continue;
    const gap = b.t - a.t;
    if (gap <= 0 || gap > 30000) continue;
    const f = Math.max(0, Math.min(1, (t - a.t) / gap));
    const row = { ...a.r, timestamp: new Date(t).toISOString() };
    keys.forEach((key) => {
      const av = Number(a.r[key]), bv = Number(b.r[key]);
      if (Number.isFinite(av) && Number.isFinite(bv)) row[key] = av + (bv - av) * f;
    });
    out.push(row);
  }
  if (!out.length) return regs;
  return out;
}

function segmentos(regs) {
  const segs = [];
  for (let i = 0; i + 1 < regs.length; i++) {
    const dt = (tsDe(regs[i + 1]) - tsDe(regs[i])) / 1000;
    if (!(dt > 0) || dt > GAP_MAX_S) continue;
    segs.push({ dt, fc: Number(regs[i].frecuencia) || 0, v: Number(regs[i].velocidad) || 0 });
  }
  return segs;
}

/* Reducción defensiva del stream. Solo entra en juego con entrenos enormes
   (más de MAX_MUESTRAS muestras). Fusiona bloques consecutivos conservando la
   media PONDERADA POR TIEMPO de FC y velocidad, que es justo lo que consumen
   las curvas de duración, así que el resultado no varía de forma apreciable. */
function limitarSegs(segs) {
  if (segs.length <= MAX_MUESTRAS) return segs;
  const paso = Math.ceil(segs.length / MAX_MUESTRAS);
  const out = [];
  for (let i = 0; i < segs.length; i += paso) {
    const fin = Math.min(segs.length, i + paso);
    let dt = 0, sfc = 0, sv = 0;
    for (let k = i; k < fin; k++) { dt += segs[k].dt; sfc += segs[k].fc * segs[k].dt; sv += segs[k].v * segs[k].dt; }
    if (dt > 0) out.push({ dt, fc: sfc / dt, v: sv / dt });
  }
  return out;
}

/* Ídem para la curva de ritmo/distancia, que trabaja con pares (t, km):
   se conserva una muestra de cada `paso` más la última (distancia total). */
function limitarPts(pts) {
  if (pts.length <= MAX_MUESTRAS) return pts;
  const paso = Math.ceil(pts.length / MAX_MUESTRAS);
  const out = [];
  for (let i = 0; i < pts.length; i += paso) out.push(pts[i]);
  if (out[out.length - 1] !== pts[pts.length - 1]) out.push(pts[pts.length - 1]);
  return out;
}

/* ── Curva de duración: mejor media móvil de FC y velocidad por ventana ── */
export function curvasDuracion(regs, windows = VENTANAS_FC) {
  if (!regs || regs.length < 2) return [];
  const segs = limitarSegs(segmentos(regs));
  const total = segs.reduce((a, s0) => a + s0.dt, 0);
  const out = [];
  for (const w of windows) {
    if (w > total) continue;
    let bfc = 0, bv = 0;
    let acc = 0, sfc = 0, sv = 0, lo = 0;
    for (let hi = 0; hi < segs.length; hi++) {
      acc += segs[hi].dt; sfc += segs[hi].fc * segs[hi].dt; sv += segs[hi].v * segs[hi].dt;
      while (lo < hi && acc - segs[lo].dt >= w) {
        sfc -= segs[lo].fc * segs[lo].dt; sv -= segs[lo].v * segs[lo].dt;
        acc -= segs[lo].dt; lo++;
      }
      if (acc >= w) {
        const f = sfc / acc, v = sv / acc;
        if (f > bfc) bfc = f;
        if (v > bv) bv = v;
      }
    }
    out.push({ w, fc: bfc, v: bv });
  }
  return out;
}

/* ── Tiempo acumulado T(≥ h) por nivel de FC (distribución acumulada) ── */
export function tiempoAcumuladoFC(regs, step = 5) {
  if (!regs || regs.length < 2) return [];
  const segs = segmentos(regs).filter((s0) => s0.fc > 0);
  if (!segs.length) return [];
  // Min/max en bucle: Math.min(...array) con streams largos revienta la pila
  // de llamadas de Hermes (RangeError) y tiraba la app abajo.
  let vMin = Infinity, vMax = -Infinity;
  for (let i = 0; i < segs.length; i++) {
    const f = segs[i].fc;
    if (f < vMin) vMin = f;
    if (f > vMax) vMax = f;
  }
  const min = Math.floor(vMin / step) * step;
  const max = Math.ceil(vMax / step) * step;
  const out = [];
  for (let h = min; h <= max; h += step) {
    let t = 0;
    for (const s0 of segs) if (s0.fc >= h) t += s0.dt;
    out.push({ x: h, v: t });
  }
  return out.filter((p) => p.v > 0);
}

/* ── Mejores esfuerzos por DISTANCIA (curva ritmo-distancia y tabla) ──
   MISMO algoritmo y MISMAS fórmulas que siempre (doble puntero sobre el
   stream ordenado + interpolación lineal en el extremo de cada ventana) y
   mismos campos de salida {d, t, pace, speed}. Lo único que cambia es el PASO
   con el que se recorren las muestras, adaptado a cada distancia:
     · Listas cortas (≤ LISTA_EXACTA_MAX distancias: tabla de Picos, línea de
       media, DISTS_CURVA_*) y distancias cortas de la escalera completa
       (D ≤ K_FIDELIDAD × espaciado entre muestras, ≈ 1-3 km): paso 1 → se
       evalúan TODAS las muestras como arranque y como extremo → valores
       IDÉNTICOS bit a bit al cálculo de siempre.
     · Distancias largas de la escalera completa (cada 5 m hasta 50 km): el
       paso crece PROPORCIONAL a la distancia (≈ D/K_FIDELIDAD metros), así el
       error relativo del mejor tiempo es del orden de 1/K_FIDELIDAD (medido:
       < 0,1 % ⇒ < 0,1 px en la gráfica) y el coste total queda ACOTADO por
       PRESUPUESTO_IT incluso con 20 000 muestras. En entrenos gigantescos
       (p. ej. 300 km) K se relaja solo hasta caber en el presupuesto: la
       curva sigue teniendo TODAS las distancias, con algo menos de finura.
   Sin esto, la escalera completa de cada 5 m volvería a costar
   O(distancias × muestras): 117-288 M de iteraciones seguidas en el hilo JS
   (6-16 s en móvil) = el crasheo medido de las RONDAS 39/40.
   RONDA 43 (dientes + apretujamiento, medido con distancia GPS realista):
     · La línea dibujada (escalera completa) consume la distancia acumulada
       SUAVIZADA (suavizarKm: media móvil centrada de los incrementos por
       segundo). Los «dientes» de la captura son el RUIDO del GPS acumulado
       (multipath/saltos) regalando distancia a ventanas de un solo segundo:
       con jitter realista salían 1 119 caídas bruscas en 58 min con el
       algoritmo base tal cual, e intervals.icu no los enseña porque no
       dibuja distancia cruda. Promediando el incremento entre 9 segundos el
       salto se diluye ANTES de medir y la forma real de la curva se
       conserva: verificado con fuerza bruta O(n²) que los quiebres y
       bajadas legítimas (p. ej. el sprint final de un entreno de series,
       que mejora el mejor ritmo de 2,3 km frente al de 2,2 km) NO son
       ruido, y por eso NO se fuerza monotonía ninguna (el mejor ritmo por
       distancia no es monótono: forzarlo costaba hasta 20 px de error).
       Las listas cortas (≤128: tabla de Picos y línea de media) no pasan
       por el suavizado: conservan sus valores exactos de siempre.
     · Reloj de seguridad PRESUPUESTO_MS: independiente del modelo de
       iteraciones, si una llamada supera ese tiempo REAL el paso se hace más
       grueso para lo que queda → toda llamada termina acotada incluso en
       móviles más lentos de lo supuesto. */
const K_FIDELIDAD = 600;       // paso ≈ D/K en metros → error relativo ~1/K
const PRESUPUESTO_IT = 16e6;   // iteraciones máx. por llamada (~0,8 s en móvil)
const PRESUPUESTO_MS = 700;    // tiempo REAL máx. por llamada; después se gruesa el paso
const LISTA_EXACTA_MAX = 128;  // listas de ≤128 distancias: siempre exactas

/* ── RONDA 43: distancia acumulada SUAVIZADA para la línea dibujada ───────
   Los «dientes» de la curva de ritmo no son forma real: el mejor ritmo medio
   por distancia es monótono por construcción (toda ventana que cubre D+Δ
   cubre también D), así que cada caída viene del RUIDO de la distancia GPS
   acumulada (rebotes de multipath, sombras de edificio): medido con jitter
   realista, 1 119 caídas en 58 min con el algoritmo base tal cual.
   suavizarKm hace una media móvil CENTRADA de los incrementos por muestra
   (ventana SUAVIZADO_W ≈ 9 s: 25 m corriendo / 90 m en bici): el salto de
   multipath se diluye entre 9 segundos en vez de regalar distancia a una
   sola ventana, y la distancia TOTAL se conserva (los incrementos
   suavizados se recortan a ≥0). O(n·W), despreciable frente al doble
   puntero. Las listas exactas (≤128: Picos, media) NO pasan por aquí. */
const SUAVIZADO_W = 9;
function suavizarKm(km, n) {
  const out = new Float64Array(n);
  const h = (SUAVIZADO_W - 1) >> 1;
  out[0] = km[0];
  let mono = true;
  for (let i = 1; i < n; i++) {
    let s0 = 0, c = 0;
    const desde = Math.max(1, i - h), hasta = Math.min(n - 1, i + h);
    for (let k = desde; k <= hasta; k++) { s0 += km[k] - km[k - 1]; c++; }
    out[i] = out[i - 1] + Math.max(0, s0 / c);
    if (out[i] < out[i - 1]) mono = false;
  }
  return { km: out, mono };
}

export function mejoresEsfuerzos(regs, distsKm) {
  if (!regs || regs.length < 2 || !distsKm || !distsKm.length) return [];
  const pts = limitarPts(regs
    .map((r) => ({ t: tsDe(r), km: Number(r.distancia) || 0 }))
    .filter((p) => Number.isFinite(p.t) && p.km > 0));
  if (pts.length < 2) return [];
  const n = pts.length;
  const km = new Float64Array(n);
  const tm = new Float64Array(n);
  let monotono = true;
  for (let i = 0; i < n; i++) {
    km[i] = pts[i].km;
    if (i > 0) {
      if (km[i] < km[i - 1]) monotono = false;
      const dt = (pts[i].t - pts[i - 1].t) / 1000;
      tm[i] = tm[i - 1] + (dt > 0 && dt <= GAP_MAX_S ? dt : 0);
    }
  }
  const exacta = distsKm.length <= LISTA_EXACTA_MAX;
  // RONDA 43: la escalera completa (línea dibujada) mide sobre la distancia
  // SUAVIZADA; las listas exactas (Picos, media) sobre la cruda de siempre.
  let kmd = km, mono = monotono;
  if (!exacta) { const sv = suavizarKm(km, n); kmd = sv.km; mono = sv.mono; }
  const L = kmd[n - 1];
  const espaciado = Math.max(1e-9, (L - km[0]) / Math.max(1, n - 1));
  const pasoDe = (D, K) => (exacta ? 1 : Math.max(1, Math.ceil(D / (K * espaciado))));
  let K = K_FIDELIDAD;
  if (!exacta) {
    // Si el coste previsto no cabe en el presupuesto, se relaja K (solo pasa
    // con entrenos enormes: muchísimos km). Nunca se sube K por encima de
    // K_FIDELIDAD, así la finura tope es siempre la prometida.
    const coste = (Kx) => {
      let total = 0;
      for (let q = 0; q < distsKm.length; q++) {
        const D = distsKm[q];
        if (!(D > 0) || L < D) continue;
        const s = pasoDe(D, Kx);
        const arr = mono ? Math.max(1, Math.ceil((n * (L - D)) / L)) : n;
        total += (arr + n) / s;
      }
      return total;
    };
    for (let it = 0; it < 16; it++) {
      const c = coste(K);
      if (c <= PRESUPUESTO_IT) break;
      const k2 = Math.max(4, Math.floor((K * PRESUPUESTO_IT) / c));
      if (k2 >= K) break;
      K = k2;
    }
  }
  // Rejillas (una por paso distinto): índices + sus km/tm copiados en
  // Float64Array propios, para que el bucle interior lea una sola vez por
  // iteración (mismos dobles, mismas fórmulas ⇒ mismos bits). Siempre incluyen
  // la última muestra, para no perder ventanas que terminan al final.
  const rejillas = new Map();
  const rejilla = (s) => {
    let g = rejillas.get(s);
    if (!g) {
      const pasos = Math.floor((n - 1) / s);
      const sobra = (n - 1) % s;
      const len = pasos + 1 + (sobra ? 1 : 0);
      const idx = new Int32Array(len), gk = new Float64Array(len), gt = new Float64Array(len);
      for (let q = 0, i2 = 0; q < len; q++, i2 += s) {
        if (q === len - 1 && sobra) i2 = n - 1;
        idx[q] = i2; gk[q] = kmd[i2]; gt[q] = tm[i2];
      }
      g = { idx, gk, gt };
      rejillas.set(s, g);
    }
    return g;
  };
  const out = [];
  const t0 = Date.now();
  for (let q = 0; q < distsKm.length; q++) {
    // Reloj de seguridad RONDA 43: si la llamada supera PRESUPUESTO_MS en
    // tiempo REAL (móvil más lento de lo que modela PRESUPUESTO_IT, stream
    // anómalo…), el paso se hace ×2 más grueso para lo que queda. Solo
    // relaja (nunca afina), así que en equipos rápidos no cambia nada y el
    // coste en el peor caso queda acotado por el reloj, no por el modelo.
    if ((q & 31) === 31 && Date.now() - t0 > PRESUPUESTO_MS) K = Math.max(4, K >> 1);
    const D = distsKm[q];
    if (!(L >= D)) continue;   // mismo salto que antes (L < D), y cubre NaN
    const g = rejilla(pasoDe(D, K));
    const gk = g.gk, gt = g.gt, gl = gk.length;
    // Último arranque viable: desde ahí ni el stream completo llega a D. Se
    // usa la MISMA aritmética (L - km[i] >= D) que la comprobación del bucle.
    let iFin = gl - 1;
    if (mono) {
      let lo = 0, hi = gl - 1, res = -1;
      while (lo <= hi) {
        const mid = (lo + hi) >> 1;
        if (L - gk[mid] >= D) { res = mid; lo = mid + 1; } else { hi = mid - 1; }
      }
      if (res < 0) continue;
      iFin = res;
    }
    let bestT = Infinity, jj = 0;
    for (let ii = 0; ii <= iFin; ii++) {
      const kmi = gk[ii];
      if (jj < ii) jj = ii;
      while (jj + 1 < gl && gk[jj] - kmi < D) jj++;
      if (gk[jj] - kmi >= D) {
        let tFin = gt[jj];
        if (jj > ii && gk[jj] > gk[jj - 1]) {
          const falt = (gk[jj] - kmi) - D;
          const dkmSeg = gk[jj] - gk[jj - 1];
          const dtSeg = gt[jj] - gt[jj - 1];
          if (dkmSeg > 0) tFin = gt[jj] - (falt / dkmSeg) * dtSeg;
        }
        const t = tFin - gt[ii];
        if (t > 0 && t < bestT) bestT = t;
      }
    }
    if (bestT < Infinity) out.push({ d: D, t: bestT, pace: bestT / D, speed: D / (bestT / 3600) });
  }
  // RONDA 43: solo la escalera completa (línea dibujada). Las listas cortas
  // (tabla de Picos, línea de media) salen exactas y sin tocar, como siempre.
  if (!exacta) suavizarSalida(out);
  return out;
}

/* ── RONDA 43: suavizado de SALIDA proporcional (eje log) de la línea ─────
   El jitter sostenido del GPS se acumula en la distancia y ni la media móvil
   de incrementos lo quita del todo: en la captura del usuario la parte
   estable de la curva salía con zigzag de ±2-3 s/km, mientras intervals.icu
   (que dibuja ~50 vértices, no 1 900) la pinta lisa. suavizarSalida aplica
   una media móvil CENTRADA al ritmo ya calculado, con ventana PROPORCIONAL
   a la distancia (±5 % de D: ±50 m en 1 km, ±500 m en 10 km), que es como se
   comporta un eje logarítmico: el zigzag de periodo ~10-15 % de D se atenúa
   ≥60 % y las formas reales más anchas que la ventana (quiebres de series,
   bajadas de sprint, cuestas) se conservan (atenuación <6 % medido). O(n)
   con sumas prefijadas. Solo para la escalera completa dibujada. */
function suavizarSalida(out) {
  const n = out.length;
  if (n < 9) return out;
  const pre = new Float64Array(n + 1);
  for (let i = 0; i < n; i++) pre[i + 1] = pre[i] + out[i].pace;
  for (let i = 0; i < n; i++) {
    let h = Math.round(10 * out[i].d);          // ±5 % de D en peldaños de 5 m
    if (h < 3) h = 3;
    if (h > 250) h = 250;
    if (h > i) h = i;
    if (h > n - 1 - i) h = n - 1 - i;
    if (h < 1) continue;
    const pace = (pre[i + h + 1] - pre[i - h]) / (2 * h + 1);
    const t = pace * out[i].d;
    out[i].pace = pace;
    out[i].t = t;
    out[i].speed = out[i].d / (t / 3600);
  }
  return out;
}

export function promediarCurvas(series) {
  const acc = new Map();
  (series || []).forEach((curve) => (curve || []).forEach((p) => {
    if (!Number.isFinite(p.x) || !Number.isFinite(p.v)) return;
    const key = String(p.x);
    const a = acc.get(key) || { x: p.x, sum: 0, n: 0 };
    a.sum += p.v; a.n += 1; acc.set(key, a);
  }));
  return Array.from(acc.values()).sort((a, b) => a.x - b.x).map((a) => ({ x: a.x, v: a.sum / a.n }));
}

/* ── Curva Skia: logX, invertY, zonas, puntos y modo interactivo ── */
const ZONA_COLORS = ['#4A90E2', '#2DB37A', '#F5C518', '#F5A623', '#E05252', '#9A7BEB'];

/* Marco ESTÁTICO memoizado (patrón de las gráficas de Detalles): rejilla,
   franjas de zona y el canvas con las curvas NO se re-renderizan al arrastrar.
   El punto, la línea vertical y el tooltip van encima como Views normales,
   así el lienzo nunca se vacía mientras se inspecciona con el dedo. */
const CurvaFrame = React.memo(({ geom, paths, width, height, color, comparisonColor, zonas, muted, gridColor, axisColor, xFmt, vFmt }) => (
  <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, width, height }}>
    {(zonas || []).map((z, i) => {
      const x1 = geom.px(Math.max(z.min, geom.xMin)), x2 = geom.px(Math.min(z.max, geom.xMax));
      if (x2 <= PAD_L || x1 >= width - PAD_R) return null;
      return (
        <React.Fragment key={`z${i}`}>
          <View style={{ position: 'absolute', left: Math.max(PAD_L, x1), width: Math.max(0, Math.min(width - PAD_R, x2) - Math.max(PAD_L, x1)), top: PAD_T, height: geom.ih, backgroundColor: ZONA_COLORS[i % ZONA_COLORS.length], opacity: 0.08 }} />
          <Text style={{ position: 'absolute', left: Math.max(PAD_L, x1), width: Math.max(24, Math.min(width - PAD_R, x2) - Math.max(PAD_L, x1)), top: 0, textAlign: 'center', fontSize: 9, color: muted }}>{z.label}</Text>
        </React.Fragment>
      );
    })}
    {geom.yTicks.map((v, i) => (
      <React.Fragment key={`y${i}`}>
        <View style={{ position: 'absolute', left: PAD_L, right: PAD_R, top: geom.py(v), height: 1, backgroundColor: gridColor }} />
        <Text numberOfLines={1} style={{ position: 'absolute', left: 0, width: PAD_L - 6, top: geom.py(v) - 7, textAlign: 'right', fontSize: 10, color: muted }}>{vFmt(v)}</Text>
      </React.Fragment>
    ))}
    {geom.ticks.map((t, i) => (
      <React.Fragment key={`x${i}`}>
        <View style={{ position: 'absolute', top: PAD_T, height: geom.ih, left: geom.px(t.v), width: 1, backgroundColor: gridColor }} />
        <Text numberOfLines={1} style={{ position: 'absolute', bottom: 2, left: Math.max(0, Math.min(geom.px(t.v) - 26, width - 52)), width: 52, textAlign: 'center', fontSize: 10, color: muted }}>{t.label != null ? t.label : xFmt(t.v)}</Text>
      </React.Fragment>
    ))}
    <View style={{ position: 'absolute', left: PAD_L, right: PAD_R, top: height - PAD_B, height: 1, backgroundColor: axisColor }} />
    <Canvas style={{ position: 'absolute', top: 0, left: 0, width, height }}>
      <Path path={paths.area} color={color} opacity={0.16} />
      {paths.hasComparison ? <Path path={paths.comparisonLine} color={comparisonColor} strokeWidth={1.2} style="stroke" /> : null}
      <Path path={paths.line} color={color} strokeWidth={1.4} style="stroke" />
    </Canvas>
  </View>
));
CurvaFrame.displayName = 'CurvaFrame';

export function CurvaSkia({ pts, comparisonPts = null, comparisonColor = '#68758A', theme, isLight, color = '#4A90E2', height = 190, invertY = false, logX = false, xTicks = null, xFmt = (v) => String(Math.round(v)), vFmt = (v) => String(Math.round(v)), zonas = null, interactive = false, tip = null }) {
  const [width, setWidth] = useState(0);
  const [act, setAct] = useState(null);
  const geom = useMemo(() => {
    if (!width || !pts || pts.length < 1) return null;
    const all = [...(pts || []), ...(comparisonPts || [])];
    const xs = all.map((p) => p.x), vs = all.map((p) => p.v);
    let xMin = Math.min(...xs), xMax = Math.max(...xs);
    if (xMax === xMin) xMax = xMin * 2 || 2;
    let vMin = Math.min(...vs), vMax = Math.max(...vs);
    if (vMax === vMin) { vMax += 1; vMin = Math.max(0, vMin - 1); }
    const padY = (vMax - vMin) * 0.12;
    vMin -= padY; vMax += padY;
    const iw = width - PAD_L - PAD_R, ih = height - PAD_T - PAD_B;
    const lx = (x) => (logX ? Math.log(Math.max(x, 1e-6)) : x);
    const px = (x) => PAD_L + ((lx(x) - lx(xMin)) / (lx(xMax) - lx(xMin) || 1)) * iw;
    const py = (v) => (invertY
      ? PAD_T + ((v - vMin) / (vMax - vMin || 1)) * ih
      : PAD_T + ih - ((v - vMin) / (vMax - vMin || 1)) * ih);
    const yStep = (() => {
      const raw = (vMax - vMin) / 4;
      const mag = Math.pow(10, Math.floor(Math.log10(raw || 1)));
      const norm = raw / mag;
      return (norm >= 5 ? 10 : norm >= 2 ? 5 : norm >= 1 ? 2 : 1) * mag;
    })();
    const yTicks = [];
    for (let v = Math.ceil(vMin / yStep) * yStep; v <= vMax + 1e-9; v += yStep) yTicks.push(v);
    const ticks = xTicks
      ? xTicks.filter((t) => t.v >= xMin && t.v <= xMax)
      : [0, 0.5, 1].map((f) => ({ v: xMin + (xMax - xMin) * f, label: null }));
    return { px, py, ih, iw, yTicks, ticks, xMin, xMax, pxVals: xs.map(px) };
  }, [width, pts, comparisonPts, height, invertY, logX, xTicks]);
  const paths = useMemo(() => {
    if (!geom || !pts || !pts.length) return null;
    const line = Skia.Path.Make();
    const comparisonLine = Skia.Path.Make();
    const area = Skia.Path.Make();
    const xy = pts.map((p) => ({ X: geom.px(p.x), Y: geom.py(p.v) }));
    const comparisonXY = (comparisonPts || []).map((p) => ({ X: geom.px(p.x), Y: geom.py(p.v) }));
    xy.forEach(({ X, Y }, i) => { if (i === 0) { line.moveTo(X, Y); area.moveTo(X, Y); } else { line.lineTo(X, Y); area.lineTo(X, Y); } });
    if (xy.length > 1) {
      area.lineTo(xy[xy.length - 1].X, PAD_T + geom.ih);
      area.lineTo(xy[0].X, PAD_T + geom.ih);
      area.close();
    }
    comparisonXY.forEach(({ X, Y }, i) => { if (i === 0) comparisonLine.moveTo(X, Y); else comparisonLine.lineTo(X, Y); });
    return { line, area, xy, comparisonLine, hasComparison: comparisonXY.length > 1 };
  }, [geom, pts, comparisonPts]);
  if (!geom || !paths) return <View style={{ width: '100%', height }} onLayout={(e) => { const w = e.nativeEvent.layout.width; if (w > 0) setWidth(w); }} />;
  const pick = (xpx) => {
    if (!geom) return;
    let bi = 0, bd = Infinity;
    geom.pxVals.forEach((X, i) => { const d = Math.abs(X - xpx); if (d < bd) { bd = d; bi = i; } });
    setAct(bi);
  };
  const actPt = act != null && pts[act] ? pts[act] : null;
  return (
    <View
      style={{ width: '100%', height }}
      onLayout={(e) => { const w = e.nativeEvent.layout.width; if (w > 0) setWidth(w); }}
      onStartShouldSetResponder={() => interactive}
      onResponderMove={(e) => interactive && pick(e.nativeEvent.locationX)}
      onResponderStart={(e) => interactive && pick(e.nativeEvent.locationX)}
      onResponderRelease={() => {}}
    >
      <CurvaFrame
        geom={geom}
        paths={paths}
        width={width}
        height={height}
        color={color}
        comparisonColor={comparisonColor}
        zonas={zonas}
        muted={theme.muted}
        gridColor={isLight ? 'rgba(21,34,56,0.10)' : 'rgba(143,168,200,0.14)'}
        axisColor={isLight ? 'rgba(21,34,56,0.28)' : 'rgba(143,168,200,0.25)'}
        xFmt={xFmt}
        vFmt={vFmt}
      />
      {/* Marcador + tooltip como overlays ligeros: al mover el dedo solo se
          re-pintan estos, el canvas memoizado queda intacto. El tooltip va
          AL LADO del punto (como en Detalles): a la derecha del dedo y, si
          se sale por el borde derecho, flip a la izquierda. */}
      {actPt && (() => {
        const pxv = geom.px(actPt.x), pyv = geom.py(actPt.v);
        let tipLeft = pxv + 12;                        // intento: a la derecha del punto
        if (tipLeft + TIP_W > width - 4) {             // no cabe por la derecha…
          tipLeft = pxv - 12 - TIP_W;                  // …flip a la izquierda
        }
        tipLeft = Math.max(4, Math.min(tipLeft, width - TIP_W - 4));
        const tipTop = Math.max(4, Math.min(pyv - 21, height - 50));
        return (
          <>
            <View pointerEvents="none" style={{ position: 'absolute', top: PAD_T, height: geom.ih, left: pxv - 0.5, width: 1, backgroundColor: isLight ? 'rgba(21,34,56,0.5)' : 'rgba(255,255,255,0.55)' }} />
            <View pointerEvents="none" style={{ position: 'absolute', left: pxv - 5, top: pyv - 5, width: 10, height: 10, borderRadius: 5, backgroundColor: color, borderWidth: 1.5, borderColor: theme.background }} />
            <View pointerEvents="none" style={[cp.tip, { backgroundColor: theme.card, borderColor: theme.border, left: tipLeft, top: tipTop }]}>
              <Text style={{ color: theme.muted, fontSize: 10 }}>{xFmt(actPt.x)}</Text>
              <Text style={{ color: theme.text, fontSize: 12, fontWeight: '800' }}>{tip && tip.v ? tip.v(actPt) : vFmt(actPt.v)}</Text>
            </View>
          </>
        );
      })()}
    </View>
  );
}

/* ── Tarjeta de gráfica con botón de pantalla completa (como Detalles) ── */
export function ChartCard({ title, subtitle, theme, onExpand, children }) {
  return (
    <View style={[cp.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
      <View style={cp.cardHeader}>
        <View style={{ flex: 1 }}>
          <Text style={[cp.cardTitle, { color: theme.text }]}>{title}</Text>
          {!!subtitle && <Text style={{ color: theme.muted, fontSize: 10, marginTop: 2 }}>{subtitle}</Text>}
        </View>
        {!!onExpand && (
          <TouchableOpacity onPress={onExpand} style={cp.expandBtn} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <Ionicons name="expand-outline" size={18} color="#8FA8C8" />
          </TouchableOpacity>
        )}
      </View>
      {children}
    </View>
  );
}

/* ── Modal de pantalla completa para una gráfica ── */
export function FullChartModal({ visible, onClose, title, theme, children }) {
  const insets = useSafeAreaInsets();
  const [size, setSize] = useState({ width: 0, height: 0 });
  useEffect(() => {
    if (!visible) return undefined;
    ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_LEFT).catch(() => {});
    return () => { ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP).catch(() => {}); };
  }, [visible]);
  return (
    <Modal visible={visible} animationType="fade" onRequestClose={onClose}>
      <View
        onLayout={(e) => setSize({ width: e.nativeEvent.layout.width, height: e.nativeEvent.layout.height })}
        style={{ flex: 1, backgroundColor: theme.background, paddingTop: Math.max(36, insets.top + 12), paddingLeft: 14 + insets.left, paddingRight: 14 + insets.right, paddingBottom: Math.max(10, insets.bottom) }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
          <Text style={{ color: theme.text, fontSize: 17, fontWeight: '800', flex: 1 }} numberOfLines={1}>{title}</Text>
          <TouchableOpacity onPress={onClose}><Ionicons name="close" size={26} color="#8FA8C8" /></TouchableOpacity>
        </View>
        {children(Math.max(180, size.height - 70))}
      </View>
      <SystemBars />
    </Modal>
  );
}

/* ── Tabla MEJORES ESFUERZOS por distancia ── */
export function TablaEsfuerzos({ rows, actividad, theme }) {
  const isCycling = actividad === 'Ciclismo';
  return (
    <View>
      <View style={[cp.tRow, cp.tHead, { backgroundColor: theme.input }]}>
        <Text style={[cp.tCell, { width: 64, color: theme.muted, fontWeight: '800' }]}>Dist.</Text>
        <Text style={[cp.tCell, { flex: 1, color: theme.muted, fontWeight: '800' }]}>Tiempo</Text>
        <Text style={[cp.tCell, { flex: 1, color: theme.muted, fontWeight: '800' }]}>{isCycling ? 'km/h' : '/km'}</Text>
      </View>
      {rows.map((r) => (
        <View key={r.d} style={[cp.tRow, { borderBottomColor: theme.border }]}>
          <Text style={[cp.tCell, { width: 64, color: theme.text, fontWeight: '700' }]}>{labelDist(r.d)}</Text>
          <Text style={[cp.tCell, { flex: 1, color: theme.text, fontWeight: '700' }]}>{fmtTiempo(r.t)}</Text>
          <Text style={[cp.tCell, { flex: 1, color: theme.text }]}>{isCycling ? `${r.speed.toFixed(1)}` : fmtPace(r.pace)}</Text>
        </View>
      ))}
    </View>
  );
}

const cp = StyleSheet.create({
  card: { borderRadius: 12, borderWidth: 1, marginBottom: 12, overflow: 'hidden' },
  cardHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 12, paddingTop: 10, paddingBottom: 6 },
  cardTitle: { fontSize: 13, fontWeight: '700' },
  expandBtn: { padding: 6 },
  tip: { position: 'absolute', width: TIP_W, borderRadius: 8, borderWidth: 1, paddingHorizontal: 8, paddingVertical: 5, gap: 2 },
  tRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, paddingHorizontal: 6, borderBottomWidth: 1 },
  tHead: { borderBottomWidth: 0, borderRadius: 8 },
  tCell: { fontSize: 12, textAlign: 'center' },
});
