// components/WeatherPanel.js
// ─────────────────────────────────────────────────────────────
// PESTAÑA DEL TIEMPO (SocialScreen) — estilo app del tiempo del iPad.
// REDISEÑO VISUAL integrado con la barra superior estilo WhatsApp de
// SocialScreen: chips de acción tipo "filtros" de WhatsApp, tarjeta principal
// con el color y los efectos del cielo (sol, noche con estrellas, lluvia,
// nieve, tormenta…), tarjetas con la paleta del chat y animaciones suaves.
// La LÓGICA es la misma que antes (Open-Meteo, geocoding, GPS protegido,
// caché y favoritos en AsyncStorage, pull-to-refresh).
// Datos EXTERNOS y gratuitos, sin clave, sin nuestro servidor ni Firestore:
//   · Pronóstico:  api.open-meteo.com  (actual + 24 h + 7 días, métrico,
//     timezone=auto) — https://open-meteo.com
//   · Búsqueda de ciudad: geocoding-api.open-meteo.com
//   · Nombre de la ubicación GPS: api.bigdatacloud.net (reverse, sin clave)
// UBICACIÓN: se guarda en AsyncStorage (tj_weather_loc) para NO usar el GPS
// en cada apertura; también se puede escribir a mano con el buscador.
// CACHÉ del último pronóstico (tj_weather_cache): al abrir se pinta al
// instante y se refresca en segundo plano (pull-to-refresh incluido).
// Prop opcional `topPad`: alto de la barra superior de SocialScreen (para que
// el contenido empiece justo debajo de ella).
// ─────────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, Animated, Easing, Pressable, RefreshControl, ScrollView, StyleSheet, Text,
  TextInput, View, useColorScheme,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
// expo-location con require PROTEGIDO (patrón AudioLib de SocialScreen):
// un OTA no puede añadir módulos nativos; si el binario no trae
// expo-location (build antigua), la app no reventa — solo no habrá GPS.
let Location = null;
try { Location = require('expo-location'); } catch (e) { Location = null; }
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';
import { getThemeColors, useAppSettings, L } from '../services/appSettings';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const BLUE = '#4A90E2';
const K_LOC = 'tj_weather_loc_v1';
const K_CACHE = 'tj_weather_cache_v1';
const K_FAVS = 'tj_weather_favs_v1';   // ubicaciones guardadas [{ lat, lon, nombre }]
const TTL_MS = 20 * 60 * 1000;   // refresco automático si el caché supera 20 min

// WMO weather codes → icono (MaterialCommunityIcons) + descripción es/en
const WMO = {
  0:  ['weather-sunny', 'Despejado', 'Clear sky'],
  1:  ['weather-partlycloudy', 'Mayormente despejado', 'Mainly clear'],
  2:  ['weather-partlycloudy', 'Parcialmente nublado', 'Partly cloudy'],
  3:  ['weather-cloudy', 'Nublado', 'Overcast'],
  45: ['weather-fog', 'Niebla', 'Fog'],
  48: ['weather-fog', 'Niebla helada', 'Rime fog'],
  51: ['weather-partly-rainy', 'Llovizna ligera', 'Light drizzle'],
  53: ['weather-partly-rainy', 'Llovizna', 'Drizzle'],
  55: ['weather-pouring', 'Llovizna intensa', 'Dense drizzle'],
  56: ['weather-snowy-rainy', 'Llovizna helada', 'Freezing drizzle'],
  57: ['weather-snowy-rainy', 'Llovizna helada intensa', 'Freezing drizzle'],
  61: ['weather-rainy', 'Lluvia ligera', 'Slight rain'],
  63: ['weather-rainy', 'Lluvia', 'Rain'],
  65: ['weather-pouring', 'Lluvia intensa', 'Heavy rain'],
  66: ['weather-snowy-rainy', 'Lluvia helada', 'Freezing rain'],
  67: ['weather-snowy-rainy', 'Lluvia helada intensa', 'Freezing rain'],
  71: ['weather-snowy', 'Nieve ligera', 'Slight snow'],
  73: ['weather-snowy', 'Nieve', 'Snow'],
  75: ['weather-snowy', 'Nieve intensa', 'Heavy snow'],
  77: ['weather-snowy', 'Granos de nieve', 'Snow grains'],
  80: ['weather-partly-rainy', 'Chubascos ligeros', 'Light showers'],
  81: ['weather-rainy', 'Chubascos', 'Showers'],
  82: ['weather-pouring', 'Chubascos fuertes', 'Violent showers'],
  85: ['weather-snowy', 'Chubascos de nieve', 'Snow showers'],
  86: ['weather-snowy', 'Chubascos de nieve', 'Snow showers'],
  95: ['weather-lightning', 'Tormenta', 'Thunderstorm'],
  96: ['weather-hail', 'Tormenta con granizo', 'Thunderstorm, hail'],
  99: ['weather-hail', 'Tormenta con granizo', 'Thunderstorm, hail'],
};
const wmoIcon = (code, isDay) => {
  const e = WMO[code];
  if (!e) return 'weather-cloudy';
  if (!isDay) {
    if (e[0] === 'weather-sunny') return 'weather-night';
    if (e[0] === 'weather-partlycloudy') return 'weather-night-partly-cloudy';
  }
  return e[0];
};
const wmoTxt = (code) => {
  const e = WMO[code];
  return e ? (L(e[1], e[2])) : '—';
};

const UV_NIVELES = [
  [2, ['Bajo', 'Low']], [5, ['Moderado', 'Moderate']], [7, ['Alto', 'High']],
  [10, ['Muy alto', 'Very high']], [11, ['Extremo', 'Extreme']],
];
const uvNivel = (uv) => {
  const e = UV_NIVELES.find(([max]) => uv <= max);
  return e ? L(e[1][0], e[1][1]) : '—';
};
const CARDINALES = { es: ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'], en: ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'] };
const cardinal = (deg, lang) => {
  if (!Number.isFinite(deg)) return '';
  const lista = CARDINALES[lang || 'es'] || CARDINALES.es;
  return lista[Math.round(deg / 45) % 8];
};

const p2 = (n) => String(n).padStart(2, '0');

// Posición ROBUSTA: iOS lanza kCLErrorDomain 0 (posición aún no lista) la
// primera vez — se usa la última conocida y se reintenta hasta 3 veces.
function obtenerPosicion() {
  let ultima = null;
  try { ultima = Location.getLastKnownPositionAsync(); } catch (e) {}
  return ultima
    .then((ult) => {
      if (ult && Date.now() - ult.timestamp < 10 * 60 * 1000) return ult;
      return (async () => {
        for (let i = 0; i < 3; i++) {
          try {
            const pos = await Location.getCurrentPositionAsync({
              accuracy: Location.Accuracy.Balanced, maxAge: 60000, timeout: 15000,
            });
            return pos;
          } catch (e) {
            await new Promise((r) => setTimeout(r, 1500));
          }
        }
        if (ult) return ult;   // mejor vieja que ninguna
        throw new Error(L('No se pudo obtener tu ubicación. Reintenta o busca tu ciudad a mano.', 'Could not get your location. Retry or search your city manually.'));
      })();
    });
}


/* ════════════════════════════════════════════════════════════════════════════
   REDISEÑO: paleta + componentes visuales / animados (solo visuales)
   ════════════════════════════════════════════════════════════════════════════ */
const WA = '#00A884';        // verde de acento (el mismo del chat)
const AMBER = '#F5A623';

// Paleta del chat (misma que SocialScreen) en modo día / noche
const paleta = (isLight) => ({
  bg: isLight ? '#F0F2F5' : '#111B21',
  card: isLight ? '#FFFFFF' : '#1F2C34',
  tile: isLight ? '#F5F6F6' : '#111B21',
  input: isLight ? '#FFFFFF' : '#202C33',
  txt: isLight ? '#111B21' : '#E9EDEF',
  mut: isLight ? '#667781' : '#8696A0',
  border: isLight ? '#E9EDEF' : '#2A3942',
  ico: isLight ? '#2F6FB5' : '#E8EDF5',
});

// Aparece con fundido + deslizamiento (entrada escalonada)
function FadeIn({ delay = 0, children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, { toValue: 1, duration: 420, delay, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [v, delay]);
  return (
    <Animated.View style={[style, { opacity: v, transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [16, 0] }) }] }]}>
      {children}
    </Animated.View>
  );
}

// Zona pulsable con efecto muelle
function Press({ onPress, style, children, hitSlop, disabled }) {
  const sc = useRef(new Animated.Value(1)).current;
  const to = (v) => Animated.spring(sc, { toValue: v, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <Pressable onPress={onPress} disabled={disabled} hitSlop={hitSlop} onPressIn={() => to(0.95)} onPressOut={() => to(1)}>
      <Animated.View style={[style, { transform: [{ scale: sc }] }]}>{children}</Animated.View>
    </Pressable>
  );
}

// Valor 0→1→0 suave
function usePingPong(duration) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(v, { toValue: 1, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [v, duration]);
  return v;
}

// Número que "cuenta" hasta su valor (temperatura)
function CountUp({ value, style, suffix = '' }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    const a = new Animated.Value(0);
    const id = a.addListener(({ value: v }) => setN(Math.round(v)));
    Animated.timing(a, { toValue: value, duration: 900, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
    return () => { a.removeListener(id); a.stopAnimation(); };
  }, [value]);
  return <Text style={style}>{n}{suffix}</Text>;
}

/* ════════════════════════════════════════════════════════════════════════════
   FONDO DEL CIELO estilo app del tiempo de Apple:
   · degradado propio para cada situación (despejado, parcial, nublado, lluvia,
     tormenta, nieve, niebla) y para cada momento del día (alba, día, ocaso, noche)
   · el sol (o la luna) recorre un arco según la hora local del lugar
   · nubes que derivan despacio, estrellas que titilan de noche, lluvia fina,
     copos de nieve, bancos de niebla y relámpagos en las tormentas
   Todas las animaciones usan UN solo bucle lineal (reloj) por elemento y
   dientes de sierra calculados con interpolate: no se paran nunca.
   ════════════════════════════════════════════════════════════════════════════ */

// Reloj lineal 0→1 en bucle (nativo, sin pausas intermedias)
function useReloj(duration) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.timing(v, { toValue: 1, duration, easing: Easing.linear, useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [v, duration]);
  return v;
}

// Diente de sierra: k ciclos por vuelta del reloj, con fase phi (0<phi<1),
// mapeado de `a` a `b`. Se reinicia solo, sin saltos visibles.
function serra(k, phi, a, b) {
  const inR = [0], outR = [phi];
  for (let n = 1; n <= k; n++) {
    const t = (n - phi) / k;
    if (t >= 1) break;
    inR.push(t, t); outR.push(1, 0);
  }
  inR.push(1); outR.push(phi);
  return { inputRange: inR, outputRange: outR.map((o) => a + o * (b - a)) };
}
// Onda suave periódica (k ciclos por vuelta) con muestreo fino
function onda(k, phi, a, b, n = 24) {
  const inR = [], outR = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    inR.push(t);
    outR.push(a + ((Math.sin(2 * Math.PI * (k * t + phi)) + 1) / 2) * (b - a));
  }
  return { inputRange: inR, outputRange: outR };
}

// Tipo de tiempo a partir del código WMO
function tipoDeTiempo(code) {
  if ([95, 96, 99].includes(code)) return 'tormenta';
  if ([71, 73, 75, 77, 85, 86, 56, 57, 66, 67].includes(code)) return 'nieve';
  if ([51, 53, 55, 61, 63, 65, 80, 81, 82].includes(code)) return 'lluvia';
  if ([45, 48].includes(code)) return 'niebla';
  if (code === 3) return 'nublado';
  if (code === 2) return 'parcial';
  return 'despejado';   // 0 y 1
}

// Degradados (arriba → abajo) por situación y momento del día
const DEGRADADOS = {
  despejado: { dia: ['#2A7BE4', '#5FAEF2', '#9CD0F7'], alba: ['#3C4C94', '#B97C9A', '#F4B382'], ocaso: ['#2B3578', '#B8607A', '#F08C5A'], noche: ['#080E26', '#16224A', '#2C3D75'] },
  parcial:   { dia: ['#4A7FB8', '#7FA6CC', '#B0C6DA'], alba: ['#3F4C88', '#A5809A', '#E6AD86'], ocaso: ['#323A72', '#A66A7E', '#E29A74'], noche: ['#0D1430', '#1C2848', '#34426A'] },
  nublado:   { dia: ['#5F7389', '#8497AA', '#AEBBC7'], alba: ['#4C5670', '#8F8A9B', '#C9AE9A'], ocaso: ['#444B66', '#86788A', '#BE9A8C'], noche: ['#161C2A', '#262F43', '#3C485E'] },
  lluvia:    { dia: ['#42566C', '#62768C', '#8497A9'], alba: ['#434A66', '#6E7790', '#98A0B0'], ocaso: ['#3B425E', '#6A6F88', '#939AAE'], noche: ['#0F1623', '#1C2638', '#2F3D54'] },
  tormenta:  { dia: ['#2D3345', '#454D66', '#636C85'], alba: ['#2C3144', '#454B63', '#646B82'], ocaso: ['#2B3043', '#444A62', '#626982'], noche: ['#0A0D1A', '#171C32', '#2A3150'] },
  nieve:     { dia: ['#7390B0', '#9FB6CE', '#CBDAE8'], alba: ['#6A7C9C', '#A0AEC4', '#D2D8E4'], ocaso: ['#65759A', '#9AA3BE', '#CCD0E0'], noche: ['#2A374D', '#46566F', '#6A7B94'] },
  niebla:    { dia: ['#8793A0', '#A6B0BA', '#C8CFD6'], alba: ['#86878F', '#A8A5AB', '#CFC4C4'], ocaso: ['#80808D', '#A39FAA', '#CBBFC3'], noche: ['#2F3841', '#47515B', '#68727C'] },
};

// Degradado a base de bandas (sin dependencias nuevas)
function Gradiente({ stops }) {
  // Degradado REAL con SVG (react-native-svg ya está en la app): la versión
  // anterior apilaba 18 franjas con flex:1 y el redondeo de píxeles entre
  // ellas pintaba hairlines claras por todo el héroe (más visibles tras un
  // re-layout, p. ej. volviendo del chat con un mensaje seleccionado).
  return (
    <Svg style={StyleSheet.absoluteFill} preserveAspectRatio="none">
      <Defs>
        <LinearGradient id="tjCieloHero" x1="0" y1="0" x2="0" y2="1">
          {stops.map((col, i) => (
            <Stop key={i} offset={`${(i / (stops.length - 1)) * 100}%`} stopColor={col} />
          ))}
        </LinearGradient>
      </Defs>
      <Rect x="0" y="0" width="100%" height="100%" fill="url(#tjCieloHero)" />
    </Svg>
  );
}

// Nube que deriva despacio de un lado a otro (formada por círculos)
function Nube({ w, y, escala, op, color, dur, phi }) {
  const v = useReloj(dur);
  const ancho = 130 * escala;
  const cfg = serra(1, phi, -ancho - 10, w + 10);
  return (
    <Animated.View
      pointerEvents="none"
      needsOffscreenAlphaCompositing
      style={{ position: 'absolute', top: y, left: 0, width: ancho, height: 56 * escala, opacity: op, transform: [{ translateX: v.interpolate(cfg) }] }}
    >
      <View style={{ position: 'absolute', left: 0, bottom: 0, width: ancho, height: 30 * escala, borderRadius: 15 * escala, backgroundColor: color }} />
      <View style={{ position: 'absolute', left: 20 * escala, top: 10 * escala, width: 40 * escala, height: 40 * escala, borderRadius: 20 * escala, backgroundColor: color }} />
      <View style={{ position: 'absolute', left: 52 * escala, top: 0, width: 52 * escala, height: 52 * escala, borderRadius: 26 * escala, backgroundColor: color }} />
      <View style={{ position: 'absolute', left: 92 * escala, top: 16 * escala, width: 32 * escala, height: 32 * escala, borderRadius: 16 * escala, backgroundColor: color }} />
    </Animated.View>
  );
}

// Estrella que titila
function Estrella({ i, H, reloj, op }) {
  const cfg = onda(1, ((i * 37) % 100) / 100, 0.15 * op, 0.95 * op);
  const t = i % 3 === 0 ? 4 : 3;
  return (
    <Animated.View pointerEvents="none" style={{
      position: 'absolute', left: `${(i * 53 + 11) % 94}%`, top: 8 + ((i * 41) % Math.round(H * 0.5)),
      width: t, height: t, borderRadius: t / 2, backgroundColor: '#FFFFFF', opacity: reloj.interpolate(cfg),
    }} />
  );
}

// Gota de lluvia: fina y tenue
function Gota({ i, H, reloj, fuerte }) {
  const k = 3 + (i % 2);
  const phi = ((i * 37) % 100) / 100 + 0.005;
  const cfg = serra(k, phi, -14, H + 6);
  return (
    <Animated.View pointerEvents="none" style={{
      position: 'absolute', left: `${(i * 53 + 7) % 96}%`, top: 0, width: 1.5, height: 11, borderRadius: 1,
      backgroundColor: fuerte ? 'rgba(210,225,255,0.34)' : 'rgba(255,255,255,0.26)',
      transform: [{ translateY: reloj.interpolate(cfg) }, { rotate: '10deg' }],
    }} />
  );
}

// Copo de nieve: cae despacio y se balancea
function Copo({ i, H, reloj }) {
  const k = 1 + (i % 2);
  const phi = ((i * 37) % 100) / 100 + 0.005;
  const cfgY = serra(k, phi, -10, H + 6);
  const cfgX = onda(k, phi, -9, 9);
  const t = i % 3 === 0 ? 6 : 4;
  return (
    <Animated.View pointerEvents="none" style={{
      position: 'absolute', left: `${(i * 47 + 5) % 94}%`, top: 0, width: t, height: t, borderRadius: t / 2,
      backgroundColor: 'rgba(255,255,255,0.7)',
      transform: [{ translateY: reloj.interpolate(cfgY) }, { translateX: reloj.interpolate(cfgX) }],
    }} />
  );
}

// Banco de niebla que se desliza
function Niebla({ y, w, dur, ancho, op }) {
  const v = useReloj(dur);
  const cfg = onda(1, 0, -w * 0.25, w * 0.25);
  return (
    <Animated.View pointerEvents="none" style={{
      position: 'absolute', top: y, left: -w * 0.3, width: w * ancho, height: 40, borderRadius: 20,
      backgroundColor: 'rgba(255,255,255,1)', opacity: op, transform: [{ translateX: v.interpolate(cfg) }],
    }} />
  );
}

// Sol / luna con halo que respira, sobre un arco según la hora
function Astro({ luna, frac, H, w, op, alba }) {
  const halo = usePingPong(3200);
  const horizonte = H * 0.64, cima = H * 0.16;
  const y = horizonte - Math.sin(Math.PI * frac) * (horizonte - cima);
  const x = w * (0.14 + 0.72 * frac);
  const disco = luna ? '#F3F0DD' : alba ? '#FFC98F' : '#FFF3BF';
  const glowC = luna ? '#DCE6FF' : alba ? '#FF9B5E' : '#FFE07A';
  const tam = luna ? 40 : 46;
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: x - 70, top: y - 70, width: 140, height: 140, alignItems: 'center', justifyContent: 'center', opacity: op }}>
      <Animated.View style={{
        position: 'absolute', width: 140, height: 140, borderRadius: 70, backgroundColor: glowC,
        opacity: halo.interpolate({ inputRange: [0, 1], outputRange: [luna ? 0.1 : 0.2, luna ? 0.2 : 0.38] }),
        transform: [{ scale: halo.interpolate({ inputRange: [0, 1], outputRange: [0.85, 1.1] }) }],
      }} />
      <View style={{ position: 'absolute', width: 92, height: 92, borderRadius: 46, backgroundColor: glowC, opacity: luna ? 0.14 : 0.3 }} />
      <View style={{ width: tam, height: tam, borderRadius: tam / 2, backgroundColor: disco }}>
        {luna && (
          <>
            <View style={{ position: 'absolute', left: 8, top: 10, width: 8, height: 8, borderRadius: 4, backgroundColor: '#D6D2B8' }} />
            <View style={{ position: 'absolute', left: 22, top: 22, width: 11, height: 11, borderRadius: 6, backgroundColor: '#DAD6BE' }} />
            <View style={{ position: 'absolute', left: 20, top: 7, width: 5, height: 5, borderRadius: 3, backgroundColor: '#D6D2B8' }} />
          </>
        )}
      </View>
    </View>
  );
}

// Fondo completo de la tarjeta principal
function FondoCielo({ tipo, fase, cover, frac, H }) {
  const [w, setW] = useState(360);
  const noche = fase === 'noche';
  const stops = (DEGRADADOS[tipo] || DEGRADADOS.despejado)[fase] || (DEGRADADOS[tipo] || DEGRADADOS.despejado).dia;
  const reloj = useReloj(tipo === 'nieve' ? 9000 : 3000);
  const relojEstrellas = useReloj(4200);
  const relojRayo = useReloj(6500);
  const cielosAbiertos = tipo === 'despejado' || tipo === 'parcial';
  // Visibilidad del sol/luna según la nubosidad y el tipo de tiempo
  const opAstro = tipo === 'despejado' ? (cover > 70 ? 0.5 : 1) : tipo === 'parcial' ? 0.6 : 0.0;
  // Nubes: cantidad y aspecto
  const nNubes = tipo === 'despejado' ? (cover > 25 ? 1 : 0) : tipo === 'parcial' ? 3 : 4;
  const colorNube = noche ? '#AAB7CC' : tipo === 'tormenta' ? '#8D97AA' : tipo === 'lluvia' || tipo === 'nublado' ? '#D3DBE5' : '#FFFFFF';
  const opNube = noche ? 0.2 : tipo === 'tormenta' ? 0.5 : tipo === 'nublado' || tipo === 'lluvia' ? 0.5 : 0.42;
  const NUBES = [
    { y: H * 0.10, escala: 1.1, dur: 70000, phi: 0.12 },
    { y: H * 0.30, escala: 0.8, dur: 95000, phi: 0.5 },
    { y: H * 0.46, escala: 1.3, dur: 60000, phi: 0.73 },
    { y: H * 0.20, escala: 0.9, dur: 110000, phi: 0.9 },
  ];
  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none" onLayout={(e) => setW(e.nativeEvent.layout.width || 360)}>
      <Gradiente stops={stops} />
      {noche && cielosAbiertos && Array.from({ length: 18 }).map((_, i) => (
        <Estrella key={i} i={i} H={H} reloj={relojEstrellas} op={Math.max(0.2, 1 - cover / 100)} />
      ))}
      {opAstro > 0 && <Astro luna={noche} frac={frac} H={H} w={w} op={opAstro} alba={fase === 'alba' || fase === 'ocaso'} />}
      {NUBES.slice(0, nNubes).map((n, i) => (
        <Nube key={i} w={w} y={n.y} escala={n.escala} op={opNube} color={colorNube} dur={n.dur} phi={n.phi} />
      ))}
      {tipo === 'niebla' && (
        <>
          <Niebla y={H * 0.22} w={w} dur={26000} ancho={1.6} op={0.16} />
          <Niebla y={H * 0.42} w={w} dur={34000} ancho={1.8} op={0.14} />
          <Niebla y={H * 0.62} w={w} dur={30000} ancho={1.5} op={0.16} />
        </>
      )}
      {(tipo === 'lluvia' || tipo === 'tormenta') && Array.from({ length: tipo === 'tormenta' ? 16 : 13 }).map((_, i) => (
        <Gota key={i} i={i} H={H} reloj={reloj} fuerte={tipo === 'tormenta'} />
      ))}
      {tipo === 'nieve' && Array.from({ length: 16 }).map((_, i) => <Copo key={i} i={i} H={H} reloj={reloj} />)}
      {tipo === 'tormenta' && (
        <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, {
          backgroundColor: '#FFFFFF',
          opacity: relojRayo.interpolate({ inputRange: [0, 0.55, 0.56, 0.6, 0.62, 0.68, 1], outputRange: [0, 0, 0.4, 0, 0.26, 0, 0] }),
        }]} />
      )}
    </View>
  );
}

const HERO_H = 330;

// Tarjeta principal: el cielo cambia según el tiempo y la hora del día
function Hero({ ahora, nombre, p }) {
  const c = ahora.c;
  const d0 = ahora.dias[0];
  const float = usePingPong(2400);
  const tipo = tipoDeTiempo(c.weather_code);
  const hhmm = (s) => { if (!s || s.indexOf(':') < 0) return null; const [h, m] = s.split(':').map(Number); return h * 60 + m; };
  const m = ahora.tzNow.getHours() * 60 + ahora.tzNow.getMinutes();
  const sr = hhmm(d0?.amanecer), ss = hhmm(d0?.atardecer);
  let fase = c.is_day ? 'dia' : 'noche';
  let frac = 0.5;
  if (sr != null && ss != null && ss > sr) {
    if (Math.abs(m - sr) <= 40) fase = 'alba';
    else if (Math.abs(m - ss) <= 40) fase = 'ocaso';
    else if (m > sr && m < ss) fase = 'dia';
    else fase = 'noche';
    if (fase === 'noche') {
      const largo = (24 * 60 - ss) + sr;
      const trans = m >= ss ? m - ss : m + (24 * 60 - ss);
      frac = Math.max(0, Math.min(1, trans / largo));
    } else {
      frac = Math.max(0, Math.min(1, (m - sr) / (ss - sr)));
    }
  }
  const chip = (icon, txt) => (
    <View style={st.heroChip}>
      <MaterialCommunityIcons name={icon} size={13} color="#FFFFFFE6" />
      <Text style={st.heroChipTxt}>{txt}</Text>
    </View>
  );
  return (
    <View style={[st.hero, { minHeight: HERO_H }]}>
      <FondoCielo tipo={tipo} fase={fase} cover={c.cloud_cover ?? 0} frac={frac} H={HERO_H} />
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, justifyContent: 'center' }}>
        <Ionicons name="location" size={14} color="#FFFFFFD9" />
        <Text style={st.locNombre} numberOfLines={1}>{nombre || ''}</Text>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 4 }}>
        <Animated.View style={{ transform: [{ translateY: float.interpolate({ inputRange: [0, 1], outputRange: [4, -4] }) }] }}>
          <MaterialCommunityIcons name={wmoIcon(c.weather_code, c.is_day)} size={78} color="#FFFFFF" />
        </Animated.View>
        <CountUp value={Math.round(c.temperature_2m)} suffix="°" style={st.tempGrande} />
      </View>
      <Text style={st.desc}>{wmoTxt(c.weather_code)}</Text>
      {!!d0 && (
        <View style={st.heroChips}>
          {chip('arrow-up', `${L('Máx', 'H')} ${Math.round(d0.max)}°`)}
          {chip('arrow-down', `${L('Mín', 'L')} ${Math.round(d0.min)}°`)}
          {chip('thermometer', `${L('Sensación', 'Feels')} ${Math.round(c.apparent_temperature)}°`)}
        </View>
      )}
    </View>
  );
}

// Chip de acción estilo "filtro" de WhatsApp
function Chip({ icon, label, on, onPress, p }) {
  return (
    <Press onPress={onPress} style={[st.chip, { backgroundColor: on ? WA + '2E' : p.card, borderColor: on ? WA : p.border }]}>
      <Ionicons name={icon} size={15} color={on ? WA : p.mut} />
      <Text style={[st.chipTxt, { color: on ? WA : p.txt }]}>{label}</Text>
    </Press>
  );
}

// Fila de ciudad (resultados de búsqueda y guardadas), como un chat de la lista
function FilaLugar({ p, titulo, sub, activo, onPress, derecha, last }) {
  return (
    <View style={[st.lugarFila, !last && { borderBottomWidth: 1, borderBottomColor: p.border }]}>
      <Pressable onPress={onPress} style={({ pressed }) => [st.lugarMain, pressed && { backgroundColor: WA + '12' }]}>
        <View style={[st.lugarAvatar, { backgroundColor: WA + '22' }]}>
          <Ionicons name="location" size={17} color={WA} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ color: p.txt, fontWeight: '700' }} numberOfLines={1}>{titulo}</Text>
          {!!sub && <Text style={{ color: p.mut, fontSize: 12 }} numberOfLines={1}>{sub}</Text>}
        </View>
        {activo && <Ionicons name="checkmark-circle" size={17} color={WA} />}
      </Pressable>
      {derecha}
    </View>
  );
}

// Tarjeta con título (misma paleta del chat)
function Tarjeta({ p, titulo, icono, children, delay = 0 }) {
  return (
    <FadeIn delay={delay}>
      <View style={[st.tarjeta, { backgroundColor: p.card, borderColor: p.border }]}>
        <View style={st.tarjetaHead}>
          <MaterialCommunityIcons name={icono} size={14} color={WA} />
          <Text style={[st.tarjetaTitulo, { color: p.mut }]}>{titulo}</Text>
        </View>
        {children}
      </View>
    </FadeIn>
  );
}

// Barra de rango de un día (se llena al aparecer)
function BarraRango({ lo, hi, p, hoy }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, { toValue: 1, duration: 800, delay: 250, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
  }, [v]);
  return (
    <View style={[st.diaBarra, { backgroundColor: p.border }]}>
      <Animated.View style={{
        position: 'absolute', top: 0, bottom: 0, borderRadius: 3, backgroundColor: hoy ? WA : AMBER,
        left: `${lo}%`, width: v.interpolate({ inputRange: [0, 1], outputRange: ['0%', `${Math.max(6, hi - lo)}%`] }),
      }} />
    </View>
  );
}

// Baldosa de detalle con icono en círculo de color
function Tile({ p, icono, color, label, valor, extra, delay = 0 }) {
  return (
    <FadeIn delay={delay} style={st.tileWrap}>
      <View style={[st.tile, { backgroundColor: p.tile }]}>
        <View style={st.tileHead}>
          <View style={[st.tileIco, { backgroundColor: color + '26' }]}>
            <MaterialCommunityIcons name={icono} size={13} color={color} />
          </View>
          <Text style={[st.tileLbl, { color: p.mut }]} numberOfLines={1}>{label}</Text>
        </View>
        <Text style={[st.tileVal, { color: p.txt }]} numberOfLines={1}>{valor}</Text>
        {!!extra ? <Text style={[st.tileExtra, { color: p.mut }]} numberOfLines={1}>{extra}</Text> : null}
      </View>
    </FadeIn>
  );
}

// Estado central (cargando / sin ubicación / error)
function Centro({ children }) {
  return <View style={st.centro}>{children}</View>;
}
function SolPulsante({ color }) {
  const v = usePingPong(1200);
  return (
    <Animated.View style={{ transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1.1] }) }] }}>
      <MaterialCommunityIcons name="weather-partly-cloudy" size={58} color={color} />
    </Animated.View>
  );
}

function safeJson(s, d) {
  try { const v = JSON.parse(s); return v == null ? d : v; } catch (e) { return d; }
}

export default function WeatherPanel({ topPad } = {}) {
  const insets = useSafeAreaInsets();
  const settings = useAppSettings();   // re-renderiza al cambiar idioma/tema
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const isLight = theme.background === '#F4F7FB';
  const loc = settings.language === 'en' ? 'en-US' : 'es-ES';

  const [locGuardada, setLocGuardada] = useState(null); // { lat, lon, nombre }
  const [data, setData] = useState(null);              // respuesta de open-meteo
  const [estado, setEstado] = useState('cargando');    // cargando | listo | error | sin-ubicacion
  const [refrescando, setRefrescando] = useState(false);
  const [actualizado, setActualizado] = useState(null);
  const [buscaAbierto, setBuscaAbierto] = useState(false);
  const [busqueda, setBusqueda] = useState('');
  const [resultados, setResultados] = useState(null);  // ciudades encontradas
  const [buscando, setBuscando] = useState(false);
  const [favs, setFavs] = useState([]);               // ubicaciones guardadas
  const [favsAbierto, setFavsAbierto] = useState(false);
  const gpsAuto = useRef(false);

  // ── Carga del pronóstico (Open-Meteo) + caché local ──
  const cargarTiempo = useCallback(async (l) => {
    const url =
      `https://api.open-meteo.com/v1/forecast?latitude=${l.lat}&longitude=${l.lon}` +
      '&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,cloud_cover,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m' +
      '&hourly=temperature_2m,weather_code,precipitation_probability,precipitation,wind_speed_10m,uv_index,visibility' +
      '&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,uv_index_max,sunrise,sunset' +
      '&timezone=auto&forecast_days=7&wind_speed_unit=kmh';
    const r = await fetch(url);
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const json = await r.json();
    setData(json);
    setActualizado(Date.now());
    await AsyncStorage.setItem(K_CACHE, JSON.stringify({ ...l, data: json, ts: Date.now() }));
  }, []);


  const guardarUbicacion = async (l) => {
    await AsyncStorage.setItem(K_LOC, JSON.stringify(l));
    setLocGuardada(l); setData(null); setActualizado(null); setEstado('cargando');
    try { await cargarTiempo(l); setEstado('listo'); } catch (e) { setEstado('error'); }
  };

  // ── Ubicaciones guardadas (favoritos) ──
  const mismaLoc = (a, b) => !!a && !!b && Math.abs(a.lat - b.lat) < 0.01 && Math.abs(a.lon - b.lon) < 0.01;
  const guardarFav = async (l) => {
    if (!l || favs.some((f) => mismaLoc(f, l))) return;
    const lista = [...favs, { lat: l.lat, lon: l.lon, nombre: l.nombre || `${l.lat?.toFixed(2)}, ${l.lon?.toFixed(2)}` }];
    setFavs(lista);
    try { await AsyncStorage.setItem(K_FAVS, JSON.stringify(lista)); } catch (e) {}
  };
  const borrarFav = async (l) => {
    const lista = favs.filter((f) => !mismaLoc(f, l));
    setFavs(lista);
    try { await AsyncStorage.setItem(K_FAVS, JSON.stringify(lista)); } catch (e) {}
  };

  // ── GPS: permiso + posición + nombre (reverse geocode) ──
  const usarGps = async () => {
    if (!Location) {
      Alert.alert(L('GPS no disponible', 'GPS unavailable'), L('Esta versión de la app no incluye el módulo de ubicación. Busca tu ciudad a mano con la lupa.', 'This app version lacks the location module. Search your city with the magnifier instead.'));
      return;
    }
    try {
      const perm = await Location.requestForegroundPermissionsAsync();
      if (!perm.granted) { Alert.alert(L('Permiso requerido', 'Permission required'), L('Activa la ubicación para usar el tiempo automático, o busca tu ciudad a mano.', 'Allow location for automatic weather, or search your city manually.')); setEstado((e) => (e === 'listo' ? e : 'sin-ubicacion')); return; }
      setEstado((e) => (e === 'listo' ? 'cargando-loc' : 'cargando'));
      const pos = await obtenerPosicion();
      let nombre = `${pos.coords.latitude.toFixed(2)}, ${pos.coords.longitude.toFixed(2)}`;
      try {
        const r = await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${pos.coords.latitude}&longitude=${pos.coords.longitude}&localityLanguage=es`);
        if (r.ok) { const j = await r.json(); nombre = [j.city || j.locality, j.principalSubdivision].filter(Boolean).join(', ') || nombre; }
      } catch (e) {}
      await guardarUbicacion({ lat: pos.coords.latitude, lon: pos.coords.longitude, nombre });
    } catch (e) {
      Alert.alert(L('Sin ubicación', 'No location'), e.message || String(e));
      setEstado((e2) => (e2 === 'listo' ? e2 : 'sin-ubicacion'));
    }
  };

  // ── Montaje: ubicación guardada → caché al instante → refresco en vivo ──
  useEffect(() => {
    let vivo = true;
    (async () => {
      try {
        const rawLoc = await AsyncStorage.getItem(K_LOC);
        const rawCache = await AsyncStorage.getItem(K_CACHE);
        const rawFavs = await AsyncStorage.getItem(K_FAVS);
        if (!vivo) return;
        if (rawFavs) { const f = safeJson(rawFavs, []); if (Array.isArray(f)) setFavs(f); }
        if (rawLoc) {
          const l = safeJson(rawLoc, null);
          if (l) {
            setLocGuardada(l);
            const cache = rawCache ? safeJson(rawCache, null) : null;
            if (cache && cache.data && Math.abs(cache.lat - l.lat) < 0.01 && Math.abs(cache.lon - l.lon) < 0.01) {
              setData(cache.data); setActualizado(cache.ts || null); setEstado('listo');
            }
            cargarTiempo(l).catch(() => { if (vivo && !cache) setEstado('error'); });
            return;
          }
        }
        // Sin módulo de ubicación (build antigua): el buscador manual es el camino
        if (!Location) { setEstado('sin-ubicacion'); return; }
        // Sin ubicación guardada: GPS automático una sola vez
        if (!gpsAuto.current) { gpsAuto.current = true; usarGps(); }
        else setEstado('sin-ubicacion');
      } catch (e) { if (vivo) setEstado('sin-ubicacion'); }
    })();
    return () => { vivo = false; };
  }, []);
  // ── Búsqueda manual de ciudad (geocoding de Open-Meteo) ──
  useEffect(() => {
    const texto = buscaAbierto ? busqueda.trim() : '';
    if (texto.length < 2) { setResultados(null); return undefined; }
    let vivo = true;
    setBuscando(true);
    const t = setTimeout(async () => {
      try {
        const r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(texto)}&count=8&language=${settings.language || 'es'}&format=json`);
        const j = await r.json();
        if (vivo) setResultados(j.results || []);
      } catch (e) { if (vivo) setResultados([]); }
      finally { if (vivo) setBuscando(false); }
    }, 350);
    return () => { vivo = false; clearTimeout(t); };
  }, [busqueda, buscaAbierto, locGuardada, settings.language]);

  const refrescar = async () => {
    if (!locGuardada) return;
    setRefrescando(true);
    try { await cargarTiempo(locGuardada); } catch (e) {}
    finally { setRefrescando(false); }
  };

  // ── Derivados del pronóstico ──
  const ahora = useMemo(() => {
    if (!data) return null;
    const c = data.current || {};
    const off = (data.utc_offset_seconds || 0) * 1000;
    const tzNow = new Date(Date.now() + off + new Date().getTimezoneOffset() * 60000);
    const H = data.hourly || {};
    const D = data.daily || {};
    let idxH = (H.time || []).findIndex((t) => new Date(t) > tzNow);
    if (idxH < 0) idxH = 0;
    const horas = (H.time || []).slice(idxH, idxH + 24).map((t, i) => ({
      hora: i === 0 ? L('Ahora', 'Now') : t.slice(11, 16),
      temp: H.temperature_2m?.[idxH + i],
      code: H.weather_code?.[idxH + i],
      prob: H.precipitation_probability?.[idxH + i],
    }));
    const dias = (D.time || []).map((t, i) => ({
      nombre: i === 0 ? L('Hoy', 'Today') : (() => { const s = new Date(`${t}T12:00:00`).toLocaleDateString(loc, { weekday: 'long' }); return s.charAt(0).toUpperCase() + s.slice(1); })(),
      code: D.weather_code?.[i],
      max: D.temperature_2m_max?.[i], min: D.temperature_2m_min?.[i],
      prob: D.precipitation_probability_max?.[i], sum: D.precipitation_sum?.[i],
      uv: D.uv_index_max?.[i], viento: D.wind_speed_10m_max?.[i],
      amanecer: (D.sunrise?.[i] || '').slice(11, 16), atardecer: (D.sunset?.[i] || '').slice(11, 16),
    }));
    const semanaMin = Math.min(...(D.temperature_2m_min || []).slice(0, 7).map(Number).filter(Number.isFinite));
    const semanaMax = Math.max(...(D.temperature_2m_max || []).slice(0, 7).map(Number).filter(Number.isFinite));
    const visibilidad = (H.visibility?.[idxH] ?? null) / 1000;
    const uvAhora = H.uv_index?.[idxH];
    return { c, horas, dias, semanaMin, semanaMax, visibilidad, uvAhora, tzNow };
  }, [data, loc]);

  const p = paleta(isLight);
  const top = topPad != null ? topPad : insets.top + 44;

  if (estado === 'cargando' || (estado === 'cargando-loc' && !data)) {
    return (
      <View style={{ flex: 1, backgroundColor: p.bg, paddingTop: top }}>
        <Centro>
          <SolPulsante color={WA} />
          <ActivityIndicator size="small" color={WA} />
          <Text style={[st.txt, { color: p.mut }]}>{L('Cargando el tiempo…', 'Loading weather…')}</Text>
        </Centro>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: p.bg }}>
      {/* ── Chips de acción (estilo filtros de WhatsApp), justo bajo la barra ── */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0, marginTop: top }} contentContainerStyle={st.cabecera}>
        <Chip p={p} icon="location" label={L('Mi ubicación', 'My location')} onPress={usarGps} />
        <Chip p={p} icon="search" label={L('Buscar', 'Search')} on={buscaAbierto}
          onPress={() => { setBuscaAbierto(!buscaAbierto); setBusqueda(''); setResultados(null); }} />
        <Chip p={p} icon="bookmarks" label={L('Guardadas', 'Saved')} on={favsAbierto}
          onPress={() => { setFavsAbierto(!favsAbierto); setBuscaAbierto(false); setBusqueda(''); setResultados(null); }} />
      </ScrollView>

      {(buscaAbierto || !locGuardada) && (
        <FadeIn>
          <View style={[st.buscaCaja, { backgroundColor: p.input, borderColor: p.border }]}>
            <Ionicons name="search-outline" size={16} color={p.mut} />
            <TextInput
              style={[st.buscaInput, { color: p.txt }]}
              value={busqueda}
              onChangeText={setBusqueda}
              placeholder={L('Ciudad… p. ej. Gijón', 'City… e.g. Gijon')}
              placeholderTextColor={p.mut}
              autoFocus
            />
            {buscando && <ActivityIndicator size="small" color={WA} />}
          </View>
        </FadeIn>
      )}
      {/* ── Panel de ubicaciones guardadas ── */}
      {favsAbierto && (
        <FadeIn>
          <View style={[st.resultados, { backgroundColor: p.card, borderColor: p.border }]}>
            <Text style={[st.txt, { color: p.mut, paddingHorizontal: 12, paddingTop: 10, paddingBottom: 4, fontSize: 11 }]}>
              {L('Toca una ubicación para ver su tiempo.', 'Tap a location to see its weather.')}
            </Text>
            {favs.length === 0 && (
              <Text style={[st.txt, { color: p.mut, padding: 12 }]}>
                {L('Aún no tienes ubicaciones guardadas. Guárdalas con el marcador desde el buscador o con "Guardar esta".', 'No saved locations yet. Save them with the bookmark from search or with "Save this one".')}
              </Text>
            )}
            {favs.map((f, i) => (
              <FilaLugar
                key={`${f.lat}-${f.lon}-${i}`}
                p={p}
                titulo={f.nombre}
                activo={mismaLoc(f, locGuardada)}
                last={i === favs.length - 1 && !(!!locGuardada && !favs.some((x) => mismaLoc(x, locGuardada)))}
                onPress={() => { setFavsAbierto(false); guardarUbicacion(f); }}
                derecha={(
                  <Pressable onPress={() => borrarFav(f)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }} style={{ paddingHorizontal: 14 }}>
                    <Ionicons name="trash-outline" size={17} color="#E5484D" />
                  </Pressable>
                )}
              />
            ))}
            {!!locGuardada && !favs.some((f) => mismaLoc(f, locGuardada)) && (
              <Pressable style={st.guardarEsta} onPress={() => guardarFav(locGuardada)}>
                <Ionicons name="bookmark-outline" size={16} color={WA} />
                <Text style={{ color: WA, fontWeight: '700', fontSize: 13 }}>
                  {L('Guardar esta ubicación', 'Save this location')}
                </Text>
              </Pressable>
            )}
          </View>
        </FadeIn>
      )}

      {(buscaAbierto || !locGuardada) && resultados != null && (
        <FadeIn>
          <View style={[st.resultados, { backgroundColor: p.card, borderColor: p.border }]}>
            {resultados.length === 0 && <Text style={[st.txt, { color: p.mut, padding: 12 }]}>{L('Sin resultados.', 'No results.')}</Text>}
            {resultados.map((r, i) => {
              const l = { lat: r.latitude, lon: r.longitude, nombre: [r.name, r.admin1].filter(Boolean).join(', ') };
              const yaGuardada = favs.some((f) => mismaLoc(f, l));
              return (
                <FilaLugar
                  key={`${r.latitude}-${r.longitude}-${i}`}
                  p={p}
                  titulo={`${r.name}${r.admin1 ? `, ${r.admin1}` : ''}`}
                  sub={r.country || ''}
                  last={i === resultados.length - 1}
                  onPress={() => { setBuscaAbierto(false); setFavsAbierto(false); setResultados(null); setBusqueda(''); guardarUbicacion(l); }}
                  derecha={(
                    <Pressable onPress={() => (yaGuardada ? borrarFav(l) : guardarFav(l))} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }} style={{ paddingHorizontal: 14 }}>
                      <Ionicons name={yaGuardada ? 'bookmark' : 'bookmark-outline'} size={18} color={yaGuardada ? AMBER : WA} />
                    </Pressable>
                  )}
                />
              );
            })}
          </View>
        </FadeIn>
      )}

      {/* ── Sin ubicación aún: onboarding ── */}
      {estado === 'sin-ubicacion' && !data && (
        <Centro>
          <SolPulsante color={p.mut} />
          <Text style={[st.txt, { color: p.mut, textAlign: 'center', paddingHorizontal: 30 }]}>
            {L('Escribe tu ciudad arriba, o usa tu ubicación.', 'Type your city above, or use your location.')}
          </Text>
          <Press onPress={usarGps} style={[st.boton, { backgroundColor: WA }]}>
            <Ionicons name="location" size={16} color="#fff" />
            <Text style={{ color: '#fff', fontWeight: '800' }}>{L('Usar mi ubicación', 'Use my location')}</Text>
          </Press>
        </Centro>
      )}

      {estado === 'error' && !data && (
        <Centro>
          <MaterialCommunityIcons name="weather-cloudy-arrow-right" size={50} color={p.mut} />
          <Text style={[st.txt, { color: p.mut }]}>{L('No se pudo cargar el tiempo.', 'Could not load the weather.')}</Text>
          <Press onPress={refrescar} style={[st.boton, { backgroundColor: WA }]}>
            <Ionicons name="refresh" size={16} color="#fff" />
            <Text style={{ color: '#fff', fontWeight: '800' }}>{L('Reintentar', 'Retry')}</Text>
          </Press>
        </Centro>
      )}

      {/* ── Pronóstico ── */}
      {data && ahora && (
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingBottom: 40 }}
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={refrescando} onRefresh={refrescar} tintColor={WA} colors={[WA]} />}
        >
          {/* HERO */}
          <FadeIn style={{ marginHorizontal: 12, marginTop: 4 }}>
            <Hero ahora={ahora} nombre={locGuardada?.nombre} p={p} />
          </FadeIn>

          {/* 24 HORAS */}
          <Tarjeta p={p} titulo={L('Próximas 24 horas', 'Next 24 hours')} icono="clock-time-four-outline" delay={120}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {ahora.horas.map((h, i) => (
                <View key={i} style={[st.horaCol, i === 0 && { backgroundColor: WA + '18', borderColor: WA + '66', borderWidth: 1 }]}>
                  <Text style={[st.horaTxt, { color: i === 0 ? WA : p.mut }]} numberOfLines={1}>{h.hora}</Text>
                  <MaterialCommunityIcons name={wmoIcon(h.code, 1)} size={26} color={p.ico} />
                  {!!(h.prob > 0) ? <Text style={st.horaProb}>{h.prob}%</Text> : <Text style={[st.horaProb, { opacity: 0 }]}>0%</Text>}
                  <Text style={[st.horaTemp, { color: p.txt }]}>{h.temp != null ? `${Math.round(h.temp)}°` : '—'}</Text>
                </View>
              ))}
            </ScrollView>
          </Tarjeta>

          {/* 7 DÍAS */}
          <Tarjeta p={p} titulo={L('7 días', '7 days')} icono="calendar-week" delay={220}>
            {ahora.dias.map((d, i) => {
              const span = Math.max(1, ahora.semanaMax - ahora.semanaMin);
              const lo = Math.max(0, Math.round(((d.min - ahora.semanaMin) / span) * 100));
              const hi = Math.min(100, Math.round(((d.max - ahora.semanaMin) / span) * 100));
              return (
                <View key={i} style={[st.diaFila, i < ahora.dias.length - 1 && { borderBottomWidth: 1, borderBottomColor: p.border }]}>
                  <Text style={[st.diaNombre, { color: p.txt }, i === 0 && { color: WA }]} numberOfLines={1}>{d.nombre}</Text>
                  <View style={{ width: 38, flexDirection: 'row', alignItems: 'center', gap: 2 }}>
                    {!!(d.prob > 0) && <><Ionicons name="water-outline" size={11} color="#4A90E2" /><Text style={st.diaProb}>{d.prob}%</Text></>}
                  </View>
                  <MaterialCommunityIcons name={wmoIcon(d.code, 1)} size={24} color={p.ico} />
                  <Text style={[st.diaMin, { color: p.mut }]}>{d.min != null ? `${Math.round(d.min)}°` : '—'}</Text>
                  <BarraRango lo={lo} hi={hi} p={p} hoy={i === 0} />
                  <Text style={[st.diaMax, { color: p.txt }]}>{d.max != null ? `${Math.round(d.max)}°` : '—'}</Text>
                </View>
              );
            })}
          </Tarjeta>

          {/* DETALLES (cuadrícula estilo iPad) */}
          <Tarjeta p={p} titulo={L('Detalles', 'Details')} icono="information-outline" delay={320}>
            <View style={st.grid}>
              <Tile p={p} delay={360} color="#F0576B" icono="thermometer" label={L('Sensación térmica', 'Feels like')} valor={`${Math.round(ahora.c.apparent_temperature)}°`} />
              <Tile p={p} delay={400} color="#4A90E2" icono="water-percent" label={L('Humedad', 'Humidity')} valor={`${Math.round(ahora.c.relative_humidity_2m)}%`} />
              <Tile p={p} delay={440} color="#22B8CF" icono="weather-windy" label={L('Viento', 'Wind')}
                valor={`${Math.round(ahora.c.wind_speed_10m)} km/h`} extra={`${cardinal(ahora.c.wind_direction_10m, settings.language)} · ${Math.round(ahora.c.wind_gusts_10m)} ${L('km/h rachas', 'km/h gusts')}`} />
              <Tile p={p} delay={480} color={AMBER} icono="weather-sunset-up" label={L('Amanecer', 'Sunrise')} valor={ahora.dias[0]?.amanecer || '—'} extra={`${L('Atardecer', 'Sunset')}: ${ahora.dias[0]?.atardecer || '—'}`} />
              <Tile p={p} delay={520} color="#F5C518" icono="weather-sunny" label={L('Índice UV', 'UV index')} valor={ahora.uvAhora != null ? Number(ahora.uvAhora).toFixed(1) : '—'} extra={ahora.uvAhora != null ? uvNivel(ahora.uvAhora) : ''} />
              <Tile p={p} delay={560} color="#A78BFA" icono="gauge" label={L('Presión', 'Pressure')} valor={`${Math.round(ahora.c.surface_pressure)} hPa`} />
              <Tile p={p} delay={600} color="#8FA8C8" icono="weather-cloudy" label={L('Nubosidad', 'Cloudiness')} valor={`${Math.round(ahora.c.cloud_cover)}%`} />
              <Tile p={p} delay={640} color="#4A90E2" icono="weather-pouring" label={L('Precipitación', 'Precipitation')}
                valor={`${ahora.c.precipitation ?? 0} mm`} extra={ahora.dias[0] ? `${L('Hoy', 'Today')}: ${ahora.dias[0].sum ?? 0} mm` : ''} />
              <Tile p={p} delay={680} color="#2DB37A" icono="eye-outline" label={L('Visibilidad', 'Visibility')}
                valor={ahora.visibilidad != null ? `${ahora.visibilidad.toFixed(0)} km` : '—'} extra={ahora.dias[0] ? `${L('UV máx hoy', 'UV max today')}: ${ahora.dias[0].uv ?? '—'}` : ''} />
            </View>
          </Tarjeta>

          {!!actualizado && (
            <Text style={[st.actualizado, { color: p.mut }]}>
              {L('Actualizado a las', 'Updated at')} {(() => { const d = new Date(actualizado); return `${p2(d.getHours())}:${p2(d.getMinutes())}`; })()} · open-meteo.com
            </Text>
          )}
        </ScrollView>
      )}
    </View>
  );
}

const st = StyleSheet.create({
  centro: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 14, padding: 20 },
  txt: { fontSize: 14 },
  cabecera: { flexDirection: 'row', gap: 8, paddingHorizontal: 12, paddingVertical: 10 },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, borderWidth: 1 },
  chipTxt: { fontSize: 13, fontWeight: '700' },
  buscaCaja: { flexDirection: 'row', alignItems: 'center', gap: 8, marginHorizontal: 12, marginBottom: 4, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, borderWidth: 1 },
  buscaInput: { flex: 1, fontSize: 14, paddingVertical: 3 },
  resultados: { marginHorizontal: 12, marginTop: 6, borderRadius: 14, borderWidth: 1, overflow: 'hidden' },
  lugarFila: { flexDirection: 'row', alignItems: 'center' },
  lugarMain: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 12, paddingVertical: 10 },
  lugarAvatar: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  guardarEsta: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 14 },
  boton: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 18, paddingVertical: 11, borderRadius: 999 },

  // Hero
  hero: { borderRadius: 26, paddingVertical: 22, paddingHorizontal: 16, alignItems: 'center', justifyContent: 'center', overflow: 'hidden', gap: 2 },
  locNombre: { fontSize: 19, fontWeight: '800', color: '#FFFFFF', textShadowColor: 'rgba(0,0,0,0.28)', textShadowRadius: 6, textShadowOffset: { width: 0, height: 1 } },
  tempGrande: { fontSize: 80, fontWeight: '200', lineHeight: 90, color: '#FFFFFF', textShadowColor: 'rgba(0,0,0,0.25)', textShadowRadius: 8, textShadowOffset: { width: 0, height: 1 } },
  desc: { fontSize: 16, fontWeight: '700', color: '#FFFFFFE6', textShadowColor: 'rgba(0,0,0,0.28)', textShadowRadius: 6, textShadowOffset: { width: 0, height: 1 } },
  heroChips: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 8, marginTop: 10 },
  heroChip: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 11, paddingVertical: 6, borderRadius: 999, backgroundColor: 'rgba(0,0,0,0.22)' },
  heroChipTxt: { color: '#FFFFFF', fontSize: 12, fontWeight: '700' },

  // Tarjetas
  tarjeta: { marginHorizontal: 12, marginTop: 12, borderRadius: 18, borderWidth: 1, padding: 12 },
  tarjetaHead: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 },
  tarjetaTitulo: { fontSize: 12, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.5 },
  horaCol: { alignItems: 'center', width: 54, gap: 3, paddingVertical: 6, borderRadius: 14, borderWidth: 1, borderColor: 'transparent' },
  horaTxt: { fontSize: 12, fontWeight: '700' },
  horaProb: { color: '#4A90E2', fontSize: 10, fontWeight: '700' },
  horaTemp: { fontSize: 15, fontWeight: '800' },
  diaFila: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 8 },
  diaNombre: { width: 82, fontSize: 13, fontWeight: '700' },
  diaProb: { color: '#4A90E2', fontSize: 11, fontWeight: '700' },
  diaMin: { width: 34, fontSize: 13, textAlign: 'right' },
  diaMax: { width: 34, fontSize: 13, fontWeight: '800' },
  diaBarra: { flex: 1, height: 6, borderRadius: 3, overflow: 'hidden' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tileWrap: { width: '48.5%', flexGrow: 1 },
  tile: { borderRadius: 14, padding: 10, gap: 3 },
  tileHead: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  tileIco: { width: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  tileLbl: { fontSize: 11, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.4, flex: 1 },
  tileVal: { fontSize: 20, fontWeight: '800' },
  tileExtra: { fontSize: 11 },
  actualizado: { textAlign: 'center', fontSize: 11, marginTop: 14 },
});