// components/ArchivosPicker.js
/* ══════════════════════════════════════════════════════════════════════
   LIBRERÍA DE ARCHIVOS (modal a pantalla completa, mis botones y patrón
   que la librería de sesiones LibreriaDrive):
   · RAÍZ: "Mis archivos" (gestor) y la carpeta FIJA "Ejercicios de
     gimnasio" (candado, no editable, subcarpetas por parte del cuerpo).
   · MIS ARCHIVOS: barra con HOME · SUBIR ARCHIVO · AÑADIR CARPETA ·
     FILTRAR POR (tipo) · BUSCAR POR NOMBRE; migas de carpeta; carpetas
     anidadas (docs esCarpeta con `carpeta` padre, como en la otra
     librería); listado local-first procedural (15 en 15) desde
     archivosStore con listener onSnapshot de `archivosLib`.
   · Pulsación larga en archivo/carpeta → MENÚ (igual que la librería de
     sesiones LibreriaDrive): archivo → Renombrar / Mover a carpeta /
     Eliminar; carpeta → Renombrar / Eliminar. "Eliminar" un archivo borra
     PRIMERO el binario de R2 (servidor /api/archivos/delete) y solo si eso
     va bien quita el doc de Firestore: no quedan huérfanos en el bucket.
   · GIMNASIO: subcarpetas por parte del cuerpo en español y ejercicios
     con miniatura + nombre ES. EjercicioViewer: gif + nombre ES + pasos.
   ══════════════════════════════════════════════════════════════════════ */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator, Alert, FlatList, Image, Linking, Modal, ScrollView, StyleSheet, Text,
  TextInput, TouchableOpacity, View,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { onSnapshot, query, collection, where, addDoc, deleteDoc, doc, updateDoc } from 'firebase/firestore';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import { auth, db } from '../firebaseConfig';
import SystemBars from './SystemBars';
import VideoYouTube from './VideoYouTube';
import { archivosStoreAll, archivosStoreInit, archivosStorePut, archivosStoreRemove } from '../services/archivosStore';
import { getGymEx, getGymIndex, getR2Base, subirArchivoDeEntreno, borrarArchivoDeR2 } from '../services/archivosUpload';
import { getThemeColors, L, useAppSettings } from '../services/appSettings';
import { youtubeIdDe } from '../services/enlaces';

const BLUE = '#4A90E2';
const RED = '#E05252';
const PAGE = 15;

/* Carpetas FIJAS de la librería de gimnasio: una por parte del cuerpo del
   dataset (body_part), en español y en este orden. No se pueden editar. */
export const GRUPOS_GYM = [
  { bp: 'chest',      es: L('Pecho', 'Chest') },
  { bp: 'back',       es: L('Espalda', 'Back') },
  { bp: 'shoulders',  es: L('Hombros', 'Shoulders') },
  { bp: 'upper arms', es: L('Brazos (bíceps y tríceps)', 'Arms (biceps & triceps)') },
  { bp: 'lower arms', es: L('Antebrazos y agarre', 'Forearms & grip') },
  { bp: 'waist',      es: L('Abdomen y cintura', 'Abs & waist') },
  { bp: 'upper legs', es: L('Piernas', 'Legs') },
  { bp: 'lower legs', es: L('Gemelos y tobillos', 'Calves & ankles') },
  { bp: 'cardio',     es: L('Cardio', 'Cardio') },
  { bp: 'neck',       es: L('Cuello', 'Neck') },
];
const ES_DE_BP = Object.fromEntries(GRUPOS_GYM.map((g) => [g.bp, g.es]));

const FILTROS = [
  { id: null,     es: L('Todos', 'All'),           icono: 'apps-outline' },
  { id: 'imagen', es: L('Imágenes', 'Images'),     icono: 'image-outline' },
  { id: 'gif',    es: L('GIFs', 'GIFs'),           icono: 'film-outline' },
  { id: 'pdf',    es: L('PDFs', 'PDFs'),           icono: 'document-text-outline' },
  { id: 'video',  es: L('Vídeos', 'Videos'),       icono: 'videocam-outline' },
  { id: 'audio',  es: L('Audio', 'Audio'),         icono: 'musical-notes-outline' },
  { id: 'otro',   es: L('Otros', 'Others'),        icono: 'document-outline' },
];

const EQUIPOS_ES = {
  'barbell': 'Barra', 'dumbbell': 'Mancuernas', 'cable': 'Polea', 'body weight': 'Peso corporal',
  'kettlebell': 'Kettlebell', 'band': 'Banda', 'resistance band': 'Banda elástica', 'machine': 'Máquina',
  'leverage machine': 'Máquina de palanca', 'smith machine': 'Máquina smith', 'ez barbell': 'Barra EZ',
  'trap bar': 'Barra hexagonal', 'rope': 'Cuerda', 'sled': 'Trineo', 'tire': 'Neumático', 'hammer': 'Mazo',
  'medicine ball': 'Balón medicinal', 'stability ball': 'Balón fitball', 'bosu ball': 'Bosu',
  'weighted': 'Con lastre', 'assisted': 'Asistida', 'stationary bike': 'Bici estática',
  'elliptical machine': 'Elíptica', 'treadmill': 'Cinta', 'row machine': 'Máquina de remo',
  'ski erg machine': 'Ski erg', 'wheel roller': 'Rueda abdominal', 'foam roll': 'Rodillo',
  'suspension': 'Suspensión', 'upper body ergometer': 'Ergómetro de brazos', 'stepmill': 'Escaleras',
  'car': 'Coche', 'other': 'Otro',
};

const ICONO_TIPO = {
  imagen: 'image-outline', gif: 'film-outline', pdf: 'document-text-outline',
  video: 'videocam-outline', audio: 'musical-notes-outline', otro: 'document-outline',
};

const fmtFecha = (iso) => {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  const p2 = (n) => String(n).padStart(2, '0');
  return `${p2(d.getDate())}/${p2(d.getMonth() + 1)}/${d.getFullYear()}`;
};
const fmtSize = (b) => (b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);

export default function ArchivosPicker({ visible, onClose, onSelect, me }) {
  const insets = useSafeAreaInsets();
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, 'dark');
  const [vista, setVista] = useState('raiz');   // raiz | mis | gym | grupo:{bp}
  const [docs, setDocs] = useState([]);
  const [index, setIndex] = useState(null);
  const [error, setError] = useState('');
  const [numVis, setNumVis] = useState(PAGE);
  const [base, setBase] = useState('');

  // Gestor "Mis archivos" (igual que LibreriaDrive)
  const [dir, setDir] = useState(null);          // carpeta actual { id, nombre } | null = raíz
  const [buscaAbierto, setBuscaAbierto] = useState(false);
  const [buscar, setBuscar] = useState('');
  const [filtroOpen, setFiltroOpen] = useState(false);
  const [filtroTipo, setFiltroTipo] = useState(null);
  const [prompt, setPrompt] = useState(null);    // { titulo, onOk, ph, btn }
  const [promptTxt, setPromptTxt] = useState('');
  const [menu, setMenu] = useState(null);        // pulsación larga: { tipo: 'file'|'carpeta', obj }
  const [mover, setMover] = useState(null);      // archivo en tránsito hacia otra carpeta
  const [subiendo, setSubiendo] = useState(false);
  const [menuSubida, setMenuSubida] = useState(false);   // cámara/galería/vídeo/navegar
  const [visor, setVisor] = useState(null);              // archivo abierto: { tipo, url, nombre }
  const [preview, setPreview] = useState(null);       // ejercicio en previsualización
  const [filtroEq, setFiltroEq] = useState(null);     // filtro de material (gimnasio)
  const [filtroEqOpen, setFiltroEqOpen] = useState(false);

  const user = me || auth.currentUser;

  // Carga local-first + listener en vivo de archivosLib (deltas)
  useEffect(() => {
    if (!visible || !user) return undefined;
    let vivo = true;
    (async () => {
      await archivosStoreInit(user.uid);
      if (vivo) setDocs(await archivosStoreAll());
    })();
    const q = query(collection(db, 'archivosLib'), where('userId', '==', user.uid));
    const unsub = onSnapshot(q, (snap) => {
      if (!vivo) return;
      const up = [];
      const muertos = [];
      for (const ch of (snap.docChanges ? snap.docChanges() : [])) {
        if (ch.type === 'removed') { muertos.push(ch.doc.id); continue; }
        up.push({ id: ch.doc.id, ...ch.doc.data() });
      }
      (async () => {
        if (up.length) await archivosStorePut(up);
        if (muertos.length) await archivosStoreRemove(muertos);
        if (up.length || muertos.length) setDocs(await archivosStoreAll());
      })();
    }, () => {});
    return () => { vivo = false; unsub(); };
  }, [visible, user]);

  useEffect(() => {
    if (!visible || !user) return;
    getR2Base(user).then(setBase).catch(() => {});
  }, [visible, user]);

  // Índice de gimnasio al entrar en la carpeta fija
  useEffect(() => {
    if (!visible || vista !== 'gym' || index || !user) return;
    let vivo = true;
    (async () => {
      try { setError(''); setIndex(await getGymIndex(user)); }
      catch (e) { if (vivo) setError(e.message || 'No se pudo cargar la librería de gimnasio'); }
    })();
    return () => { vivo = false; };
  }, [visible, vista, index, user]);

  useEffect(() => { setNumVis(PAGE); }, [vista, dir, filtroTipo, buscar]);
  useEffect(() => { if (visible) { setVista('raiz'); setDir(null); setBuscar(''); setBuscaAbierto(false); setFiltroTipo(null); setMenu(null); setMover(null); } }, [visible]);

  // ── Derivados del gestor (0 lecturas: todo sale del almacén) ──
  const idActual = dir ? dir.id : null;
  const carpetasDelDir = useMemo(
    () => docs.filter((c) => c.esCarpeta && (c.carpeta ?? null) === idActual)
      .sort((a, b) => String(a.nombre).localeCompare(String(b.nombre))),
    [docs, idActual],
  );
  const recuentos = useMemo(() => {
    const out = {};
    for (const d of docs) if (d.esCarpeta) out[d.id] = 0;
    for (const d of docs) if (!d.esCarpeta && d.carpeta != null && out[d.carpeta] != null) out[d.carpeta] += 1;
    return out;
  }, [docs]);
  const itemsDelDir = useMemo(() => {
    let xs = docs.filter((x) => !x.esCarpeta && (x.carpeta ?? null) === idActual);
    if (filtroTipo) xs = xs.filter((x) => x.tipo === filtroTipo);
    const texto = buscaAbierto ? buscar.trim().toLowerCase() : '';
    if (texto) xs = xs.filter((x) => String(x.nombre || '').toLowerCase().includes(texto));
    return xs;   // el almacén ya los devuelve ordenados por fecha desc
  }, [docs, idActual, filtroTipo, buscaAbierto, buscar]);
  const lista = useMemo(
    () => [...carpetasDelDir.map((c) => ({ key: `c${c.id}`, tipo: 'carpeta', obj: c })),
      ...itemsDelDir.map((f) => ({ key: `f${f.id}`, tipo: 'file', obj: f }))],
    [carpetasDelDir, itemsDelDir],
  );

  // ── Acciones del gestor ──
  const crearCarpeta = async (nombre) => {
    const n = String(nombre || '').trim();
    if (!n || !user) return;
    const data = { userId: user.uid, esCarpeta: true, nombre: n, carpeta: idActual, createdAt: new Date().toISOString() };
    const ref = await addDoc(collection(db, 'archivosLib'), data);
    await archivosStorePut({ ...data, id: ref.id });
    setDocs(await archivosStoreAll());
  };
  const eliminarCarpeta = (c) => {
    Alert.alert(L('Eliminar carpeta', 'Delete folder'), L(`¿Eliminar la carpeta "${c.nombre}"?`, `Delete folder "${c.nombre}"?`), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: async () => {
        const hayDentro = docs.some((x) => (x.carpeta ?? null) === c.id);
        if (hayDentro) { Alert.alert(L('Carpeta no vacía', 'Folder not empty'), L('Vacíala antes (borra o mueve lo de dentro).', 'Empty it first.')); return; }
        try { await deleteDoc(doc(db, 'archivosLib', c.id)); } catch (e) {}
        await archivosStoreRemove(c.id);
        setDocs(await archivosStoreAll());
      } },
    ]);
  };
  const eliminarArchivo = (f) => {
    Alert.alert(L('Eliminar archivo', 'Delete file'),
      L(`Se eliminará "${f.nombre}" de tu librería y del almacenamiento. Los entrenos que lo usen perderán el archivo.`,
        `"${f.nombre}" will be deleted from your library and from storage. Workouts using it will lose the file.`), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: async () => {
        try {
          // 1) PRIMERO el binario de R2: si el borrado del almacenamiento
          //    falla, NO se quita la entrada de la librería (más vale un
          //    archivo visible que un binario huérfano; reintentar es seguro
          //    porque DeleteObject es idempotente). Cada subida genera su
          //    propia clave, pero si otra entrada viva apunta a la MISMA url
          //    no se toca el objeto.
          const compartido = !!f.url && docs.some((x) => !x.esCarpeta && x.id !== f.id && x.url === f.url);
          let r2 = null;
          if (f.url && !compartido) r2 = await borrarArchivoDeR2(user, f.url);
          // 2) Firestore + almacén local.
          await deleteDoc(doc(db, 'archivosLib', f.id));
          await archivosStoreRemove(f.id);
          setDocs(await archivosStoreAll());
          // Servidor sin redeployar (404 de plataforma): se avisa en vez de
          // dejarlo pasar en silencio (el binario seguiría en el bucket).
          if (r2 && r2.sin === 'sin-ruta') {
            Alert.alert(L('Quitado de la librería', 'Removed from library'),
              L('El servidor aún no tiene el borrado en R2 (falta redeploy): el binario sigue en el bucket.',
                'The server does not have R2 deletion yet (pending redeploy): the binary is still in the bucket.'));
          }
        } catch (e) {
          Alert.alert(L('Error', 'Error'), L('No se pudo eliminar: ', 'Could not delete: ') + (e.message || String(e)));
        }
      } },
    ]);
  };
  // Renombrar archivo o carpeta (los dos viven en `archivosLib` con `nombre`).
  const renombrar = async (obj, nombre) => {
    const n = String(nombre || '').trim();
    if (!n || n === obj.nombre) return;
    try {
      await updateDoc(doc(db, 'archivosLib', obj.id), { nombre: n });
      await archivosStorePut({ ...obj, nombre: n });
      setDocs(await archivosStoreAll());
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };
  // Mover archivo a otra carpeta (destinoId null = raíz). Solo archivos:
  // el menú de carpeta es el mismo que en la librería de sesiones.
  const moverA = async (destinoId) => {
    if (!mover) return;
    const obj = mover.obj;
    setMover(null);
    if ((obj.carpeta ?? null) === (destinoId ?? null)) return;   // ya está ahí
    try {
      await updateDoc(doc(db, 'archivosLib', obj.id), { carpeta: destinoId ?? null });
      await archivosStorePut({ ...obj, carpeta: destinoId ?? null });
      setDocs(await archivosStoreAll());
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };
  // Navegar (documento cualquiera) — la opción "Navegar" del menú de subida
  const subirNavegando = async () => {
    try {
      const res = await DocumentPicker.getDocumentAsync({ copyToCacheDir: true });
      if (!res || res.canceled || !res.assets || !res.assets[0]) return;
      const a = res.assets[0];
      setSubiendo(true);
      await subirArchivoDeEntreno(user, {
        uri: a.uri, nombre: a.name || 'archivo', contentType: a.mimeType || 'application/octet-stream',
        size: a.size || 0, carpeta: idActual,
      });
      setDocs(await archivosStoreAll());
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
    finally { setSubiendo(false); }
  };
  // Subida común de imagen (cámara o galería)
  const subirImagen = async (resultado) => {
    try {
      const a = resultado?.assets?.[0];
      if (!a) return;
      setSubiendo(true);
      const nombre = `foto-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.jpg`;
      await subirArchivoDeEntreno(user, {
        uri: a.uri, nombre, contentType: 'image/jpeg',
        size: a.fileSize || 0, carpeta: idActual,
      });
      setDocs(await archivosStoreAll());
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
    finally { setSubiendo(false); }
  };
  const subirDeCamara = async () => {
    try {
      const perm = await ImagePicker.requestCameraPermissionsAsync();
      if (!perm.granted) { Alert.alert(L('Permiso requerido', 'Permission required'), L('Activa el permiso de cámara para hacer fotos.', 'Allow camera access to take photos.')); return; }
      const res = await ImagePicker.launchCameraAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.8 });
      await subirImagen(res);
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };
  const subirDeGaleria = async () => {
    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) { Alert.alert(L('Permiso requerido', 'Permission required'), L('Activa el permiso de fotos para elegir de la galería.', 'Allow photo access to pick from the gallery.')); return; }
      const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.8 });
      await subirImagen(res);
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };
  // Seleccionar vídeo: guarda un ENLACE de YouTube en la librería (sin subida)
  const anadirVideoUrl = async (texto) => {
    const url = String(texto || '').trim();
    if (!user) return;
    if (!youtubeIdDe(url)) {
      Alert.alert(L('Enlace no válido', 'Invalid link'), L('Pega un enlace de YouTube (watch, youtu.be, shorts…).', 'Paste a YouTube link (watch, youtu.be, shorts…).'));
      return;
    }
    try {
      const data = { userId: user.uid, tipo: 'video', nombre: url, url, carpeta: idActual, size: null, createdAt: new Date().toISOString() };
      const ref = await addDoc(collection(db, 'archivosLib'), data);
      await archivosStorePut({ ...data, id: ref.id });
      setDocs(await archivosStoreAll());
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };
  const abrirArchivo = (f) => {
    if (f.tipo === 'video') { setVisor({ tipo: 'video', url: f.url, nombre: f.nombre }); return; }
    if (f.tipo === 'imagen' || f.tipo === 'gif') { setVisor({ tipo: f.tipo, url: f.url, nombre: f.nombre }); return; }
    // PDF y demás: visor del sistema
    if (f.url) { Linking.openURL(f.url).catch(() => {}); }
  };

  const porGrupo = useMemo(() => {
    const m = new Map();
    for (const e of (index || [])) {
      if (!m.has(e.bp)) m.set(e.bp, []);
      m.get(e.bp).push(e);
    }
    return m;
  }, [index]);
  const grupoActivo = vista.startsWith('grupo:') ? vista.slice(6) : null;
  const nArchivos = useMemo(() => docs.filter((d) => !d.esCarpeta).length, [docs]);

  // Gimnasio: búsqueda por nombre (ES o EN) en TODO el índice + filtro de
  // material. Con búsqueda/filtro/grupo activo se pinta lista plana.
  const textoGym = buscaAbierto ? buscar.trim().toLowerCase() : '';
  // ÁMBITO: dentro de una carpeta, búsqueda y filtro actúan SOLO sobre esa
  // carpeta (en "Pecho" el filtro de peso corporal no puede sacar 325
  // ejercicios de otras secciones); en la raíz, sobre todo el índice.
  const ambitoGym = useMemo(
    () => (grupoActivo ? (porGrupo.get(grupoActivo) || []) : (index || [])),
    [grupoActivo, porGrupo, index],
  );
  const gymPlana = useMemo(() => {
    let xs = ambitoGym;
    if (textoGym) xs = xs.filter((e) => (e.es || '').toLowerCase().includes(textoGym) || (e.n || '').toLowerCase().includes(textoGym));
    if (filtroEq) xs = xs.filter((e) => e.eq === filtroEq);
    return xs;
  }, [ambitoGym, textoGym, filtroEq]);
  const mostrarPlana = (vista === 'gym' || vista.startsWith('grupo:')) && (!!textoGym || !!filtroEq || !!grupoActivo);
  // Opciones del menú FILTRAR con contadores DEL ÁMBITO ACTUAL
  const opcionesEq = useMemo(() => {
    const c = {};
    for (const e of ambitoGym) c[e.eq] = (c[e.eq] || 0) + 1;
    return Object.entries(c).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([id, n]) => ({ id, n }));
  }, [ambitoGym]);
  const entryGym = useCallback((e) => ({
    tipo: 'ejercicio', gymId: e.id, nombre: e.es || e.n,
    url: base && e.m ? `${base}/gym/${e.m}` : '',
    thumb: base && e.t ? `${base}/gym/${e.t}` : '',
    grupo: ES_DE_BP[e.bp] || e.bp,
  }), [base]);

  // Fila de ejercicio: TOCAR = previsualizar · el "+" del lado = agregar al entreno
  const filaGymRow = ({ item }) => (
    <TouchableOpacity
      style={[st.filaGym, { backgroundColor: theme.card, borderColor: theme.border }]}
      activeOpacity={0.75}
      onPress={() => setPreview(item)}
    >
      {!!item.t && base ? (
        <Image source={{ uri: `${base}/gym/${item.t}` }} style={st.mini} resizeMode="cover" />
      ) : <View style={[st.mini, { backgroundColor: theme.background }]} />}
      <View style={{ flex: 1 }}>
        <Text style={{ color: theme.text, fontSize: 14, fontWeight: '700' }} numberOfLines={2}>{item.es || item.n}</Text>
        <Text style={{ color: theme.muted, fontSize: 11, marginTop: 2 }} numberOfLines={1}>
          {(!grupoActivo || textoGym) ? `${ES_DE_BP[item.bp] || item.bp} · ` : ''}{item.n}{item.eq ? ` · ${EQUIPOS_ES[item.eq] || item.eq}` : ''}
        </Text>
      </View>
      <TouchableOpacity style={{ padding: 4 }} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }} onPress={() => onSelect(entryGym(item))}>
        <Ionicons name="add-circle" size={23} color={BLUE} />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  const abrirPrompt = (titulo, onOk, inicial, ph, btn) => { setPromptTxt(inicial || ''); setPrompt({ titulo, onOk, ph, btn }); };

  const barraBtn = (icono, onPress, activo) => (
    <TouchableOpacity style={[st.barraBtn, { backgroundColor: theme.card, borderColor: theme.border }, activo && st.barraBtnActivo]} onPress={onPress} activeOpacity={0.75}>
      {icono}
    </TouchableOpacity>
  );

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: theme.background }}>
        {/* Cabecera según vista */}
        <View style={[st.header, { borderBottomColor: theme.border, paddingTop: insets.top + 6 }]}>
          <TouchableOpacity onPress={() => {
            if (vista === 'grupo:' || vista.startsWith('grupo:')) setVista('gym');
            else if (vista === 'gym' || vista === 'mis') setVista('raiz');
            else onClose();
          }}>
            <Ionicons name="chevron-back" size={24} color="#8FA8C8" />
          </TouchableOpacity>
          <Text style={[st.headerTitle, { color: theme.text }]} numberOfLines={1}>
            {vista === 'raiz' ? L('Librería de archivos', 'File library')
              : vista === 'mis' ? L('Mis archivos', 'My files')
              : vista === 'gym' ? L('Ejercicios de gimnasio', 'Gym exercises')
              : (ES_DE_BP[grupoActivo] || grupoActivo)}
          </Text>
          <View style={{ width: 24 }} />
        </View>

        {/* ── Barra de navegación del GIMNASIO: home · filtrar · buscar ── */}
        {(vista === 'gym' || grupoActivo) && (
          <>
            <View style={st.barra}>
              {barraBtn(<Ionicons name="home-outline" size={19} color={BLUE} />, () => { setVista('gym'); setBuscaAbierto(false); setBuscar(''); setFiltroEq(null); })}
              {barraBtn(<MaterialCommunityIcons name="filter-variant" size={19} color={BLUE} />, () => setFiltroEqOpen(true), !!filtroEq)}
              {barraBtn(<Ionicons name="search-outline" size={19} color={BLUE} />, () => { setBuscaAbierto(!buscaAbierto); setBuscar(''); }, buscaAbierto)}
            </View>
            {buscaAbierto && (
              <View style={[st.buscaCaja, { backgroundColor: theme.card, borderColor: theme.border }]}>
                <Ionicons name="search-outline" size={16} color="#8FA8C8" />
                <TextInput
                  style={[st.buscaInput, { color: theme.text }]}
                  value={buscar}
                  onChangeText={setBuscar}
                  placeholder={grupoActivo
                    ? L(`Buscar en ${ES_DE_BP[grupoActivo] || grupoActivo}...`, `Search in ${grupoActivo}...`)
                    : L('Buscar ejercicio por nombre...', 'Search exercise by name...')}
                  placeholderTextColor="#4A6080"
                  autoFocus
                />
                {!!buscar && <TouchableOpacity onPress={() => setBuscar('')}><Ionicons name="close-circle" size={17} color="#8FA8C8" /></TouchableOpacity>}
              </View>
            )}
            {filtroEq && (
              <View style={st.filtroChip}>
                <Ionicons name="funnel-outline" size={13} color={BLUE} />
                <Text style={{ color: BLUE, fontSize: 12, fontWeight: '700' }}>{EQUIPOS_ES[filtroEq] || filtroEq}</Text>
                <TouchableOpacity onPress={() => setFiltroEq(null)}><Ionicons name="close" size={14} color={BLUE} /></TouchableOpacity>
              </View>
            )}
          </>
        )}

        {/* ── RAÍZ ── */}
        {vista === 'raiz' && (
          <ScrollView contentContainerStyle={{ padding: 14, gap: 10, paddingBottom: insets.bottom + 30 }}>
            <TouchableOpacity style={[st.fila, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => setVista('mis')} activeOpacity={0.75}>
              <Ionicons name="folder-outline" size={22} color={BLUE} />
              <View style={{ flex: 1 }}>
                <Text style={{ color: theme.text, fontSize: 15, fontWeight: '700' }}>{L('Mis archivos', 'My files')}</Text>
                <Text style={{ color: theme.muted, fontSize: 12, marginTop: 2 }}>
                  {L(`${nArchivos} archivo(s) · carpetas, filtros y búsqueda`, `${nArchivos} file(s) · folders, filters and search`)}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color={theme.muted} />
            </TouchableOpacity>
            <TouchableOpacity style={[st.fila, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => setVista('gym')} activeOpacity={0.75}>
              <MaterialCommunityIcons name="dumbbell" size={22} color="#2DB37A" />
              <View style={{ flex: 1 }}>
                <Text style={{ color: theme.text, fontSize: 15, fontWeight: '700' }}>{L('Ejercicios de gimnasio', 'Gym exercises')}</Text>
                <Text style={{ color: theme.muted, fontSize: 12, marginTop: 2 }}>
                  {L('Carpeta fija por grupo muscular · no editable', 'Fixed folder by muscle group · not editable')}
                </Text>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Ionicons name="lock-closed" size={14} color={theme.muted} />
                <Ionicons name="chevron-forward" size={16} color={theme.muted} />
              </View>
            </TouchableOpacity>
          </ScrollView>
        )}

        {/* ── MIS ARCHIVOS: barra home/subir/carpeta/filtrar/buscar ── */}
        {vista === 'mis' && (
          <>
            <View style={st.barra}>
              {barraBtn(<Ionicons name="home-outline" size={19} color={BLUE} />, () => { setDir(null); setBuscaAbierto(false); setBuscar(''); })}
              {barraBtn(
                subiendo ? <ActivityIndicator size="small" color={BLUE} /> : <Ionicons name="cloud-upload-outline" size={19} color={BLUE} />,
                () => setMenuSubida(true),
              )}
              {barraBtn(<Ionicons name="folder-open-outline" size={19} color={BLUE} />, () => abrirPrompt(L('Nueva carpeta', 'New folder'), crearCarpeta))}
              {barraBtn(<MaterialCommunityIcons name="filter-variant" size={19} color={BLUE} />, () => setFiltroOpen(true), !!filtroTipo)}
              {barraBtn(<Ionicons name="search-outline" size={19} color={BLUE} />, () => { setBuscaAbierto(!buscaAbierto); setBuscar(''); }, buscaAbierto)}
            </View>
            {dir && (
              <View style={st.migas}>
                <TouchableOpacity onPress={() => { setDir(null); setBuscaAbierto(false); setBuscar(''); }}>
                  <Text style={[st.miga, { color: theme.muted }]}>{L('Mis archivos', 'My files')}</Text>
                </TouchableOpacity>
                <Text style={[st.miga, { color: theme.muted }]}> › </Text>
                <Text style={[st.miga, { color: BLUE }]} numberOfLines={1}>{dir.nombre}</Text>
              </View>
            )}
            {buscaAbierto && (
              <View style={[st.buscaCaja, { backgroundColor: theme.card, borderColor: theme.border }]}>
                <Ionicons name="search-outline" size={16} color="#8FA8C8" />
                <TextInput
                  style={[st.buscaInput, { color: theme.text }]}
                  value={buscar}
                  onChangeText={setBuscar}
                  placeholder={L('Buscar por nombre...', 'Search by name...')}
                  placeholderTextColor="#4A6080"
                  autoFocus
                />
                {!!buscar && <TouchableOpacity onPress={() => setBuscar('')}><Ionicons name="close-circle" size={17} color="#8FA8C8" /></TouchableOpacity>}
              </View>
            )}
            {filtroTipo && (
              <View style={st.filtroChip}>
                <Ionicons name="funnel-outline" size={13} color={BLUE} />
                <Text style={{ color: BLUE, fontSize: 12, fontWeight: '700' }}>
                  {(FILTROS.find((f) => f.id === filtroTipo) || {}).es}
                </Text>
                <TouchableOpacity onPress={() => setFiltroTipo(null)}><Ionicons name="close" size={14} color={BLUE} /></TouchableOpacity>
              </View>
            )}
            <FlatList
              data={lista.slice(0, numVis)}
              keyExtractor={(x) => x.key}
              contentContainerStyle={{ padding: 14, paddingBottom: insets.bottom + 30 }}
              onEndReached={() => { if (numVis < lista.length) setNumVis((n) => n + PAGE); }}
              onEndReachedThreshold={0.3}
              ListEmptyComponent={(
                <View style={{ alignItems: 'center', paddingVertical: 50, gap: 10 }}>
                  <Ionicons name="cloud-upload-outline" size={40} color={theme.muted} />
                  <Text style={{ color: theme.muted, fontSize: 13, textAlign: 'center', paddingHorizontal: 24 }}>
                    {buscar || filtroTipo
                      ? L('Sin resultados con este filtro/búsqueda.', 'No results with this filter/search.')
                      : L('Aún no hay nada aquí. Sube un archivo o crea una carpeta con la barra de arriba.', 'Nothing here yet. Upload a file or create a folder from the bar above.')}
                  </Text>
                </View>
              )}
              renderItem={({ item }) => (item.tipo === 'carpeta' ? (
                <TouchableOpacity
                  style={[st.fila, { backgroundColor: theme.card, borderColor: theme.border, marginBottom: 8 }]}
                  onPress={() => { setDir({ id: item.obj.id, nombre: item.obj.nombre }); setBuscaAbierto(false); setBuscar(''); }}
                  onLongPress={() => setMenu({ tipo: 'carpeta', obj: item.obj })}
                  delayLongPress={350}
                  activeOpacity={0.8}
                >
                  <Ionicons name="folder" size={22} color={BLUE} />
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: theme.text, fontSize: 15, fontWeight: '700' }} numberOfLines={1}>{item.obj.nombre}</Text>
                    <Text style={{ color: theme.muted, fontSize: 12, marginTop: 2 }}>
                      {L(`${recuentos[item.obj.id] || 0} archivo(s)`, `${recuentos[item.obj.id] || 0} file(s)`)}
                    </Text>
                  </View>
                  <Ionicons name="chevron-forward" size={16} color={theme.muted} />
                </TouchableOpacity>
              ) : (
                <View style={[st.fila, { backgroundColor: theme.card, borderColor: theme.border, marginBottom: 8 }]}>
                  {/* Miniatura a la izquierda (como los ejercicios de gimnasio) */}
                  {(item.obj.tipo === 'imagen' || item.obj.tipo === 'gif') && item.obj.url ? (
                    <Image source={{ uri: item.obj.url }} style={st.mini} resizeMode="cover" />
                  ) : (
                    <View style={[st.mini, { backgroundColor: theme.background, alignItems: 'center', justifyContent: 'center' }]}>
                      <Ionicons name={ICONO_TIPO[item.obj.tipo] || 'document-outline'} size={18} color={BLUE} />
                    </View>
                  )}
                  {/* Tocar el archivo lo ABRE para verlo; el "+" lo agrega */}
                  <TouchableOpacity style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10 }} activeOpacity={0.7}
                    onPress={() => abrirArchivo(item.obj)}
                    onLongPress={() => setMenu({ tipo: 'file', obj: item.obj })}
                    delayLongPress={350}>
                    <View style={{ flex: 1 }}>
                      <Text style={{ color: theme.text, fontSize: 14, fontWeight: '700' }} numberOfLines={1}>{item.obj.nombre}</Text>
                      <Text style={{ color: theme.muted, fontSize: 12, marginTop: 2 }}>
                        {fmtFecha(item.obj.createdAt)}{item.obj.size ? ` · ${fmtSize(item.obj.size)}` : ''}
                      </Text>
                    </View>
                    <Ionicons name="chevron-forward" size={16} color={theme.muted} />
                  </TouchableOpacity>
                  <TouchableOpacity style={{ padding: 4 }} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                    onPress={() => onSelect({ tipo: item.obj.tipo, url: item.obj.url, nombre: item.obj.nombre, thumb: (item.obj.tipo === 'imagen' || item.obj.tipo === 'gif') ? item.obj.url : null, size: item.obj.size ?? null })}>
                    <Ionicons name="add-circle" size={23} color={BLUE} />
                  </TouchableOpacity>
                </View>
              ))}
            />
          </>
        )}

        {/* ── GIMNASIO: carpetas fijas por parte del cuerpo o lista plana
              (grupo activo, búsqueda por nombre o filtro de material) ── */}
        {(vista === 'gym' || grupoActivo) && (
          !index ? (
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 }}>
              {error
                ? <Text style={{ color: '#E05252', fontSize: 13, textAlign: 'center', paddingHorizontal: 24 }}>{error}</Text>
                : <ActivityIndicator color={BLUE} />}
            </View>
          ) : mostrarPlana ? (
            <FlatList
              data={gymPlana.slice(0, numVis)}
              keyExtractor={(e) => e.id}
              contentContainerStyle={{ padding: 10, paddingBottom: insets.bottom + 30 }}
              onEndReached={() => { if (numVis < gymPlana.length) setNumVis((n) => n + PAGE); }}
              onEndReachedThreshold={0.3}
              ListEmptyComponent={(
                <View style={{ alignItems: 'center', paddingVertical: 40, gap: 8 }}>
                  <Ionicons name="search-outline" size={32} color={theme.muted} />
                  <Text style={{ color: theme.muted, fontSize: 13, textAlign: 'center' }}>
                    {L('Sin ejercicios con esta búsqueda/filtro.', 'No exercises with this search/filter.')}
                  </Text>
                </View>
              )}
              renderItem={filaGymRow}
            />
          ) : (
            <ScrollView contentContainerStyle={{ padding: 14, paddingBottom: insets.bottom + 30 }}>
              {GRUPOS_GYM.map((g) => {
                const n = (porGrupo.get(g.bp) || []).length;
                if (!n) return null;
                return (
                  <TouchableOpacity key={g.bp} style={[st.fila, { backgroundColor: theme.card, borderColor: theme.border, marginBottom: 8 }]} onPress={() => { setVista(`grupo:${g.bp}`); setFiltroEq(null); setBuscaAbierto(false); setBuscar(''); }} activeOpacity={0.75}>
                    <MaterialCommunityIcons name="dumbbell" size={20} color="#2DB37A" />
                    <View style={{ flex: 1 }}>
                      <Text style={{ color: theme.text, fontSize: 15, fontWeight: '700' }}>{g.es}</Text>
                      <Text style={{ color: theme.muted, fontSize: 12, marginTop: 2 }}>{L(`${n} ejercicio(s)`, `${n} exercise(s)`)}</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={16} color={theme.muted} />
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          )
        )}

        {/* ── Menú FILTRAR POR ── */}
        <Modal visible={filtroOpen} transparent animationType="fade" onRequestClose={() => setFiltroOpen(false)}>
          <TouchableOpacity style={st.ov} activeOpacity={1} onPress={() => setFiltroOpen(false)}>
            <TouchableOpacity activeOpacity={1} onPress={() => {}} style={[st.caja, { backgroundColor: theme.card }]}>
              <Text style={[st.cajaTitulo, { color: theme.text }]}>{L('Filtrar por', 'Filter by')}</Text>
              {FILTROS.map((f) => (
                <TouchableOpacity key={String(f.id)} style={st.menuFila} onPress={() => { setFiltroTipo(f.id); setFiltroOpen(false); }}>
                  <Ionicons name={f.icono} size={17} color={filtroTipo === f.id ? BLUE : theme.muted} />
                  <Text style={{ color: filtroTipo === f.id ? BLUE : theme.text, flex: 1, fontSize: 15, fontWeight: filtroTipo === f.id ? '800' : '400' }}>{f.es}</Text>
                  {filtroTipo === f.id && <Ionicons name="checkmark" size={16} color={BLUE} />}
                </TouchableOpacity>
              ))}
            </TouchableOpacity>
          </TouchableOpacity>
        </Modal>

        {/* ── Menú FILTRAR POR material (gimnasio) ── */}
        <Modal visible={filtroEqOpen} transparent animationType="fade" onRequestClose={() => setFiltroEqOpen(false)}>
          <TouchableOpacity style={st.ov} activeOpacity={1} onPress={() => setFiltroEqOpen(false)}>
            <TouchableOpacity activeOpacity={1} onPress={() => {}} style={[st.caja, { backgroundColor: theme.card }]}>
              <Text style={[st.cajaTitulo, { color: theme.text }]}>{L('Filtrar por material', 'Filter by equipment')}</Text>
              <TouchableOpacity style={st.menuFila} onPress={() => { setFiltroEq(null); setFiltroEqOpen(false); }}>
                <MaterialCommunityIcons name="dumbbell" size={17} color={!filtroEq ? BLUE : theme.muted} />
                <Text style={{ color: !filtroEq ? BLUE : theme.text, flex: 1, fontSize: 15, fontWeight: !filtroEq ? '800' : '400' }}>{L('Todo el material', 'All equipment')}</Text>
                {!filtroEq && <Ionicons name="checkmark" size={16} color={BLUE} />}
              </TouchableOpacity>
              {opcionesEq.map((o) => (
                <TouchableOpacity key={o.id} style={st.menuFila} onPress={() => { setFiltroEq(o.id); setFiltroEqOpen(false); }}>
                  <MaterialCommunityIcons name="dumbbell" size={17} color={filtroEq === o.id ? BLUE : theme.muted} />
                  <Text style={{ color: filtroEq === o.id ? BLUE : theme.text, flex: 1, fontSize: 15, fontWeight: filtroEq === o.id ? '800' : '400' }}>
                    {EQUIPOS_ES[o.id] || o.id} ({o.n})
                  </Text>
                  {filtroEq === o.id && <Ionicons name="checkmark" size={16} color={BLUE} />}
                </TouchableOpacity>
              ))}
            </TouchableOpacity>
          </TouchableOpacity>
        </Modal>

        {/* ── Previsualización de ejercicio (tap) con botón añadir ── */}
        <EjercicioViewer
          visible={!!preview}
          gymId={preview?.id}
          nombre={preview?.es || preview?.n}
          onClose={() => setPreview(null)}
          onAdd={() => { if (preview) { onSelect(entryGym(preview)); setPreview(null); } }}
        />

        {/* ── Prompt nombre de carpeta ── */}
        <Modal visible={!!prompt} transparent animationType="fade" onRequestClose={() => setPrompt(null)}>
          <TouchableOpacity style={st.ov} activeOpacity={1} onPress={() => setPrompt(null)}>
            <TouchableOpacity activeOpacity={1} onPress={() => {}} style={[st.caja, { backgroundColor: theme.card }]}>
              <Text style={[st.cajaTitulo, { color: theme.text }]}>{prompt?.titulo}</Text>
              <TextInput
                style={[st.input, { color: theme.text, borderColor: theme.border, backgroundColor: theme.background }]}
                value={promptTxt}
                onChangeText={setPromptTxt}
                placeholder={prompt?.ph || L('Nombre de la carpeta', 'Folder name')}
                placeholderTextColor="#4A6080"
                autoFocus
              />
              <View style={{ flexDirection: 'row', justifyContent: 'flex-end', gap: 10, marginTop: 14 }}>
                <TouchableOpacity style={[st.botonSoft, { backgroundColor: theme.background }]} onPress={() => setPrompt(null)}>
                  <Text style={{ color: theme.text, fontWeight: '700' }}>{L('Cancelar', 'Cancel')}</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[st.botonSoft, { backgroundColor: BLUE, opacity: promptTxt.trim() ? 1 : 0.4 }]}
                  disabled={!promptTxt.trim()}
                  onPress={async () => { const ok = prompt?.onOk; setPrompt(null); await ok?.(promptTxt); }}
                >
                  <Text style={{ color: '#fff', fontWeight: '800' }}>{prompt?.btn || L('Crear', 'Create')}</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          </TouchableOpacity>
        </Modal>

        {/* ── Menú de pulsación larga (mismo patrón que LibreriaDrive) ── */}
        <Modal visible={!!menu} transparent animationType="fade" onRequestClose={() => setMenu(null)}>
          <TouchableOpacity style={st.ov} activeOpacity={1} onPress={() => setMenu(null)}>
            <TouchableOpacity activeOpacity={1} onPress={() => {}} style={[st.caja, { backgroundColor: theme.card }]}>
              {(menu ? (menu.tipo === 'file' ? [
                { k: 'renombrar', icono: 'create-outline', color: theme.text, txt: L('Renombrar', 'Rename'), fn: () => { const m = menu; setMenu(null); abrirPrompt(L('Renombrar archivo', 'Rename file'), (t) => renombrar(m.obj, t), m.obj.nombre, L('Nombre del archivo', 'File name'), L('Renombrar', 'Rename')); } },
                { k: 'mover', icono: 'folder-open-outline', color: theme.text, txt: L('Mover a carpeta', 'Move to folder'), fn: () => { const m = menu; setMenu(null); setMover(m); } },
                { k: 'del', icono: 'trash-outline', color: RED, txt: L('Eliminar', 'Delete'), fn: () => { const m = menu; setMenu(null); eliminarArchivo(m.obj); } },
              ] : [
                { k: 'renombrar', icono: 'create-outline', color: theme.text, txt: L('Renombrar', 'Rename'), fn: () => { const m = menu; setMenu(null); abrirPrompt(L('Renombrar carpeta', 'Rename folder'), (t) => renombrar(m.obj, t), m.obj.nombre, L('Nombre de la carpeta', 'Folder name'), L('Renombrar', 'Rename')); } },
                { k: 'del', icono: 'trash-outline', color: RED, txt: L('Eliminar', 'Delete'), fn: () => { const m = menu; setMenu(null); eliminarCarpeta(m.obj); } },
              ]) : []).map((o) => (
                <TouchableOpacity key={o.k} style={st.menuFila} onPress={o.fn}>
                  <Ionicons name={o.icono} size={17} color={o.color} />
                  <Text style={{ color: o.color, fontSize: 15 }}>{o.txt}</Text>
                </TouchableOpacity>
              ))}
            </TouchableOpacity>
          </TouchableOpacity>
        </Modal>

        {/* ── Menú de SUBIDA: cámara / galería / vídeo (YouTube) / navegar ── */}
        <Modal visible={menuSubida} transparent animationType="fade" onRequestClose={() => setMenuSubida(false)}>
          <TouchableOpacity style={st.ov} activeOpacity={1} onPress={() => setMenuSubida(false)}>
            <TouchableOpacity activeOpacity={1} onPress={() => {}} style={[st.caja, { backgroundColor: theme.card }]}>
              <Text style={[st.cajaTitulo, { color: theme.text }]}>{L('Cargar archivo', 'Add file')}</Text>
              {[
                { k: 'camara', icono: 'camera-outline', txt: L('De la cámara', 'From camera'), fn: () => { setMenuSubida(false); subirDeCamara(); } },
                { k: 'galeria', icono: 'images-outline', txt: L('De la galería', 'From gallery'), fn: () => { setMenuSubida(false); subirDeGaleria(); } },
                { k: 'video', icono: 'videocam-outline', txt: L('Seleccionar vídeo (YouTube)', 'Pick video (YouTube)'), fn: () => { setMenuSubida(false); abrirPrompt(L('Enlace de YouTube', 'YouTube link'), anadirVideoUrl, '', L('https://youtube.com/watch?v=…', 'https://youtube.com/watch?v=…'), L('Añadir', 'Add')); } },
                { k: 'navegar', icono: 'folder-open-outline', txt: L('Navegar (cualquier archivo)', 'Browse (any file)'), fn: () => { setMenuSubida(false); subirNavegando(); } },
              ].map((o) => (
                <TouchableOpacity key={o.k} style={st.menuFila} onPress={o.fn}>
                  <Ionicons name={o.icono} size={17} color={BLUE} />
                  <Text style={{ color: theme.text, fontSize: 15 }}>{o.txt}</Text>
                </TouchableOpacity>
              ))}
            </TouchableOpacity>
          </TouchableOpacity>
        </Modal>

        {/* ── Visor de archivo: imagen a pantalla completa, vídeo de YouTube
              embebido en la app; PDF y demás se abren con el sistema ── */}
        <Modal visible={!!visor} transparent animationType="fade" onRequestClose={() => setVisor(null)}>
          <View style={{ flex: 1, backgroundColor: 'rgba(4,10,20,0.96)' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingTop: 50, paddingBottom: 10, gap: 10 }}>
              <Text style={{ color: '#E8EDF5', flex: 1, fontSize: 14, fontWeight: '700' }} numberOfLines={1}>{visor?.nombre || ''}</Text>
              <TouchableOpacity onPress={() => setVisor(null)} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                <Ionicons name="close-circle" size={30} color="#8FA8C8" />
              </TouchableOpacity>
            </View>
            {visor?.tipo === 'video' ? (
              <VideoYouTube url={visor.url} style={{ marginHorizontal: 12 }} />
            ) : (
              <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 12, paddingBottom: 50 }}>
                {!!visor?.url && <Image source={{ uri: visor.url }} style={{ width: '100%', aspectRatio: 1, borderRadius: 10 }} resizeMode="contain" />}
              </ScrollView>
            )}
          </View>
        </Modal>

        {/* ── Mover archivo: selector de carpeta destino (el mismo que usa
              el botón "Cargar archivo" de los entrenos) ── */}
        <PickerCarpetaArchivos
          visible={!!mover}
          onClose={() => setMover(null)}
          onElegir={(id) => moverA(id)}
          titulo={L('Mover a carpeta', 'Move to folder')}
          textoBoton={L('Mover aquí', 'Move here')}
          me={user}
        />
        <SystemBars />
      </View>
    </Modal>
  );
}

/* ── Visor de ejercicio: gif grande + nombre ES + pasos en español ── */
export function EjercicioViewer({ visible, gymId, nombre, onClose, onAdd }) {
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, 'dark');
  const insets = useSafeAreaInsets();
  const [ex, setEx] = useState(null);
  const [base, setBase] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!visible || !gymId) return;
    let vivo = true;
    setEx(null); setError('');
    (async () => {
      try {
        const user = auth.currentUser;
        const b = await getR2Base(user);
        if (!vivo) return;
        setBase(b);
        setEx(await getGymEx(user, gymId));
      } catch (e) { if (vivo) setError(e.message || 'Error'); }
    })();
    return () => { vivo = false; };
  }, [visible, gymId]);

  const pasos = ex && ex.instruction_steps && ex.instruction_steps.es
    ? ex.instruction_steps.es
    : (ex && ex.instructions && ex.instructions.es ? [ex.instructions.es] : []);

  return (
    <Modal visible={visible} animationType="fade" transparent onRequestClose={onClose}>
      <View style={st.ov}>
        <View style={[st.caja, { backgroundColor: theme.card, borderColor: theme.border, maxHeight: '86%' }]}>
          <View style={st.cajaHeader}>
            <Text style={{ color: theme.text, fontSize: 16, fontWeight: '800', flex: 1 }} numberOfLines={2}>
              {ex?.es || nombre || ''}
            </Text>
            <TouchableOpacity onPress={onClose}><Ionicons name="close" size={24} color="#8FA8C8" /></TouchableOpacity>
          </View>
          <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 20 }} showsVerticalScrollIndicator>
            {base && ex?.m ? (
              <Image source={{ uri: `${base}/gym/${ex.m}` }} style={st.gif} resizeMode="contain" />
            ) : null}
            {!ex && !error && <ActivityIndicator color={BLUE} style={{ marginVertical: 20 }} />}
            {!!error && <Text style={{ color: '#E05252', fontSize: 13, textAlign: 'center' }}>{error}</Text>}
            {ex?.mg && (
              <Text style={{ color: theme.muted, fontSize: 12, textAlign: 'center', marginBottom: 8 }}>
                {ex.bp_es || ES_DE_BP[ex.bp] || ex.bp}{ex.mg ? ` · ${ex.mg}` : ''}{ex.eq ? ` · ${ex.eq}` : ''}
              </Text>
            )}
            {pasos.map((p, i) => (
              <View key={i} style={st.paso}>
                <Text style={{ color: BLUE, fontWeight: '800', fontSize: 13, width: 20 }}>{i + 1}</Text>
                <Text style={{ color: theme.text, fontSize: 13, lineHeight: 19, flex: 1 }}>{p}</Text>
              </View>
            ))}
          </ScrollView>
          {!!onAdd && (
            <TouchableOpacity
              style={{ marginHorizontal: 14, marginBottom: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, backgroundColor: '#4A90E2', borderRadius: 10, paddingVertical: 11 }}
              onPress={onAdd}
            >
              <Ionicons name="add" size={16} color="#fff" />
              <Text style={{ color: '#fff', fontWeight: '800' }}>{L('Añadir al entreno', 'Add to workout')}</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </Modal>
  );
}

/* ── Selector de carpeta de la librería de archivos (para el botón
      "Cargar archivo" de los entrenos): migas Raíz › …, subcarpetas y
      botón "Subir aquí". Misma UX que PickerCarpetaLibreria (sesiones). ── */
export function PickerCarpetaArchivos({ visible, onClose, onElegir, titulo, textoBoton, me }) {
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, 'dark');
  const user = me || auth.currentUser;
  const [dir, setDir] = useState(null);
  const [carpetas, setCarpetas] = useState([]);

  useEffect(() => {
    if (!visible || !user) return;
    setDir(null);
    (async () => {
      await archivosStoreInit(user.uid);
      const all = await archivosStoreAll();
      setCarpetas(all.filter((d) => d.esCarpeta));
    })();
  }, [visible, user]);

  const camino = (id) => {
    const tramo = [];
    let aux = id ? carpetas.find((c) => c.id === id) || null : null;
    while (aux) { tramo.unshift(aux); aux = aux.carpeta ? carpetas.find((c) => c.id === aux.carpeta) || null : null; }
    return tramo;
  };
  const hijas = carpetas.filter((c) => (c.carpeta ?? null) === (dir ? dir.id : null));

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <TouchableOpacity style={st.ov} activeOpacity={1} onPress={onClose}>
        <TouchableOpacity activeOpacity={1} onPress={() => {}} style={[st.caja, { backgroundColor: theme.card }]}>
          <Text style={[st.cajaTitulo, { color: theme.text }]}>{titulo || L('Guardar en la librería', 'Save to library')}</Text>
          <View style={st.migas}>
            <TouchableOpacity onPress={() => setDir(null)}>
              <Text style={[st.miga, { color: !dir ? BLUE : theme.muted }]}>{L('Raíz', 'Root')}</Text>
            </TouchableOpacity>
            {camino(dir ? dir.id : null).map((c) => (
              <TouchableOpacity key={c.id} onPress={() => setDir(c)}>
                <Text style={[st.miga, { color: dir && dir.id === c.id ? BLUE : theme.muted }]}> › {c.nombre}</Text>
              </TouchableOpacity>
            ))}
          </View>
          {hijas.length ? (
            <View style={{ maxHeight: 240 }}>
              {hijas.map((c) => (
                <TouchableOpacity key={c.id} style={st.menuFila} onPress={() => setDir(c)}>
                  <Ionicons name="folder" size={20} color={BLUE} />
                  <Text style={{ color: theme.text, flex: 1 }} numberOfLines={1}>{c.nombre}</Text>
                  <Ionicons name="chevron-forward" size={14} color={theme.muted} />
                </TouchableOpacity>
              ))}
            </View>
          ) : (
            <Text style={{ color: theme.muted, fontSize: 13, paddingVertical: 12 }}>
              {L('Sin subcarpetas aquí.', 'No subfolders here.')}
            </Text>
          )}
          <TouchableOpacity
            style={{ backgroundColor: BLUE, borderRadius: 10, paddingVertical: 11, alignItems: 'center', marginTop: 6 }}
            onPress={() => { onElegir(dir ? dir.id : null); onClose(); }}
          >
            <Text style={{ color: '#fff', fontWeight: '800' }}>{textoBoton || L('Guardar aquí', 'Save here')}</Text>
          </TouchableOpacity>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

const st = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1, gap: 10 },
  headerTitle: { fontSize: 17, fontWeight: '800', flex: 1, textAlign: 'center' },
  barra: { flexDirection: 'row', gap: 8, paddingHorizontal: 14, paddingTop: 10 },
  barraBtn: { width: 42, height: 38, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderRadius: 10 },
  barraBtnActivo: { borderColor: BLUE },
  migas: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 8, gap: 2 },
  miga: { fontSize: 12, fontWeight: '700' },
  buscaCaja: { flexDirection: 'row', alignItems: 'center', gap: 8, marginHorizontal: 14, marginTop: 8, borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8 },
  buscaInput: { flex: 1, fontSize: 14, padding: 0 },
  filtroChip: { flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', marginHorizontal: 14, marginTop: 8, borderWidth: 1, borderColor: BLUE, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4 },
  fila: { flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 12 },
  filaGym: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 8, marginBottom: 8 },
  mini: { width: 46, height: 46, borderRadius: 8, backgroundColor: '#00000022' },
  ov: { flex: 1, backgroundColor: '#00000088', justifyContent: 'center', alignItems: 'center', padding: 20 },
  caja: { width: '100%', maxWidth: 400, borderRadius: 14, padding: 16, maxHeight: '80%' },
  cajaTitulo: { fontSize: 16, fontWeight: '800', marginBottom: 10, color: '#E8EDF5' },
  cajaHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 14, paddingTop: 12, paddingBottom: 8 },
  menuFila: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 11 },
  input: { borderWidth: 1, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 9, fontSize: 14 },
  botonSoft: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 10 },
  gif: { width: '100%', height: 220, backgroundColor: '#00000025', borderRadius: 10, marginVertical: 6 },
  paso: { flexDirection: 'row', gap: 8, paddingHorizontal: 14, paddingVertical: 5 },
});
