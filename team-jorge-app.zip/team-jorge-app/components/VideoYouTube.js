// components/VideoYouTube.js
// ─────────────────────────────────────────────────────────────
// Reproductor de YouTube DENTRO de la app, como lo hacen TrainerPlan y
// similares: react-native-youtube-iframe, que carga la IFrame Player API
// OFICIAL de YouTube sobre react-native-webview (solo JS: sin módulo
// nativo nuevo, seguro para OTA). Extrae el ID del enlace (watch, youtu.be,
// shorts, embed, live) con youtubeIdDe().
//
// Nota: cargar el embed como URL directa del WebView falla en Android con
// "Video player configuration error" (152/153): YouTube rechaza WebViews
// desnudos. La IFrame API + un user-agent de Chrome real son lo que evita
// el rechazo. Si aun así un vídeo falla (p. ej. su autor bloquea el embed),
// se muestra la miniatura con "Ver en YouTube".
// ─────────────────────────────────────────────────────────────
import React, { useCallback, useState } from 'react';
import { Image, Linking, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { youtubeIdDe, normalizarUrl } from '../services/enlaces';

// User-agent de Chrome Android REAL: el WebView por defecto se anuncia con
// "; wv)" y YouTube le niega el reproductor.
const UA_CHROME = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

export default function VideoYouTube({ url, style }) {
  const id = youtubeIdDe(url);
  const [fallo, setFallo] = useState(false);
  const onError = useCallback(() => setFallo(true), []);
  if (!id) return null;

  const abrirFuera = () => { try { Linking.openURL(normalizarUrl(url)); } catch (e) {} };

  return (
    <View style={[{ width: '100%', borderRadius: 10, overflow: 'hidden', backgroundColor: '#000' }, style]}>
      <View style={{ width: '100%', aspectRatio: 16 / 9 }}>
        {fallo ? (
          /* Respaldo: el vídeo bloquea el reproductor embebido → miniatura
             + "Ver en YouTube" */
          <TouchableOpacity style={st.respaldo} activeOpacity={0.85} onPress={abrirFuera}>
            <Image source={{ uri: `https://i.ytimg.com/vi/${id}/hqdefault.jpg` }} style={StyleSheet.absoluteFill} resizeMode="cover" />
            <View style={st.respaldoBoton}>
              <Text style={{ color: '#fff', fontWeight: '800', fontSize: 13 }}>▶ Ver en YouTube</Text>
            </View>
          </TouchableOpacity>
        ) : (
          <YoutubePlayer
            height="100%"
            width="100%"
            videoId={id}
            onError={onError}
            initialPlayerParams={{ controls: true, playsinline: true, preventFullScreen: false }}
            webViewProps={{
              userAgent: UA_CHROME,
              allowsFullscreenVideo: true,
              mediaPlaybackRequiresUserAction: false,
            }}
          />
        )}
      </View>
      <TouchableOpacity style={st.pie} onPress={abrirFuera} hitSlop={{ top: 4, bottom: 4 }}>
        <Text style={{ color: '#53BDEB', fontSize: 12, fontWeight: '700' }}>Ver en YouTube</Text>
      </TouchableOpacity>
    </View>
  );
}

const st = {
  respaldo: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  respaldoBoton: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 999, backgroundColor: 'rgba(0,0,0,0.65)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.4)' },
  pie: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, paddingVertical: 6, backgroundColor: 'rgba(255,255,255,0.06)' },
};
