// components/PasosResumen.js
// ─────────────────────────────────────────────────────────────
// Resumen SOLO LECTURA de los pasos programados de un entreno, con el
// diseño del mockup: barra azul numerada (el texto es el OBJETIVO del
// paso — zona R1/CAMBIO, rango de ritmo… — o su tipo si no tiene) y
// debajo las filas Tipo / Duración y, si el paso tiene objetivo, una
// tercera con el tipo de objetivo y su valor:
//   Zona FC      → "Zone 2 Default: 128-142 ppm" (rango del perfil)
//   Intensidad   → "2 - Muy fácil"
//   Ritmo/FC/Potencia/Elevación/Cadencia → "min-max unidad"
// Los pasos con hijos son grupos de repetición: caja redondeada "Repetir
// N veces" que envuelve al propio paso (SI tiene duración u objetivo
// propio, p.ej. un Intensivo) y a sus hijos; un contenedor vacío no
// pinta barra, como en el mockup.
// El numerado es global y correlativo solo para los pasos con barra.
// ─────────────────────────────────────────────────────────────
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, StyleSheet, useColorScheme } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { Alert, Image, TextInput, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { EjercicioViewer } from './ArchivosPicker';
import VideoYouTube from './VideoYouTube';
import { getGymIndex, getR2Base } from '../services/archivosUpload';
import { getThemeColors, useAppSettings, L } from '../services/appSettings';
import { auth, db } from '../firebaseConfig';
import { doc, getDoc, updateDoc, Timestamp } from 'firebase/firestore';
import { Keyboard } from 'react-native';
import { zonasDeActividad } from '../services/zonas';
import { getCachedProfile } from '../services/profileCache';

const BLUE = '#4A90E2';
const RED = '#E05252';

const TIPOS = {
  'Calentamiento': () => L('Calentamiento', 'Warm-up'),
  'Extensivo': () => L('Extensivo', 'Extensive'),
  'Intensivo': () => L('Intensivo', 'Intensive'),
  'Variable': () => L('Variable', 'Variable'),
  'Recuperación': () => L('Recuperación', 'Recovery'),
  'Entrenamiento tecnico': () => L('Entrenamiento tecnico', 'Tech training'),
  'Enfriarse': () => L('Enfriarse', 'Cool-down'),
  'Otro': () => L('Otro', 'Other'),
};
const tipoTxt = (k) => (TIPOS[k] ? TIPOS[k]() : (k || '—'));

const OBJ_LABELS = {
  'Ritmo': ['Ritmo', 'Pace'],
  'FC media': ['FC media', 'Avg HR'],
  'Zona FC': ['Zona FC', 'HR zone'],
  'Potencia': ['Potencia', 'Power'],
  'Zona potencia': ['Zona potencia', 'Power zone'],
  'Zona ritmo': ['Zona ritmo', 'Pace zone'],
  'Intensidad': ['Intensidad', 'Intensity'],
  'Elevación': ['Elevación', 'Elevation'],
  'Cadencia': ['Cadencia', 'Cadence'],
};
const objLabelTxt = (k) => (OBJ_LABELS[k] ? L(OBJ_LABELS[k][0], OBJ_LABELS[k][1]) : k);

// Escala de sensación 1-10 para el objetivo Intensidad.
const INTENSIDAD = {
  1: ['Muy muy fácil', 'Very, very easy'],
  2: ['Muy fácil', 'Very easy'],
  3: ['Fácil', 'Easy'],
  4: ['Moderado', 'Moderate'],
  5: ['Algo duro', 'Somewhat hard'],
  6: ['Duro', 'Hard'],
  7: ['Muy duro', 'Very hard'],
  8: ['Muy muy duro', 'Very, very hard'],
  9: ['Casi máximo', 'Almost maximal'],
  10: ['Máximo', 'Maximal'],
};

// Texto de la barra: el objetivo del paso si lo tiene (zona "R1"/"CAMBIO",
// rango de ritmo 4:30–4:00…); si no, el tipo.
function tituloPaso(p) {
  if (p.objZona) return p.objZona;
  if (p.objetivo === 'Ritmo' && (p.objMin || p.objMax)) return `${p.objMin || '?'}–${p.objMax || '?'}`;
  if (p.objetivo && p.objMin != null && p.objMin !== '') return `${p.objetivo} ${p.objMin}`;
  return null;
}

// Duración en texto: distancia con unidad, tiempo ya formateado
// ("00:10:00") o minutos → hh:mm:ss, botón de vuelta con referencia.
function durTxt(p) {
  if (p.durTipo === 'Distancia') return `${p.durValor ?? ''} ${p.durUnidad || 'km'}`.trim();
  if (p.durTipo === 'Botón de vuelta') return `${L('Vuelta', 'Lap')} ${p.durValor ?? ''} ${p.durUnidad || ''}`.trim();
  const raw = p.durTexto ?? p.durValor ?? '';
  if (String(raw).includes(':')) return String(raw);
  const mins = Number(raw);
  if (!Number.isFinite(mins) || mins <= 0) return '00:00:00';
  const total = Math.round(mins * 60);
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(Math.floor(total / 3600))}:${pad(Math.floor((total % 3600) / 60))}:${pad(total % 60)}`;
}

// Encuentra la zona del perfil cuyo nombre visible coincide con la elegida
// en el paso (por titulo/label, o por posición "Z2"/"R3" si no tenía).
function zonaPorNombre(lista, nombre, pref) {
  if (!nombre) return null;
  let i = (lista || []).findIndex((z) => (z.titulo || z.label) === nombre);
  if (i >= 0) return lista[i];
  i = (lista || []).findIndex((z, ix) => `${pref}${ix + 1}` === nombre);
  return i >= 0 ? lista[i] : null;
}

// Valor de la columna Objetivo según el tipo de objetivo del paso.
function objetivoTxt(p, zonas) {
  const par = (a, b) => [a, b].filter((x) => x != null && x !== '').join('-');
  switch (p.objetivo) {
    case 'Zona FC': {
      const z = zonaPorNombre(zonas.fc, p.objZona, 'Z');
      const r = z ? par(z.min, z.max) : '';
      return r ? `${p.objZona}: ${r} ppm` : p.objZona;
    }
    case 'Zona ritmo': {
      const z = zonaPorNombre(zonas.ritmo, p.objZona, 'R');
      const r = z ? par(z.min, z.max) : '';
      return r ? `${p.objZona}: ${r} /km` : p.objZona;
    }
    case 'Zona potencia': {
      const z = zonaPorNombre(zonas.pot, p.objZona, 'Z');
      const r = z ? par(z.min, z.max) : '';
      return r ? `${p.objZona}: ${r} W` : p.objZona;
    }
    case 'Intensidad': {
      const e = INTENSIDAD[String(p.objMin)] || INTENSIDAD[p.objMin];
      return e ? `${p.objMin} - ${L(e[0], e[1])}` : String(p.objMin ?? '');
    }
    case 'Ritmo': return `${par(p.objMin, p.objMax)} /km`;
    case 'FC media': return `${par(p.objMin, p.objMax)} ppm`;
    case 'Potencia': return `${par(p.objMin, p.objMax)} W`;
    case 'Elevación': return `${par(p.objMin, p.objMax)} m`;
    case 'Cadencia': return `${par(p.objMin, p.objMax)} rpm`;
    default: return '';
  }
}

// ¿El paso tiene contenido propio (duración u objetivo)? Los contenedores
// de repetición sin nada propio no pintan barra (mockup); un "Intensivo"
// con su duración y una recuperación dentro SÍ pinta la suya.
function conContenido(p) {
  const dur = String(p.durTexto ?? p.durValor ?? '').trim();
  if (dur && dur !== '0') return true;
  return !!(p.objZona || p.objMin || p.objMax);
}

// Numerado global correlativo (1,2,3…) de los pasos que se pintan con
// barra: todas las hojas y los contenedores con contenido propio.
function numerar(list, map, contador) {
  (list || []).forEach((p) => {
    if ((p.hijos || []).length > 0) {
      if (conContenido(p)) { map[p.id] = contador.n; contador.n += 1; }
      numerar(p.hijos, map, contador);
    } else {
      map[p.id] = contador.n; contador.n += 1;
    }
  });
}

function Paso({ p, numero, numeros, zonas, esLight, theme }) {
  const reps = Math.max(1, parseInt(p.repeticiones, 10) || 1);
  const hijos = (p.hijos || []).length > 0;
  const borde = esLight ? '#C9D4E2' : '#31435A';
  const objVal = p.objetivo ? objetivoTxt(p, zonas) : '';

  const cuerpo = (!hijos || conContenido(p)) && (
    <>
      <View style={[st.barra, { backgroundColor: esLight ? BLUE : '#2C4160' }]}>
        <View style={[st.barraNum, { backgroundColor: esLight ? '#FFFFFF42' : '#1E3048' }]}>
          <Text style={st.barraNumTxt}>{numero}</Text>
        </View>
        <Text style={st.barraTxt} numberOfLines={1}>{tituloPaso(p) || tipoTxt(p.tipo)}</Text>
      </View>
      <View style={st.campos}>
        <View style={[st.campo, { borderLeftColor: borde }]}>
          <Text style={[st.campoLbl, { color: theme.text }]}>{L('Tipo', 'Type')}</Text>
          <Text style={[st.campoVal, { color: theme.muted }]}>{tipoTxt(p.tipo)}</Text>
        </View>
        <View style={[st.campo, { borderLeftColor: borde }]}>
          <Text style={[st.campoLbl, { color: theme.text }]}>{L('Duración', 'Duration')}</Text>
          <Text style={[st.campoVal, { color: theme.muted }]}>{durTxt(p)}</Text>
        </View>
        {objVal ? (
          <View style={[st.campo, st.campoObjetivo, { borderLeftColor: borde }]}>
            <Text style={[st.campoLbl, { color: theme.text }]} numberOfLines={1}>{objLabelTxt(p.objetivo)}</Text>
            <Text style={[st.campoVal, st.campoValSm, { color: theme.muted }]} numberOfLines={2}>{objVal}</Text>
          </View>
        ) : null}
      </View>
      {/* Vídeo del paso (enlace de YouTube): embebido debajo del paso */}
      {p.videoUrl ? <VideoYouTube url={p.videoUrl} style={{ marginTop: 8 }} /> : null}
    </>
  );

  const anidados = hijos && (p.hijos || []).map((h) => (
    <Paso key={h.id} p={h} numero={numeros[h.id]} numeros={numeros} zonas={zonas} esLight={esLight} theme={theme} />
  ));

  if (hijos) {
    return (
      <View style={[st.repsCaja, { borderColor: borde }]}>
        <View style={st.repsHead}>
          <Ionicons name="repeat" size={16} color={BLUE} />
          <Text style={[st.repsTxt, { color: theme.text }]}>{L('Repetir', 'Repeat')}</Text>
          <View style={[st.repsNum, { backgroundColor: esLight ? '#E8EEF6' : '#1E3048' }]}>
            <Text style={[st.repsNumTxt, { color: theme.text }]}>{reps}</Text>
          </View>
          <Text style={[st.repsTxt, { color: theme.text }]}>{L('veces', 'times')}</Text>
        </View>
        {cuerpo}
        {anidados}
      </View>
    );
  }
  return <View style={st.paso}>{cuerpo}</View>;
}

export default function PasosResumen({ pasos, profileUid, actividad, onUpdatePasos }) {
  const settings0 = useAppSettings();
  const theme0 = getThemeColors(settings0.themeMode, useColorScheme());
  // MODO FUERZA: tarjeta interactiva por ejercicio (series con peso real y tick)
  if (actividad === 'Fuerza' || (pasos || []).some((p) => p.esEjercicio)) {
    return <FuerzaResumen pasos={pasos} theme={theme0} onUpdatePasos={onUpdatePasos} />;
  }
  const settings = useAppSettings(); // re-renderiza al cambiar idioma/tema
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const esLight = theme.background === '#F4F7FB';

  // Zonas del atleta (FC/ritmo/potencia) para pintar los rangos de los
  // objetivos de zona: "Zone 2 Default: 128-142 ppm".
  const [zonas, setZonas] = useState({ fc: [], ritmo: [], pot: [] });
  useEffect(() => {
    (async () => {
      try {
        const uid = profileUid || auth.currentUser?.uid;
        if (!uid) return;
        let prof = await getCachedProfile(uid);
        if (!prof) {
          // Sin caché (p.ej. entrenador viendo el entreno de un atleta cuyo
          // perfil no está cacheado en este dispositivo): se lee de Firestore.
          try {
            const s = await getDoc(doc(db, 'perfiles', uid));
            if (s.exists()) prof = s.data();
          } catch (e2) {}
        }
        if (!prof) return;
        // Rangos de zona de la ACTIVIDAD del entreno (fallback a genéricas)
        setZonas({
          fc: zonasDeActividad(prof, 'FC', actividad),
          ritmo: zonasDeActividad(prof, 'Ritmo', actividad),
          pot: zonasDeActividad(prof, 'Potencia', actividad),
        });
      } catch (e) {}
    })();
  }, [profileUid, actividad]);

  const numeros = {};
  const contador = { n: 1 };
  numerar(pasos, numeros, contador);

  return (
    <View style={st.wrap}>
      {(pasos || []).map((p) => (
        <Paso key={p.id} p={p} numero={numeros[p.id]} numeros={numeros} zonas={zonas} esLight={esLight} theme={theme} />
      ))}
    </View>
  );
}

const st = StyleSheet.create({
  wrap: { gap: 10, marginTop: 4 },
  paso: { gap: 10 },
  barra: {
    flexDirection: 'row', alignItems: 'center', borderRadius: 5, overflow: 'hidden', height: 36,
  },
  // El segmento del número abraza al dígito y deja 12 px de aire del color
  // de la barra antes del título: el borde del segmento queda a la mitad
  // exacta entre el final del número y el principio del título.
  barraNum: { minWidth: 34, paddingHorizontal: 12, height: '100%', alignItems: 'center', justifyContent: 'center' },
  barraNumTxt: { color: '#fff', fontSize: 15, fontWeight: '700' },
  barraTxt: { color: '#fff', fontSize: 15, fontWeight: '700', flex: 1, paddingLeft: 12, paddingRight: 12 },
  campos: { flexDirection: 'row' },
  campo: { flex: 1, borderLeftWidth: 2, paddingLeft: 12, paddingVertical: 2, gap: 4 },
  campoObjetivo: { flex: 1.5 },
  campoLbl: { fontSize: 15, fontWeight: '800' },
  campoVal: { fontSize: 15 },
  campoValSm: { fontSize: 13, lineHeight: 17 },
  repsCaja: { borderWidth: 1.5, borderRadius: 12, padding: 12, gap: 10 },
  repsHead: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  repsTxt: { fontSize: 16, fontWeight: '800' },
  repsNum: { minWidth: 30, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8, alignItems: 'center' },
  repsNumTxt: { fontSize: 15, fontWeight: '800' },
});


/* ── VISTA DE FUERZA (atleta) ──
   · Tarjeta por ejercicio: letra + NOMBRE (tocarlo abre el visor de la
     librería para ver cómo se hace) y debajo el GIF EN GRANDE.
   · Series con sus datos (reps y peso planificado), estilo filas de datos.
   · "Comenzar entreno" arranca un CRONÓMETRO persistente: si te sales de
     la app o se apaga el teléfono, al volver te ofrece seguir donde ibas
     o empezar de nuevo (AsyncStorage con marca de tiempo).
   · En sesión: inputs de kg y ticks MÁS GRANDES; al marcar el tick verde
     el peso de esa serie queda BLOQUEADO (no editable).
   · Los pesos reales y ticks se guardan en el doc del entreno (pasos). ── */
const fmtCrono = (ms) => {
  const t = Math.max(0, Math.round(ms / 1000));
  const h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), ss = t % 60;
  const p2 = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${p2(m)}:${p2(ss)}` : `${p2(m)}:${p2(ss)}`;
};

function PesoInput({ value, onCommit, theme, big, locked }) {
  const [txt, setTxt] = useState(value ?? '');
  const timer = useRef(null);
  useEffect(() => { setTxt(value ?? ''); }, [value]);
  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);
  const change = (t) => {
    setTxt(t);
    if (locked) return;
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => onCommit(t), 400);   // autoguardado suave
  };
  return (
    <TextInput
      style={[
        fr.pesoInput, big && fr.pesoInputBig,
        { backgroundColor: theme.card, borderColor: locked ? '#2DB37A' : theme.border, color: theme.text, opacity: locked ? 0.65 : 1 },
      ]}
      value={txt}
      placeholder="—"
      placeholderTextColor="#4A6080"
      keyboardType="decimal-pad"
      editable={!locked}
      onChangeText={change}
      onBlur={() => {
        if (timer.current) clearTimeout(timer.current);
        if (!locked && txt !== (value ?? '')) onCommit(txt);
      }}
    />
  );
}

function FuerzaResumen({ pasos, theme, onUpdatePasos, workoutId, onGuardarEntreno }) {
  const canEdit = !!onUpdatePasos;
  const [gym, setGym] = useState(null);
  const [base, setBase] = useState('');
  const [viewer, setViewer] = useState(null);          // { gymId, nombre }
  const [ses, setSes] = useState(null);                // { activo, startedAt, accumulated, lastSeen }
  const [now, setNow] = useState(Date.now());          // reloj del cronómetro
  const KEY = workoutId ? `tj_fuerza_ses_v1_${workoutId}` : null;

  useEffect(() => {
    let vivo = true;
    (async () => {
      try {
        const u = auth.currentUser;
        if (!u) return;
        const b = await getR2Base(u);
        const list = await getGymIndex(u);
        if (!vivo) return;
        setBase(b); setGym(list);
      } catch (e) {}
    })();
    return () => { vivo = false; };
  }, []);

  const porId = useMemo(() => {
    const m = new Map();
    for (const e of (gym || [])) m.set(e.id, e);
    return m;
  }, [gym]);

  const guardarSes = (obj) => { if (KEY) AsyncStorage.setItem(KEY, JSON.stringify(obj)).catch(() => {}); };

  // ── Recuperación tras cierre inesperado / salir de la app ──
  useEffect(() => {
    if (!KEY || !canEdit) return;
    let vivo = true;
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(KEY);
        if (!raw || !vivo) return;
        const st = JSON.parse(raw);
        if (!st) return;
        // Sesión ya PARADA (cronómetro detenido sin guardar): se restaura
        // en silencio para poder Guardar con el tiempo y los kg ya echos.
        if (!st.activo) { if ((st.accumulated || 0) > 0) setSes(st); return; }
        const llevado = (st.accumulated || 0) + Math.max(0, (st.lastSeen || st.startedAt || 0) - (st.startedAt || st.lastSeen || 0));
        if (llevado < 5000) { AsyncStorage.removeItem(KEY).catch(() => {}); return; }
        Alert.alert(
          L('Entreno de fuerza a medias', 'Strength workout in progress'),
          L(`Llevabas ${fmtCrono(llevado)}. ¿Seguir por donde ibas o empezar de nuevo?`, `You were at ${fmtCrono(llevado)}. Resume where you left off or start over?`),
          [
            { text: L('Seguir donde iba', 'Resume'), onPress: () => { const t = Date.now(); setNow(t); setSes({ activo: true, startedAt: t, accumulated: llevado, lastSeen: t }); } },
            { text: L('Borrar lo marcado y empezar de nuevo', 'Clear marks and start over'), style: 'destructive', onPress: resetTotal },
            { text: L('Ahora no', 'Not now'), style: 'cancel', onPress: () => setSes(null) },
          ],
        );
      } catch (e) {}
    })();
    return () => { vivo = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Cronómetro: un solo interval que avanza `now` (el texto se repinta
  //    cada segundo sí o sí) y marca lastSeen; la persistencia va en un
  //    effect aparte (nunca dentro de un updater de estado). ──
  const activo = !!(ses && ses.activo);
  useEffect(() => {
    if (!activo) return undefined;
    const iv = setInterval(() => {
      const t = Date.now();
      setNow(t);
      setSes((s0) => (s0 && s0.activo ? { ...s0, lastSeen: t } : s0));
    }, 1000);
    return () => clearInterval(iv);
  }, [activo]);
  useEffect(() => { if (ses && KEY) guardarSes(ses); }, [ses, KEY]);

  const elapsed = ses
    ? (ses.activo ? (ses.accumulated || 0) + Math.max(0, now - (ses.startedAt || now)) : (ses.accumulated || 0))
    : 0;

  const comenzar = () => {
    const t = Date.now();
    setNow(t);
    setSes({ activo: true, startedAt: t, accumulated: 0, lastSeen: t });
  };
  // Parar el crono: la sesión queda DETENIDA (no borrada) para que al
  // Guardar se registre el tiempo real y el inicio, como un entreno sync.
  const parar = () => {
    const t = Date.now();
    setNow(t);
    setSes((s0) => (s0 ? { ...s0, activo: false, accumulated: (s0.accumulated || 0) + Math.max(0, t - (s0.startedAt || t)), lastSeen: t } : s0));
  };
  const reanudar = () => {
    const t = Date.now();
    setNow(t);
    setSes((s0) => (s0 ? { ...s0, activo: true, startedAt: t, lastSeen: t } : s0));
  };
  // Guardar entreno = como sincronizar: se escribe DIRECTAMENTE en el doc
  // (estado 'completo' + duración real + fecha/hora de inicio) sin depender
  // de ningún cableado del modal; después se avisa al padre para refrescar.
  const guardarEntreno = () => {
    Keyboard.dismiss();   // hace blur → commit de cualquier kg a medias
    setTimeout(async () => {
      const payload = ses ? { startedAt: ses.startedAt || Date.now(), elapsedSec: Math.max(0, Math.round(elapsed / 1000)) } : null;
      if (KEY) AsyncStorage.removeItem(KEY).catch(() => {});
      setSes(null);
      if (workoutId) {
        try {
          const upd = { estado: 'completo' };
          if (payload && payload.elapsedSec > 0) upd.duracion = payload.elapsedSec;
          if (payload && payload.startedAt) {
            const d = new Date(payload.startedAt);
            if (!isNaN(d.getTime())) {
              const p2 = (n) => String(n).padStart(2, '0');
              upd.fecha = Timestamp.fromDate(d);
              upd.fechaStr = `${p2(d.getDate())}/${p2(d.getMonth() + 1)}/${p2(d.getFullYear())}`;
            }
          }
          console.log('[fuerza] guardando en doc', workoutId, JSON.stringify(upd));
          await updateDoc(doc(db, 'entrenamientos', workoutId), upd);
        } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
      }
      if (onGuardarEntreno) onGuardarEntreno(payload);
    }, 120);
  };
  function resetTotal() {
    if (KEY) AsyncStorage.removeItem(KEY).catch(() => {});
    setSes(null);   // (setFinOpen ya no existe en esta pantalla: quitarlo evita un ReferenceError al reiniciar el entreno de fuerza)
    if (onUpdatePasos) onUpdatePasos((pasos || []).map((p) => ({ ...p, series: (p.series || []).map((sr) => ({ ...sr, pesoReal: '', hecho: false })) })));
  }

  const letra = (i) => String.fromCharCode(65 + (i % 26));
  const commit = (next) => { if (onUpdatePasos) onUpdatePasos(next); };
  const patchSerie = (pid, sid, patch) => {
    commit((pasos || []).map((p) => (p.id !== pid ? p : {
      ...p, series: (p.series || []).map((sr) => (sr.id === sid ? { ...sr, ...patch } : sr)),
    })));
  };

  return (
    <View style={{ gap: 10 }}>
      {/* Cronómetro / comenzar / terminar */}
      {canEdit && (
        <View style={[fr.cronoBox, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <Ionicons name="barbell-outline" size={20} color="#2DB37A" />
          <Text style={[fr.cronoTxt, { color: theme.text }]}>{fmtCrono(elapsed)}</Text>
          <View style={{ flex: 1 }} />
          {activo ? (
            <TouchableOpacity style={[fr.cronoBtn, { backgroundColor: RED }]} onPress={parar}>
              <Ionicons name="stop" size={15} color="#fff" />
              <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>{L('Parar', 'Stop')}</Text>
            </TouchableOpacity>
          ) : ses ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <TouchableOpacity style={[fr.cronoBtn, { backgroundColor: 'transparent', borderWidth: 1, borderColor: RED }]} onPress={resetTotal}>
                <Ionicons name="trash-outline" size={14} color={RED} />
              </TouchableOpacity>
              <TouchableOpacity style={[fr.cronoBtn, { backgroundColor: '#4A90E2' }]} onPress={reanudar}>
                <Ionicons name="play" size={15} color="#fff" />
                <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>{L('Reanudar', 'Resume')}</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity style={[fr.cronoBtn, { backgroundColor: '#2DB37A' }]} onPress={comenzar}>
              <Ionicons name="play" size={15} color="#fff" />
              <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>{L('Comenzar entreno', 'Start workout')}</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
      {/* Al PARAR el crono: Guardar (registra como completado) o Cancelar
          (descarta la sesión y lo marcado) bien visibles bajo el crono. */}
      {canEdit && ses && !ses.activo && (
        <View style={[fr.finBox, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <TouchableOpacity style={[fr.finBtn, { backgroundColor: '#2DB37A' }]} onPress={guardarEntreno}>
            <Ionicons name="save-outline" size={16} color="#fff" />
            <Text style={{ color: '#fff', fontWeight: '800' }}>{L('Guardar entreno', 'Save workout')}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[fr.finBtn, { backgroundColor: 'transparent', borderWidth: 1, borderColor: RED }]} onPress={resetTotal}>
            <Ionicons name="close-circle-outline" size={16} color={RED} />
            <Text style={{ color: RED, fontWeight: '800' }}>{L('Cancelar entreno', 'Cancel workout')}</Text>
          </TouchableOpacity>
        </View>
      )}
      {(pasos || []).map((p, i) => {
        const ge = p.gymId ? porId.get(p.gymId) : null;
        return (
          <View key={p.id} style={[fr.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
            {/* Letra + nombre (tocar el título abre el visor; sin icono "i") */}
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <View style={fr.badge}><Text style={fr.badgeTxt}>{letra(i)}</Text></View>
              <Text style={{ color: theme.text, fontSize: 15, fontWeight: '800', flex: 1 }} numberOfLines={2}>
                {p.nombre || L('Ejercicio', 'Exercise')}
              </Text>
            </View>
            {!!p.nota && <Text style={{ color: theme.muted, fontSize: 12, marginTop: 4 }}>{p.nota}</Text>}

            {/* GIF EN GRANDE: tocarlo abre el visor (cómo se hace) */}
            <TouchableOpacity activeOpacity={0.85} disabled={!p.gymId} onPress={() => setViewer({ gymId: p.gymId, nombre: p.nombre })}>
            {ge && base ? (
              <Image source={{ uri: `${base}/gym/${ge.m}` }} style={[fr.gifBig, { backgroundColor: theme.background }]} resizeMode="contain" />
            ) : (
              <View style={[fr.gifBig, { backgroundColor: theme.background, alignItems: 'center', justifyContent: 'center' }]}>
                <MaterialCommunityIcons name="dumbbell" size={34} color={theme.muted} />
              </View>
            )}
              {!!p.gymId && (
                <View style={fr.gifHint}>
                  <Ionicons name="information-circle" size={13} color="#fff" />
                  <Text style={{ color: '#fff', fontSize: 10, fontWeight: '700' }}>{L('Ver cómo se hace', "See how it's done")}</Text>
                </View>
              )}
            </TouchableOpacity>

            {/* Series: tarjeta de dos filas (datos arriba, kg realizados
                debajo) para que nada se junté en sesión */}
            <View style={{ marginTop: 8, gap: 6 }}>
              {(p.series || []).map((sr, si) => (
                <View key={sr.id} style={[fr.serieCard, { borderColor: theme.border, backgroundColor: theme.background }, activo && fr.serieCardBig]}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                    <View style={fr.sChip}><Text style={fr.sChipTxt}>{si + 1}</Text></View>
                    <Text style={{ color: theme.text, fontSize: activo ? 14 : 12, flex: 1 }} numberOfLines={1}>
                      {sr.reps ? `${sr.reps} ${L('reps', 'reps')}` : '—'}{sr.peso ? ` · ${sr.peso} kg` : ''}
                    </Text>
                    {canEdit ? (
                      <TouchableOpacity onPress={() => patchSerie(p.id, sr.id, { hecho: !sr.hecho })} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                        <View style={[fr.tick, activo && fr.tickBig, sr.hecho && fr.tickOn]}>
                          <Ionicons name="checkmark" size={activo ? 22 : 15} color={sr.hecho ? '#fff' : theme.muted} />
                        </View>
                      </TouchableOpacity>
                    ) : (
                      !!sr.hecho && <Ionicons name="checkmark-circle" size={18} color="#2DB37A" />
                    )}
                  </View>
                  {canEdit ? (
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 8 }}>
                      <Text style={{ color: theme.muted, fontSize: activo ? 12 : 11 }}>{L('Kg realizados', 'Kg done')}</Text>
                      <PesoInput big={activo} locked={!!sr.hecho} value={sr.pesoReal} theme={theme} onCommit={(t) => patchSerie(p.id, sr.id, { pesoReal: t })} />
                      <Text style={{ color: theme.muted, fontSize: 11 }}>kg</Text>
                      {!!sr.hecho && <Text style={{ color: '#2DB37A', fontSize: 11, fontWeight: '800' }}>{L('bloqueado', 'locked')}</Text>}
                    </View>
                  ) : (
                    !!(sr.pesoReal || sr.hecho) && (
                      <Text style={{ color: theme.muted, fontSize: 11, marginTop: 4 }}>
                        {L('Realizado', 'Done')}: {sr.pesoReal ? `${sr.pesoReal} kg` : ''}{sr.hecho ? ' ✓' : ''}
                      </Text>
                    )
                  )}
                </View>
              ))}
            </View>
          </View>
        );
      })}

      {/* Guardar entreno: marca completado y cierra la sesión del cronómetro */}
      {canEdit && onGuardarEntreno && (
        <TouchableOpacity style={fr.guardarBtn} onPress={guardarEntreno}>
          <Ionicons name="save-outline" size={17} color="#fff" />
          <Text style={{ color: '#fff', fontWeight: '800', fontSize: 14 }}>{L('Guardar entreno', 'Save workout')}</Text>
        </TouchableOpacity>
      )}

      <EjercicioViewer
        visible={!!viewer}
        gymId={viewer?.gymId}
        nombre={viewer?.nombre}
        onClose={() => setViewer(null)}
      />
    </View>
  );
}

const fr = StyleSheet.create({
  card: { borderRadius: 12, borderWidth: 1, padding: 12 },
  badge: { width: 26, height: 26, borderRadius: 6, backgroundColor: '#4A90E2', alignItems: 'center', justifyContent: 'center' },
  badgeTxt: { color: '#fff', fontWeight: '800', fontSize: 14 },
  gifBig: { width: '100%', height: 170, borderRadius: 10, marginTop: 8 },
  serieCard: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 9 },
  serieCardBig: { paddingHorizontal: 12, paddingVertical: 12 },
  sChip: { width: 22, height: 22, borderRadius: 6, backgroundColor: '#4A90E222', borderWidth: 1, borderColor: '#4A90E2', alignItems: 'center', justifyContent: 'center' },
  sChipTxt: { color: '#4A90E2', fontWeight: '800', fontSize: 11 },
  pesoInput: { width: 52, borderWidth: 1, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 4, fontSize: 12, textAlign: 'center' },
  pesoInputBig: { width: 80, paddingVertical: 10, fontSize: 16, borderRadius: 8 },
  tick: { width: 26, height: 26, borderRadius: 6, borderWidth: 1, borderColor: '#2DB37A', alignItems: 'center', justifyContent: 'center' },
  tickBig: { width: 38, height: 38, borderRadius: 8 },
  tickOn: { backgroundColor: '#2DB37A' },
  cronoBox: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10 },
  cronoTxt: { fontSize: 20, fontWeight: '800', fontVariant: ['tabular-nums'] },
  cronoBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 9 },
  guardarBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#2DB37A', borderRadius: 12, paddingVertical: 13 },
  gifHint: { position: 'absolute', bottom: 6, left: 6, flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#00000099', borderRadius: 999, paddingHorizontal: 8, paddingVertical: 3 },
  finBox: { flexDirection: 'row', gap: 10, borderWidth: 1, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 10 },
  finBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, borderRadius: 10, paddingVertical: 11 },
});
