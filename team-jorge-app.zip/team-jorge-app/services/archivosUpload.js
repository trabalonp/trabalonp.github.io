// services/archivosUpload.js
/* ══════════════════════════════════════════════════════════════════════
   SUBIDA DE ARCHIVOS DE ENTRENO A CLOUDFLARE R2 + LIBRERÍA DE ARCHIVOS
   ──────────────────────────────────────────────────────────────────────
   · presignArchivos(): pide al servidor (/api/archivos/presign) una URL
     firmada; la app sube el BINARIO directo al bucket (PUT) bajo
     archivos/{uid}/… Nunca se tocan las claves de R2.
   · subirArchivoDeEntreno(): presign + PUT + alta en Firestore
     (`archivosLib`) + alta en el almacén local → "si subes un archivo, se
     agrega automáticamente a tu librería de archivos".
   · borrarArchivoDeR2(): llama al servidor (/api/archivos/delete) para que
     borre el BINARIO del bucket al quitar el archivo de la librería → no
     quedan huérfanos en R2. El servidor valida que la clave sea
     archivos/{uid}/… del usuario autenticado (la app nunca ve claves).
   · Cachés de la librería de GIMNASIO (carpeta fija gym/… en R2):
     getR2Base()  → /api/archivos/config (dominio público del bucket)
     getGymIndex()→ {base}/gym/index.json (AsyncStorage 24 h, fallback caché)
     getGymEx(id) → {base}/gym/ex/{id}.json (pasos en español; caché eterna)
   ══════════════════════════════════════════════════════════════════════ */
import * as FileSystem from 'expo-file-system/legacy';  // uploadAsync clásico (la API nueva lo depreca)
import AsyncStorage from '@react-native-async-storage/async-storage';
import { addDoc, collection } from 'firebase/firestore';
import { db } from '../firebaseConfig';
import { getApiUrl } from './api';
import { archivosStorePut } from './archivosStore';

/* Método de subida binario (legacy expo-file-system): BINARY_CONTENT, con
   fallbacks por si el enum viene con otro nombre en alguna versión.
   FIX 29/09: antes el uploadType se resolvía con un miembro del enum que NO
   EXISTE (BINARY_UPLOAD; los reales son BINARY_CONTENT y MULTIPART), así que
   al nativo llegaba undefined y expo-file-system legacy crasheaba con
   «NullPointerException: FileSystemUploadType.ordinal()» al subir un archivo
   desde un entreno. Misma protección que ya usan SocialScreen y avatarCache. */
const BIN_UPLOAD = (() => {
  try {
    const M = FileSystem.FileSystemUploadMethod || FileSystem.FileSystemUploadType || {};
    if (typeof M.BINARY_CONTENT === 'number') return M.BINARY_CONTENT;
    if (typeof M.MULTIPART === 'number') return M.MULTIPART === 0 ? 1 : 0;
  } catch (e) {}
  return 0;
})();

export function tipoDeArchivo(nombre, contentType) {
  const ext = (String(nombre || '').match(/\.([a-z0-9]+)$/i) || [, ''])[1].toLowerCase();
  const ct = String(contentType || '').toLowerCase();
  if (ct.startsWith('image/gif') || ext === 'gif') return 'gif';
  if (ct.startsWith('image/') || ['jpg', 'jpeg', 'png', 'webp', 'heic'].includes(ext)) return 'imagen';
  if (ct === 'application/pdf' || ext === 'pdf') return 'pdf';
  if (ct.startsWith('video/') || ['mp4', 'mov', 'webm'].includes(ext)) return 'video';
  if (ct.startsWith('audio/') || ['mp3', 'm4a', 'wav'].includes(ext)) return 'audio';
  return 'otro';
}

export async function presignArchivos(user, filename, contentType, size) {
  const apiUrl = (await getApiUrl()).replace(/\/+$/, '');
  const token = await user.getIdToken();
  const r = await fetch(`${apiUrl}/archivos/presign`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ filename, contentType, size }),
  });
  const t = await r.text();
  let d = null;
  try { d = JSON.parse(t); } catch (e) { d = null; }
  if (!r.ok || !d || !d.uploadUrl) throw new Error((d && d.error) || `presign HTTP ${r.status}: ${t.slice(0, 120)}`);
  return d;
}

async function uploadBin(uploadUrl, uri, contentType) {
  const result = await FileSystem.uploadAsync(uploadUrl, uri, {
    httpMethod: 'PUT',
    headers: { 'Content-Type': contentType },
    mimeType: contentType,
    // Doble seguridad: al nativo NUNCA puede llegarle uploadType null/undefined
    // (ese era el NullPointerException de la subida desde un entreno).
    uploadType: typeof BIN_UPLOAD === 'number' ? BIN_UPLOAD : 0,
  });
  const status = Number(result && result.status);
  if (status && (status < 200 || status >= 300)) throw new Error(`R2 upload HTTP ${status}`);
  return result;
}

/* Sube un archivo local a R2 y lo registra en la librería de archivos del
   usuario (Firestore + almacén local). Devuelve el entry listo para
   adjuntar al entreno. `carpeta` = id de la carpeta de la librería donde
   se deja (null = raíz). */
export async function subirArchivoDeEntreno(user, { uri, nombre, contentType, size, carpeta = null }) {
  const ct = contentType || 'application/octet-stream';
  const d = await presignArchivos(user, nombre || 'archivo', ct, size || 0);
  await uploadBin(d.uploadUrl, uri, ct);
  const entry = {
    userId: user.uid,
    nombre: nombre || 'archivo',
    tipo: tipoDeArchivo(nombre, ct),
    url: d.publicUrl,
    size: size || 0,
    contentType: ct,
    carpeta,
    origen: 'subida',
    createdAt: new Date().toISOString(),
  };
  const ref = await addDoc(collection(db, 'archivosLib'), entry);
  const conId = { ...entry, id: ref.id };
  await archivosStorePut(conId);
  return conId;
}

/* Borra el BINARIO de un archivo de la librería en R2 a través del servidor
   (/api/archivos/delete). Contrato para el que llama (ArchivosPicker):
   · { ok:true }                 → objeto borrado del bucket (DeleteObject es
                                   idempotente: si ya no existía, también ok).
   · { ok:true, sin:'sin-url' }  → el doc no tiene url (nada que borrar).
   · { ok:false, sin:'sin-ruta' }→ 404 de plataforma: servidor SIN redeployar
                                   (el handler nunca devuelve 404). El que
                                   llama puede quitar la entrada de la
                                   librería, pero el binario sigue en R2.
   · cualquier otro error        → LANZA excepción: el que llama NO debe
                                   borrar el doc de Firestore (más vale un
                                   archivo visible que un binario huérfano). */
export async function borrarArchivoDeR2(user, url) {
  if (!url) return { ok: true, sin: 'sin-url' };
  const apiUrl = (await getApiUrl()).replace(/\/+$/, '');
  const token = await user.getIdToken();
  const r = await fetch(`${apiUrl}/archivos/delete`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ url }),
  });
  if (r.status === 404) {
    console.warn('[archivos] /archivos/delete no desplegado (404); el binario sigue en R2');
    return { ok: false, sin: 'sin-ruta' };
  }
  const t = await r.text();
  let d = null;
  try { d = JSON.parse(t); } catch (e) { d = null; }
  if (!r.ok || !d || !d.ok) throw new Error((d && d.error) || `delete HTTP ${r.status}: ${t.slice(0, 120)}`);
  return d;
}

/* ── Lecturas públicas de R2 (librería de gimnasio, carpeta fija) ── */
let r2BaseMem = null;
export async function getR2Base(user) {
  if (r2BaseMem) return r2BaseMem;
  try {
    const cached = await AsyncStorage.getItem('tj_r2base_v1');
    if (cached) { r2BaseMem = cached; return cached; }
  } catch (e) {}
  const apiUrl = (await getApiUrl()).replace(/\/+$/, '');
  const token = await user.getIdToken();
  const r = await fetch(`${apiUrl}/archivos/config`, { headers: { Authorization: `Bearer ${token}` } });
  const d = await r.json().catch(() => null);
  if (!r.ok || !d || !d.publicUrl) throw new Error((d && d.error) || 'R2 no configurado');
  r2BaseMem = d.publicUrl;
  AsyncStorage.setItem('tj_r2base_v1', d.publicUrl).catch(() => {});
  return d.publicUrl;
}

/* Índice de la librería de gimnasio: [{id, n, es, bp, mg, eq}].
   Caché 24 h en AsyncStorage; si la red falla se sirve la caché. */
export async function getGymIndex(user) {
  const KEY = 'tj_gym_index_v1';
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (raw) {
      const c = JSON.parse(raw);
      if (c && Array.isArray(c.list) && Date.now() - (c.ts || 0) < 24 * 3600 * 1000) return c.list;
    }
  } catch (e) {}
  const base = await getR2Base(user);
  try {
    const r = await fetch(`${base}/gym/index.json`);
    if (!r.ok) throw new Error(`index HTTP ${r.status}`);
    const list = await r.json();
    AsyncStorage.setItem(KEY, JSON.stringify({ ts: Date.now(), list })).catch(() => {});
    return list;
  } catch (e) {
    const raw = await AsyncStorage.getItem(KEY).catch(() => null);
    if (raw) {
      const c = JSON.parse(raw);
      if (c && Array.isArray(c.list)) return c.list;
    }
    throw e;
  }
}

/* Detalle de un ejercicio (pasos en español): gym/ex/{id}.json, caché eterna. */
export async function getGymEx(user, id) {
  const KEY = `tj_gym_ex_${id}`;
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  const base = await getR2Base(user);
  const r = await fetch(`${base}/gym/ex/${id}.json`);
  if (!r.ok) throw new Error(`ex HTTP ${r.status}`);
  const ex = await r.json();
  AsyncStorage.setItem(KEY, JSON.stringify(ex)).catch(() => {});
  return ex;
}

/* Rutas de media de un ejercicio: el índice (y cada ex/{id}.json) traen
   `m` (gif) y `t` (miniatura) con su ruta bajo gym/, tal cual se subieron
   del repo (videos/… e images/…). */
export const gymUrls = (base, e) => ({
  gif: `${base}/gym/${e.m}`,
  thumb: `${base}/gym/${e.t}`,
});
