// services/deepLink.js
/* Puente mínimo para abrir un entreno desde una notificación:
   App.js guarda aquí el workoutId del push tocado y avisa a quien esté
   suscrito (HomeScreen, que tiene el modal de detalle). Si aún no hay nadie
   suscrito (arranque en frío), el id queda pendiente y se consume al montar. */
let pendingWorkoutId = null;
const subs = new Set();
let ultimaEntrega = null;   // { id, ts }: deduplica aperturas entre remounts

export function setPendingWorkoutId(id) {
  if (!id) return;
  pendingWorkoutId = id;
  if (subs.size) {
    // Ya hay quien escuche: se entrega y se LIMPIA. Si el id se quedara
    // pendiente, el próximo montaje de HomeScreen lo re-consumiría y la
    // ficha del entreno se abriría otra vez (duplicada).
    subs.forEach((fn) => { try { fn(id); } catch (e) {} });
    pendingWorkoutId = null;
  }
}

/* Deduplicación de apertura compartida entre montajes: la misma ficha no se
   abre dos veces en la misma ventana (antes la guarda vivía dentro del
   efecto de HomeScreen y un remount la reiniciaba). */
export function entregaYaHecha(id, ventanaMs = 10000) {
  const ahora = Date.now();
  if (ultimaEntrega && ultimaEntrega.id === id && ahora - ultimaEntrega.ts < ventanaMs) return true;
  ultimaEntrega = { id, ts: ahora };
  return false;
}

export function consumePendingWorkoutId() {
  const id = pendingWorkoutId;
  pendingWorkoutId = null;
  return id;
}

export function subscribePendingWorkout(fn) {
  subs.add(fn);
  return () => subs.delete(fn);
}
