// services/archivosStore.js
/* ══════════════════════════════════════════════════════════════════════
   ALMACÉN LOCAL DE LA LIBRERÍA DE ARCHIVOS (mismo patrón local-first que
   libreriaStore y chatStore):
   · Los archivos subidos por el usuario viven en Firestore (colección
     `archivosLib`, filtro userId) Y en este almacén de AsyncStorage.
   · Al abrir la librería se pinta el almacén AL INSTANTE y un listener
     onSnapshot mantiene el almacén al día con deltas (added/modified/
     removed). El listado procedural (15 en 15) pagina EN CLIENTE.
   ══════════════════════════════════════════════════════════════════════ */
import AsyncStorage from '@react-native-async-storage/async-storage';

const clave = (uid) => `tj_archivos_v1_${uid || 'anon'}`;
const MAX_DOCS = 1000;

let mem = null;        // { uid, docs: Map(id->doc) }
let initPr = null;
let saveTimer = null;

function safeJson(s, d) {
  try { const v = JSON.parse(s); return v == null ? d : v; } catch (e) { return d; }
}

function persist() {
  if (!mem) return;
  if (saveTimer) clearTimeout(saveTimer);
  const uid = mem.uid;
  saveTimer = setTimeout(() => {
    const arr = [...mem.docs.values()];
    AsyncStorage.setItem(clave(uid), JSON.stringify(arr)).catch(() => {});
  }, 150);
}

async function cargar(uid) {
  const raw = await AsyncStorage.getItem(clave(uid));
  let docs = raw ? safeJson(raw, []) : [];
  if (!Array.isArray(docs)) docs = [];
  const map = new Map();
  for (const d of docs) if (d && d.id) map.set(d.id, d);
  mem = { uid, docs: map };
  persist();
  return mem;
}

export async function archivosStoreInit(uid) {
  if (mem && mem.uid === uid) return mem;
  if (initPr && initPr.uid === uid) return initPr.pr;
  initPr = { uid, pr: cargar(uid).catch((e) => {
    console.warn('[archivosStore] init:', e && e.message);
    mem = { uid, docs: new Map() };
    return mem;
  }) };
  return initPr.pr;
}

export async function archivosStoreAll() {
  if (!mem) return [];
  return [...mem.docs.values()].sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
}

export async function archivosStorePut(list) {
  if (!mem) return;
  const arr = Array.isArray(list) ? list : [list];
  for (const d of arr) {
    if (!d || !d.id) continue;
    mem.docs.set(d.id, { ...d });
  }
  if (mem.docs.size > MAX_DOCS) {
    const recortados = [...mem.docs.values()].slice(0, MAX_DOCS);
    mem.docs = new Map(recortados.map((d) => [d.id, d]));
  }
  persist();
}

export async function archivosStoreRemove(ids) {
  if (!mem) return 0;
  const arr = Array.isArray(ids) ? ids : [ids];
  let n = 0;
  for (const id of arr) if (mem.docs.delete(id)) n++;
  if (n) persist();
  return n;
}
