// App.js
import React, { useEffect, useState } from 'react';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { setPendingWorkoutId } from './services/deepLink';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { onAuthStateChanged } from 'firebase/auth';
import { Ionicons } from '@expo/vector-icons';
import { auth, db } from './firebaseConfig';
import { doc, setDoc } from 'firebase/firestore';
import * as Notifications from 'expo-notifications';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Device from 'expo-device';
import {
  View,
  ActivityIndicator,
  StyleSheet,
  Alert,
  Platform,
  Pressable,
  Text,
  useColorScheme,
  StatusBar,
} from 'react-native';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import LoginScreen        from './screens/LoginScreen';
import HomeScreen         from './screens/HomeScreen';
import CalendarScreen     from './screens/CalendarScreen';
import AnalysisScreen     from './screens/AnalysisScreen';
import SettingsScreen     from './screens/SettingsScreen';
import SyncSettingsScreen from './screens/SyncSettingsScreen';
import GarminLoginScreen  from './screens/GarminLoginScreen';
import ProfileScreen      from './screens/ProfileScreen';
import ZonesScreen        from './screens/ZonesScreen';
import MarcasScreen       from './screens/MarcasScreen';
import DonationScreen     from './screens/DonationScreen';
import CoachScreen        from './screens/CoachScreen';
import AppSettingsScreen  from './screens/AppSettingsScreen';
import SupportScreen      from './screens/SupportScreen';
import SocialScreen       from './screens/SocialScreen';
import NotificacionesScreen from './screens/NotificacionesScreen';
import SystemBars         from './components/SystemBars';
import { getThemeColors, useAppSettings } from './services/appSettings';

const Stack = createNativeStackNavigator();

// Ref global de navegación para el deep link de notificaciones. Se crea con
// require + guardia (nunca con named-import en module scope): si algo fallara
// al resolverlo, la app ARRANCA IGUAL y solo se pierde el deep link.
let navigationRef = null;
try {
  const Nav = require('@react-navigation/native');
  if (typeof Nav.createNavigationContainerRef === 'function') {
    navigationRef = Nav.createNavigationContainerRef();
  }
} catch (e) {}
const Tab   = createBottomTabNavigator();

const NAVY   = '#0D1B2A';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';

// Manejador GLOBAL de notificaciones en primer plano: el banner/lista se
// muestra en CUALQUIER pantalla de la app (antes solo se configuraba al
// montar el chat social, así que un push con la app abierta en otra
// pestaña podía no pintarse, sobre todo en iOS).
try {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowBanner: true,
      shouldShowList: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
    }),
  });
} catch (e) {}

// Tema oscuro: evita fondos blancos por defecto en transiciones y modales
const NAV_THEME = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: NAVY,
    card: NAVY,
  },
};

function EmptyScreen() {
  const settings = useAppSettings();
  const colors = getThemeColors(settings.themeMode, useColorScheme());
  return <View style={{ flex: 1, backgroundColor: colors.background }} />;
}

function MainTabs() {
  const insets = useSafeAreaInsets();
  const settings = useAppSettings();
  const colors = getThemeColors(settings.themeMode, useColorScheme());
  const bottomPad = insets.bottom; // sin botones (iPad home, etc.) => 0 y la barra queda a ras
  const BAR_CONTENT_H = 52; // altura útil de la barra (sin la franja de botones del sistema)
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.tab,
          borderTopColor: colors.border,
          borderTopWidth: 1,
          height: BAR_CONTENT_H + bottomPad,
          paddingBottom: bottomPad,
          paddingTop: 0,
        },
        tabBarActiveTintColor:   BLUE,
        tabBarInactiveTintColor: '#4A6080',
        tabBarShowLabel: false,
        // Caja explícita mayor que el icono: evita recortes del wrapper interno
        // (31x28 dp por defecto) y centra el icono con el mismo aire arriba/abajo.
        tabBarIconStyle: { width: 42, height: 42 },
        // Evita que el Dynamic Type (iPad con texto grande) agrande el glifo
        // fuera de su caja y lo recorte.
        tabBarAllowFontScaling: false,
        // Sin ripple negro al pulsar (feedback solo de opacidad)
        tabBarButton: (props) => (
          <Pressable
            {...props}
            android_ripple={{ color: 'transparent' }}
            style={(state) => [
              props.style,
              { opacity: state.pressed ? 0.55 : 1, backgroundColor: 'transparent' },
            ]}
          />
        ),
        tabBarIcon: ({ color, focused }) => {
          const icons = {
            Dashboard: focused ? 'home'        : 'home-outline',
            Calendar:  focused ? 'calendar'    : 'calendar-outline',
            Analisis:  focused ? 'stats-chart' : 'stats-chart-outline',
            Social:    focused ? 'megaphone'    : 'megaphone-outline',
            Settings:  focused ? 'settings'    : 'settings-outline',
          };
          return (
            <Ionicons
              name={icons[route.name]}
              size={30}
              color={color}
              // lineHeight mayor que el size: en iOS el glifo de la fuente de
              // iconos se recortaba por debajo con lineHeight ajustado.
              // marginTop: pequeño descenso óptico pedido a mano.
              style={{ lineHeight: 38, marginTop: 2 }}
            />
          );
        },
      })}
    >
      <Tab.Screen name="Dashboard" component={HomeScreen}     />
      <Tab.Screen name="Calendar"  component={CalendarScreen} />
      <Tab.Screen name="Analisis"  component={AnalysisScreen} />
      <Tab.Screen name="Social"    component={SocialScreen}   />
      <Tab.Screen name="Settings"  component={SettingsScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  const settings = useAppSettings();
  const systemScheme = useColorScheme();
  const colors = getThemeColors(settings.themeMode, systemScheme);
  const [user,    setUser]    = useState(null);
  const [loading, setLoading] = useState(true);

  // Barra negra tras la barra de estado (SystemBars): iconos siempre claros
  useEffect(() => {
    StatusBar.setBarStyle('light-content', true);
    if (Platform.OS === 'android') StatusBar.setBackgroundColor('#000000', true);
  }, []);

  // Idioma del usuario en su perfil: el servidor compone los push en ESTE
  // idioma (el del atleta), no en el del coach que envía el aviso.
  useEffect(() => {
    if (!user) return;
    setDoc(doc(db, 'perfiles', user.uid), { language: settings.language || 'es' }, { merge: true }).catch(() => {});
  }, [user, settings.language]);

  // Deep link de notificaciones: tocar un push abre la app Y el entreno al
  // que se refiere (data.workoutId). Cubre app en primer plano, en segundo
  // plano y arrancada en frío desde el toque.
  useEffect(() => {
    try {
      // El mismo toque llega DOS veces: por el listener de respuesta y por
      // getLastNotificationResponseAsync (que devuelve el último toque aunque
      // ya se haya procesado). Esta guarda los deduplica por contenido+fecha
      // dentro de una ventana corta; un toque posterior del mismo push sigue
      // funcionando porque la ventana ya habrá pasado.
      let ultimaResp = null;
      const abrir = (response) => {
        try {
          const data = response?.notification?.request?.content?.data;
          console.log('[deeplink] data del push:', JSON.stringify(data || null));
          if (!navigationRef || !navigationRef.isReady || !navigationRef.isReady()) return;
          const respKey = `${response?.notification?.request?.date ?? ''}|${data?.workoutId || data?.messageId || ''}`;
          if (ultimaResp && ultimaResp.key === respKey && Date.now() - ultimaResp.ts < 30000) {
            console.log('[deeplink] respuesta de push duplicada ignorada');
            return;
          }
          ultimaResp = { key: respKey, ts: Date.now() };
          // Push de un mensaje del chat social → abre el Tablón
          if (data?.kind === 'chat' || data?.messageId) {
            navigationRef.navigate('Main', { screen: 'Social', params: { tab: 'tablon', ts: Date.now() } });
            return;
          }
          const wid = data?.workoutId;
          if (!wid) return;
          setPendingWorkoutId(wid);
          navigationRef.navigate('Main', { screen: 'Dashboard' });
        } catch (e) {}
      };
      let sub = null;
      if (typeof Notifications.addNotificationResponseReceived === 'function') {
        sub = Notifications.addNotificationResponseReceived(abrir);
      }
      if (typeof Notifications.getLastNotificationResponseAsync === 'function') {
        Notifications.getLastNotificationResponseAsync().then((r) => { if (r) abrir(r); }).catch(() => {});
      }
      return () => { if (sub && sub.remove) sub.remove(); };
    } catch (e) {
      return undefined;
    }
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return unsub;
  }, []);

  // ── DIAGNÓSTICO DE CRASHES: guarda el último error fatal (mensaje +
  //    stack) y lo muestra en un alert al rearrancar, para depurar con
  //    datos reales en vez de a ciegas. ──
  useEffect(() => {
    try {
      const EU = global.ErrorUtils;
      if (EU && typeof EU.setGlobalHandler === 'function') {
        const prev = EU.getGlobalHandler ? EU.getGlobalHandler() : null;
        EU.setGlobalHandler((error, isFatal) => {
          try {
            AsyncStorage.setItem('tj_last_crash', JSON.stringify({
              ts: new Date().toISOString(),
              isFatal: !!isFatal,
              msg: String((error && error.message) || error),
              stack: String((error && error.stack) || '').slice(0, 1500),
            })).catch(() => {});
          } catch (e) {}
          if (prev) prev(error, isFatal);
        });
      }
    } catch (e) {}
    (async () => {
      try {
        const raw = await AsyncStorage.getItem('tj_last_crash');
        if (!raw) return;
        const c = JSON.parse(raw);
        Alert.alert(
          'Diagnóstico: último cierre inesperado',
          `${c.ts || ''}\n${c.msg || ''}\n\n${(c.stack || '').split('\n').slice(0, 6).join('\n')}`,
          [
            { text: 'OK (borrar)', onPress: () => AsyncStorage.removeItem('tj_last_crash').catch(() => {}) },
            { text: 'Mantener', style: 'cancel' },
          ],
        );
      } catch (e) {}
    })();
  }, []);

  useEffect(() => {
    if (user) {
      registerForPushNotificationsAsync();
    }
  }, [user]);

  async function registerForPushNotificationsAsync() {
    console.log('📱 Iniciando registro de notificaciones...');
    if (!Device.isDevice) {
      console.log('❌ No es un dispositivo físico');
      return;
    }
    console.log('📱 Dispositivo físico detectado');
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    console.log('🔔 Estado actual de permisos:', existingStatus);
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
      console.log('🔔 Permiso solicitado, resultado:', status);
    }
    if (finalStatus !== 'granted') {
      console.log('❌ Permiso denegado');
      Alert.alert(
        'Permiso requerido',
        'Para recibir notificaciones de sincronización, activa los permisos en Ajustes.'
      );
      return;
    }
    console.log('🔔 Permiso concedido, obteniendo token...');
    try {
      const expoPushToken = (await Notifications.getExpoPushTokenAsync()).data;
      console.log('✅ Token obtenido:', expoPushToken);
      try {
        console.log('💾 Guardando token en Firestore para:', user.uid);
        await setDoc(doc(db, 'perfiles', user.uid), { expoPushToken }, { merge: true });
        console.log('✅ Token guardado correctamente en Firestore');
      } catch (e) {
        console.error('❌ Error al guardar token:', e);
        Alert.alert('Error', 'No se pudo guardar el token de notificaciones: ' + e.message);
      }
    } catch (error) {
      console.error('❌ Error al obtener token:', error);
      Alert.alert('Error', 'No se pudo obtener el token de notificación: ' + error.message);
      return;
    }
    if (Platform.OS === 'android') {
      Notifications.setNotificationChannelAsync('default', {
        name: 'Notificaciones generales',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
      });
    }
  }

  if (loading) {
    return (
      <GestureHandlerRootView style={{ flex: 1 }}>
        <SafeAreaProvider>
          <View style={[styles.splash, { backgroundColor: colors.background }]}>
            <ActivityIndicator size="large" color={BLUE} />
          </View>
          <StatusBar barStyle="light-content" backgroundColor="#000000" translucent={false} />
          <SystemBars />
        </SafeAreaProvider>
      </GestureHandlerRootView>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
        <SafeAreaProvider>
          <NavigationContainer ref={navigationRef || undefined} theme={{ ...NAV_THEME, colors: { ...NAV_THEME.colors, background: colors.background, card: colors.card, border: colors.border, text: colors.text, primary: BLUE } }}>
            <StatusBar barStyle="light-content" backgroundColor="#000000" translucent={false} />
          <Stack.Navigator
            screenOptions={{
              headerShown: false,
              contentStyle: { backgroundColor: colors.background },
            }}
          >
            {user ? (
              <Stack.Group>
                <Stack.Screen name="Main"         component={MainTabs}           />
                <Stack.Screen name="SyncSettings" component={SyncSettingsScreen} />
                <Stack.Screen name="GarminLogin"  component={GarminLoginScreen}  />
                <Stack.Screen name="Profile"      component={ProfileScreen}      />
                <Stack.Screen name="Coach"        component={CoachScreen}        />
                <Stack.Screen name="Zones"        component={ZonesScreen}        />
                <Stack.Screen name="Marcas"        component={MarcasScreen}       />
                <Stack.Screen name="Donaciones"   component={DonationScreen}     />
                <Stack.Screen name="AppSettings"  component={AppSettingsScreen}  />
                <Stack.Screen name="Support"      component={SupportScreen}      />
                <Stack.Screen name="Notificaciones" component={NotificacionesScreen} />
              </Stack.Group>
            ) : (
              <Stack.Screen name="Login" component={LoginScreen} />
            )}
          </Stack.Navigator>
        </NavigationContainer>
        <SystemBars />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  splash: {
    flex: 1,
    backgroundColor: NAVY,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
