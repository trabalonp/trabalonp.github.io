// screens/MarcasScreen.js
/* ─────────────────────────────────────────────────────────────
   MARCAS PERSONALES v5 — REDISEÑO VISUAL "SALÓN DE LA FAMA".
   La lógica (carga local-first con caché, escritura en Firestore +
   caché, pruebas/métricas/resultados, wizard, gestión de métricas,
   máscara de tiempo, historial procedural 15 en 15, gráfica de
   puntos con Skia) es la MISMA que la versión v4. Solo cambia la
   capa visual y se añaden animaciones. Sin dependencias nuevas.
   Datos en perfiles/{uid}: marcasDefs, marcasResults, marcasMetrics.
   El servidor añade resultados al detectar récords en las sincronizaciones.
   ───────────────────────────────────────────────────────────── */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, Animated, Easing, FlatList, KeyboardAvoidingView, Modal, Platform,
  Pressable, ScrollView, StatusBar, StyleSheet, Text, TextInput, View,
  useColorScheme,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Canvas, Circle, Path, Skia } from '@shopify/react-native-skia';
import { doc, getDoc, setDoc, Timestamp } from 'firebase/firestore';
import SystemBars from '../components/SystemBars';
import MonthPickerModal from '../components/MonthPickerModal';
import { auth, db } from '../firebaseConfig';
import { cacheProfile, getCachedProfile } from '../services/profileCache';
import { getThemeColors, L, useAppSettings } from '../services/appSettings';

const BLUE = '#4A90E2';
const GOLD = '#F5C518';
const RED = '#E05252';
const PAGE = 15;
const p2 = (n) => String(n).padStart(2, '0');

/* Distancias clásicas de TrainingPeaks: la marca es el TIEMPO en recorrer
   la distancia (menor = mejor). Mismos ids/títulos que DISTANCIAS_CLASICAS
   del servidor (lib/records.js): si un entreno auto-crea la prueba, la app
   la reconoce por título/distancia aunque el id sea otro. */
const METRICAS_TP = [
  { id: 'tp_200',  titulo: '200 m',          distM: 200 },
  { id: 'tp_400',  titulo: '400 m',          distM: 400 },
  { id: 'tp_800',  titulo: '800 m',          distM: 800 },
  { id: 'tp_1500', titulo: '1500 m',         distM: 1500 },
  { id: 'tp_milla', titulo: 'Milla',         distM: 1609.344 },
  { id: 'tp_3000', titulo: '3000 m',         distM: 3000 },
  { id: 'tp_1k',   titulo: '1K',             distM: 1000 },
  { id: 'tp_5k',   titulo: '5K',             distM: 5000 },
  { id: 'tp_10k',  titulo: '10K',            distM: 10000 },
  { id: 'tp_hm',   titulo: 'Half Marathon',  distM: 21097.5 },
  { id: 'tp_mar',  titulo: 'Marathon',       distM: 42194.5 },
];
const ACTIVIDADES = ['Running', 'Ciclismo', 'Natación', 'Fuerza', 'Triatlón', 'Otro', 'Evento'];
const UNIDADES = [
  { id: 'distancia', label: 'Distancia (km)' },
  { id: 'duracion',  label: 'Duración (tiempo)' },
  { id: 'peso',      label: 'Peso (kg)' },
  { id: 'reps',      label: 'Repeticiones' },
];

const esTiempo = (def) => def.tipo === 'dist' || def.unidadTipo === 'duracion';
const esMenorMejor = (def) => esTiempo(def);

function tiempoASeg(txt) {
  const t = String(txt || '').trim();
  if (!t) return null;
  const partes = t.split(':').map((x) => x.trim());
  if (partes.some((x) => x !== '' && !Number.isFinite(Number(x)))) return null;
  let seg = 0;
  if (partes.length === 1) seg = Number(partes[0]) * 60;
  else if (partes.length === 2) seg = Number(partes[0]) * 60 + Number(partes[1] || 0);
  else seg = Number(partes[0]) * 3600 + Number(partes[1] || 0) * 60 + Number(partes[2] || 0);
  if (!Number.isFinite(seg) || seg <= 0) return null;
  return Math.round(seg);
}
function segATiempo(seg) {
  const total = Math.round(Number(seg) || 0);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const ss = total % 60;
  return h > 0 ? `${h}:${p2(m)}:${p2(ss)}` : `${m}:${p2(ss)}`;
}
function fmtValor(def, valor) {
  const v = Number(valor);
  if (!Number.isFinite(v)) return '—';
  if (esTiempo(def)) return segATiempo(v);
  if (def.unidadTipo === 'peso') return `${v.toFixed(1)} kg`;
  if (def.unidadTipo === 'reps') return `${Math.round(v)}`;
  return `${v.toFixed(2)} km`;
}
function unidadLabel(def) {
  if (def.tipo === 'dist') return L('Duración (tiempo)', 'Duration (time)');
  const u = UNIDADES.find((x) => x.id === def.unidadTipo);
  return u ? u.label : def.unidadTipo || '';
}
function parseResultado(def, txt) {
  if (esTiempo(def)) return tiempoASeg(txt);
  const n = Number(String(txt).replace(',', '.'));
  return Number.isFinite(n) && n > 0 ? n : null;
}
/* Pruebas de sprint (200 m, 400 m): el tiempo se teclea en segundos, así
   que "26" pasa a ser "0:26" en vez de "26:00". */
const esSprint = (def) => def.tipo === 'dist' && Number(def.distM) <= 500;

/* Máscara de tiempo: al teclear se corrige sola a hh:mm:ss ("4530" →
   "45:30", "12345" → "1:23:45"), igual que los pasos. En sprints los
   primeros dígitos son segundos ("26" → "0:26", "126" → "1:26"). */
function mascaraTiempo(txt, sprint) {
  const digitos = String(txt || '').replace(/\D/g, '').slice(0, 6);
  if (!digitos) return '';
  const n = digitos.length;
  if (n <= 2) return sprint ? `0:${p2(Number(digitos))}` : digitos;
  if (n <= 4) return `${digitos.slice(0, n - 2)}:${digitos.slice(n - 2)}`;
  return `${digitos.slice(0, n - 4)}:${digitos.slice(n - 4, n - 2)}:${digitos.slice(n - 2)}`;
}
const fmtFecha = (d) => `${p2(d.getDate())}/${p2(d.getMonth() + 1)}/${d.getFullYear()}`;
const fmtFechaTick = (d) => `${p2(d.getDate())}/${p2(d.getMonth() + 1)}/${String(d.getFullYear()).slice(2)}`;


/* ── Paleta extra del rediseño (solo visual) ── */
const GREEN = '#2DB37A';
const GOLD_DARK = '#3A2A00';
const ACT_STYLE = {
  Running:   { color: '#4A90E2', icon: 'run-fast' },
  Ciclismo:  { color: '#2DB37A', icon: 'bike' },
  'Natación': { color: '#22B8CF', icon: 'swim' },
  Fuerza:    { color: '#E05252', icon: 'dumbbell' },
  'Triatlón': { color: '#A78BFA', icon: 'trophy-variant-outline' },
  Otro:      { color: '#8FA8C8', icon: 'star-four-points-outline' },
  Evento:    { color: '#F5C518', icon: 'flag-checkered' },
};
const actStyle = (a) => ACT_STYLE[a] || { color: BLUE, icon: 'medal-outline' };

/* ════════════════════════════════════════════════════════════════════════════
   COMPONENTES VISUALES / ANIMADOS
   ════════════════════════════════════════════════════════════════════════════ */

// Aparece con fundido + deslizamiento (entrada escalonada con `delay`)
function FadeIn({ delay = 0, children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, {
      toValue: 1, duration: 420, delay,
      easing: Easing.out(Easing.cubic), useNativeDriver: true,
    }).start();
  }, [v, delay]);
  return (
    <Animated.View
      style={[style, {
        opacity: v,
        transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [16, 0] }) }],
      }]}
    >
      {children}
    </Animated.View>
  );
}

// Zona pulsable con efecto "muelle"
function Press({ onPress, onLongPress, delayLongPress, disabled, style, children, hitSlop }) {
  const sc = useRef(new Animated.Value(1)).current;
  const to = (value) =>
    Animated.spring(sc, { toValue: value, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <Pressable
      onPress={onPress}
      onLongPress={onLongPress}
      delayLongPress={delayLongPress}
      disabled={disabled}
      hitSlop={hitSlop}
      onPressIn={() => to(0.97)}
      onPressOut={() => to(1)}
    >
      <Animated.View style={[style, { transform: [{ scale: sc }] }]}>{children}</Animated.View>
    </Pressable>
  );
}

// Valor 0→1 en bucle
function useLoop(duration, active = true, easing = Easing.linear) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!active) { v.setValue(0); return undefined; }
    const loop = Animated.loop(Animated.timing(v, { toValue: 1, duration, easing, useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [v, duration, active, easing]);
  return v;
}

// Valor 0→1→0 suave (flotar)
function usePingPong(duration) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(v, { toValue: 1, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [v, duration]);
  return v;
}

// Número que "cuenta" hasta su valor

// Trofeo flotante con rayos giratorios
function TrophyStage({ size = 150, icon = 'trophy', iconSize = 46 }) {
  const spin = useLoop(26000, true);
  const bob = usePingPong(2400);
  const discSize = size * 0.56;
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Animated.View
        style={[StyleSheet.absoluteFill, { transform: [{ rotate: spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] }) }] }]}
      >
        {Array.from({ length: 12 }).map((_, i) => (
          <View key={i} style={[StyleSheet.absoluteFill, { alignItems: 'center', transform: [{ rotate: `${i * 30}deg` }] }]}>
            <View style={{
              marginTop: 4, width: 3, borderRadius: 2, backgroundColor: GOLD,
              height: i % 2 ? size * 0.09 : size * 0.14, opacity: i % 2 ? 0.35 : 0.65,
            }} />
          </View>
        ))}
      </Animated.View>
      <View style={{
        position: 'absolute', width: discSize, height: discSize, borderRadius: discSize / 2,
        backgroundColor: GOLD + '1F', borderWidth: 2, borderColor: GOLD + '88',
      }} />
      <Animated.View style={{ transform: [{ translateY: bob.interpolate({ inputRange: [0, 1], outputRange: [3, -3] }) }] }}>
        <MaterialCommunityIcons name={icon} size={iconSize} color={GOLD} />
      </Animated.View>
    </View>
  );
}

// Estado vacío
function EmptyState({ theme, onAdd }) {
  return (
    <FadeIn>
      <View style={st.empty}>
        <TrophyStage size={170} icon="trophy-outline" iconSize={52} />
        <Text style={[st.emptyTitle, { color: theme.text }]}>{L('Tu sala de trofeos está vacía', 'Your trophy room is empty')}</Text>
        <Text style={[st.txt, { color: theme.muted, textAlign: 'center' }]}>
          {L('Añade una prueba para empezar a registrar tus marcas y ver tu evolución.', 'Add a test to start logging your marks and see your progress.')}
        </Text>
        <Press onPress={onAdd} style={[st.ctaBtn, { backgroundColor: GOLD }]}>
          <Ionicons name="add" size={18} color={GOLD_DARK} />
          <Text style={[st.ctaText, { color: GOLD_DARK }]}>{L('Nueva prueba', 'New test')}</Text>
        </Press>
      </View>
    </FadeIn>
  );
}

// Mini gráfica de tendencia (Skia)
function MiniSpark({ valores, color }) {
  const W = 72, H = 28;
  const geo = useMemo(() => {
    const v = valores.slice(-12);
    if (v.length < 2) return null;
    const mn = Math.min(...v), mx = Math.max(...v), rng = (mx - mn) || 1;
    const p = Skia.Path.Make();
    let lx = 0, ly = 0;
    v.forEach((val, i) => {
      const x = 3 + (i / (v.length - 1)) * (W - 6);
      const y = H - 4 - ((val - mn) / rng) * (H - 8);
      if (i === 0) p.moveTo(x, y); else p.lineTo(x, y);
      lx = x; ly = y;
    });
    return { p, lx, ly };
  }, [valores]);
  if (!geo) return null;
  return (
    <Canvas style={{ width: W, height: H }} pointerEvents="none">
      <Path path={geo.p} color={color} style="stroke" strokeWidth={1.8} strokeJoin="round" strokeCap="round" />
      <Circle cx={geo.lx} cy={geo.ly} r={5} color={color} opacity={0.25} />
      <Circle cx={geo.lx} cy={geo.ly} r={2.6} color={color} />
    </Canvas>
  );
}

// Tarjeta de prueba ("medalla")
function MarcaCard({ def, lista, mejor, mejorRes, theme, delay, onOpen, onAdd }) {
  const vals = lista.map((x) => x.valor).filter(Number.isFinite);
  const prReciente = lista.length > 0 && mejor != null && lista[lista.length - 1].valor === mejor;
  return (
    <FadeIn delay={delay}>
      <Press onPress={onOpen} style={[st.tarjeta, { backgroundColor: theme.card, borderColor: theme.border }]}>
        <View style={[st.stripe, { backgroundColor: GOLD }]} />
        <View style={st.tarjetaBody}>
          <View style={st.tarjetaTop}>
            <View style={[st.medalBadge, { backgroundColor: GOLD + '22', borderColor: GOLD + '77' }]}>
              <MaterialCommunityIcons name="medal-outline" size={18} color={GOLD} />
            </View>
            <Text style={[st.tarjetaNombre, { color: theme.text }]} numberOfLines={1}>{def.titulo}</Text>
            {prReciente && (
              <View style={[st.prChip, { backgroundColor: GREEN + '22', borderColor: GREEN + '66' }]}>
                <Ionicons name="flame" size={11} color={GREEN} />
                <Text style={[st.prChipText, { color: GREEN }]}>PR</Text>
              </View>
            )}
          </View>
          <View style={st.tarjetaMid}>
            {mejor != null
              ? <Text style={[st.mejorGrande, { color: theme.text }]}>{fmtValor(def, mejor)}</Text>
              : <Text style={[st.mejorGrande, { color: theme.muted }]}>—</Text>}
            <MiniSpark valores={vals} color={GOLD} />
          </View>
          <View style={st.tarjetaBottom}>
            <Text style={[st.tarjetaMeta, { color: theme.muted }]} numberOfLines={1}>
              {mejorRes?.fecha
                ? `${L('Récord', 'Record')} · ${fmtFecha(mejorRes.fecha?.toDate ? mejorRes.fecha.toDate() : new Date(mejorRes.fecha))}`
                : L('Sin resultados todavía', 'No results yet')}
            </Text>
            <Press onPress={onAdd} style={[st.addPill, { backgroundColor: GOLD }]} hitSlop={6}>
              <Ionicons name="add" size={15} color={GOLD_DARK} />
              <Text style={[st.addPillText, { color: GOLD_DARK }]}>{L('Resultado', 'Result')}</Text>
            </Press>
          </View>
        </View>
      </Press>
    </FadeIn>
  );
}

// Cabecera de actividad
function ActividadHeader({ actividad, count, theme }) {
  const a = actStyle(actividad);
  return (
    <View style={st.actHeader}>
      <View style={[st.actIcon, { backgroundColor: a.color + '22', borderColor: a.color + '66' }]}>
        <MaterialCommunityIcons name={a.icon} size={18} color={a.color} />
      </View>
      <Text style={[st.seccionActividad, { color: theme.text }]}>{actividad}</Text>
      <View style={[st.countChip, { backgroundColor: a.color + '22' }]}>
        <Text style={[st.countChipText, { color: a.color }]}>{count}</Text>
      </View>
      <View style={[st.actLine, { backgroundColor: theme.border }]} />
    </View>
  );
}

// Título de sección dentro de pantallas completas
function SectionTitle({ children, color = GOLD, theme, style }) {
  return (
    <View style={[st.secRow, style]}>
      <View style={[st.secBar, { backgroundColor: color }]} />
      <Text style={[st.wSub, { color: theme.muted }]}>{children}</Text>
    </View>
  );
}

// Barra de pasos del wizard (se rellena al avanzar)
function StepBar({ paso, theme }) {
  const a = useRef(new Animated.Value(paso === 'metrica' ? 1 : 0)).current;
  useEffect(() => {
    Animated.timing(a, { toValue: paso === 'metrica' ? 1 : 0, duration: 320, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
  }, [paso, a]);
  const dot = (n, active, label) => (
    <View style={st.stepItem}>
      <View style={[st.stepDot, { backgroundColor: active ? GOLD : theme.card, borderColor: active ? GOLD : theme.border }]}>
        <Text style={{ color: active ? GOLD_DARK : theme.muted, fontWeight: '800', fontSize: 12 }}>{n}</Text>
      </View>
      <Text style={{ color: active ? theme.text : theme.muted, fontSize: 12, fontWeight: '700' }}>{label}</Text>
    </View>
  );
  return (
    <View style={st.stepBar}>
      {dot(1, true, L('Actividad', 'Activity'))}
      <View style={[st.stepTrack, { backgroundColor: theme.border }]}>
        <Animated.View style={[st.stepFill, { width: a.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }) }]} />
      </View>
      {dot(2, paso === 'metrica', L('Métrica', 'Metric'))}
    </View>
  );
}

// Campo con icono y foco dorado
function IconInput({ icon, theme, ...props }) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={[st.inputWrap, { backgroundColor: theme.card, borderColor: focused ? GOLD : theme.border }]}>
      <Ionicons name={icon} size={17} color={focused ? GOLD : theme.muted} />
      <TextInput
        {...props}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={[st.inputInner, { color: theme.text }]}
        placeholderTextColor="#4A6080"
      />
    </View>
  );
}

// Caja del menú de unidad: entra con rebote
function PopBox({ children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.spring(v, { toValue: 1, useNativeDriver: true, speed: 16, bounciness: 9 }).start();
  }, [v]);
  return (
    <Animated.View
      style={[style, {
        opacity: v,
        transform: [
          { translateY: v.interpolate({ inputRange: [0, 1], outputRange: [28, 0] }) },
          { scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1] }) },
        ],
      }]}
    >
      {children}
    </Animated.View>
  );
}

/* ══ GRÁFICA DE MARCAS — MISMO DISEÑO que las del detalle de entreno
   (components/ActivityChart.js): Canvas de Skia, rejilla sutil, etiquetas
   mudas de 10 px, línea fina (1.4) con área (0.16) y PUNTO en cada marca.
   X = orden cronológico de las marcas (ticks con fecha DD/MM/AA);
   Y = valor formateado según la prueba (tiempo, km, kg, reps). ══ */
const PAD_L = 46, PAD_R = 12, PAD_T = 10, PAD_B = 24;   // iguales que ActivityChart
const CHART_H = 190;                                    // SMALL_H de ActivityChart
const GRID_LIGHT = 'rgba(21,34,56,0.10)',  GRID_DARK = 'rgba(143,168,200,0.14)';
const AXIS_LIGHT = 'rgba(21,34,56,0.28)',  AXIS_DARK = 'rgba(143,168,200,0.25)';

function niceStep(range, count) {
  const raw = range / Math.max(1, count);
  const mag = Math.pow(10, Math.floor(Math.log10(raw || 1)));
  const norm = raw / mag;
  return (norm >= 5 ? 10 : norm >= 2 ? 5 : norm >= 1 ? 2 : 1) * mag;
}


function GraficaMarcas({ ordenadas, def, theme, isLight }) {
  const [width, setWidth] = useState(0);

  // Animación de "dibujado": la línea se traza de izquierda a derecha y
  // los puntos van apareciendo (se repite al añadir/borrar una marca).
  const [prog, setProg] = useState(0);
  const nMarcas = ordenadas.length;
  useEffect(() => {
    const a = new Animated.Value(0);
    const id = a.addListener(({ value }) => setProg(value));
    Animated.timing(a, { toValue: 1, duration: 1100, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
    return () => { a.removeListener(id); a.stopAnimation(); };
  }, [nMarcas]);

  const geom = useMemo(() => {
    const n = ordenadas.length;
    if (!width || !n) return null;
    const vals = ordenadas.map((m) => Number(m.valor)).filter(Number.isFinite);
    if (!vals.length) return null;
    let yMin = Math.min(...vals), yMax = Math.max(...vals);
    if (yMax === yMin) { yMax += 1; yMin -= 1; }
    const padY = (yMax - yMin) * 0.08;
    yMin -= padY; yMax += padY;
    const iw = width - PAD_L - PAD_R;
    const ih = CHART_H - PAD_T - PAD_B;
    const px = (i) => (n === 1 ? PAD_L + iw / 2 : PAD_L + (i / (n - 1)) * iw);
    const pyv = (v) => PAD_T + ih - ((v - yMin) / (yMax - yMin || 1)) * ih;
    const step = niceStep(yMax - yMin, 3);
    const yTicks = [];
    for (let v = Math.ceil(yMin / step) * step; v <= yMax + 1e-9; v += step) yTicks.push(v);
    const idxTicks = n === 1 ? [0] : n === 2 ? [0, 1] : [...new Set([0, Math.round((n - 1) / 2), n - 1])];
    return { n, iw, ih, px, pyv, yTicks, idxTicks };
  }, [width, ordenadas]);

  const paths = useMemo(() => {
    if (!geom) return null;
    const line = Skia.Path.Make();
    const area = Skia.Path.Make();
    const pts = [];
    ordenadas.forEach((m, i) => {
      const v = Number(m.valor);
      if (!Number.isFinite(v)) return;
      const X = geom.px(i), Y = geom.pyv(v);
      pts.push({ X, Y, i });
      if (pts.length === 1) { line.moveTo(X, Y); area.moveTo(X, Y); }
      else { line.lineTo(X, Y); area.lineTo(X, Y); }
    });
    if (pts.length >= 2) {
      area.lineTo(pts[pts.length - 1].X, PAD_T + geom.ih);
      area.lineTo(pts[0].X, PAD_T + geom.ih);
      area.close();
    }
    return { line, area, pts };
  }, [geom, ordenadas]);

  // Etiqueta del eje Y según la unidad de la prueba (sin el "km" para que
  // quepa en los 46 px del margen, igual que los ritmos en ActivityChart).
  const fmtTick = (v) => {
    if (esTiempo(def)) return segATiempo(v);
    if (def.unidadTipo === 'peso') return v.toFixed(1);
    if (def.unidadTipo === 'reps') return String(Math.round(v));
    return String(Math.round(v * 10) / 10);
  };

  // Mejor marca (se pinta en dorado)
  const valsAll = ordenadas.map((m) => Number(m.valor)).filter(Number.isFinite);
  const mejorV = valsAll.length ? (esMenorMejor(def) ? Math.min(...valsAll) : Math.max(...valsAll)) : null;

  const gridColor = isLight ? GRID_LIGHT : GRID_DARK;
  const axisColor = isLight ? AXIS_LIGHT : AXIS_DARK;
  // El View medidor se monta SIEMPRE: su onLayout da el ancho con el que se
  // calcula la geometría. (Un return null previo impedía medir y la
  // gráfica no salía nunca.)
  return (
    <View
      style={{ width: '100%', height: CHART_H }}
      onLayout={(e) => { const w = e.nativeEvent.layout.width; if (w > 0) setWidth(w); }}
    >
      {geom && paths && (<>
      {/* Rejilla horizontal + etiquetas Y (valores) */}
      {geom.yTicks.map((v, i) => (
        <React.Fragment key={`y${i}`}>
          <View pointerEvents="none" style={{ position: 'absolute', left: PAD_L, right: PAD_R, top: geom.pyv(v), height: 1, backgroundColor: gridColor }} />
          <Text pointerEvents="none" numberOfLines={1} style={{ position: 'absolute', left: 0, width: PAD_L - 6, top: geom.pyv(v) - 7, textAlign: 'right', fontSize: 10, color: theme.muted }}>{fmtTick(v)}</Text>
        </React.Fragment>
      ))}
      {/* Rejilla vertical + etiquetas X (fechas) */}
      {geom.idxTicks.map((idx) => {
        const f = ordenadas[idx] && ordenadas[idx].fecha;
        if (!f) return null;
        const d = f.toDate ? f.toDate() : new Date(f);
        const X = geom.px(idx);
        return (
          <React.Fragment key={`x${idx}`}>
            <View pointerEvents="none" style={{ position: 'absolute', top: PAD_T, height: geom.ih, left: X, width: 1, backgroundColor: gridColor }} />
            <Text pointerEvents="none" numberOfLines={1} style={{ position: 'absolute', bottom: 2, left: Math.max(0, Math.min(X - 26, width - 52)), width: 52, textAlign: 'center', fontSize: 10, color: theme.muted }}>{fmtFechaTick(d)}</Text>
          </React.Fragment>
        );
      })}
      {/* Línea base del eje X */}
      <View pointerEvents="none" style={{ position: 'absolute', left: PAD_L, right: PAD_R, top: CHART_H - PAD_B, height: 1, backgroundColor: axisColor }} />
      {/* Área + línea + UN PUNTO POR MARCA (Skia, como ActivityChart) */}
      <Canvas style={{ position: 'absolute', top: 0, left: 0, width, height: CHART_H }} pointerEvents="none">
        {geom.n >= 2 && <Path path={paths.area} color={BLUE} opacity={0.16 * prog} />}
        {geom.n >= 2 && <Path path={paths.line} color={BLUE} strokeWidth={1.4} style="stroke" start={0} end={prog} />}
        {paths.pts.map((pt, k) => {
          const umbral = paths.pts.length <= 1 ? 0 : k / (paths.pts.length - 1);
          if (prog < umbral - 0.001) return null;
          const esMejor = mejorV != null && Number(ordenadas[pt.i].valor) === mejorV;
          return (
            <React.Fragment key={k}>
              {esMejor && <Circle cx={pt.X} cy={pt.Y} r={8} color={GOLD} opacity={0.25} />}
              <Circle cx={pt.X} cy={pt.Y} r={esMejor ? 4 : 3} color={esMejor ? GOLD : BLUE} />
            </React.Fragment>
          );
        })}
      </Canvas>
      </>)}
    </View>
  );
}

export default function MarcasScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const insets = useSafeAreaInsets();
  const athleteId = route.params?.athleteId;
  const currentUserId = athleteId || auth.currentUser?.uid;
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());

  const [loading, setLoading] = useState(true);
  const [defs, setDefs] = useState([]);          // pruebas: { id, actividad, titulo, tipo, distM?, unidadTipo? }
  const [results, setResults] = useState({});    // { defId: [ { id, valor, fecha, notas, workoutId? } ] }
  const [metricas, setMetricas] = useState([]);  // métricas personalizadas
  const [detalle, setDetalle] = useState(null);  // def cuya gráfica se muestra
  const [form, setForm] = useState(null);        // { def, editando } del formulario de resultado
  const [formValor, setFormValor] = useState('');
  const [formFecha, setFormFecha] = useState(new Date());
  const [formNotas, setFormNotas] = useState('');
  const [formFechaAbierta, setFormFechaAbierta] = useState(false);
  const [saving, setSaving] = useState(false);

  // ── Wizard nueva prueba + gestión de métricas ──
  const [wizard, setWizard] = useState(null);    // null | { paso: 'actividad'|'metrica', actividad? }
  const [gestionOpen, setGestionOpen] = useState(false);
  const [nuevaMetrica, setNuevaMetrica] = useState({ titulo: '', unidadTipo: 'distancia' });
  const [menuUnidad, setMenuUnidad] = useState(false);

  // ── CARGA local-first: perfil cacheado al instante → documento fresco ──
  const aplicar = useCallback((d) => {
    if (!d) return;
    setDefs(Array.isArray(d.marcasDefs) ? d.marcasDefs : []);
    setResults(d.marcasResults && typeof d.marcasResults === 'object' ? d.marcasResults : {});
    setMetricas(Array.isArray(d.marcasMetrics) ? d.marcasMetrics : []);
  }, []);

  useEffect(() => {
    let vivo = true;
    (async () => {
      try {
        const cache = (await getCachedProfile(currentUserId)) || {};
        if (!vivo) return;
        if (cache.marcasDefs) { aplicar(cache); setLoading(false); }
        const snap = await getDoc(doc(db, 'perfiles', currentUserId));
        if (!vivo) return;
        if (snap.exists()) aplicar(snap.data());
      } catch (e) {}
      if (vivo) setLoading(false);
    })();
    return () => { vivo = false; };
  }, [currentUserId, aplicar]);

  // ── Escritura: documento + caché local (la próxima entrada pinta lo nuevo) ──
  const guardarTodo = useCallback(async (nuevasDefs, nuevosResults, nuevasMetricas) => {
    const data = { marcasDefs: nuevasDefs, marcasResults: nuevosResults, marcasMetrics: nuevasMetricas };
    await setDoc(doc(db, 'perfiles', currentUserId), data, { merge: true });
    await cacheProfile(currentUserId, data);
    setDefs(nuevasDefs);
    setResults(nuevosResults);
    setMetricas(nuevasMetricas);
  }, [currentUserId]);

  // ── Aperturas: tap en la tarjeta → gráfica; botón "+ Resultado" → form ──
  const abrirDetalle = (def) => setDetalle(def);
  const abrirForm = (def, editando) => {
    if (editando) {
      setFormValor(esTiempo(def) ? segATiempo(editando.valor) : String(editando.valor));
      setFormFecha(editando.fecha?.toDate ? editando.fecha.toDate() : new Date(editando.fecha));
      setFormNotas(editando.notas || '');
    } else {
      setFormValor(''); setFormNotas(''); setFormFecha(new Date());
    }
    setForm({ def, editando: editando || null });
  };
  const cerrarForm = () => { setForm(null); setFormValor(''); setFormNotas(''); setFormFecha(new Date()); };

  // ── Crear prueba (actividad + métrica) ──
  const crearPrueba = async (actividad, metrica) => {
    const def = metrica.distM != null
      ? { id: `d_${Date.now()}`, actividad, titulo: metrica.titulo, tipo: 'dist', distM: metrica.distM }
      : { id: `d_${Date.now()}`, actividad, titulo: metrica.titulo, tipo: 'custom', unidadTipo: metrica.unidadTipo, mejorMenor: metrica.unidadTipo === 'duracion' };
    if (defs.some((x) => x.actividad === actividad && x.titulo === def.titulo)) {
      Alert.alert(L('Ya existe', 'Already exists'), L('Ya tienes esa prueba para esa actividad.', 'You already have that test for that activity.'));
      return;
    }
    await guardarTodo([...defs, def], { ...results, [def.id]: [] }, metricas);
    setWizard(null);
    abrirDetalle(def);   // estrena la prueba viendo su (vacía) gráfica
  };

  // ── Guardar resultado (nuevo o editado) ──
  const guardarResultado = async (def, editando) => {
    const valor = parseResultado(def, formValor);
    if (valor == null) {
      Alert.alert(L('Valor no válido', 'Invalid value'),
        esTiempo(def) ? L('Escribe el tiempo como 45:30 o 1:23:45.', 'Enter the time as 45:30 or 1:23:45.')
          : L('Escribe el valor numérico de la marca.', 'Enter the numeric value of the mark.'));
      return;
    }
    setSaving(true);
    try {
      const lista = [...(results[def.id] || [])];
      if (editando) {
        const i = lista.findIndex((x) => x.id === editando.id);
        if (i >= 0) lista[i] = { ...lista[i], valor, fecha: Timestamp.fromDate(formFecha), notas: formNotas.trim() };
      } else {
        lista.push({ id: `r_${Date.now()}`, valor, fecha: Timestamp.fromDate(formFecha), notas: formNotas.trim() });
      }
      lista.sort((a, b) => (a.fecha?.toMillis?.() ?? 0) - (b.fecha?.toMillis?.() ?? 0));
      await guardarTodo(defs, { ...results, [def.id]: lista }, metricas);
      cerrarForm();   // si el detalle (gráfica) estaba abierto, se refresca solo
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
    finally { setSaving(false); }
  };

  const eliminarResultado = (def, res) => {
    Alert.alert(L('Eliminar resultado', 'Delete result'), L(`¿Eliminar el resultado del ${fmtFecha(res.fecha?.toDate ? res.fecha.toDate() : new Date(res.fecha))}?`, `Delete the result from ${fmtFecha(res.fecha?.toDate ? res.fecha.toDate() : new Date(res.fecha))}?`), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: () => {
        const lista = (results[def.id] || []).filter((x) => x.id !== res.id);
        guardarTodo(defs, { ...results, [def.id]: lista }, metricas);
      } },
    ]);
  };

  // Eliminar una prueba SOLO desde "Gestionar métricas" (nunca con
  // pulsación larga en la tarjeta, como se pidió explícitamente).
  const eliminarDef = (def) => {
    Alert.alert(L('Eliminar prueba', 'Delete test'), L(`Se eliminará "${def.titulo}" con todos sus resultados.`, `"${def.titulo}" and all its results will be deleted.`), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: () => {
        const res2 = { ...results };
        delete res2[def.id];
        guardarTodo(defs.filter((x) => x.id !== def.id), res2, metricas);
      } },
    ]);
  };

  // ── Métricas personalizadas ──
  const crearMetrica = () => {
    const titulo = nuevaMetrica.titulo.trim();
    if (!titulo) { Alert.alert(L('Falta el título', 'Title required'), L('Escribe el título de la métrica.', 'Type the metric title.')); return; }
    if (metricas.some((m) => m.titulo.toLowerCase() === titulo.toLowerCase())) {
      Alert.alert(L('Ya existe', 'Already exists'), L('Ya tienes una métrica con ese título.', 'A metric with that title already exists.'));
      return;
    }
    setMetricas([...metricas, { id: `mtr_${Date.now()}`, titulo, unidadTipo: nuevaMetrica.unidadTipo }]);
    setNuevaMetrica({ titulo: '', unidadTipo: 'distancia' });
  };
  const eliminarMetrica = (m) => {
    Alert.alert(L('Eliminar métrica', 'Delete metric'), L(`¿Eliminar la métrica "${m.titulo}"?`, `Delete metric "${m.titulo}"?`), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      // OJO: antes solo cambiaba el estado local y al recargar reaparecía:
      // hay que persistir con guardarTodo (documento + caché).
      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: () => guardarTodo(defs, results, metricas.filter((x) => x.id !== m.id)) },
    ]);
  };

  // ── Derivados ──
  const porActividad = useMemo(() => {
    const map = new Map();
    for (const d of defs) {
      if (!map.has(d.actividad)) map.set(d.actividad, []);
      map.get(d.actividad).push(d);
    }
    return [...map.entries()].sort((a, b) => String(a[0]).localeCompare(String(b[0])));
  }, [defs]);

  // Pruebas "puestas" en la actividad del wizard: son las que se listan
  // abajo en "Gestionar métricas" para poder eliminarlas.
  const defsPuestas = useMemo(
    () => (wizard?.actividad ? defs.filter((d) => d.actividad === wizard.actividad) : defs),
    [defs, wizard?.actividad],
  );

  const mejoresDe = (def) => {
    const lista = [...(results[def.id] || [])].sort((a, b) => (a.fecha?.toMillis?.() ?? 0) - (b.fecha?.toMillis?.() ?? 0));
    const vals = lista.map((x) => x.valor).filter(Number.isFinite);
    const mejor = vals.length ? (esMenorMejor(def) ? Math.min(...vals) : Math.max(...vals)) : null;
    const mejorRes = mejor != null ? lista.find((x) => x.valor === mejor) : null;
    return { lista, mejor, mejorRes };
  };


  // ── Resumen para la cabecera (solo visual, derivado de los datos) ──
  let k = 0; // contador para escalonar la entrada de las tarjetas

  return (
    <KeyboardAvoidingView style={[st.container, { backgroundColor: theme.background }]} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      {/* ── Cabecera ── */}
      <View style={[st.header, { borderBottomColor: theme.border, paddingTop: insets.top + 6 }]}>
        <Press onPress={() => navigation.goBack()} style={[st.circleBtn, { backgroundColor: theme.card, borderColor: theme.border }]} hitSlop={10}>
          <Ionicons name="chevron-back" size={22} color="#8FA8C8" />
        </Press>
        <Text style={[st.headerTitle, { color: theme.text }]}>{L('Marcas personales', 'Personal records')}</Text>
        <Press onPress={() => setWizard({ paso: 'actividad' })} style={[st.circleBtn, { backgroundColor: GOLD + '26', borderColor: GOLD + '88' }]} hitSlop={10}>
          <Ionicons name="add" size={22} color={GOLD} />
        </Press>
      </View>

      <ScrollView style={st.scroll} contentContainerStyle={{ paddingBottom: insets.bottom + 40, gap: 6 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        {loading && defs.length === 0 && <ActivityIndicator color={GOLD} style={{ marginTop: 60 }} />}

        {!loading && defs.length === 0 && (
          <EmptyState theme={theme} onAdd={() => setWizard({ paso: 'actividad' })} />
        )}

        {porActividad.map(([actividad, lista]) => (
          <View key={actividad} style={{ marginTop: 12 }}>
            <ActividadHeader actividad={actividad} count={lista.length} theme={theme} />
            {lista.map((def) => {
              const { lista: ordenadas, mejor, mejorRes } = mejoresDe(def);
              const delay = 150 + Math.min(k++ * 70, 700);
              return (
                <MarcaCard
                  key={def.id}
                  def={def}
                  lista={ordenadas}
                  mejor={mejor}
                  mejorRes={mejorRes}
                  theme={theme}
                  delay={delay}
                  onOpen={() => abrirDetalle(def)}
                  onAdd={() => abrirForm(def, null)}
                />
              );
            })}
          </View>
        ))}

        {defs.length > 0 && (
          <Press onPress={() => setWizard({ paso: 'actividad' })} style={[st.botonAniadir, { borderColor: GOLD + '77', backgroundColor: GOLD + '0F' }]}>
            <Ionicons name="add-circle-outline" size={20} color={GOLD} />
            <Text style={{ color: GOLD, fontWeight: '800' }}>{L('Nueva prueba', 'New test')}</Text>
          </Press>
        )}
      </ScrollView>

      {/* ── Wizard A PANTALLA COMPLETA: nueva prueba (actividad → métrica) ── */}
      <Modal visible={!!wizard} animationType="slide" onRequestClose={() => setWizard(null)}>
        {wizard && (
        <View style={{ flex: 1, backgroundColor: theme.background, paddingTop: insets.top }}>
          <View style={[st.wHeader, { borderBottomColor: theme.border }]}>
            <Press onPress={() => (wizard.paso === 'metrica' ? setWizard({ paso: 'actividad' }) : setWizard(null))} style={[st.circleBtn, { backgroundColor: theme.card, borderColor: theme.border }]} hitSlop={10}>
              <Ionicons name={wizard.paso === 'metrica' ? 'chevron-back' : 'close'} size={22} color="#8FA8C8" />
            </Press>
            <Text style={[st.wHeaderTitulo, { color: theme.text }]}>
              {wizard.paso === 'actividad' ? L('Nueva prueba', 'New test') : L('Elige la métrica', 'Choose the metric')}
            </Text>
            <View style={{ width: 40 }} />
          </View>
          <StepBar paso={wizard.paso} theme={theme} />
          <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
            {wizard.paso === 'actividad' && (
              <>
                <Text style={[st.wLead, { color: theme.muted }]}>{L('Elige la actividad', 'Choose the activity')}</Text>
                <View style={st.grid}>
                  {ACTIVIDADES.map((a, i) => {
                    const as = actStyle(a);
                    return (
                      <FadeIn key={a} delay={i * 55} style={st.gridCell}>
                        <Press onPress={() => setWizard({ paso: 'metrica', actividad: a })} style={[st.actTile, { backgroundColor: theme.card, borderColor: as.color + '55' }]}>
                          <View style={[st.actTileIcon, { backgroundColor: as.color + '22', borderColor: as.color + '77' }]}>
                            <MaterialCommunityIcons name={as.icon} size={26} color={as.color} />
                          </View>
                          <Text style={{ color: theme.text, fontSize: 15, fontWeight: '800' }} numberOfLines={1}>{a}</Text>
                        </Press>
                      </FadeIn>
                    );
                  })}
                </View>
              </>
            )}
            {wizard.paso === 'metrica' && (
              <>
                <Text style={[st.wLead, { color: theme.muted }]}>
                  {L('Elige la métrica de la prueba', 'Choose the test metric')} — <Text style={{ color: actStyle(wizard.actividad).color, fontWeight: '800' }}>{wizard.actividad}</Text>
                </Text>
                <View style={st.grid}>
                  {METRICAS_TP.map((m, i) => {
                    const ya = defs.some((d) => d.actividad === wizard.actividad && d.titulo === m.titulo);
                    return (
                      <FadeIn key={m.id} delay={i * 40} style={st.gridCell}>
                        <Press disabled={ya} onPress={() => crearPrueba(wizard.actividad, m)}
                          style={[st.metTile, { backgroundColor: theme.card, borderColor: theme.border }, ya && { opacity: 0.35 }]}>
                          <Text style={{ color: theme.text, fontSize: 20, fontWeight: '800' }} numberOfLines={1}>{m.titulo}</Text>
                          <Text style={{ color: theme.muted, fontSize: 11, marginTop: 2 }} numberOfLines={2}>
                            {L('Marca: tiempo en recorrer la distancia', 'Mark: time to cover the distance')}
                          </Text>
                          {ya && <Ionicons name="checkmark-circle" size={18} color={GOLD} style={st.tileCheck} />}
                        </Press>
                      </FadeIn>
                    );
                  })}
                </View>
                {metricas.length > 0 && (
                  <SectionTitle theme={theme} color={BLUE} style={{ marginTop: 14 }}>{L('PERSONALIZADAS', 'CUSTOM')}</SectionTitle>
                )}
                {metricas.map((m, i) => {
                  const ya = defs.some((d) => d.actividad === wizard.actividad && d.titulo === m.titulo);
                  return (
                    <FadeIn key={m.id} delay={i * 50}>
                      <Press disabled={ya}
                        style={[st.wFila, { backgroundColor: theme.card, borderColor: theme.border }, ya && { opacity: 0.35 }]}
                        onPress={() => crearPrueba(wizard.actividad, { id: m.id, titulo: m.titulo, unidadTipo: m.unidadTipo })}>
                        <View style={[st.miniIcon, { backgroundColor: BLUE + '22' }]}>
                          <Ionicons name="options-outline" size={16} color={BLUE} />
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={{ color: theme.text, fontSize: 16, fontWeight: '700' }}>{m.titulo}</Text>
                          <Text style={{ color: theme.muted, fontSize: 11 }}>
                            {(UNIDADES.find((u) => u.id === m.unidadTipo) || UNIDADES[0]).label}
                          </Text>
                        </View>
                        {ya && <Ionicons name="checkmark-circle" size={18} color={GOLD} />}
                      </Press>
                    </FadeIn>
                  );
                })}
                <Press style={[st.wFila, { borderStyle: 'dashed', borderColor: theme.border, marginTop: 6 }]} onPress={() => setGestionOpen(true)}>
                  <Ionicons name="settings-outline" size={18} color={theme.muted} />
                  <Text style={{ color: theme.muted, fontSize: 15, fontWeight: '700', flex: 1 }}>
                    {L('Gestionar métricas', 'Manage metrics')}
                  </Text>
                  <Ionicons name="chevron-forward" size={16} color={theme.muted} />
                </Press>
              </>
            )}
          </ScrollView>
        </View>
        )}
      </Modal>

      {/* ── Gestionar métricas A PANTALLA COMPLETA (tres secciones: crear
          métrica, métricas personalizadas y, ABAJO, las pruebas que tienes
          puestas en la actividad con botón de eliminar) ── */}
      <Modal visible={gestionOpen} animationType="slide" onRequestClose={() => setGestionOpen(false)}>
        <View style={{ flex: 1, backgroundColor: theme.background, paddingTop: insets.top }}>
          <View style={[st.wHeader, { borderBottomColor: theme.border }]}>
            <Press onPress={() => setGestionOpen(false)} style={[st.circleBtn, { backgroundColor: theme.card, borderColor: theme.border }]} hitSlop={10}>
              <Ionicons name="chevron-back" size={22} color="#8FA8C8" />
            </Press>
            <Text style={[st.wHeaderTitulo, { color: theme.text }]}>{L('Gestionar métricas', 'Manage metrics')}</Text>
            <View style={{ width: 40 }} />
          </View>
          <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
            {/* SECCIÓN 1: añadir nueva métrica personalizada */}
            <FadeIn>
              <SectionTitle theme={theme} color={GOLD}>{L('AÑADIR NUEVA MÉTRICA', 'ADD NEW METRIC')}</SectionTitle>
              <Text style={{ color: theme.muted, fontSize: 12, marginBottom: 10 }}>
                {L('Se añadirá al desplegable de métricas al crear una prueba.', 'It will appear in the metric dropdown when creating a test.')}
              </Text>
              <Text style={st.fieldLabel}>{L('Título', 'Title')}</Text>
              <IconInput
                icon="pricetag-outline"
                theme={theme}
                value={nuevaMetrica.titulo}
                onChangeText={(t) => setNuevaMetrica((m) => ({ ...m, titulo: t }))}
                placeholder={L('Ej: Peso muerto, Natación 500 m…', 'e.g. Deadlift, 500 m swim…')}
              />
              <Text style={[st.fieldLabel, { marginTop: 12 }]}>{L('Unidad de medida', 'Unit of measure')}</Text>
              <Press
                style={[st.inputWrap, { backgroundColor: theme.card, borderColor: theme.border, justifyContent: 'space-between' }]}
                onPress={() => setMenuUnidad(true)}
              >
                <Ionicons name="speedometer-outline" size={17} color={theme.muted} />
                <Text style={{ color: theme.text, fontSize: 14, flex: 1 }}>
                  {(UNIDADES.find((u) => u.id === nuevaMetrica.unidadTipo) || UNIDADES[0]).label}
                </Text>
                <Ionicons name="chevron-down" size={16} color={theme.muted} />
              </Press>
              <Press
                style={[st.ctaBtn, { backgroundColor: GOLD, marginTop: 16, opacity: nuevaMetrica.titulo.trim() ? 1 : 0.4 }]}
                disabled={!nuevaMetrica.titulo.trim()}
                onPress={crearMetrica}
              >
                <Ionicons name="add" size={18} color={GOLD_DARK} />
                <Text style={[st.ctaText, { color: GOLD_DARK }]}>{L('Añadir métrica', 'Add metric')}</Text>
              </Press>
            </FadeIn>

            {/* SECCIÓN 2: métricas personalizadas creadas (plantillas) */}
            <FadeIn delay={120}>
              <SectionTitle theme={theme} color={BLUE} style={{ marginTop: 26 }}>{L('TUS MÉTRICAS PERSONALIZADAS', 'YOUR CUSTOM METRICS')}</SectionTitle>
              {metricas.length === 0 && (
                <Text style={{ color: theme.muted, fontSize: 13, paddingVertical: 10 }}>
                  {L('Todavía no has creado métricas personalizadas.', 'You have no custom metrics yet.')}
                </Text>
              )}
              {metricas.map((m) => (
                <View key={m.id} style={[st.wFila, { backgroundColor: theme.card, borderColor: theme.border }]}>
                  <View style={[st.miniIcon, { backgroundColor: BLUE + '22' }]}>
                    <Ionicons name="options-outline" size={16} color={BLUE} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: theme.text, fontSize: 16, fontWeight: '700' }} numberOfLines={1}>{m.titulo}</Text>
                    <Text style={{ color: theme.muted, fontSize: 12, marginTop: 2 }}>
                      {(UNIDADES.find((u) => u.id === m.unidadTipo) || UNIDADES[0]).label}
                    </Text>
                  </View>
                  <Press onPress={() => eliminarMetrica(m)} style={st.dangerBtn} hitSlop={8}>
                    <Ionicons name="trash-outline" size={17} color={RED} />
                  </Press>
                </View>
              ))}
            </FadeIn>

            {/* SECCIÓN 3 (ABAJO): las pruebas que tienes puestas en esta
                actividad → aquí se eliminan (con confirmación). Al borrarlas
                dejan de salir como seleccionadas en la lista de métricas. */}
            <FadeIn delay={220}>
              <SectionTitle theme={theme} color={RED} style={{ marginTop: 26 }}>
                {wizard?.actividad
                  ? `${L('TIENES PUESTAS EN', 'YOU HAVE ADDED IN')} ${String(wizard.actividad).toUpperCase()}`
                  : L('TIENES PUESTAS', 'YOU HAVE ADDED')}
              </SectionTitle>
              {defsPuestas.length === 0 && (
                <Text style={{ color: theme.muted, fontSize: 13, paddingVertical: 10 }}>
                  {L('No tienes ninguna prueba puesta en esta actividad.', 'You have no tests added for this activity.')}
                </Text>
              )}
              {defsPuestas.map((d) => (
                <View key={d.id} style={[st.wFila, { backgroundColor: theme.card, borderColor: theme.border }]}>
                  <View style={[st.miniIcon, { backgroundColor: GOLD + '22' }]}>
                    <MaterialCommunityIcons name="medal-outline" size={17} color={GOLD} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: theme.text, fontSize: 16, fontWeight: '700' }} numberOfLines={1}>{d.titulo}</Text>
                    <Text style={{ color: theme.muted, fontSize: 12, marginTop: 2 }}>
                      {d.actividad}{(results[d.id] || []).length ? ` · ${(results[d.id] || []).length} ${L('resultados', 'results')}` : ''}
                    </Text>
                  </View>
                  <Press onPress={() => eliminarDef(d)} style={st.dangerBtn} hitSlop={8}>
                    <Ionicons name="trash-outline" size={17} color={RED} />
                  </Press>
                </View>
              ))}
            </FadeIn>
          </ScrollView>
        </View>
      </Modal>

      {/* ── Menú GRANDE: unidad de medida ── */}
      <Modal visible={menuUnidad} transparent animationType="fade" onRequestClose={() => setMenuUnidad(false)}>
        <View style={st.ov}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setMenuUnidad(false)} />
          <PopBox style={[st.caja, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <Text style={[st.cajaTitulo, { color: theme.text }]}>{L('Unidad de medida', 'Unit of measure')}</Text>
            {UNIDADES.map((u) => {
              const activa = nuevaMetrica.unidadTipo === u.id;
              return (
                <Pressable
                  key={u.id}
                  style={({ pressed }) => [st.menuFila, { borderColor: activa ? GOLD : 'transparent', backgroundColor: activa ? GOLD + '1A' : pressed ? theme.input : 'transparent' }]}
                  onPress={() => { setNuevaMetrica((m) => ({ ...m, unidadTipo: u.id })); setMenuUnidad(false); }}
                >
                  <Text style={{ color: activa ? GOLD : theme.text, flex: 1, fontSize: 15, fontWeight: activa ? '800' : '500' }}>{u.label}</Text>
                  {activa && <Ionicons name="checkmark-circle" size={18} color={GOLD} />}
                </Pressable>
              );
            })}
          </PopBox>
        </View>
      </Modal>

      {/* ── Detalle de prueba: SOLO gráfica de puntos + historial ── */}
      <Modal visible={!!detalle} animationType="slide" onRequestClose={() => setDetalle(null)}>
        <DetallePrueba
          key={detalle?.id}
          def={detalle}
          results={detalle ? (results[detalle.id] || []) : []}
          theme={theme}
          onClose={() => setDetalle(null)}
          onAniadirResultado={(def) => abrirForm(def, null)}
          onEditarResultado={(def, res) => abrirForm(def, res)}
          onEliminarResultado={eliminarResultado}
        />
      </Modal>

      {/* ── Formulario de resultado: SOLO se abre con el botón
          "+ Resultado" (tarjeta o detalle) o al editar del historial ── */}
      <Modal visible={!!form} animationType="slide" onRequestClose={cerrarForm}>
        <FormResultado
          def={form?.def}
          editando={form?.editando}
          theme={theme}
          onClose={cerrarForm}
          onGuardar={guardarResultado}
          form={{ valor: formValor, setValor: setFormValor, fecha: formFecha, setFecha: setFormFecha, notas: formNotas, setNotas: setFormNotas, abierta: formFechaAbierta, setAbierta: setFormFechaAbierta, saving }}
        />
      </Modal>

      {/* Calendario para la fecha del resultado (por encima del formulario) */}
      <MonthPickerModal
        visible={formFechaAbierta}
        initialDate={formFecha}
        onClose={() => setFormFechaAbierta(false)}
        onSelect={(d) => { setFormFecha(d); setFormFechaAbierta(false); }}
      />
      <SystemBars />
    </KeyboardAvoidingView>
  );
}

/* ── Detalle de una prueba: SOLO la GRÁFICA DE PUNTOS con todas las
      marcas (estilo Análisis / detalle de entreno) + HISTORIAL procedural
      (15 en 15). El formulario de resultado NO vive aquí: se abre con el
      botón "Añadir resultado" (o con el "+ Resultado" de la tarjeta).
      En el historial, iconos y pulsación larga → Editar o Eliminar. ── */
function DetallePrueba({ def, results, theme, onClose, onAniadirResultado, onEditarResultado, onEliminarResultado }) {
  const isLight = theme.background === '#F4F7FB';
  const [numVisible, setNumVisible] = useState(PAGE);
  const barraAlta = Platform.OS === 'android' ? (StatusBar.currentHeight || 0) : 24;

  if (!def) return null;

  const ordenadas = [...results].sort((a, b) => (a.fecha?.toMillis?.() ?? 0) - (b.fecha?.toMillis?.() ?? 0));
  const historial = [...ordenadas].reverse();   // últimas primero
  const visibles = historial.slice(0, numVisible);

  // Resumen visual (derivado de los resultados)
  const vals = ordenadas.map((x) => x.valor).filter(Number.isFinite);
  const mejor = vals.length ? (esMenorMejor(def) ? Math.min(...vals) : Math.max(...vals)) : null;
  const mejorRes = mejor != null ? ordenadas.find((x) => x.valor === mejor) : null;
  const primero = vals.length ? vals[0] : null;
  const ultimo = vals.length ? vals[vals.length - 1] : null;
  const mejoraAbs = (primero != null && mejor != null && vals.length >= 2)
    ? (esMenorMejor(def) ? primero - mejor : mejor - primero) : 0;

  const tile = (icon, color, label, value) => (
    <View style={[st.dTile, { backgroundColor: color + '12', borderColor: color + '44' }]}>
      <Ionicons name={icon} size={15} color={color} />
      <Text style={[st.dTileVal, { color: theme.text }]} numberOfLines={1}>{value}</Text>
      <Text style={[st.dTileLabel, { color: theme.muted }]} numberOfLines={1}>{label}</Text>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: theme.background }}>
      {/* Cabecera: debajo de la barra de estado de Android (no se solapa) */}
      <View style={[st.dHeader, { borderBottomColor: theme.border, paddingTop: barraAlta + 10 }]}>
        <Press onPress={onClose} style={[st.circleBtn, { backgroundColor: theme.card, borderColor: theme.border }]} hitSlop={10}>
          <Ionicons name="chevron-back" size={22} color="#8FA8C8" />
        </Press>
        <Text style={[st.dTitulo, { color: theme.text }]} numberOfLines={1}>{def.titulo}</Text>
        <View style={[st.circleBtn, { backgroundColor: GOLD + '22', borderColor: GOLD + '77' }]}>
          <MaterialCommunityIcons name="medal-outline" size={19} color={GOLD} />
        </View>
      </View>

      <FlatList
        data={visibles}
        keyExtractor={(r) => r.id}
        contentContainerStyle={{ paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
        onEndReached={() => { if (numVisible < historial.length) setNumVisible((n) => n + PAGE); }}
        onEndReachedThreshold={0.25}
        ListHeaderComponent={(
          <View style={{ padding: 14, gap: 14 }}>
            {/* Panel de récord */}
            <FadeIn>
              <View style={[st.recordCard, { backgroundColor: theme.card, borderColor: GOLD + '66' }]}>
                <View style={[st.blob, { backgroundColor: GOLD + '14', top: -50, right: -30, width: 150, height: 150 }]} />
                <TrophyStage size={96} iconSize={30} />
                <View style={{ flex: 1 }}>
                  <Text style={[st.recordLabel, { color: GOLD }]}>{L('MEJOR MARCA', 'PERSONAL BEST')}</Text>
                  <Text style={[st.recordValue, { color: theme.text }]} numberOfLines={1} adjustsFontSizeToFit>
                    {mejor != null ? fmtValor(def, mejor) : '—'}
                  </Text>
                  <Text style={{ color: theme.muted, fontSize: 12 }} numberOfLines={1}>
                    {mejorRes?.fecha
                      ? fmtFecha(mejorRes.fecha?.toDate ? mejorRes.fecha.toDate() : new Date(mejorRes.fecha))
                      : L('Sin resultados todavía', 'No results yet')}
                  </Text>
                </View>
              </View>
            </FadeIn>

            {ordenadas.length >= 1 && (
              <FadeIn delay={90}>
                <View style={st.dTilesRow}>
                  {tile('layers-outline', BLUE, L('Resultados', 'Results'), String(ordenadas.length))}
                  {tile('time-outline', '#8FA8C8', L('Último', 'Latest'), ultimo != null ? fmtValor(def, ultimo) : '—')}
                  {mejoraAbs > 0 && tile('trending-up', GREEN, L('Mejora', 'Gain'), fmtValor(def, mejoraAbs))}
                </View>
              </FadeIn>
            )}

            {/* Gráfica MISMO DISEÑO que las del detalle de entreno
                (ActivityChart): rejilla, ejes con etiquetas y un PUNTO por
                cada marca registrada. */}
            {ordenadas.length >= 1 && (
              <FadeIn delay={170}>
                <View style={[st.chartWrap, { backgroundColor: theme.card, borderColor: theme.border }]}>
                  <View style={st.chartTitleRow}>
                    <Ionicons name="analytics-outline" size={14} color={BLUE} />
                    <Text style={[st.chartTitle, { color: theme.muted }]}>{L('Evolución', 'Progress')}</Text>
                  </View>
                  <GraficaMarcas ordenadas={ordenadas} def={def} theme={theme} isLight={isLight} />
                </View>
              </FadeIn>
            )}

            {/* Botón que abre el formulario (el tap en la tarjeta NO lo abre) */}
            <FadeIn delay={240}>
              <Press style={[st.ctaBtn, { backgroundColor: GOLD }]} onPress={() => onAniadirResultado(def)}>
                <Ionicons name="add" size={18} color={GOLD_DARK} />
                <Text style={[st.ctaText, { color: GOLD_DARK }]}>{L('Añadir resultado', 'Add result')}</Text>
              </Press>
            </FadeIn>

            <View style={[st.histCabecera, { borderBottomColor: theme.border }]}>
              <Text style={[st.histTitulo, { color: theme.muted }]}>{L('Historial', 'History')}</Text>
              <Text style={{ color: theme.muted, fontSize: 10 }}>{L('Pulsa larga para editar o eliminar', 'Long-press to edit or delete')}</Text>
            </View>
          </View>
        )}
        ListEmptyComponent={(
          <View style={{ alignItems: 'center', paddingVertical: 30, gap: 8 }}>
            <MaterialCommunityIcons name="clipboard-text-outline" size={36} color={theme.muted} />
            <Text style={{ color: theme.muted, fontSize: 13, textAlign: 'center' }}>{L('Todavía no hay resultados.', 'No results yet.')}</Text>
          </View>
        )}
        renderItem={({ item, index }) => {
          const fecha = item.fecha?.toDate ? item.fecha.toDate() : new Date(item.fecha);
          const esMejor = mejor != null && item.valor === mejor;
          const ultimaFila = index === visibles.length - 1;
          return (
            <FadeIn delay={(index % PAGE) * 35} style={{ paddingHorizontal: 14 }}>
              <View style={st.tlRow}>
                {/* Raíl de la línea de tiempo */}
                <View style={st.tlRail}>
                  {!ultimaFila && <View style={[st.tlLine, { backgroundColor: theme.border }]} />}
                  <View style={[st.tlDot, esMejor
                    ? { backgroundColor: GOLD, borderColor: GOLD }
                    : { backgroundColor: theme.background, borderColor: BLUE }]} />
                </View>
                <View style={{ flex: 1 }}>
                <Press
                  style={[st.histFila, { backgroundColor: theme.card, borderColor: esMejor ? GOLD + '88' : theme.border }]}
                  onLongPress={() => {
                    Alert.alert(
                      fmtFecha(fecha),
                      `${fmtValor(def, item.valor)}${item.notas ? `\n${item.notas}` : ''}`,
                      [
                        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
                        { text: L('Editar', 'Edit'), onPress: () => onEditarResultado(def, item) },
                        { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: () => onEliminarResultado(def, item) },
                      ]
                    );
                  }}
                  delayLongPress={300}
                >
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                      <Text style={{ color: esMejor ? GOLD : theme.text, fontSize: 16, fontWeight: '800' }}>{fmtValor(def, item.valor)}</Text>
                      {esMejor && <MaterialCommunityIcons name="medal" size={15} color={GOLD} />}
                    </View>
                    <Text style={{ color: theme.muted, fontSize: 11, marginTop: 2 }} numberOfLines={1}>
                      {fmtFecha(fecha)}{item.notas ? ` · ${item.notas}` : ''}{item.workoutId ? ` · ${L('entreno', 'workout')}` : ''}
                    </Text>
                  </View>
                  <Press onPress={() => onEditarResultado(def, item)} style={st.iconBtn} hitSlop={8}>
                    <Ionicons name="pencil-outline" size={16} color={theme.muted} />
                  </Press>
                  <Press onPress={() => onEliminarResultado(def, item)} style={[st.iconBtn, { backgroundColor: RED + '1F' }]} hitSlop={8}>
                    <Ionicons name="trash-outline" size={16} color={RED} />
                  </Press>
                </Press>
                </View>
              </View>
            </FadeIn>
          );
        }}
      />
      <SystemBars />
    </View>
  );
}

// Campo grande de resultado (foco dorado)
function BigInput({ theme, ...props }) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={[st.bigWrap, { backgroundColor: theme.card, borderColor: focused ? GOLD : theme.border }]}>
      <TextInput
        {...props}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={[st.bigInput, { color: theme.text }]}
        placeholderTextColor="#4A6080"
      />
    </View>
  );
}

/* ── Formulario de resultado (pantalla propia): se abre SOLO con el botón
      "+ Resultado" de la tarjeta, con "Añadir resultado" del detalle o al
      editar desde el historial. Unidad / Resultado / Fecha / Notas. ── */
function FormResultado({ def, editando, theme, onClose, onGuardar, form }) {
  const barraAlta = Platform.OS === 'android' ? (StatusBar.currentHeight || 0) : 24;
  if (!def) return null;
  const puedeGuardar = !!form.valor.trim() && !form.saving;
  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: theme.background }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={[st.dHeader, { borderBottomColor: theme.border, paddingTop: barraAlta + 10 }]}>
        <Press onPress={onClose} style={[st.circleBtn, { backgroundColor: theme.card, borderColor: theme.border }]} hitSlop={10}>
          <Ionicons name="close" size={22} color="#8FA8C8" />
        </Press>
        <Text style={[st.dTitulo, { color: theme.text }]} numberOfLines={1}>
          {editando ? L('Editar resultado', 'Edit result') : `${L('Añadir resultado', 'Add result')} · ${def.titulo}`}
        </Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40, gap: 12 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <FadeIn>
          <View style={st.formHero}>
            <TrophyStage size={110} iconSize={34} />
            <Text style={[st.formHeroTitle, { color: theme.text }]}>{def.titulo}</Text>
            <View style={[st.unidadChip, { backgroundColor: GOLD + '1F', borderColor: GOLD + '66' }]}>
              <Ionicons name="speedometer-outline" size={13} color={GOLD} />
              <Text style={{ color: GOLD, fontSize: 12, fontWeight: '700' }}>{unidadLabel(def)}</Text>
            </View>
          </View>
        </FadeIn>

        <FadeIn delay={90}>
          <Text style={st.fieldLabel}>{L('Resultado', 'Result')}</Text>
          <BigInput
            theme={theme}
            value={form.valor}
            onChangeText={(t) => form.setValor(esTiempo(def) ? mascaraTiempo(t, esSprint(def)) : t)}
            placeholder={esTiempo(def) ? (esSprint(def) ? L('ej., 0:26', 'e.g., 0:26') : 'ej., 45:30 o 1:23:45') : '0'}
            keyboardType="number-pad"
            autoFocus={!editando}
          />
        </FadeIn>

        <FadeIn delay={170}>
          <Text style={st.fieldLabel}>{L('Fecha', 'Date')}</Text>
          <Press style={[st.inputWrap, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => form.setAbierta(true)}>
            <Ionicons name="calendar-outline" size={17} color={GOLD} />
            <Text style={{ color: theme.text, fontSize: 15, fontWeight: '600', flex: 1 }}>{fmtFecha(form.fecha)}</Text>
            <Ionicons name="chevron-forward" size={15} color={theme.muted} />
          </Press>
        </FadeIn>

        <FadeIn delay={240}>
          <Text style={st.fieldLabel}>{L('Notas', 'Notes')}</Text>
          <IconInput
            icon="create-outline"
            theme={theme}
            value={form.notas}
            onChangeText={form.setNotas}
            placeholder={L('ej., Carrera, Entrenamiento, Con lluvia…', 'e.g. Race, Training, In the rain…')}
            multiline
          />
        </FadeIn>

        <FadeIn delay={310}>
          <Press
            style={[st.ctaBtn, { backgroundColor: GOLD, opacity: puedeGuardar ? 1 : 0.5, marginTop: 6 }]}
            disabled={!puedeGuardar}
            onPress={() => onGuardar(def, editando)}
          >
            {form.saving
              ? <ActivityIndicator color={GOLD_DARK} />
              : <Ionicons name={editando ? 'checkmark' : 'add'} size={18} color={GOLD_DARK} />}
            <Text style={[st.ctaText, { color: GOLD_DARK }]}>{editando ? L('Guardar cambios', 'Save changes') : L('Añadir resultado', 'Add result')}</Text>
          </Press>
        </FadeIn>
      </ScrollView>
      <SystemBars />
    </KeyboardAvoidingView>
  );
}

const st = StyleSheet.create({
  container: { flex: 1 },
  txt: { fontSize: 14, lineHeight: 20 },

  // Cabeceras
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  circleBtn: { width: 40, height: 40, borderRadius: 20, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  scroll: { flex: 1, padding: 14 },

  // Héroe
  blob: { position: 'absolute', borderRadius: 999 },

  // Estado vacío
  empty: { alignItems: 'center', paddingVertical: 36, gap: 14, paddingHorizontal: 20 },
  emptyTitle: { fontSize: 19, fontWeight: '800', textAlign: 'center' },

  // Actividad
  actHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  actIcon: { width: 32, height: 32, borderRadius: 10, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  seccionActividad: { fontSize: 14, fontWeight: '800', letterSpacing: 0.6, textTransform: 'uppercase' },
  countChip: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 999 },
  countChipText: { fontSize: 11, fontWeight: '800' },
  actLine: { flex: 1, height: 1 },

  // Tarjeta de prueba
  tarjeta: { flexDirection: 'row', borderRadius: 16, borderWidth: 1, overflow: 'hidden', marginBottom: 10 },
  stripe: { width: 5 },
  tarjetaBody: { flex: 1, padding: 12, gap: 6 },
  tarjetaTop: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  medalBadge: { width: 30, height: 30, borderRadius: 15, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  tarjetaNombre: { fontSize: 15, fontWeight: '800', flex: 1 },
  prChip: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 7, paddingVertical: 3, borderRadius: 999, borderWidth: 1 },
  prChipText: { fontSize: 10, fontWeight: '800' },
  tarjetaMid: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  mejorGrande: { fontSize: 34, fontWeight: '300' },
  tarjetaBottom: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  tarjetaMeta: { fontSize: 11, flex: 1 },
  addPill: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 999 },
  addPillText: { fontWeight: '800', fontSize: 12 },
  botonAniadir: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 14, borderWidth: 1.5, borderStyle: 'dashed', borderRadius: 14, marginTop: 8 },

  // Botones / campos
  ctaBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, paddingHorizontal: 22, borderRadius: 14 },
  ctaText: { fontSize: 15, fontWeight: '800' },
  fieldLabel: { color: '#8FA8C8', fontSize: 11, fontWeight: '800', marginBottom: 6, letterSpacing: 0.4 },
  inputWrap: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1.5, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 11 },
  inputInner: { flex: 1, fontSize: 14, paddingVertical: 0, minHeight: 22 },
  bigWrap: { borderWidth: 2, borderRadius: 18, paddingVertical: 10, paddingHorizontal: 12 },
  bigInput: { fontSize: 20, fontWeight: '600', textAlign: 'center', paddingVertical: 10 },

  // Wizard / gestión
  wHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  wHeaderTitulo: { fontSize: 17, fontWeight: '800', flex: 1, textAlign: 'center' },
  wLead: { fontSize: 14, fontWeight: '600', marginBottom: 12 },
  wSub: { fontSize: 13, fontWeight: '800', letterSpacing: 0.5 },
  secRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  secBar: { width: 4, height: 16, borderRadius: 2 },
  stepBar: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 20, paddingVertical: 14 },
  stepItem: { alignItems: 'center', gap: 4 },
  stepDot: { width: 28, height: 28, borderRadius: 14, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  stepTrack: { flex: 1, height: 4, borderRadius: 2, overflow: 'hidden', marginBottom: 18 },
  stepFill: { height: 4, borderRadius: 2, backgroundColor: GOLD },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', rowGap: 10 },
  gridCell: { width: '48.5%' },
  actTile: { borderRadius: 16, borderWidth: 1.5, padding: 14, alignItems: 'center', gap: 10 },
  actTileIcon: { width: 54, height: 54, borderRadius: 27, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  metTile: { borderRadius: 14, borderWidth: 1, padding: 14, minHeight: 84 },
  tileCheck: { position: 'absolute', top: 8, right: 8 },
  wFila: { flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 14, marginBottom: 8 },
  miniIcon: { width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  dangerBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: RED + '1F', alignItems: 'center', justifyContent: 'center' },

  // Menú de unidad
  ov: { flex: 1, backgroundColor: '#000000AA', justifyContent: 'center', alignItems: 'center', padding: 24 },
  caja: { width: '100%', maxWidth: 360, borderRadius: 22, borderWidth: 1, padding: 16 },
  cajaTitulo: { fontSize: 16, fontWeight: '800', marginBottom: 10 },
  menuFila: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 13, paddingHorizontal: 12, borderRadius: 12, borderWidth: 1.5, marginBottom: 6 },

  // Detalle
  dHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  dTitulo: { fontSize: 18, fontWeight: '800', flex: 1, textAlign: 'center' },
  recordCard: { flexDirection: 'row', alignItems: 'center', gap: 8, borderRadius: 22, borderWidth: 1.5, padding: 12, overflow: 'hidden' },
  recordLabel: { fontSize: 11, fontWeight: '800', letterSpacing: 1 },
  recordValue: { fontSize: 42, fontWeight: '300', marginVertical: 2 },
  dTilesRow: { flexDirection: 'row', gap: 10 },
  dTile: { flex: 1, borderRadius: 14, borderWidth: 1, paddingVertical: 10, paddingHorizontal: 8, alignItems: 'center', gap: 3 },
  dTileVal: { fontSize: 15, fontWeight: '800' },
  dTileLabel: { fontSize: 10, fontWeight: '700' },
  chartWrap: { borderRadius: 16, borderWidth: 1, overflow: 'hidden', paddingTop: 8 },
  chartTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingBottom: 2 },
  chartTitle: { fontSize: 11, fontWeight: '800', letterSpacing: 0.5, textTransform: 'uppercase' },
  histCabecera: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4, paddingBottom: 6, borderBottomWidth: 1 },
  histTitulo: { fontSize: 13, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.5 },
  tlRow: { flexDirection: 'row', alignItems: 'stretch', gap: 10, paddingBottom: 8 },
  tlRail: { width: 18, alignItems: 'center' },
  tlLine: { position: 'absolute', top: 0, bottom: -8, width: 2, borderRadius: 1 },
  tlDot: { width: 14, height: 14, borderRadius: 7, borderWidth: 2.5, marginTop: 18 },
  histFila: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8, borderRadius: 14, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 10 },
  iconBtn: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },

  // Formulario
  formHero: { alignItems: 'center', gap: 8, paddingVertical: 4 },
  formHeroTitle: { fontSize: 22, fontWeight: '800' },
  unidadChip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 5, borderRadius: 999, borderWidth: 1 },
});