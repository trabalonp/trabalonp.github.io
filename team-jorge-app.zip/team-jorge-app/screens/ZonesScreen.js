// screens/ZonesScreen.js
/* Pantalla de Zonas con DOS MODOS de presentación:
   · VER (por defecto): lista limpia — a la izquierda el TÍTULO de la zona
     (el editable: "R0", "R1+"… o el label antiguo) y a la derecha el valor
     configurado (ritmo / FC / potencia min–max). Nada más.
   · EDITAR (botón "Editar", a la izquierda de "Guardar"): aparece todo lo
     demás: umbrales, "Calcular zonas automáticamente", y por zona el
     encabezado "Zona N" (posición), el TÍTULO editable, el PORCENTAJE de
     cálculo tocable y los min/max. El menú "Agregar zona" sigue llamándolas
     "Zona 1, Zona 2…": el nombre bonito lo pone el usuario en el título.
   Los porcentajes de cálculo viven en services/zonas.js (editables por zona).

   REDISEÑO VISUAL "ESPECTRO DE INTENSIDAD" + ANIMACIONES: la lógica (carga
   caché → Firestore, guardado en perfil + caché, zonas por actividad,
   cálculo automático por porcentajes, añadir/borrar zonas) es la MISMA que
   la versión anterior. Solo cambia la capa visual. Sin dependencias nuevas. */
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import SystemBars from '../components/SystemBars';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Animated,
  Easing,
  KeyboardAvoidingView,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  Platform,
  useColorScheme,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { auth, db } from '../firebaseConfig';
import { cacheProfile, getCachedProfile } from '../services/profileCache';
import { getThemeColors, L, useAppSettings } from '../services/appSettings';
import { pctZona, tituloZona } from '../services/zonas';

const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';
const RED    = '#E05252';
const FC_OPTIONS = [
  ['1', 'Z1 Recuperación'], ['2', 'Z2 Aeróbico'], ['3', 'Z3 Tempo'],
  ['4', 'Z4 SubUmbral'], ['5', 'Z5A SuperUmbral'],
  ['6', 'Z5B Capacidad Aeróbica'], ['7', 'Z5C Capacidad Anaeróbica'],
];
const RITMO_OPTIONS = ['R0', 'R1', 'R1+', 'R2', 'R2+', 'R3', 'R3+', 'R4', 'R4+', 'R5', 'R5+', 'R6'];
const POWER_OPTIONS = ['1', '2', '3', '4', '5', '6'].map(id => [`${id}`, `Z${id}`]);
// Actividades a las que se pueden asignar zonas propias (el Descanso no es
// entrenable; no necesita zonas).
const ACTIVIDADES = ['Running', 'Ciclismo', 'Natación', 'Fuerza', 'Triatlón', 'Evento', 'Otro', 'Notas'];


/* ── Paleta del rediseño (solo visual) ── */
const GREEN = '#2DB37A';
const AMBER = '#F5A623';
const ACCENT = { FC: '#F0576B', Ritmo: BLUE, Potencia: AMBER };
const TAB_ICON = { FC: 'heart', Ritmo: 'speedometer', Potencia: 'flash' };
const ACT_ICON = {
  Running: 'run-fast', Ciclismo: 'bike', 'Natación': 'swim', Fuerza: 'dumbbell',
  'Triatlón': 'trophy-variant-outline', Evento: 'flag-checkered', Otro: 'star-four-points-outline',
  Notas: 'note-text-outline',
};

// Escala de calor (frío → caliente) para colorear las zonas por intensidad
const HEAT = ['#4FC3F7', '#2DD4A8', '#9BE15D', '#F5C518', '#F5A623', '#F2703B', '#E05252'];
const hex2rgb = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const heat = (t) => {
  const x = Math.max(0, Math.min(1, t)) * (HEAT.length - 1);
  const i = Math.floor(x);
  const f = x - i;
  const a = hex2rgb(HEAT[i]);
  const b = hex2rgb(HEAT[Math.min(i + 1, HEAT.length - 1)]);
  return '#' + a.map((v, k) => Math.round(v + (b[k] - v) * f).toString(16).padStart(2, '0')).join('');
};
const zoneColor = (i, n) => heat(n <= 1 ? 0.5 : i / (n - 1));

/* ════════════════════════════════════════════════════════════════════════════
   COMPONENTES VISUALES / ANIMADOS
   ════════════════════════════════════════════════════════════════════════════ */

// Aparece con fundido + deslizamiento (entrada escalonada con `delay`)
function FadeIn({ delay = 0, children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, {
      toValue: 1, duration: 400, delay,
      easing: Easing.out(Easing.cubic), useNativeDriver: true,
    }).start();
  }, [v, delay]);
  return (
    <Animated.View
      style={[style, {
        opacity: v,
        transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) }],
      }]}
    >
      {children}
    </Animated.View>
  );
}

// Zona pulsable con efecto "muelle"
function Press({ onPress, disabled, style, children, hitSlop }) {
  const sc = useRef(new Animated.Value(1)).current;
  const to = (value) =>
    Animated.spring(sc, { toValue: value, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      hitSlop={hitSlop}
      onPressIn={() => to(0.96)}
      onPressOut={() => to(1)}
    >
      <Animated.View style={[style, { transform: [{ scale: sc }] }]}>{children}</Animated.View>
    </Pressable>
  );
}

// Valor 0→1→0 suave (flotar)
function usePingPong(duration) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(v, { toValue: 1, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [v, duration]);
  return v;
}

// Destello que cruza el botón principal cada pocos segundos
function Shine() {
  const [w, setW] = useState(0);
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(v, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.delay(2600),
        Animated.timing(v, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [v]);
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      <Animated.View
        style={[styles.shine, {
          transform: [
            { translateX: v.interpolate({ inputRange: [0, 1], outputRange: [-60, w + 60] }) },
            { rotate: '20deg' },
          ],
        }]}
      />
    </View>
  );
}

// Barras de ecualizador con los colores del espectro (pantalla de carga)
function Bar({ color, delay }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.delay(delay),
      Animated.timing(v, { toValue: 1, duration: 500, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration: 500, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [v, delay]);
  return (
    <Animated.View
      style={{
        width: 11, height: 56, borderRadius: 6, backgroundColor: color,
        transform: [{ scaleY: v.interpolate({ inputRange: [0, 1], outputRange: [0.3, 1] }) }],
      }}
    />
  );
}
function BarsLoader() {
  const cols = ['#4FC3F7', '#2DD4A8', '#F5C518', '#F5A623', '#E05252'];
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 7, height: 56 }}>
      {cols.map((c, i) => <Bar key={i} color={c} delay={i * 130} />)}
    </View>
  );
}

// Selector de métrica con "píldora" deslizante
function SegTabs({ tab, setTab, theme }) {
  const TABS = ['FC', 'Ritmo', 'Potencia'];
  const [w, setW] = useState(0);
  const x = useRef(new Animated.Value(0)).current;
  const tabW = w > 0 ? (w - 8) / TABS.length : 0;
  useEffect(() => {
    Animated.spring(x, { toValue: TABS.indexOf(tab) * tabW, useNativeDriver: true, speed: 16, bounciness: 8 }).start();
  }, [tab, tabW, x]);
  const accent = ACCENT[tab];
  return (
    <View
      style={[styles.segWrap, { backgroundColor: theme.card, borderColor: theme.border }]}
      onLayout={(e) => setW(e.nativeEvent.layout.width)}
    >
      {tabW > 0 && (
        <Animated.View
          style={[styles.segPill, { width: tabW, backgroundColor: accent + '2A', borderColor: accent, transform: [{ translateX: x }] }]}
        />
      )}
      {TABS.map((t) => {
        const on = tab === t;
        return (
          <Pressable key={t} style={styles.segItem} onPress={() => setTab(t)}>
            <Ionicons name={TAB_ICON[t]} size={16} color={on ? ACCENT[t] : theme.muted} />
            <Text style={[styles.segText, { color: on ? theme.text : theme.muted }, on && { fontWeight: '800' }]}>{t}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

// Barra de intensidad animada dentro de cada zona
function ZoneBar({ frac, color, delay, theme }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, { toValue: frac, duration: 700, delay, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
  }, [v, frac, delay]);
  return (
    <View style={[styles.zoneBarTrack, { backgroundColor: theme.border }]}>
      <Animated.View
        style={[styles.zoneBarFill, { backgroundColor: color, width: v.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }) }]}
      />
    </View>
  );
}

// Tarjeta de zona en modo VER
function ZoneViewCard({ titulo, valor, index, n, theme, delay }) {
  const color = zoneColor(index, n);
  return (
    <FadeIn delay={delay}>
      <View style={[styles.viewCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
        <View style={[styles.viewStripe, { backgroundColor: color }]} />
        <View style={styles.viewBody}>
          <View style={styles.viewRow}>
            <View style={[styles.zoneBadge, { backgroundColor: color + '24', borderColor: color }]}>
              <Text style={[styles.zoneBadgeText, { color }]}>{index + 1}</Text>
            </View>
            <Text style={[styles.viewTitle, { color: theme.text }]} numberOfLines={1}>{titulo}</Text>
            <View style={[styles.valuePill, { backgroundColor: color + '1F' }]}>
              <Text style={[styles.viewValue, { color }]} numberOfLines={1}>{valor}</Text>
            </View>
          </View>
          <ZoneBar frac={(index + 1) / n} color={color} delay={delay + 120} theme={theme} />
        </View>
      </View>
    </FadeIn>
  );
}

// Campo con etiqueta, icono, foco de color y nota opcional
function Field({ label, icon, theme, accent, hint, style, ...props }) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={style}>
      {!!label && <Text style={[styles.label, { color: theme.muted }]}>{label}</Text>}
      <View style={[styles.inputWrap, { backgroundColor: theme.card, borderColor: focused ? accent : theme.border }]}>
        {!!icon && <Ionicons name={icon} size={17} color={focused ? accent : theme.muted} />}
        <TextInput
          {...props}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={[styles.inputInner, { color: theme.text }]}
          placeholderTextColor={theme.muted}
        />
      </View>
      {!!hint && <Text style={[styles.hint, { color: theme.muted }]}>{hint}</Text>}
    </View>
  );
}

// Campo pequeño (%, Min, Max) de una zona
function MiniField({ label, theme, color, ...props }) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={{ flex: 1 }}>
      <Text style={[styles.miniLabel, { color: theme.muted }]}>{label}</Text>
      <TextInput
        {...props}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={[styles.zoneInput, { backgroundColor: theme.input, borderColor: focused ? color : theme.border, color: theme.text }]}
        placeholderTextColor={theme.muted}
      />
    </View>
  );
}

// Caja de los menús: entra con rebote
function PopBox({ children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.spring(v, { toValue: 1, useNativeDriver: true, speed: 16, bounciness: 9 }).start();
  }, [v]);
  return (
    <Animated.View
      style={[style, {
        opacity: v,
        transform: [
          { translateY: v.interpolate({ inputRange: [0, 1], outputRange: [28, 0] }) },
          { scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1] }) },
        ],
      }]}
    >
      {children}
    </Animated.View>
  );
}

// Botón "Calcular zonas automáticamente"
function CalcButton({ onPress, accent }) {
  return (
    <Press onPress={onPress} style={[styles.calcBtn, { backgroundColor: accent }]}>
      <Shine />
      <Ionicons name="color-wand-outline" size={18} color="#fff" />
      <Text style={styles.calcBtnText}>Calcular zonas automáticamente</Text>
    </Press>
  );
}

export default function ZonesScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const insets = useSafeAreaInsets();
  const athleteId = route.params?.athleteId;    // si viene del entrenador
  const user = auth.currentUser;
  const currentUserId = athleteId || user?.uid;
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());

  const [tab, setTab] = useState('FC'); // 'FC', 'Ritmo', 'Potencia'
  const [editando, setEditando] = useState(false);   // modo VER vs EDITAR
  const [loading, setLoading] = useState(true);
  const [fcZones, setFcZones] = useState([]);
  const [ritmoZones, setRitmoZones] = useState([]);
  const [potenciaZones, setPotenciaZones] = useState([]);
  const [umbralRitmo, setUmbralRitmo] = useState(''); // min/km para R5
  const [umbralFC, setUmbralFC] = useState('');       // FC máxima (¡no es el umbral!)
  const [fcUmbral, setFcUmbral] = useState('');       // FC umbral (LTHR)
  const [fcReposo, setFcReposo] = useState('');       // FC en reposo (TRIMP/TrainerPlan)
  const [umbralPotencia, setUmbralPotencia] = useState('');
  const [zonePickerOpen, setZonePickerOpen] = useState(false);
  // ── Zonas POR ACTIVIDAD ──
  const [actividadZonas, setActividadZonas] = useState({});  // { [actividad]: { fc, ritmo, potencia } }
  const [actSel, setActSel] = useState({ FC: null, Ritmo: null, Potencia: null }); // actividad elegida por métrica (null = Genéricas)
  const [actPickerOpen, setActPickerOpen] = useState(false);

  // Cargar zonas desde el perfil (caché → Firestore)
  useEffect(() => {
    (async () => {
      const cached = await getCachedProfile(currentUserId);
      if (cached) {
        setFcZones(cached.zonasFC || []);
        setRitmoZones(cached.zonasRitmo || []);
        setPotenciaZones(cached.zonasPotencia || []);
        setUmbralRitmo(cached.umbralRitmo || '');
        setUmbralFC(cached.umbralFC || '');
        setFcUmbral(cached.fcUmbral || '');
        setFcReposo(cached.fcReposo || '');
        setUmbralPotencia(cached.umbralPotencia || '');
        setActividadZonas(cached.zonasActividad || {});
      }
      try {
        const snap = await getDoc(doc(db, 'perfiles', currentUserId));
        if (snap.exists()) {
          const data = snap.data();
          setFcZones(data.zonasFC || []);
          setRitmoZones(data.zonasRitmo || []);
          setPotenciaZones(data.zonasPotencia || []);
          setUmbralRitmo(data.umbralRitmo || '');
          setUmbralFC(data.umbralFC || '');
          setFcUmbral(data.fcUmbral || '');
          setFcReposo(data.fcReposo || '');
          setUmbralPotencia(data.umbralPotencia || '');
          setActividadZonas(data.zonasActividad || {});
        }
      } catch (e) {}
      setLoading(false);
    })();
  }, [currentUserId]);

  // Guardar zonas en Firestore y caché
  const saveZones = async () => {
    try {
      const data = {
        zonasFC: fcZones,
        zonasRitmo: ritmoZones,
        zonasPotencia: potenciaZones,
        zonasActividad: actividadZonas,
        umbralRitmo,
        umbralFC,
        fcUmbral,
        fcReposo,
        umbralPotencia,
      };
      await setDoc(doc(db, 'perfiles', currentUserId), data, { merge: true });
      await cacheProfile(currentUserId, { ...data });   // actualiza caché local
      Alert.alert('Guardado', 'Las zonas se han actualizado correctamente.');
    } catch (err) {
      // El código del error (permission-denied = reglas de Firestore sin
      // desplegar) se muestra para diagnosticar sin dudas.
      Alert.alert('Error', `No se pudieron guardar las zonas. (${e.code || e.message})`);
    }
  };

  // ── Contexto activo: zonas GENÉRICAS o las de la ACTIVIDAD elegida ──
  const metricKey = tab === 'FC' ? 'fc' : tab === 'Ritmo' ? 'ritmo' : 'potencia';
  const actActual = actSel[tab];
  const activeZones = actActual
    ? (actividadZonas[actActual]?.[metricKey] || [])
    : (tab === 'FC' ? fcZones : tab === 'Ritmo' ? ritmoZones : potenciaZones);

  // Modificar las zonas del contexto activo (actividad o genéricas)
  const setContextZones = (fn) => {
    if (actActual) {
      setActividadZonas(prev => {
        const base = { fc: [], ritmo: [], potencia: [], ...(prev[actActual] || {}) };
        base[metricKey] = typeof fn === 'function' ? fn(base[metricKey] || []) : fn;
        return { ...prev, [actActual]: base };
      });
    } else if (tab === 'FC') setFcZones(typeof fn === 'function' ? fn(fcZones) : fn);
    else if (tab === 'Ritmo') setRitmoZones(typeof fn === 'function' ? fn(ritmoZones) : fn);
    else setPotenciaZones(typeof fn === 'function' ? fn(potenciaZones) : fn);
  };

  // Actividades con zonas propias en la MÉTRICA actual + añadir una nueva
  const actsConZonas = Object.keys(actividadZonas)
    .filter(a => (actividadZonas[a]?.[metricKey] || []).length > 0);
  const actsDisponibles = ACTIVIDADES.filter(a => !actsConZonas.includes(a));

  const agregarActividad = (act) => {
    // Se copian las GENÉRICAS de esta métrica como punto de partida editable;
    // el resto de métricas de la actividad empiezan vacías (usarán genéricas).
    const genericas = tab === 'FC' ? fcZones : tab === 'Ritmo' ? ritmoZones : potenciaZones;
    setActividadZonas(prev => ({
      ...prev,
      [act]: { ...(prev[act] || { fc: [], ritmo: [], potencia: [] }), [metricKey]: genericas.map(z => ({ ...z })) },
    }));
    setActSel(prev => ({ ...prev, [tab]: act }));
    setActPickerOpen(false);
  };

  const quitarActividad = (act) => {
    Alert.alert(
      L('Quitar actividad', 'Remove activity'),
      L(`¿Quitar las zonas de ${act} para ${tab}? Volverá a usar las zonas genéricas.`, `Remove ${act}'s ${tab} zones? It will use the generic zones again.`),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        { text: L('Quitar', 'Remove'), style: 'destructive', onPress: () => {
          setActividadZonas(prev => {
            const copia = { ...(prev[act] || {}) };
            delete copia[metricKey];
            const quedan = Object.values(copia).some(a => Array.isArray(a) && a.length);
            const next = { ...prev };
            if (quedan) next[act] = copia; else delete next[act];
            return next;
          });
          setActSel(prev => ({ ...prev, [tab]: null }));
        } },
      ],
      { cancelable: true }
    );
  };
  // El menú "Agregar zona" las llama siempre "Zona 1, Zona 2…": el título
  // bonito (R0, R1+…) lo edita el usuario dentro de cada zona.
  const zoneOptions = (tab === 'FC' ? FC_OPTIONS : tab === 'Ritmo' ? RITMO_OPTIONS.map(label => [label, label]) : POWER_OPTIONS)
    .map(([id], idx) => [id, `Zona ${idx + 1}`]);

  // Añadir exclusivamente una zona que aún no exista.
  const addZone = () => {
    setZonePickerOpen(true);
  };
  const addSelectedZone = (id, label) => {
    if (activeZones.some(z => String(z.id) === String(id) || z.label === label)) {
      setZonePickerOpen(false);
      return;
    }
    const newZone = { id, min: '', max: '', label };
    setContextZones(prevZones => [...prevZones, newZone].sort((a, b) => {
      const ai = tab === 'Ritmo' ? RITMO_OPTIONS.indexOf(a.id) : Number.parseInt(a.id, 10);
      const bi = tab === 'Ritmo' ? RITMO_OPTIONS.indexOf(b.id) : Number.parseInt(b.id, 10);
      return (ai < 0 ? 999 : ai) - (bi < 0 ? 999 : bi);
    }));
    setZonePickerOpen(false);
  };

  // Actualizar un campo de una zona del contexto activo
  const updateZone = (id, field, value) => {
    setContextZones(list => list.map(z => z.id === id ? { ...z, [field]: value } : z));
  };

  // Borrar zona: pide confirmación para evitar borrados accidentales.
  const deleteZone = (zone) => {
    if (!zone) return;
    const id = zone.id;
    const nombre = tituloZona(zone, activeZones.findIndex(z => z.id === id), tab === 'Ritmo' ? 'R' : 'Z');
    const pregunta = tab === 'FC'
      ? { es: '¿Quieres eliminar la zona de frecuencia cardíaca', en: 'Do you want to delete the heart rate zone' }
      : tab === 'Ritmo'
        ? { es: '¿Quieres eliminar la zona de ritmo', en: 'Do you want to delete the pace zone' }
        : { es: '¿Quieres eliminar la zona de potencia', en: 'Do you want to delete the power zone' };
    Alert.alert(
      L('Eliminar zona', 'Delete zone'),
      L(`${pregunta.es} "${nombre}"?`, `${pregunta.en} "${nombre}"?`),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Eliminar', 'Delete'),
          style: 'destructive',
          onPress: () => {
            setContextZones(list => list.filter(item => item.id !== id));
          },
        },
      ],
      { cancelable: true }
    );
  };

  /* Calcular zonas automáticamente usando LOS PORCENTAJES DE CADA ZONA
     (editables en modo Editar; defectos en services/zonas.js). El % de una
     zona es su límite superior; el mínimo es el % de la zona anterior. */
  const calcFcZones = () => {
    if (!umbralFC) {
      Alert.alert('Falta FC máxima', 'Introduce tu frecuencia cardíaca máxima.');
      return;
    }
    const max = parseInt(umbralFC, 10);
    setContextZones(zs => zs.map((zone, i) => {
      const p = pctZona(zone, i, 'FC');
      const min = i === 0 ? 0 : Math.round(max * (pctZona(zs[i - 1], i - 1, 'FC') / 100));
      return { ...zone, min, max: Math.round(max * (p / 100)) };
    }));
  };

  const calcRitmoZones = () => {
    if (!umbralRitmo) {
      Alert.alert('Falta umbral', 'Introduce tu ritmo umbral (R5) en min/km.');
      return;
    }
    setContextZones(zs => zs.map((zone, i) => {
      const p = pctZona(zone, i, 'Ritmo');
      return {
        ...zone,
        min: i === 0 ? '00:00' : formatRitmo(pctZona(zs[i - 1], i - 1, 'Ritmo') / 100),
        max: formatRitmo(p / 100),
      };
    }));
  };

  const calcPotenciaZones = () => {
    if (!umbralPotencia) {
      Alert.alert('Falta umbral', 'Introduce tu umbral de potencia en vatios.');
      return;
    }
    const umbral = parseInt(umbralPotencia, 10);
    setContextZones(zs => zs.map((zone, i) => {
      const p = pctZona(zone, i, 'Potencia');
      const min = i === 0 ? 0 : Math.round(umbral * (pctZona(zs[i - 1], i - 1, 'Potencia') / 100));
      return { ...zone, min, max: Math.round(umbral * (p / 100)) };
    }));
  };

  const formatRitmo = (porc) => {
    const [min, sec] = umbralRitmo.split(':').map(Number);
    const umbralSeg = min * 60 + sec;
    const seg = umbralSeg / porc;
    const m = Math.floor(seg / 60);
    const s = Math.round(seg % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  // Valor configurado que se muestra a la derecha en modo VER
  const valorVista = (zone) => {
    const a = zone.min === '' || zone.min == null ? '—' : zone.min;
    const b = zone.max === '' || zone.max == null ? '—' : zone.max;
    if (tab === 'FC') return `${a}–${b} ppm`;
    if (tab === 'Ritmo') return `${a} – ${b} /km`;
    return `${a}–${b} W`;
  };

  if (loading) {
    return (
      <View style={[styles.center, { backgroundColor: theme.background }]}>
        <BarsLoader />
      </View>
    );
  }

  const accent = ACCENT[tab];
  const nZonas = activeZones.length;
  const contexto = actActual || L('Genéricas', 'Generic');
  const keyCtx = `${tab}-${actActual || 'g'}`;

  return (
    <KeyboardAvoidingView style={[styles.container, { backgroundColor: theme.background }]} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={insets.top}>
      <View style={[styles.header, { borderBottomColor: theme.border, paddingTop: insets.top + 6 }]}>
        <Press onPress={() => navigation.goBack()} style={[styles.circleBtn, { backgroundColor: theme.card, borderColor: theme.border }]} hitSlop={10}>
          <Ionicons name="chevron-back" size={22} color="#8FA8C8" />
        </Press>
        <Text style={[styles.headerTitle, { color: theme.text }]}>Zonas</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          {/* Editar va A LA IZQUIERDA de Guardar, como se pidió */}
          <Press
            onPress={() => setEditando(v => !v)}
            style={[styles.pill, editando
              ? { backgroundColor: GREEN + '26', borderColor: GREEN }
              : { backgroundColor: theme.card, borderColor: theme.border }]}
          >
            <Ionicons name={editando ? 'checkmark' : 'create-outline'} size={15} color={editando ? GREEN : BLUE} />
            <Text style={[styles.pillText, { color: editando ? GREEN : BLUE }]}>
              {editando ? 'Listo' : 'Editar'}
            </Text>
          </Press>
          <Press onPress={saveZones} style={[styles.pill, { backgroundColor: accent, borderColor: accent }]}>
            <Ionicons name="save-outline" size={15} color="#fff" />
            <Text style={[styles.pillText, { color: '#fff' }]}>Guardar</Text>
          </Press>
        </View>
      </View>

      {/* Pestañas */}
      <View style={styles.tabsWrap}>
        <SegTabs tab={tab} setTab={setTab} theme={theme} />
      </View>

      {/* Actividades: Genéricas + las que tienen zonas propias para esta métrica */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.actRow} contentContainerStyle={{ gap: 8, paddingHorizontal: 16 }}>
        <Press
          style={[styles.actChip, { backgroundColor: theme.card, borderColor: theme.border }, !actActual && { borderColor: accent, backgroundColor: accent + '26' }]}
          onPress={() => setActSel(prev => ({ ...prev, [tab]: null }))}
        >
          <Ionicons name="globe-outline" size={14} color={!actActual ? accent : theme.muted} />
          <Text style={[styles.actChipTxt, { color: !actActual ? theme.text : theme.muted }]}>{L('Genéricas', 'Generic')}</Text>
        </Press>
        {actsConZonas.map(a => (
          <Press
            key={a}
            style={[styles.actChip, { backgroundColor: theme.card, borderColor: theme.border }, actActual === a && { borderColor: accent, backgroundColor: accent + '26' }]}
            onPress={() => setActSel(prev => ({ ...prev, [tab]: a }))}
          >
            <MaterialCommunityIcons name={ACT_ICON[a] || 'medal-outline'} size={14} color={actActual === a ? accent : theme.muted} />
            <Text style={[styles.actChipTxt, { color: actActual === a ? theme.text : theme.muted }]}>{a}</Text>
          </Press>
        ))}
        <Press style={[styles.actChip, styles.actChipAdd, { borderColor: accent + '88' }]} onPress={() => setActPickerOpen(true)}>
          <Ionicons name="add" size={14} color={accent} />
          <Text style={[styles.actChipTxt, { color: accent }]}>{L('Actividad', 'Activity')}</Text>
        </Press>
      </ScrollView>

      {/* En edición con actividad seleccionada: quitar sus zonas */}
      {editando && actActual && (
        <FadeIn>
          <Press style={[styles.quitarActBtn, { backgroundColor: RED + '14', borderColor: RED + '66' }]} onPress={() => quitarActividad(actActual)}>
            <Ionicons name="close-circle-outline" size={16} color={RED} />
            <Text style={[styles.quitarActTxt, { color: RED }]}>{L(`Quitar zonas de ${actActual}`, `Remove ${actActual} zones`)}</Text>
          </Press>
        </FadeIn>
      )}

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ paddingBottom: insets.bottom + 180 }}
        keyboardShouldPersistTaps="handled"
        automaticallyAdjustKeyboardInsets
        showsVerticalScrollIndicator={false}
      >
        {/* ── MODO EDITAR: umbrales + calcular + porcentajes ── */}
        {editando && tab === 'FC' && (
          <FadeIn key={`u-${keyCtx}`}>
            <View style={[styles.threshCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
              <View style={styles.threshHead}>
                <View style={[styles.spectrumIcon, { backgroundColor: accent + '22', borderColor: accent + '66' }]}>
                  <Ionicons name="heart" size={15} color={accent} />
                </View>
                <Text style={[styles.threshTitle, { color: theme.text }]}>{L('Umbrales', 'Thresholds')}</Text>
              </View>
              <Field label="FC máxima" icon="heart-outline" theme={theme} accent={accent} value={umbralFC} onChangeText={setUmbralFC} placeholder="190" keyboardType="numeric" />
              <Field style={{ marginTop: 10 }} label="FC umbral (LTHR) — opcional" icon="pulse-outline" theme={theme} accent={accent} value={fcUmbral} onChangeText={setFcUmbral} placeholder="170" keyboardType="numeric"
                hint="La FC que aguantas 1 hora a ritmo fuerte: define la zona de umbral. El esfuerzo (TRIMP) ya no la necesita, usa la FC máxima y la de reposo." />
              <Field style={{ marginTop: 10 }} label="FC en reposo" icon="bed-outline" theme={theme} accent={accent} value={fcReposo} onChangeText={setFcReposo} placeholder="50" keyboardType="numeric"
                hint="Tu FC nada más despertarte. Con ella y la FC máxima se calcula el esfuerzo de cada entreno (TRIMP, mismo algoritmo que TrainerPlan); si la dejas vacía se usa la del wellness del día o 60." />
              <CalcButton onPress={calcFcZones} accent={accent} />
            </View>
          </FadeIn>
        )}
        {editando && tab === 'Ritmo' && (
          <FadeIn key={`u-${keyCtx}`}>
            <View style={[styles.threshCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
              <View style={styles.threshHead}>
                <View style={[styles.spectrumIcon, { backgroundColor: accent + '22', borderColor: accent + '66' }]}>
                  <Ionicons name="speedometer" size={15} color={accent} />
                </View>
                <Text style={[styles.threshTitle, { color: theme.text }]}>{L('Umbrales', 'Thresholds')}</Text>
              </View>
              <Field label="Ritmo umbral (R5) min/km" icon="timer-outline" theme={theme} accent={accent} value={umbralRitmo} onChangeText={setUmbralRitmo} placeholder="02:52" />
              <CalcButton onPress={calcRitmoZones} accent={accent} />
            </View>
          </FadeIn>
        )}
        {editando && tab === 'Potencia' && (
          <FadeIn key={`u-${keyCtx}`}>
            <View style={[styles.threshCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
              <View style={styles.threshHead}>
                <View style={[styles.spectrumIcon, { backgroundColor: accent + '22', borderColor: accent + '66' }]}>
                  <Ionicons name="flash" size={15} color={accent} />
                </View>
                <Text style={[styles.threshTitle, { color: theme.text }]}>{L('Umbrales', 'Thresholds')}</Text>
              </View>
              <Field label="Umbral de potencia (W)" icon="flash-outline" theme={theme} accent={accent} value={umbralPotencia} onChangeText={setUmbralPotencia} placeholder="250" keyboardType="numeric" />
              <CalcButton onPress={calcPotenciaZones} accent={accent} />
            </View>
          </FadeIn>
        )}

        {/* ── MODO VER: solo título + valor configurado ── */}
        {!editando && activeZones.map((zone, index) => (
          <ZoneViewCard
            key={`${keyCtx}-${zone.id}`}
            titulo={tituloZona(zone, index, tab === 'Ritmo' ? 'R' : 'Z')}
            valor={valorVista(zone)}
            index={index}
            n={nZonas}
            theme={theme}
            delay={Math.min(index * 55, 550)}
          />
        ))}
        {!editando && activeZones.length === 0 && (
          <FadeIn>
            <View style={styles.emptyBox}>
              <View style={[styles.emptyCircle, { backgroundColor: accent + '1A', borderColor: accent + '55' }]}>
                <Ionicons name={TAB_ICON[tab]} size={30} color={accent} />
              </View>
              <Text style={[styles.label, { color: theme.muted, textAlign: 'center', marginTop: 4 }]}>
                No hay zonas configuradas. Pulsa Editar para añadirlas.
              </Text>
            </View>
          </FadeIn>
        )}

        {/* ── MODO EDITAR: tarjetas con título, % y min/max editables ── */}
        {editando && activeZones.map((zone, index) => {
          const color = zoneColor(index, nZonas);
          return (
            <FadeIn key={`${keyCtx}-${zone.id}`} delay={Math.min(index * 50, 400)}>
              <View style={[styles.zoneCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
                <View style={[styles.viewStripe, { backgroundColor: color }]} />
                <View style={{ flex: 1, padding: 14 }}>
                  <View style={styles.zoneRow}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                      <View style={[styles.zoneBadge, { backgroundColor: color + '24', borderColor: color }]}>
                        <Text style={[styles.zoneBadgeText, { color }]}>{index + 1}</Text>
                      </View>
                      <Text style={[styles.zonePos, { color: theme.muted }]}>Zona {index + 1}</Text>
                    </View>
                    <Press onPress={() => deleteZone(zone)} style={styles.dangerBtn} hitSlop={8}>
                      <Ionicons name="trash-outline" size={17} color={RED} />
                    </Press>
                  </View>
                  <Field
                    label="Título"
                    icon="pricetag-outline"
                    theme={theme}
                    accent={color}
                    value={zone.titulo || ''}
                    onChangeText={v => updateZone(zone.id, 'titulo', v)}
                    placeholder={zone.label || `Zona ${index + 1}`}
                  />
                  <View style={styles.row}>
                    <MiniField
                      label="%"
                      theme={theme}
                      color={color}
                      value={zone.pct !== undefined && zone.pct !== '' ? String(zone.pct) : String(pctZona(zone, index, tab))}
                      onChangeText={v => updateZone(zone.id, 'pct', v.replace(/[^0-9.,]/g, ''))}
                      keyboardType="numeric"
                    />
                    <MiniField
                      label="Min"
                      theme={theme}
                      color={color}
                      value={String(zone.min ?? '')}
                      onChangeText={v => updateZone(zone.id, 'min', v)}
                      keyboardType={tab === 'Ritmo' ? 'default' : 'numeric'}
                      placeholder={tab === 'Ritmo' ? '00:00' : '0'}
                    />
                    <MiniField
                      label="Max"
                      theme={theme}
                      color={color}
                      value={String(zone.max ?? '')}
                      onChangeText={v => updateZone(zone.id, 'max', v)}
                      keyboardType={tab === 'Ritmo' ? 'default' : 'numeric'}
                      placeholder={tab === 'Ritmo' ? '00:00' : '0'}
                    />
                  </View>
                  <Text style={[styles.hint, { color: theme.muted, marginTop: 8 }]}>
                    % = límite superior de la zona sobre {tab === 'FC' ? 'la FC máxima' : tab === 'Ritmo' ? 'el umbral de ritmo' : 'el FTP'}; el mínimo sale del % de la zona anterior.
                  </Text>
                </View>
              </View>
            </FadeIn>
          );
        })}

        {editando && (
          <Press style={[styles.addBtn, { borderColor: accent + '88', backgroundColor: accent + '0F' }]} onPress={addZone}>
            <Ionicons name="add-circle-outline" size={20} color={accent} />
            <Text style={[styles.addBtnText, { color: accent }]}>Agregar zona</Text>
          </Press>
        )}
      </ScrollView>

      <Modal visible={zonePickerOpen} transparent animationType="fade" onRequestClose={() => setZonePickerOpen(false)}>
        <View style={[styles.modalOverlay, { backgroundColor: theme.overlay }]}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setZonePickerOpen(false)} />
          <PopBox style={[styles.zonePicker, { backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border }]}>
            <Text style={[styles.zonePickerTitle, { color: theme.text }]}>Añadir zona de {tab}</Text>
            <ScrollView showsVerticalScrollIndicator={false}>
              {zoneOptions.map(([id, label], idx) => {
                const exists = activeZones.some(z => String(z.id) === String(id) || z.label === label);
                const c = zoneColor(idx, zoneOptions.length);
                return (
                  <Pressable
                    key={id}
                    disabled={exists}
                    style={({ pressed }) => [styles.zoneOption, { borderColor: theme.border, backgroundColor: pressed ? c + '1A' : 'transparent' }, exists && styles.zoneOptionDisabled]}
                    onPress={() => addSelectedZone(id, label)}
                  >
                    <View style={[styles.optDot, { backgroundColor: c }]} />
                    <Text style={[styles.zoneOptionText, { color: theme.text }]}>{label}</Text>
                    {exists
                      ? <Ionicons name="checkmark-circle" size={16} color={GREEN} />
                      : <Ionicons name="add-circle-outline" size={16} color={accent} />}
                    <Text style={[styles.zoneOptionState, { color: exists ? GREEN : accent }]}>{exists ? 'Añadida' : 'Añadir'}</Text>
                  </Pressable>
                );
              })}
            </ScrollView>
            <Press style={styles.cancelBtn} onPress={() => setZonePickerOpen(false)}>
              <Text style={[styles.cancelBtnText, { color: theme.muted }]}>Cancelar</Text>
            </Press>
          </PopBox>
        </View>
      </Modal>
      {/* Modal: elegir actividad a la que darle zonas propias */}
      <Modal visible={actPickerOpen} transparent animationType="fade" onRequestClose={() => setActPickerOpen(false)}>
        <View style={[styles.modalOverlay, { backgroundColor: theme.overlay }]}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setActPickerOpen(false)} />
          <PopBox style={[styles.zonePicker, { backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border }]}>
            <Text style={[styles.zonePickerTitle, { color: theme.text }]}>{L('Actividad para', 'Activity for')} {tab}</Text>
            <ScrollView showsVerticalScrollIndicator={false}>
              {actsDisponibles.map(a => (
                <Pressable
                  key={a}
                  style={({ pressed }) => [styles.zoneOption, { borderColor: theme.border, backgroundColor: pressed ? accent + '1A' : 'transparent' }]}
                  onPress={() => agregarActividad(a)}
                >
                  <MaterialCommunityIcons name={ACT_ICON[a] || 'medal-outline'} size={18} color={accent} />
                  <Text style={[styles.zoneOptionText, { color: theme.text }]}>{a}</Text>
                  <Ionicons name="add" size={16} color={accent} />
                </Pressable>
              ))}
            </ScrollView>
            <Press style={styles.cancelBtn} onPress={() => setActPickerOpen(false)}>
              <Text style={[styles.cancelBtnText, { color: theme.muted }]}>{L('Cancelar', 'Cancel')}</Text>
            </Press>
          </PopBox>
        </View>
        <SystemBars />
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: NAVY,
  },

  // Cabecera
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8,
    paddingHorizontal: 16, paddingBottom: 12,
    borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  headerTitle: { fontSize: 18, fontWeight: '800', flex: 1, textAlign: 'center' },
  circleBtn: { width: 40, height: 40, borderRadius: 20, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  pill: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 999, borderWidth: 1.5 },
  pillText: { fontSize: 13, fontWeight: '800' },
  shine: { position: 'absolute', top: -30, height: 120, width: 28, backgroundColor: 'rgba(255,255,255,0.22)' },

  // Pestañas
  tabsWrap: { paddingHorizontal: 16, paddingTop: 14 },
  segWrap: { flexDirection: 'row', borderRadius: 16, borderWidth: 1, padding: 4 },
  segPill: { position: 'absolute', top: 4, bottom: 4, left: 4, borderRadius: 12, borderWidth: 1.5 },
  segItem: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 11 },
  segText: { fontSize: 14, fontWeight: '600' },

  // Actividades
  actRow: { flexGrow: 0, paddingVertical: 12 },
  actChip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 13, paddingVertical: 8, borderRadius: 999, borderWidth: 1.5 },
  actChipAdd: { borderStyle: 'dashed' },
  actChipTxt: { fontSize: 12, fontWeight: '700' },
  quitarActBtn: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', gap: 6, marginLeft: 16, marginBottom: 6, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 999, borderWidth: 1 },
  quitarActTxt: { fontSize: 12, fontWeight: '700' },

  scroll: { flex: 1, paddingHorizontal: 16, paddingTop: 4 },

  // Espectro
  spectrumIcon: { width: 30, height: 30, borderRadius: 10, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  miniChip: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 999, maxWidth: 150 },
  miniChipText: { fontSize: 11, fontWeight: '800' },

  // Campos
  label: { fontSize: 14, marginBottom: 8 },
  inputWrap: { flexDirection: 'row', alignItems: 'center', gap: 10, borderRadius: 12, borderWidth: 1.5, paddingHorizontal: 12 },
  inputInner: { flex: 1, paddingVertical: 11, fontSize: 14 },
  hint: { fontSize: 11, marginTop: 6, opacity: 0.8, lineHeight: 16 },
  miniLabel: { fontSize: 11, fontWeight: '800', marginBottom: 4, textAlign: 'center', letterSpacing: 0.4 },
  threshCard: { borderRadius: 18, borderWidth: 1, padding: 14, marginBottom: 14 },
  threshHead: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 },
  threshTitle: { fontSize: 14, fontWeight: '800' },
  calcBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, borderRadius: 14, marginTop: 16, overflow: 'hidden' },
  calcBtnText: { color: '#fff', fontWeight: '800', fontSize: 14 },

  // Modo VER
  viewCard: { flexDirection: 'row', borderRadius: 16, borderWidth: 1, marginBottom: 10, overflow: 'hidden' },
  viewStripe: { width: 5 },
  viewBody: { flex: 1, padding: 12, gap: 10 },
  viewRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  zoneBadge: { width: 30, height: 30, borderRadius: 15, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  zoneBadgeText: { fontSize: 13, fontWeight: '800' },
  viewTitle: { fontWeight: '800', fontSize: 15, flex: 1 },
  valuePill: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999, maxWidth: 170 },
  viewValue: { fontSize: 13, fontWeight: '800' },
  zoneBarTrack: { height: 5, borderRadius: 3, overflow: 'hidden' },
  zoneBarFill: { height: 5, borderRadius: 3 },
  emptyBox: { alignItems: 'center', paddingTop: 30, gap: 10 },
  emptyCircle: { width: 72, height: 72, borderRadius: 36, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },

  // Modo EDITAR
  zoneCard: { flexDirection: 'row', borderRadius: 16, borderWidth: 1, marginBottom: 12, overflow: 'hidden' },
  zoneRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  zonePos: { fontWeight: '800', fontSize: 12, textTransform: 'uppercase', letterSpacing: 0.6 },
  dangerBtn: { width: 34, height: 34, borderRadius: 17, backgroundColor: RED + '1F', alignItems: 'center', justifyContent: 'center' },
  row: { flexDirection: 'row', alignItems: 'flex-end', gap: 8, marginTop: 12 },
  zoneInput: { borderRadius: 10, borderWidth: 1.5, paddingVertical: 10, paddingHorizontal: 6, textAlign: 'center', fontSize: 14, fontWeight: '700' },
  addBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 4, padding: 14, borderRadius: 14, borderWidth: 1.5, borderStyle: 'dashed' },
  addBtnText: { fontWeight: '800' },

  // Modales
  modalOverlay: { flex: 1, backgroundColor: '#00000088', justifyContent: 'center', padding: 24 },
  zonePicker: { maxHeight: '75%', borderRadius: 22, padding: 16 },
  zonePickerTitle: { fontSize: 17, fontWeight: '800', marginBottom: 12 },
  zoneOption: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 13, paddingHorizontal: 12, borderRadius: 12, borderWidth: 1, marginBottom: 6 },
  zoneOptionDisabled: { opacity: 0.45 },
  optDot: { width: 10, height: 10, borderRadius: 5 },
  zoneOptionText: { fontSize: 14, flex: 1, fontWeight: '600' },
  zoneOptionState: { fontSize: 12, fontWeight: '800' },
  cancelBtn: { alignItems: 'center', paddingTop: 14 },
  cancelBtnText: { fontWeight: '700' },
});