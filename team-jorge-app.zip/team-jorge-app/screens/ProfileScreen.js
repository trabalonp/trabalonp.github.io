// screens/ProfileScreen.js
// ─────────────────────────────────────────────────────────────────────────────
// REDISEÑO VISUAL + ANIMACIONES ("carnet de atleta").
// La lógica (carga caché → Firestore, foto con ImagePicker + redimensionado a
// 200 px + base64, validación y normalización de la fecha de nacimiento,
// guardado en perfil + caché + avatar publicado, cerrar sesión y eliminar
// cuenta) es la MISMA que la versión anterior. Solo cambia la capa visual.
// Sin dependencias nuevas.
// ─────────────────────────────────────────────────────────────────────────────
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import * as FileSystem from 'expo-file-system/legacy';
import * as ImageManipulator from 'expo-image-manipulator';
import * as ImagePicker from 'expo-image-picker';
import { deleteUser, signOut } from 'firebase/auth';
import { deleteDoc, doc, getDoc, setDoc } from 'firebase/firestore';
import { useEffect, useRef, useState } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import SystemBars from '../components/SystemBars';
import {
  ActivityIndicator,
  Alert,
  Animated,
  Easing,
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  useColorScheme,
} from 'react-native';
import { auth, db } from '../firebaseConfig';
import MonthPickerModal from '../components/MonthPickerModal';
import { clearCoachCache } from '../services/coachCache';
import { cacheProfile, clearProfileCache, getCachedProfile, invalidateProfileCache } from '../services/profileCache';
import { publicarMiAvatar } from '../services/avatarCache';
import { getThemeColors, L, locale, useAppSettings } from '../services/appSettings';

const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';
const RED    = '#E05252';
const SERVER_URL = 'https://garmin-fit-server.onrender.com';

// ── Fecha de nacimiento: parseo y validación ──
const MESES_ES_LARGOS = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
const MESES_EN_LARGOS = ['january','february','march','april','may','june','july','august','september','october','november','december'];
const MESES_ES_CORTOS = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
const MESES_EN_CORTOS = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
const MESES_DISPLAY = {
  es: ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'],
  en: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
};

function mesesDisplay() {
  return locale() === 'en-US' ? MESES_DISPLAY.en : MESES_DISPLAY.es;
}

function mesDesdeTexto(txt) {
  const t = String(txt).toLowerCase().trim();
  if (!t) return null;
  let i = MESES_ES_LARGOS.indexOf(t); if (i >= 0) return i + 1;
  i = MESES_EN_LARGOS.indexOf(t); if (i >= 0) return i + 1;
  if (t.length <= 4) {
    const t3 = t.slice(0, 3);
    i = MESES_ES_CORTOS.indexOf(t3); if (i >= 0) return i + 1;
    i = MESES_EN_CORTOS.indexOf(t3); if (i >= 0) return i + 1;
  }
  return null;
}

function esFechaReal(y, m, d) {
  if (!(m >= 1 && m <= 12) || !(d >= 1)) return false;
  const dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
}

// Parsea el campo y devuelve { y, m, d } o null si no encaja en ningún formato
// aceptado:
//   · DD/MM/AAAA, DD-MM-AAAA, DD.MM.AAAA (también año de 2 dígitos: 30-99 → 19xx, 00-29 → 20xx)
//   · AAAA-MM-DD (ISO)
//   · DD MMM AAAA / DD de MMMM de AAAA / MMM DD, AAAA ("15 Mar 1990", "15 de marzo de 1990", "Mar 15, 1990"; mes en español o inglés)
function parseFechaNac(txt) {
  if (txt == null) return null;
  const s = String(txt).trim().replace(/\s+/g, ' ');
  if (!s) return null;
  const expandir = (yy) => (yy <= 29 ? 2000 + yy : 1900 + yy);

  let r = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s); // AAAA-MM-DD
  if (r) {
    const y = +r[1], m = +r[2], d = +r[3];
    return esFechaReal(y, m, d) ? { y, m, d } : null;
  }
  r = /^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2}|\d{4})$/.exec(s); // DD/MM/AAAA
  if (r) {
    const d = +r[1], m = +r[2];
    const y = r[3].length === 2 ? expandir(+r[3]) : +r[3];
    return esFechaReal(y, m, d) ? { y, m, d } : null;
  }
  r = /^(\d{1,2})[\s.]+(?:de\s+)?([A-Za-zÁÉÍÓÚÜÑáéíóúüñ]{3,12})[.,]?\s*(?:de\s+|del\s+)?(\d{2}|\d{4})$/.exec(s); // DD MMM AAAA
  if (r) {
    const d = +r[1], m = mesDesdeTexto(r[2]);
    const y = r[3].length === 2 ? expandir(+r[3]) : +r[3];
    return m && esFechaReal(y, m, d) ? { y, m, d } : null;
  }
  r = /^([A-Za-zÁÉÍÓÚÜÑáéíóúüñ]{3,12})[.,]?\s+(\d{1,2})(?:st|nd|rd|th)?[,\s]+(\d{2}|\d{4})$/.exec(s); // MMM DD, AAAA (inglés)
  if (r) {
    const m = mesDesdeTexto(r[1]), d = +r[2];
    const y = r[3].length === 2 ? expandir(+r[3]) : +r[3];
    return m && esFechaReal(y, m, d) ? { y, m, d } : null;
  }
  return null;
}

// Valida el campo: vacío se permite (campo opcional); si no, debe tener un
// formato aceptado, ser una fecha real del calendario, no futura y no implicar
// más de 110 años. Si es correcta devuelve { ok: true, iso } con la fecha
// normalizada a AAAA-MM-DD (es lo que se guarda en Firestore, para que
// new Date() la entienda siempre — p. ej. la fórmula de Tanaka del SyncService).
function validarFechaNac(txt) {
  const s = txt == null ? '' : String(txt).trim();
  if (!s) return { ok: true, iso: '' };
  const p = parseFechaNac(s);
  if (!p) return { ok: false, motivo: 'formato' };
  const hoy = new Date();
  const nac = new Date(p.y, p.m - 1, p.d);
  if (nac.getTime() > hoy.getTime()) return { ok: false, motivo: 'futura' };
  const edad = (hoy.getTime() - nac.getTime()) / (365.25 * 24 * 3600 * 1000);
  if (edad > 110) return { ok: false, motivo: 'rango' };
  const iso = `${p.y}-${String(p.m).padStart(2, '0')}-${String(p.d).padStart(2, '0')}`;
  return { ok: true, iso };
}

// Muestra la fecha guardada (cadena ISO o Timestamp de Firestore) como
// "DD MMM AAAA". Si no se puede interpretar, la devuelve tal cual.
function formatoBonitoFechaNac(v) {
  if (v == null || v === '') return '';
  if (typeof v === 'object' && typeof v.toDate === 'function') {
    const d = v.toDate();
    return `${String(d.getDate()).padStart(2, '0')} ${mesesDisplay()[d.getMonth()]} ${d.getFullYear()}`;
  }
  const s = String(v).trim();
  const p = parseFechaNac(s);
  if (!p) return s;
  return `${String(p.d).padStart(2, '0')} ${mesesDisplay()[p.m - 1]} ${p.y}`;
}


/* ── Paleta del rediseño (solo visual) ── */
const TEAL  = '#22B8CF';
const CORAL = '#FF7A59';
const GREEN = '#2DB37A';
const AMBER = '#F5A623';

/* ════════════════════════════════════════════════════════════════════════════
   COMPONENTES VISUALES / ANIMADOS
   ════════════════════════════════════════════════════════════════════════════ */

// Aparece con fundido + deslizamiento (entrada escalonada con `delay`)
function FadeIn({ delay = 0, children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, {
      toValue: 1, duration: 420, delay,
      easing: Easing.out(Easing.cubic), useNativeDriver: true,
    }).start();
  }, [v, delay]);
  return (
    <Animated.View
      style={[style, {
        opacity: v,
        transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [16, 0] }) }],
      }]}
    >
      {children}
    </Animated.View>
  );
}

// Zona pulsable con efecto "muelle"
function Press({ onPress, disabled, style, children, hitSlop, activeScale = 0.97 }) {
  const sc = useRef(new Animated.Value(1)).current;
  const to = (value) =>
    Animated.spring(sc, { toValue: value, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      hitSlop={hitSlop}
      onPressIn={() => to(activeScale)}
      onPressOut={() => to(1)}
    >
      <Animated.View style={[style, { transform: [{ scale: sc }] }]}>{children}</Animated.View>
    </Pressable>
  );
}

// Valor 0→1 en bucle
function useLoop(duration, active = true, easing = Easing.linear) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!active) { v.setValue(0); return undefined; }
    const loop = Animated.loop(Animated.timing(v, { toValue: 1, duration, easing, useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [v, duration, active, easing]);
  return v;
}

// Valor 0→1→0 suave
function usePingPong(duration) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(v, { toValue: 1, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [v, duration]);
  return v;
}

// Número que "cuenta" hasta su valor
function CountUp({ value, style, suffix = '' }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    const a = new Animated.Value(0);
    const id = a.addListener(({ value: v }) => setN(Math.round(v)));
    Animated.timing(a, { toValue: value, duration: 900, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
    return () => { a.removeListener(id); a.stopAnimation(); };
  }, [value]);
  return <Text style={style}>{n}{suffix}</Text>;
}

// Destello que cruza el botón principal cada pocos segundos
function Shine() {
  const [w, setW] = useState(0);
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(v, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.delay(2600),
        Animated.timing(v, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [v]);
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      <Animated.View
        style={[styles.shine, {
          transform: [
            { translateX: v.interpolate({ inputRange: [0, 1], outputRange: [-60, w + 60] }) },
            { rotate: '20deg' },
          ],
        }]}
      />
    </View>
  );
}

// Anillo que se expande (insignia de la cámara)
function PulseRing({ size, color }) {
  const v = useLoop(2000, true, Easing.out(Easing.quad));
  return (
    <Animated.View
      pointerEvents="none"
      style={{
        position: 'absolute', width: size, height: size, borderRadius: size / 2,
        borderWidth: 2, borderColor: color,
        opacity: v.interpolate({ inputRange: [0, 1], outputRange: [0.55, 0] }),
        transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [1, 1.8] }) }],
      }}
    />
  );
}

// Esqueleto de carga con forma de carnet
function SkeletonProfile({ theme }) {
  const p = usePingPong(800);
  const op = p.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0.9] });
  const bar = (w, h, extra) => (
    <Animated.View style={[{ width: w, height: h, borderRadius: h / 2, backgroundColor: theme.border, opacity: op }, extra]} />
  );
  return (
    <View style={[styles.centered, { backgroundColor: theme.background }]}>
      <View style={[styles.skelCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
        <Animated.View style={{ width: 96, height: 96, borderRadius: 30, backgroundColor: TEAL + '33', opacity: op }} />
        {bar(150, 16, { marginTop: 18 })}
        {bar(100, 10, { marginTop: 10 })}
        <View style={{ flexDirection: 'row', gap: 10, marginTop: 20 }}>
          {bar(70, 46, { borderRadius: 14 })}
          {bar(70, 46, { borderRadius: 14 })}
          {bar(70, 46, { borderRadius: 14 })}
        </View>
      </View>
      <ActivityIndicator size="small" color={TEAL} style={{ marginTop: 22 }} />
    </View>
  );
}

// Barra de completado del perfil
function CompletionBar({ pct, theme, L: LL }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, { toValue: pct / 100, duration: 900, delay: 300, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
  }, [v, pct]);
  const color = pct >= 100 ? GREEN : pct >= 60 ? TEAL : AMBER;
  return (
    <View style={styles.compWrap}>
      <View style={styles.compTop}>
        <Text style={[styles.compLabel, { color: theme.muted }]}>{LL('Perfil completado', 'Profile completed')}</Text>
        <CountUp value={pct} suffix="%" style={[styles.compPct, { color }]} />
      </View>
      <View style={[styles.compTrack, { backgroundColor: theme.border }]}>
        <Animated.View style={[styles.compFill, { backgroundColor: color, width: v.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }) }]} />
      </View>
    </View>
  );
}

// Carnet de atleta (foto + nombre + datos clave + completado)
function IdCard({ theme, foto, nombre, apellido, pais, ciudad, edad, altura, unidadAltura, peso, unidadPeso, pct, onPickImage }) {
  const nombreCompleto = `${nombre || ''} ${apellido || ''}`.trim();
  const lugar = `${ciudad || ''}${ciudad && pais ? ', ' : ''}${pais || ''}`;
  const tile = (icon, color, valor, label) => (
    <View style={[styles.statTile, { backgroundColor: color + '14', borderColor: color + '44' }]}>
      <Ionicons name={icon} size={15} color={color} />
      <Text style={[styles.statVal, { color: theme.text }]} numberOfLines={1}>{valor}</Text>
      <Text style={[styles.statLabel, { color: theme.muted }]} numberOfLines={1}>{label}</Text>
    </View>
  );
  return (
    <View style={[styles.idCard, { backgroundColor: theme.card, borderColor: TEAL + '55' }]}>
      {/* Banda superior con rayas diagonales y ranura de cordón */}
      <View style={[styles.band, { backgroundColor: TEAL + '26' }]}>
        {[0, 1, 2, 3, 4, 5, 6].map((i) => (
          <View key={i} style={{ position: 'absolute', left: i * 62 - 20, top: -30, width: 16, height: 180, backgroundColor: TEAL + '1C', transform: [{ rotate: '25deg' }] }} />
        ))}
        <View style={[styles.slot, { backgroundColor: theme.background, borderColor: TEAL + '66' }]} />
        <View style={styles.bandTag}>
          <MaterialCommunityIcons name="card-account-details-outline" size={14} color={TEAL} />
          <Text style={[styles.bandTagText, { color: TEAL }]}>{L('ATLETA', 'ATHLETE')}</Text>
        </View>
      </View>

      {/* Foto */}
      <View style={{ alignItems: 'center', marginTop: -54 }}>
        <Press onPress={onPickImage} style={styles.photoWrap} activeScale={0.95}>
          {foto ? (
            <Image source={{ uri: `data:image/jpeg;base64,${foto}` }} style={[styles.photo, { borderColor: theme.card }]} />
          ) : (
            <View style={[styles.photo, styles.photoPlaceholder, { backgroundColor: theme.input, borderColor: theme.card }]}>
              <Ionicons name="person" size={44} color={theme.muted} />
            </View>
          )}
          <View style={styles.camWrap}>
            <PulseRing size={32} color={CORAL} />
            <View style={[styles.camBadge, { borderColor: theme.card }]}>
              <Ionicons name="camera" size={15} color="#fff" />
            </View>
          </View>
        </Press>
        <Text style={[styles.photoText, { color: TEAL }]}>{L('Selecciona foto', 'Select photo')}</Text>
      </View>

      <Text style={[styles.idName, { color: theme.text }]} numberOfLines={1}>
        {nombreCompleto || L('Tu nombre', 'Your name')}
      </Text>
      {!!lugar && (
        <View style={styles.placeRow}>
          <Ionicons name="location-outline" size={14} color={theme.muted} />
          <Text style={[styles.placeText, { color: theme.muted }]} numberOfLines={1}>{lugar}</Text>
        </View>
      )}

      <View style={styles.statsRow}>
        {tile('calendar-outline', TEAL, edad != null ? String(edad) : '—', L('Edad', 'Age'))}
        {tile('resize-outline', CORAL, altura ? `${altura} ${unidadAltura}` : '—', L('Altura', 'Height'))}
        {tile('barbell-outline', AMBER, peso ? `${peso} ${unidadPeso}` : '—', L('Peso', 'Weight'))}
      </View>

      <CompletionBar pct={pct} theme={theme} L={L} />
    </View>
  );
}

// Tarjeta de sección con cabecera de color
function Section({ icon, color, title, children, theme }) {
  return (
    <View style={[styles.section, { backgroundColor: theme.card, borderColor: theme.border }]}>
      <View style={styles.sectionHead}>
        <View style={[styles.sectionIcon, { backgroundColor: color + '22', borderColor: color + '66' }]}>
          <Ionicons name={icon} size={16} color={color} />
        </View>
        <Text style={[styles.sectionTitle, { color: theme.text }]}>{title}</Text>
      </View>
      {children}
    </View>
  );
}

// Campo de texto con icono y foco de color
function Field({ label, value, onChange, keyboardType, placeholder, editable = true, icon }) {
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const [focused, setFocused] = useState(false);
  return (
    <View style={styles.fieldContainer}>
      <Text style={[styles.fieldLabel, { color: theme.muted }]}>{label}</Text>
      <View style={[
        styles.fieldWrap,
        { backgroundColor: theme.input, borderColor: focused ? TEAL : theme.border },
        !editable && styles.disabledInput,
      ]}>
        {!!icon && <Ionicons name={icon} size={17} color={focused ? TEAL : theme.muted} />}
        <TextInput
          style={[styles.fieldInput, { color: theme.text }]}
          value={value}
          onChangeText={onChange}
          placeholder={placeholder || ''}
          placeholderTextColor="#4A6080"
          keyboardType={keyboardType}
          editable={editable}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
        />
        {!editable && <Ionicons name="lock-closed-outline" size={15} color={theme.muted} />}
      </View>
    </View>
  );
}

// Opción del selector a pantalla completa (check que "salta")
function PopCheck() {
  const sc = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.spring(sc, { toValue: 1, useNativeDriver: true, speed: 18, bounciness: 14 }).start();
  }, [sc]);
  return (
    <Animated.View style={{ transform: [{ scale: sc }] }}>
      <Ionicons name="checkmark-circle" size={22} color={TEAL} />
    </Animated.View>
  );
}

function FullScreenPicker({ value, options, onChange, placeholder = 'Escoge' }) {
  const insets = useSafeAreaInsets();
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const [visible, setVisible] = useState(false);
  const select = (opt) => { onChange(opt); setVisible(false); };
  const currentLabel = value || placeholder;
  return (
    <>
      <Press style={[pk.btn, { backgroundColor: theme.input, borderColor: theme.border }]} onPress={() => setVisible(true)}>
        <Text style={[pk.text, { color: value ? theme.text : theme.muted }]} numberOfLines={1}>{currentLabel}</Text>
        <Ionicons name="chevron-down" size={15} color={TEAL} />
      </Press>
      <Modal visible={visible} animationType="slide" transparent={false} onRequestClose={() => setVisible(false)}>
        <View style={[pk.fullScreen, { backgroundColor: theme.background }]}>
          <View style={[pk.fullHeader, { borderBottomColor: theme.border, paddingTop: insets.top + 10 }]}>
            <Text style={[pk.fullTitle, { color: theme.text }]}>{L('Selecciona una opción','Select an option')}</Text>
            <Press onPress={() => setVisible(false)} style={[styles.circleBtn, { backgroundColor: theme.card, borderColor: theme.border }]} hitSlop={10}>
              <Ionicons name="close" size={22} color="#8FA8C8" />
            </Press>
          </View>
          <ScrollView style={pk.fullList} contentContainerStyle={{ paddingTop: 12, paddingBottom: 12 }} showsVerticalScrollIndicator={false}>
            {options.map((opt, index) => {
              const selected = value === opt;
              return (
                <FadeIn key={opt} delay={Math.min(index * 35, 350)}>
                  <Pressable
                    style={({ pressed }) => [
                      pk.fullOption,
                      { backgroundColor: selected ? TEAL + '1F' : pressed ? theme.card : 'transparent', borderColor: selected ? TEAL : theme.border },
                    ]}
                    onPress={() => select(opt)}
                  >
                    <View style={[pk.indexBadge, { backgroundColor: selected ? TEAL : theme.card, borderColor: selected ? TEAL : theme.border }]}>
                      <Text style={{ color: selected ? '#06222A' : theme.muted, fontWeight: '800', fontSize: 13 }}>{index + 1}</Text>
                    </View>
                    <Text style={[pk.fullOptionText, { color: selected ? theme.text : theme.text }, selected && { fontWeight: '800' }]}>{opt}</Text>
                    {selected && <PopCheck />}
                  </Pressable>
                </FadeIn>
              );
            })}
          </ScrollView>
          <Press style={[pk.fullCancelBtn, { borderTopColor: theme.border, paddingBottom: 18 + insets.bottom }]} onPress={() => setVisible(false)}>
            <Text style={pk.fullCancelText}>{L('Cancelar','Cancel')}</Text>
          </Press>
        </View>
        <SystemBars />
      </Modal>
    </>
  );
}
const pk = StyleSheet.create({
  btn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 6, borderRadius: 12, borderWidth: 1.5, paddingHorizontal: 12, paddingVertical: 12 },
  text: { fontSize: 14, flex: 1 },
  fullScreen: { flex: 1, backgroundColor: NAVY },
  fullHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingBottom: 14, borderBottomWidth: 1 },
  fullTitle: { fontSize: 18, fontWeight: '800' },
  fullList: { flex: 1, paddingHorizontal: 16 },
  fullOption: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 12, borderWidth: 1.5, borderRadius: 14, marginBottom: 8, gap: 14 },
  indexBadge: { width: 32, height: 32, borderRadius: 16, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  fullOptionText: { fontSize: 16, flex: 1 },
  fullCancelBtn: { paddingVertical: 18, alignItems: 'center', borderTopWidth: 1, marginTop: 4 },
  fullCancelText: { color: RED, fontSize: 16, fontWeight: '700' },
});

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const appSettings = useAppSettings(); // re-renderiza al cambiar idioma/tema
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const user = auth.currentUser;
  const uid = user?.uid;
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [profile, setProfile] = useState(null);
  const [nombre, setNombre] = useState('');
  const [apellido, setApellido] = useState('');
  const [sexo, setSexo] = useState('');
  const [fechaNac, setFechaNac] = useState('');
  const [calNac, setCalNac] = useState(false);   // calendario para la fecha de nacimiento
  const [altura, setAltura] = useState('');
  const [unidadAltura, setUnidadAltura] = useState('cm');
  const [peso, setPeso] = useState('');
  const [unidadPeso, setUnidadPeso] = useState('kg');
  const [pais, setPais] = useState('');
  const [ciudad, setCiudad] = useState('');
  const [dni, setDni] = useState('');
  const [telefono, setTelefono] = useState('');
  const [fotoBase64, setFotoBase64] = useState(null);
  const sexos = ['Masculino', 'Femenino', 'Otro'];
  const unidades = ['cm', 'm', 'in', 'ft'];
  const unidadesPeso = ['kg', 'lb'];

  useEffect(() => {
    if (!uid) { setFetching(false); return; }
    (async () => {
      const cached = await getCachedProfile();
      if (cached) {
        setProfile(cached);
        setNombre(cached.nombre || ''); setApellido(cached.apellido || '');
        setSexo(cached.sexo || ''); setFechaNac(formatoBonitoFechaNac(cached.fechaNac));
        setAltura(cached.altura || ''); setUnidadAltura(cached.unidadAltura || 'cm');
        setPeso(cached.peso || ''); setUnidadPeso(cached.unidadPeso || 'kg');
        setPais(cached.pais || ''); setCiudad(cached.ciudad || '');
        setDni(cached.dni || ''); setTelefono(cached.telefono || '');
        if (cached.foto) setFotoBase64(cached.foto);
        setFetching(false);
      }
      try {
        const snap = await getDoc(doc(db, 'perfiles', uid));
        if (snap.exists()) {
          const data = snap.data();
          setProfile(data);
          setNombre(data.nombre || ''); setApellido(data.apellido || '');
          setSexo(data.sexo || ''); setFechaNac(formatoBonitoFechaNac(data.fechaNac));
          setAltura(data.altura || ''); setUnidadAltura(data.unidadAltura || 'cm');
          setPeso(data.peso || ''); setUnidadPeso(data.unidadPeso || 'kg');
          setPais(data.pais || ''); setCiudad(data.ciudad || '');
          setDni(data.dni || ''); setTelefono(data.telefono || '');
          if (data.foto) setFotoBase64(data.foto);
          await cacheProfile(uid, data);
        }
      } catch (err) {
        console.error('Error refrescando perfil:', err);
      } finally {
        setFetching(false);
      }
    })();
  }, [uid]);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert(L('Permiso requerido','Permission required'), L('Concede acceso a la galería para elegir una foto.','Grant gallery access to pick a photo.'));
      return;
    }
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });
    if (result.canceled || !result.assets || result.assets.length === 0) return;
    const imageUri = result.assets[0].uri;
    try {
      const tempFile = FileSystem.cacheDirectory + 'profile_pic_temp.jpg';
      await FileSystem.copyAsync({ from: imageUri, to: tempFile });
      const manipResult = await ImageManipulator.manipulateAsync(
        tempFile,
        [{ resize: { width: 200, height: 200 } }],
        { compress: 0.5, format: ImageManipulator.SaveFormat.JPEG }
      );
      const base64 = await FileSystem.readAsStringAsync(manipResult.uri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      setFotoBase64(base64);
      await FileSystem.deleteAsync(tempFile, { idempotent: true });
    } catch (error) {
      console.error('Error al manipular:', error);
      try {
        const base64 = await FileSystem.readAsStringAsync(imageUri, {
          encoding: FileSystem.EncodingType.Base64,
        });
        setFotoBase64(base64);
        Alert.alert(L('Imagen guardada','Image saved'), L('No se pudo comprimir, se guardó la imagen original.','Could not compress; original image saved.'));
      } catch (fallbackError) {
        console.error('Error al leer la imagen original:', fallbackError);
        Alert.alert(L('Error','Error'), L('No se pudo procesar la imagen seleccionada.','Could not process the selected image.'));
      }
    }
  };

  const handleUpdate = async () => {
    if (!uid) { Alert.alert(L('Error','Error'), L('No se ha identificado al usuario.','User not identified.')); return; }
    // Validar la fecha de nacimiento antes de guardar nada: si está rellena y
    // el formato no es correcto (o es futura / inverosímil), se bloquea la
    // actualización completa del perfil y se avisa al usuario.
    const fnCheck = validarFechaNac(fechaNac);
    if (!fnCheck.ok) {
      const mensajes = {
        futura: L('La fecha de nacimiento no puede ser futura.','Date of birth cannot be in the future.'),
        rango: L('La fecha de nacimiento no parece válida (más de 110 años).','Date of birth does not look valid (over 110 years).'),
        formato: L('El formato de la fecha de nacimiento no es correcto. Formatos válidos: DD/MM/AAAA, DD-MM-AAAA, AAAA-MM-DD o DD MMM AAAA (p. ej. 15/03/1990 o 15 Mar 1990).','Invalid date of birth format. Valid formats: DD/MM/YYYY, DD-MM-YYYY, YYYY-MM-DD or DD MMM YYYY (e.g. 15/03/1990 or 15 Mar 1990).'),
      };
      Alert.alert(
        L('Fecha de nacimiento no válida','Invalid date of birth'),
        (mensajes[fnCheck.motivo] || mensajes.formato) + ' ' + L('No se ha guardado ningún cambio.','No changes were saved.')
      );
      return;
    }
    setLoading(true);
    try {
      const dataToSave = {
        nombre, apellido, sexo, fechaNac: fnCheck.iso, altura, unidadAltura, peso, unidadPeso,
        pais, ciudad, dni, telefono, email: user?.email || '',
      };
      if (fotoBase64) dataToSave.foto = fotoBase64;
      await setDoc(doc(db, 'perfiles', uid), dataToSave, { merge: true });
      await cacheProfile(uid, dataToSave);
      await invalidateProfileCache(uid);
      if (fotoBase64) {
        // Avatar estilo WhatsApp: sube la foto a R2 y publica avatares/<uid>
        // (doc ligero). Los demás teléfonos la descargan UNA vez y solo
        // vuelven a bajarla cuando cambie. Si el servidor no está desplegado
        // no pasa nada: el chat usa el respaldo legacy (base64 de perfiles).
        publicarMiAvatar(fotoBase64, user).catch((e) => console.warn('[perfil] avatar:', e && e.message));
      }
      Alert.alert(L('Perfil actualizado','Profile updated'), L('Los cambios se han guardado correctamente.','Changes saved successfully.'));
    } catch (err) {
      console.error('Error al guardar perfil:', err);
      Alert.alert(L('Error','Error'), L('No se pudo guardar el perfil: ','Could not save profile: ') + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    Alert.alert(L('Cerrar sesión','Sign out'), L('¿Estás seguro de que quieres salir?','Are you sure you want to exit?'), [
      { text: L('Cancelar','Cancel'), style: 'cancel' },
      {
        text: L('Salir','Exit'),
        style: 'destructive',
        onPress: async () => {
          await clearProfileCache();
          await clearCoachCache();
          await AsyncStorage.multiRemove(['garmin_email', 'garmin_password', 'garmin_days', 'fit_folder_uri']);
          signOut(auth);
        },
      },
    ]);
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      L('Eliminar cuenta','Delete account'),
      L('Esta acción es irreversible. Se borrarán todos tus datos, entrenos y relaciones con entrenador.','This action is irreversible. All your data, workouts and coach relations will be deleted.'),
      [
        { text: L('Cancelar','Cancel'), style: 'cancel' },
        {
          text: L('Eliminar','Delete'),
          style: 'destructive',
          onPress: async () => {
            setLoading(true);
            try {
              if (profile?.entrenador) {
                await fetch(`${SERVER_URL}/eliminar-entrenador`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ atletaId: uid }),
                });
              }
              await deleteDoc(doc(db, 'perfiles', uid));
              await deleteUser(auth.currentUser);
            } catch (error) {
              Alert.alert(L('Error','Error'), L('Necesitas haber iniciado sesión recientemente para eliminar la cuenta. Vuelve a iniciar sesión e inténtalo.','You need a recent session to delete the account. Sign in again and retry.'));
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  };

  if (fetching) {
    return <SkeletonProfile theme={theme} />;
  }

  // ── Datos derivados para el carnet (solo visual) ──
  const pNac = parseFechaNac(fechaNac);
  const edadCalc = pNac ? Math.floor((Date.now() - new Date(pNac.y, pNac.m - 1, pNac.d).getTime()) / (365.25 * 24 * 3600 * 1000)) : null;
  const edad = edadCalc != null && edadCalc >= 0 && edadCalc < 130 ? edadCalc : null;
  const camposCompletables = [nombre, apellido, sexo, fechaNac, altura, peso, pais, ciudad, dni, telefono, fotoBase64];
  const rellenos = camposCompletables.filter((c) => String(c ?? '').trim() !== '').length;
  const pctCompleto = Math.round((rellenos / camposCompletables.length) * 100);

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <View style={[styles.header, { backgroundColor: theme.card, borderBottomColor: theme.border, paddingTop: insets.top + 10 }]}>
        <Press onPress={() => navigation.goBack()} style={[styles.circleBtn, { backgroundColor: theme.background, borderColor: theme.border }]} hitSlop={10}>
          <Ionicons name="chevron-back" size={22} color="#8FA8C8" />
        </Press>
        <Text style={[styles.headerTitle, { color: theme.text }]}>{L('Perfil','Profile')}</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        contentContainerStyle={[styles.scrollContent, { paddingBottom: Math.max(40, insets.bottom + 16) }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Carnet de atleta */}
        <FadeIn style={styles.pad}>
          <IdCard
            theme={theme}
            foto={fotoBase64}
            nombre={nombre}
            apellido={apellido}
            pais={pais}
            ciudad={ciudad}
            edad={edad}
            altura={altura}
            unidadAltura={unidadAltura}
            peso={peso}
            unidadPeso={unidadPeso}
            pct={pctCompleto}
            onPickImage={pickImage}
          />
        </FadeIn>

        {/* Datos personales */}
        <FadeIn delay={120} style={styles.pad}>
          <Section icon="person-outline" color={TEAL} title={L('Datos personales', 'Personal details')} theme={theme}>
            <Field icon="person-outline" label={L('Nombre','First name')} value={nombre} onChange={setNombre} />
            <Field icon="people-outline" label={L('Apellido','Last name')} value={apellido} onChange={setApellido} />
            <Text style={[styles.fieldLabel, { color: theme.muted }]}>{L('Sexo','Gender')}</Text>
            <FullScreenPicker value={sexo} options={sexos} onChange={setSexo} placeholder={L('Seleccionar sexo','Select gender')} />
            <View style={{ height: 12 }} />
            <Text style={[styles.fieldLabel, { color: theme.muted }]}>{L('Fecha de nacimiento','Date of birth')}</Text>
            <Press
              style={[styles.fieldWrap, { backgroundColor: theme.input, borderColor: theme.border, paddingVertical: 13 }]}
              onPress={() => setCalNac(true)}
            >
              <Ionicons name="calendar-outline" size={17} color={TEAL} />
              <Text style={{ color: fechaNac ? theme.text : '#4A6080', fontSize: 15, flex: 1 }}>
                {fechaNac || L('DD MMM AAAA','DD MMM YYYY')}
              </Text>
              <Ionicons name="chevron-forward" size={15} color={theme.muted} />
            </Press>
            <View style={[styles.row, { marginTop: 12 }]}>
              <View style={{ flex: 1 }}>
                <Field icon="resize-outline" label={L('Altura','Height')} value={altura} onChange={setAltura} keyboardType="numeric" />
              </View>
              <View style={{ width: 92, marginLeft: 10 }}>
                <Text style={[styles.fieldLabel, { color: theme.muted }]}>{L('Unidad','Unit')}</Text>
                <FullScreenPicker value={unidadAltura} options={unidades} onChange={setUnidadAltura} />
              </View>
            </View>
            <View style={styles.row}>
              <View style={{ flex: 1 }}>
                <Field icon="barbell-outline" label={L('Peso','Weight')} value={peso} onChange={setPeso} keyboardType="numeric" />
              </View>
              <View style={{ width: 92, marginLeft: 10 }}>
                <Text style={[styles.fieldLabel, { color: theme.muted }]}>{L('Unidad','Unit')}</Text>
                <FullScreenPicker value={unidadPeso} options={unidadesPeso} onChange={setUnidadPeso} />
              </View>
            </View>
          </Section>
        </FadeIn>

        {/* Contacto y ubicación */}
        <FadeIn delay={220} style={styles.pad}>
          <Section icon="mail-outline" color={CORAL} title={L('Contacto y ubicación', 'Contact & location')} theme={theme}>
            <Field icon="mail-outline" label={L('Correo Electrónico','Email')} value={user?.email || ''} editable={false} />
            <Field icon="flag-outline" label={L('País','Country')} value={pais} onChange={setPais} />
            <Field icon="location-outline" label={L('Ciudad','City')} value={ciudad} onChange={setCiudad} />
            <Field icon="id-card-outline" label={L('DNI','ID')} value={dni} onChange={setDni} />
            <Field icon="call-outline" label={L('Teléfono','Phone')} value={telefono} onChange={setTelefono} keyboardType="phone-pad" />
          </Section>
        </FadeIn>

        {/* Acciones */}
        <FadeIn delay={320} style={styles.pad}>
          <Press style={[styles.updateBtn, loading && { opacity: 0.7 }]} onPress={handleUpdate} disabled={loading}>
            {!loading && <Shine />}
            {loading
              ? <ActivityIndicator color="#fff" />
              : (<>
                  <Ionicons name="checkmark-circle-outline" size={20} color="#fff" />
                  <Text style={styles.updateBtnText}>{L('Actualiza','Update')}</Text>
                </>)}
          </Press>
          <Press style={styles.logoutBtn} onPress={handleLogout}>
            <Ionicons name="log-out-outline" size={20} color={RED} />
            <Text style={styles.logoutText}>{L('Cerrar sesión','Sign out')}</Text>
          </Press>
          <Press style={styles.deleteBtn} onPress={handleDeleteAccount}>
            <Ionicons name="trash-outline" size={16} color={RED} />
            <Text style={styles.deleteText}>{L('Eliminar Cuenta','Delete Account')}</Text>
          </Press>
        </FadeIn>
      </ScrollView>
      <MonthPickerModal
        visible={calNac}
        nacimiento
        initialDate={(() => { const p = parseFechaNac(fechaNac); return p ? new Date(p.y, p.m - 1, p.d) : new Date(new Date().getFullYear() - 30, new Date().getMonth(), new Date().getDate()); })()}
        onClose={() => setCalNac(false)}
        onSelect={(d) => { setFechaNac(`${d.getDate()} ${mesesDisplay()[d.getMonth()]} ${d.getFullYear()}`); setCalNac(false); }}
      />
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  centered: { flex: 1, backgroundColor: NAVY, alignItems: 'center', justifyContent: 'center' },
  scrollContent: { paddingTop: 16, gap: 18 },
  pad: { paddingHorizontal: 16 },

  // Cabecera
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: BORDER },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  circleBtn: { width: 40, height: 40, borderRadius: 20, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  shine: { position: 'absolute', top: -30, height: 120, width: 28, backgroundColor: 'rgba(255,255,255,0.22)' },

  // Esqueleto
  skelCard: { alignItems: 'center', borderRadius: 26, borderWidth: 1.5, padding: 24, width: '82%' },

  // Carnet
  idCard: { borderRadius: 28, borderWidth: 1.5, overflow: 'hidden', paddingBottom: 18, alignItems: 'center' },
  band: { height: 104, width: '100%', overflow: 'hidden' },
  slot: { alignSelf: 'center', marginTop: 10, width: 56, height: 12, borderRadius: 6, borderWidth: 1.5 },
  bandTag: { position: 'absolute', left: 16, bottom: 12, flexDirection: 'row', alignItems: 'center', gap: 6 },
  bandTagText: { fontSize: 11, fontWeight: '800', letterSpacing: 1.5 },
  photoWrap: { width: 112, height: 112, alignItems: 'center', justifyContent: 'center' },
  photo: { width: 108, height: 108, borderRadius: 34, borderWidth: 4 },
  photoPlaceholder: { alignItems: 'center', justifyContent: 'center' },
  camWrap: { position: 'absolute', right: -2, bottom: -2, width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  camBadge: { width: 32, height: 32, borderRadius: 16, backgroundColor: CORAL, alignItems: 'center', justifyContent: 'center', borderWidth: 3 },
  photoText: { fontSize: 13, marginTop: 8, fontWeight: '700' },
  idName: { fontSize: 22, fontWeight: '800', marginTop: 10, paddingHorizontal: 20 },
  placeRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4, paddingHorizontal: 20 },
  placeText: { fontSize: 13 },
  statsRow: { flexDirection: 'row', gap: 10, marginTop: 16, paddingHorizontal: 16, width: '100%' },
  statTile: { flex: 1, borderRadius: 14, borderWidth: 1, paddingVertical: 10, paddingHorizontal: 6, alignItems: 'center', gap: 3 },
  statVal: { fontSize: 15, fontWeight: '800' },
  statLabel: { fontSize: 10, fontWeight: '700' },
  compWrap: { width: '100%', paddingHorizontal: 16, marginTop: 16, gap: 8 },
  compTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  compLabel: { fontSize: 12, fontWeight: '700' },
  compPct: { fontSize: 14, fontWeight: '800' },
  compTrack: { height: 7, borderRadius: 4, overflow: 'hidden' },
  compFill: { height: 7, borderRadius: 4 },

  // Secciones
  section: { borderRadius: 22, borderWidth: 1, padding: 16 },
  sectionHead: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 14 },
  sectionIcon: { width: 32, height: 32, borderRadius: 11, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  sectionTitle: { fontSize: 15, fontWeight: '800' },
  row: { flexDirection: 'row', alignItems: 'flex-start' },
  fieldContainer: { marginBottom: 12 },
  fieldLabel: { fontSize: 13, marginBottom: 6, fontWeight: '600' },
  fieldWrap: { flexDirection: 'row', alignItems: 'center', gap: 10, borderRadius: 12, borderWidth: 1.5, paddingHorizontal: 12 },
  fieldInput: { flex: 1, paddingVertical: 12, fontSize: 15 },
  disabledInput: { opacity: 0.7 },

  // Acciones
  updateBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, backgroundColor: TEAL, borderRadius: 16, paddingVertical: 16, overflow: 'hidden' },
  updateBtnText: { color: '#fff', fontSize: 16, fontWeight: '800' },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, marginTop: 12, backgroundColor: RED + '1A', borderRadius: 16, borderWidth: 1.5, borderColor: RED + '66', paddingVertical: 15 },
  logoutText: { color: RED, fontSize: 16, fontWeight: '800' },
  deleteBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 14, paddingVertical: 12, borderRadius: 14, borderWidth: 1.5, borderStyle: 'dashed', borderColor: RED + '55' },
  deleteText: { color: RED, fontSize: 14, fontWeight: '700' },
});