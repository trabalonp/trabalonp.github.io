// screens/SocialScreen.js
// REDISEÑO VISUAL estilo WhatsApp: barra superior con pestañas, burbujas agrupadas
// con cola y tic de enviado, composer en píldora + botón verde, fondo de chat y
// FAB ↓ de WhatsApp. TODA la lógica (sincronización, caché, subidas a R2, audio,
// encuestas, reacciones, retos, visor de imágenes…) es la misma que antes.
/* Pestaña SOCIAL — chat de equipo estilo WhatsApp + retos.
   TABLÓN:
   · Burbujas (propias derecha verde / demás izquierda con avatar y nombre de
     color), hora abajo-derecha, reacciones con pulsación larga (una por
     persona, pills con contador), responder/reenviar/eliminar al seleccionar,
     citas y marca de reenviado. Tocar la CITA salta al mensaje original si
     está cargado (destello azul); si no está, no hace nada.
   · Separadores de fecha estilo WhatsApp entre mensajes de días distintos:
     HOY / AYER / nombre del día (últimos 7 días) / "15 de marzo de 2024",
     en una píldora negra semitransparente centrada.
   · Audios reproducibles DENTRO del chat (expo-audio: play/pause, barra de
     progreso con seek, duración; uno a la vez) y archivos en tarjeta grande
     estilo WhatsApp (icono, nombre, extensión · tamaño).
   · Fondo del tablón tal cual se subió: sin velo blanco encima.
   · Imágenes (patrón WhatsApp real): al enviar se genera y sube también una
     MINIATURA de 640 px; la burbuja pinta la miniatura (expo-image, caché
     memoria+disco) y el visor a pantalla completa carga el ORIGINAL con
     gestos en el hilo de UI (gesture-handler + reanimated): pellizco anclado
     a los dedos, pan 1:1, doble toque 2.5x, swipe entre fotos y swipe abajo
     para cerrar.
   · Envío estilo WhatsApp: el mensaje se publica AL INSTANTE con la imagen en
     local y un aro de progreso; la subida a Cloudflare R2 va en segundo plano
     y al terminar se fija la URL en Firestore (los demás la ven entonces).
   · Caché local-first estilo WhatsApp (services/chatStore.js): el historial
     ya recibido vive en el dispositivo y se pinta AL INSTANTE sin red; las
     imágenes en disco (cacheDirectory) con descarga single-flight + .part +
     move atómico (adiós imágenes cortadas).
   · Sincronización INCREMENTAL: al abrir solo se piden los mensajes
     posteriores al último sincronizado (where createdAt > lastSync); el
     historial antiguo se pagina hacia atrás AUTOMÁTICAMENTE por zonas de
     50 al rozar el borde superior (sin botón de "descargar el chat de la
     nube"). Motor en services/chatSync.js, verificado por
     tests/chat-sync-test.js. Nunca se descarga todo el chat.
   · Listener en vivo con docChanges(): added/modified se fusionan en el
     almacén local; removed se ignora a propósito (defensivo: el servidor
     ya no purga mensajes).
   · Historial PERMANENTE: los mensajes no caducan. La sincronización
     incremental ya garantiza que nunca se descarga el chat entero, así que
     el tamaño del historial no aumenta el coste. El endpoint de purga
     (api/social/purge) queda como herramienta opcional, desactivada.
   · Eliminar = borrado lógico (eliminado:true): los demás ven "Mensaje
     eliminado". Si el mensaje tenía imagen/archivo, el borrado pasa por el
     servidor (api/social/delete-message.js), que elimina TAMBIÉN el objeto
     de Cloudflare R2 — solo si ningún otro mensaje vivo lo referencia (los
     reenvíos comparten URL y no se rompen). Sin servidor desplegado, la app
     hace el borrado lógico de siempre como respaldo.
   · Enlaces PINCHABLES en el texto (azul + subrayado, patrón WhatsApp) y
     PREVISUALIZACIÓN Open Graph generada en el lado del EMISOR: al enviar,
     la app pide los metadatos al servidor (api/social/link-preview.js, con
     protección SSRF) y los adjunta al mensaje (campo preview); el receptor
     pinta la tarjeta (imagen + título + dominio) sin descargar nada.
     Mensajes antiguos sin preview: se piden una vez y se cachean 7 días
     (services/linkPreview.js).
   · Encuestas estilo WhatsApp: resultados EN VIVO (listener propio por
     documento: los votos de los demás llegan al instante aunque la
     encuesta sea antigua), voto optimista en pantalla, barras de color por
     opción e insignia "GANANDO" en la líder (recuento en
     services/encuestas.js).
   · Foto de perfil en la burbuja con CACHÉ LOCAL (services/avatarCache.js,
     patrón WhatsApp): la foto se descarga UNA vez a disco y se pinta desde
     ahí; solo se vuelve a descargar cuando la persona cambia su foto (doc
     ligero avatares/<uid> con la URL en R2; los perfiles antiguos sin doc
     usan un respaldo con TTL de 6 h).
   · Scroll estilo WhatsApp: el viewport SOLO sigue el chat si ya estaba
     abajo. Votar una encuesta, reaccionar, seleccionar un mensaje o recibir
     mensajes mientras lees historial ya NO te arrastran al último mensaje;
     al volver de la pestaña "Retos" se restaura la posición exacta. Cuando
     NO estás abajo aparece un botón circular ↓ sobre la isla flotante
     (mismo diseño que las fichas de fecha, con insignia de no vistos).
   RETOS: coach crea con métrica, periodo y atletas invitados; invitados
   aceptan; ranking en vivo entre aceptados; historial con ganador. */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, Animated, Dimensions, Easing, Image, Keyboard, Linking,
  Modal, Platform, Pressable, RefreshControl, ScrollView, Text, TextInput,
  TouchableOpacity, View, useColorScheme,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { getSocialBg } from '../services/socialBg';
import { Ionicons } from '@expo/vector-icons';
import { chatStoreInit, chatStoreAll, chatStorePut, chatStoreMeta, chatStoreSetMeta, chatStoreRemove } from '../services/chatStore';
import { gapSync, loadOlderZone } from '../services/chatSync';
import { claveDia, esAudioMedia, extDe, fmtDur, fmtSeparador, fmtSize } from '../services/fechasChat';
import { colorOpcion, contarVotos } from '../services/encuestas';
import { dominioDe, normalizarUrl, primeraUrl, segmentar } from '../services/enlaces';
import { obtenerPreview, previewParaEnvio } from '../services/linkPreview';
import { avatarCacheInit, sincronizarAvatares, useAvatar } from '../services/avatarCache';
import {
  Timestamp, addDoc, arrayUnion, collection, deleteDoc, doc, getDoc, getDocs,
  limit, onSnapshot, orderBy, query, updateDoc, where,
} from 'firebase/firestore';
import * as FileSystem from 'expo-file-system/legacy';  // uploadAsync/getInfoAsync clásicos
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import * as Sharing from 'expo-sharing';
import * as Clipboard from 'expo-clipboard';
import RangoCalendarioModal from '../components/RangoCalendarioModal';
import WeatherPanel from '../components/WeatherPanel';
import { sendNotificationToAthlete } from '../services/coachNotify';
// Reproductor de audio del chat (expo-audio, SDK 57). require PROTEGIDO: si
// el bundle llega por OTA a un binario antiguo sin el módulo nativo, la app
// sigue funcionando y los audios se abren con el panel del sistema.
let AudioLib = null;
try { AudioLib = require('expo-audio'); } catch (e) { AudioLib = null; }
import * as ImageManipulator from 'expo-image-manipulator';
import { Image as ExpoImage } from 'expo-image';
import { Gesture, GestureDetector, GestureHandlerRootView } from 'react-native-gesture-handler';
import Reanimated, {
  clamp, interpolate, runOnJS, useAnimatedStyle, useSharedValue,
  withSpring, withTiming,
} from 'react-native-reanimated';
import { auth, db } from '../firebaseConfig';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getThemeColors, useAppSettings, locale } from '../services/appSettings';
import { getCachedProfile } from '../services/profileCache';
import { getApiUrl } from '../services/api';
import { onTablonPurge } from '../services/tablonPurge';
import { configureSocialNotifications } from '../services/socialNotifications';
import SystemBars from '../components/SystemBars';

// Método de subida binario (legacy expo-file-system): BINARY_CONTENT, con
// fallbacks por si el enum viene con otro nombre en alguna versión.
let GOOD_UPLOAD_TYPE = 0;   // se auto-corrige verificando el objeto subido
const BIN_UPLOAD = (() => {
  try {
    const M = FileSystem.FileSystemUploadMethod || FileSystem.FileSystemUploadType || {};
    if (typeof M.BINARY_CONTENT === 'number') return M.BINARY_CONTENT;
    if (typeof M.MULTIPART === 'number') return M.MULTIPART === 0 ? 1 : 0;
  } catch (e) {}
  return 0;
})();
GOOD_UPLOAD_TYPE = BIN_UPLOAD;

const REACCIONES_BASE = ['\u{1F44D}', '\u{2764}\u{FE0F}', '\u{1F602}', '\u{1F62E}', '\u{1F622}', '\u{1F64F}', '\u{1F525}'];
const REACCIONES_TODAS = ['\u{1F600}','\u{1F603}','\u{1F604}','\u{1F60D}','\u{1F618}','\u{1F61B}','\u{1F61C}','\u{1F622}','\u{1F62E}','\u{1F621}','\u{1F631}','\u{1F914}','\u{1F44D}','\u{1F44E}','\u{1F44F}','\u{1F64F}','\u{1F4AA}','\u{1F525}','\u{1F389}','\u{1F60A}','\u{1F60C}','\u{1F609}','\u{1F60F}','\u{1F970}','\u{1F917}','\u{1F92D}','\u{1F929}','\u{1F973}','\u{1F976}','\u{1F92F}','\u{1F44C}','\u{1F91D}','\u{1F64C}','\u{1F4AF}','\u{2764}\u{FE0F}','\u{1F499}','\u{1F49A}','\u{1F49B}','\u{1F49C}','\u{1F90D}','\u{1F5A4}','\u{1F494}','\u{1F4A5}','\u{1F4A1}','\u{1F4AF}','\u{1F389}','\u{1F381}','\u{1F4AF}'];
const REACCIONES = REACCIONES_BASE;
const NOMBRES_COLOR = ['#E5426A', '#0E8A6D', '#B5651D', '#4A90E2', '#8E44AD', '#2DB37A', '#D35400', '#16A085'];
const METRICAS = [
  { id: 'pasos',      label: 'Pasos',             unidad: 'pasos' },
  { id: 'sueno',      label: 'Sueño',             unidad: 'h' },
  { id: 'racha',      label: 'Racha de entrenos',  unidad: 'días' },
  { id: 'km',        label: 'Kilómetros',         unidad: 'km' },
  { id: 'sesiones',  label: 'Sesiones',           unidad: 'sesiones' },
  { id: 'minutos',   label: 'Tiempo',             unidad: 'min' },
  { id: 'esfuerzo',  label: 'Puntos de esfuerzo', unidad: 'pts' },
];

/* Votos optimistas recientes (postId -> { idx, ts }): durante 5 s ningún
   eco del servidor puede revertir un voto recién hecho en pantalla. */
const votosRecientes = new Map();

const colorDe = (uid) => {
  let h = 0;
  const str = String(uid || 'x');
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return NOMBRES_COLOR[h % NOMBRES_COLOR.length] || '#4A90E2';
};
const fmtHora = (ts, loc) => {
  if (!ts) return '';
  const d = ts?.toDate ? ts.toDate() : new Date(ts);
  if (isNaN(d.getTime())) return '';
  const hoy = new Date();
  return d.toDateString() === hoy.toDateString()
    ? d.toLocaleTimeString(loc, { hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString(loc, { day: '2-digit', month: '2-digit' }) + ' ' + d.toLocaleTimeString(loc, { hour: '2-digit', minute: '2-digit' });
};
const fmtDia = (ts, loc) => {
  if (!ts) return '';
  const d = ts?.toDate ? ts.toDate() : new Date(ts);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleDateString(loc, { day: 'numeric', month: 'short' });
};
const valorDe = (w, metrica) => {
  switch (metrica) {
    case 'pasos':    return Number(w.pasos ?? w.steps ?? w.stepCount ?? 0);
    case 'sueno':    return Number(w.sueno ?? w.sueño ?? w.sleepHours ?? w.sleep ?? 0);
    case 'km':       return Number(w.distancia || 0);
    case 'sesiones': return 1;
    case 'minutos':  return Number(w.duracion || 0) / 60;
    case 'esfuerzo': return Number(w.esfuerzo || 0);
    default:         return 0;
  }
};
const fmtValor = (v, metrica) =>
  metrica === 'sesiones' || metrica === 'pasos' || metrica === 'racha' ? String(Math.round(v)) + (metrica === 'racha' ? ' d' : '') :
  metrica === 'minutos' ? `${Math.round(v)}'` : metrica === 'sueno' ? `${Number(v).toFixed(1)} h` :
  metrica === 'esfuerzo' ? String(Math.round(v)) : `${v.toFixed(1)} km`;

function rachaDeEntrenos(fechas) {
  const dias = [...new Set((fechas || []).map((f) => {
    const d = f?.toDate?.() || new Date(f);
    return isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10);
  }).filter(Boolean))].sort();
  let mejor = 0, actual = 0, anterior = null;
  for (const dia of dias) {
    const d = new Date(`${dia}T00:00:00Z`);
    const prev = anterior ? new Date(`${anterior}T00:00:00Z`) : null;
    actual = prev && (d - prev) === 86400000 ? actual + 1 : 1;
    mejor = Math.max(mejor, actual);
    anterior = dia;
  }
  return mejor;
}

/* ── Caché de imágenes en disco: single-flight + .part + move atómico ── */
const IMG_DIR = (FileSystem.documentDirectory || FileSystem.cacheDirectory) + 'social-thumbs-v4/';
const ORIGINAL_DIR = (FileSystem.cacheDirectory || FileSystem.documentDirectory) + 'social-originals-session/';
let imgDirReady = false;
async function ensureImgDir() {
  if (imgDirReady) return;
  try {
    const info = await FileSystem.getInfoAsync(IMG_DIR);
    if (!info.exists) await FileSystem.makeDirectoryAsync(IMG_DIR, { intermediates: true });
  } catch (e) {}
  imgDirReady = true;
}
  const cleanMediaUrl = (url) => String(url || '').replace(/\s+/g, '').trim();
  const localFor = (url) => IMG_DIR + (cleanMediaUrl(url).split('/').pop().split('?')[0] || 'img');
const diskCache = new Map();   // url -> uri local ya descargada
const inflight = new Map();
const originalCache = new Map();
const originalInflight = new Map();

/* Ajustes → "Limpiar memoria del Tablón": al purgar se borran las carpetas
   de imágenes; aquí se vacían también las cachés EN MEMORIA de este módulo
   para que ninguna burbuja pinte la ruta de un archivo que ya no existe. */
onTablonPurge(async () => { diskCache.clear(); inflight.clear(); originalCache.clear(); originalInflight.clear(); imgDirReady = false; });
function cachedOrDownload(url) {
  const cleanUrl = cleanMediaUrl(url);
  if (!cleanUrl) return Promise.reject(new Error('URL de media vacía'));
  if (inflight.has(cleanUrl)) return inflight.get(cleanUrl);
  const pr = (async () => {
    await ensureImgDir();
    const local = localFor(cleanUrl);
    const info = await FileSystem.getInfoAsync(local);
    if (info.exists && info.size > 0) { diskCache.set(cleanUrl, local); return local; }
    const part = local + '.part';
    try { await FileSystem.deleteAsync(part, { idempotent: true }); } catch (e) {}
    await FileSystem.downloadAsync(cleanUrl, part);
    await FileSystem.moveAsync({ from: part, to: local });
    diskCache.set(cleanUrl, local);
    return local;
  })();
  inflight.set(cleanUrl, pr);
  pr.catch(() => {}).then(() => inflight.delete(cleanUrl));
  return pr;
}

/* El original solo vive en cacheDirectory durante esta sesión. La miniatura
   usa cachedOrDownload() y queda en documentDirectory para el historial.
   NOMBRE DEL FICHERO: sin caracteres raros (hash + extensión real). Antes se
   usaba encodeURIComponent(url) y el nombre salía lleno de %3A%2F… — Android
   (expo-sharing) decodifica esos %XX al resolver la ruta y el fichero "deja
   de existir", así que compartir la imagen fallaba en silencio en Android. */
const extImg = (u) => {
  const m = /\.(jpe?g|png|webp|gif|heic|heif|bmp)(\?|$)/i.exec(String(u || '').split('?')[0] || '');
  const e = m ? m[1].toLowerCase() : 'jpg';
  return `.${e === 'jpeg' ? 'jpg' : e}`;
};
const hashUrl = (s) => {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
  return h.toString(36);
};
function cachedOriginal(url) {
  const cleanUrl = cleanMediaUrl(url);
  if (!cleanUrl) return Promise.reject(new Error('URL de original vacía'));
  if (originalCache.has(cleanUrl)) return Promise.resolve(originalCache.get(cleanUrl));
  if (originalInflight.has(cleanUrl)) return originalInflight.get(cleanUrl);
  const pr = (async () => {
    try { await FileSystem.makeDirectoryAsync(ORIGINAL_DIR, { intermediates: true }); } catch (e) {}
    const local = ORIGINAL_DIR + hashUrl(cleanUrl) + extImg(cleanUrl);
    await FileSystem.downloadAsync(cleanUrl, local);
    originalCache.set(cleanUrl, local);
    return local;
  })();
  originalInflight.set(cleanUrl, pr);
  pr.catch(() => {}).then(() => originalInflight.delete(cleanUrl));
  return pr;
}

/* Al eliminar un mensaje con media se olvidan sus archivos locales: las
   imágenes/audios borrados dejan de ocupar espacio en el dispositivo. */
function olvidarMediaLocal(urls) {
  for (const u of (urls || [])) {
    try {
      diskCache.delete(u);
      const f = localFor(u);
      FileSystem.deleteAsync(f, { idempotent: true }).catch(() => {});
      FileSystem.deleteAsync(f + '.part', { idempotent: true }).catch(() => {});
    } catch (e) {}
  }
}

/* ── Miniatura 640 px estilo WhatsApp: la burbuja del chat pinta esta copia
      ligera; el original solo se descarga en el visor a pantalla completa.
      API nueva por contexto (SDK 52+) con fallback al método legacy. ── */
const THUMB_W = 640;
const THUMB_MIN_BYTES = 200 * 1024;   // por debajo de esto no compensa miniatura
async function makeThumb(uri) {
  const save = { compress: 0.72, format: ImageManipulator.SaveFormat.JPEG };
  if (typeof ImageManipulator.manipulate === 'function') {
    const ctx = ImageManipulator.manipulate(uri);
    ctx.resize({ width: THUMB_W });
    const ref = await ctx.renderAsync();
    const out = await ref.saveAsync(save);
    return out.uri;
  }
  const out = await ImageManipulator.manipulateAsync(uri, [{ resize: { width: THUMB_W } }], save);
  return out.uri;
}

async function presign(me, filename, contentType, size) {
  const apiUrl = (await getApiUrl()).replace(/\/+$/, '');
  const token = await me.getIdToken();
  const r = await fetch(`${apiUrl}/social/presign`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ filename, contentType, size }),
  });
  const t = await r.text();
  let d = null;
  try { d = JSON.parse(t); } catch (e) { d = null; }
  if (!r.ok || !d || !d.uploadUrl) throw new Error((d && d.error) || `presign HTTP ${r.status}: ${t.slice(0, 120)}`);
  return d;
}

/* PUSH DEL CHAT CON LA APP CERRADA — el listener de Firestore solo existe
   con la app abierta, así que el remitente avisa al servidor justo tras
   publicar; el servidor (/social/notify-message) avisa a TODOS los perfiles
   registrados (el Tablón lo lee todo el equipo, no solo entrenador y
   atletas directos), les manda el push de Expo y lo guarda en su historial
   de notificaciones. Fire-and-forget: si falla, el mensaje YA está
   publicado y el envío nunca se rompe. */
async function notificarPushMensaje(me, messageId, texto, autorNombre) {
  try {
    const apiUrl = (await getApiUrl()).replace(/\/+$/, '');
    const token = await me.getIdToken();
    const r = await fetch(`${apiUrl}/social/notify-message`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ messageId, texto, autorNombre }),
    });
    const d = await r.json().catch(() => null);
    // Trazabilidad: a quién dice el servidor que envió el push del mensaje
    // (`entrenador` = lo que el perfil del remitente tiene en su campo
    // entrenador). Si un aviso "no llega", compara esto con lo esperado.
    console.log('[chat-push]', r.ok ? `enviados=${d?.enviados} entrenador=${d?.entrenador} destinos=[${(d?.destinos || []).join(',')}]` : `HTTP ${r.status}`);
  } catch (e) { /* sin push no se rompe el envío */ }
}

/* Compatibilidad con las versiones del backend que han usado `publicUrl`,
   `url` o `publicURL`. Nunca debemos publicar un documento de Firestore con
   media.url vacío: R2 puede tener el objeto subido, pero el chat no tendría
   forma de leerlo. El servidor actual devuelve publicUrl; los otros nombres
   permiten que una app OTA siga funcionando mientras Vercel se despliega. */
function publicMediaUrl(d) {
  const u = d && (d.publicUrl || d.publicURL || d.url);
  // Evita guardar "r2.dev /social/..." si R2_PUBLIC_URL tiene un espacio.
  const limpia = typeof u === 'string' ? u.replace(/\s+/g, '').trim() : '';
  return /^https?:\/\//i.test(limpia) ? limpia : '';
}

async function uploadBinary(uploadUrl, uri, contentType) {
  const result = await FileSystem.uploadAsync(uploadUrl, uri, {
    httpMethod: 'PUT',
    headers: { 'Content-Type': contentType },
    mimeType: contentType,
    uploadType: BIN_UPLOAD,
  });
  const status = Number(result && result.status);
  if (status && (status < 200 || status >= 300)) {
    throw new Error(`R2 upload HTTP ${status}`);
  }
  return result;
}

/* ── ErrorBoundary: un dato malo ya no puede tumbar la app; muestra el
      error en pantalla para poder diagnosticarlo con una captura ── */
class SocialErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { err: null, cstack: '' }; }
  static getDerivedStateFromError(e) { return { err: e }; }
  componentDidCatch(e, info) {
    this.setState({ cstack: (info && info.componentStack) || '' });
  }
  render() {
    if (this.state.err) {
      const stack = String((this.state.err && this.state.err.stack) || '').split('\n').slice(0, 8).join('\n');
      return (
        <ScrollView style={{ margin: 8, maxHeight: 300, padding: 12, borderRadius: 12, backgroundColor: '#00000018', borderWidth: 1, borderColor: '#E05252' }}>
          <Text style={{ color: '#E05252', fontWeight: '800', marginBottom: 4 }}>Error en Social</Text>
          <Text style={{ color: '#444', fontSize: 12 }} selectable>{String(this.state.err && this.state.err.message)}</Text>
          <Text style={{ color: '#666', fontSize: 10, marginTop: 6 }} selectable>{stack}</Text>
          {!!this.state.cstack && <Text style={{ color: '#888', fontSize: 10, marginTop: 6 }} selectable>{this.state.cstack.split('\n').slice(0, 6).join('\n')}</Text>}
        </ScrollView>
      );
    }
    return this.props.children;
  }
}

export default function SocialScreen({ route }) {
  const insets = useSafeAreaInsets();
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const lang = appSettings.language;
  const L = (es, en) => (lang === 'en' ? en : es);
  const loc = lang === 'en' ? 'en-US' : 'es-ES';
  const me = auth.currentUser;
  const isLight = theme.background === '#F4F7FB';

  const [tab, setTab] = useState('tablon');
  const [posts, setPosts] = useState([]);          // cronológico asc
  const [loading, setLoading] = useState(true);

  const [hasMoreOld, setHasMoreOld] = useState(false);  // queda historial por paginar
  const [loadingOld, setLoadingOld] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [selIds, setSelIds] = useState([]);          // multi-selección de mensajes
  const [reactionPicker, setReactionPicker] = useState(false);
  const [reactionUsage, setReactionUsage] = useState({});
  const [bgUri, setBgUri] = useState(null);          // fondo local del tablón
  const [replyTo, setReplyTo] = useState(null);
  const [highlightId, setHighlightId] = useState(null);   // destello al saltar a un mensaje citado
  const [islandBottom, setIslandBottom] = useState(0.25);   // isla: 0.25 px de la barra; sube con el teclado
  const branchRef = useRef(null);
  const [viewer, setViewer] = useState(null);            // { index, urls } del visor
  const scrollRef = useRef(null);
  const contentH = useRef(0);          // alto del contenido (fija el scroll al paginar)
  const offsetRef = useRef(0);         // offset Y actual del scroll
  const pendingFix = useRef(null);     // { prevH, prevOff } al prepender antiguos
  const enElFinalRef = useRef(true);   // ¿el viewport está al final del chat?
  const prevCountRef = useRef(0);      // nº de mensajes en el último cambio de contenido
  const forzarFinalRef = useRef(false);// el próximo crecimiento FUERZA ir al final (mensaje propio)
  const restaurarRef = useRef(null);   // { y, h } guardado al salir a "Retos": se restaura al volver
  const primeraCargaRef = useRef(true);// primera carga del chat en esta sesión de la pantalla
  const [mostrarIrAbajo, setMostrarIrAbajo] = useState(false);  // visibilidad del FAB ↓
  const mostrarIrAbajoRef = useRef(false);                      // espejo del FAB (evita setState por evento)
  const [nuevosSinVer, setNuevosSinVer] = useState(0);          // insignia de no vistos del FAB ↓
  const posRef = useRef(new Map());    // id de mensaje -> { y } medido en el contenido
  const hlTimer = useRef(null);        // temporizador del destello
  const notifiedMessagesRef = useRef(new Set());

  const [retos, setRetos] = useState({ activos: [], pasados: [] });
  const [retosLoading, setRetosLoading] = useState(true);
  const [soyCoach, setSoyCoach] = useState(false);
  const [creaRetoOpen, setCreaRetoOpen] = useState(false);

  useEffect(() => {
    // Deep link de notificaciones: un push de mensaje (tab 'tablon') o de
    // reto (tab 'retos') lleva a su pestaña aunque se estuviera en la otra.
    if (route?.params?.tab === 'retos') setTab('retos');
    else if (route?.params?.tab === 'tablon') setTab('tablon');
  }, [route?.params?.tab, route?.params?.ts]);

  useEffect(() => {
    AsyncStorage.getItem(`social-reactions:${me.uid}`).then((raw) => {
      if (raw) setReactionUsage(JSON.parse(raw));
    }).catch(() => {});
    configureSocialNotifications().catch(() => {});
  }, [me.uid]);

  const reaccionesVisibles = useMemo(() => {
    const ordenadas = [...REACCIONES_TODAS].sort((a, b) => (reactionUsage[b] || 0) - (reactionUsage[a] || 0));
    return [...new Set([...ordenadas.slice(0, 7), ...REACCIONES_BASE])].slice(0, 7);
  }, [reactionUsage]);

  // La isla es FLOTANTE (absolute sobre el chat). Al salir el teclado se mide
  // el borde inferior del contenedor y el superior del teclado en las mismas
  // coordenadas de ventana, y se eleva justo hasta quedar encima.
  useEffect(() => {
    try {
    const evShow = Platform.OS === 'android' ? 'keyboardDidShow' : 'keyboardWillShow';
    const evHide = Platform.OS === 'android' ? 'keyboardDidHide' : 'keyboardWillHide';
    const s1 = Keyboard.addListener(evShow, (e) => {
      const kb = e.endCoordinates.height;
      branchRef.current?.measureInWindow((x, y, w, h) => {
        const winH = Dimensions.get('window').height;
        const off = (y + h) - (winH - kb);
        // + inset inferior (barra de navegación en edge-to-edge) + aire:
        // la isla queda justo por encima del borde superior del teclado.
        setIslandBottom(off > 0 ? off + insets.bottom + 0.25 : 0.25);
      });
    });
    const s2 = Keyboard.addListener(evHide, () => setIslandBottom(0.25));
    return () => { s1.remove(); s2.remove(); };
    } catch (e) { console.warn('[social] keyboard effect:', e.message); return undefined; }
  }, []);

  /* Scroll estilo WhatsApp: alFinal() solo baja si el usuario YA está al
     final (suave: no interrumpe la lectura del historial); alFinal(true)
     lo fuerza siempre (mensajes propios y primera apertura del chat). */
  const alFinal = (forzar = false) => setTimeout(() => {
    if (forzar || enElFinalRef.current) scrollRef.current?.scrollToEnd({ animated: false });
  }, 60);

  /* FAB ↓ (círculo sobre la isla): vuelve al último mensaje con animación
     y limpia la cuenta de mensajes no vistos. */
  const irAlFinal = () => {
    setNuevosSinVer(0);
    scrollRef.current?.scrollToEnd({ animated: true });
  };

  /* Al pasar a la pestaña "Retos" el ScrollView se desmonta: se guarda la
     posición exacta y se restaura al volver (WhatsApp no te tira al último
     mensaje cuando regresas a una conversación). */
  useEffect(() => {
    if (tab !== 'tablon') restaurarRef.current = { y: offsetRef.current, h: contentH.current };
  }, [tab]);

  // Fondo local del tablón (nunca en la nube): se refresca al volver a la pestaña
  useFocusEffect(useCallback(() => {
    getSocialBg().then((p) => setBgUri(p || null)).catch(() => {});
  }, []));


  const toggleSel = (id) => {
    restaurarOffsetSel();
    setSelIds((ids) => (ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id]));
  };

  // Seleccionar/desseleccionar mensajes re-renderiza cabecera flotante y
  // burbujas y en Android el ScrollView puede perder el offset y saltar al
  // principio de todo el chat. Se guarda el offset actual y se restaura un
  // par de frames después del cambio de estado: si nada se movió, el
  // scrollTo es un no-op; si saltó, devuelve al usuario donde estaba.
  function restaurarOffsetSel() {
    const y = Math.max(0, offsetRef.current);
    requestAnimationFrame(() => requestAnimationFrame(() => {
      scrollRef.current?.scrollTo({ y, animated: false });
    }));
  }
  const limpiarSel = () => {
    if (selIds.length) restaurarOffsetSel();
    setSelIds([]);
  };

  // Reenviar varios (uno a uno, como WhatsApp con múltiples)
  const reenviarVarios = async (list) => {
    limpiarSel();
    try {
      const perfil = (await getCachedProfile(me.uid)) || {};
      const nuevos = [];
      for (const post of list) {
        const iso = new Date().toISOString();
        const ref = await addDoc(collection(db, 'posts'), {
          autorUid: me.uid,
          autorNombre: perfil.nombre || me.displayName || 'Alguien',
          texto: post.texto || '',
          media: (post.media || []).map((m) => ({ ...m })),
          reenviado: true,
          encuesta: null,
          preview: post.preview || null,
          reacciones: {},
          createdAt: iso,
        });
        // Push del reenvío (app cerrada): mismo camino que un mensaje nuevo.
        notificarPushMensaje(me, ref.id, post.texto || '', perfil.nombre || me.displayName || 'Alguien').catch(() => {});
        nuevos.push({
          id: ref.id, autorUid: me.uid, autorNombre: perfil.nombre || me.displayName || 'Alguien',
          texto: post.texto || '', media: (post.media || []).map((m) => ({ ...m })),
          reenviado: true, encuesta: null, preview: post.preview || null, reacciones: {}, createdAt: iso,
        });
      }
      await chatStorePut(nuevos);
      await chatStoreSetMeta({ lastSync: new Date().toISOString() });
      forzarFinalRef.current = true;   // reenvío propio: siempre al final
      setPosts(await chatStoreAll());
      alFinal(true);
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };

  // Eliminar varios = BORRADO LÓGICO estilo WhatsApp: el doc se queda en el
  // servidor marcado como eliminado (los demás reciben "modified" y ven
  // "Mensaje eliminado"). Un deleteDoc físico llegaría a los demás como
  // "removed", que es la señal de CADUCIDAD (TTL) y aquí se ignora a propósito
  // para no borrar las copias locales.
  const eliminarVarios = (list) => {
    limpiarSel();
    Alert.alert(L('Eliminar mensajes', 'Delete messages'), L(`¿Eliminar ${list.length} mensaje(s)?`, `Delete ${list.length} message(s)?`), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: async () => {
        const parche = { eliminado: true, texto: '', media: [], encuesta: null, preview: null, reacciones: {} };
        // URLs de R2 de la media (original + miniatura) de los mensajes
        const urls = [];
        for (const post of list) for (const m of (post.media || [])) {
          if (m && m.url) urls.push(m.url);
          if (m && m.thumbUrl) urls.push(m.thumbUrl);
        }
        // Con media, el borrado pasa por el SERVIDOR: marca eliminado Y borra
        // los objetos de R2 que ningún otro mensaje vivo referencie (los
        // reenvíos comparten URL y no se rompen).
        let hechoEnServidor = false;
        if (urls.length) {
          try {
            const apiUrl = (await getApiUrl()).replace(/\/+$/, '');
            const token = await me.getIdToken();
            const r = await fetch(`${apiUrl}/social/delete-message`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
              body: JSON.stringify({ postIds: list.map((p) => p.id) }),
            });
            const d = await r.json().catch(() => null);
            hechoEnServidor = !!(r.ok && d && d.ok);
          } catch (e) { hechoEnServidor = false; }
        }
        if (!hechoEnServidor) {
          // Respaldo (servidor sin desplegar o mensajes solo de texto):
          // borrado lógico directo, como siempre
          try { for (const post of list) await updateDoc(doc(db, 'posts', post.id), parche); } catch (e) {}
        }
        try {
          await chatStorePut(list.map((p) => ({ ...p, ...parche })));
          olvidarMediaLocal(urls);   // libera el disco local de la media borrada
          setPosts(await chatStoreAll());
        } catch (e) {}
      } },
    ]);
  };

  // Daño conocido: objeto multipart (empieza por '--boundary') o vacío,
  // producto del bug antiguo de subida. Lo 'desconocido' NO se bloquea.
  const isDamaged = async (uri) => {
    try {
      const b64 = await FileSystem.readAsync(uri, { encoding: FileSystem.EncodingType.Base64, position: 0, length: 12 });
      if (!b64 || b64.length === 0) return true;
      return b64.startsWith('LS0');   // '--' = boundary multipart = objeto corrupto
    } catch (e) {
      return false;   // si no se puede leer, no bloqueamos la apertura
    }
  };

  // Verifica el objeto YA subido a R2 (Range HTTP de 12 bytes). Si salió
  // multipart, reintenta con el uploadType contrario y recuerda el bueno.
  const remoteOk = async (publicUrl) => {
    try {
      const r = await fetch(publicUrl, { headers: { Range: 'bytes=0-11' } });
      const buf = await r.arrayBuffer();
      const b = new Uint8Array(buf);
      if (!b.length) return true;
      const multipart = b[0] === 0x2d && b[1] === 0x2d;   // '--'
      return !multipart;
    } catch (e) { return true; }
  };

  // Abrir visor estilo WhatsApp: lista de imágenes VÁLIDAS del chat + índice
  const openImage = async (url) => {
    const urls = [];
    posts.forEach((p) => (p.media || []).forEach((m) => { if (m.tipo === 'imagen' && m.url) urls.push(m.url); }));
    const valid = [];
    for (const u of urls) {
      try {
        const local = originalCache.get(cleanMediaUrl(u)) || (await cachedOriginal(u));
        if (!(await isDamaged(local))) valid.push(u);
      } catch (e) { valid.push(u); }
    }
    if (!valid.includes(url)) {
      Alert.alert(L('Imagen no disponible', 'Image unavailable'),
        L('Esta imagen se subió con una versión antigua de la app y está dañada; no puede mostrarse. Puedes eliminar el mensaje.',
          'This image was uploaded with an old app version and is corrupted; it cannot be displayed. You can delete the message.'));
      return;
    }
    setViewer({ index: valid.indexOf(url), urls: valid });
  };
  /* ══════════ MOTOR DE SINCRONIZACIÓN (patrón WhatsApp) ══════════
     1) El almacén local pinta el chat AL INSTANTE (sin red, sin volver a
        descargar lo que ya tienes en el dispositivo).
     2) Sincronización INCREMENTAL: solo los mensajes posteriores al último
        sincronizado (where createdAt > lastSync). Nunca todo el historial.
     3) Primera vez en un dispositivo: únicamente los 60 más recientes; el
        resto se pagina hacia atrás bajo demanda ("Cargar anteriores").
     4) Listener en vivo con docChanges(): added/modified se fusionan en el
        almacén; removed se IGNORA a propósito: la copia local se conserva
        (el servidor no purga; solo aplicaría ante borrados manuales). */
  /* Ventana "viva": los 120 mensajes más recientes se escuchan EN VIVO con
     un segundo listener (query con limit), porque el listener por marca de
     agua solo cubre mensajes NUEVOS (createdAt > lastSync): sin esto, un
     borrado/edición/reacción sobre un mensaje ya sincronizado no llegaba
     hasta el pull-to-refresh. 120 docs escuchados es barato (Firebase cobra
     por cambio, no por doc escuchado) y es la misma ventana que refresca
     onRefresh, así el comportamiento es idéntico pero AUTOMÁTICO. */
  const VENTANA_VIVO = 120;

  /* Re-lectura de la ventana reciente + fusión en el almacén local. La usan
     el listener en vivo (tras cada cambio), el foco de pantalla y el
     pull-to-refresh: una sola fuente de verdad para "qué hay ahora". */
  const refrescoVentana = useCallback(async () => {
    const snap = await getDocs(query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(VENTANA_VIVO)));
    await chatStorePut(snap.docs.map((d) => protegerVoto({ id: d.id, ...d.data() })));
    return snap.docs.length;
  }, []);

  const reloadFromStore = useCallback(async () => {
    const all = await chatStoreAll();
    setPosts(all);
    const meta = await chatStoreMeta();
    setHasMoreOld(!!meta.hasMore);
    return all;
  }, []);

  // gapSync (primera página de 60 + incremental where createdAt > lastSync)
  // vive en services/chatSync.js: aislado y verificado por
  // tests/chat-sync-test.js contra un Firestore simulado.

  // Paginación AUTOMÁTICA por zonas (patrón WhatsApp del documento duck.ai):
  // bloques de 50 más antiguos, disparados al rozar el borde superior del
  // scroll — sin botón de "descargar el chat". Mantiene la posición.
  const cargarAnteriores = useCallback(async () => {
    if (loadingOld) return;
    setLoadingOld(true);
    try {
      const { hasMore } = await loadOlderZone();
      setHasMoreOld(hasMore);
      pendingFix.current = { prevH: contentH.current, prevOff: offsetRef.current };
      setPosts(await chatStoreAll());
    } catch (e) {
      console.warn('[social] antiguos:', e.message);
    } finally {
      setLoadingOld(false);
    }
  }, [loadingOld]);

  /* Listener en vivo: solo mensajes NUEVOS o MODIFICADOS desde la marca de
     agua. docChanges() da added/modified/removed; removed se ignora: ya no
     hay purga por caducidad y la copia local permanece. */
  useEffect(() => {
    if (tab !== 'tablon') return undefined;
    let alive = true;
    let unsub = null;
    (async () => {
      try {
        await chatStoreInit();
        // La bandera de "primera carga" se levanta ANTES del primer setPosts
        // para que forzarFinalRef se consuma de forma determinista en el
        // primer onContentSizeChange (una bandera vieja arrastraría el
        // viewport más adelante). Al VOLVER de "Retos" primera=false: no se
        // fuerza nada y restaurarRef devuelve la posición guardada.
        const primera = primeraCargaRef.current;
        primeraCargaRef.current = false;
        if (primera) forzarFinalRef.current = true;
        await reloadFromStore();
        setLoading(false);
        alFinal(primera);   // 1ª apertura: al final; vuelta de "Retos": nada
        await gapSync();
        if (!alive) return;
        await reloadFromStore();
        alFinal();   // suave: solo sigue el final si el usuario ya estaba ahí
        const meta = await chatStoreMeta();
        const marca = meta.lastSync || new Date().toISOString();
        const q = query(collection(db, 'posts'), where('createdAt', '>', marca), orderBy('createdAt', 'asc'));
        unsub = onSnapshot(q, (snap) => {
          if (!alive) return;
          const up = [];
          const muertos = [];
          const changes = typeof snap.docChanges === 'function' ? snap.docChanges() : [];
          for (const ch of changes) {
            if (ch.type === 'removed') {
              // Borrado FÍSICO en el servidor (script de mantenimiento): se
              // purga también del local. Si el doc aún existe, es que solo
              // salió del rango de la query: la copia local se conserva.
              if (!ch.doc.exists()) muertos.push({ id: ch.doc.id, media: (ch.doc.data() || {}).media || [] });
              continue;
            }
            up.push(protegerVoto({ id: ch.doc.id, ...ch.doc.data() }));
          }
          if (!up.length && !muertos.length) return;
          (async () => {
            if (up.length) {
              await chatStorePut(up);
              const m = await chatStoreMeta();
              const maxC = up[up.length - 1].createdAt;
              if (maxC && maxC > (m.lastSync || '')) await chatStoreSetMeta({ lastSync: maxC });
            }
            if (muertos.length) {
              await chatStoreRemove(muertos.map((x) => x.id));
              olvidarMediaLocal(muertos.flatMap((x) => (x.media || []).flatMap((mm) => [mm.url, mm.thumbUrl]).filter(Boolean)));
            }
            setPosts(await chatStoreAll());
            alFinal();
          })();
        }, (err) => console.warn('[social] listener:', err.message));
      } catch (e) {
        console.warn('[social] sync:', e.message);
        setLoading(false);
      }
    })();
    return () => { alive = false; if (unsub) unsub(); };
  }, [tab, reloadFromStore]);

  /* LISTENER EN VIVO DE LA VENTANA RECIENTE — arregla el "borrado no se ve
     hasta recargar": el listener por marca de agua solo cubre mensajes
     NUEVOS (createdAt > lastSync), así que un borrado lógico (eliminado:true),
     una edición o una reacción sobre un mensaje YA sincronizado no llegaban
     nunca en vivo. Aquí se escuchan los VENTANA_VIVO más recientes (query con
     limit, sin marca de agua): cualquier modified/added dentro de la ventana
     entra al instante, sea el mensaje de cuando sea.
     · removed con doc.exists()===false → borrado físico real (purga del
       script Python): se purga del local y se libera su media del disco.
     · removed con exists()===true → solo cayó fuera de la ventana por un
       mensaje nuevo: la copia local se conserva (diseño local-first).
     · El primer snapshot del listen se salta (todo added): el almacén ya
       tiene esa ventana y así no se escribe ni se mueve el scroll en balde. */
  useEffect(() => {
    if (tab !== 'tablon') return undefined;
    let vivo = true;
    let primera = true;
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(VENTANA_VIVO));
    const u = onSnapshot(q, (snap) => {
      if (!vivo) return;
      if (primera) { primera = false; return; }
      const up = [];
      const muertos = [];
      const changes = typeof snap.docChanges === 'function' ? snap.docChanges() : [];
      for (const ch of changes) {
        if (ch.type === 'removed') {
          if (!ch.doc.exists()) muertos.push({ id: ch.doc.id, media: (ch.doc.data() || {}).media || [] });
          continue;
        }
        const nuevo = protegerVoto({ id: ch.doc.id, ...ch.doc.data() });
        up.push(nuevo);
        if (ch.type === 'added' && nuevo.autorUid && nuevo.autorUid !== me.uid && !notifiedMessagesRef.current.has(nuevo.id)) {
          notifiedMessagesRef.current.add(nuevo.id);
        }
      }
      if (!up.length && !muertos.length) return;
      (async () => {
        try {
          if (up.length) await chatStorePut(up);
          if (muertos.length) {
            await chatStoreRemove(muertos.map((x) => x.id));
            olvidarMediaLocal(muertos.flatMap((x) => (x.media || []).flatMap((mm) => [mm.url, mm.thumbUrl]).filter(Boolean)));
          }
          await reloadFromStore();
          alFinal();   // suave: solo si el usuario ya estaba al final
        } catch (e) { console.warn('[social] ventana vivo:', e.message); }
      })();
    }, (err) => console.warn('[social] listener ventana:', err.message));
    return () => { vivo = false; u(); };
  }, [tab, reloadFromStore]);

  /* Fotos de perfil (patrón WhatsApp): la caché se inicializa una vez y se
     sincroniza con debounce cuando cambian los autores visibles. No descarga
     nada si nada cambió: lee los docs ligeros avatares/<uid> (url) y solo
     baja el archivo cuando la URL es nueva. */
  useEffect(() => { avatarCacheInit(); }, []);
  useEffect(() => {
    if (tab !== 'tablon' || posts.length === 0) return undefined;
    const uids = [...new Set(posts.map((p) => p.autorUid).filter(Boolean))];
    const t = setTimeout(() => { sincronizarAvatares(uids, me.uid).catch(() => {}); }, 600);
    return () => clearTimeout(t);
  }, [posts, tab]);

  /* Encuestas EN VIVO (WhatsApp): el listener principal solo cubre mensajes
     nuevos (createdAt > lastSync), así que los votos en encuestas antiguas
     no llegaban. Aquí se suscribe por documento a las encuestas cargadas
     (máx. 12): cada voto de cualquier persona entra al instante. La clave
     del effect es la huella (id + si tiene encuesta), de modo que los votos
     recibidos NO re-suscriben (evita bucles). */
  useEffect(() => {
    if (tab !== 'tablon') return undefined;
    const conEnc = posts.filter((p) => p.encuesta && !p.eliminado).slice(-12);
    if (conEnc.length === 0) return undefined;
    let vivo = true;
    const unsubs = [];
    for (const pe of conEnc) {
      try {
        const u = onSnapshot(doc(db, 'posts', pe.id), (snap) => {
          if (!vivo || !snap.exists()) return;
          const nuevo = protegerVoto({ id: pe.id, ...snap.data() });
          chatStorePut(nuevo).catch(() => {});
          setPosts((ps) => ps.map((x) => (x.id === nuevo.id ? { ...x, ...nuevo } : x)));
        }, () => {});
        unsubs.push(u);
      } catch (e) {}
    }
    return () => { vivo = false; for (const u of unsubs) { try { u(); } catch (e) {} } };
  }, [posts.map((p) => `${p.id}:${p.encuesta ? 'e' : ''}`).join('|'), tab]);

  /* ── Retos ── */
  const loadRetos = useCallback(async () => {
    try {
      const miPerfil = (await getCachedProfile(me.uid)) || {};
      const linkedCoach = miPerfil.entrenador;
      const coach = typeof linkedCoach === 'string' ? linkedCoach : (linkedCoach?.uid || linkedCoach?.id || linkedCoach?.userId || null);
      const ids = [me.uid, coach].filter(Boolean);
      const [snapCreados, snapInvitado, snapCoach] = await Promise.all([
        getDocs(query(collection(db, 'retos'), where('creadorUid', 'in', ids))),
        getDocs(query(collection(db, 'retos'), where('invitados', 'array-contains', me.uid))),
        getDocs(query(collection(db, 'perfiles'), where('entrenador', '==', me.uid), limit(1))),
      ]);
      setSoyCoach(!snapCoach.empty);
      const porId = new Map();
      [...snapCreados.docs, ...snapInvitado.docs].forEach((d) => porId.set(d.id, { id: d.id, ...d.data() }));
      const ahora = new Date();
      const activos = [], pasados = [];
      for (const r of porId.values()) {
        const fin = r.fin?.toDate?.() || new Date(r.fin);
        const ini = r.inicio?.toDate?.() || new Date(r.inicio);
        let invitados = Array.isArray(r.invitados) ? r.invitados : null;
        if (!invitados) {
          const snapAt = await getDocs(query(collection(db, 'perfiles'), where('entrenador', '==', r.creadorUid)));
          invitados = snapAt.docs.map((d) => d.id);
        }
        // El creador PUEDE unirse a su propio reto: si está en aceptados, compite.
        const aceptados = Array.isArray(r.aceptados) ? r.aceptados : [];
        const nombres = {};
        await Promise.all(aceptados.map(async (uid) => {
          const p = (await getCachedProfile(uid)) || {};
          nombres[uid] = p.nombre || L('Atleta', 'Athlete');
        }));
        const partSet = new Set(aceptados);
        const acc = new Map();
        const fechasPorUsuario = new Map();
        // Pasos y sueño son datos DIARIOS del wellness (wellness/{uid}.days),
        // NO del entreno: se suman por fecha dentro del rango del reto para
        // cada participante. Antes se leían del doc de entreno (que no los
        // tiene) y el ranking salía a 0.
        if (r.metrica === 'pasos' || r.metrica === 'sueño') {
          await Promise.all(aceptados.map(async (uid) => {
            let total = 0;
            try {
              const s = await getDoc(doc(db, 'wellness', uid));
              const dias = s.exists() ? (s.data().days || {}) : {};
              const cursor = new Date(ini); const finDia = new Date(fin);
              cursor.setHours(0, 0, 0, 0); finDia.setHours(0, 0, 0, 0);
              const p2 = (n) => String(n).padStart(2, '0');
              while (cursor <= finDia) {
                const v = dias[`${cursor.getFullYear()}-${p2(cursor.getMonth() + 1)}-${p2(cursor.getDate())}`];
                if (v) total += r.metrica === 'pasos' ? (Number(v.steps) || 0) : (Number(v.sleep) || 0) / 3600;
                cursor.setDate(cursor.getDate() + 1);
              }
            } catch (e) {}
            acc.set(uid, total);
          }));
        } else {
          const snapAct = await getDocs(query(collection(db, 'entrenamientos'),
            where('fecha', '>=', Timestamp.fromDate(ini)), where('fecha', '<=', Timestamp.fromDate(fin))));
          snapAct.docs.forEach((a) => {
            const w = a.data();
            if (w.estado !== 'completo' || !partSet.has(w.userId)) return;
            if (r.metrica === 'racha') {
              const f = fechasPorUsuario.get(w.userId) || [];
              f.push(w.fecha || w.createdAt);
              fechasPorUsuario.set(w.userId, f);
            } else {
              acc.set(w.userId, (acc.get(w.userId) || 0) + valorDe(w, r.metrica));
            }
          });
        }
        const ranking = aceptados
          .map((uid) => ({ uid, nombre: nombres[uid] || '?', valor: r.metrica === 'racha' ? rachaDeEntrenos(fechasPorUsuario.get(uid)) : (acc.get(uid) || 0) }))
          .sort((a, b) => b.valor - a.valor);
        const item = { ...r, ini, fin, ranking, invitados, aceptado: aceptados.includes(me.uid), diasRestantes: Math.ceil((fin - ahora) / 86400000) };
        (fin >= ahora ? activos : pasados).push(item);
      }
      activos.sort((a, b) => a.fin - b.fin);
      pasados.sort((a, b) => b.fin - a.fin);
      setRetos({ activos, pasados });
    } catch (e) {
      console.warn('[social] retos:', e.message);
    } finally {
      setRetosLoading(false);
    }
  }, [me.uid]);

  useEffect(() => { loadRetos().catch(() => {}); }, []);
  /* REFRESCO AUTOMÁTICO AL ENTRAR/VOLVER: cada vez que la pantalla Social
     recupera el foco (volver de Home, Perfil, otra app…) se hace una
     sincronización silenciosa: gapSync (nuevos desde la marca de agua) +
     re-lectura de la ventana reciente (borrados, ediciones, reacciones que
     ocurrieron mientras no mirabas) + retos al día. Sin spinners: el chat
     sigue pintado desde el almacén local mientras tanto. Con throttle de
     8 s para que navegar rápido no multiplique lecturas; el primer foco
     (montaje) se salta porque el effect principal ya carga todo. */
  const ultimoFocoRef = useRef(Date.now());
  useFocusEffect(useCallback(() => {
    const ahora = Date.now();
    if (ahora - ultimoFocoRef.current < 8000) return;
    ultimoFocoRef.current = ahora;
    (async () => {
      try {
        await gapSync();
        await refrescoVentana();
        await reloadFromStore();
        await loadRetos();
      } catch (e) { console.warn('[social] refresco foco:', e.message); }
    })();
  }, [refrescoVentana, reloadFromStore, loadRetos]));

  const aceptarReto = async (r) => {
    try {
      await updateDoc(doc(db, 'retos', r.id), { aceptados: arrayUnion(me.uid) });
      setRetosLoading(true);
      loadRetos();
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    }
  };

  /* Cancelar un reto propio: SOLO el creador ve el botón y las reglas de
     Firestore solo dejan borrar al creador (resource.data.creadorUid).
     Se pide confirmación porque desaparece para todos los invitados. */
  const cancelarReto = (r) => {
    Alert.alert(
      L('Cancelar reto', 'Cancel challenge'),
      L(`Se eliminará "${r.titulo}" para todos los invitados y desaparecerá del ranking. Esta acción no se puede deshacer.`,
        `"${r.titulo}" will be deleted for every invite and removed from the ranking. This cannot be undone.`),
      [
        { text: L('No', 'No'), style: 'cancel' },
        {
          text: L('Sí, cancelar el reto', 'Yes, cancel it'), style: 'destructive',
          onPress: async () => {
            try {
              await deleteDoc(doc(db, 'retos', r.id));
              setRetos((prev) => ({ activos: prev.activos.filter((x) => x.id !== r.id), pasados: prev.pasados.filter((x) => x.id !== r.id) }));
              setRetosLoading(true);
              loadRetos();
            } catch (e) {
              Alert.alert(L('Error', 'Error'), e.message);
            }
          },
        },
      ]);
  };

  /* ── Reacciones: una por persona ── */
  const reaccionar = async (post, emoji) => {
    if (!emoji) return;
    const r = {};
    const emojis = [...new Set([...REACCIONES_TODAS, ...Object.keys(post.reacciones || {})])];
    for (const e of emojis) {
      const arr = (post.reacciones || {})[e] || [];
      if (e === emoji) r[e] = arr.includes(me.uid) ? arr.filter((u) => u !== me.uid) : [...arr, me.uid];
      else r[e] = arr.filter((u) => u !== me.uid);
    }
    const nuevo = { ...post, reacciones: r };
    setPosts((ps) => ps.map((p) => (p.id === post.id ? nuevo : p)));
    limpiarSel();
    setReactionPicker(false);
    const usage = { ...reactionUsage, [emoji]: (reactionUsage[emoji] || 0) + 1 };
    setReactionUsage(usage);
    AsyncStorage.setItem(`social-reactions:${me.uid}`, JSON.stringify(usage)).catch(() => {});
    chatStorePut(nuevo).catch(() => {});   // persiste la reacción en el local
    try {
      const updates = {};
      for (const e of emojis) updates[`reacciones.${e}`] = r[e];
      await updateDoc(doc(db, 'posts', post.id), updates);
    } catch (e) {}
  };

  /* Voto de encuesta (patrón WhatsApp): optimista EN PANTALLA al instante
     (antes el voto no se reflejaba hasta refrescar), persistido en el
     almacén local y en Firestore. El listener en vivo de encuestas (más
     abajo) devuelve los votos de los demás aunque la encuesta sea antigua. */
  const votarEncuesta = useCallback((post, idxOpcion) => {
    if (!post || !post.encuesta) return;
    votosRecientes.set(post.id, { idx: idxOpcion, ts: Date.now() });
    const votos = { ...(post.encuesta.votos || {}), [me.uid]: idxOpcion };
    const nuevo = { ...post, encuesta: { ...post.encuesta, votos } };
    setPosts((ps) => ps.map((x) => (x.id === post.id ? nuevo : x)));
    chatStorePut(nuevo).catch(() => {});
    updateDoc(doc(db, 'posts', post.id), { [`encuesta.votos.${me.uid}`]: idxOpcion })
      .catch((e) => console.warn('[social] voto:', e.message));
  }, [me.uid]);

  /* Fusiona un doc recibido del servidor protegiendo el voto propio recién
     hecho: los ecos iniciales de los listeners pueden llegar con el estado
     anterior al updateDoc y harían parpadear la encuesta hacia atrás. */
  const protegerVoto = (d) => {
    try {
      const rec = votosRecientes.get(d.id);
      if (rec && d.encuesta && Date.now() - rec.ts < 5000) {
        d.encuesta = { ...d.encuesta, votos: { ...(d.encuesta.votos || {}), [me.uid]: rec.idx } };
      } else if (rec && Date.now() - rec.ts >= 5000) {
        votosRecientes.delete(d.id);
      }
    } catch (e) {}
    return d;
  };

  const responder = (post) => {
    // Se guarda también el id: tocar la cita salta al mensaje original
    setReplyTo({ id: post.id, nombre: post.autorNombre, texto: post.texto || (post.media?.length ? '📎 ' + L('adjunto', 'attachment') : post.encuesta ? '📊 ' + L('encuesta', 'poll') : '') });
    limpiarSel();
  };

  /* Saltar al mensaje citado (WhatsApp): si el original está cargado hace
     scroll hasta él y lo destella 1.6 s; si no existe (cita antigua sin id
     o mensaje de una zona aún no cargada) NO hace nada. */
  const irAMensaje = useCallback((id) => {
    if (!id) return;
    if (!posts.some((x) => x.id === id)) return;
    const m = posRef.current.get(id);
    if (m) scrollRef.current?.scrollTo({ y: Math.max(0, m.y - insets.top - 70), animated: true });
    setHighlightId(id);
    if (hlTimer.current) clearTimeout(hlTimer.current);
    hlTimer.current = setTimeout(() => setHighlightId(null), 1600);
  }, [posts, insets.top]);

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      await gapSync();
      // Refresca la ventana reciente (reacciones, encuestas, eliminados)
      // sin descargar todo el historial: solo los VENTANA_VIVO últimos docs.
      await refrescoVentana();
      const all = await reloadFromStore();
      await loadRetos();
      // Refresco forzado de fotos de perfil (solo descarga las que cambiaron)
      sincronizarAvatares([...new Set(all.map((x) => x.autorUid).filter(Boolean))], me.uid, { force: true }).catch(() => {});
    } catch (e) { console.warn('[social] refresh:', e.message); }
    setRefreshing(false);
  };

  const c = {
    bg: theme.background, card: theme.card, border: theme.border,
    txt: theme.text, mut: theme.muted, acc: '#4A90E2',
    isLight,
    // Paleta estilo WhatsApp (modo noche / modo día)
    chatBg: isLight ? '#EFEAE2' : '#0B141A',
    bar: isLight ? '#008069' : '#1F2C34',
    barTxt: isLight ? '#FFFFFF' : '#E9EDEF',
    barMut: isLight ? '#FFFFFFB3' : '#8696A0',
    tabAct: isLight ? '#FFFFFF' : '#00A884',
    input: isLight ? '#FFFFFF' : '#1F2C34',
    send: '#00A884',
    bubbleOwn: isLight ? '#D9FDD3' : '#005C4B',
    bubbleOther: isLight ? '#FFFFFF' : '#202C33',
    txtBubble: isLight ? '#111B21' : '#E9EDEF',
    // Retos / Tiempo: fondo de lista y tarjetas con la paleta del chat
    listBg: isLight ? '#F0F2F5' : '#111B21',
    cardWA: isLight ? '#FFFFFF' : '#1F2C34',
  };
  const selPosts = selIds.map((id) => posts.find((p) => p.id === id)).filter(Boolean);
  const sel = selPosts.length === 1 ? selPosts[0] : null;
  const allMine = selPosts.length > 0 && selPosts.every((p) => p.autorUid === me.uid);
  // Alto de la barra flotante: con mensajes seleccionados aparece la barra
  // contextual (56) sobre las pestañas; sin selección, solo las pestañas.
  const BAR_H = insets.top + (selPosts.length > 0 ? 100 : 44);
  const copiarMensajes = async (list) => {
    const texto = list.map((p) => p.texto || (p.media?.length ? '📎 adjunto' : '')).filter(Boolean).join('\n');
    if (!texto) return;
    await Clipboard.setStringAsync(texto);
    Alert.alert(L('Copiado', 'Copied'), L('Texto copiado', 'Message text copied'));
    limpiarSel();
  };

  return (
    <SocialErrorBoundary>
    <View style={{ flex: 1, backgroundColor: tab === 'tablon' ? c.chatBg : c.listBg }}>
      {bgUri ? (
        /* Fondo TAL CUAL se subió: sin velo blanco ni tinte encima */
        <Image source={{ uri: bgUri }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} resizeMode="cover" />
      ) : null}
      {/* Barra superior estilo WhatsApp: avatar de grupo + título, y debajo las
          pestañas con indicador deslizante. En modo selección, la barra se
          convierte en la barra contextual (cerrar, nº seleccionados, acciones). */}
      <View style={{ position: 'absolute', top: 0, left: 0, right: 0, zIndex: 5, backgroundColor: c.bar, paddingTop: insets.top, elevation: 4, shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 4, shadowOffset: { width: 0, height: 2 } }}>
        {selPosts.length > 0 && (
        <View style={{ height: 56, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, gap: 12 }}>
          <>
              <TouchableOpacity onPress={limpiarSel} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}><Ionicons name="close" size={26} color={c.barTxt} /></TouchableOpacity>
              <Text style={{ color: c.barTxt, fontWeight: '700', flex: 1, fontSize: 19 }}>{selIds.length}</Text>
              {selIds.length === 1 && (
                <TouchableOpacity onPress={() => responder(sel)} hitSlop={{ top: 10, bottom: 10, left: 6, right: 6 }}><Ionicons name="arrow-undo" size={23} color={c.barTxt} /></TouchableOpacity>
              )}
              <TouchableOpacity onPress={() => copiarMensajes(selPosts)} hitSlop={{ top: 10, bottom: 10, left: 6, right: 6 }}><Ionicons name="copy-outline" size={22} color={c.barTxt} /></TouchableOpacity>
              <TouchableOpacity onPress={() => reenviarVarios(selPosts)} hitSlop={{ top: 10, bottom: 10, left: 6, right: 6 }}><Ionicons name="arrow-redo" size={23} color={c.barTxt} /></TouchableOpacity>
              {allMine && (
                <TouchableOpacity onPress={() => eliminarVarios(selPosts)} hitSlop={{ top: 10, bottom: 10, left: 6, right: 6 }}><Ionicons name="trash-outline" size={23} color={c.isLight ? '#FFD6D6' : '#F15C6D'} /></TouchableOpacity>
              )}
            </>
        </View>
        )}
        <TabsBarWA tab={tab} setTab={setTab} c={c} L={L} />
      </View>

      {tab === 'tablon' ? (
        <View ref={branchRef} style={{ flex: 1 }}>
          <ScrollView
            ref={scrollRef}
            style={{ flex: 1 }}
            // La isla es flotante: solo reservamos su altura real aproximada,
            // no un hueco de 138 px que dejaba el último mensaje a media pantalla.
            contentContainerStyle={{ paddingTop: BAR_H + 8, paddingBottom: 78 + insets.bottom, paddingHorizontal: 10 }}
            onScroll={(e) => {
              const ev = e.nativeEvent;
              offsetRef.current = ev.contentOffset.y;
              // Remontaje en curso (se vuelve de "Retos"): no se evalúa nada
              // hasta que onContentSizeChange restaure la posición guardada.
              if (restaurarRef.current) return;
              // "Estar al final" con tolerancia de ~70 px (criterio WhatsApp):
              // solo en ese caso los mensajes nuevos arrastran el viewport.
              const dist = ev.contentSize.height - ev.layoutMeasurement.height - ev.contentOffset.y;
              enElFinalRef.current = dist <= 70;
              if (enElFinalRef.current && nuevosSinVer !== 0) setNuevosSinVer(0);
              // FAB ↓: visible si NO se está al final y el chat desborda la pantalla
              const fab = !enElFinalRef.current && ev.contentSize.height > ev.layoutMeasurement.height + 120;
              if (fab !== mostrarIrAbajoRef.current) { mostrarIrAbajoRef.current = fab; setMostrarIrAbajo(fab); }
              // Zonas automáticas estilo WhatsApp: al rozar el borde superior
              // se carga el siguiente bloque de 50 (sin ningún botón).
              if (offsetRef.current < 220 && hasMoreOld && !loadingOld) cargarAnteriores();
            }}
            scrollEventThrottle={16}
            onContentSizeChange={(w, h) => {
              contentH.current = h;
              // Al PREPENDER historial antiguo mantiene el viewport en el
              // mismo mensaje (el contenido crece por arriba).
              const fix = pendingFix.current;
              if (fix) {
                pendingFix.current = null;
                prevCountRef.current = posts.length;
                scrollRef.current?.scrollTo({ y: Math.max(0, h - fix.prevH + fix.prevOff), animated: false });
                return;
              }
              // Al VOLVER de la pestaña "Retos": restaura la posición guardada
              // en cuanto el layout ha reproducido el alto que tenía al salir.
              // Mientras se remonta NUNCA se hace scrollToEnd (era el salto).
              const rest = restaurarRef.current;
              if (rest) {
                if (h >= rest.h * 0.98) {
                  restaurarRef.current = null;
                  prevCountRef.current = posts.length;
                  scrollRef.current?.scrollTo({ y: rest.y, animated: false });
                }
                return;
              }
              // Solo se "sigue el chat" cuando AUMENTAN los mensajes. Un
              // cambio de altura por votar una encuesta, reaccionar,
              // seleccionar un mensaje o cargarse una imagen YA NO mueve el
              // viewport (ese era el salto molesto al último mensaje).
              const nuevos = posts.length - prevCountRef.current;
              prevCountRef.current = posts.length;
              if (nuevos <= 0) return;
              if (forzarFinalRef.current || enElFinalRef.current) {
                // Mensaje propio / primera apertura, o ya se estaba abajo:
                // se sigue la conversación hasta el final.
                forzarFinalRef.current = false;
                scrollRef.current?.scrollToEnd({ animated: false });
              } else {
                // Leyendo historial: no se interrumpe; los no vistos se
                // acumulan en la insignia del FAB ↓.
                setNuevosSinVer((n) => n + nuevos);
              }
            }}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={c.mut} />}
          >
            {posts.length > 0 && (
              hasMoreOld ? (
                loadingOld ? (
                  <View style={{ alignSelf: 'center', marginVertical: 8 }}>
                    <ActivityIndicator size="small" color={c.acc} />
                  </View>
                ) : null
              ) : (
                <Text style={{ color: c.mut, fontSize: 10, textAlign: 'center', marginBottom: 8 }}>
                  {L('Inicio del historial · este es el primer mensaje del chat', 'Start of history · this is the first message of the chat')}
                </Text>
              )
            )}
            {loading && posts.length === 0 ? (
              <ActivityIndicator style={{ marginTop: 40 }} color={c.acc} />
            ) : posts.length === 0 ? (
              <View style={{ alignItems: 'center', marginTop: 60, gap: 8 }}>
                <Ionicons name="megaphone-outline" size={40} color={c.mut} />
                <Text style={{ color: c.mut }}>{L('Aún no hay mensajes. ¡Estrena el tablón!', 'No messages yet. Be the first!')}</Text>
              </View>
            ) : posts.map((p, i) => {
              // Separador de fecha estilo WhatsApp entre mensajes de días
              // distintos: HOY / AYER / nombre del día / fecha con mes y año.
              const prev = posts[i - 1];
              const next = posts[i + 1];
              const nuevoDia = !prev || claveDia(prev.createdAt) !== claveDia(p.createdAt);
              // Agrupación estilo WhatsApp: mensajes seguidos de la misma persona
              // forman un bloque (nombre y "cola" solo en el primero, avatar en el último).
              const primeroGrupo = nuevoDia || prev.autorUid !== p.autorUid;
              const ultimoGrupo = !next || next.autorUid !== p.autorUid || claveDia(next.createdAt) !== claveDia(p.createdAt);
              return (
                <React.Fragment key={p.id}>
                  {nuevoDia && (
                    <View style={{ alignItems: 'center', marginVertical: 9 }}>
                      <View style={{ backgroundColor: bgUri ? 'rgba(0,0,0,0.42)' : (isLight ? '#FFFFFFE6' : '#182229'), borderRadius: 9, paddingHorizontal: 12, paddingVertical: 5, maxWidth: '85%', elevation: bgUri || !isLight ? 0 : 1 }}>
                        <Text style={{ color: bgUri ? '#FFFFFFF2' : (isLight ? '#54656F' : '#8696A0'), fontSize: 12, fontWeight: '600', letterSpacing: 0.3 }}>{fmtSeparador(p.createdAt, loc, L)}</Text>
                      </View>
                    </View>
                  )}
                  <View onLayout={(ev) => { posRef.current.set(p.id, { y: ev.nativeEvent.layout.y }); }}>
                    <SocialErrorBoundary>
                      <Burbuja p={p} me={me.uid} c={c} loc={loc} isLight={isLight}
                        primero={primeroGrupo} ultimo={ultimoGrupo}
                        selected={selIds.includes(p.id)} highlighted={highlightId === p.id}
                        onTapReply={irAMensaje} onVote={votarEncuesta}
                        onLongPress={() => toggleSel(p.id)} onOpenImage={openImage} />
                    </SocialErrorBoundary>
                  </View>
                </React.Fragment>
              );
            })}
          </ScrollView>

          {/* Columna flotante: barra de reacciones + isla, encima del chat */}
          <View style={{ position: 'absolute', left: 0.25, right: 0.25, bottom: islandBottom }}>
            {selPosts.length === 1 && (
              <View style={{ marginBottom: 6, borderRadius: 999, backgroundColor: c.bubbleOther, borderWidth: 1, borderColor: c.border, flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center', paddingVertical: 6, paddingHorizontal: 4 }}>
                {reaccionesVisibles.map((e) => (
                  <Pressable key={e} onPress={() => reaccionar(sel, e)} style={{ paddingHorizontal: 7, paddingVertical: 3 }}>
                    <Text style={{ fontSize: 22 }}>{e}</Text>
                  </Pressable>
                ))}
                <Pressable onPress={() => setReactionPicker(true)} style={{ width: 30, height: 30, borderRadius: 15, backgroundColor: c.acc + '22', alignItems: 'center', justifyContent: 'center' }}>
                  <Ionicons name="add" size={21} color={c.acc} />
                </Pressable>
              </View>
            )}
            {mostrarIrAbajo && (
              <View pointerEvents="box-none" style={{ flexDirection: 'row', justifyContent: 'flex-end', paddingRight: 6, marginBottom: 8 }}>
                {/* FAB ↓ estilo WhatsApp: círculo con el MISMO aspecto que las
                    fichas de fecha del chat (negro translúcido + blanco) e
                    insignia con los mensajes no vistos mientras se lee arriba */}
                <Pressable
                  onPress={irAlFinal}
                  style={({ pressed }) => ({
                    width: 42, height: 42, borderRadius: 21,
                    backgroundColor: pressed ? (isLight ? '#F0F2F5' : '#2A3942') : c.input,
                    alignItems: 'center', justifyContent: 'center',
                    borderWidth: 0,
                    elevation: 3, shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 3, shadowOffset: { width: 0, height: 1 },
                  })}
                >
                  <Ionicons name="chevron-down" size={24} color={c.mut} />
                  {nuevosSinVer > 0 && (
                    <View style={{ position: 'absolute', top: -7, right: -7, minWidth: 20, height: 20, paddingHorizontal: 5, borderRadius: 10, backgroundColor: c.send, alignItems: 'center', justifyContent: 'center' }}>
                      <Text style={{ color: '#FFFFFF', fontSize: 11, fontWeight: '800' }}>{nuevosSinVer > 99 ? '99+' : nuevosSinVer}</Text>
                    </View>
                  )}
                </Pressable>
              </View>
            )}
            <ComposerIsland c={c} L={L} replyTo={replyTo} onCancelReply={() => setReplyTo(null)}
              onPublicado={() => { forzarFinalRef.current = true; reloadFromStore().then(() => alFinal(true)); }} />
          </View>
        </View>
      ) : tab === 'retos' ? (
        <View style={{ flex: 1, backgroundColor: c.listBg }}>
          <ScrollView contentContainerStyle={{ paddingTop: BAR_H + 8, paddingBottom: soyCoach ? 110 : 24 }} showsVerticalScrollIndicator={false} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={c.mut} progressViewOffset={BAR_H} />}>
            {retosLoading ? <ActivityIndicator style={{ marginTop: 40 }} color={c.send} /> : (
              <>
                <ResumenRetos activos={retos.activos} pasados={retos.pasados} c={c} L={L} />
                <SeccionRetos titulo={L('RETOS ACTIVOS', 'ACTIVE CHALLENGES')} n={retos.activos.length} c={c} />
                {retos.activos.length === 0 && (
                  <FadeInWA>
                    <View style={{ alignItems: 'center', marginVertical: 26, gap: 10 }}>
                      <TrofeoFlotante size={44} color={c.mut} />
                      <Text style={{ color: c.mut }}>{L('No hay retos activos ahora mismo.', 'No active challenges right now.')}</Text>
                    </View>
                  </FadeInWA>
                )}
                {retos.activos.map((r, i) => (
                  <RetoCard key={r.id} r={r} activo c={c} loc={loc} L={L} meUid={me.uid} delay={Math.min(i * 80, 480)} onAceptar={() => aceptarReto(r)} onCancelar={() => cancelarReto(r)} />
                ))}
                <SeccionRetos titulo={L('HISTORIAL', 'HISTORY')} n={retos.pasados.length} c={c} />
                {retos.pasados.length === 0 && (
                  <Text style={{ color: c.mut, marginHorizontal: 16 }}>{L('Todavía no hay retos terminados.', 'No finished challenges yet.')}</Text>
                )}
                {retos.pasados.map((r, i) => (
                  <RetoCard key={r.id} r={r} c={c} loc={loc} L={L} meUid={me.uid} delay={Math.min(i * 80, 480)} />
                ))}
              </>
            )}
          </ScrollView>
          {/* Botón redondo "+" abajo a la derecha (como en el calendario): crear reto */}
          {soyCoach && (
            <View pointerEvents="box-none" style={{ position: 'absolute', right: 16, bottom: insets.bottom + 18 }}>
              <PressWA onPress={() => setCreaRetoOpen(true)} style={{ width: 56, height: 56, borderRadius: 28, backgroundColor: c.send, alignItems: 'center', justifyContent: 'center', elevation: 5, shadowColor: '#000', shadowOpacity: 0.3, shadowRadius: 4, shadowOffset: { width: 0, height: 2 } }}>
                <Ionicons name="add" size={30} color="#fff" />
              </PressWA>
            </View>
          )}
        </View>
      ) : (
        <WeatherPanel topPad={BAR_H} />
      )}

      {viewer && (
        <FocalViewer urls={viewer.urls} initialIndex={viewer.index} onClose={() => setViewer(null)} />
      )}
      {creaRetoOpen && (
        <CreaReto
          onClose={() => setCreaRetoOpen(false)}
          c={c} L={L}
          onCreado={() => { setCreaRetoOpen(false); setRetosLoading(true); loadRetos(); }}
        />
      )}
      <Modal visible={reactionPicker && !!sel} transparent animationType="fade" onRequestClose={() => setReactionPicker(false)}>
        <Pressable onPress={() => setReactionPicker(false)} style={{ flex: 1, backgroundColor: '#00000088', justifyContent: 'flex-end' }}>
          <Pressable onPress={() => {}} style={{ backgroundColor: c.card, borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 16, paddingBottom: Math.max(insets.bottom, 12) + 16 }}>
            <Text style={{ color: c.txt, fontWeight: '800', fontSize: 16, marginBottom: 12 }}>{L('Elegir reacción', 'Choose reaction')}</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {REACCIONES_TODAS.map((e, i) => (
                <Pressable key={`${e}-${i}`} onPress={() => reaccionar(sel, e)} style={{ width: 42, height: 42, alignItems: 'center', justifyContent: 'center', borderRadius: 21, backgroundColor: c.bg }}>
                  <Text style={{ fontSize: 25 }}>{e}</Text>
                </Pressable>
              ))}
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
    </SocialErrorBoundary>
  );
}

/* ══════════════ AYUDAS VISUALES PARA RETOS (estilo WhatsApp) ══════════════ */
// Aparece con fundido + deslizamiento (entrada escalonada)
function FadeInWA({ delay = 0, children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, { toValue: 1, duration: 420, delay, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [v, delay]);
  return (
    <Animated.View style={[style, { opacity: v, transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) }] }]}>
      {children}
    </Animated.View>
  );
}

// Zona pulsable con efecto muelle
function PressWA({ onPress, disabled, style, children, hitSlop }) {
  const sc = useRef(new Animated.Value(1)).current;
  const to = (v) => Animated.spring(sc, { toValue: v, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <Pressable onPress={onPress} disabled={disabled} hitSlop={hitSlop} onPressIn={() => to(0.96)} onPressOut={() => to(1)}>
      <Animated.View style={[style, { transform: [{ scale: sc }] }]}>{children}</Animated.View>
    </Pressable>
  );
}

// Trofeo que flota suavemente
function TrofeoFlotante({ size = 40, color }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(v, { toValue: 1, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [v]);
  return (
    <Animated.View style={{ transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [3, -3] }) }] }}>
      <Ionicons name="trophy" size={size} color={color} />
    </Animated.View>
  );
}

// Número que "cuenta" hasta su valor
function CuentaHasta({ value, style }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    const a = new Animated.Value(0);
    const id = a.addListener(({ value: v }) => setN(Math.round(v)));
    Animated.timing(a, { toValue: value, duration: 700, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
    return () => { a.removeListener(id); a.stopAnimation(); };
  }, [value]);
  return <Text style={style}>{n}</Text>;
}

// Barra de progreso del tiempo transcurrido del reto (se llena al aparecer)
function ProgresoReto({ pct, color, track }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, { toValue: pct, duration: 900, delay: 200, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
  }, [v, pct]);
  return (
    <View style={{ height: 5, borderRadius: 3, backgroundColor: track, overflow: 'hidden' }}>
      <Animated.View style={{ height: 5, borderRadius: 3, backgroundColor: color, width: v.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }) }} />
    </View>
  );
}

// Banner de resumen de la pestaña Retos
function ResumenRetos({ activos, pasados, c, L }) {
  const aceptados = activos.filter((r) => r.aceptado).length;
  const stat = (n, label, color) => (
    <View style={{ flex: 1, alignItems: 'center', paddingVertical: 9, borderRadius: 14, backgroundColor: color + '18' }}>
      <CuentaHasta value={n} style={{ color, fontSize: 22, fontWeight: '800' }} />
      <Text style={{ color: c.mut, fontSize: 11, fontWeight: '700' }} numberOfLines={1}>{label}</Text>
    </View>
  );
  return (
    <FadeInWA>
      <View style={{ marginHorizontal: 12, marginBottom: 6, padding: 14, borderRadius: 18, backgroundColor: c.cardWA, borderWidth: c.isLight ? 0 : 1, borderColor: c.border, elevation: c.isLight ? 1 : 0, shadowColor: '#000', shadowOpacity: c.isLight ? 0.1 : 0, shadowRadius: 2, shadowOffset: { width: 0, height: 1 } }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 }}>
          <View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: '#F5A62326', borderWidth: 1.5, borderColor: '#F5A62366', alignItems: 'center', justifyContent: 'center' }}>
            <TrofeoFlotante size={26} color="#F5A623" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: c.txt, fontSize: 17, fontWeight: '800' }}>{L('Retos del equipo', 'Team challenges')}</Text>
            <Text style={{ color: c.mut, fontSize: 12 }}>{L('Compite, acepta retos y sube en la clasificación', 'Compete, accept challenges and climb the ranking')}</Text>
          </View>
        </View>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          {stat(activos.length, L('Activos', 'Active'), '#F5A623')}
          {stat(aceptados, L('Aceptados', 'Accepted'), c.send)}
          {stat(pasados.length, L('Terminados', 'Finished'), c.mut)}
        </View>
      </View>
    </FadeInWA>
  );
}

// Título de sección (verde, mayúsculas, como en WhatsApp)
function SeccionRetos({ titulo, n, c }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginHorizontal: 16, marginTop: 16, marginBottom: 8 }}>
      <Text style={{ color: c.send, fontWeight: '800', fontSize: 12, letterSpacing: 0.8 }}>{titulo}</Text>
      {n != null && (
        <View style={{ paddingHorizontal: 8, paddingVertical: 1, borderRadius: 999, backgroundColor: c.send + '22' }}>
          <Text style={{ color: c.send, fontWeight: '800', fontSize: 11 }}>{n}</Text>
        </View>
      )}
      <View style={{ flex: 1, height: 1, backgroundColor: c.border }} />
    </View>
  );
}

// Fila de clasificación estilo "lista de chats": puesto · avatar · nombre · valor
function FilaRanking({ row, pos, valor, meUid, c, L, lider }) {
  const avatar = useAvatar(row.uid);
  const yo = row.uid === meUid;
  const ini = (row.nombre || '?').trim().charAt(0).toUpperCase() || '?';
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 11, paddingHorizontal: 10, paddingVertical: 8, borderRadius: 12, backgroundColor: yo ? c.send + '1A' : 'transparent' }}>
      <View style={{ width: 24, alignItems: 'center' }}>
        {pos <= 3
          ? <Text style={{ fontSize: 17 }}>{pos === 1 ? '🥇' : pos === 2 ? '🥈' : '🥉'}</Text>
          : <Text style={{ color: c.mut, fontWeight: '800' }}>{pos}</Text>}
      </View>
      {avatar ? (
        <Image source={{ uri: avatar }} style={{ width: 38, height: 38, borderRadius: 19 }} />
      ) : (
        <View style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: colorDe(row.uid) + '33', alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: colorDe(row.uid), fontWeight: '800' }}>{ini}</Text>
        </View>
      )}
      <View style={{ flex: 1 }}>
        <Text style={{ color: c.txt, fontWeight: '700' }} numberOfLines={1}>{row.nombre}</Text>
        {yo && <Text style={{ color: c.send, fontSize: 11, fontWeight: '700' }}>{L('tú', 'you')}</Text>}
      </View>
      <Text style={{ color: lider ? '#F5A623' : c.txt, fontWeight: '800', fontSize: 15 }}>{valor}</Text>
    </View>
  );
}

/* ══════════════ PESTAÑAS estilo WhatsApp (indicador deslizante) ══════════════ */
function TabsBarWA({ tab, setTab, c, L }) {
  const items = [
    ['tablon', L('Tablón', 'Feed'), 'megaphone-outline'],
    ['retos', L('Retos', 'Challenges'), 'trophy-outline'],
    ['tiempo', L('Tiempo', 'Weather'), 'partly-sunny-outline'],
  ];
  const [w, setW] = useState(0);
  const x = useRef(new Animated.Value(0)).current;
  const idx = Math.max(0, items.findIndex((i) => i[0] === tab));
  useEffect(() => {
    if (w > 0) Animated.spring(x, { toValue: idx * (w / 3), useNativeDriver: true, speed: 18, bounciness: 6 }).start();
  }, [idx, w]);
  return (
    <View style={{ flexDirection: 'row', height: 44 }} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      {items.map(([id, label, icon]) => {
        const on = tab === id;
        return (
          <Pressable key={id} onPress={() => setTab(id)} android_ripple={{ color: '#FFFFFF22' }}
            style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            <Ionicons name={icon} size={16} color={on ? c.tabAct : c.barMut} />
            <Text style={{ color: on ? c.tabAct : c.barMut, fontWeight: '800', fontSize: 13, letterSpacing: 0.4 }}>{label.toUpperCase()}</Text>
          </Pressable>
        );
      })}
      {w > 0 && (
        <Animated.View pointerEvents="none" style={{ position: 'absolute', bottom: 0, left: 0, width: w / 3, height: 3, backgroundColor: c.tabAct, transform: [{ translateX: x }] }} />
      )}
    </View>
  );
}

/* ══════════════ BURBUJA estilo WhatsApp ══════════════
   · Mensajes seguidos de la misma persona se agrupan: nombre y "cola" solo en
     el primero, avatar solo en el último (el resto reserva el hueco).
   · Cola triangular en el primer mensaje del bloque, esquinas de 10 px.
   · Hora abajo a la derecha y, en los propios, el tic de "enviado".
   · Seleccionar tiñe toda la fila de verde translúcido (sin marco). */
function Burbuja({ p, me, c, loc, isLight, onLongPress, onOpenImage, selected, highlighted, onTapReply, onVote, primero = true, ultimo = true }) {
  const mio = p.autorUid === me;
  const radio = 10;
  const esquina = mio ? { borderTopRightRadius: primero ? 0 : radio } : { borderTopLeftRadius: primero ? 0 : radio };
  const margenSup = primero ? 6 : 1.5;
  const huecoAvatar = <View style={{ width: 39 }} />;
  // Borrado lógico estilo WhatsApp: el doc sigue existiendo pero vaciado
  if (p.eliminado) {
    return (
      <View style={{ flexDirection: 'row', marginTop: margenSup, marginBottom: 1.5, justifyContent: mio ? 'flex-end' : 'flex-start' }}>
        {!mio && (ultimo ? <AvatarChat uid={p.autorUid} nombre={p.autorNombre} dim /> : huecoAvatar)}
        <View style={{ maxWidth: '78%', borderRadius: radio, ...esquina, backgroundColor: isLight ? '#0000000A' : '#FFFFFF0D', borderWidth: isLight ? 1 : 0, borderColor: c.border, paddingHorizontal: 10, paddingVertical: 7 }}>
          <Text style={{ color: c.mut, fontSize: 13, fontStyle: 'italic' }}>🚫 {mio ? 'Mensaje eliminado' : 'Mensaje eliminado'}</Text>
          <View style={{ flexDirection: 'row', alignItems: 'flex-end', marginTop: 2 }}>
            <View style={{ flex: 1 }} />
            <Text style={{ color: isLight ? '#00000066' : '#FFFFFF77', fontSize: 11 }}>{fmtHora(p.createdAt, loc)}</Text>
          </View>
        </View>
      </View>
    );
  }
  const reacs = Object.entries(p.reacciones || {}).filter(([, arr]) => arr && arr.length > 0);
  const colorBurbuja = mio ? c.bubbleOwn : c.bubbleOther;
  const ancho = p.encuesta || (p.media || []).some(esAudioMedia) ? '94%' : '78%';
  const tinteMeta = isLight ? '#00000066' : '#FFFFFF77';
  return (
    <View style={{ flexDirection: 'row', alignSelf: 'stretch', marginTop: margenSup, marginBottom: 1.5, paddingVertical: selected ? 3 : 0, backgroundColor: selected ? '#00A88430' : 'transparent', justifyContent: mio ? 'flex-end' : 'flex-start' }}>
      {!mio && (ultimo ? <AvatarChat uid={p.autorUid} nombre={p.autorNombre} /> : huecoAvatar)}
      <View style={{ maxWidth: ancho, minWidth: 0, ...(isLight ? { elevation: 1, shadowColor: '#000', shadowOpacity: 0.13, shadowRadius: 1, shadowOffset: { width: 0, height: 1 } } : null) }}>
        {/* Cola de la burbuja (solo en el primer mensaje del bloque) */}
        {primero && (mio ? (
          <View pointerEvents="none" style={{ position: 'absolute', top: 0, right: -9, width: 0, height: 0, borderTopWidth: 10, borderRightWidth: 10, borderTopColor: colorBurbuja, borderRightColor: 'transparent' }} />
        ) : (
          <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: -9, width: 0, height: 0, borderTopWidth: 10, borderLeftWidth: 10, borderTopColor: colorBurbuja, borderLeftColor: 'transparent' }} />
        ))}
        <Pressable onLongPress={onLongPress} delayLongPress={280}
          style={{ minWidth: 0, borderRadius: radio, ...esquina, backgroundColor: colorBurbuja, borderWidth: highlighted ? 2.5 : 0, borderColor: '#8AB4F8', paddingHorizontal: 9, paddingTop: 6, paddingBottom: 5, overflow: 'hidden' }}>
          {!mio && primero && <Text style={{ color: colorDe(p.autorUid), fontWeight: '700', fontSize: 13, marginBottom: 2 }}>{p.autorNombre}</Text>}
          {!!p.reenviado && <Text style={{ color: c.mut, fontSize: 11, fontStyle: 'italic', marginBottom: 2 }}>↪ Reenviado</Text>}
          {p.replyTo && (
            /* Tocar la cita salta al mensaje original si está cargado */
            <Pressable onPress={() => { if (onTapReply) onTapReply(p.replyTo.id); }}
              style={{ backgroundColor: isLight ? '#0000000D' : '#00000033', borderLeftWidth: 4, borderLeftColor: colorDe(p.replyTo.nombre || p.replyTo.id), borderRadius: 7, paddingHorizontal: 8, paddingVertical: 5, marginBottom: 5 }}>
              <Text style={{ color: colorDe(p.replyTo.nombre || p.replyTo.id), fontWeight: '700', fontSize: 12 }}>{p.replyTo.nombre}</Text>
              <Text style={{ color: c.mut, fontSize: 12 }} numberOfLines={2}>{p.replyTo.texto}</Text>
            </Pressable>
          )}
          <VistaPrevia p={p} c={c} isLight={isLight} />
          {!!p.texto && <TextoEnlaces texto={p.texto} c={c} isLight={isLight} />}
          {(p.media || []).map((m, i) => (
            m.tipo === 'imagen'
              ? <FotoBurbuja key={i} m={m} c={c} isLight={isLight} onPress={() => onOpenImage(m.url)} />
              : <ChipArchivo key={i} m={m} c={c} isLight={isLight} />
          ))}
          {p.encuesta && <EncuestaBurbuja p={p} c={c} me={me} isLight={isLight} onVotar={onVote} />}
          <View style={{ flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'flex-end', marginTop: 1 }}>
            <Text style={{ color: tinteMeta, fontSize: 11 }}>{fmtHora(p.createdAt, loc)}</Text>
            {mio && <Ionicons name="checkmark" size={14} color={isLight ? '#667781' : '#8696A0'} style={{ marginLeft: 3, marginBottom: -1 }} />}
          </View>
          {reacs.length > 0 && (
            <View style={{ flexDirection: 'row', gap: 4, marginTop: 4, flexWrap: 'wrap' }}>
              {reacs.map(([e, arr]) => (
                <View key={e} style={{ flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: isLight ? '#00000010' : '#FFFFFF18', borderRadius: 999, paddingHorizontal: 6, paddingVertical: 2 }}>
                  <Text style={{ fontSize: 13 }}>{e}</Text>
                  {arr.length > 1 && <Text style={{ fontSize: 11, color: c.txtBubble, fontWeight: '700' }}>{arr.length}</Text>}
                </View>
              ))}
            </View>
          )}
        </Pressable>
      </View>
    </View>
  );
}

/* ── Avatar del chat (patrón WhatsApp, services/avatarCache.js): pinta la
      foto desde el DISCO local (se descargó una sola vez); si la persona
      cambia su foto, la caché la vuelve a bajar y este componente se
      redibuja solo (useAvatar). Sin foto (o archivo dañado): inicial
      coloreada de siempre. ── */
function AvatarChat({ uid, nombre, dim }) {
  const uri = useAvatar(uid);
  const [falla, setFalla] = useState(false);
  useEffect(() => { setFalla(false); }, [uri]);
  const base = { width: 32, height: 32, borderRadius: 16, marginRight: 7, alignSelf: 'flex-end', overflow: 'hidden', opacity: dim ? 0.45 : 1 };
  if (uri && !falla) {
    return (
      <View style={[base, { backgroundColor: colorDe(uid) }]}>
        <ExpoImage source={{ uri }} style={{ width: 32, height: 32 }} contentFit="cover" cachePolicy="memory-disk" transition={120} onError={() => setFalla(true)} />
      </View>
    );
  }
  return (
    <View style={[base, { backgroundColor: colorDe(uid), alignItems: 'center', justifyContent: 'center' }]}>
      <Text style={{ color: '#fff', fontWeight: '800', fontSize: 14 }}>{(nombre || '?').charAt(0).toUpperCase()}</Text>
    </View>
  );
}

/* ── Texto con enlaces pinchables (WhatsApp): las URLs del mensaje se
      detectan (services/enlaces.js, puro y con tests), se pintan en azul +
      subrayado y al tocarlas se abren en el navegador. La pulsación larga
      sigue llegando al Pressable padre (selección del mensaje). ── */
function TextoEnlaces({ texto, c, isLight }) {
  const segs = useMemo(() => segmentar(texto), [texto]);
  const colorLink = isLight ? '#027EB5' : '#53BDEB';
  const abrir = (u) => { try { Linking.openURL(normalizarUrl(u)); } catch (e) {} };
  const copiar = async (u) => {
    await Clipboard.setStringAsync(normalizarUrl(u));
    Alert.alert('URL copiada', 'La URL se ha copiado al portapapeles');
  };
  return (
    <Text style={{ color: c.txtBubble, fontSize: 15, lineHeight: 21 }}>
      {segs.map((sg, i) => (sg.url ? (
        <Text key={i} style={{ color: colorLink, textDecorationLine: 'underline' }} onPress={() => abrir(sg.v)} onLongPress={() => copiar(sg.v)} delayLongPress={350}>{sg.v}</Text>
      ) : (
        <Text key={i}>{sg.v}</Text>
      )))}
    </Text>
  );
}

/* ── Tarjeta de previsualización de enlace (WhatsApp): miniatura + título +
      descripción + dominio, tocables. Los datos viajan ADJUNTOS al mensaje
      (campo preview, generados por quien lo envía); los mensajes antiguos
      sin preview lo piden una sola vez al servidor y lo cachean 7 días
      (services/linkPreview.js). Con fotos/archivos en el mensaje no se
      muestra (WhatsApp solo despliega enlaces de texto). ── */
function VistaPrevia({ p, c, isLight }) {
  const urlTxt = useMemo(() => primeraUrl(p.texto || ''), [p.texto]);
  const [prev, setPrev] = useState(() => ((p.preview && (p.preview.titulo || p.preview.imagen)) ? p.preview : null));
  useEffect(() => {
    setPrev((p.preview && (p.preview.titulo || p.preview.imagen)) ? p.preview : null);
  }, [p.preview]);
  useEffect(() => {
    if (prev || !urlTxt || (p.media || []).length) return undefined;
    let vivo = true;
    obtenerPreview(urlTxt).then((r) => { if (vivo && r) setPrev(r); }).catch(() => {});
    return () => { vivo = false; };
  }, [urlTxt, prev, p.media]);
  if (!urlTxt || (p.media || []).length) return null;
  if (!prev || (!prev.titulo && !prev.imagen)) return null;
  const colorLink = isLight ? '#027EB5' : '#53BDEB';
  const dominio = prev.dominio || dominioDe(prev.url || urlTxt);
  const abrir = () => { try { Linking.openURL(normalizarUrl(prev.url || urlTxt)); } catch (e) {} };
  return (
    <TouchableOpacity onPress={abrir} activeOpacity={0.85}
      style={{ minWidth: 235, maxWidth: 300, marginTop: 2, marginBottom: 5, borderRadius: 12, overflow: 'hidden', backgroundColor: isLight ? '#00000008' : '#FFFFFF10', borderWidth: 1, borderColor: isLight ? '#00000014' : '#FFFFFF1A' }}>
      {!!prev.imagen && (
        <View>
          <ExpoImage source={{ uri: prev.imagen }} style={{ width: '100%', height: 130, backgroundColor: isLight ? '#0000000A' : '#FFFFFF10' }} contentFit="cover" cachePolicy="memory-disk" transition={150} />
          {/* Vídeo (YouTube/reel…): play centrado sobre la miniatura, como los mensajeros */}
          {prev.tipo === 'video' && (
            <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="play-circle" size={46} color="rgba(255,255,255,0.92)" />
            </View>
          )}
        </View>
      )}
      <View style={{ paddingHorizontal: 10, paddingVertical: 8, gap: 3 }}>
        {!!prev.titulo && <Text numberOfLines={2} style={{ color: c.txtBubble, fontWeight: '800', fontSize: 13.5, lineHeight: 18 }}>{prev.titulo}</Text>}
        {!!prev.descripcion && <Text numberOfLines={2} style={{ color: c.mut, fontSize: 12, lineHeight: 16 }}>{prev.descripcion}</Text>}
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 1 }}>
          <Ionicons name="link-outline" size={11} color={colorLink} />
          <Text numberOfLines={1} style={{ color: colorLink, fontSize: 11, fontWeight: '700' }}>{dominio}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

/* ── Imagen de burbuja: pinta la MINIATURA 640 px (thumbUrl) con expo-image
      (decodificación y caché memoria+disco eficientes); el tap abre el visor
      con el ORIGINAL. Mensajes antiguos sin thumbUrl: se usa el original. ── */
function FotoBurbuja({ m, c, isLight, onPress }) {
  const [cached, setCached] = useState(null);
  const showUrl = m.thumbUrl || m.url;
  useEffect(() => {
    if (!showUrl) return undefined;
    let alive = true;
    cachedOrDownload(showUrl).then((u) => { if (alive) setCached(u); }).catch(() => { if (alive) setCached(showUrl); });
    return () => { alive = false; };
  }, [showUrl]);
  if (!m.url) {
    // Posts antiguos cuya subida nunca terminó: placeholder en vez de crash
    return (
      <View style={{ width: 220, height: 120, borderRadius: 10, marginTop: 5, backgroundColor: isLight ? '#00000010' : '#FFFFFF10', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
        <Ionicons name="image-outline" size={26} color={c.mut} />
        <Text style={{ color: c.mut, fontSize: 11 }}>{'Imagen no disponible'}</Text>
      </View>
    );
  }
  const uri = cached || showUrl;
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.85}>
      <ExpoImage source={{ uri }} style={{ width: 220, height: 220, borderRadius: 10, marginTop: 5, backgroundColor: isLight ? '#00000010' : '#FFFFFF10' }} contentFit="cover" cachePolicy="memory-disk" transition={120} />
    </TouchableOpacity>
  );
}

/* ── Tarjeta de archivo estilo WhatsApp: más ancha y más alta que el chip
      viejo (icono por tipo, nombre, extensión · tamaño). Los AUDIOS se
      reproducen dentro del propio chat (expo-audio, uno a la vez) y el
      resto de archivos se abre con el visor del sistema. ── */
function ChipArchivo({ m, c, isLight }) {
  if (esAudioMedia(m)) return <AudioBurbuja m={m} c={c} isLight={isLight} />;
  const meta = [extDe(m.nombre) || 'ARCHIVO', fmtSize(m.size)].filter(Boolean).join(' · ');
  return (
    <TouchableOpacity onPress={() => { if (m.url) Linking.openURL(m.url); }}
      style={{ flexDirection: 'row', alignItems: 'center', gap: 11, minWidth: 240, maxWidth: 300, minHeight: 66, marginTop: 6, marginBottom: 2, paddingHorizontal: 12, paddingVertical: 10, borderRadius: 14, backgroundColor: isLight ? '#0000000D' : '#FFFFFF14' }}>
      <View style={{ width: 40, height: 48, borderRadius: 8, backgroundColor: '#D35400', alignItems: 'center', justifyContent: 'center' }}>
        <Ionicons name="document-text-outline" size={22} color="#fff" />
      </View>
      <View style={{ flex: 1, gap: 3 }}>
        <Text style={{ color: c.txtBubble, fontSize: 14, fontWeight: '700' }} numberOfLines={2}>{m.nombre || 'archivo'}</Text>
        {!!meta && <Text style={{ color: c.mut, fontSize: 11 }} numberOfLines={1}>{meta}</Text>}
      </View>
      <Ionicons name="download-outline" size={18} color={c.mut} />
    </TouchableOpacity>
  );
}

/* ── Audio en el chat (WhatsApp): botón play/pause, barra de progreso con
      punto arrastrable y duración. Solo suena UN audio a la vez; el archivo
      se baja a disco la primera vez (misma caché single-flight que imágenes). ── */
let playerActivo = null;
let modoAudioOk = false;
async function asegurarModoAudio() {
  if (modoAudioOk || !AudioLib) return;
  modoAudioOk = true;
  // allowsRecording:false (default iOS) = sesión de SOLO reproducción: si se
  // queda true, el audio puede salir por el auricular en vez del altavoz.
  try { await AudioLib.setAudioModeAsync({ playsInSilentMode: true, allowsRecording: false }); } catch (e) {}
}
// iOS exige allowsRecording:true en el modo de audio ANTES de grabar
// (si no: "RecordingDisabledException: Recording not allowed on IOS").
// En Android la opción se ignora, así que da igual llamarlo siempre.
async function ponerModoGrabacion(grabando) {
  if (!AudioLib) return;
  try { await AudioLib.setAudioModeAsync({ playsInSilentMode: true, allowsRecording: grabando }); } catch (e) {}
}

function AudioBurbuja({ m, c, isLight }) {
  // No forzar width: 100% dentro de la burbuja. En Android eso encogía el
  // bloque interno y hacía desaparecer el nombre del archivo.
  const caja = { flexDirection: 'row', alignItems: 'center', gap: 9, minWidth: 255, maxWidth: 330, marginTop: 6, marginBottom: 2, paddingHorizontal: 10, paddingVertical: 9, borderRadius: 14, backgroundColor: isLight ? '#0000000D' : '#FFFFFF14' };
  if (!AudioLib || !m.url) {
    // Binario sin expo-audio (OTA antigua) o sin URL: tarjeta que lo abre
    return (
      <TouchableOpacity onPress={() => { if (m.url) Linking.openURL(m.url); }} style={caja}>
        <View style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: '#8E44AD', alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="musical-notes-outline" size={20} color="#fff" />
        </View>
        <View style={{ flex: 1, gap: 3 }}>
          <Text style={{ color: c.txtBubble, fontSize: 14, fontWeight: '700' }} numberOfLines={1}>{m.nombre || 'Audio'}</Text>
          <Text style={{ color: c.mut, fontSize: 11 }} numberOfLines={1}>{['AUDIO', fmtSize(m.size)].filter(Boolean).join(' · ')}</Text>
        </View>
        <Ionicons name="play-circle-outline" size={22} color={c.mut} />
      </TouchableOpacity>
    );
  }
  return <ReproductorAudio m={m} c={c} isLight={isLight} caja={caja} />;
}

/* ── Barra de audio clásica: pista horizontal fina, tramo coloreado hasta
      la posición y un punto que se mueve con el dedo (pan) para adelantar
      o retroceder; un toque en la pista también salta ahí. Al soltar se
      conserva el valor comprometido 0,8 s para que el punto no "vuelva"
      mientras el status del player (250 ms) alcanza el seek. La usan el
      reproductor del chat y la vista previa del envío. ── */
const BA_R = 6;               // radio del punto
const BA_MARGEN = BA_R + 4;   // aire lateral para que el punto no recorte

function BarraAudio({ pct, dur, onSeek, c, isLight, altura = 28, centro = false, fallbackDer = 'AUDIO' }) {
  const [ancho, setAncho] = useState(0);
  const [drag, setDrag] = useState(null);      // 0..1 mientras el dedo arrastra
  const [commit, setCommit] = useState(null);  // seek recién hecho (lag del status)

  const util = Math.max(1, ancho - BA_MARGEN * 2);
  const pctSt = Math.max(0, Math.min(1, pct || 0));
  const p = drag != null ? drag : (commit != null ? commit : pctSt);
  const posSeg = p * (dur || 0);

  const pctDe = (x) => Math.max(0, Math.min(1, (x - BA_MARGEN) / util));
  const alTocar = (x) => { const v = pctDe(x); setCommit(v); if (onSeek) onSeek(v * dur); };
  const alMover = (x) => setDrag(pctDe(x));
  const alSoltar = (x) => { const v = pctDe(x); setDrag(null); setCommit(v); if (onSeek) onSeek(v * dur); };
  const alCancelar = () => setDrag(null);

  useEffect(() => {
    if (commit == null) return;
    const t = setTimeout(() => setCommit(null), 800);
    return () => clearTimeout(t);
  }, [commit]);

  const tap = Gesture.Tap()
    .maxDuration(300)   // falla rápido: no le roba el long-press a la burbuja
    .onEnd((e, ok) => { if (ok && dur > 0) runOnJS(alTocar)(e.x); });
  const pan = Gesture.Pan()
    .maxPointers(1)
    .activeOffsetX([-6, 6])   // el dedo manda en horizontal (scrub)...
    .failOffsetY([-8, 8])     // ...y pierde en vertical (scroll del chat)
    .onUpdate((e) => { if (dur > 0) runOnJS(alMover)(e.x); })
    .onEnd((e, ok) => { if (ok && dur > 0) runOnJS(alSoltar)(e.x); else runOnJS(alCancelar)(); });

  return (
    <View>
      <GestureDetector gesture={Gesture.Race(tap, pan)}>
        <View style={{ height: altura, justifyContent: 'center' }} onLayout={(e) => { const w = e.nativeEvent.layout.width || 0; if (w > 0) setAncho(w); }}>
          <View style={{ position: 'absolute', left: BA_MARGEN, right: BA_MARGEN, height: 3, borderRadius: 1.5, backgroundColor: isLight ? '#00000022' : '#FFFFFF30', overflow: 'hidden' }}>
            <View style={{ width: (Math.round(p * 1000) / 10) + '%', height: '100%', backgroundColor: c.acc }} />
          </View>
          <View style={[{ position: 'absolute', left: BA_MARGEN + p * util - BA_R, width: BA_R * 2, height: BA_R * 2, borderRadius: BA_R, backgroundColor: c.acc, borderWidth: 2, borderColor: isLight ? '#FFFFFF' : '#FFFFFFE6' },
            Platform.OS === 'android' ? { elevation: 3 } : { shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 2, shadowOffset: { width: 0, height: 1 } }]} />
        </View>
      </GestureDetector>
      {centro ? (
        <Text style={{ color: c.mut, textAlign: 'center', fontSize: 12, marginTop: 2 }}>{fmtDur(posSeg)} / {dur > 0 ? fmtDur(dur) : fallbackDer}</Text>
      ) : (
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Text style={{ color: c.mut, fontSize: 10.5 }}>{fmtDur(posSeg)}</Text>
          <Text style={{ color: c.mut, fontSize: 10.5 }}>{dur > 0 ? fmtDur(dur) : fallbackDer}</Text>
        </View>
      )}
    </View>
  );
}

function ReproductorAudio({ m, c, isLight, caja }) {
  const [localUri, setLocalUri] = useState(() => diskCache.get(m.url) || null);
  const [bajando, setBajando] = useState(false);
  const cargada = useRef(false);
  const player = AudioLib.useAudioPlayer(null, { updateInterval: 250 });
  const status = AudioLib.useAudioPlayerStatus(player);

  // Al desmontar: si este audio sonaba, se detiene (nunca se queda sonando)
  useEffect(() => () => {
    if (playerActivo === player) playerActivo = null;
    try { player.pause(); } catch (e) {}
  }, []);

  const toggle = async () => {
    try {
      await asegurarModoAudio();
      let uri = localUri;
      if (!uri) {
        setBajando(true);
        try { uri = diskCache.get(m.url) || (await cachedOrDownload(m.url)); } finally { setBajando(false); }
        if (!uri) return;
        setLocalUri(uri);
      }
      if (!cargada.current) { player.replace({ uri }); cargada.current = true; }
      if (status && status.playing) { player.pause(); return; }
      // Un solo audio a la vez, como WhatsApp
      if (playerActivo && playerActivo !== player) { try { playerActivo.pause(); } catch (e) {} }
      playerActivo = player;
      if (status && status.didJustFinish) { try { await player.seekTo(0); } catch (e) {} }
      player.play();
    } catch (e) {}
  };

  const dur = status && status.duration > 0 ? status.duration : 0;
  const cur = status && status.currentTime > 0 ? Math.min(status.currentTime, dur || status.currentTime) : 0;
  const pct = dur > 0 ? Math.max(0, Math.min(1, cur / dur)) : 0;
  const playing = !!(status && status.playing);

  const buscar = (sec) => { try { player.seekTo(sec); } catch (e) {} };

  return (
    <View style={caja}>
      <TouchableOpacity onPress={toggle} style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: c.acc, alignItems: 'center', justifyContent: 'center' }}>
        {bajando ? <ActivityIndicator size="small" color="#fff" />
          : <Ionicons name={playing ? 'pause' : 'play'} size={playing ? 20 : 22} color="#fff" style={playing ? undefined : { marginLeft: 3 }} />}
      </TouchableOpacity>
      <View style={{ flex: 1, minWidth: 0, gap: 4 }}>
        <Text style={{ color: c.txtBubble, fontSize: 13, fontWeight: '800' }} numberOfLines={2} ellipsizeMode="tail">{m.nombre || 'Audio'}</Text>
        <BarraAudio pct={pct} dur={dur} onSeek={buscar} c={c} isLight={isLight} fallbackDer={fmtSize(m.size) || 'AUDIO'} />
      </View>
    </View>
  );
}

/* ── Encuesta dentro de la burbuja (WhatsApp): cuadro MÁS ANCHO (la burbuja
      sube a 94% cuando hay encuesta), barra de color por opción, insignia
      "GANANDO" en la líder (empates: varias), check en tu voto, recuento y
      porcentajes EN VIVO. Tocar vota; tocar otra opción cambia el voto. ── */
function EncuestaBurbuja({ p, c, me, isLight, onVotar }) {
  const enc = p.encuesta || {};
  const opciones = enc.opciones || [];
  const r = contarVotos(enc, me);
  return (
    <View style={{ minWidth: 255, marginTop: 6, marginBottom: 2, gap: 6 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
        <Ionicons name="stats-chart" size={15} color={c.acc} />
        <Text style={{ color: c.txtBubble, fontWeight: '800', fontSize: 14, flex: 1 }}>{enc.pregunta || 'Encuesta'}</Text>
      </View>
      {opciones.map((op, i) => {
        const color = colorOpcion(i);
        const n = r.porOpcion[i] || 0;
        const pct = r.porcentajes[i] || 0;
        const lider = n > 0 && r.lideres.indexOf(i) >= 0;
        const mio = r.mio === i;
        return (
          <TouchableOpacity key={i} activeOpacity={0.8} onPress={() => { if (onVotar) onVotar(p, i); }}
            style={{ borderRadius: 11, borderWidth: lider ? 1.8 : 1.2, borderColor: lider ? color : (mio ? c.acc : (isLight ? '#00000022' : '#FFFFFF2E')), backgroundColor: isLight ? '#FFFFFFCC' : '#0C1425CC', overflow: 'hidden' }}>
            <View style={{ position: 'absolute', top: 0, bottom: 0, left: 0, width: `${pct}%`, backgroundColor: color + (lider ? '66' : '33') }} />
            <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 9, gap: 7 }}>
              <Text style={{ flex: 1, color: c.txtBubble, fontSize: 13, fontWeight: lider ? '800' : '600' }} numberOfLines={2}>{op}</Text>
              {lider && (
                <View style={{ backgroundColor: color, borderRadius: 999, paddingHorizontal: 6, paddingVertical: 1.5 }}>
                  <Text style={{ color: '#fff', fontSize: 9, fontWeight: '800', letterSpacing: 0.4 }}>GANANDO</Text>
                </View>
              )}
              {mio && <Ionicons name="checkmark-circle" size={16} color={c.acc} />}
              <Text style={{ color: c.mut, fontSize: 11.5, fontWeight: '700' }}>{n > 0 ? `${pct}% · ${n}` : '—'}</Text>
            </View>
          </TouchableOpacity>
        );
      })}
      <Text style={{ color: c.mut, fontSize: 11 }}>
        {r.total === 1 ? '1 voto' : `${r.total} votos`} · {r.mio != null ? 'toca otra opción para cambiar tu voto' : 'toca una opción para votar'}
      </Text>
    </View>
  );
}

/* ── Visor a pantalla completa con ZOOM (pellizco + doble toque) ── */
/* ══════════════ TARJETA DE RETO ══════════════ */
function RetoCard({ r, activo, c, loc, L, meUid, onAceptar, onCancelar, delay = 0 }) {
  const [abierto, setAbierto] = useState(false);   // clasificación desplegada
  const met = METRICAS.find((m) => m.id === r.metrica) || METRICAS[0];
  const ganador = r.ranking?.[0];
  const soyCreador = r.creadorUid === meUid;
  const invitado = (r.invitados || []).includes(meUid) || soyCreador;
  const ahora = new Date();
  const noEmpezado = r.ini && r.ini > ahora;
  const durDias = r.ini && r.fin ? Math.round((r.fin - r.ini) / 86400000) : null;
  // Progreso del tiempo transcurrido (solo visual)
  const pctTiempo = r.ini && r.fin && r.fin > r.ini ? Math.max(0, Math.min(1, (ahora - r.ini) / (r.fin - r.ini))) : 0;
  const dorado = '#F5A623';
  const chipTxt = activo
    ? (noEmpezado
        ? ((r.ini - ahora) < 86400000 ? L('empieza mañana', 'starts tomorrow') : `${L('empieza en', 'starts in')} ${Math.ceil((r.ini - ahora) / 86400000)} ${L('días', 'days')}`)
        : r.diasRestantes <= 0 ? L('último día', 'last day') : `${r.diasRestantes} ${L('días', 'days')}`)
    : null;
  return (
    <FadeInWA delay={delay}>
      <View style={{ marginHorizontal: 12, marginBottom: 10, borderRadius: 18, backgroundColor: c.cardWA, borderWidth: c.isLight ? 0 : 1, borderColor: activo ? dorado + '55' : c.border, overflow: 'hidden', elevation: c.isLight ? 1 : 0, shadowColor: '#000', shadowOpacity: c.isLight ? 0.1 : 0, shadowRadius: 2, shadowOffset: { width: 0, height: 1 } }}>
        {activo && <View style={{ height: 3, backgroundColor: dorado }} />}
        <View style={{ padding: 14 }}>
          {/* Cabecera: avatar-trofeo + título + estado (como una conversación) */}
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <View style={{ width: 46, height: 46, borderRadius: 23, backgroundColor: activo ? dorado + '26' : c.mut + '22', borderWidth: 1.5, borderColor: activo ? dorado + '77' : c.border, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="trophy" size={21} color={activo ? dorado : c.mut} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: c.txt, fontWeight: '800', fontSize: 16 }} numberOfLines={2}>{r.titulo}</Text>
              <Text style={{ color: c.mut, fontSize: 12, marginTop: 1 }} numberOfLines={1}>
                {L('creado por', 'by')} {r.creadorNombre || '?'} · {met.label}
              </Text>
            </View>
            {activo && (
              <View style={{ paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, backgroundColor: dorado + '22' }}>
                <Text style={{ color: dorado, fontWeight: '800', fontSize: 12 }}>{chipTxt}</Text>
              </View>
            )}
          </View>
          {!!r.descripcion && <Text style={{ color: c.mut, marginTop: 10, lineHeight: 19 }}>{r.descripcion}</Text>}
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 10 }}>
            <Ionicons name="calendar-outline" size={14} color={c.mut} />
            <Text style={{ color: c.mut, fontSize: 12, flex: 1 }} numberOfLines={1}>
              {fmtDia(r.inicio, loc)} → {fmtDia(r.fin, loc)}{durDias ? ` · ${durDias} ${L('días', 'days')}` : ''}
            </Text>
          </View>
          {activo && !noEmpezado && r.ini && r.fin && (
            <View style={{ marginTop: 8 }}>
              <ProgresoReto pct={pctTiempo} color={dorado} track={c.border} />
            </View>
          )}
          {activo && invitado && !r.aceptado && (
            <PressWA onPress={onAceptar} style={{ marginTop: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 12, borderRadius: 999, backgroundColor: c.send }}>
              <Ionicons name="checkmark-circle-outline" size={18} color="#fff" />
              <Text style={{ color: '#fff', fontWeight: '800' }}>{soyCreador ? L('Unirme al reto', 'Join challenge') : L('Aceptar reto', 'Accept challenge')}</Text>
            </PressWA>
          )}
          {(r.aceptado || soyCreador || !activo) && (
            <View style={{ marginTop: 12, gap: 2 }}>
              {/* ACTIVOS: plegado = solo quién va ganando; al pinchar se despliega
                  la lista completa con puestos y lo que lleva cada uno. */}
              {activo && (r.ranking || []).length > 0 && (
                <Pressable onPress={() => setAbierto((v) => !v)} style={({ pressed }) => ({ borderRadius: 12, backgroundColor: pressed ? c.send + '12' : 'transparent' })}>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <View style={{ flex: 1 }}>
                      <Text style={{ color: c.mut, fontSize: 11, fontWeight: '800', letterSpacing: 0.5, marginLeft: 10, marginBottom: 2 }}>{L('VA GANANDO', 'LEADING')}</Text>
                      <FilaRanking row={r.ranking[0]} pos={1} valor={fmtValor(r.ranking[0].valor, r.metrica)} meUid={meUid} c={c} L={L} lider />
                    </View>
                    <Ionicons name={abierto ? 'chevron-up' : 'chevron-down'} size={18} color={c.mut} style={{ marginRight: 8 }} />
                  </View>
                </Pressable>
              )}
              {activo && abierto && (r.ranking || []).slice(1).map((row, i) => (
                <FilaRanking key={row.uid} row={row} pos={i + 2} valor={fmtValor(row.valor, r.metrica)} meUid={meUid} c={c} L={L} />
              ))}
              {activo && abierto && (r.ranking || []).length === 1 && (
                <Text style={{ color: c.mut, fontSize: 12, paddingHorizontal: 10 }}>
                  {L('Nadie más ha aceptado el reto todavía.', 'Nobody else has accepted yet.')}
                </Text>
              )}
              {/* PASADOS: historial con el podio, como siempre */}
              {!activo && (r.ranking || []).slice(0, 3).map((row, i) => (
                <FilaRanking key={row.uid} row={row} pos={i + 1} valor={fmtValor(row.valor, r.metrica)} meUid={meUid} c={c} L={L} lider={i === 0} />
              ))}
              {(r.ranking || []).length === 0 && (
                <Text style={{ color: c.mut, fontSize: 12 }}>{L('Nadie ha aceptado el reto todavía.', 'Nobody accepted the challenge yet.')}</Text>
              )}
            </View>
          )}
          {!activo && ganador && (
            <Text style={{ color: c.mut, marginTop: 8, fontSize: 12 }}>
              {L('Ganador', 'Winner')}: <Text style={{ color: c.txt, fontWeight: '800' }}>{ganador.nombre}</Text> · {fmtValor(ganador.valor, r.metrica)}
            </Text>
          )}
          {activo && soyCreador && (
            <Pressable onPress={onCancelar} hitSlop={6} style={{ marginTop: 12, alignSelf: 'center', flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 6 }}>
              <Ionicons name="trash-bin-outline" size={15} color="#E5484D" />
              <Text style={{ color: '#E5484D', fontWeight: '700', fontSize: 13 }}>{L('Cancelar reto', 'Cancel challenge')}</Text>
            </Pressable>
          )}
        </View>
      </View>
    </FadeInWA>
  );
}

/* ══════════════ ISLA DE COMPOSICIÓN ══════════════ */
function ComposerIsland({ c, L, onPublicado, replyTo, onCancelReply }) {
  const me = auth.currentUser;
  const [texto, setTexto] = useState('');
  const [media, setMedia] = useState([]);
  const [encuesta, setEncuesta] = useState(null);
  const [panelEnc, setPanelEnc] = useState(false);
  const [sending, setSending] = useState(false);
  const [txtH, setTxtH] = useState(22);
  const [recording, setRecording] = useState(false);
  const [preview, setPreview] = useState(null);
  const recorder = AudioLib?.useAudioRecorder
    ? AudioLib.useAudioRecorder(AudioLib.RecordingPresets?.HIGH_QUALITY)
    : null;
  // Espejo de "recording" para el cleanup de desmonte (allí el state se ve
  // obsoleto): si sales del chat grabando, se corta y se libera el micrófono.
  const grabandoRef = useRef(false);
  useEffect(() => () => {
    if (!grabandoRef.current || !recorder) return;
    grabandoRef.current = false;
    try { recorder.stop(); } catch (e) {}
    ponerModoGrabacion(false);
  }, []);

  const toggleRecording = async () => {
    if (!recorder) {
      Alert.alert(L('Grabación no disponible', 'Recording unavailable'), L('Actualiza la app para activar la grabación de audio.', 'Update the app to enable audio recording.'));
      return;
    }
    try {
      if (recording) {
        await recorder.stop();
        // Volver a sesión de reproducción: con allowsRecording:true el audio
        // de los players puede salir por el auricular en iOS.
        await ponerModoGrabacion(false);
        const uri = recorder.uri;
        grabandoRef.current = false;
        setRecording(false);
        if (uri) {
          const info = await FileSystem.getInfoAsync(uri);
          setMedia((m) => [...m, { uri, nombre: `audio-${Date.now()}.m4a`, size: info.size || 0, contentType: 'audio/m4a', tipo: 'archivo' }]);
        }
      } else {
        const permission = await AudioLib.requestRecordingPermissionsAsync();
        if (!permission.granted) {
          Alert.alert(L('Permiso requerido', 'Permission required'), L('Activa el permiso del micrófono para grabar audios.', 'Allow microphone access to record audio.'));
          return;
        }
        await ponerModoGrabacion(true);
        await recorder.prepareToRecordAsync();
        recorder.record();
        grabandoRef.current = true;
        setRecording(true);
      }
    } catch (e) {
      await ponerModoGrabacion(false);   // no deja la sesión en modo grabación
      grabandoRef.current = false;
      setRecording(false);
      Alert.alert(L('No se pudo grabar el audio', 'Could not record audio'), e.message || String(e));
    }
  };

  const pickFiles = async () => {
    const r = await DocumentPicker.getDocumentAsync({ type: '*/*', multiple: true, copyToCacheDirectory: true });
    if (r.canceled) return;
    const adds = (r.assets || []).map((a) => ({
      uri: a.uri, nombre: a.name || 'archivo', size: a.size || 0,
      contentType: a.mimeType || 'application/octet-stream',
      tipo: (a.mimeType || '').startsWith('image/') ? 'imagen' : 'archivo',
    }));
    setMedia((m) => [...m, ...adds]);
  };
  const pickCamera = async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      Alert.alert(L('Permiso requerido', 'Permission required'), L('Activa la cámara para hacer fotos.', 'Enable camera to take photos.'));
      return;
    }
    const r = await ImagePicker.launchCameraAsync({ quality: 0.8 });
    if (r.canceled) return;
    const adds = [];
    for (const a of r.assets) {
      const info = await FileSystem.getInfoAsync(a.uri);
      adds.push({ uri: a.uri, nombre: a.fileName || `foto-${Date.now()}.jpg`, size: info.size || 0, contentType: a.mimeType || 'image/jpeg', tipo: 'imagen' });
    }
    setMedia((m) => [...m, ...adds]);
  };

  /* Publicar AL INSTANTE: el post sale ya con la miniatura local y el aro de
     progreso; las subidas a R2 continúan en segundo plano. */
  const publicar = async () => {
    if (!texto.trim() && media.length === 0 && !(encuesta && encuesta.pregunta.trim())) return;
    setSending(true);
    try {
      const perfil = (await getCachedProfile(me.uid)) || {};
      // Como antes (lo que funciona): primero se suben los archivos a R2 y
      // después se publica el mensaje con las URLs finales, sin estados
      // intermedios que se puedan quedar colgados.
      const mediaUp = [];
      for (const item of media) {
        const ct = item.contentType || 'application/octet-stream';
        const d = await presign(me, item.nombre || 'archivo', ct, item.size || 0);
        const originalUrl = publicMediaUrl(d);
        if (!originalUrl) throw new Error('El servidor no devolvió la URL pública del archivo (publicUrl). Revisa R2_PUBLIC_URL en Vercel.');
        // BINARIO explícito: el multipart por defecto envuelve el archivo y
        // corrompe el objeto en R2 (imágenes "cortadas" en el chat).
        await uploadBinary(d.uploadUrl, item.uri, ct);
        const entry = { tipo: item.tipo, url: originalUrl, nombre: item.nombre, size: item.size };
        // Miniatura estilo WhatsApp (dos URLs): la burbuja pintará thumbUrl y
        // el visor cargará el original. Si algo falla, seguimos sin miniatura
        // (la burbuja usa el original) y el envío NO se rompe.
        if (item.tipo === 'imagen' && (item.size || 0) > THUMB_MIN_BYTES) {
          try {
            const thumbUri = await makeThumb(item.uri);
            const tinfo = await FileSystem.getInfoAsync(thumbUri);
            const dt = await presign(me, `thumb-${item.nombre || 'foto'}.jpg`, 'image/jpeg', tinfo.size || 0);
            const thumbUrl = publicMediaUrl(dt);
            if (!thumbUrl) throw new Error('El servidor no devolvió la URL pública de la miniatura.');
            await uploadBinary(dt.uploadUrl, thumbUri, 'image/jpeg');
            entry.thumbUrl = thumbUrl;
            entry.thumbSize = tinfo.size || 0;
          } catch (e) { /* sin miniatura: la burbuja usará el original */ }
        }
        mediaUp.push(entry);
      }
      // Previsualización de enlace estilo WhatsApp: se genera en el lado del
      // EMISOR (el servidor obtiene el Open Graph y se adjunta al mensaje;
      // los receptores no descargan nada). Tope de 3.5 s: si no llega, el
      // mensaje se envía igual sin preview.
      let preview = null;
      const urlEnTexto = primeraUrl(texto);
      if (urlEnTexto && mediaUp.length === 0) {
        try { preview = await previewParaEnvio(urlEnTexto, me); } catch (e) { preview = null; }
      }
      const iso = new Date().toISOString();
      const encFinal = encuesta && encuesta.pregunta.trim()
        ? { pregunta: encuesta.pregunta.trim(), opciones: encuesta.opciones.map((o) => o.trim()).filter(Boolean), votos: {} }
        : null;
      const ref = await addDoc(collection(db, 'posts'), {
        autorUid: me.uid,
        autorNombre: perfil.nombre || me.displayName || 'Alguien',
        texto: texto.trim(),
        media: mediaUp,
        replyTo: replyTo || null,
        encuesta: encFinal,
        preview: preview || null,
        reacciones: {},
        createdAt: iso,
        // Sin caducidad: el historial es permanente (la sincronización es
        // incremental y nunca descarga todo el chat, así que el tamaño no
        // aumenta el coste de uso).
      });
      // Copia local inmediata: se pinta sin esperar al listener
      chatStorePut({
        id: ref.id,
        autorUid: me.uid,
        autorNombre: perfil.nombre || me.displayName || 'Alguien',
        texto: texto.trim(),
        media: mediaUp,
        replyTo: replyTo || null,
        encuesta: encFinal,
        preview: preview || null,
        reacciones: {},
        createdAt: iso,
      }).catch(() => {});
      // Push a los demás (entrenador/atletas) para que el mensaje llegue
      // TAMBIÉN con la app cerrada. No bloquea ni rompe el envío. Si no hay
      // texto (adjunto/encuesta), el servidor compone "📎 adjunto".
      const textoPush = texto.trim() || (encFinal ? encFinal.pregunta : '');
      notificarPushMensaje(me, ref.id, textoPush, perfil.nombre || me.displayName || 'Alguien').catch(() => {});
      // Al vaciar por código el TextInput NO dispara onContentSizeChange
      // (Android): sin este reset la caja se quedaba alta hasta teclear.
      setTexto(''); setTxtH(24); setMedia([]); setEncuesta(null); setPanelEnc(false); onCancelReply();
      onPublicado();
    } catch (e) {
      const perm = /permission/i.test(e.message || '') || e.code === 'permission-denied';
      Alert.alert(L('Error', 'Error'), perm
        ? L('Faltan las reglas de Firestore de "posts": pega firestore.rules en Firebase Console → Firestore → Rules y publica.',
            'Missing Firestore rules for "posts": paste firestore.rules in Firebase Console → Firestore → Rules and publish.')
        : e.message);
    } finally {
      setSending(false);
    }
  };

  const hayAlgo = !!texto.trim() || media.length > 0 || !!(encuesta && encuesta.pregunta.trim());
  const iconBtn = { width: 34, height: 40, alignItems: 'center', justifyContent: 'center' };
  const sendBtn = { width: 48, height: 48, borderRadius: 24, backgroundColor: recording ? '#E05252' : c.send, alignItems: 'center', justifyContent: 'center', elevation: 2, shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 2, shadowOffset: { width: 0, height: 1 } };

  /* Composer estilo WhatsApp: píldora redondeada (encuesta · texto · adjuntar ·
     cámara) + botón circular verde a la derecha (enviar / micrófono). La cita,
     las miniaturas y el panel de encuesta se apilan DENTRO de la píldora. */
  return (
    <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 6, marginHorizontal: 6, marginBottom: 4 }}>
      <View style={{ flex: 1, borderRadius: 24, backgroundColor: c.input, overflow: 'hidden', elevation: c.isLight ? 1 : 0 }}>
        {replyTo && (
          <View style={{ flexDirection: 'row', alignItems: 'center', marginHorizontal: 8, marginTop: 8, backgroundColor: c.isLight ? '#0000000D' : '#00000040', borderLeftWidth: 4, borderLeftColor: c.send, borderRadius: 9, paddingHorizontal: 9, paddingVertical: 6 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: c.send, fontWeight: '700', fontSize: 12 }}>{replyTo.nombre}</Text>
              <Text style={{ color: c.mut, fontSize: 12 }} numberOfLines={1}>{replyTo.texto}</Text>
            </View>
            <TouchableOpacity onPress={onCancelReply}><Ionicons name="close" size={18} color={c.mut} /></TouchableOpacity>
          </View>
        )}
        {media.length > 0 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ maxHeight: 84, marginTop: 10 }} contentContainerStyle={{ paddingHorizontal: 10, gap: 8 }}>
            {media.map((m, i) => (
              <Pressable key={i} onPress={() => setPreview({ item: m, index: i })} style={{ width: 62, height: 62, borderRadius: 10, overflow: 'hidden', borderWidth: 1, borderColor: c.border }}>
                {m.tipo === 'imagen' ? <Image source={{ uri: m.uri }} style={{ width: 62, height: 62 }} /> : (
                  <View style={{ width: 62, height: 62, alignItems: 'center', justifyContent: 'center', backgroundColor: c.bg }}>
                    <Ionicons name={esAudioMedia(m) ? 'musical-notes-outline' : 'document-outline'} size={20} color={c.mut} />
                  </View>
                )}
                <TouchableOpacity onPress={() => { setMedia((mm) => mm.filter((_, j) => j !== i)); if (preview?.index === i) setPreview(null); }} style={{ position: 'absolute', top: 1, right: 1, backgroundColor: '#000000AA', borderRadius: 9, paddingHorizontal: 4 }}>
                  <Text style={{ color: '#fff', fontWeight: '800', fontSize: 11 }}>✕</Text>
                </TouchableOpacity>
              </Pressable>
            ))}
          </ScrollView>
        )}
        <Modal visible={!!preview} transparent animationType="fade" onRequestClose={() => setPreview(null)}>
          {/* Android: el Modal abre una ventana nativa aparte; los gestos de la
              barra de audio (BarraAudio) necesitan su propio GestureHandlerRootView. */}
          <GestureHandlerRootView style={{ flex: 1 }}>
            <View style={{ flex: 1, backgroundColor: '#000000D9', justifyContent: 'center', padding: 18 }}>
              <View style={{ borderRadius: 18, overflow: 'hidden', backgroundColor: c.card, borderWidth: 1, borderColor: c.border }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 14, paddingVertical: 12 }}>
                  <Text style={{ color: c.txt, fontWeight: '800', flex: 1 }} numberOfLines={1}>{preview?.item?.nombre || L('Vista previa', 'Preview')}</Text>
                  <TouchableOpacity onPress={() => setPreview(null)}><Ionicons name="close" size={24} color={c.mut} /></TouchableOpacity>
                </View>
                {!!preview?.item && <AdjuntoPreview item={preview.item} c={c} isLight={c.bg === '#F4F7FB'} />}
                <View style={{ flexDirection: 'row', justifyContent: 'flex-end', gap: 10, padding: 12 }}>
                  <TouchableOpacity onPress={() => setPreview(null)} style={{ paddingHorizontal: 14, paddingVertical: 9, borderRadius: 10, backgroundColor: c.bg }}>
                    <Text style={{ color: c.txt, fontWeight: '700' }}>{L('Cerrar', 'Close')}</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => { const i = preview?.index; setPreview(null); if (i != null) setMedia((mm) => mm.filter((_, j) => j !== i)); }} style={{ paddingHorizontal: 14, paddingVertical: 9, borderRadius: 10, backgroundColor: '#E05252' }}>
                    <Text style={{ color: '#fff', fontWeight: '700' }}>{L('Quitar', 'Remove')}</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </GestureHandlerRootView>
        </Modal>
        {panelEnc && (
          <View style={{ marginHorizontal: 10, marginTop: 10, gap: 7, padding: 10, borderRadius: 12, borderWidth: 1, borderColor: c.border }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <TextInput value={encuesta?.pregunta || ''} onChangeText={(t) => setEncuesta((e) => ({ pregunta: t, opciones: e?.opciones || ['', ''] }))}
                placeholder={L('Pregunta de la encuesta', 'Poll question')} placeholderTextColor={c.mut}
                style={{ flex: 1, color: c.txt, fontWeight: '700' }} />
              <TouchableOpacity onPress={() => { setPanelEnc(false); setEncuesta(null); }}>
                <Ionicons name="trash-outline" size={18} color={c.mut} />
              </TouchableOpacity>
            </View>
            {(encuesta?.opciones || []).map((op, i) => (
              <View key={i} style={{ flexDirection: 'row', gap: 7, alignItems: 'center' }}>
                <TextInput value={op} onChangeText={(t) => setEncuesta((e) => { const o = [...e.opciones]; o[i] = t; return { ...e, opciones: o }; })}
                  placeholder={`${L('Opción', 'Option')} ${i + 1}`} placeholderTextColor={c.mut}
                  style={{ flex: 1, color: c.txt, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 9, backgroundColor: c.bg }} />
                <TouchableOpacity onPress={() => setEncuesta((e) => ({ ...e, opciones: e.opciones.filter((_, j) => j !== i) }))}>
                  <Ionicons name="close-circle-outline" size={18} color={c.mut} />
                </TouchableOpacity>
              </View>
            ))}
            {(encuesta?.opciones || []).length < 6 && (
              <TouchableOpacity onPress={() => setEncuesta((e) => ({ ...e, opciones: [...(e?.opciones || ['']), ''] }))}>
                <Text style={{ color: c.send, fontWeight: '700' }}>+ {L('Añadir opción', 'Add option')}</Text>
              </TouchableOpacity>
            )}
          </View>
        )}
        <View style={{ flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 4, paddingVertical: 4 }}>
          <TouchableOpacity onPress={() => setPanelEnc((v) => !v)} style={iconBtn} accessibilityLabel={L('Encuesta', 'Poll')}>
            <Ionicons name={panelEnc ? 'bar-chart' : 'bar-chart-outline'} size={22} color={panelEnc || encuesta ? c.send : c.mut} />
          </TouchableOpacity>
          <View style={{ flex: 1, maxHeight: 132, justifyContent: 'center', paddingHorizontal: 4, paddingVertical: 7 }}>
            <TextInput
              value={texto} onChangeText={(t) => { setTexto(t); if (!t) setTxtH(24); }} multiline
              onContentSizeChange={(e) => setTxtH(e.nativeEvent.contentSize.height)}
              placeholder={recording ? L('Grabando audio…', 'Recording audio…') : L('Mensaje', 'Message')} placeholderTextColor={c.mut}
              style={{ color: c.txt, fontSize: 16, lineHeight: 22, paddingVertical: 0, minHeight: 24, height: Math.min(120, Math.max(24, txtH)), textAlignVertical: 'center' }}
            />
          </View>
          {/* Acciones secundarias dentro de la píldora: adjuntar → cámara */}
          <TouchableOpacity onPress={pickFiles} style={iconBtn} accessibilityLabel={L('Adjuntar archivo', 'Attach file')}>
            <Ionicons name="attach" size={24} color={c.mut} style={{ transform: [{ rotate: '-45deg' }] }} />
          </TouchableOpacity>
          <TouchableOpacity onPress={pickCamera} style={iconBtn} accessibilityLabel={L('Cámara', 'Camera')}>
            <Ionicons name="camera-outline" size={23} color={c.mut} />
          </TouchableOpacity>
        </View>
      </View>
      {hayAlgo ? (
        <TouchableOpacity onPress={publicar} disabled={sending} style={sendBtn} accessibilityLabel={L('Enviar mensaje', 'Send message')}>
          {sending ? <ActivityIndicator color="#fff" size="small" /> : <Ionicons name="send" size={21} color="#fff" style={{ marginLeft: 2 }} />}
        </TouchableOpacity>
      ) : (
        <TouchableOpacity onPress={toggleRecording} disabled={sending} style={sendBtn} accessibilityLabel={recording ? L('Detener grabación', 'Stop recording') : L('Grabar audio', 'Record audio')}>
          <Ionicons name={recording ? 'stop' : 'mic'} size={23} color="#fff" />
        </TouchableOpacity>
      )}
    </View>
  );
}

function AdjuntoPreview({ item, c, isLight }) {
  if (item.tipo === 'imagen') {
    return <Image source={{ uri: item.uri }} resizeMode="contain" style={{ width: '100%', height: 330, backgroundColor: '#000' }} />;
  }
  if (esAudioMedia(item) && AudioLib) return <AudioPreview item={item} c={c} isLight={isLight} />;
  return (
    <View style={{ alignItems: 'center', justifyContent: 'center', padding: 34, gap: 10 }}>
      <Ionicons name="document-text-outline" size={52} color={c.acc} />
      <Text style={{ color: c.txt, fontWeight: '700', textAlign: 'center' }}>{item.nombre || 'Archivo'}</Text>
      <Text style={{ color: c.mut }}>{fmtSize(item.size) || 'Archivo listo para enviar'}</Text>
    </View>
  );
}

function AudioPreview({ item, c, isLight }) {
  const player = AudioLib.useAudioPlayer(null, { updateInterval: 200 });
  const status = AudioLib.useAudioPlayerStatus(player);
  useEffect(() => { try { player.replace({ uri: item.uri }); } catch (e) {} return () => { try { player.pause(); } catch (e) {} }; }, [item.uri, player]);
  const duration = status?.duration || 0;
  const current = status?.currentTime || 0;
  const pct = duration ? Math.min(1, current / duration) : 0;
  return (
    <View style={{ paddingHorizontal: 18, paddingVertical: 22, gap: 12 }}>
      <TouchableOpacity disabled={!status?.isLoaded} onPress={() => status?.playing ? player.pause() : player.play()} style={{ alignSelf: 'center', width: 58, height: 58, borderRadius: 29, backgroundColor: c.acc, alignItems: 'center', justifyContent: 'center' }}>
        <Ionicons name={status?.playing ? 'pause' : 'play'} size={27} color="#fff" />
      </TouchableOpacity>
      <BarraAudio pct={pct} dur={duration} altura={34} centro
        onSeek={(sec) => { try { player.seekTo(sec); } catch (e) {} }}
        c={c} isLight={isLight} fallbackDer={fmtSize(item.size) || 'AUDIO'} />
    </View>
  );
}

/* ══════════════ FILA DE ATLETA (foto + nombre + apellido) ══════════════
   La foto sale de la caché de avatares del chat (avatares/<uid> en R2,
   descargada una sola vez por teléfono); si aún no está, iniciales. */
function AtletaRetoChip({ a, on, c, L, onPress }) {
  const avatar = useAvatar(a.uid);
  const nombreCompleto = `${a.nombre || ''} ${a.apellido || ''}`.trim() || a.uid;
  const iniciales = `${(a.nombre || '?').charAt(0)}${(a.apellido || '').charAt(0)}`.toUpperCase() || '?';
  /* Fila estilo lista de chats: avatar (con check verde al seleccionar) + nombre */
  return (
    <Pressable onPress={onPress}
      style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 10, paddingVertical: 8, borderRadius: 14, backgroundColor: on ? c.send + '1F' : pressed ? c.send + '0F' : 'transparent' })}>
      <View style={{ width: 42, height: 42 }}>
        {avatar ? (
          <Image source={{ uri: avatar }} style={{ width: 42, height: 42, borderRadius: 21 }} />
        ) : (
          <View style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: colorDe(a.uid) + '33', alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ color: colorDe(a.uid), fontWeight: '800', fontSize: 14 }}>{iniciales}</Text>
          </View>
        )}
        {on && (
          <View style={{ position: 'absolute', right: -3, bottom: -3, width: 20, height: 20, borderRadius: 10, backgroundColor: c.send, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: c.cardWA }}>
            <Ionicons name="checkmark" size={12} color="#fff" />
          </View>
        )}
      </View>
      <Text style={{ flex: 1, color: c.txt, fontWeight: on ? '800' : '600', fontSize: 15 }} numberOfLines={1}>{nombreCompleto}</Text>
      <Ionicons name={on ? 'checkmark-circle' : 'ellipse-outline'} size={22} color={on ? c.send : c.mut} />
    </Pressable>
  );
}

/* ══════════════ CREAR RETO ══════════════ */
function CreaReto({ onClose, c, L, onCreado }) {
  const me = auth.currentUser;
  const [titulo, setTitulo] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [metrica, setMetrica] = useState('km');
  const [rango, setRango] = useState(null);                // { a, b } días inicio/fin (00:00 local)
  const [calOpen, setCalOpen] = useState(false);           // calendario de rango
  const [atletas, setAtletas] = useState(null);
  const [sel, setSel] = useState(new Set());
  const [saving, setSaving] = useState(false);
  const [metricaOpen, setMetricaOpen] = useState(false);   // desplegable de métrica

  useEffect(() => {
    (async () => {
      try {
        const snap = await getDocs(query(collection(db, 'perfiles'), where('entrenador', '==', me.uid)));
        const list = snap.docs.map((d) => ({
          uid: d.id,
          nombre: d.data().nombre || d.data().email || d.id,
          apellido: d.data().apellido || '',
        }));
        setAtletas(list);
        // Fotos de perfil estilo chat: avatares/<uid> → caché local (useAvatar)
        sincronizarAvatares(list.map((a) => a.uid), me.uid).catch(() => {});
      } catch (e) { setAtletas([]); }
    })();
  }, []);

  const loc = locale();
  const diasTotales = (r) => Math.round((r.b - r.a) / 86400000) + 1;

  const crear = async () => {
    if (!titulo.trim() || sel.size === 0 || !rango) return;
    setSaving(true);
    try {
      const perfil = (await getCachedProfile(me.uid)) || {};
      // Fechas elegidas en el calendario de rango: el reto empieza el primer
      // día seleccionado y termina el segundo (a las 23:59:59.999).
      const ini = new Date(rango.a); ini.setHours(0, 0, 0, 0);
      const fin = new Date(rango.b); fin.setHours(23, 59, 59, 999);
      const ref = await addDoc(collection(db, 'retos'), {
        creadorUid: me.uid,
        creadorNombre: perfil.nombre || me.displayName || 'Coach',
        titulo: titulo.trim(),
        descripcion: descripcion.trim(),
        metrica,
        invitados: [...sel],
        aceptados: [],
        inicio: ini.toISOString(),
        fin: fin.toISOString(),
        createdAt: new Date().toISOString(),
      });
      // Push a cada atleta invitado: el servidor compone el texto en el
      // idioma del atleta con el kind 'reto' (endpoint notify-athlete).
      const cn = perfil.nombre || me.displayName || 'Tu entrenador';
      await Promise.all([...sel].map((uid) => sendNotificationToAthlete(
        uid, me.uid, { kind: 'reto', coachName: cn, nombre: titulo.trim(), retoId: ref.id }
      )));
      onCreado();
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally {
      setSaving(false);
    }
  };

  const inp = { color: c.txt, paddingHorizontal: 14, paddingVertical: 11, borderRadius: 12, backgroundColor: c.listBg, borderWidth: 1.5, borderColor: c.border };
  const filaSel = [inp, { flexDirection: 'row', alignItems: 'center', gap: 10 }];
  const bloqueado = saving || sel.size === 0 || !rango;
  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: '#000000AA', justifyContent: 'center', padding: 18 }}>
        <View style={{ backgroundColor: c.cardWA, borderRadius: 22, overflow: 'hidden', maxHeight: '88%' }}>
          {/* Barra superior verde, como la de la conversación */}
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 14, paddingVertical: 14, backgroundColor: c.bar }}>
            <View style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: c.isLight ? '#FFFFFF2E' : '#2A3942', alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="trophy" size={19} color="#F5A623" />
            </View>
            <Text style={{ color: c.barTxt, fontWeight: '800', fontSize: 16, flex: 1 }} numberOfLines={2}>{L('Nuevo reto para tus atletas', 'New challenge for your athletes')}</Text>
            <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}><Ionicons name="close" size={24} color={c.barTxt} /></TouchableOpacity>
          </View>
          <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" style={{ maxHeight: 440 }} contentContainerStyle={{ padding: 16 }}>
            <View style={{ gap: 10 }}>
              <TextInput value={titulo} onChangeText={setTitulo} placeholder={L('Título: Reto de mayo', 'Title: May challenge')} placeholderTextColor={c.mut} style={inp} />
              <TextInput value={descripcion} onChangeText={setDescripcion} placeholder={L('Descripción (opcional)', 'Description (optional)')} placeholderTextColor={c.mut} style={inp} multiline />
              {/* Métrica en LISTA DESPLEGABLE (antes: fila de botones) */}
              <TouchableOpacity style={filaSel} onPress={() => setMetricaOpen(true)}>
                <Ionicons name="trophy-outline" size={18} color={c.send} />
                <Text style={{ flex: 1, color: c.txt, fontWeight: '700' }} numberOfLines={1}>
                  {(METRICAS.find((m) => m.id === metrica) || METRICAS[0]).label}
                </Text>
                <Ionicons name="chevron-down" size={16} color={c.mut} />
              </TouchableOpacity>
              {/* Fechas del reto: calendario de rango (inicio → fin), mismo
                  diseño que el picker mensual del calendario. */}
              <TouchableOpacity style={filaSel} onPress={() => setCalOpen(true)}>
                <Ionicons name="calendar-outline" size={18} color={c.send} />
                <Text style={{ flex: 1, color: rango ? c.txt : c.mut, fontWeight: '700' }} numberOfLines={1}>
                  {rango
                    ? `${fmtDia(rango.a, loc)} → ${fmtDia(rango.b, loc)} · ${diasTotales(rango)} ${L('días', 'days')}`
                    : L('Del día… al día… (toca para elegir)', 'From… to… (tap to choose)')}
                </Text>
                <Ionicons name="chevron-forward" size={16} color={c.mut} />
              </TouchableOpacity>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 6 }}>
                <Text style={{ color: c.send, fontWeight: '800', fontSize: 12, letterSpacing: 0.6 }}>{L('INVITAR AL RETO', 'INVITE TO THE CHALLENGE')}</Text>
                {sel.size > 0 && (
                  <View style={{ paddingHorizontal: 8, paddingVertical: 1, borderRadius: 999, backgroundColor: c.send + '22' }}>
                    <Text style={{ color: c.send, fontWeight: '800', fontSize: 11 }}>{sel.size}</Text>
                  </View>
                )}
                <View style={{ flex: 1, height: 1, backgroundColor: c.border }} />
              </View>
              {atletas === null ? <ActivityIndicator color={c.send} /> : atletas.length === 0 ? (
                <Text style={{ color: c.mut }}>{L('No tienes atletas asignados todavía.', 'You have no assigned athletes yet.')}</Text>
              ) : (
                <View style={{ gap: 2 }}>
                  {atletas.map((a) => (
                    <AtletaRetoChip
                      key={a.uid}
                      a={a}
                      on={sel.has(a.uid)}
                      c={c}
                      L={L}
                      onPress={() => setSel((s) => { const n = new Set(s); if (n.has(a.uid)) n.delete(a.uid); else n.add(a.uid); return n; })}
                    />
                  ))}
                </View>
              )}
            </View>
          </ScrollView>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 10, paddingHorizontal: 16, paddingVertical: 12, borderTopWidth: 1, borderTopColor: c.border }}>
            <TouchableOpacity onPress={onClose} style={{ paddingHorizontal: 14, paddingVertical: 10 }}><Text style={{ color: c.mut, fontWeight: '700' }}>{L('Cancelar', 'Cancel')}</Text></TouchableOpacity>
            <TouchableOpacity onPress={crear} disabled={bloqueado} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 20, paddingVertical: 11, borderRadius: 999, backgroundColor: c.send, opacity: bloqueado ? 0.5 : 1 }}>
              {saving ? <ActivityIndicator size="small" color="#fff" /> : <Ionicons name="send" size={16} color="#fff" />}
              <Text style={{ color: '#fff', fontWeight: '800' }}>{saving ? L('Creando…', 'Creating…') : L('Crear e invitar', 'Create & invite')}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      {/* Desplegable de métrica: lista con check en la activa */}
        <Modal visible={metricaOpen} transparent animationType="fade" onRequestClose={() => setMetricaOpen(false)}>
          <View style={{ flex: 1, backgroundColor: '#00000088', justifyContent: 'center', padding: 24 }}>
            <View style={{ backgroundColor: c.cardWA, borderRadius: 18, paddingVertical: 6 }}>
              <Text style={{ color: c.mut, fontSize: 12, fontWeight: '700', paddingHorizontal: 16, paddingVertical: 8 }}>
                {L('Métrica del ranking', 'Ranking metric')}
              </Text>
              {METRICAS.map((m) => (
                <TouchableOpacity key={m.id} style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: c.border }}
                  onPress={() => { setMetrica(m.id); setMetricaOpen(false); }}>
                  <Text style={{ color: c.txt, fontSize: 14 }}>{m.label}</Text>
                  {metrica === m.id && <Ionicons name="checkmark-circle" size={20} color={c.send} />}
                </TouchableOpacity>
              ))}
              <TouchableOpacity style={{ alignItems: 'center', paddingVertical: 12 }} onPress={() => setMetricaOpen(false)}>
                <Text style={{ color: c.mut, fontWeight: '700' }}>{L('Cancelar', 'Cancel')}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      {/* Calendario de rango: toca el día de inicio y el de fin (máx. 2) */}
        <RangoCalendarioModal
          visible={calOpen}
          inicial={rango}
          onClose={() => setCalOpen(false)}
          onOk={(r) => { setRango(r); setCalOpen(false); }}
        />
      <SystemBars />
    </Modal>
  );
}

/* ══════════════ VISOR FOCAL estilo WhatsApp/Telegram (HILO DE UI) ══════════════
   Gesture Handler + Reanimated: pellizco, pan y doble toque se calculan en el
   hilo de UI (worklets), así el zoom no da tirones aunque el hilo JS esté
   ocupado (listas del chat, red, etc.) — el "mecanismo de zoom perfecto" de
   WhatsApp.
   · Pellizco: fórmula exacta de anclaje focal t = f − (f₀ − t₀)·(s/s₀): el
     punto bajo los dedos se queda bajo los dedos y el traslado a dos dedos
     va 1:1. Límites 1x–5x. Al levantar UN dedo el gesto se enmudece (fix
     del "salto al soltar": RNGH movería el foco al dedo restante y la foto
     saltaría) y el traslado va topado a los bordes durante el gesto → al
     soltar no rebota nada.
   · Pan: 1:1 con tope en los bordes REALES de la imagen (se respeta el
     letterbox del contentFit="contain"; nada de arrastrar por la zona negra).
   · Sin zoom: swipe horizontal pasa de foto (la imagen sigue al dedo) y
     swipe hacia abajo cierra (el fondo se atenúa siguiendo al dedo).
   · Doble toque: zoom 2.5x anclado al punto tocado / el siguiente vuelve a
     1x con muelle.
   · expo-image: decodificación y caché memoria/disco eficientes; se
     precargan las fotos vecinas para que el swipe no muestre spinner.
   · Barra superior NEGRA (cerrar + compartir, sin numeración de fotos):
     se oculta en cuanto se hace un poco de zoom y vuelve al regresar a 1x.
   OJO: en Android el Modal crea una ventana nativa nueva, por eso el
   contenido va envuelto en su propio GestureHandlerRootView. */
const MINZ = 1;
const MAXZ = 5;
const AnimatedImage = Reanimated.createAnimatedComponent(ExpoImage);

function FocalViewer({ urls, initialIndex, onClose }) {
  const insets = useSafeAreaInsets();
  const [idx, setIdx] = useState(initialIndex || 0);
  const [uri, setUri] = useState(null);

  /* Estado compartido: vive en el hilo de UI; los gestos lo leen/escriben
     sin pasar por JS (por eso el zoom es perfectamente fluido). */
  const scale = useSharedValue(1);
  const tx = useSharedValue(0);
  const ty = useSharedValue(0);
  const imgW = useSharedValue(0);      // tamaño natural de la imagen (onLoad)
  const imgH = useSharedValue(0);
  const boxW = useSharedValue(Dimensions.get('window').width);
  const boxH = useSharedValue(Dimensions.get('window').height);
  const p0s = useSharedValue(1);       // anclas del pellizco: scale/translate
  const p0x = useSharedValue(0);       // y foco en el momento de empezar
  const p0y = useSharedValue(0);
  const p0fx = useSharedValue(0);
  const p0fy = useSharedValue(0);
  const p0e = useSharedValue(1);       // e.scale acumulado en el anclaje
  const pfx = useSharedValue(0);       // foco del frame anterior (anti-salto)
  const pfy = useSharedValue(0);
  const lastE = useSharedValue(1);     // ultimo e.scale visto
  const pinchMuted = useSharedValue(false); // pellizco enmudecido al soltar 1 dedo
  const s0x = useSharedValue(0);       // anclas del pan
  const s0y = useSharedValue(0);

  useEffect(() => {
    let alive = true;
    const u = urls[idx];
    setUri(null);
    imgW.value = 0; imgH.value = 0;
    cachedOriginal(u).then((l) => { if (alive) setUri(l); }).catch(() => { if (alive) setUri(u); });
    // Precarga las vecinas: el swipe lateral no muestra spinner
    if (urls[idx - 1]) cachedOriginal(urls[idx - 1]).catch(() => {});
    if (urls[idx + 1]) cachedOriginal(urls[idx + 1]).catch(() => {});
    return () => { alive = false; };
  }, [idx, urls]);

  const goIdx = (n) => {
    if (n < 0 || n >= urls.length || n === idx) return;
    scale.value = 1; tx.value = 0; ty.value = 0;
    setIdx(n);
  };

  /* Límites reales: con contentFit="contain" la imagen ocupa dw×dh dentro del
     contenedor (letterbox). El pan solo llega hasta el borde de lo que se ve. */
  const bounds = (s) => {
    'worklet';
    let dw = boxW.value;
    let dh = boxH.value;
    if (imgW.value > 0 && imgH.value > 0) {
      const fit = Math.min(boxW.value / imgW.value, boxH.value / imgH.value);
      dw = imgW.value * fit;
      dh = imgH.value * fit;
    }
    return {
      maxX: Math.max(0, (dw * s - boxW.value) / 2),
      maxY: Math.max(0, (dh * s - boxH.value) / 2),
    };
  };
  const snapToBounds = () => {
    'worklet';
    const b = bounds(scale.value);
    tx.value = withTiming(clamp(tx.value, -b.maxX, b.maxX), { duration: 160 });
    ty.value = withTiming(clamp(ty.value, -b.maxY, b.maxY), { duration: 160 });
  };
  const springHome = () => {
    'worklet';
    const cfg = { damping: 18, stiffness: 200 };
    tx.value = withSpring(0, cfg);
    ty.value = withSpring(0, cfg);
  };
  const resetZoom = () => {
    'worklet';
    const cfg = { damping: 17, stiffness: 170 };
    scale.value = withSpring(1, cfg);
    tx.value = withSpring(0, cfg);
    ty.value = withSpring(0, cfg);
  };

  /* ── Pellizco: zoom anclado al punto exacto de los dedos ──
     FIX "salto al soltar" (comportamiento WhatsApp): en Android RNGH NO
     termina el pellizco al levantar UN dedo — el handler ignora onScaleEnd y
     sigue ACTIVE despachando onUpdate con el FOCO TELETRANSPORTADO al dedo
     que queda (su ScaleGestureDetector recalcula el foco excluyendo el dedo
     levantado). La foto saltaba a otro punto, la arrastraba el dedo restante
     y al soltar del todo el snap la devolvía ("va y vuelve"). Los eventos de
     touches se despachan ANTES que los updates (garantizado por el
     GestureHandlerOrchestrator): en cuanto queda 1 touch enmudecemos el
     gesto — termina ahí, como en WhatsApp. Además el traslado va topado a
     los bordes reales DURANTE el gesto: al soltar no rebota nada. */
  const pinch = Gesture.Pinch()
    .onBegin(() => {
      pinchMuted.value = false;   // interaccion nueva: oidos abiertos
    })
    .onTouchesDown((e) => {
      // Si apoyas un dedo nuevo quedando otro en pantalla (pellizco ya
      // enmudecido), reanclamos el gesto al estado actual en vez de exigir
      // levantar todos los dedos primero.
      if (!pinchMuted.value || e.numberOfTouches < 2) return;
      const ts = e.allTouches;
      if (!ts || ts.length < 2) return;
      let sx = 0;
      let sy = 0;
      for (let i = 0; i < ts.length; i++) { sx += ts[i].x; sy += ts[i].y; }
      p0s.value = Math.max(0.01, scale.value);
      p0x.value = tx.value;
      p0y.value = ty.value;
      p0e.value = lastE.value > 0 ? lastE.value : 1;
      p0fx.value = sx / ts.length - boxW.value / 2;
      p0fy.value = sy / ts.length - boxH.value / 2;
      pfx.value = p0fx.value;
      pfy.value = p0fy.value;
      pinchMuted.value = false;
    })
    .onTouchesUp((e) => {
      // Queda 1 dedo (o ninguno): el pellizco termina AQUI, como en WhatsApp.
      // Sin esto RNGH seguiria mandando updates con el foco en el dedo
      // restante y la imagen daria el salto.
      if (e.numberOfTouches <= 1) pinchMuted.value = true;
    })
    .onStart((e) => {
      pinchMuted.value = false;
      p0s.value = Math.max(0.01, scale.value);
      p0x.value = tx.value;
      p0y.value = ty.value;
      p0e.value = e.scale > 0 ? e.scale : 1;
      p0fx.value = e.focalX - boxW.value / 2;
      p0fy.value = e.focalY - boxH.value / 2;
      pfx.value = p0fx.value;
      pfy.value = p0fy.value;
    })
    .onUpdate((e) => {
      lastE.value = e.scale;
      if (pinchMuted.value) return;
      const fx = e.focalX - boxW.value / 2;
      const fy = e.focalY - boxH.value / 2;
      // Red de seguridad: el foco no puede teletransportarse de un frame a
      // otro; si salta >150px es el artefacto de levantar un dedo -> callar.
      // (La defensa principal es onTouchesUp; esto cubre rutas exoticas.)
      const jx = fx - pfx.value;
      const jy = fy - pfy.value;
      if (jx * jx + jy * jy > 22500) { pinchMuted.value = true; return; }
      pfx.value = fx;
      pfy.value = fy;
      const s0 = p0s.value;
      if (s0 <= 0) return;
      const next = clamp(s0 * (e.scale / p0e.value), MINZ, MAXZ);
      const ratio = next / s0;
      scale.value = next;
      // t = f − (f₀ − t₀)·ratio: el contenido que estaba bajo el foco inicial
      // sigue bajo el foco actual (zoom + traslado de dos dedos exactos),
      // topado a los bordes reales: nada se sale y "vuelve" al soltar.
      const b = bounds(next);
      tx.value = clamp(fx - (p0fx.value - p0x.value) * ratio, -b.maxX, b.maxX);
      ty.value = clamp(fy - (p0fy.value - p0y.value) * ratio, -b.maxY, b.maxY);
    })
    .onEnd(() => {
      if (scale.value <= 1.02) resetZoom();
      else snapToBounds();
    });

  /* ── Arrastre: pan con zoom / paging y cierre sin zoom ── */
  const pan = Gesture.Pan()
    .maxPointers(1)          // a dos dedos manda el pellizco
    .minDistance(6)
    .onStart(() => {
      s0x.value = tx.value;
      s0y.value = ty.value;
    })
    .onUpdate((e) => {
      if (scale.value > 1.02) {
        const b = bounds(scale.value);
        tx.value = clamp(s0x.value + e.translationX, -b.maxX, b.maxX);
        ty.value = clamp(s0y.value + e.translationY, -b.maxY, b.maxY);
      } else {
        // Sin zoom: la foto sigue al dedo (goma si no hay más fotos o arriba)
        tx.value = urls.length > 1 ? e.translationX : e.translationX * 0.3;
        ty.value = e.translationY > 0 ? e.translationY : e.translationY * 0.3;
      }
    })
    .onEnd((e, success) => {
      if (!success) return;                 // cancelado por el pellizco
      if (scale.value > 1.02) { snapToBounds(); return; }
      const dx = e.translationX;
      const dy = e.translationY;
      if (dy > 110 || e.velocityY > 900) { runOnJS(onClose)(); return; }
      if (urls.length > 1 && Math.abs(dx) > Math.abs(dy)
          && (Math.abs(dx) > boxW.value * 0.28 || Math.abs(e.velocityX) > 650)) {
        runOnJS(goIdx)(idx + (dx < 0 ? 1 : -1));
        return;
      }
      springHome();
    });

  /* ── Doble toque: 2.5x en el punto tocado / vuelta a 1x ── */
  const doubleTap = Gesture.Tap()
    .numberOfTaps(2)
    .maxDuration(250)
    .maxDelay(250)
    .onEnd((e) => {
      if (scale.value > 1.02) { resetZoom(); return; }
      const s0 = Math.max(0.01, scale.value);
      const next = 2.5;
      const ratio = next / s0;
      const ex = e.x - boxW.value / 2;
      const ey = e.y - boxH.value / 2;
      const b = bounds(next);
      scale.value = withTiming(next, { duration: 220 });
      tx.value = withTiming(clamp(ex - (ex - tx.value) * ratio, -b.maxX, b.maxX), { duration: 220 });
      ty.value = withTiming(clamp(ey - (ey - ty.value) * ratio, -b.maxY, b.maxY), { duration: 220 });
    });

  const composed = Gesture.Simultaneous(pinch, pan, doubleTap);

  const imgStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: tx.value },
      { translateY: ty.value },
      { scale: scale.value },
    ],
  }));
  // El fondo se atenúa mientras arrastras hacia abajo para cerrar:
  const bgStyle = useAnimatedStyle(() => ({
    opacity: scale.value > 1.02
      ? 0.96
      : interpolate(ty.value, [0, 320], [0.96, 0.3], 'clamp'),
  }));

  // Compartir: panel del sistema (incluye "Guardar imagen"). Android exige
  // file:// con nombre SIN caracteres escapados y un MIME de imagen: si el
  // tipo acaba en */* muchos destinos ni aparecen. Se comparte una COPIA con
  // nombre limpio y extensión real (los cachés antiguos se llamaban .img).
  const compartir = async () => {
    try {
      const u = urls[idx];
      const local = originalCache.get(cleanMediaUrl(u)) || (await cachedOriginal(u));
      if (!local || !(await Sharing.isAvailableAsync())) return;
      const ext = extImg(u);
      const copia = (FileSystem.cacheDirectory || FileSystem.documentDirectory) + `imagen-${Date.now()}${ext}`;
      await FileSystem.copyAsync({ from: local, to: copia });
      const tipo = `image/${ext === '.jpg' ? 'jpeg' : ext.slice(1)}`;
      await Sharing.shareAsync(copia, { dialogTitle: 'Compartir imagen', mimeType: tipo });
      // NO se borra la copia al resolver: el destinatario puede leer el
      // content:// después de cerrar el panel. La caché del sistema la limpia.
    } catch (e) {
      Alert.alert(
        locale().startsWith('es') ? 'No se pudo compartir' : 'Could not share',
        e?.message || String(e)
      );
    }
  };

  /* Barra superior NEGRA estilo WhatsApp (cerrar + compartir): se desliza
     fuera de pantalla y se desvanece en cuanto hay zoom, y vuelve sola al
     regresar a 1x. La animación vive en el hilo de UI (useAnimatedStyle). */
  const barStyle = useAnimatedStyle(() => {
    const vis = scale.value <= 1.02;
    return {
      opacity: withTiming(vis ? 1 : 0, { duration: 150 }),
      transform: [{ translateY: withTiming(vis ? 0 : -170, { duration: 220 }) }],
    };
  });

  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose}>
      {/* Android: el Modal abre una ventana nativa aparte; los gestos
          necesitan su propio GestureHandlerRootView dentro. */}
      <GestureHandlerRootView style={{ flex: 1 }}>
        <View
          style={{ flex: 1 }}
          onLayout={(e) => {
            const { width, height } = e.nativeEvent.layout;
            if (width > 0 && height > 0) { boxW.value = width; boxH.value = height; }
          }}
        >
          <Reanimated.View style={[{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#000' }, bgStyle]} />
          {uri ? (
            <GestureDetector gesture={composed}>
              <AnimatedImage
                source={{ uri }}
                style={[{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }, imgStyle]}
                contentFit="contain"
                cachePolicy="memory-disk"
                onLoad={(e) => {
                  const w = (e && e.source && e.source.width) || 0;
                  const h = (e && e.source && e.source.height) || 0;
                  if (w > 0 && h > 0) { imgW.value = w; imgH.value = h; }
                }}
              />
            </GestureDetector>
          ) : (
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
              <ActivityIndicator color="#fff" />
            </View>
          )}
          {/* Barra superior NEGRA: cerrar + compartir, SIN numeración de
              fotos. Se oculta sola con un poco de zoom y vuelve a 1x. */}
          <Reanimated.View pointerEvents="box-none" style={[{ position: 'absolute', top: 0, left: 0, right: 0, zIndex: 3, backgroundColor: '#000000', paddingTop: Math.max(insets.top, 24) + 8, paddingBottom: 10, paddingHorizontal: 8, flexDirection: 'row', alignItems: 'center' }, barStyle]}>
            <TouchableOpacity onPress={onClose} style={{ padding: 10 }} hitSlop={6}><Ionicons name="close" size={28} color="#fff" /></TouchableOpacity>
            <View style={{ flex: 1 }} />
            <TouchableOpacity onPress={compartir} style={{ padding: 10 }} hitSlop={6}><Ionicons name="share-outline" size={25} color="#fff" /></TouchableOpacity>
          </Reanimated.View>
        </View>
      </GestureHandlerRootView>
      <SystemBars />
    </Modal>
  );
}