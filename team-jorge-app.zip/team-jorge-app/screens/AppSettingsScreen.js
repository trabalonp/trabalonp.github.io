// screens/AppSettingsScreen.js
// ─────────────────────────────────────────────────────────────────────────────
// REDISEÑO VISUAL + ANIMACIONES.
// La lógica (idioma/unidades/formato de fecha, fondo del Tablón, purga local,
// borrado de notificaciones en Firestore, actualizar ajustes) es la MISMA que
// la versión original. Solo cambia la capa visual. Sin dependencias nuevas.
// ─────────────────────────────────────────────────────────────────────────────
import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, Animated, Easing, Modal, Pressable, ScrollView,
  StyleSheet, Text, View, useColorScheme,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { getSocialBg, setSocialBg, clearSocialBg } from '../services/socialBg';
import { purgeTablonLocal, tablonLocalStats } from '../services/tablonPurge';
import { useNavigation } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import SystemBars from '../components/SystemBars';
import { getThemeColors, loadSettings, saveSettings, t, useAppSettings } from '../services/appSettings';
import { auth, db } from '../firebaseConfig';
import { collection, getDocs, limit, query, writeBatch } from 'firebase/firestore';

const NAVY = '#0D1B2A', BLUE = '#4A90E2', BORDER = '#1E3048';
const GREEN = '#2DB37A', AMBER = '#F5A623', PURPLE = '#A78BFA', RED = '#E5484D';

const PICKER_TITLES = {
  language: 'appsettings.language',
  units: 'appsettings.units',
  dateFormat: 'appsettings.dateFormat',
};

/* ════════════════════════════════════════════════════════════════════════════
   COMPONENTES VISUALES / ANIMADOS
   ════════════════════════════════════════════════════════════════════════════ */

// Aparece con fundido + deslizamiento (entrada escalonada con `delay`)
function FadeIn({ delay = 0, children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, {
      toValue: 1, duration: 450, delay,
      easing: Easing.out(Easing.cubic), useNativeDriver: true,
    }).start();
  }, [v, delay]);
  return (
    <Animated.View
      style={[style, {
        opacity: v,
        transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [18, 0] }) }],
      }]}
    >
      {children}
    </Animated.View>
  );
}

// Zona pulsable con efecto "muelle"
function PressableScale({ onPress, disabled, style, children, hitSlop }) {
  const sc = useRef(new Animated.Value(1)).current;
  const to = (value) =>
    Animated.spring(sc, { toValue: value, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      hitSlop={hitSlop}
      onPressIn={() => to(0.96)}
      onPressOut={() => to(1)}
    >
      <Animated.View style={[style, { transform: [{ scale: sc }] }]}>{children}</Animated.View>
    </Pressable>
  );
}

// Valor animado 0→1 en bucle
function useLoop(duration, active = true, easing = Easing.linear) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!active) { v.setValue(0); return undefined; }
    const loop = Animated.loop(
      Animated.timing(v, { toValue: 1, duration, easing, useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, [v, duration, active, easing]);
  return v;
}

// Destello que cruza el botón principal cada pocos segundos
function Shine() {
  const [w, setW] = useState(0);
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(v, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.delay(2600),
        Animated.timing(v, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [v]);
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      <Animated.View
        style={[st.shine, {
          transform: [
            { translateX: v.interpolate({ inputRange: [0, 1], outputRange: [-60, w + 60] }) },
            { rotate: '20deg' },
          ],
        }]}
      />
    </View>
  );
}

// Título de sección
function SectionLabel({ children, color, theme }) {
  return (
    <View style={st.sectionLabelRow}>
      <View style={[st.sectionBar, { backgroundColor: color }]} />
      <Text style={[st.sectionLabel, { color: theme.text }]}>{children}</Text>
    </View>
  );
}

// Fila de ajuste (dentro de una tarjeta de grupo)
function Row({ icon, color = BLUE, label, sub, value, onPress, theme, loading, disabled, last }) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        st.row,
        !last && { borderBottomWidth: 1, borderBottomColor: theme.border },
        pressed && { backgroundColor: color + '14' },
        disabled && { opacity: 0.6 },
      ]}
    >
      <View style={[st.rowIcon, { backgroundColor: color + '22', borderColor: color + '55' }]}>
        <Ionicons name={icon} size={19} color={color} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[st.rowLabel, { color: theme.text }]}>{label}</Text>
        {!!sub && <Text style={[st.rowSub, { color: theme.muted }]}>{sub}</Text>}
      </View>
      {!!value && (
        <View style={[st.valuePill, { backgroundColor: color + '1F' }]}>
          <Text style={[st.rowValue, { color }]} numberOfLines={1}>{value}</Text>
        </View>
      )}
      {loading
        ? <ActivityIndicator size="small" color={color} />
        : <Ionicons name="chevron-forward" size={16} color="#4A6080" />}
    </Pressable>
  );
}

// Check que "salta" al aparecer
function PopCheck() {
  const sc = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.spring(sc, { toValue: 1, useNativeDriver: true, speed: 18, bounciness: 14 }).start();
  }, [sc]);
  return (
    <Animated.View style={{ transform: [{ scale: sc }] }}>
      <Ionicons name="checkmark-circle" size={22} color={BLUE} />
    </Animated.View>
  );
}

// Caja del selector: entra con un pequeño rebote
function PickerBox({ theme, title, options, current, onChoose }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.spring(v, { toValue: 1, useNativeDriver: true, speed: 16, bounciness: 9 }).start();
  }, [v]);
  return (
    <Animated.View
      style={[
        st.pickerBox,
        { backgroundColor: theme.card, borderColor: theme.border, opacity: v,
          transform: [
            { translateY: v.interpolate({ inputRange: [0, 1], outputRange: [30, 0] }) },
            { scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1] }) },
          ] },
      ]}
    >
      <View style={st.pickerHandle} />
      <Text style={[st.pickerTitle, { color: theme.text }]}>{title}</Text>
      <ScrollView bounces={false} style={st.pickerScroll}>
        {options.map((o) => {
          const active = current === o.value;
          return (
            <Pressable
              key={o.value}
              onPress={() => onChoose(o.value)}
              style={({ pressed }) => [
                st.opt,
                { borderColor: active ? BLUE : 'transparent', backgroundColor: active ? BLUE + '1F' : pressed ? theme.input : 'transparent' },
              ]}
            >
              <Text style={[st.optText, { color: theme.text }, active && st.optTextActive]}>{o.label}</Text>
              {active
                ? <PopCheck />
                : <View style={[st.radio, { borderColor: theme.border }]} />}
            </Pressable>
          );
        })}
      </ScrollView>
    </Animated.View>
  );
}

/* ════════════════════════════════════════════════════════════════════════════
   PANTALLA
   ════════════════════════════════════════════════════════════════════════════ */
export default function AppSettingsScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const [picker, setPicker] = useState(null); // 'language' | 'units' | 'dateFormat'

  const lang = settings.language;
  const L = (es, en) => (lang === 'en' ? en : es);

  // Fondo del Tablón: 100% local (nunca se sube a la nube)
  const [bgSet, setBgSet] = useState(false);

  // Memoria local del Tablón (mensajes + imágenes + avatares en el teléfono)
  const [cacheInfo, setCacheInfo] = useState(null);
  const [clearingNotifications, setClearingNotifications] = useState(false);
  const [updating, setUpdating] = useState(false); // solo visual: gira el icono al actualizar
  const fmtMB = (b) => (b < 1048576 ? `${Math.max(1, Math.round(b / 1024))} KB` : `${(b / 1048576).toFixed(1)} MB`);
  const refreshCacheInfo = () => { tablonLocalStats().then(setCacheInfo).catch(() => {}); };
  useEffect(() => { refreshCacheInfo(); }, []);
  const handlePurge = () => {
    const s = cacheInfo || { msgs: 0, bytes: 0 };
    Alert.alert(
      L('Limpiar memoria del Tablón', 'Clear Chat storage'),
      L(`Se borrarán de ESTE teléfono ${s.msgs} mensajes y ~${fmtMB(s.bytes)} de imágenes/avatares caché del chat. No se pierde nada de nadie: el historial vive en la nube y al abrir el Tablón se resincroniza solo. Tu fondo y tus ajustes se conservan.`,
        `This phone will delete ${s.msgs} messages and ~${fmtMB(s.bytes)} of cached chat images/avatars. Nothing is lost for anyone: history lives in the cloud and re-syncs on open. Your background and settings are kept.`),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Limpiar ahora', 'Clear now'), style: 'destructive',
          onPress: async () => {
            try {
              const r = await purgeTablonLocal();
              refreshCacheInfo();
              Alert.alert(L('Memoria limpiada', 'Storage cleared'),
                L(`Se liberaron ~${fmtMB(r.bytes)}. Al entrar en el Tablón se volverán a descargar los mensajes recientes.`,
                  `Freed ~${fmtMB(r.bytes)}. Recent messages will download again when you open the Chat.`));
            } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
          },
        },
      ]);
  };
  const handleClearNotifications = () => {
    if (clearingNotifications) return;
    Alert.alert(
      L('Limpiar notificaciones', 'Clear notifications'),
      L('Se eliminará todo el historial de notificaciones de tu cuenta. Esta acción no se puede deshacer.', 'All notifications in your account will be deleted. This cannot be undone.'),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Eliminar todas', 'Delete all'), style: 'destructive',
          onPress: async () => {
            const uid = auth.currentUser?.uid;
            if (!uid) return;
            setClearingNotifications(true);
            try {
              let total = 0;
              const ref = collection(db, 'perfiles', uid, 'notificaciones');
              while (true) {
                const snap = await getDocs(query(ref, limit(450)));
                if (snap.empty) break;
                const batch = writeBatch(db);
                snap.docs.forEach((item) => batch.delete(item.ref));
                await batch.commit();
                total += snap.size;
                if (snap.size < 450) break;
              }
              Alert.alert(L('Notificaciones eliminadas', 'Notifications deleted'), L(`Se han eliminado ${total} notificaciones.`, `${total} notifications were deleted.`));
            } catch (e) {
              Alert.alert(L('Error', 'Error'), e.message || L('No se pudieron eliminar las notificaciones.', 'Notifications could not be deleted.'));
            } finally {
              setClearingNotifications(false);
            }
          },
        },
      ],
    );
  };
  useEffect(() => { (async () => { try { setBgSet(!!(await getSocialBg())); } catch (e) {} })(); }, []);
  const pickBg = async () => {
    // quality: 1 -> la imagen se guarda TAL CUAL se subió (sin recomprimir)
    const r = await ImagePicker.launchImageLibraryAsync({ quality: 1 });
    if (r.canceled || !r.assets?.length) return;
    try { await setSocialBg(r.assets[0].uri); setBgSet(true); } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };
  const removeBg = async () => { await clearSocialBg(); setBgSet(false); };
  const handleBg = () => {
    const opts = [];
    if (bgSet) opts.push({ text: L('Quitar fondo', 'Remove background'), style: 'destructive', onPress: removeBg });
    opts.push({ text: bgSet ? L('Cambiar imagen', 'Change image') : L('Elegir imagen', 'Choose image'), onPress: pickBg });
    opts.push({ text: L('Cancelar', 'Cancel'), style: 'cancel' });
    Alert.alert(L('Fondo del Tablón', 'Chat background'),
      L('La imagen se guarda SOLO en tu teléfono; nunca se sube a la nube.',
        'The image is stored ONLY on your phone; never uploaded to the cloud.'), opts);
  };

  // OPTIONS dentro del componente: las etiquetas traducidas se recalculan al cambiar idioma.
  // Idioma y unidades quedan literales a propósito (se entienden en ambos idiomas).
  const OPTIONS = {
    language: [
      { value: 'es', label: 'Español' },
      { value: 'en', label: 'English' },
    ],
    units: [
      { value: 'metric',   label: t('units.metric')   },
      { value: 'imperial', label: t('units.imperial') },
    ],
    dateFormat: [
      { value: 'largo',      label: t('fmt.largo')      },
      { value: 'dd/mm/yyyy', label: t('fmt.ddmmyyyy')   },
      { value: 'mm/dd/yyyy', label: t('fmt.mmddyyyy')   },
      { value: 'yyyy-mm-dd', label: t('fmt.yyyymmdd')   },
    ],
  };

  const currentLabel = (key) => {
    const opt = (OPTIONS[key] || []).find(o => o.value === settings[key]);
    return opt ? opt.label : '';
  };
  const choose = (value) => {
    saveSettings({ [picker]: value });
    setPicker(null);
  };
  const handleUpdate = async () => {
    await loadSettings();
    Alert.alert(t('appsettings.updated'), t('appsettings.updatedMsg'));
  };
  // Envoltorio visual: hace girar el icono mientras se actualiza
  const onUpdatePress = async () => {
    setUpdating(true);
    try { await handleUpdate(); } finally { setUpdating(false); }
  };

  const spin = useLoop(900, updating);

  const cardStyle = [st.card, { backgroundColor: theme.card, borderColor: theme.border }];

  return (
    <View style={[st.container, { backgroundColor: theme.background }]}>
      <View style={[st.header, { borderBottomColor: theme.border, paddingTop: insets.top + 10 }]}>
        <PressableScale
          onPress={() => navigation.goBack()}
          style={[st.backBtn, { backgroundColor: theme.card, borderColor: theme.border }]}
          hitSlop={10}
        >
          <Ionicons name="chevron-back" size={22} color="#8FA8C8" />
        </PressableScale>
        <Text style={[st.headerTitle, { color: theme.text }]}>{t('appsettings.title')}</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        contentContainerStyle={[st.scroll, { paddingBottom: Math.max(40, insets.bottom + 16) }]}
        showsVerticalScrollIndicator={false}
      >
        {/* ══════════ GENERAL ══════════ */}
        <FadeIn>
          <SectionLabel color={BLUE} theme={theme}>{L('General', 'General')}</SectionLabel>
          <View style={cardStyle}>
            <Row
              icon="language-outline"
              color={BLUE}
              label={t('appsettings.language')}
              value={currentLabel('language')}
              onPress={() => setPicker('language')}
              theme={theme}
            />
            <Row
              icon="swap-horizontal-outline"
              color={GREEN}
              label={t('appsettings.units')}
              value={currentLabel('units')}
              onPress={() => setPicker('units')}
              theme={theme}
            />
            <Row
              icon="calendar-outline"
              color={AMBER}
              label={t('appsettings.dateFormat')}
              value={currentLabel('dateFormat')}
              onPress={() => setPicker('dateFormat')}
              theme={theme}
              last
            />
          </View>
        </FadeIn>

        {/* ══════════ TABLÓN ══════════ */}
        <FadeIn delay={220}>
          <SectionLabel color={PURPLE} theme={theme}>{L('Tablón', 'Chat')}</SectionLabel>
          <View style={cardStyle}>
            <Row
              icon="image-outline"
              color={PURPLE}
              label={L('Fondo del Tablón', 'Chat background')}
              value={bgSet ? L('Puesto', 'Set') : L('Sin poner', 'Not set')}
              onPress={handleBg}
              theme={theme}
            />
            {/* Purga local del chat: borra SOLO lo guardado en este teléfono */}
            <Row
              icon="trash-bin-outline"
              color={RED}
              label={L('Limpiar memoria del Tablón', 'Clear Chat storage')}
              sub={L('Mensajes, imágenes y avatares guardados en este teléfono', 'Messages, images & avatars stored on this phone')}
              value={cacheInfo ? `${cacheInfo.msgs} ${L('msgs', 'msgs')} · ${fmtMB(cacheInfo.bytes)}` : '…'}
              onPress={handlePurge}
              theme={theme}
              last
            />
          </View>
        </FadeIn>

        {/* ══════════ CUENTA ══════════ */}
        <FadeIn delay={320}>
          <SectionLabel color={RED} theme={theme}>{L('Cuenta', 'Account')}</SectionLabel>
          <View style={[cardStyle, { borderColor: RED + '44' }]}>
            <Row
              icon="notifications-off-outline"
              color={RED}
              label={L('Limpiar todas las notificaciones', 'Clear all notifications')}
              sub={L('Elimina el historial de notificaciones de tu cuenta', 'Delete your notification history')}
              onPress={handleClearNotifications}
              loading={clearingNotifications}
              disabled={clearingNotifications}
              theme={theme}
              last
            />
          </View>
        </FadeIn>

        {/* ══════════ ACTUALIZAR ══════════ */}
        <FadeIn delay={420}>
          <PressableScale onPress={onUpdatePress} disabled={updating} style={st.updateBtn}>
            <Shine />
            <Animated.View
              style={updating ? { transform: [{ rotate: spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] }) }] } : null}
            >
              <Ionicons name="refresh" size={19} color="#fff" />
            </Animated.View>
            <Text style={st.updateBtnText}>{t('appsettings.update')}</Text>
          </PressableScale>
        </FadeIn>
      </ScrollView>

      {/* Modal de selección: lista completa de opciones con check en la activa */}
      <Modal visible={!!picker} transparent animationType="fade" onRequestClose={() => setPicker(null)}>
        <View style={st.overlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setPicker(null)} />
          {!!picker && (
            <PickerBox
              theme={theme}
              title={t(PICKER_TITLES[picker])}
              options={OPTIONS[picker] || []}
              current={settings[picker]}
              onChoose={choose}
            />
          )}
        </View>
        <SystemBars />
      </Modal>
    </View>
  );
}

/* ════════════════════════════════════════════════════════════════════════════
   ESTILOS
   ════════════════════════════════════════════════════════════════════════════ */
const st = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },

  // Cabecera
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingBottom: 12,
    borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  backBtn: {
    width: 40, height: 40, borderRadius: 20, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
  },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  scroll: { padding: 16, gap: 22 },

  // Secciones
  sectionLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  sectionBar: { width: 4, height: 18, borderRadius: 2 },
  sectionLabel: { fontSize: 15, fontWeight: '800' },
  card: { borderRadius: 20, borderWidth: 1, overflow: 'hidden' },

  // Filas
  row: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    paddingHorizontal: 14, paddingVertical: 14,
  },
  rowIcon: {
    width: 38, height: 38, borderRadius: 12, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
  },
  rowLabel: { fontSize: 15, fontWeight: '700' },
  rowSub: { fontSize: 12, marginTop: 2, lineHeight: 16 },
  valuePill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, maxWidth: 150 },
  rowValue: { fontSize: 12, fontWeight: '700' },

  // Botón actualizar
  updateBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    backgroundColor: BLUE, borderRadius: 16, paddingVertical: 16, overflow: 'hidden',
  },
  updateBtnText: { color: '#fff', fontSize: 15, fontWeight: '800' },
  shine: {
    position: 'absolute', top: -30, height: 120, width: 28,
    backgroundColor: 'rgba(255,255,255,0.20)',
  },

  // Modal selector
  overlay: { flex: 1, backgroundColor: '#000000AA', justifyContent: 'center', alignItems: 'center' },
  pickerBox: {
    width: '84%', borderRadius: 24, borderWidth: 1,
    overflow: 'hidden', paddingBottom: 10, zIndex: 10,
  },
  pickerHandle: {
    alignSelf: 'center', width: 40, height: 4, borderRadius: 2,
    backgroundColor: '#4A6080', marginTop: 10,
  },
  pickerTitle: { fontSize: 16, fontWeight: '800', paddingHorizontal: 18, paddingTop: 14, paddingBottom: 10 },
  pickerScroll: { maxHeight: 340, paddingHorizontal: 10 },
  opt: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 14, paddingVertical: 14, marginBottom: 6,
    borderRadius: 14, borderWidth: 1.5,
  },
  optText: { fontSize: 14 },
  optTextActive: { fontWeight: '800' },
  radio: { width: 20, height: 20, borderRadius: 10, borderWidth: 2 },
});