// screens/DonationScreen.js
/* Pantalla de donaciones SIN botón ni redirección: solo un diseño bonito
   que explica que, si te gusta la app, puedes contribuir. Basado en el
   diseño "héroe con corazón orbitado" (react-native-svg ya está en la app).
   • La cabecera respeta el inset superior y el contenido el inferior, para
     que ni la barra de estado ni los botones de Android tapen nada.
   • Paleta adaptativa: claro (la del diseño) y oscuro (tema de la app). */
import React, { useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Animated, Easing, useColorScheme,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Svg, { Circle, Path, G, Rect, Ellipse } from 'react-native-svg';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getThemeColors, useAppSettings } from '../services/appSettings';

/* Corazón centrado en (0,0) y destello de 4 puntas */
const HEART = 'M0 8 C-14 -2 -10 -14 -4 -14 C-1 -14 0 -11 0 -9 C0 -11 1 -14 4 -14 C10 -14 14 -2 0 8Z';
const SPARKLE = 'M0 -8 L2 -2 L8 0 L2 2 L0 8 L-2 2 L-8 0 L-2 -2Z';

/* ── HÉROE: corazón con círculos concéntricos e iconos orbitando (latido) ── */
// Latido compartido a nivel de módulo (la pantalla es única): así el lint
// del compilador de React no ve accesos a refs durante el render.
const PULSE = new Animated.Value(0);

function Hero({ C }) {
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(PULSE, { toValue: 1, duration: 1400, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(PULSE, { toValue: 0, duration: 1400, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, []);
  const scale = PULSE.interpolate({ inputRange: [0, 1], outputRange: [1, 1.04] });

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <Svg width={280} height={260} viewBox="0 0 280 260">
        <Circle cx={140} cy={130} r={112} fill="none" stroke={C.ringDash} strokeWidth={1.5} strokeDasharray="3 7" />
        <Circle cx={140} cy={130} r={92} fill={C.blue100} />
        <Circle cx={140} cy={130} r={68} fill={C.blue200} />
        <Circle cx={140} cy={130} r={46} fill={C.blue300} />
        <G transform="translate(140 133) scale(4.2)">
          <Path d={HEART} fill={C.blue} stroke={C.blueDark} strokeWidth={0.6} />
        </G>
        <Ellipse cx={120} cy={108} rx={9} ry={5} fill="#FFFFFF" opacity={0.7} transform="rotate(-35 120 108)" />

        {/* satélites: mancuerna, corazón rosa, rayo, destello, corazón, diana */}
        <G transform="translate(62 55)">
          <Circle r={19} fill={C.white} stroke={C.ringDash} strokeWidth={1.5} />
          <Path d="M-9 0 H9" stroke={C.ink} strokeWidth={2.5} strokeLinecap="round" />
          <Rect x={-12} y={-7} width={4} height={14} rx={1.5} fill={C.blue} />
          <Rect x={8} y={-7} width={4} height={14} rx={1.5} fill={C.blue} />
        </G>
        <G transform="translate(218 55)">
          <Circle r={19} fill={C.white} stroke={C.ringDash} strokeWidth={1.5} />
          <G transform="scale(1.1)"><Path d={HEART} fill={C.pink} /></G>
        </G>
        <G transform="translate(28 137)">
          <Circle r={17} fill={C.white} stroke={C.ringDash} strokeWidth={1.5} />
          <Path d="M-3 -9 L-8 2 H-1 L-3 9 L6 -3 H0 L3 -9Z" fill={C.yellow} />
        </G>
        <G transform="translate(252 137)">
          <Circle r={17} fill={C.white} stroke={C.ringDash} strokeWidth={1.5} />
          <Path d={SPARKLE} fill={C.mint} />
        </G>
        <G transform="translate(70 211)">
          <Circle r={14} fill={C.white} stroke={C.ringDash} strokeWidth={1.5} />
          <G transform="scale(0.75)"><Path d={HEART} fill={C.blue} /></G>
        </G>
        <G transform="translate(210 211)">
          <Circle r={14} fill={C.white} stroke={C.ringDash} strokeWidth={1.5} />
          <Circle r={6} fill="none" stroke={C.ink} strokeWidth={2} />
          <Circle r={1.8} fill={C.ink} />
        </G>

        {/* confeti */}
        <Circle cx={36} cy={55} r={4} fill={C.yellow} />
        <Circle cx={228} cy={32} r={5} fill={C.pink} />
        <Circle cx={24} cy={205} r={3} fill={C.blue} />
        <Circle cx={244} cy={222} r={4} fill={C.mint} />
        <G transform="translate(44 105)"><Path d={SPARKLE} fill={C.yellow} /></G>
        <G transform="translate(240 100) scale(0.8)"><Path d={SPARKLE} fill={C.blue} /></G>
        <Path d="M26 162 l6 -6 l6 6" fill="none" stroke={C.pink} strokeWidth={2} strokeLinecap="round" />
        <Path d="M226 168 l6 6 l6 -6" fill="none" stroke={C.yellow} strokeWidth={2} strokeLinecap="round" />
      </Svg>
    </Animated.View>
  );
}

/* ── Subrayado ondulado bajo el título ── */
function Squiggle({ C }) {
  return (
    <Svg width={80} height={12} viewBox="0 0 80 12">
      <Path d="M0 6 q10 -8 20 0 t20 0 t20 0 t20 0" fill="none" stroke={C.blue} strokeWidth={3} strokeLinecap="round" />
    </Svg>
  );
}

/* ── Iconos de las tarjetas ── */
const ServerIcon = ({ C }) => (
  <Svg width={20} height={20} viewBox="0 0 20 20">
    <Rect x={1} y={2} width={18} height={7} rx={2} fill={C.blue} />
    <Rect x={1} y={11} width={18} height={7} rx={2} fill={C.blueDark} />
    <Circle cx={5} cy={5.5} r={1.2} fill="#FFFFFF" />
    <Circle cx={5} cy={14.5} r={1.2} fill="#FFFFFF" />
  </Svg>
);
const ArrowUpIcon = ({ C }) => (
  <Svg width={20} height={20} viewBox="0 0 20 20">
    <Path d="M10 17 V3 M4 9 L10 3 L16 9" fill="none" stroke={C.pink} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
const SparkleIcon = ({ C }) => (
  <Svg width={22} height={22} viewBox="0 0 20 20">
    <Path d="M10 1 L12.5 7.5 L19 10 L12.5 12.5 L10 19 L7.5 12.5 L1 10 L7.5 7.5Z" fill={C.mint} />
  </Svg>
);
const InfoCard = ({ C, bg, icon, line1, line2 }) => (
  <View style={[st.card, { backgroundColor: C.card, borderColor: C.line }]}>
    <View style={[st.cardIcon, { backgroundColor: bg }]}>{icon}</View>
    <Text style={[st.cardTitle, { color: C.ink }]}>{line1}</Text>
    <Text style={[st.cardSub, { color: C.text }]}>{line2}</Text>
  </View>
);

/* ── Olas decorativas del pie ── */
function Waves({ C }) {
  return (
    <View pointerEvents="none" style={st.waves}>
      <Svg width="100%" height="100%" viewBox="0 0 360 110" preserveAspectRatio="none">
        <Path d="M0 32 C60 4 120 64 180 34 C240 6 300 64 360 28 L360 110 L0 110 Z" fill={C.wave1} />
        <Path d="M0 60 C70 34 130 88 190 60 C250 32 310 82 360 56 L360 110 L0 110 Z" fill={C.wave2} />
        <Path d="M0 84 C80 64 140 104 200 84 C260 64 310 96 360 80 L360 110 L0 110 Z" fill={C.wave3} />
      </Svg>
    </View>
  );
}

export default function DonationScreen({ navigation }) {
  const appSettings = useAppSettings();
  const lang = appSettings.language;
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const L = (es, en) => (lang === 'en' ? en : es);
  const insets = useSafeAreaInsets();
  const oscuro = theme.background !== '#F4F7FB';   // mismo detector que usaba la pantalla

  // Paleta: clara = la del diseño; oscura = adaptada al tema de la app.
  const C = oscuro ? {
    ink: theme.text, text: theme.muted,
    blue: '#4A90E2', blueDark: '#2F6DBF',
    blue100: '#16283E', blue200: '#1B3048', blue300: '#24405F',
    line: theme.border, ringDash: '#3D5A80',
    card: theme.card, back: '#6B9BD6',
    wave1: '#142638', wave2: '#1B334F', wave3: '#2B5A8F',
    pink: '#FF6B81', yellow: '#F5B942', mint: '#3CC8A5', white: '#162032',
  } : {
    ink: '#12233D', text: '#5B6B82',
    blue: '#4A90E2', blueDark: '#2F6DBF',
    blue100: '#E3EEFF', blue200: '#CFE1FB', blue300: '#B9D4F7',
    line: '#D6E4F8', ringDash: '#9CC0F0',
    card: '#FFFFFF', back: '#6B9BD6',
    wave1: '#DCEAFC', wave2: '#B9D4F7', wave3: '#4A90E2',
    pink: '#FF6B81', yellow: '#F5B942', mint: '#3CC8A5', white: '#FFFFFF',
  };

  return (
    <View style={[st.safe, { backgroundColor: theme.background }]}>
      {/* aros decorativos de fondo */}
      <View pointerEvents="none" style={[st.ring, st.ringTop, { borderColor: C.blue100 }]} />
      <View pointerEvents="none" style={[st.ring, st.ringLeft, { borderColor: C.blue100 }]} />
      <View pointerEvents="none" style={[st.ring, st.ringRight, { borderColor: C.blue100 }]} />

      {/* cabecera: respeta la barra de estado (inset superior) */}
      <View style={[st.header, { paddingTop: Math.max(insets.top, 8) + 8, borderBottomColor: C.line }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={st.backBtn} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
          <Ionicons name="chevron-back" size={24} color={C.back} />
        </TouchableOpacity>
        <Text style={[st.headerTitle, { color: C.ink }]}>{L('Donaciones', 'Donations')}</Text>
        <View style={st.backBtn} />
      </View>

      <ScrollView contentContainerStyle={[st.content, { paddingBottom: 150 + insets.bottom }]} showsVerticalScrollIndicator={false}>
        <Hero C={C} />
        <Text style={[st.title, { color: C.ink }]}>{L('¡Ayúdanos a mantener la app!', 'Help us keep the app alive!')}</Text>
        <Squiggle C={C} />
        <Text style={[st.paragraph, { color: C.text }]}>
          {L(
            'Si te gusta Team Jorge App y quieres contribuir a su desarrollo, puedes hacer una donación.',
            'If you like Team Jorge App and want to support its development, you can make a donation.'
          )}
        </Text>
        <Text style={[st.helpsTitle, { color: C.ink }]}>{L('Tu contribución nos ayuda a', 'Your contribution helps us')}</Text>
        <View style={st.cardsRow}>
          <InfoCard C={C} bg={C.blue100} icon={<ServerIcon C={C} />} line1={L('Cubrir costes', 'Cover server')} line2={L('del servidor', 'costs')} />
          <InfoCard C={C} bg="#FFE9EC" icon={<ArrowUpIcon C={C} />} line1={L('Mejorar', 'Improve')} line2={L('la app', 'the app')} />
          <InfoCard C={C} bg="#E0F7F0" icon={<SparkleIcon C={C} />} line1={L('Añadir nuevas', 'Add new')} line2={L('funciones', 'features')} />
        </View>
        <Text style={[st.thanks, { color: C.ink }]}>{L('¡Muchas gracias por tu apoyo! ❤️', 'Thank you so much for your support! ❤️')}</Text>
      </ScrollView>

      <Waves C={C} />
    </View>
  );
}

const st = StyleSheet.create({
  safe: { flex: 1 },

  // aros de fondo
  ring: { position: 'absolute', borderRadius: 999 },
  ringTop: { top: -70, right: -70, width: 220, height: 220, borderWidth: 14 },
  ringLeft: { top: 360, left: -45, width: 140, height: 140, borderWidth: 12 },
  ringRight: { top: 430, right: -35, width: 100, height: 100, borderWidth: 10 },

  // cabecera
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 14,
    borderBottomWidth: 1,
  },
  backBtn: { width: 28, alignItems: 'flex-start', justifyContent: 'center' },
  headerTitle: { fontSize: 17, fontWeight: '700' },

  // contenido
  content: {
    alignItems: 'center',
    paddingTop: 20,
    paddingHorizontal: 24,
  },
  title: {
    fontSize: 25,
    lineHeight: 31,
    fontWeight: '800',
    textAlign: 'center',
    marginTop: 14,
    marginBottom: 6,
    paddingHorizontal: 16,
  },
  paragraph: {
    fontSize: 15,
    lineHeight: 23,
    textAlign: 'center',
    marginTop: 14,
    paddingHorizontal: 8,
  },
  helpsTitle: {
    fontSize: 15,
    fontWeight: '700',
    marginTop: 22,
    marginBottom: 12,
  },

  // tarjetas
  cardsRow: { flexDirection: 'row', justifyContent: 'center', gap: 10 },
  card: {
    width: 98,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 14,
    borderWidth: 1.5,
  },
  cardIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  cardTitle: { fontSize: 12, fontWeight: '600', textAlign: 'center' },
  cardSub: { fontSize: 12, textAlign: 'center' },

  thanks: {
    fontSize: 15,
    fontWeight: '700',
    marginTop: 26,
    textAlign: 'center',
  },

  // olas del pie (decorativas, no interceptan toques)
  waves: { position: 'absolute', left: 0, right: 0, bottom: 0, height: 110 },
});
