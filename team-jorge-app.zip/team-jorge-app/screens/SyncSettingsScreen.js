// screens/SyncSettingsScreen.js
// ─────────────────────────────────────────────────────────────────────────────
// REDISEÑO VISUAL + ANIMACIONES.
// La lógica (estados, handlers, llamadas a GarminSyncService / SyncService,
// Firebase auth, SAF/FileSystem, AsyncStorage) es la MISMA que la versión
// original. Solo cambia la capa visual. No necesita dependencias nuevas
// (usa Animated / LayoutAnimation de React Native + @expo/vector-icons).
// ─────────────────────────────────────────────────────────────────────────────
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Alert, ActivityIndicator, Linking,
  TextInput, useColorScheme, Animated, Easing, Pressable, LayoutAnimation,
  Platform, UIManager,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as FileSystem from 'expo-file-system/legacy';
import { auth } from '../firebaseConfig';
import { getThemeColors, useAppSettings } from '../services/appSettings';
import { resetSyncFolder, syncFitFiles, recalcularEsfuerzos } from '../services/SyncService';
import {
  getIntervalsStatus,
  saveIntervalsCredentials,
  disconnectIntervals,
} from '../services/GarminSyncService';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const { StorageAccessFramework } = FileSystem;

const NAVY   = '#0D1B2A';
const BLUE   = '#4A90E2';
const GREEN  = '#2DB37A';
const RED    = '#E05252';
const BORDER = '#1E3048';
const AMBER  = '#F5A623';
const FOLDER_KEY = 'fit_folder_uri';

/* ════════════════════════════════════════════════════════════════════════════
   COMPONENTES VISUALES / ANIMADOS
   ════════════════════════════════════════════════════════════════════════════ */

// Aparece con fundido + deslizamiento suave (entrada escalonada con `delay`)
function FadeIn({ delay = 0, children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, {
      toValue: 1, duration: 450, delay,
      easing: Easing.out(Easing.cubic), useNativeDriver: true,
    }).start();
  }, [v, delay]);
  return (
    <Animated.View
      style={[style, {
        opacity: v,
        transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [18, 0] }) }],
      }]}
    >
      {children}
    </Animated.View>
  );
}

// Botón/zona pulsable con efecto "muelle" al presionar
function PressableScale({ onPress, disabled, style, children, hitSlop }) {
  const sc = useRef(new Animated.Value(1)).current;
  const to = (value) =>
    Animated.spring(sc, { toValue: value, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      hitSlop={hitSlop}
      onPressIn={() => to(0.96)}
      onPressOut={() => to(1)}
    >
      <Animated.View style={[style, { transform: [{ scale: sc }] }]}>{children}</Animated.View>
    </Pressable>
  );
}

// Valor animado 0→1 en bucle (para anillos de pulso, puntos viajeros, etc.)
function useLoop(duration, active = true, easing = Easing.linear) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!active) { v.setValue(0); return undefined; }
    const loop = Animated.loop(
      Animated.timing(v, { toValue: 1, duration, easing, useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, [v, duration, active, easing]);
  return v;
}

// Nodo circular del héroe (reloj, nube, móvil)
function HeroNode({ icon, color, label, theme, rings, spin, size = 58 }) {
  const pulse = useLoop(2200, !!rings, Easing.out(Easing.quad));
  const rot = useLoop(1400, !!spin);
  const ringStyle = (phase) => ({
    position: 'absolute', width: size, height: size, borderRadius: size / 2,
    borderWidth: 2, borderColor: color,
    opacity: pulse.interpolate(
      phase === 0
        ? { inputRange: [0, 1], outputRange: [0.5, 0] }
        : { inputRange: [0, 0.5, 0.5, 1], outputRange: [0.22, 0, 0.5, 0.22] }
    ),
    transform: [{
      scale: pulse.interpolate(
        phase === 0
          ? { inputRange: [0, 1], outputRange: [1, 1.9] }
          : { inputRange: [0, 0.5, 0.5, 1], outputRange: [1.45, 1.9, 1, 1.45] }
      ),
    }],
  });
  return (
    <View style={s.nodeCol}>
      <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
        {rings && <Animated.View style={ringStyle(0)} />}
        {rings && <Animated.View style={ringStyle(1)} />}
        <View style={[s.node, {
          width: size, height: size, borderRadius: size / 2,
          backgroundColor: color + '24', borderColor: color,
        }]}>
          <Animated.View
            style={spin ? { transform: [{ rotate: rot.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] }) }] } : null}
          >
            <Ionicons name={icon} size={26} color={color} />
          </Animated.View>
        </View>
      </View>
      <Text style={[s.nodeLabel, { color: theme.muted }]} numberOfLines={1}>{label}</Text>
    </View>
  );
}

// Línea de conexión con puntos de luz que viajan de un nodo a otro
function FlowLine({ color, active, fast }) {
  const [w, setW] = useState(0);
  const v = useLoop(fast ? 900 : 2200, active);
  return (
    <View style={s.flowLine} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      <View style={[s.flowBase, { backgroundColor: active ? color + '40' : '#4A608044' }]} />
      {active && (
        <>
          <Animated.View
            style={[s.flowDot, {
              backgroundColor: color,
              opacity: v.interpolate({ inputRange: [0, 0.1, 0.9, 1], outputRange: [0, 1, 1, 0] }),
              transform: [{ translateX: v.interpolate({ inputRange: [0, 1], outputRange: [0, Math.max(w - 9, 0)] }) }],
            }]}
          />
          <Animated.View
            style={[s.flowDot, {
              backgroundColor: color,
              opacity: v.interpolate({ inputRange: [0, 0.4, 0.5, 0.5, 0.6, 1], outputRange: [1, 1, 0, 0, 1, 1] }),
              transform: [{
                translateX: v.interpolate({
                  inputRange: [0, 0.5, 0.5, 1],
                  outputRange: [Math.max(w - 9, 0) / 2, Math.max(w - 9, 0), 0, Math.max(w - 9, 0) / 2],
                }),
              }],
            }]}
          />
        </>
      )}
    </View>
  );
}

// Cabecera visual: Garmin → Intervals.icu → tu app
function SyncHero({ status, busy, checking, theme, L }) {
  const connected = status === 'connected';
  const accent = connected ? GREEN : checking ? BLUE : AMBER;
  const flowing = connected || busy;
  const text = busy
    ? L('Sincronizando…', 'Syncing…')
    : checking
      ? L('Comprobando conexión…', 'Checking connection…')
      : connected
        ? L('Todo conectado', 'All connected')
        : L('Sin conectar', 'Not connected');
  return (
    <View style={[s.hero, { backgroundColor: theme.card, borderColor: accent + '55' }]}>
      <View style={[s.blob, { backgroundColor: accent + '16', top: -50, right: -30, width: 150, height: 150 }]} />
      <View style={[s.blob, { backgroundColor: BLUE + '10', bottom: -60, left: -40, width: 130, height: 130 }]} />
      <View style={s.heroRow}>
        <HeroNode icon="watch-outline" color={connected ? GREEN : BLUE} label="Garmin" theme={theme} />
        <FlowLine color={accent} active={flowing} fast={busy} />
        <HeroNode icon="sync" color={accent} label="Intervals.icu" theme={theme} rings={flowing} spin={busy} />
        <FlowLine color={accent} active={flowing} fast={busy} />
        <HeroNode icon="phone-portrait-outline" color={connected ? GREEN : BLUE} label={L('Tu app', 'Your app')} theme={theme} />
      </View>
      <View style={[s.chip, { backgroundColor: accent + '1F', borderColor: accent + '66' }]}>
        <View style={[s.chipDot, { backgroundColor: accent }]} />
        <Text style={[s.chipText, { color: accent }]}>{text}</Text>
      </View>
    </View>
  );
}

// Icono con halo que late (estado "conectado")
function PulsingIcon({ name, color, size = 26 }) {
  const v = useLoop(1800, true, Easing.out(Easing.quad));
  return (
    <View style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
      <Animated.View
        style={{
          position: 'absolute', width: 36, height: 36, borderRadius: 18, backgroundColor: color,
          opacity: v.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0] }),
          transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.8, 1.5] }) }],
        }}
      />
      <Ionicons name={name} size={size} color={color} />
    </View>
  );
}

// Destello que cruza el botón principal cada pocos segundos
function Shine() {
  const [w, setW] = useState(0);
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(v, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.delay(2600),
        Animated.timing(v, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [v]);
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      <Animated.View
        style={[s.shine, {
          transform: [
            { translateX: v.interpolate({ inputRange: [0, 1], outputRange: [-60, w + 60] }) },
            { rotate: '20deg' },
          ],
        }]}
      />
    </View>
  );
}

// Botón de acción (sólido o "tintado")
function ActionButton({ icon, label, onPress, color = BLUE, variant = 'solid', loading, disabled, shine, style }) {
  const solid = variant === 'solid';
  const fg = solid ? '#fff' : color;
  return (
    <PressableScale
      onPress={onPress}
      disabled={disabled || loading}
      style={[
        s.btn,
        solid
          ? { backgroundColor: color }
          : { backgroundColor: color + '1A', borderWidth: 1, borderColor: color + '55' },
        (disabled || loading) && s.disabled,
        style,
      ]}
    >
      {solid && shine && !disabled && !loading && <Shine />}
      {loading ? (
        <ActivityIndicator color={fg} />
      ) : (
        <>
          <Ionicons name={icon} size={19} color={fg} />
          <Text style={[s.btnText, { color: fg }]} numberOfLines={1}>{label}</Text>
        </>
      )}
    </PressableScale>
  );
}

// Campo de texto con icono, foco animado y "ojo" para claves
function Field({ label, icon, theme, secure, ...props }) {
  const [focused, setFocused] = useState(false);
  const [hidden, setHidden] = useState(!!secure);
  return (
    <View style={{ marginTop: 10 }}>
      <Text style={[s.label, { color: theme.muted }]}>{label}</Text>
      <View
        style={[
          s.inputWrap,
          { backgroundColor: theme.input, borderColor: focused ? BLUE : theme.border },
          focused && s.inputFocus,
        ]}
      >
        <Ionicons name={icon} size={18} color={focused ? BLUE : theme.muted} />
        <TextInput
          {...props}
          secureTextEntry={hidden}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={[s.input, { color: theme.text }]}
          placeholderTextColor="#4A6080"
          autoCapitalize="none"
          autoCorrect={false}
        />
        {secure && (
          <Pressable onPress={() => setHidden((h) => !h)} hitSlop={10}>
            <Ionicons name={hidden ? 'eye-outline' : 'eye-off-outline'} size={19} color={theme.muted} />
          </Pressable>
        )}
      </View>
    </View>
  );
}

// Barra de progreso indeterminada + mensaje
function ProgressPanel({ message, theme }) {
  const [w, setW] = useState(0);
  const v = useLoop(1300, true, Easing.inOut(Easing.quad));
  const bar = w * 0.4;
  return (
    <View style={[s.progress, { backgroundColor: theme.input, borderColor: BLUE + '66' }]}>
      <View style={s.progressTop}>
        <Ionicons name="sync" size={15} color={BLUE} />
        <Text style={[s.progressText, { color: theme.muted }]} numberOfLines={1}>{message}</Text>
      </View>
      <View style={s.track} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
        <Animated.View
          style={[s.bar, {
            width: bar,
            transform: [{ translateX: v.interpolate({ inputRange: [0, 1], outputRange: [-bar, w] }) }],
          }]}
        />
      </View>
    </View>
  );
}

// Cabecera de sección con icono de color y etiqueta
function SectionHeader({ icon, color, title, tag, theme }) {
  return (
    <View style={s.sectionHeader}>
      <View style={[s.sectionIcon, { backgroundColor: color + '22', borderColor: color + '66' }]}>
        <Ionicons name={icon} size={18} color={color} />
      </View>
      <Text style={[s.sectionTitle, { color: theme.text }]}>{title}</Text>
      {!!tag && (
        <View style={[s.tag, { backgroundColor: color + '22' }]}>
          <Text style={[s.tagText, { color }]}>{tag}</Text>
        </View>
      )}
    </View>
  );
}

// Guía desplegable con línea de tiempo
function Guide({ icon, color, title, open, onToggle, steps, theme, L }) {
  const rot = useRef(new Animated.Value(open ? 1 : 0)).current;
  useEffect(() => {
    Animated.timing(rot, { toValue: open ? 1 : 0, duration: 220, useNativeDriver: true }).start();
  }, [open, rot]);
  return (
    <View style={[s.guide, { backgroundColor: theme.input, borderColor: theme.border }]}>
      <Pressable style={s.guideHeader} onPress={onToggle}>
        <Ionicons name={icon} size={18} color={color} />
        <Text style={[s.guideTitle, { color: theme.text }]}>{title}</Text>
        <Animated.View style={{ transform: [{ rotate: rot.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '180deg'] }) }] }}>
          <Ionicons name="chevron-down" size={18} color={theme.muted} />
        </Animated.View>
      </Pressable>
      {open && (
        <View style={s.timeline}>
          {steps.map((step, i) => (
            <FadeIn key={i} delay={i * 70}>
              <View style={s.stepRow}>
                <View style={s.stepRail}>
                  <View style={[s.stepNode, { backgroundColor: step.color + '22', borderColor: step.color }]}>
                    <Ionicons name={step.icon} size={18} color={step.color} />
                  </View>
                  {i < steps.length - 1 && <View style={[s.stepLine, { backgroundColor: theme.border }]} />}
                </View>
                <View style={s.stepBody}>
                  <Text style={[s.stepNum, { color: step.color }]}>{L('Paso', 'Step')} {i + 1}</Text>
                  <Text style={[s.stepTitle, { color: theme.text }]}>{step.title}</Text>
                  <Text style={[s.stepDesc, { color: theme.muted }]}>{step.desc}</Text>
                </View>
              </View>
            </FadeIn>
          ))}
        </View>
      )}
    </View>
  );
}

/* ════════════════════════════════════════════════════════════════════════════
   PANTALLA
   ════════════════════════════════════════════════════════════════════════════ */
export default function SyncSettingsScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const appSettings = useAppSettings();
  const lang = appSettings.language;            // re-renderiza al cambiar idioma
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción

  // ── Intervals.icu ──
  const [intStatus, setIntStatus] = useState('unknown'); // unknown | connected | disconnected
  const [athleteName, setAthleteName] = useState(null);
  const [athleteId, setAthleteId] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [saving, setSaving] = useState(false);
  const [disconnecting, setDisconnecting] = useState(false);
  const [checking, setChecking] = useState(true);
  // ── Guías desplegables ──
  const [openGuideInt, setOpenGuideInt] = useState(false);
  const [openGuideFit, setOpenGuideFit] = useState(false);
  // ── Carpeta .fit (plan B) ──
  const [folderUri, setFolderUri] = useState(null);
  const [loadingFolder, setLoadingFolder] = useState(false);
  const [fileCount, setFileCount] = useState(null);
  const [syncingFolder, setSyncingFolder] = useState(false);
  const [folderProgress, setFolderProgress] = useState('');

  // Pasos de las guías, traducidos (dentro del componente para usar L)
  const STEPS_INTERVALS = [
    {
      icon: 'create-outline',
      color: BLUE,
      title: L('Crea tu cuenta en Intervals.icu', 'Create your Intervals.icu account'),
      desc: L('Entra en intervals.icu y crea una cuenta gratuita.', 'Go to intervals.icu and create a free account.'),
    },
    {
      icon: 'download-outline',
      color: GREEN,
      title: L('Activa la descarga desde Garmin', 'Enable downloads from Garmin'),
      desc: L('En Settings → bloque Garmin, marca "Download activities". Tus actividades terminadas bajarán solas desde Garmin Connect.', 'In Settings → Garmin block, tick "Download activities". Your finished activities will download automatically from Garmin Connect.'),
    },
    {
      icon: 'key-outline',
      color: AMBER,
      title: L('Copia tu Athlete ID y tu API key', 'Copy your Athlete ID and API key'),
      desc: L('En Settings → Developer Settings genera tu API key y copia también tu Athlete ID (ej: i12345).', 'In Settings → Developer Settings generate your API key and copy your Athlete ID too (e.g. i12345).'),
    },
    {
      icon: 'link-outline',
      color: BLUE,
      title: L('Pégalos aquí y conecta', 'Paste them here and connect'),
      desc: L('Introduce ambos datos abajo y pulsa "Conectar". La app validará las credenciales y quedará vinculada.', 'Enter both values below and tap "Connect". The app will validate the credentials and link the account.'),
    },
  ];
  const STEPS_FIT = [
    {
      icon: 'download-outline',
      color: AMBER,
      title: L('Descarga el archivo .fit', 'Download the .fit file'),
      desc: L('En connect.garmin.com, abre la actividad y descarga el archivo original (.fit).', 'On connect.garmin.com, open the activity and download the original file (.fit).'),
    },
    {
      icon: 'folder-outline',
      color: BLUE,
      title: L('Colócalo en una carpeta', 'Put it in a folder'),
      desc: L('Mueve el .fit a una carpeta de Descargas (ej: Descargas/Garmin).', 'Move the .fit into a Downloads folder (e.g. Downloads/Garmin).'),
    },
    {
      icon: 'sync-outline',
      color: GREEN,
      title: L('Sincroniza la carpeta aquí', 'Sync the folder here'),
      desc: L('Selecciona la carpeta y pulsa "Sincronizar carpeta ahora". Solo se importarán archivos nuevos.', 'Select the folder and tap "Sync folder now". Only new files will be imported.'),
    },
  ];

  const checkStatus = useCallback(async () => {
    setChecking(true);
    const data = await getIntervalsStatus();
    if (data.connected) {
      setIntStatus('connected');
      setAthleteName(data.athleteName || null);
    } else {
      setIntStatus('disconnected');
      setAthleteName(null);
    }
    setChecking(false);
  }, []);

  useEffect(() => {
    checkStatus();
    AsyncStorage.getItem(FOLDER_KEY).then(uri => {
      if (uri) {
        setFolderUri(uri);
        countFiles(uri);
      }
    });
  }, [checkStatus]);

  const countFiles = async (uri) => {
    try {
      const entries = await StorageAccessFramework.readDirectoryAsync(uri);
      const fits = entries.filter(u => {
        const n = u.toLowerCase();
        return n.endsWith('.fit') || n.includes('.fit%');
      });
      setFileCount(fits.length);
    } catch {
      setFileCount(null);
    }
  };

  // ── Conectar Intervals.icu ──
  const handleConnect = async () => {
    if (!athleteId.trim() || !apiKey.trim()) {
      Alert.alert(L('Faltan datos', 'Missing data'), L('Introduce tu Athlete ID y tu API key de Intervals.icu.', 'Enter your Athlete ID and your Intervals.icu API key.'));
      return;
    }
    setSaving(true);
    try {
      const data = await saveIntervalsCredentials(athleteId.trim(), apiKey.trim());
      setAthleteName(data.athleteName || null);
      setIntStatus('connected');
      setApiKey('');
      Alert.alert(
        L('Conectado', 'Connected'),
        L('Intervals.icu vinculado correctamente', 'Intervals.icu linked successfully') + (data.athleteName ? ` (${data.athleteName})` : '') + '.'
      );
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDisconnect = () => {
    Alert.alert(
      L('Desconectar Intervals.icu', 'Disconnect Intervals.icu'),
      L('¿Seguro que quieres desconectar tu cuenta? Podrás volver a conectarla cuando quieras.', 'Are you sure you want to disconnect? You can reconnect it anytime.'),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Desconectar', 'Disconnect'),
          style: 'destructive',
          onPress: async () => {
            setDisconnecting(true);
            try {
              await disconnectIntervals();
              setIntStatus('disconnected');
              setAthleteName(null);
            } catch (e) {
              Alert.alert(L('Error', 'Error'), e.message);
            } finally {
              setDisconnecting(false);
            }
          },
        },
      ]
    );
  };

  // ── Carpeta .fit ──
  const handleSelectFolder = async () => {
    setLoadingFolder(true);
    try {
      const result = await StorageAccessFramework.requestDirectoryPermissionsAsync();
      if (!result.granted) { setLoadingFolder(false); return; }
      await AsyncStorage.setItem(FOLDER_KEY, result.directoryUri);
      setFolderUri(result.directoryUri);
      await countFiles(result.directoryUri);
      Alert.alert(L('Carpeta guardada', 'Folder saved'), L('La carpeta se ha guardado correctamente.', 'The folder has been saved successfully.'));
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally {
      setLoadingFolder(false);
    }
  };

  const handleResetFolder = () => {
    Alert.alert(L('Borrar carpeta', 'Delete folder'), L('¿Quieres eliminar la carpeta guardada?', 'Do you want to remove the saved folder?'), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      {
        text: L('Borrar', 'Delete'),
        style: 'destructive',
        onPress: async () => {
          await resetSyncFolder();
          setFolderUri(null);
          setFileCount(null);
        },
      },
    ]);
  };

  const handleSyncFolder = async () => {
    const userId = auth.currentUser?.uid;
    if (!userId) return;
    if (!folderUri) {
      Alert.alert(L('Sin carpeta', 'No folder'), L('Selecciona primero una carpeta con archivos .fit.', 'Select a folder with .fit files first.'));
      return;
    }
    setSyncingFolder(true);
    setFolderProgress(L('Preparando…', 'Preparing…'));
    try {
      const result = await syncFitFiles(userId, (msg) => setFolderProgress(msg), lang);
      if (result.cancelled) {
        Alert.alert(L('Cancelado', 'Cancelled'), result.message || L('No hay carpeta configurada.', 'No folder configured.'));
      } else {
        Alert.alert(
          L('Importación completada', 'Import completed'),
          `${result.synced} ${L('nuevos', 'new')} · ${result.skipped} ${L('existentes', 'existing')} · ${result.errors} ${L('errores', 'errors')}`
        );
      }
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally {
      setSyncingFolder(false);
      setFolderProgress('');
    }
  };

  // ── Mantenimiento: recalcular el esfuerzo (TSS) de lo ya guardado ──
  const [recalculando, setRecalculando] = useState(false);
  const [recalculoMsg, setRecalculoMsg] = useState('');
  const handleRecalcularEsfuerzo = () => {
    const userId = auth.currentUser?.uid;
    if (!userId) return;
    Alert.alert(
      L('Recalcular esfuerzo', 'Recalculate effort'),
      L(
        'Vuelve a calcular el esfuerzo (TSS) de tus entrenos guardados usando la duración, la distancia, la FC y tus umbrales de Zonas. No modifica los entrenos sincronizados desde intervals.icu (ésos usan el TSS real de intervals.icu) ni los que hayas editado a mano.',
        'Recalculates the effort (TSS) of your saved workouts using duration, distance, HR and your Zones thresholds. Workouts synced from intervals.icu (which use the real intervals.icu TSS) and manually edited ones are not modified.'
      ),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Recalcular', 'Recalculate'),
          onPress: async () => {
            setRecalculando(true);
            setRecalculoMsg(L('Preparando…', 'Preparing…'));
            try {
              const r = await recalcularEsfuerzos(userId, (msg) => setRecalculoMsg(msg));
              Alert.alert(
                L('Esfuerzo recalculado', 'Effort recalculated'),
                `${r.actualizados} ${L('actualizados', 'updated')} · ${r.intactos} ${L('sin cambios', 'unchanged')} · ${r.sinDatos} ${L('sin datos suficientes', 'not enough data')} · ${r.omitidos} ${L('de intervals.icu (los corrige el servidor)', 'from intervals.icu (fixed by the server)')}`
              );
            } catch (e) {
              Alert.alert(L('Error', 'Error'), e.message);
            } finally {
              setRecalculando(false);
              setRecalculoMsg('');
            }
          },
        },
      ]
    );
  };

  const folderName = folderUri
    ? decodeURIComponent(folderUri.split('%3A').pop().split(':').pop())
    : null;

  // Animación suave al abrir/cerrar guías (solo visual)
  const toggleGuide = (setter) => {
    LayoutAnimation.configureNext(LayoutAnimation.create(240, 'easeInEaseOut', 'opacity'));
    setter((v) => !v);
  };

  const busy = saving || syncingFolder || recalculando || disconnecting;

  /* ─────────────────────────────── RENDER ─────────────────────────────── */
  return (
    <View style={[s.container, { backgroundColor: theme.background }]}>
      {/* Cabecera */}
      <View style={[s.header, { borderBottomColor: theme.border, paddingTop: insets.top + 10 }]}>
        <PressableScale
          onPress={() => navigation.goBack()}
          style={[s.backBtn, { backgroundColor: theme.card, borderColor: theme.border }]}
          hitSlop={10}
        >
          <Ionicons name="chevron-back" size={22} color="#8FA8C8" />
        </PressableScale>
        <Text style={[s.headerTitle, { color: theme.text }]}>{L('Sincronización', 'Sync')}</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        contentContainerStyle={[s.scrollContent, { paddingBottom: Math.max(40, insets.bottom + 16) }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* ══════════ HÉROE ANIMADO ══════════ */}
        <FadeIn>
          <SyncHero status={intStatus} busy={busy} checking={checking} theme={theme} L={L} />
        </FadeIn>

        {/* ══════════ BLOQUE 1: INTERVALS.ICU ══════════ */}
        <FadeIn delay={120}>
          <SectionHeader
            icon="flash-outline"
            color={BLUE}
            title={L('Sincronización automática (Intervals.icu)', 'Automatic sync (Intervals.icu)')}
            tag={L('Recomendado', 'Recommended')}
            theme={theme}
          />
          <View style={[s.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
            {intStatus === 'connected' ? (
              <View style={[s.statusRow, { backgroundColor: GREEN + '14', borderColor: GREEN + '55' }]}>
                <PulsingIcon name="checkmark-circle" color={GREEN} />
                <View style={{ flex: 1 }}>
                  <Text style={[s.statusTitle, { color: theme.text }]}>{L('Intervals.icu conectado', 'Intervals.icu connected')}</Text>
                  {athleteName && (
                    <Text style={[s.statusSub, { color: theme.muted }]} numberOfLines={1}>{athleteName}</Text>
                  )}
                </View>
                <PressableScale
                  onPress={handleDisconnect}
                  disabled={disconnecting}
                  style={s.dangerBtn}
                  hitSlop={8}
                >
                  {disconnecting
                    ? <ActivityIndicator size="small" color={RED} />
                    : <Ionicons name="trash-outline" size={18} color={RED} />}
                </PressableScale>
              </View>
            ) : (
              <View style={[s.statusRow, { backgroundColor: AMBER + '12', borderColor: AMBER + '55' }]}>
                <Ionicons name="warning-outline" size={22} color={AMBER} />
                <Text style={[s.statusWarnText, { color: theme.muted }]}>
                  {checking
                    ? L('Comprobando conexión…', 'Checking connection…')
                    : L('Sin conectar. Sigue los pasos y pega tus datos abajo.', 'Not connected. Follow the steps and paste your details below.')}
                </Text>
              </View>
            )}

            {intStatus !== 'connected' && (
              <>
                <Field
                  label="Athlete ID"
                  icon="person-outline"
                  theme={theme}
                  value={athleteId}
                  onChangeText={setAthleteId}
                  placeholder="i12345"
                />
                <Field
                  label="API Key"
                  icon="key-outline"
                  theme={theme}
                  secure
                  value={apiKey}
                  onChangeText={setApiKey}
                  placeholder={L('Pega aquí tu API key', 'Paste your API key here')}
                />
                <ActionButton
                  icon="link-outline"
                  label={L('Conectar Intervals.icu', 'Connect Intervals.icu')}
                  onPress={handleConnect}
                  loading={saving}
                  shine
                  style={{ marginTop: 14 }}
                />
              </>
            )}

            <ActionButton
              icon="globe-outline"
              label={L('Abrir ajustes de Intervals.icu', 'Open Intervals.icu settings')}
              onPress={() => Linking.openURL('https://intervals.icu/settings')}
              variant="tint"
              color={BLUE}
              style={{ marginTop: 10 }}
            />

            <Guide
              icon="help-circle-outline"
              color={BLUE}
              title={L('¿Cómo funciona Intervals.icu?', 'How does Intervals.icu work?')}
              open={openGuideInt}
              onToggle={() => toggleGuide(setOpenGuideInt)}
              steps={STEPS_INTERVALS}
              theme={theme}
              L={L}
            />
          </View>
        </FadeIn>

        {/* ══════════ BLOQUE 2: CARPETA .FIT (PLAN B) ══════════ */}
        <FadeIn delay={220}>
          <SectionHeader
            icon="folder-open-outline"
            color={GREEN}
            title={L('Importación manual (archivos .fit)', 'Manual import (.fit files)')}
            tag={L('Opcional', 'Optional')}
            theme={theme}
          />
          <View style={[s.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
            {folderUri ? (
              <View style={[s.statusRow, { backgroundColor: BLUE + '12', borderColor: BLUE + '55' }]}>
                <Ionicons name="folder-open" size={26} color={BLUE} />
                <View style={{ flex: 1 }}>
                  <Text style={[s.statusTitle, { color: theme.text }]}>{L('Carpeta configurada', 'Folder configured')}</Text>
                  <Text style={[s.statusSub, { color: theme.muted }]} numberOfLines={1}>{folderName}</Text>
                  {fileCount != null && (
                    <View style={[s.countChip, { backgroundColor: GREEN + '22' }]}>
                      <Ionicons name="document-text-outline" size={12} color={GREEN} />
                      <Text style={[s.statusCount, { color: GREEN }]}>
                        {L(
                          `${fileCount} archivo${fileCount !== 1 ? 's' : ''} .fit en la carpeta`,
                          `${fileCount} .fit file${fileCount !== 1 ? 's' : ''} in the folder`
                        )}
                      </Text>
                    </View>
                  )}
                </View>
                <PressableScale onPress={handleResetFolder} style={s.dangerBtn} hitSlop={8}>
                  <Ionicons name="trash-outline" size={18} color={RED} />
                </PressableScale>
              </View>
            ) : (
              <View style={[s.statusRow, { backgroundColor: AMBER + '12', borderColor: AMBER + '55' }]}>
                <Ionicons name="warning-outline" size={22} color={AMBER} />
                <Text style={[s.statusWarnText, { color: theme.muted }]}>{L('Sin carpeta configurada (opcional).', 'No folder configured (optional).')}</Text>
              </View>
            )}

            <ActionButton
              icon="folder-open-outline"
              label={folderUri ? L('Cambiar carpeta .fit', 'Change .fit folder') : L('Seleccionar carpeta .fit', 'Select .fit folder')}
              onPress={handleSelectFolder}
              variant="tint"
              color={BLUE}
              loading={loadingFolder}
              style={{ marginTop: 12 }}
            />
            <ActionButton
              icon="sync-outline"
              label={L('Sincronizar carpeta ahora', 'Sync folder now')}
              onPress={handleSyncFolder}
              color={GREEN}
              loading={syncingFolder}
              disabled={!folderUri}
              shine
              style={{ marginTop: 10 }}
            />
            {syncingFolder && !!folderProgress && <ProgressPanel message={folderProgress} theme={theme} />}

            <Guide
              icon="folder-open-outline"
              color={GREEN}
              title={L('Pasos de la importación manual', 'Manual import steps')}
              open={openGuideFit}
              onToggle={() => toggleGuide(setOpenGuideFit)}
              steps={STEPS_FIT}
              theme={theme}
              L={L}
            />
          </View>
        </FadeIn>

        {/* ══════════ MANTENIMIENTO: ESFUERZO (TSS) ══════════ */}
        <FadeIn delay={320}>
          <SectionHeader
            icon="speedometer-outline"
            color={AMBER}
            title={L('Esfuerzo (TSS)', 'Effort (TSS)')}
            theme={theme}
          />
          <View style={[s.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <Text style={[s.cardDesc, { color: theme.muted }]}>
              {L(
                'Vuelve a calcular el esfuerzo de tus entrenos guardados con tus umbrales actuales.',
                'Recalculates the effort of your saved workouts using your current thresholds.'
              )}
            </Text>
            <ActionButton
              icon="refresh-outline"
              label={L('Recalcular esfuerzo de mis entrenos', 'Recalculate effort of my workouts')}
              onPress={handleRecalcularEsfuerzo}
              variant="tint"
              color={AMBER}
              loading={recalculando}
              style={{ marginTop: 12 }}
            />
            {recalculando && !!recalculoMsg && <ProgressPanel message={recalculoMsg} theme={theme} />}
          </View>
        </FadeIn>

        {/* ══════════ NOTA INFORMATIVA ══════════ */}
        <FadeIn delay={420}>
          <View style={[s.infoBox, { backgroundColor: BLUE + '14', borderColor: BLUE + '44' }]}>
            <View style={[s.infoIcon, { backgroundColor: BLUE + '26' }]}>
              <Ionicons name="bulb-outline" size={18} color={BLUE} />
            </View>
            <Text style={[s.infoText, { color: theme.muted }]}>
              {L(
                'La vía recomendada es Intervals.icu: tus actividades de Garmin llegan solas y el botón ↻ del Dashboard las trae a la app. La carpeta .fit es solo un plan B para actividades sueltas que no aparezcan en Intervals.icu.',
                'The recommended way is Intervals.icu: your Garmin activities arrive automatically and the ↻ button on the Dashboard brings them into the app. The .fit folder is only a plan B for isolated activities that do not appear in Intervals.icu.'
              )}
            </Text>
          </View>
        </FadeIn>
      </ScrollView>
    </View>
  );
}

/* ════════════════════════════════════════════════════════════════════════════
   ESTILOS
   ════════════════════════════════════════════════════════════════════════════ */
const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },

  // Cabecera
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingBottom: 12,
    borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  backBtn: {
    width: 40, height: 40, borderRadius: 20, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
  },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  scrollContent: { padding: 16, gap: 22 },

  // Héroe
  hero: {
    borderRadius: 24, borderWidth: 1.5, padding: 18, paddingTop: 22,
    overflow: 'hidden', alignItems: 'center',
  },
  blob: { position: 'absolute', borderRadius: 999 },
  heroRow: { flexDirection: 'row', alignItems: 'flex-start', width: '100%' },
  nodeCol: { width: 72, alignItems: 'center', gap: 8 },
  node: { borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  nodeLabel: { fontSize: 11, fontWeight: '600' },
  flowLine: { flex: 1, height: 58, justifyContent: 'center', overflow: 'hidden' },
  flowBase: { height: 3, borderRadius: 2 },
  flowDot: { position: 'absolute', top: 24.5, width: 9, height: 9, borderRadius: 5 },
  chip: {
    flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 18,
    paddingHorizontal: 14, paddingVertical: 7, borderRadius: 999, borderWidth: 1,
  },
  chipDot: { width: 8, height: 8, borderRadius: 4 },
  chipText: { fontSize: 13, fontWeight: '700' },

  // Secciones
  sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  sectionIcon: {
    width: 34, height: 34, borderRadius: 11, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
  },
  sectionTitle: { fontSize: 15, fontWeight: '800', flex: 1 },
  tag: { paddingHorizontal: 9, paddingVertical: 3, borderRadius: 999 },
  tagText: { fontSize: 11, fontWeight: '700' },
  card: { borderRadius: 20, borderWidth: 1, padding: 14 },
  cardDesc: { fontSize: 13, lineHeight: 19 },

  // Estado
  statusRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    borderRadius: 14, borderWidth: 1, padding: 12,
  },
  statusTitle: { fontWeight: '700', fontSize: 14 },
  statusSub: { fontSize: 12, marginTop: 2 },
  statusWarnText: { fontSize: 13, flex: 1, lineHeight: 18 },
  countChip: {
    flexDirection: 'row', alignItems: 'center', gap: 5, alignSelf: 'flex-start',
    marginTop: 6, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 999,
  },
  statusCount: { fontSize: 11, fontWeight: '700' },
  dangerBtn: {
    width: 38, height: 38, borderRadius: 19, backgroundColor: RED + '1F',
    alignItems: 'center', justifyContent: 'center',
  },

  // Formulario
  label: { fontSize: 12, fontWeight: '600', marginBottom: 6, marginLeft: 2 },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    borderRadius: 12, borderWidth: 1.5, paddingHorizontal: 12,
  },
  inputFocus: {
    shadowColor: BLUE, shadowOpacity: 0.35, shadowRadius: 8, shadowOffset: { width: 0, height: 0 },
  },
  input: { flex: 1, paddingVertical: 12, fontSize: 14 },

  // Botones
  btn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    borderRadius: 14, paddingVertical: 15, paddingHorizontal: 14, gap: 10, overflow: 'hidden',
  },
  btnText: { fontWeight: '800', fontSize: 15, flexShrink: 1 },
  disabled: { opacity: 0.55 },
  shine: {
    position: 'absolute', top: -30, height: 120, width: 28,
    backgroundColor: 'rgba(255,255,255,0.20)',
  },

  // Progreso
  progress: { marginTop: 12, borderRadius: 12, borderWidth: 1, padding: 12, gap: 10 },
  progressTop: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  progressText: { fontSize: 13, flex: 1 },
  track: { height: 5, borderRadius: 3, backgroundColor: BLUE + '2A', overflow: 'hidden' },
  bar: { height: 5, borderRadius: 3, backgroundColor: BLUE },

  // Guías (línea de tiempo)
  guide: { marginTop: 14, borderRadius: 14, borderWidth: 1, overflow: 'hidden' },
  guideHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 14 },
  guideTitle: { fontSize: 14, fontWeight: '700', flex: 1 },
  timeline: { paddingHorizontal: 14, paddingBottom: 6 },
  stepRow: { flexDirection: 'row', gap: 14 },
  stepRail: { alignItems: 'center', width: 40 },
  stepNode: {
    width: 40, height: 40, borderRadius: 20, borderWidth: 1.5,
    alignItems: 'center', justifyContent: 'center',
  },
  stepLine: { flex: 1, width: 2, marginVertical: 4, borderRadius: 1 },
  stepBody: { flex: 1, paddingBottom: 18 },
  stepNum: { fontSize: 11, fontWeight: '800', marginBottom: 2 },
  stepTitle: { fontSize: 14, fontWeight: '700', marginBottom: 4 },
  stepDesc: { fontSize: 13, lineHeight: 19 },

  // Info
  infoBox: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 12,
    borderRadius: 16, padding: 14, borderWidth: 1,
  },
  infoIcon: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  infoText: { fontSize: 13, lineHeight: 19, flex: 1 },
});