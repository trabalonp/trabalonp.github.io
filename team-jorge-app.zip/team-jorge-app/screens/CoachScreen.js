// screens/CoachScreen.js
// ─────────────────────────────────────────────────────────────────────────────
// REDISEÑO VISUAL + ANIMACIONES ("vestuario del entrenador").
// La lógica (caché local-first de coachCache, refresco en segundo plano con
// timeout, endpoints /coach-screen-data, /solicitar-entrenador,
// /gestionar-solicitud, /eliminar-entrenador, selección de atleta en
// AsyncStorage y navegación al Dashboard, calentamiento de Render) es la
// MISMA que la versión original. Solo cambia la capa visual.
// Sin dependencias nuevas.
// ─────────────────────────────────────────────────────────────────────────────
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import SystemBars from '../components/SystemBars';
import {
  ActivityIndicator,
  Alert,
  Animated,
  Easing,
  FlatList,
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  TextInput,
  View,
  useColorScheme,
} from 'react-native';
import { auth } from '../firebaseConfig';
import { cacheCoach, clearCoachCache, getCachedCoach, isCacheStale } from '../services/coachCache';
import { getThemeColors, useAppSettings } from '../services/appSettings';

const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';
const RED    = '#E05252';
const SERVER_URL = 'https://garmin-fit-server.onrender.com';

// ── Calienta el servicio de Render al arrancar la app (una vez por arranque) ──
// Cualquier petición HTTP despierta un servicio dormido del plan gratuito;
// al lanzarla al cargar la app, cuando entras aquí el servidor ya está despierto.
let serverWarmed = false;
function warmServer() {
  if (serverWarmed) return;
  serverWarmed = true;
  fetch(`${SERVER_URL}/ping`, { method: 'GET' }).catch(() => {});
}
warmServer();


/* ── Paleta del rediseño (solo visual) ── */
const VIOLET = '#8B7BF7';
const MINT   = '#2DD4A8';
const AMBER  = '#F5A623';
const ATHLETE_COLORS = [VIOLET, MINT, BLUE, AMBER, '#F472B6', '#22B8CF'];
const colorDe = (txt) => {
  let h = 0;
  const s = String(txt || '');
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 997;
  return ATHLETE_COLORS[h % ATHLETE_COLORS.length];
};

/* ════════════════════════════════════════════════════════════════════════════
   COMPONENTES VISUALES / ANIMADOS
   ════════════════════════════════════════════════════════════════════════════ */

// Aparece con fundido + deslizamiento (entrada escalonada con `delay`)
function FadeIn({ delay = 0, children, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, {
      toValue: 1, duration: 420, delay,
      easing: Easing.out(Easing.cubic), useNativeDriver: true,
    }).start();
  }, [v, delay]);
  return (
    <Animated.View
      style={[style, {
        opacity: v,
        transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [16, 0] }) }],
      }]}
    >
      {children}
    </Animated.View>
  );
}

// Zona pulsable con efecto "muelle"
function Press({ onPress, disabled, style, children, hitSlop }) {
  const sc = useRef(new Animated.Value(1)).current;
  const to = (value) =>
    Animated.spring(sc, { toValue: value, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      hitSlop={hitSlop}
      onPressIn={() => to(0.97)}
      onPressOut={() => to(1)}
    >
      <Animated.View style={[style, { transform: [{ scale: sc }] }]}>{children}</Animated.View>
    </Pressable>
  );
}

// Valor 0→1 en bucle
function useLoop(duration, active = true, easing = Easing.linear) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!active) { v.setValue(0); return undefined; }
    const loop = Animated.loop(Animated.timing(v, { toValue: 1, duration, easing, useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [v, duration, active, easing]);
  return v;
}

// Valor 0→1→0 suave (flotar)
function usePingPong(duration) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(v, { toValue: 1, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [v, duration]);
  return v;
}

// Número que "cuenta" hasta su valor
function CountUp({ value, style }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    const a = new Animated.Value(0);
    const id = a.addListener(({ value: v }) => setN(Math.round(v)));
    Animated.timing(a, { toValue: value, duration: 700, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
    return () => { a.removeListener(id); a.stopAnimation(); };
  }, [value]);
  return <Text style={style}>{n}</Text>;
}

// Anillos que se expanden desde el centro
function PulseRings({ size, color }) {
  const v = useLoop(2400, true, Easing.out(Easing.quad));
  const ring = (phase) => ({
    position: 'absolute', width: size, height: size, borderRadius: size / 2,
    borderWidth: 2, borderColor: color,
    opacity: v.interpolate(
      phase === 0
        ? { inputRange: [0, 1], outputRange: [0.45, 0] }
        : { inputRange: [0, 0.5, 0.5, 1], outputRange: [0.2, 0, 0.45, 0.2] }
    ),
    transform: [{
      scale: v.interpolate(
        phase === 0
          ? { inputRange: [0, 1], outputRange: [1, 1.9] }
          : { inputRange: [0, 0.5, 0.5, 1], outputRange: [1.45, 1.9, 1, 1.45] }
      ),
    }],
  });
  return (
    <>
      <Animated.View pointerEvents="none" style={ring(0)} />
      <Animated.View pointerEvents="none" style={ring(1)} />
    </>
  );
}

// Punto que late (estado "vinculado")
function PulseDot({ color }) {
  const v = useLoop(1600, true, Easing.out(Easing.quad));
  return (
    <View style={{ width: 14, height: 14, alignItems: 'center', justifyContent: 'center' }}>
      <Animated.View
        style={{
          position: 'absolute', width: 14, height: 14, borderRadius: 7, backgroundColor: color,
          opacity: v.interpolate({ inputRange: [0, 1], outputRange: [0.5, 0] }),
          transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.8, 2] }) }],
        }}
      />
      <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: color }} />
    </View>
  );
}

// Avatar: foto en base64 o inicial
function Avatar({ foto, letra, size = 50, color = BLUE }) {
  return (
    <View style={{
      width: size, height: size, borderRadius: size / 2, backgroundColor: color,
      alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
    }}>
      {foto ? (
        <Image source={{ uri: `data:image/jpeg;base64,${foto}` }} style={{ width: size, height: size }} />
      ) : (
        <Text style={{ color: '#fff', fontSize: size * 0.44, fontWeight: '800' }}>{letra}</Text>
      )}
    </View>
  );
}

// Campana que se agita cuando hay solicitudes pendientes
function WiggleBell({ count }) {
  const rot = useRef(new Animated.Value(0)).current;
  const pop = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (count > 0) {
      pop.setValue(0);
      Animated.spring(pop, { toValue: 1, useNativeDriver: true, speed: 14, bounciness: 14 }).start();
      const step = (to) => Animated.timing(rot, { toValue: to, duration: 90, useNativeDriver: true });
      const loop = Animated.loop(Animated.sequence([
        step(1), step(-1), step(0.7), step(-0.7), step(0), Animated.delay(2600),
      ]));
      loop.start();
      return () => loop.stop();
    }
    rot.setValue(0);
    return undefined;
  }, [count, rot, pop]);
  return (
    <View>
      <Animated.View style={{ transform: [{ rotate: rot.interpolate({ inputRange: [-1, 1], outputRange: ['-18deg', '18deg'] }) }] }}>
        <Ionicons name={count > 0 ? 'notifications' : 'notifications-outline'} size={22} color={count > 0 ? VIOLET : '#8FA8C8'} />
      </Animated.View>
      {count > 0 && (
        <Animated.View style={[styles.badge, { transform: [{ scale: pop }] }]}>
          <Text style={styles.badgeText}>{count}</Text>
        </Animated.View>
      )}
    </View>
  );
}

// Pantalla de carga: anillos que laten alrededor de un icono
function LoadingScreen({ theme }) {
  return (
    <View style={[styles.centered, { backgroundColor: theme.background }]}>
      <View style={{ width: 84, height: 84, alignItems: 'center', justifyContent: 'center' }}>
        <PulseRings size={84} color={VIOLET} />
        <View style={[styles.loadCircle, { backgroundColor: VIOLET + '24', borderColor: VIOLET }]}>
          <Ionicons name="people" size={34} color={VIOLET} />
        </View>
      </View>
      <ActivityIndicator size="small" color={VIOLET} style={{ marginTop: 28 }} />
    </View>
  );
}

// Halo de puntos que gira alrededor del avatar del entrenador
function OrbitAvatar({ foto, letra }) {
  const spin = useLoop(16000, true);
  const SIZE = 128;
  return (
    <View style={{ width: SIZE, height: SIZE, alignItems: 'center', justifyContent: 'center' }}>
      <Animated.View
        style={[StyleSheet.absoluteFill, { transform: [{ rotate: spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] }) }] }]}
      >
        {Array.from({ length: 14 }).map((_, i) => (
          <View key={i} style={[StyleSheet.absoluteFill, { alignItems: 'center', transform: [{ rotate: `${i * (360 / 14)}deg` }] }]}>
            <View style={{
              width: i % 2 ? 4 : 6, height: i % 2 ? 4 : 6, borderRadius: 3,
              backgroundColor: i % 2 ? MINT : VIOLET, opacity: i % 2 ? 0.55 : 0.9,
            }} />
          </View>
        ))}
      </Animated.View>
      <View style={styles.orbitInner}>
        <Avatar foto={foto} letra={letra} size={92} color={VIOLET} />
      </View>
      <View style={styles.orbitBadge}>
        <Ionicons name="shield-checkmark" size={15} color="#0D1B2A" />
      </View>
    </View>
  );
}

// Líneas de "pizarra / campo" decorativas de fondo
function CourtLines({ color }) {
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <View style={{ position: 'absolute', left: 0, right: 0, top: '52%', height: 1.5, backgroundColor: color }} />
      <View style={{ position: 'absolute', alignSelf: 'center', top: '52%', marginTop: -70, width: 140, height: 140, borderRadius: 70, borderWidth: 1.5, borderColor: color }} />
      <View style={{ position: 'absolute', left: -40, top: -40, width: 110, height: 110, borderRadius: 55, borderWidth: 1.5, borderColor: color }} />
      <View style={{ position: 'absolute', right: -40, bottom: -40, width: 110, height: 110, borderRadius: 55, borderWidth: 1.5, borderColor: color }} />
    </View>
  );
}

// Destello que cruza el botón principal cada pocos segundos
function Shine() {
  const [w, setW] = useState(0);
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(v, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.delay(2600),
        Animated.timing(v, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [v]);
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      <Animated.View
        style={[styles.shine, {
          transform: [
            { translateX: v.interpolate({ inputRange: [0, 1], outputRange: [-60, w + 60] }) },
            { rotate: '20deg' },
          ],
        }]}
      />
    </View>
  );
}

// Campo con icono y foco violeta
function IconInput({ icon, theme, ...props }) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={[styles.inputWrap, { backgroundColor: theme.input, borderColor: focused ? VIOLET : theme.border }]}>
      <Ionicons name={icon} size={18} color={focused ? VIOLET : theme.muted} />
      <TextInput
        {...props}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={[styles.inputInner, { color: theme.text }]}
        placeholderTextColor="#4A6080"
      />
    </View>
  );
}

// Tarjeta del entrenador vinculado
function CoachHero({ theme, nombre, email, foto, onRemove, L }) {
  return (
    <View style={[styles.hero, { backgroundColor: theme.card, borderColor: VIOLET + '55' }]}>
      <CourtLines color={VIOLET + '1E'} />
      <OrbitAvatar foto={foto} letra={nombre.charAt(0).toUpperCase()} />
      <Text style={[styles.name, { color: theme.text }]} numberOfLines={1}>{nombre}</Text>
      {!!email && <Text style={[styles.email, { color: theme.muted }]} numberOfLines={1}>{email}</Text>}
      <View style={[styles.chip, { backgroundColor: MINT + '1F', borderColor: MINT + '66' }]}>
        <PulseDot color={MINT} />
        <Text style={[styles.chipText, { color: MINT }]}>{L('Entrenador vinculado', 'Coach linked')}</Text>
      </View>
      <TouchableOpacity
        onPress={onRemove}
        style={[styles.removeBtn, { backgroundColor: RED + '1F' }]}
        hitSlop={8}
      >
        <Ionicons name="trash-outline" size={18} color={RED} />
      </TouchableOpacity>
    </View>
  );
}

// Tarjeta para pedir un entrenador
function RequestCard({ theme, email, setEmail, sending, onSend, L }) {
  const fly = usePingPong(1800);
  return (
    <View style={[styles.hero, { backgroundColor: theme.card, borderColor: VIOLET + '55', alignItems: 'stretch' }]}>
      <CourtLines color={VIOLET + '14'} />
      <View style={{ alignItems: 'center', marginBottom: 10 }}>
        <View style={{ width: 76, height: 76, alignItems: 'center', justifyContent: 'center' }}>
          <PulseRings size={76} color={VIOLET} />
          <View style={[styles.loadCircle, { width: 76, height: 76, borderRadius: 38, backgroundColor: VIOLET + '24', borderColor: VIOLET }]}>
            <Animated.View style={{ transform: [
              { translateX: fly.interpolate({ inputRange: [0, 1], outputRange: [-3, 3] }) },
              { translateY: fly.interpolate({ inputRange: [0, 1], outputRange: [3, -3] }) },
            ] }}>
              <Ionicons name="paper-plane" size={30} color={VIOLET} />
            </Animated.View>
          </View>
        </View>
      </View>
      <Text style={[styles.label, { color: theme.text }]}>{L('Introduce el correo de tu entrenador:', 'Enter your coach\'s email:')}</Text>
      <IconInput
        icon="mail-outline"
        theme={theme}
        value={email}
        onChangeText={setEmail}
        placeholder="correo@ejemplo.com"
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <Press onPress={onSend} disabled={sending} style={[styles.btnPrimary, sending && styles.disabled]}>
        {!sending && <Shine />}
        {sending
          ? <ActivityIndicator color="#fff" />
          : (<>
              <Ionicons name="paper-plane-outline" size={18} color="#fff" />
              <Text style={styles.btnPrimaryText}>{L('Enviar solicitud', 'Send request')}</Text>
            </>)}
      </Press>
    </View>
  );
}

// Tarjeta de atleta
function AtletaCard({ atleta, theme, delay, onPress }) {
  const color = colorDe(atleta.uid || atleta.nombre);
  return (
    <FadeIn delay={delay}>
      <Press onPress={onPress} style={[styles.atletaCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
        <View style={[styles.stripe, { backgroundColor: color }]} />
        <View style={[styles.avatarRing, { borderColor: color + '88' }]}>
          <Avatar
            foto={atleta.foto}
            letra={atleta.nombre ? atleta.nombre.charAt(0).toUpperCase() : 'A'}
            size={44}
            color={color}
          />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.atletaName, { color: theme.text }]} numberOfLines={1}>{atleta.nombre} {atleta.apellido}</Text>
        </View>
        <View style={[styles.goBtn, { backgroundColor: color + '22' }]}>
          <Ionicons name="chevron-forward" size={18} color={color} />
        </View>
      </Press>
    </FadeIn>
  );
}

// Estado vacío de atletas
function EmptyAtletas({ theme, text, loadingBg }) {
  const bob = usePingPong(2200);
  return (
    <FadeIn>
      <View style={styles.empty}>
        <Animated.View style={{ transform: [{ translateY: bob.interpolate({ inputRange: [0, 1], outputRange: [4, -4] }) }] }}>
          <View style={[styles.emptyCircle, { backgroundColor: VIOLET + '1A', borderColor: VIOLET + '55' }]}>
            <Ionicons name="people-outline" size={32} color={VIOLET} />
          </View>
        </Animated.View>
        <Text style={[styles.emptyText, { color: theme.muted }]}>{text}</Text>
        {loadingBg && <ActivityIndicator size="small" color={VIOLET} />}
      </View>
    </FadeIn>
  );
}

// Tarjeta de solicitud dentro del modal
function SolicitudCard({ item, theme, loc, index, onAceptar, onRechazar, L }) {
  const color = colorDe(item.atletaNombre);
  return (
    <FadeIn delay={index * 70}>
      <View style={[styles.solicitudCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
        <View style={styles.solicitudTop}>
          <Avatar letra={String(item.atletaNombre || 'A').charAt(0).toUpperCase()} size={42} color={color} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.solicitudName, { color: theme.text }]} numberOfLines={1}>{item.atletaNombre}</Text>
            <Text style={[styles.solicitudDate, { color: theme.muted }]}>
              {new Date(item.fecha).toLocaleDateString(loc, {
                day: 'numeric', month: 'short', year: 'numeric',
              })}
            </Text>
          </View>
        </View>
        <View style={styles.acciones}>
          <Press style={styles.btnAceptar} onPress={onAceptar}>
            <Ionicons name="checkmark" size={17} color="#0D1B2A" />
            <Text style={styles.btnAceptarText}>{L('Aceptar', 'Accept')}</Text>
          </Press>
          <Press style={styles.btnRechazar} onPress={onRechazar}>
            <Ionicons name="close" size={17} color={RED} />
            <Text style={styles.btnRechazarText}>{L('Rechazar', 'Reject')}</Text>
          </Press>
        </View>
      </View>
    </FadeIn>
  );
}

export default function CoachScreen() {
  const insets = useSafeAreaInsets();
  const user = auth.currentUser;
  const navigation = useNavigation();
  const appSettings = useAppSettings();
  const lang = appSettings.language;            // re-renderiza al cambiar idioma
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción
  const loc = lang === 'en' ? 'en-US' : 'es-ES';   // locale para fechas

  const [entrenador, setEntrenador] = useState(null);
  const [loading, setLoading] = useState(true);            // sin caché: spinner a pantalla completa
  const [refreshingBg, setRefreshingBg] = useState(false); // con caché: indicador discreto
  const [emailSolicitud, setEmailSolicitud] = useState('');
  const [sending, setSending] = useState(false);
  const [solicitudes, setSolicitudes] = useState([]);
  const [showSolicitudes, setShowSolicitudes] = useState(false);
  const [pedirEntrenadorOpen, setPedirEntrenadorOpen] = useState(false);   // desplegable de "añadir entrenador"
  const [atletas, setAtletas] = useState([]);
  const [buscaAbierta, setBuscaAbierta] = useState(false);   // lupa: buscador de atletas
  const [buscaAtleta, setBuscaAtleta] = useState('');
  const atletasVisibles = (() => {
    const t = buscaAtleta.trim().toLowerCase();
    if (!t) return atletas;
    return atletas.filter((a) => `${a.nombre || ''} ${a.apellido || ''}`.toLowerCase().includes(t));
  })();

  // Única fuente de verdad remota: el endpoint del servidor
  const fetchFromServer = useCallback(async (signal) => {
    const res = await fetch(`${SERVER_URL}/coach-screen-data/${user.uid}`, { signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    setEntrenador(data.entrenador ?? null);
    setSolicitudes(Array.isArray(data.solicitudes) ? data.solicitudes : []);
    setAtletas(Array.isArray(data.atletas) ? data.atletas : []);
    await cacheCoach(data);
    return data;
  }, [user.uid]);

  const fetchData = useCallback(async (force = false) => {
    if (!user) return;
    // 1) Pintar caché al instante si existe (nunca se oculta mientras refresca)
    let hasCache = false;
    try {
      const cached = await getCachedCoach();
      if (cached) {
        hasCache = true;
        setEntrenador(cached.entrenador ?? null);
        setSolicitudes(cached.solicitudes || []);
        setAtletas(cached.atletas || []);
      }
    } catch (e) {}
    setLoading(!hasCache);
    // 2) ¿Toca refrescar? (caché caducada o refresco forzado)
    let stale = true;
    try { stale = await isCacheStale(); } catch (e) {}
    if (!force && hasCache && !stale) { setLoading(false); return; }
    // 3) Refresco en segundo plano con timeout, sin ruleta que tape la lista
    if (hasCache) setRefreshingBg(true);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 25000);
    try {
      await fetchFromServer(controller.signal);
    } catch (err) {
      console.log('Error al obtener datos:', err.message);
    } finally {
      clearTimeout(timeout);
      setLoading(false);
      setRefreshingBg(false);
    }
  }, [user, fetchFromServer]);

  useFocusEffect(
    useCallback(() => {
      fetchData(false);
    }, [fetchData])
  );

  const handleEnviarSolicitud = async () => {
    if (!emailSolicitud.trim()) {
      Alert.alert(L('Error', 'Error'), L('Introduce el correo del entrenador', 'Enter your coach\'s email'));
      return;
    }
    setSending(true);
    try {
      const res = await fetch(`${SERVER_URL}/solicitar-entrenador`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ atletaId: user.uid, entrenadorEmail: emailSolicitud.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error del servidor');
      Alert.alert(L('Solicitud enviada', 'Request sent'), L('Tu solicitud ha sido enviada correctamente.', 'Your request has been sent successfully.'));
      setEmailSolicitud('');
      fetchData(true);
    } catch (err) {
      Alert.alert(L('Error', 'Error'), err.message);
    } finally {
      setSending(false);
    }
  };

  const handleGestionarSolicitud = async (solicitudId, accion) => {
    try {
      const res = await fetch(`${SERVER_URL}/gestionar-solicitud`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ solicitudId, entrenadorId: user.uid, accion }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error del servidor');
      fetchData(true);
      if (accion === 'aceptar') {
        Alert.alert(L('Solicitud aceptada', 'Request accepted'), L('El atleta ya aparece en tu lista.', 'The athlete now appears in your list.'));
      }
    } catch (err) {
      Alert.alert(L('Error', 'Error'), err.message);
    }
  };

  const handleEliminarEntrenador = async () => {
    Alert.alert(
      L('Eliminar entrenador', 'Remove coach'),
      L('¿Estás seguro de que quieres eliminar a tu entrenador?', 'Are you sure you want to remove your coach?'),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Eliminar', 'Remove'),
          style: 'destructive',
          onPress: async () => {
            try {
              const res = await fetch(`${SERVER_URL}/eliminar-entrenador`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ atletaId: user.uid }),
              });
              if (!res.ok) throw new Error('Error al eliminar');
              setEntrenador(null);
              await clearCoachCache();
              Alert.alert(L('Eliminado', 'Removed'), L('Entrenador eliminado correctamente.', 'Coach removed successfully.'));
              fetchData(true);
            } catch (err) {
              Alert.alert(L('Error', 'Error'), err.message);
            }
          },
        },
      ]
    );
  };

  const nombreCompletoEntrenador = entrenador
    ? `${entrenador.nombre || ''} ${entrenador.apellido || ''}`.trim() || L('Entrenador', 'Coach')
    : '';
  const fotoEntrenador = entrenador?.foto;

  if (loading) {
    return <LoadingScreen theme={theme} />;
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: theme.border, paddingTop: insets.top + 10 }]}>
        <Press onPress={() => navigation.goBack()} style={[styles.circleBtn, { backgroundColor: theme.card, borderColor: theme.border }]} hitSlop={10}>
          <Ionicons name="chevron-back" size={22} color="#8FA8C8" />
        </Press>
        <Text style={[styles.headerTitle, { color: theme.text }]}>{L('Mi Entrenador', 'My Coach')}</Text>
        <Press onPress={() => setShowSolicitudes(true)} style={[styles.circleBtn, { backgroundColor: theme.card, borderColor: solicitudes.length > 0 ? VIOLET + '88' : theme.border }]} hitSlop={10}>
          <WiggleBell count={solicitudes.length} />
        </Press>
      </View>

      <ScrollView
        contentContainerStyle={[styles.scrollContent, { paddingBottom: Math.max(40, insets.bottom + 16) }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Sección Entrenador */}
        <FadeIn style={styles.blockPad}>
          {entrenador ? (
            <CoachHero
              theme={theme}
              nombre={nombreCompletoEntrenador}
              email={entrenador.email || ''}
              foto={fotoEntrenador}
              onRemove={handleEliminarEntrenador}
              L={L}
            />
          ) : (
            <View>
              {/* Desplegable: colapsado por defecto para que no coma media
                  pantalla a quien entrena a otros; al abrirlo aparece la
                  tarjeta para pedir entrenador. */}
              <Press
                onPress={() => setPedirEntrenadorOpen((v) => !v)}
                style={[styles.pedirToggle, { backgroundColor: theme.card, borderColor: theme.border }]}
              >
                <View style={[styles.pedirIcono, { backgroundColor: VIOLET + '24' }]}>
                  <Ionicons name="person-add-outline" size={18} color={VIOLET} />
                </View>
                <Text style={[styles.pedirTexto, { color: theme.text }]}>
                  {L('Añadir entrenador', 'Add a coach')}
                </Text>
                <Ionicons
                  name={pedirEntrenadorOpen ? 'chevron-up' : 'chevron-down'}
                  size={18}
                  color={theme.muted}
                />
              </Press>
              {pedirEntrenadorOpen && (
                <FadeIn>
                  <RequestCard
                    theme={theme}
                    email={emailSolicitud}
                    setEmail={setEmailSolicitud}
                    sending={sending}
                    onSend={handleEnviarSolicitud}
                    L={L}
                  />
                </FadeIn>
              )}
            </View>
          )}
        </FadeIn>

        {/* Sección Atletas */}
        <FadeIn delay={140} style={styles.sectionContainer}>
          <View style={styles.sectionHeaderRow}>
            <View style={[styles.secBar, { backgroundColor: VIOLET }]} />
            <Text style={[styles.sectionTitle, { color: theme.text }]}>{L('Personas a las que entrenas', 'People you coach')}</Text>
            {atletas.length > 0 && (
              <View style={[styles.countChip, { backgroundColor: VIOLET + '22' }]}>
                <CountUp value={atletas.length} style={[styles.countChipText, { color: VIOLET }]} />
              </View>
            )}
            <View style={{ flex: 1 }} />
            {refreshingBg && <ActivityIndicator size="small" color={VIOLET} />}
            <Press
              style={[styles.buscaBtn, { backgroundColor: theme.card, borderColor: theme.border }, buscaAbierta && { borderColor: VIOLET, backgroundColor: VIOLET + '22' }]}
              onPress={() => { setBuscaAbierta((v) => !v); setBuscaAtleta(''); }}
            >
              <Ionicons name="search" size={16} color={VIOLET} />
            </Press>
          </View>
          {(buscaAbierta || buscaAtleta.trim() !== '') && (
            <FadeIn>
              <View style={[styles.buscaCaja, { backgroundColor: theme.card, borderColor: buscaAtleta ? VIOLET : theme.border }]}>
                <Ionicons name="search-outline" size={15} color="#8FA8C8" />
                <TextInput
                  style={[styles.buscaInput, { color: theme.text }]}
                  value={buscaAtleta}
                  onChangeText={setBuscaAtleta}
                  placeholder={L('Buscar atleta por nombre…', 'Search athlete by name…')}
                  placeholderTextColor="#4A6080"
                />
                {!!buscaAtleta && (
                  <Pressable onPress={() => setBuscaAtleta('')} hitSlop={8}>
                    <Ionicons name="close-circle" size={16} color="#8FA8C8" />
                  </Pressable>
                )}
              </View>
            </FadeIn>
          )}
          {atletas.length === 0 ? (
            <EmptyAtletas
              theme={theme}
              loadingBg={refreshingBg}
              text={refreshingBg ? L('Buscando atletas…', 'Looking for athletes…') : L('Aún no entrenas a nadie.', 'You don\'t coach anyone yet.')}
            />
          ) : (
            atletasVisibles.map((atleta, i) => (
              <AtletaCard
                key={atleta.uid}
                atleta={atleta}
                theme={theme}
                delay={Math.min(i * 60, 600)}
                onPress={async () => {
                  await AsyncStorage.setItem('currentAthleteId', atleta.uid);
                  await AsyncStorage.setItem('currentAthleteName', `${atleta.nombre} ${atleta.apellido}`.trim());
                  navigation.navigate('Main', { screen: 'Dashboard' });
                }}
              />
            ))
          )}
        </FadeIn>
      </ScrollView>

      {/* Modal de solicitudes */}
      <Modal visible={showSolicitudes} animationType="slide" transparent onRequestClose={() => setShowSolicitudes(false)}>
        <View style={styles.modalOverlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setShowSolicitudes(false)} />
          <View style={[styles.modalContent, { backgroundColor: theme.background, borderColor: theme.border, paddingBottom: Math.max(30, insets.bottom + 12) }]}>
            <View style={styles.handle} />
            <View style={[styles.modalHeader, { borderBottomColor: theme.border }]}>
              <View style={[styles.modalIcon, { backgroundColor: VIOLET + '22', borderColor: VIOLET + '66' }]}>
                <Ionicons name="mail-unread-outline" size={18} color={VIOLET} />
              </View>
              <Text style={[styles.modalTitle, { color: theme.text }]}>{L('Solicitudes pendientes', 'Pending requests')}</Text>
              <Press onPress={() => setShowSolicitudes(false)} style={[styles.closeBtn, { backgroundColor: theme.card }]} hitSlop={8}>
                <Ionicons name="close" size={20} color="#8FA8C8" />
              </Press>
            </View>
            {solicitudes.length === 0 ? (
              <View style={styles.empty}>
                <View style={[styles.emptyCircle, { backgroundColor: MINT + '1A', borderColor: MINT + '55' }]}>
                  <Ionicons name="checkmark-done" size={30} color={MINT} />
                </View>
                <Text style={[styles.emptyText, { color: theme.muted }]}>{L('No tienes solicitudes pendientes', 'You have no pending requests')}</Text>
              </View>
            ) : (
              <FlatList
                data={solicitudes}
                keyExtractor={(item) => item.id}
                showsVerticalScrollIndicator={false}
                renderItem={({ item, index }) => (
                  <SolicitudCard
                    item={item}
                    theme={theme}
                    loc={loc}
                    index={index}
                    L={L}
                    onAceptar={() => handleGestionarSolicitud(item.id, 'aceptar')}
                    onRechazar={() => handleGestionarSolicitud(item.id, 'rechazar')}
                  />
                )}
              />
            )}
          </View>
        </View>
        <SystemBars />
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  centered: { flex: 1, backgroundColor: NAVY, alignItems: 'center', justifyContent: 'center' },
  scrollContent: { paddingTop: 16, gap: 22 },
  blockPad: { paddingHorizontal: 16 },

  // Cabecera
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingBottom: 12,
    borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  circleBtn: { width: 40, height: 40, borderRadius: 20, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  badge: {
    position: 'absolute', top: -6, right: -9,
    backgroundColor: RED, borderRadius: 9, minWidth: 18, height: 18, paddingHorizontal: 4,
    alignItems: 'center', justifyContent: 'center',
  },
  badgeText: { color: '#fff', fontSize: 11, fontWeight: '800' },

  // Carga
  loadCircle: { width: 84, height: 84, borderRadius: 42, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },

  // Tarjeta principal (entrenador / solicitud)
  hero: {
    borderRadius: 24, borderWidth: 1.5, padding: 20, overflow: 'hidden',
    alignItems: 'center', gap: 4,
  },
  orbitInner: { position: 'absolute', alignItems: 'center', justifyContent: 'center' },
  orbitBadge: {
    position: 'absolute', right: 20, bottom: 18, width: 28, height: 28, borderRadius: 14,
    backgroundColor: MINT, alignItems: 'center', justifyContent: 'center',
    borderWidth: 3, borderColor: '#162032',
  },
  name: { fontSize: 20, fontWeight: '800', marginTop: 10 },
  email: { fontSize: 13, marginBottom: 8 },
  chip: {
    flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 6,
    paddingHorizontal: 14, paddingVertical: 7, borderRadius: 999, borderWidth: 1,
  },
  chipText: { fontSize: 13, fontWeight: '700' },
  removeBtn: {
    position: 'absolute', top: 14, right: 14, width: 38, height: 38, borderRadius: 19,
    alignItems: 'center', justifyContent: 'center', zIndex: 5,
  },
  pedirToggle: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    borderRadius: 16, borderWidth: 1.5, borderStyle: 'dashed',
    paddingHorizontal: 14, paddingVertical: 13,
  },
  pedirIcono: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  pedirTexto: { flex: 1, fontSize: 15, fontWeight: '700' },
  label: { fontSize: 14, fontWeight: '700', marginBottom: 10, textAlign: 'center' },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    borderRadius: 12, borderWidth: 1.5, paddingHorizontal: 12, marginBottom: 12,
  },
  inputInner: { flex: 1, paddingVertical: 12, fontSize: 14 },
  btnPrimary: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    backgroundColor: VIOLET, borderRadius: 14, paddingVertical: 15, overflow: 'hidden',
  },
  disabled: { opacity: 0.55 },
  btnPrimaryText: { color: '#fff', fontWeight: '800', fontSize: 15 },
  shine: {
    position: 'absolute', top: -30, height: 120, width: 28,
    backgroundColor: 'rgba(255,255,255,0.22)',
  },

  // Atletas
  sectionContainer: { paddingHorizontal: 16 },
  sectionHeaderRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 },
  secBar: { width: 4, height: 18, borderRadius: 2 },
  sectionTitle: { fontSize: 15, fontWeight: '800', flexShrink: 1 },
  countChip: { paddingHorizontal: 9, paddingVertical: 2, borderRadius: 999 },
  countChipText: { fontSize: 12, fontWeight: '800' },
  buscaBtn: { width: 36, height: 36, borderRadius: 18, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  buscaCaja: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 12, borderWidth: 1.5 },
  buscaInput: { flex: 1, fontSize: 14, paddingVertical: 2 },
  atletaCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    borderRadius: 16, paddingVertical: 10, paddingRight: 12, paddingLeft: 0,
    marginBottom: 10, borderWidth: 1, overflow: 'hidden',
  },
  stripe: { width: 5, alignSelf: 'stretch' },
  avatarRing: { padding: 2, borderRadius: 26, borderWidth: 2 },
  atletaName: { fontSize: 16, fontWeight: '700' },
  goBtn: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },

  // Estados vacíos
  empty: { alignItems: 'center', paddingVertical: 34, gap: 14 },
  emptyCircle: { width: 72, height: 72, borderRadius: 36, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  emptyText: { fontSize: 14, textAlign: 'center' },

  // Modal de solicitudes
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.65)', justifyContent: 'flex-end' },
  modalContent: {
    borderTopLeftRadius: 28, borderTopRightRadius: 28, borderWidth: 1, borderBottomWidth: 0,
    maxHeight: '80%',
  },
  handle: { alignSelf: 'center', width: 42, height: 4, borderRadius: 2, backgroundColor: '#4A6080', marginTop: 10 },
  modalHeader: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1,
  },
  modalIcon: { width: 36, height: 36, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  modalTitle: { fontSize: 17, fontWeight: '800', flex: 1 },
  closeBtn: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  solicitudCard: { padding: 14, marginHorizontal: 16, marginTop: 10, borderRadius: 16, borderWidth: 1 },
  solicitudTop: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  solicitudName: { fontSize: 16, fontWeight: '700' },
  solicitudDate: { fontSize: 12, marginTop: 3 },
  acciones: { flexDirection: 'row', marginTop: 14, gap: 10 },
  btnAceptar: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: MINT, borderRadius: 12, paddingVertical: 11,
  },
  btnAceptarText: { color: '#0D1B2A', fontWeight: '800' },
  btnRechazar: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: RED + '14', borderRadius: 12, paddingVertical: 11,
    borderWidth: 1, borderColor: RED + '88',
  },
  btnRechazarText: { color: RED, fontWeight: '800' },
});
