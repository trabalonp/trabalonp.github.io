/* tests/curvas-coste-test.js — REGRESIÓN DE LAS CURVAS (RONDA 41 + RONDA 42 + RONDA 43).
   Historial:
     · RONDA 39/40: al abrir «Curva FC» / «Curva ritmo» la app se iba a
       pantalla negra. Causa real medida: mejoresEsfuerzos() recorría el stream
       completo por cada una de las 10 000 distancias de la escalera de cada
       5 m → hasta 288 M de iteraciones seguidas (~16 s en móvil) → Android
       mataba la app sin error JS.
     · RONDA 41: se corrigió con escalas logarítmicas (~29× menos datos) y el
       crasheo desapareció, PERO la línea del entreno pasó a dibujarse con
       menos puntos de los reales (en entrenos con series se desviaba hasta
       2 px y el rango del eje Y cambiaba).
     · RONDA 42 (este contrato): la LÍNEA DEL ENTRENO vuelve a la escala
       COMPLETA original (cada 10 s / cada 5 m, TODOS los puntos) y la LÍNEA DE
       MEDIA se queda exactamente como estaba en la RONDA 41. Para no reintroducir
       el crasheo, mejoresEsfuerzos() mantiene el MISMO algoritmo y las MISMAS
       fórmulas con paso adaptativo + presupuesto acotado:
         - listas cortas (≤128 distancias: Picos, media, DISTS_CURVA_*) y
           distancias cortas: paso 1 → valores IDÉNTICOS bit a bit al original;
         - distancias largas de la escalera completa: paso ∝ D → error
           relativo ≤ 0,5 % (medido ≤ 0,11 % ⇒ ≤ 0,3 s/km ⇒ subpíxel);
         - coste total acotado por presupuesto incluso con streams de 16 h.
     · RONDA 43 (capturas del usuario vs intervals.icu): la curva de ritmo
       dibujada salía con «dientes» y con toda la información apretada en el
         tercio final del eje. Causas MEDIDAS (harness .tmp-r43/diag.js con
         distancia GPS realista: deriva lenta + jitter + rebotes multipath):
         - el mejor ritmo por distancia del ALGORITMO BASE (y de cualquiera
           sobre distancia GPS cruda) viola la monotonía 1 119 veces en 58 min:
           esos dientes son RUIDO del GPS acumulado, no forma real (la curva
           verdadera es monótona: toda ventana que cubre D+Δ cubre D);
         - con arranque de escalera en 5 m, el dominio log del render quedaba
           [0.005, máx] y las marcas 500 m/1 km/2 km/5 km caían al
           58/67/75/87 % del ancho (intervals.icu empieza su curva de ritmo
           en 1 km: marcas al 0/31/61/92 %).
       Fix: escalera de distancia desde 1 km (5 m si el entreno es < 1 km),
       cola izquierda < 1 km recortada TAMBIÉN de la línea de media (valores
       conservados bit a bit) para que no arrastre el dominio, y regresión
       isotónica (PAV) del ritmo de la escalera completa → 0 dientes. Listas
       cortas (Picos, media) sin tocar: valores exactos. Extra antichoque:
       reloj de pared PRESUPUESTO_MS en mejoresEsfuerzos y try/catch en los
       4 memos de curvas de WorkoutDetailModal (stream corrupto → «sin
       datos», nunca pantalla negra).
   Este test bloquea la clase de fallo, no el caso concreto.
   Uso: node tests/curvas-coste-test.js */
'use strict';
const fs = require('fs');
const path = require('path');

let pasadas = 0;
const fallos = [];
function ok(cond, msg) {
  if (cond) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log('FALLO ' + msg); }
}
function eq(a, b, msg) {
  if (a === b) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log(`FALLO ${msg} (esperado ${JSON.stringify(b)}, obtenido ${JSON.stringify(a)})`); }
}

const RAIZ = path.join(__dirname, '..');
const SRC_CURVAS = path.join(RAIZ, 'components', 'CurvasPicos.js');
const SRC_MODAL = path.join(RAIZ, 'screens', 'WorkoutDetailModal.js');
const srcCurvas = fs.readFileSync(SRC_CURVAS, 'utf8');
const srcModal = fs.readFileSync(SRC_MODAL, 'utf8');

/* ══════ Carga SOLO la parte de cálculo puro (sin React / RN / Skia) ══════ */
function cargarPuras(src) {
  const a = src.indexOf('const PAD_L');
  const b = src.indexOf('/* ── Curva Skia');
  if (a < 0 || b < 0 || b <= a) throw new Error('no se localiza la zona pura de CurvasPicos.js');
  const codigo = src.slice(a, b).replace(/^export\s+/gm, '');
  const nombres = ['curvasDuracion', 'mejoresEsfuerzos', 'tiempoAcumuladoFC', 'remuestrearPorSegundo',
    'promediarCurvas', 'duracionesCada10s', 'distanciasCada5m', 'duracionesReducidas', 'distanciasReducidas',
    'adelgazarEscala', 'duracionesParaMedia', 'distanciasParaMedia',
    'VENTANAS_FC', 'DISTS_CURVA_RUN', 'DISTS_CURVA_BIKE', 'DISTS_TABLA_RUN', 'DISTS_TABLA_BIKE'];
  const mod = { exports: {} };
  // eslint-disable-next-line no-new-func
  new Function('module', 'exports', `${codigo}\nmodule.exports = { ${nombres.join(', ')} };`)(mod, mod.exports);
  return mod.exports;
}
const M = cargarPuras(srcCurvas);

/* ══════ REFERENCIA 1: el algoritmo ORIGINAL del usuario (copia literal de su
   base) — la verdad absoluta contra la que se compara bit a bit. ══════ */
const GAP_REF = 30;
const tsRef = (r) => new Date(r.timestamp).getTime();
function mejoresEsfuerzosBase(regs, distsKm) {
  if (!regs || regs.length < 2 || !distsKm || !distsKm.length) return [];
  const pts = regs
    .map((r) => ({ t: tsRef(r), km: Number(r.distancia) || 0 }))
    .filter((p) => Number.isFinite(p.t) && p.km > 0);
  if (pts.length < 2) return [];
  const tm = [0];
  for (let i = 1; i < pts.length; i++) {
    const dt = (pts[i].t - pts[i - 1].t) / 1000;
    tm.push(tm[i - 1] + (dt > 0 && dt <= GAP_REF ? dt : 0));
  }
  const out = [];
  for (const D of distsKm) {
    if (pts[pts.length - 1].km < D) continue;
    let bestT = Infinity, j = 0;
    for (let i = 0; i < pts.length; i++) {
      if (j < i) j = i;
      while (j + 1 < pts.length && pts[j].km - pts[i].km < D) j++;
      if (pts[j].km - pts[i].km >= D) {
        let tFin = tm[j];
        if (j > i && pts[j].km > pts[j - 1].km) {
          const falt = (pts[j].km - pts[i].km) - D;
          const dkmSeg = pts[j].km - pts[j - 1].km;
          const dtSeg = tm[j] - tm[j - 1];
          if (dkmSeg > 0) tFin = tm[j] - (falt / dkmSeg) * dtSeg;
        }
        const t = tFin - tm[i];
        if (t > 0 && t < bestT) bestT = t;
      }
    }
    if (bestT < Infinity) out.push({ d: D, t: bestT, pace: bestT / D, speed: D / (bestT / 3600) });
  }
  return out;
}
function segmentosBase(regs) {
  const segs = [];
  for (let i = 0; i + 1 < regs.length; i++) {
    const dt = (tsRef(regs[i + 1]) - tsRef(regs[i])) / 1000;
    if (!(dt > 0) || dt > GAP_REF) continue;
    segs.push({ dt, fc: Number(regs[i].frecuencia) || 0, v: Number(regs[i].velocidad) || 0 });
  }
  return segs;
}
function curvasDuracionBase(regs, windows) {
  if (!regs || regs.length < 2) return [];
  const segs = segmentosBase(regs);
  const total = segs.reduce((a, s0) => a + s0.dt, 0);
  const out = [];
  for (const w of windows) {
    if (w > total) continue;
    let bfc = 0, bv = 0;
    let acc = 0, sfc = 0, sv = 0, lo = 0;
    for (let hi = 0; hi < segs.length; hi++) {
      acc += segs[hi].dt; sfc += segs[hi].fc * segs[hi].dt; sv += segs[hi].v * segs[hi].dt;
      while (lo < hi && acc - segs[lo].dt >= w) {
        sfc -= segs[lo].fc * segs[lo].dt; sv -= segs[lo].v * segs[lo].dt;
        acc -= segs[lo].dt; lo++;
      }
      if (acc >= w) {
        const f = sfc / acc, v = sv / acc;
        if (f > bfc) bfc = f;
        if (v > bv) bv = v;
      }
    }
    out.push({ w, fc: bfc, v: bv });
  }
  return out;
}

/* ══════ REFERENCIA 2: escalas de la RONDA 41 (línea de media, NO cambia) ══════ */
const TRAMOS_DUR_REF = [[600, 10], [1800, 30], [3600, 60]];
function duracionesReducidasRef(maxSec) {
  const max = Math.min(3600, Math.floor(Number(maxSec) || 0));
  const out = [];
  let anterior = 0;
  for (let i = 0; i < TRAMOS_DUR_REF.length; i++) {
    const tope = TRAMOS_DUR_REF[i][0], paso = TRAMOS_DUR_REF[i][1];
    if (max <= anterior) break;
    const fin = Math.min(max, tope);
    for (let s = anterior + paso; s <= fin; s += paso) out.push(s);
    anterior = tope;
  }
  const cola = Math.floor(max / 10) * 10;
  if (cola > 0 && (!out.length || cola > out[out.length - 1])) out.push(cola);
  return out;
}
const TRAMOS_DIS_REF = [[200, 5], [500, 10], [2000, 25], [5000, 50], [10000, 100], [21100, 250], [50000, 500]];
function distanciasReducidasRef(maxKm) {
  const maxM = Math.min(50000, Math.floor((Number(maxKm) || 0) * 1000));
  const out = [];
  let anterior = 0;
  for (let i = 0; i < TRAMOS_DIS_REF.length; i++) {
    const tope = TRAMOS_DIS_REF[i][0], paso = TRAMOS_DIS_REF[i][1];
    if (maxM <= anterior) break;
    const fin = Math.min(maxM, tope);
    for (let m = anterior + paso; m <= fin; m += paso) out.push(m / 1000);
    anterior = tope;
  }
  const colaM = Math.min(50000, Math.round(Math.min(50, Math.floor((Number(maxKm) || 0) * 200) / 200) * 1000));
  if (colaM >= 5 && (!out.length || colaM > Math.round(out[out.length - 1] * 1000))) out.push(colaM / 1000);
  return out;
}
function adelgazarRef(lista, max) {
  if (!Array.isArray(lista)) return [];
  if (lista.length <= max) return lista;
  const paso = Math.ceil(lista.length / max);
  const out = [];
  for (let i = 0; i < lista.length; i += paso) out.push(lista[i]);
  if (out[out.length - 1] !== lista[lista.length - 1]) out.push(lista[lista.length - 1]);
  return out;
}
/* Escaleras LINEALES de referencia (las de la base del usuario) */
const durLineal = (maxSec) => { const max = Math.min(3600, Math.floor(Number(maxSec) || 0)); const o = []; for (let s = 10; s <= max; s += 10) o.push(s); return o; };
const distLineal = (maxKm) => { const max = Math.min(50, Math.floor((Number(maxKm) || 0) * 200) / 200); const o = []; for (let m = 5; m <= Math.round(max * 1000); m += 5) o.push(m / 1000); return o; };
/* RONDA 43: escalera completa pero desde 1 km (como intervals.icu). */
const distLinealDesde1km = (maxKm) => { const max = Math.min(50, Math.floor((Number(maxKm) || 0) * 200) / 200); const o = []; for (let m = (max >= 1 ? 1000 : 5); m <= Math.round(max * 1000); m += 5) o.push(m / 1000); return o; };
/* Réplicas EXACTAS de los dos suavizados de la RONDA 43 (para acotar el
   error del PASO adaptativo separado del suavizado) + detector de dientes
   (desvío de cada peldaño frente a la media de sus ±2 vecinos: una forma
   legítima es suave en esa escala, un diente de GPS no). */
function dientes(cur) {
  let peor = 0;
  for (let i = 2; i + 2 < cur.length; i++) {
    const m = (cur[i - 2].pace + cur[i - 1].pace + cur[i + 1].pace + cur[i + 2].pace) / 4;
    const d = Math.abs(cur[i].pace - m);
    if (d > peor) peor = d;
  }
  return peor;
}
function suavizarKmRef(regs) {
  const pts = regs.map((r) => ({ t: new Date(r.timestamp).getTime(), km: Number(r.distancia) || 0 })).filter((q) => Number.isFinite(q.t) && q.km > 0);
  const km = pts.map((q) => q.km);
  const n = km.length, h = 4, out = [km[0]];
  for (let i = 1; i < n; i++) {
    let s0 = 0, c = 0;
    for (let k = Math.max(1, i - h); k <= Math.min(n - 1, i + h); k++) { s0 += km[k] - km[k - 1]; c++; }
    out.push(out[i - 1] + Math.max(0, s0 / c));
  }
  return pts.map((q, i2) => ({ timestamp: new Date(q.t).toISOString(), distancia: out[i2], velocidad: 0, frecuencia: 0 }));
}
function suavizarSalidaRef(list) {
  const out = list.map((q) => ({ ...q }));
  const n = out.length;
  if (n < 9) return out;
  const pre = [0];
  for (let i = 0; i < n; i++) pre.push(pre[i] + out[i].pace);
  for (let i = 0; i < n; i++) {
    let h = Math.round(10 * out[i].d);
    if (h < 3) h = 3;
    if (h > 250) h = 250;
    if (h > i) h = i;
    if (h > n - 1 - i) h = n - 1 - i;
    if (h < 1) continue;
    const pace = (pre[i + h + 1] - pre[i - h]) / (2 * h + 1);
    const t = pace * out[i].d;
    out[i].pace = pace; out[i].t = t; out[i].speed = out[i].d / (t / 3600);
  }
  return out;
}

/* ══════ Streams sintéticos 1 Hz (como un FIT real) ══════ */
function stream(seg, vCrucero, k = 9.2, semilla = 7) {
  const pts = [];
  let t = Date.UTC(2026, 8, 20, 7, 0, 0), km = 0, s = semilla, fcLag = 60 + k * vCrucero * 0.7;
  const rnd = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648; };
  for (let i = 0; i < seg; i++) {
    const p = i / seg;
    let v = vCrucero * (0.72 + 0.28 * Math.min(1, i / 300)) * (1 - 0.09 * p);
    v *= 1 + 0.025 * Math.sin(i / 37) + (rnd() - 0.5) * 0.03;
    v = Math.max(0.4, v);
    fcLag += ((60 + k * v + 9 * p) - fcLag) / 30;
    km += v / 3600;
    pts.push({
      timestamp: new Date(t).toISOString(), distancia: Number(km.toFixed(5)),
      frecuencia: Math.max(50, Math.min(205, Math.round(fcLag + (rnd() - 0.5) * 2.5))),
      velocidad: Number(v.toFixed(3)),
    });
    t += 1000;
  }
  return pts;
}
/* Carrera con SERIES (bloques rápidos/lentos + sprint): el peor caso para la
   envolvente de mejores esfuerzos. */
function streamSeries(minutos, semilla = 11) {
  const pts = []; let s = semilla;
  const rnd = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648; };
  let t = Date.UTC(2026, 8, 20, 7, 0, 0), km = 0;
  const N = minutos * 60;
  for (let i = 0; i < N; i++) {
    const bloque = Math.floor(i / 240) % 2;
    const fin = i > N - 90;
    let v = bloque ? 10.5 : 19.5;
    if (fin) v = 24;
    if (i < 300) v = 11 + (v - 11) * (i / 300);
    v *= 1 + 0.02 * Math.sin(i / 29) + (rnd() - 0.5) * 0.02;
    km += v / 3600;
    pts.push({ timestamp: new Date(t).toISOString(), distancia: Number(km.toFixed(5)), frecuencia: Math.round(130 + 2.2 * v), velocidad: Number(v.toFixed(3)) });
    t += 1000;
  }
  return pts;
}
/* Bici con PUERTOS: velocidad muy variable (12–40 km/h) y muchísimos km. */
function streamBici(horas, semilla = 23) {
  const pts = []; let s = semilla;
  const rnd = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648; };
  let t = Date.UTC(2026, 8, 20, 8, 0, 0), km = 0;
  const N = horas * 3600;
  for (let i = 0; i < N; i++) {
    const fase = Math.sin((i / N) * Math.PI * 6);
    let v = 26 + 14 * fase;
    v *= 1 + 0.03 * Math.sin(i / 53) + (rnd() - 0.5) * 0.03;
    v = Math.max(6, v);
    km += v / 3600;
    pts.push({ timestamp: new Date(t).toISOString(), distancia: Number(km.toFixed(5)), frecuencia: Math.round(110 + 1.6 * v), velocidad: Number(v.toFixed(3)) });
    t += 1000;
  }
  return pts;
}
const maxSecDe = (r) => (new Date(r[r.length - 1].timestamp) - new Date(r[0].timestamp)) / 1000;
const maxKmDe = (r) => Number(r[r.length - 1].distancia) || 0;

console.log('— 1) Escala COMPLETA de la línea del entreno = la original —');
eq(JSON.stringify(M.duracionesCada10s(3600)), JSON.stringify(durLineal(3600)), 'duracionesCada10s(1 h) = cada 10 s (360 ventanas, como la base)');
eq(JSON.stringify(M.duracionesCada10s(2699)), JSON.stringify(durLineal(2699)), 'duracionesCada10s(2699 s) idéntica a la base');
eq(JSON.stringify(M.distanciasCada5m(42.2)), JSON.stringify(distLinealDesde1km(42.2)), 'distanciasCada5m(42,2 km) = cada 5 m desde 1 km (RONDA 43, como intervals.icu)');
eq(JSON.stringify(M.distanciasCada5m(7.9)), JSON.stringify(distLinealDesde1km(7.9)), 'distanciasCada5m(7,9 km): mismo paso de 5 m, sin generalizar');
eq(JSON.stringify(M.distanciasCada5m(120)), JSON.stringify(distLinealDesde1km(120)), 'distanciasCada5m(120 km) con tope 50 km');
eq(M.distanciasCada5m(50).length, 9801, 'tope duro: 50 km ⇒ 9 801 distancias (antes 10 000; nunca más)');
eq(M.duracionesCada10s(7200).length, 360, 'tope duro: por encima de 1 h no pasan de 360 ventanas');
eq(M.distanciasCada5m(7.9)[0], 1, 'primer valor: 1 km (dominio del eje como intervals.icu)');
eq(JSON.stringify(M.distanciasCada5m(0.8)), JSON.stringify(distLineal(0.8)), 'entreno de menos de 1 km: sigue arrancando en 5 m');
eq(M.duracionesCada10s(2699)[0], 10, 'primer valor: 10 s');

console.log('\n— 2) Línea de MEDIA: escalas idénticas a la RONDA 41 (no cambia) —');
eq(JSON.stringify(M.duracionesReducidas(3600)), JSON.stringify(duracionesReducidasRef(3600)), 'duracionesReducidas = escalera de la RONDA 41');
eq(JSON.stringify(M.distanciasReducidas(50)), JSON.stringify(distanciasReducidasRef(50)), 'distanciasReducidas = escalera de la RONDA 41');
for (const v of [2699, 3600, 7200]) {
  eq(JSON.stringify(M.duracionesParaMedia(v)), JSON.stringify(adelgazarRef(duracionesReducidasRef(v), 60)), `duracionesParaMedia(${v}) = adelgazar(reducida, 60) de la RONDA 41`);
}
for (const v of [7.9, 42.2, 120]) {
  eq(JSON.stringify(M.distanciasParaMedia(v)), JSON.stringify(adelgazarRef(distanciasReducidasRef(v), 70).filter((d) => d >= 1)), `distanciasParaMedia(${v}) = valores R41/R42 sin la cola < 1 km (RONDA 43)`);
}
eq(JSON.stringify(M.distanciasParaMedia(0.8)), JSON.stringify(adelgazarRef(distanciasReducidasRef(0.8), 70)), 'distanciasParaMedia(0,8 km) sin recortar (entreno < 1 km)');
ok(M.distanciasParaMedia(50).length <= 71, `la media usa ≤71 distancias (obtenido ${M.distanciasParaMedia(50).length})`);
ok(M.duracionesParaMedia(3600).length <= 61, `la media usa ≤61 ventanas (obtenido ${M.duracionesParaMedia(3600).length})`);
eq(JSON.stringify(M.adelgazarEscala(null, 10)), '[]', 'adelgazarEscala(null) → []');

console.log('\n— 3) Casos límite (nada de NaN ni bucles infinitos) —');
for (const v of [0, -5, NaN, null, undefined, '', 'abc']) {
  ok(Array.isArray(M.duracionesCada10s(v)) && Array.isArray(M.distanciasCada5m(v)), `duracionesCada10s/distanciasCada5m(${JSON.stringify(v)}) devuelve array`);
  ok(M.duracionesCada10s(v).every(Number.isFinite) && M.distanciasCada5m(v).every(Number.isFinite), `...sin valores no numéricos para ${JSON.stringify(v)}`);
  ok(Array.isArray(M.distanciasParaMedia(v)) && Array.isArray(M.duracionesParaMedia(v)), `escalas de media(${JSON.stringify(v)}) devuelven array`);
}
eq(M.distanciasCada5m(0).length, 0, 'distanciasCada5m(0) vacío');
eq(M.duracionesCada10s(5).length, 0, 'duracionesCada10s(5 s) vacío (la primera ventana es 10 s)');
eq(JSON.stringify(M.mejoresEsfuerzos([], [1])), '[]', 'mejoresEsfuerzos sin registros → []');
eq(JSON.stringify(M.mejoresEsfuerzos(stream(10, 10), [])), '[]', 'mejoresEsfuerzos sin distancias → [] (no recorre el stream en balde)');
eq(JSON.stringify(M.mejoresEsfuerzos(stream(600, 10), [NaN, -1, 0])), '[]', 'distancias inválidas (NaN/-1/0) → [] sin excepción');
eq(JSON.stringify(M.curvasDuracion(null)), '[]', 'curvasDuracion(null) → []');
eq(JSON.stringify(M.tiempoAcumuladoFC(undefined)), '[]', 'tiempoAcumuladoFC(undefined) → []');

console.log('\n— 4) Listas cortas (Picos, media, DISTS_CURVA): BIT A BIT como la base —');
const STREAMS_CORTOS = [
  ['carrera 45 min', stream(2700, 11)],
  ['carrera 1 h', stream(3600, 12.2)],
  ['series 80 min', streamSeries(80)],
  ['maratón 4 h', stream(14400, 10.7)],
  ['bici puertos 5 h', streamBici(5)],
];
for (const [nom, regs] of STREAMS_CORTOS) {
  const listas = [
    ['DISTS_TABLA_RUN', M.DISTS_TABLA_RUN],
    ['DISTS_TABLA_BIKE', M.DISTS_TABLA_BIKE],
    ['DISTS_CURVA_RUN', M.DISTS_CURVA_RUN],
    ['escalera de media', M.distanciasParaMedia(maxKmDe(regs))],
  ];
  let todosIguales = true;
  for (const [, lista] of listas) {
    if (JSON.stringify(M.mejoresEsfuerzos(regs, lista)) !== JSON.stringify(mejoresEsfuerzosBase(regs, lista))) todosIguales = false;
  }
  ok(todosIguales && listas.every(([, l]) => l.length <= 128), `${nom}: tabla de Picos, DISTS_CURVA y media → valores IDÉNTICOS bit a bit a la base`);
}

console.log('\n— 5) Escalera COMPLETA (cada 5 m desde 1 km): todas las distancias, sin dientes y con los quiebres reales —');
const TOPE_DELTA = { 'carrera 45 min': 1, 'carrera 1 h': 1, 'series 80 min': 2.5, 'maratón 4 h': 1, 'bici puertos 5 h': 2.5 };
for (const [nom, regs] of STREAMS_CORTOS) {
  const dis = M.distanciasCada5m(maxKmDe(regs));
  const nueva = M.mejoresEsfuerzos(regs, dis);
  const ref = mejoresEsfuerzosBase(regs, dis);
  // Referencia EXACTA (fuerza bruta) sobre los mismos datos suavizados y con
  // el mismo suavizado de salida: la diferencia contra ella es SOLO el paso
  // adaptativo, que es el contrato de fidelidad de la RONDA 42.
  const refS = suavizarSalidaRef(mejoresEsfuerzosBase(suavizarKmRef(regs), dis));
  eq(nueva.length, ref.length, `${nom}: la curva tiene TODAS las distancias de la escalera completa (${ref.length})`);
  ok(nueva.every((p, k) => p.d === ref[k].d), `${nom}: mismas distancias, mismo orden`);
  let nBits = 0, peorRel = 0, peorD = 0;
  for (let k = 0; k < nueva.length; k++) {
    if (nueva[k].t === refS[k].t) nBits++;
    const rel = Math.abs(nueva[k].t - refS[k].t) / refS[k].t;
    if (rel > peorRel) { peorRel = rel; peorD = nueva[k].d; }
  }
  ok(peorRel <= 0.005, `${nom}: error del paso adaptativo ${((peorRel * 100).toFixed(3))}% ≤ 0,5% vs referencia exacta con el mismo suavizado (en D=${peorD.toFixed(3)} km)`);
  // La zona de paso 1 (bit a bit) sólo pisa la escalera si arranca por debajo
  // de K·espaciado: en entrenos largos (maratón, bici) el presupuesto relaja K
  // y esa zona queda < 1 km, fuera de la escalera → ahí manda el ≤0,5%.
  const CON_BITS = new Set(['carrera 45 min', 'carrera 1 h', 'series 80 min']);
  if (CON_BITS.has(nom)) ok(nBits >= 60, `${nom}: ${nBits} distancias bit a bit idénticas a esa referencia`);
  else ok(nBits === 0 && peorRel <= 0.005, `${nom}: entreno largo sin zona de paso 1 en la escalera (K relajado por presupuesto); el ≤0,5% cubre la fidelidad`);
  ok(dientes(nueva) <= dientes(ref) + 1e-12, `${nom}: dientes ${dientes(ref).toFixed(2)} → ${dientes(nueva).toFixed(2)} s/km (el suavizado nunca los aumenta)`);
  let peor = 0;
  for (let k = 0; k < nueva.length; k++) peor = Math.max(peor, Math.abs(nueva[k].pace - ref[k].pace));
  ok(peor <= (TOPE_DELTA[nom] || 3), `${nom}: desplazamiento total vs base cruda ${peor.toFixed(2)} s/km ≤ ${TOPE_DELTA[nom] || 3} (ruido quitado, no forma)`);
}

console.log('\n— 5b) Stream sin ruido: el suavizado es casi identidad (≤1 s/km) y no inventa dientes —');
{
  const limpio = [];
  let t = Date.UTC(2026, 8, 20, 7, 0, 0), km = 0;
  for (let i = 0; i < 3600; i++) { const v = 3.6 * (1 - 0.00002 * i); km += v / 1000; limpio.push({ timestamp: new Date(t).toISOString(), distancia: Number(km.toFixed(6)), velocidad: Number(v.toFixed(4)), frecuencia: 150 }); t += 1000; }
  const dis = M.distanciasCada5m(maxKmDe(limpio));
  const a = M.mejoresEsfuerzos(limpio, dis);
  const b = mejoresEsfuerzosBase(limpio, dis);
  let peor = 0;
  for (let k = 0; k < a.length; k++) peor = Math.max(peor, Math.abs(a[k].pace - b[k].pace));
  ok(peor <= 1, `stream limpio: desplazamiento ${peor.toFixed(2)} s/km ≤ 1 (suavizar datos sin ruido ≈ identidad)`);
  ok(dientes(a) <= dientes(b) + 1e-12, 'stream limpio: sin dientes añadidos');
}

console.log('\n— 6) Curva de FC con escalera completa: bit a bit como la base —');
for (const [nom, regs] of STREAMS_CORTOS) {
  const w = M.duracionesCada10s(maxSecDe(regs));
  eq(JSON.stringify(M.curvasDuracion(regs, w)), JSON.stringify(curvasDuracionBase(regs, w)), `${nom}: mejor FC/velocidad por ventana IDÉNTICO a la base (${w.length} ventanas)`);
}

console.log('\n— 7) Sin Math.min(...array) en la zona de cálculo (RangeError en Hermes) —');
const zonaPura = srcCurvas.slice(srcCurvas.indexOf('const PAD_L'), srcCurvas.indexOf('/* ── Curva Skia'))
  .split('\n').filter((l) => !l.trim().startsWith('//') && !l.trim().startsWith('/*') && !l.trim().startsWith('*')).join('\n');
ok(!/Math\.(min|max)\(\s*\.\.\./.test(zonaPura), 'la zona de cálculo no usa spread sobre arrays (Math.min(...arr))');
ok(/for \(let i = 0; i < segs\.length; i\+\+\)/.test(zonaPura), 'tiempoAcumuladoFC saca el min/max con un bucle');
const giganteFc = stream(120000, 11); // 33 h de muestras: con spread revienta la pila
let acum = null, errAcum = null;
try { acum = M.tiempoAcumuladoFC(giganteFc, 10); } catch (e) { errAcum = e; }
ok(!errAcum, `tiempoAcumuladoFC con ${giganteFc.length} muestras no lanza excepción${errAcum ? ': ' + errAcum.message : ''}`);
ok(Array.isArray(acum) && acum.length > 1 && acum.every((p) => Number.isFinite(p.x) && Number.isFinite(p.v)), 'devuelve puntos válidos');

console.log('\n— 8) Presupuesto de dibujo de CurvaSkia (Math.min(...xs) del render) —');
// CurvaSkia (intacta) hace Math.min(...xs) con los puntos de la curva + los de
// la media. Peor caso RONDA 43: escalera completa de ritmo desde 1 km (9 801)
// + media recortada (≤69): ~9 870 argumentos ≈ 79 KB de pila, ≥6× por debajo
// del límite más estricto conocido de los motores (≈65 000 args).
const maxDibujados = M.distanciasCada5m(50).length + M.distanciasParaMedia(50).length;
ok(maxDibujados <= 10071, `peor caso de puntos dibujados: ${maxDibujados} ≤ 10 071 (margen ≥6× sobre el límite de spread)`);
ok(M.duracionesCada10s(3600).length + M.duracionesParaMedia(3600).length <= 421, `curva de FC: ≤421 puntos (360 + media)`);

console.log('\n— 9) Streams enormes: sin excepción, escalera completa, coste acotado —');
const ultra16h = stream(57600, 7.6);
let r1 = null, r2 = null, err = null;
const t0 = Date.now();
try { r1 = M.curvasDuracion(ultra16h, M.duracionesCada10s(maxSecDe(ultra16h))); r2 = M.mejoresEsfuerzos(ultra16h, M.distanciasCada5m(maxKmDe(ultra16h))); } catch (e) { err = e; }
const dt = Date.now() - t0;
ok(!err, `16 h (${ultra16h.length} muestras): sin excepción${err ? ' → ' + err.message : ''}`);
eq(r1.length, 360, '16 h: la curva de FC tiene las 360 ventanas completas');
eq(r2.length, M.distanciasCada5m(maxKmDe(ultra16h)).length, '16 h: la curva de ritmo tiene TODAS las distancias (tope 50 km)');
ok(r1[r1.length - 1].fc > 0 && r2[r2.length - 1].t > 0, '16 h: resultados coherentes');
ok(dt <= 2500, `16 h: las dos curvas en ${dt} ms (≤2500 ms en este equipo)`);

console.log('\n— 10) Coste total acotado (el hilo JS no se bloquea) —');
// En la app cada pestaña calcula SOLO lo suyo (ver sección 12); aquí se suma
// todo para dejar margen de sobra. Móvil ≈ ×6 lo medido en este equipo.
for (const [nom, regs, topeMs] of [
  ['carrera 45 min', stream(2700, 11), 500],
  ['carrera 1 h', stream(3600, 12.2), 500],
  ['series 80 min', streamSeries(80), 500],
  ['maratón 4 h', stream(14400, 10.7), 1000],
  ['bici puertos 5 h', streamBici(5), 1800],
  ['ultra bici 8 h', stream(28800, 7.6), 1800],
]) {
  M.curvasDuracion(regs.slice(0, 300), M.duracionesCada10s(300)); // calienta el JIT
  M.mejoresEsfuerzos(regs.slice(0, 300), M.distanciasCada5m(maxKmDe(regs.slice(0, 300))));
  const t = Date.now();
  M.curvasDuracion(regs, M.duracionesCada10s(maxSecDe(regs)));
  M.mejoresEsfuerzos(regs, M.distanciasCada5m(maxKmDe(regs)));
  M.tiempoAcumuladoFC(regs, 10);
  M.mejoresEsfuerzos(regs, M.DISTS_TABLA_RUN);
  const ms = Date.now() - t;
  ok(ms <= topeMs, `${nom}: las 4 curvas completas en ${ms} ms (tope ${topeMs} ms en este equipo)`);
}

console.log('\n— 11) La zona de RENDER de CurvasPicos.js no se ha tocado —');
const zonaRender = srcCurvas.slice(srcCurvas.indexOf('/* ── Curva Skia'));
for (const pieza of ['export function CurvaSkia(', 'export function ChartCard(', 'export function FullChartModal(', 'export function TablaEsfuerzos(', 'simplificarCurva']) {
  if (pieza === 'simplificarCurva') { ok(!zonaRender.includes(pieza), 'sin helper de render añadido (simplificarCurva)'); continue; }
  ok(zonaRender.includes(pieza), `sigue existiendo ${pieza}`);
}
ok(!zonaRender.includes('hint'), 'FullChartModal sin props nuevas (hint)');
/* Base de RENDER nueva del 29/09 (ZIP version29926 del usuario): el marco
   estático (rejilla + franjas + canvas) va memoizado en CurvaFrame y el
   marcador/tooltip son Views por encima, así el lienzo no se vacía al
   arrastrar. Se congela esa base: si alguien la redefine, salta. */
ok(/const CurvaFrame = React\.memo\(/.test(zonaRender), 'base 29/09: marco memoizado CurvaFrame presente');
ok(/const TIP_W = 140;/.test(srcCurvas) && /width: TIP_W/.test(srcCurvas), 'base 29/09: tooltip con ancho fijo TIP_W');
ok(!/Circle/.test(srcCurvas.slice(0, srcCurvas.indexOf('/* ── Curva Skia'))), 'base 29/09: sin import Circle (el marcador es un View)');
ok(/tipLeft = pxv - 12 - TIP_W/.test(zonaRender), 'base 29/09: tooltip al lado del punto con flip por borde derecho');

console.log('\n— 12) WorkoutDetailModal: fuente —');
ok(/subTab === 'curvafc' \|\| subTab === 'curvaritmo' \|\| subTab === 'picos'/.test(srcModal.replace(/[\r\n]/g, ' ')), 'las pestañas de curvas cargan los registros (fix «sin datos»)');
ok(/registrosGrafica = useMemo\(\(\) => \(subTab === 'detalles'/.test(srcModal), 'el remuestreo a 1 Hz sólo se calcula en Detalles (ActivityChart)');
ok(/curvasDuracion\(registrosCurva/.test(srcModal) && /mejoresEsfuerzos\(registrosCurva/.test(srcModal), 'las curvas usan el stream FIT original, no el remuestreado');
ok(!/remuestrearPorSegundo\(s\.data\(\)\.puntos/.test(srcModal), 'el histórico de la línea de media ya no remuestrea 12 streams');
ok(/const curvas = useMemo\(\(\) => \{ try \{ return subTab === 'curvafc' \? curvasDuracion/.test(srcModal), 'la curva de FC sólo se calcula en su pestaña (con try/catch RONDA 43)');
ok(/const esfuerzosCurva = useMemo\(\(\) => \{ try \{ return subTab === 'curvaritmo' \? mejoresEsfuerzos/.test(srcModal), 'la curva de ritmo sólo se calcula en su pestaña (con try/catch RONDA 43)');
ok(/const esfuerzos = useMemo\(\(\) => \{ try \{ return subTab === 'picos' \? mejoresEsfuerzos/.test(srcModal), 'la tabla de picos sólo se calcula en su pestaña (con try/catch RONDA 43)');
ok(/const acumFcPts = useMemo\(\(\) => \{ try \{ return subTab === 'curvafc' \? tiempoAcumuladoFC/.test(srcModal), 'el tiempo acumulado sólo se calcula en Curva FC (con try/catch RONDA 43)');
eq((srcModal.match(/useMemo\(\(\) => \{ try \{ return/g) || []).length, 4, 'WDM: exactamente 4 memos de cálculo con try/catch (stream corrupto → «sin datos», no pantalla negra)');
ok(/duracionesCada10s\(maxCurvaSec\)/.test(srcModal) && /distanciasCada5m\(maxCurvaKm\)/.test(srcModal), 'la línea del entreno usa la escala COMPLETA (cada 10 s / cada 5 m)');
ok(/const venMedia = useMemo\(\(\) => duracionesParaMedia\(maxCurvaSec\)/.test(srcModal), 'la línea de media usa duracionesParaMedia (escala RONDA 41)');
ok(/const disMedia = useMemo\(\(\) => distanciasParaMedia\(maxCurvaKm\)/.test(srcModal), 'la línea de media usa distanciasParaMedia (escala RONDA 41)');
ok(/const ven = subTab === 'curvafc' \? venMedia : \[\]/.test(srcModal) && /const dis = subTab === 'curvaritmo' \? disMedia : \[\]/.test(srcModal), 'el histórico calcula sólo la serie de la pestaña abierta');
ok(/await new Promise\(\(resolve\) => setTimeout\(resolve, 0\)\)/.test(srcModal), 'el histórico cede el hilo JS entre entreno y entreno');
const spreadsModal = (srcModal.match(/Math\.(min|max)\(\s*\.\.\./g) || []).length;
eq(spreadsModal, 2, 'WorkoutDetailModal sigue con sus 2 spread preexistentes (ritmo de VUELTAS, array pequeño) y ninguno nuevo');
ok(!/Math\.(min|max)\(\s*\.\.\./.test(srcModal.slice(srcModal.indexOf('const registrosGrafica'), srcModal.indexOf('const [fullChart'))), 'la zona de cálculo de curvas no usa spread sobre el stream');
ok(!/adelgazarEscala/.test(srcModal), 'WDM ya no compone a mano la escala de media (usa duracionesParaMedia/distanciasParaMedia)');

console.log('\n— 13) RONDA 43: dientes fuera, eje desde 1 km, quiebres reales dentro, reloj de pared —');
/* Carrera con distancia GPS realista (deriva + jitter + rebotes de multipath
   de ~18-36 m cada 2 min): el MISMO generador del harness .tmp-r43/diag.js. */
function streamGPS(min, semilla, saltoM) {
  let s2 = semilla;
  const rnd = () => { s2 = (s2 * 1103515245 + 12345) % 2147483648; return s2 / 2147483648; };
  const gauss = () => { const u = Math.max(1e-12, rnd()), v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
  const pts = [];
  let t = Date.UTC(2026, 8, 13, 7, 0, 0), km = 0, deriva = 0;
  const vBase = 1000 / 245;
  for (let i = 0; i < min * 60; i++) {
    deriva = Math.max(-0.05, Math.min(0.05, deriva + gauss() * 0.008));
    let eps = deriva + gauss() * 0.035 + 0.05 * Math.sin(i / 47);
    let inc = vBase * Math.max(0.2, 1 + eps);
    if (saltoM && i % 120 === 57) inc += saltoM * (0.5 + rnd());
    km += inc / 1000;
    pts.push({ timestamp: new Date(t).toISOString(), distancia: Number(km.toFixed(5)), velocidad: Number(inc.toFixed(3)), frecuencia: Math.round(150 + 10 * Math.sin(i / 200)) });
    t += 1000;
  }
  return pts;
}
const gps = streamGPS(58, 5, 18);
const disGps = M.distanciasCada5m(maxKmDe(gps));
const crudaGps = mejoresEsfuerzosBase(gps, disGps);
const suaveGps = M.mejoresEsfuerzos(gps, disGps);
const dBase = dientes(crudaGps), dNueva = dientes(suaveGps);
ok(dBase >= 0.4, `el algoritmo BASE con GPS realista (saltos de multipath) sale con dientes: ${dBase.toFixed(2)} s/km = el defecto de la captura`);
ok(dNueva <= 0.35 * dBase, `RONDA 43: dientes ${dBase.toFixed(2)} → ${dNueva.toFixed(2)} s/km (≥65 % de atenuación)`);
let peorMov = 0;
for (let k = 0; k < suaveGps.length; k++) peorMov = Math.max(peorMov, Math.abs(suaveGps[k].pace - crudaGps[k].pace));
ok(peorMov <= 4, `el suavizado sólo recoloca ruido: peor Δ vs base cruda ${peorMov.toFixed(2)} s/km ≤ 4 s/km`);
{
  // La bajada legítima del sprint final (series) se conserva: profundidad del
  // mínimo local en la zona del sprint con ±2,5 s/km de tolerancia.
  const regs = STREAMS_CORTOS.find((x) => x[0] === 'series 80 min')[1];
  const dis = M.distanciasCada5m(maxKmDe(regs));
  const a = M.mejoresEsfuerzos(regs, dis), b = mejoresEsfuerzosBase(regs, dis);
  const minEn = (cur) => cur.filter((p) => p.d >= 2.25 && p.d <= 2.45).reduce((m, p) => Math.min(m, p.pace), Infinity);
  ok(Math.abs(minEn(a) - minEn(b)) <= 2.5, `la bajada del sprint final se conserva (mínimo ${minEn(b).toFixed(1)} → ${minEn(a).toFixed(1)} s/km)`);
}
eq(JSON.stringify(M.mejoresEsfuerzos(gps, M.DISTS_TABLA_RUN)), JSON.stringify(mejoresEsfuerzosBase(gps, M.DISTS_TABLA_RUN)), 'tabla de Picos con GPS ruidoso: valores EXACTOS de la base (sin suavizar)');
eq(JSON.stringify(M.mejoresEsfuerzos(gps, M.distanciasParaMedia(maxKmDe(gps)))), JSON.stringify(mejoresEsfuerzosBase(gps, M.distanciasParaMedia(maxKmDe(gps)))), 'línea de media con GPS ruidoso: valores EXACTOS de la base (sin suavizar)');
eq(disGps[0], 1, 'la escalera dibujada arranca en 1 km');
ok(M.distanciasParaMedia(maxKmDe(gps))[0] >= 1, 'la línea de media no arrastra el dominio a 5 m');
{
  // Posición de las marcas del eje con la geometría log real de CurvaSkia.
  const frac = (v, xMin, xMax) => Math.log(v / xMin) / Math.log(xMax / xMin);
  ok(frac(2, 1, 9.65) < 0.35, `marca 2 km al ${(frac(2, 1, 9.65) * 100).toFixed(0)} % del ancho con dominio desde 1 km (antes ${(frac(2, 0.005, 9.65) * 100).toFixed(0)} %: apretujada al final)`);
  ok(frac(5, 1, 9.65) < 0.75, `marca 5 km al ${(frac(5, 1, 9.65) * 100).toFixed(0)} % (antes ${(frac(5, 0.005, 9.65) * 100).toFixed(0)} %)`);
}
ok(/PRESUPUESTO_MS = 700/.test(srcCurvas) && /Date\.now\(\) - t0 > PRESUPUESTO_MS/.test(srcCurvas), 'reloj de pared PRESUPUESTO_MS dentro de mejoresEsfuerzos (acota el tiempo real aunque el modelo de iteraciones falle)');
ok(/const SUAVIZADO_W = 9;/.test(srcCurvas) && /function suavizarKm\(km, n\)/.test(srcCurvas) && /function suavizarSalida\(out\)/.test(srcCurvas), 'suavizado de incrementos (W=9) + suavizado de salida proporcional, sólo en la escalera completa');
ok(/if \(!exacta\) suavizarSalida\(out\);/.test(srcCurvas) && /if \(!exacta\) \{ const sv = suavizarKm\(km, n\);/.test(srcCurvas), 'las listas exactas (Picos, media) no pasan por ningún suavizado');

console.log('');
if (fallos.length) { console.error(`❌ ${fallos.length} FALLOS de ${pasadas + fallos.length} aserciones`); fallos.forEach((f) => console.error('   · ' + f)); process.exit(1); }
console.log(`TODO OK — ${pasadas} aserciones pasadas`);
