/* tests/trimp-esfuerzo-test.js — REGRESIÓN RONDA 46 (esfuerzo = TRIMP de
   Banister, mismo algoritmo que TrainerPlan).

   Motivo: los valores de esfuerzo de la app diferían mucho de los de
   TrainerPlan porque la app normalizaba el TRIMP a escala TSS (1 h al umbral
   de FC = 100). TrainerPlan usa el TRIMP CLÁSICO de Banister con la FC máxima
   y la FC de reposo del perfil, integrando la variación de FC del entreno:

     r(t) = (FC(t) − FCrep) / (FCmax − FCrep)  acotado a [0,1]
     TRIMP = Σ (Δt min) · r · C·e^(B·r)   hombres C=0.64 B=1.92 · mujeres C=1.67 B=0.89

   Escala de referencia (capturas oficiales del blog de TrainerPlan):
   trote 30 min ≈ 21 · series 60 min ≈ 112 · tirada 75 min ≈ 143.

   El test extrae el bloque marcado __TRIMP_START__/__TRIMP_END__ de
   services/SyncService.js y lo EJECUTA de verdad (son funciones puras), además
   de comprobar los puntos de integración (FIT, resumen, modal, Zonas).
   Uso: node tests/trimp-esfuerzo-test.js */
'use strict';
const fs = require('fs');
const path = require('path');

let pasadas = 0;
const fallos = [];
function ok(cond, msg) {
  if (cond) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log('FALLO ' + msg); }
}
function eq(a, b, msg) {
  if (a === b) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log(`FALLO ${msg} (esperado ${JSON.stringify(b)}, obtenido ${JSON.stringify(a)})`); }
}

const RAIZ = path.join(__dirname, '..');
const leer = (p) => fs.readFileSync(path.join(RAIZ, p), 'utf8');
const srcSync = leer('services/SyncService.js');
const srcWDM = leer('screens/WorkoutDetailModal.js');
const srcZonas = leer('screens/ZonesScreen.js');

// ── Carga el código TRIMP real del SyncService (funciones puras) ──
const i0 = srcSync.indexOf('// __TRIMP_START__');
const i1 = srcSync.indexOf('// __TRIMP_END__');
ok(i0 > 0 && i1 > i0, 'el bloque TRIMP está marcado en SyncService.js');
const codigo = srcSync.slice(i0, i1).replace(/^export /gm, '');
const numOrNull = (v) => (v != null && Number.isFinite(Number(v)) ? Number(v) : null);
const M = new Function('numOrNull', codigo +
  '; return { coefTrimp, trimpBanister, hrMaxParaTrimp, hrRestParaTrimp, calcularTrimpEsfuerzo };')(numOrNull);

const FECHA = new Date('2026-09-20T09:00:00Z');
const DIA = '2026-09-20';
const mk = (n, fc, t0, fcPico) => Array.from({ length: n }, (_, i) => ({ t: (t0 || 0) + i * 1000, fc: fcPico != null && i === n - 1 ? fcPico : fc }));
const PERFIL = { umbralFC: 190, fcReposo: 60, sexo: 'Masculino' };

console.log('— 1) Coeficientes de Banister por sexo —');
eq(M.coefTrimp('Masculino').C, 0.64, 'hombre C=0.64');
eq(M.coefTrimp('Masculino').B, 1.92, 'hombre B=1.92');
eq(M.coefTrimp('Femenino').C, 1.67, 'mujer C=1.67');
eq(M.coefTrimp('Femenino').B, 0.89, 'mujer B=0.89');
eq(M.coefTrimp(undefined).C, 0.64, 'sin sexo → coeficientes de hombre (default)');

console.log('— 2) TRIMP integrado con muestras de FC —');
{
  // 3600 muestras a 1 s con FC 150, FCmax 190, FCrep 60 → r=0.6923 →
  // 59.983 min · 0.6923 · 0.64 · e^(1.92·0.6923) = 100.4 → 100
  const int = M.trimpBanister(mk(3600, 150), 190, 60, 'Masculino');
  ok(int != null, 'integra 1 h de muestras sin devolver null');
  eq(int.segundosCubiertos, 3599, 'cubre 3599 s (3599 intervalos de 1 s)');
  eq(Math.round(int.trimp), 100, '1 h a FC 150 (max 190, rep 60) = TRIMP 100');
}
{
  // Un hueco de 10 min (reloj parado) NO debe sumar esfuerzo
  const a = mk(1800, 150, 0);
  const b = mk(1800, 150, 1800000 + 600000);
  const int = M.trimpBanister(a.concat(b), 190, 60, 'Masculino');
  eq(int.segundosCubiertos, 3598, 'el hueco de 10 min no suma segundos cubiertos');
  eq(Math.round(int.trimp), 100, 'con pausa de 10 min el TRIMP es el mismo que sin pausa');
}
{
  // Muestras con FC 0 (banda sin lectura) no suman
  const m = mk(3600, 150);
  for (let i = 1000; i <= 2000; i++) m[i].fc = 0;
  const int = M.trimpBanister(m, 190, 60, 'Masculino');
  eq(Math.round(int.trimp), 72, '1001 s sin lectura de FC descuentan su TRIMP');
}
{
  ok(M.trimpBanister(mk(2, 150), 190, 60, 'Masculino') == null, 'con <60 s cubiertos devuelve null (no inventa)');
  ok(M.trimpBanister(null, 190, 60, 'Masculino') == null, 'sin muestras devuelve null');
  ok(M.trimpBanister(mk(100, 150), 60, 60, 'Masculino') == null, 'con FCmax == FCrep devuelve null (den=0)');
}

console.log('— 3) TRIMP por FC media (sin muestras) —');
{
  const r = M.calcularTrimpEsfuerzo({ avgHr: 150, durMin: 60, startDate: FECHA, perfil: PERFIL });
  eq(r.valor, 100, '60 min a FC media 150 (max 190, rep 60) = 100');
  eq(r.fuente, 'trimp', 'la fuente es "trimp"');
}
{
  const r = M.calcularTrimpEsfuerzo({ avgHr: 150, durMin: 60, startDate: FECHA, perfil: { ...PERFIL, sexo: 'Femenino' } });
  eq(r.valor, 128, 'mismos datos en mujer = 128 (C=1.67, B=0.89)');
}
{
  ok(M.calcularTrimpEsfuerzo({ avgHr: 150, durMin: 3, startDate: FECHA, perfil: PERFIL }) == null, 'sesión <5 min sin muestras → null');
  ok(M.calcularTrimpEsfuerzo({ avgHr: 0, durMin: 60, startDate: FECHA, perfil: PERFIL }) == null, 'sin FC → null (no cae en otras fórmulas)');
}
{
  // Las muestras mandan sobre la FC media cuando existen
  const r = M.calcularTrimpEsfuerzo({ muestras: mk(3600, 150), avgHr: 120, durMin: 60, startDate: FECHA, perfil: PERFIL });
  eq(r.valor, 100, 'con muestras se integra la variación (la FC media se ignora)');
}

console.log('— 4) FC máxima y de reposo: de dónde salen —');
{
  eq(M.hrMaxParaTrimp({ umbralFC: 190 }, FECHA, 195), 190, 'la FC máxima del perfil manda sobre la de la sesión (como TrainerPlan)');
  eq(M.hrMaxParaTrimp({}, FECHA, 195), 195, 'sin FC máxima en el perfil: estimada 190 subida hasta la de la sesión');
  eq(M.hrRestParaTrimp({ fcReposo: 50 }, FECHA, { [DIA]: { rhr: 40 } }), 50, 'fcReposo del perfil manda sobre el wellness del día');
  eq(M.hrRestParaTrimp({}, FECHA, { [DIA]: { rhr: 48 } }), 48, 'sin fcReposo: wellness del día');
  eq(M.hrRestParaTrimp({}, FECHA, {}), 60, 'sin nada: 60 por defecto');
  const con50 = M.calcularTrimpEsfuerzo({ avgHr: 150, durMin: 60, startDate: FECHA, perfil: { ...PERFIL, fcReposo: 50 } });
  eq(con50.valor, 108, 'con FC reposo 50 el mismo entreno sube a 108');
}

console.log('— 5) Integración: el TRIMP manda en la cascada de esfuerzo —');
{
  const f = srcSync.indexOf('function computeEsfuerzo(');
  const g = srcSync.indexOf('function calcularEsfuerzoDesdeResumen(');
  const cuerpo = srcSync.slice(f, g);
  const iTrimp = cuerpo.indexOf('calcularTrimpEsfuerzo({');
  const iTss = cuerpo.indexOf('session.trainingStressScore');
  ok(iTrimp > 0 && iTss > 0 && iTrimp < iTss, 'computeEsfuerzo: el TRIMP va ANTES que el TSS del archivo');
  ok(/computeEsfuerzo\(session, startTime, perfil, wellnessDays, muestrasTrimp\)/.test(srcSync), 'el FIT pasa las muestras de FC a computeEsfuerzo');
  ok(/const muestrasTrimp = recordMesgs\.map/.test(srcSync), 'las muestras se construyen desde los records del FIT');
  ok(/const trimpRec = calcularTrimpEsfuerzo\({/.test(srcSync) && /if \(trimpRec\) \{ esfuerzo = trimpRec\.valor;/.test(srcSync), 'FIT sin mensaje session también calcula TRIMP desde los records');
  const d0 = srcSync.indexOf('function calcularEsfuerzoDesdeResumen(');
  const cuerpoR = srcSync.slice(d0, d0 + 2500);
  ok(cuerpoR.indexOf('calcularTrimpEsfuerzo({') < cuerpoR.indexOf('calcularRtss('), 'calcularEsfuerzoDesdeResumen: TRIMP antes que rTSS');
  ok(/muestras: d\.muestras/.test(cuerpoR), 'el resumen acepta muestras de quien las tenga');
  ok(!/calcularHrTss/.test(srcSync), 'desaparece el hrTSS normalizado (causa de la diferencia con TrainerPlan)');
  ok(!/100 \/ denom/.test(srcSync), 'desaparece la normalización a escala TSS');
}

console.log('— 6) UI: FC de reposo en Zonas y fuente en el modal —');
{
  ok(/const \[fcReposo, setFcReposo\] = useState\(''\);/.test(srcZonas), 'ZonesScreen: estado fcReposo');
  ok(/setFcReposo\(cached\.fcReposo \|\| ''\);/.test(srcZonas) && /setFcReposo\(data\.fcReposo \|\| ''\);/.test(srcZonas), 'ZonesScreen: carga desde caché y Firestore');
  ok(/\n        fcReposo,\n/.test(srcZonas), 'ZonesScreen: fcReposo se guarda en el perfil');
  ok(/value=\{fcReposo\} onChangeText=\{setFcReposo\}/.test(srcZonas), 'ZonesScreen: input de FC en reposo en la pestaña FC');
  ok(/mismo algoritmo que TrainerPlan/.test(srcZonas), 'ZonesScreen: el aviso explica que es el algoritmo de TrainerPlan');
  ok(/let muestras = Array\.isArray\(registros\) && registros\.length >= 2 \? registros : null;/.test(srcWDM), 'WDM: el botón de recálculo usa los registros cargados como muestras');
  ok(/const s = await getDoc\(doc\(db, 'entrenamientos', workout\.id, 'registros', 'data'\)\);/.test(srcWDM), 'WDM: si no hay muestras en memoria el recálculo las carga de Firestore (antes solo salía el TRIMP por FC media)');
  ok(/^\s+muestras,$/m.test(srcWDM), 'WDM: las muestras, recién cargadas o no, llegan al cálculo');
  ok(/case 'trimp': return 'Frecuencia cardíaca \(TRIMP, algoritmo TrainerPlan\)';/.test(srcWDM), 'WDM: la fuente "trimp" tiene texto propio');
}

console.log('— 7) Servidor: el sync usa el MISMO TRIMP integrado con muestras —');
{
  const srvRaiz = require('./server-ruta')();
  if (!fs.existsSync(path.join(srvRaiz, 'lib', 'intervals.js'))) {
    console.log('SKIP servidor: no se encuentra el código del server (server-extract o ../mi-app-entrenos)');
  } else {
    // firebase-admin exige la variable al inicializar (igual que el dispatcher-test).
    const { generateKeyPairSync } = require('crypto');
    process.env.FIREBASE_SERVICE_ACCOUNT = JSON.stringify({
      type: 'service_account',
      project_id: 'test-local',
      private_key_id: 'x',
      private_key: generateKeyPairSync('rsa', { modulusLength: 2048 }).privateKey.export({ type: 'pkcs8', format: 'pem' }),
      client_email: 'test@test-local.iam.gserviceaccount.com',
      client_id: '1',
      token_uri: 'https://oauth2.example.com/token',
    });
    const SI = require(path.join(srvRaiz, 'lib', 'intervals.js'));

    // Paridad exacta app↔server con las mismas muestras: si algún día se
    // separan los dos algoritmos, el sync volverá a pisar el valor de la app.
    const muestrasApp = mk(3600, 150);
    const appR = M.calcularTrimpEsfuerzo({ muestras: muestrasApp, avgHr: 120, durMin: 60, startDate: FECHA, perfil: PERFIL });
    const srvR = SI.calcularTrimpDesdeMuestras(muestrasApp, PERFIL, FECHA, {});
    eq(srvR && srvR.valor, appR.valor, 'paridad: server y app integran las mismas muestras al mismo valor (1 h @150)');
    eq(srvR && srvR.fuente, 'trimp', 'el TRIMP de muestras del server lleva fuente "trimp"');

    // Misma forma de punto que escribe intervalsDetail (timestamp ISO + frecuencia)
    const iso = mk(600, 140).map((p, i) => ({ timestamp: new Date(FECHA.getTime() + i * 1000).toISOString(), frecuencia: p.fc }));
    const appIso = M.calcularTrimpEsfuerzo({ muestras: iso, durMin: 10, startDate: FECHA, perfil: PERFIL });
    const srvIso = SI.calcularTrimpDesdeMuestras(iso, PERFIL, FECHA, {});
    eq(srvIso && srvIso.valor, appIso && appIso.valor, 'paridad con puntos timestamp+frecuencia (los del detalle de intervals.icu)');

    // Los huecos > 60 s se descartan igual en los dos lados
    const conHuecoApp = M.calcularTrimpEsfuerzo({ muestras: mk(600, 150).concat(mk(600, 150, 900 * 1000)), durMin: 25, startDate: FECHA, perfil: PERFIL });
    const conHuecoSrv = SI.calcularTrimpDesdeMuestras(mk(600, 150).concat(mk(600, 150, 900 * 1000)), PERFIL, FECHA, {});
    eq(conHuecoSrv && conHuecoSrv.valor, conHuecoApp && conHuecoApp.valor, 'paridad: la pausa de 5 min se descuenta igual en server y app');

    // Menos de 60 s cubiertos → null en ambos (el server cae a la variante de FC media)
    eq(SI.calcularTrimpDesdeMuestras(mk(30, 150), PERFIL, FECHA, {}), null, 'server: <60 s cubiertos → null (cae a FC media como la app)');

    // La FC máxima de la sesión eleva la estimada (Tanaka/190), igual que la app
    const pSinUmbral = { fcReposo: 60, sexo: 'Masculino' };
    const srvPico = SI.calcularTrimpDesdeMuestras(mk(3600, 150, 0, 195), pSinUmbral, FECHA, {});
    const appPico = M.calcularTrimpEsfuerzo({ muestras: mk(3600, 150, 0, 195), durMin: 60, startDate: FECHA, perfil: pSinUmbral, maxHrSesion: 195 });
    eq(srvPico && srvPico.valor, appPico && appPico.valor, 'paridad: FC máxima de sesión 195 elevando la FC máxima estimada');

    eq(SI.mapFuenteEsfuerzo('trimp'), 'trimp', 'mapFuenteEsfuerzo: trimp');
    eq(SI.mapFuenteEsfuerzo('ritmo'), 'rTSS', 'mapFuenteEsfuerzo: ritmo → rTSS');
    eq(SI.mapFuenteEsfuerzo('icu_training_load'), 'intervals.icu', 'mapFuenteEsfuerzo: icu → intervals.icu');

    // Puntos de integración: rectifica y detalle calculan el TRIMP de muestras
    // ANTES que la aproximación de FC media, y el backfill ya no fuerza el
    // icu_training_load crudo.
    const srcSyncInt = fs.readFileSync(path.join(srvRaiz, 'handlers', 'sync-intervals.js'), 'utf8');
    const srcDet = fs.readFileSync(path.join(srvRaiz, 'lib', 'intervalsDetail.js'), 'utf8');
    const iRect = srcSyncInt.indexOf('loadLista = calcularTrimpDesdeMuestras(pts, perfil');
    const iAvg = srcSyncInt.indexOf('loadLista = computeEsfuerzoIntervals(actEnr, perfil');
    ok(iRect > 0 && iAvg > iRect, 'sync-intervals: la rectificación prueba el TRIMP de muestras ANTES que la FC media (ya no revierte el valor de la app)');
    ok(/calcularTrimpDesdeMuestras\(puntos, perfil, startDate, wellnessDays/.test(srcDet), 'intervalsDetail: calcula el TRIMP con las muestras recién descargadas');
    const iDetMuestras = srcDet.indexOf('calcularTrimpDesdeMuestras(puntos');
    const iDetAvg = srcDet.indexOf('computeEsfuerzoIntervals(a, perfil');
    ok(iDetMuestras > 0 && iDetAvg > iDetMuestras, 'intervalsDetail: las muestras van antes que la FC media');
    ok(!/esfuerzoFuente: 'intervals\.icu'/.test(srcSyncInt), 'sync-intervals: la fuente se mapea (trimp/rTSS/potencia) en vez de fijar "intervals.icu"');
  }
}

console.log('');
console.log(`TRIMP/ESFUERZO RONDA 46: ${pasadas} comprobaciones OK, ${fallos.length} fallos`);
if (fallos.length) { fallos.forEach((f) => console.log('  FALLO: ' + f)); process.exit(1); }
