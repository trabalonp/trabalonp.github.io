// tests/server-ruta.js — localiza el código del server para los tests, en
// este orden:
//   1) server-extract/mi-app-entrenos-main (copia dentro del repo, para CI)
//   2) ../mi-app-entrenos (el repo real del server, hermano de este repo)
// Si no existe ninguno, devuelve la ruta local para que el test falle con un
// mensaje claro (o salte, según el test).
'use strict';
const fs = require('fs');
const path = require('path');

function rutaServer() {
  const local = path.join(__dirname, '..', 'server-extract', 'mi-app-entrenos-main');
  const hermano = path.join(__dirname, '..', '..', 'mi-app-entrenos');
  if (fs.existsSync(path.join(local, 'lib', 'firebase.js'))) return local;
  if (fs.existsSync(path.join(hermano, 'lib', 'firebase.js'))) return hermano;
  return local;
}

module.exports = rutaServer;
