// services/deepLink.js
/* Puente mínimo para abrir un entreno desde una notificación:
   App.js guarda aquí el workoutId del push tocado y avisa a quien esté
   suscrito (HomeScreen, que tiene el modal de detalle). Si aún no hay nadie
   suscrito (arranque en frío), el id queda pendiente y se consume al montar. */
let pendingWorkoutId = null;
const subs = new Set();

export function setPendingWorkoutId(id) {
  if (!id) return;
  pendingWorkoutId = id;
  subs.forEach((fn) => { try { fn(id); } catch (e) {} });
}

export function consumePendingWorkoutId() {
  const id = pendingWorkoutId;
  pendingWorkoutId = null;
  return id;
}

export function subscribePendingWorkout(fn) {
  subs.add(fn);
  return () => subs.delete(fn);
}
