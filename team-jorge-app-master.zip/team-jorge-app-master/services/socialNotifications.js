import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';

let configured = false;

export async function configureSocialNotifications() {
  if (configured) return true;
  configured = true;

  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowBanner: true,
      shouldShowList: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
    }),
  });

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('social-chat', {
      name: 'Chat social',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      sound: 'default',
    });
  }

  if (!Device.isDevice) return false;
  const current = await Notifications.getPermissionsAsync();
  if (current.status === 'granted') return true;
  const requested = await Notifications.requestPermissionsAsync();
  return requested.status === 'granted';
}

export async function notifyIncomingSocialMessage({ author, text }) {
  const granted = await configureSocialNotifications();
  if (!granted) return;

  await Notifications.scheduleNotificationAsync({
    content: {
      title: String(author || 'Nuevo mensaje'),
      body: String(text || '').trim() || 'Te ha enviado un archivo',
      sound: 'default',
      data: { type: 'social-message' },
      ...(Platform.OS === 'android' ? { channelId: 'social-chat' } : {}),
    },
    trigger: null,
  });
}
