// services/enlaces.js
/* Utilidades PURAS de detección de enlaces (sin dependencias de React Native:
   verificables desde Node con tests/enlaces-test.js).

   Patrón WhatsApp: los enlaces dentro del texto del mensaje se detectan con
   una expresión regular, se pintan en azul + subrayado y al tocarlos se abren
   en el navegador. Se reconocen URLs con esquema (http/https) y con prefijo
   "www."; la puntuación final de frase (.,;:!?) y los paréntesis sin balancear
   NO forman parte del enlace, igual que en WhatsApp. */

/* Coincidencias: https?://… o www.…, cortando en espacios y comillas. */
const RE_URL = /(https?:\/\/[^\s<>"'`]+|www\.[^\s<>"'`]+)/gi;

/** Quita la puntuación de final de frase y los paréntesis sin balancear. */
export function limpiarUrl(u) {
  let s = String(u == null ? '' : u).trim();
  s = s.replace(/[.,;:!?¡¿»…"'`]+$/u, '');
  let guard = 0;
  while (s.endsWith(')') && guard < 12) {
    const open = (s.match(/\(/g) || []).length;
    const close = (s.match(/\)/g) || []).length;
    if (close > open) s = s.slice(0, -1);
    else break;
    guard++;
  }
  return s;
}

/** Parte el texto en segmentos: [{ url: bool, v: string }] preservando todo. */
export function segmentar(texto) {
  const out = [];
  const src = String(texto == null ? '' : texto);
  if (!src) return out;
  let last = 0;
  let m;
  RE_URL.lastIndex = 0;
  while ((m = RE_URL.exec(src)) !== null) {
    const limpio = limpiarUrl(m[0]);
    if (!limpio) continue;
    const start = m.index;
    const end = start + limpio.length;   // lo recortado (puntuación) queda como texto
    if (end <= last) continue;           // defensivo: solapes imposibles
    if (start > last) out.push({ url: false, v: src.slice(last, start) });
    out.push({ url: true, v: limpio });
    last = end;
    RE_URL.lastIndex = end;
  }
  if (last < src.length) out.push({ url: false, v: src.slice(last) });
  return out;
}

/** URLs del texto, en orden y sin duplicados. */
export function extraerUrls(texto) {
  const vistos = new Set();
  const out = [];
  for (const s of segmentar(texto)) {
    if (s.url && !vistos.has(s.v)) { vistos.add(s.v); out.push(s.v); }
  }
  return out;
}

/** Primera URL del texto (la que WhatsApp previsualiza) o null. */
export function primeraUrl(texto) {
  const urls = extraerUrls(texto);
  return urls.length ? urls[0] : null;
}

/** "https://es.marca.com/x?a=1" → "es.marca.com" (sin www, minúsculas). */
export function dominioDe(url) {
  try {
    const s = String(url == null ? '' : url).trim()
      .replace(/^https?:\/\//i, '')
      .replace(/^www\./i, '');
    const host = s.split('/')[0].split('?')[0].split('#')[0];
    if (!host) return '';
    try { return decodeURIComponent(host).toLowerCase(); } catch (e) { return host.toLowerCase(); }
  } catch (e) { return ''; }
}

/** Añade https:// a los enlaces "www.…" para poder abrirlos. */
export function normalizarUrl(u) {
  const s = String(u == null ? '' : u).trim();
  if (!s) return '';
  return /^https?:\/\//i.test(s) ? s : 'https://' + s;
}
