// services/compliance.js
// ─────────────────────────────────────────────────────────────
// CUMPLIMIENTO DE ENTRENO (workout compliance) por colores, como los
// planes de entrenamiento clásicos (TrainingPeaks & co.). Se calcula en
// el cliente con los campos que deja la fusión del servidor (matcher):
// mergedFromPlanId + planDist/planDur frente a distancia/duración real.
//
//   VERDE    80–120% del plan            → check  ✅ (icono checkmark)
//   AMARILLO 50–79% o 121–150%           → flecha ⬇️ / ⬆️
//   NARANJA  <50% o >150%                → flecha ⬇️ / ⬆️
//   ROJO     planificado no realizado (día pasado) o marcado incompleto → cruz
//   GRIS     planificado (hoy o futuro)  → sin marca
//   VERDE    realizado SIN plan enlazado (sync suelto): color de hecho,
//            SIN marca ("a los no enlazados no se les pone nada")
//
// Las flechas apuntan ⬆️ si el realizado quedó POR ENCIMA del plan y ⬇️ si
// quedó POR DEBAJO. kind da el icono (ICONO_COMP) y color el tinte tanto
// del icono como de la tarjeta y del icono de actividad.
// DESCANSO no se evalúa NUNCA: un día de descanso sigue gris aunque pase,
// esté hecho o no (no es un entreno).
// ─────────────────────────────────────────────────────────────
export const GREEN = '#2DB37A';
export const YELLOW = '#F5C518';
export const ORANGE = '#F5A623';
export const RED = '#E05252';
export const GRAY = '#4A6080';

// Icono Ionicons por tipo de cumplimiento (con el color de compliance).
export const ICONO_COMP = {
  ok: 'checkmark-circle',
  up: 'arrow-up-circle',
  down: 'arrow-down-circle',
  ko: 'close-circle',
};

const aFecha = (f) => {
  const d = f?.toDate ? f.toDate() : f ? new Date(f) : null;
  return d && !isNaN(d.getTime()) ? d : null;
};

// ¿El día del entreno es ANTERIOR a hoy (a nivel de día)? Solo entonces un
// planificado sin realizar cuenta como "no completado".
const aMedianoche = (x) => { const c = new Date(x); c.setHours(0, 0, 0, 0); return c.getTime(); };
const diaPasado = (f, ahora) => {
  const d = aFecha(f);
  return !!d && aMedianoche(d) < aMedianoche(ahora);
};

export function complianceEntreno(w, ahora = new Date()) {
  if (!w) return { color: GRAY, kind: null };

  // Descanso: jamás se evalúa (ni verde ni rojo): gris sin marca siempre.
  if (w.tipo === 'Descanso') return { color: GRAY, kind: null };

  // Fusionado por el servidor: hay plan contra el que comparar.
  if (w.mergedFromPlanId) {
    const planDist = Number(w.planDist) || 0;
    const planDur = Number(w.planDur) || 0;
    const plan = planDist > 0 ? planDist : planDur;
    if (!(plan > 0)) return { color: GREEN, kind: 'ok' };   // enlazado sin métricas de plan
    const real = planDist > 0 ? (Number(w.distancia) || 0) : (Number(w.duracion) || 0);
    const pct = real > 0 ? (real / plan) * 100 : 0;
    if (pct >= 80 && pct <= 120) return { color: GREEN, kind: 'ok', pct };
    if (pct > 120) return { color: pct <= 150 ? YELLOW : ORANGE, kind: 'up', pct };
    return { color: pct >= 50 ? YELLOW : ORANGE, kind: 'down', pct };
  }

  if (w.estado === 'incompleto') return { color: RED, kind: 'ko' };

  // Planificado sin realizar y el día ya pasó → no completado.
  if (!w.estado || w.estado !== 'completo') {
    if (diaPasado(w.fecha, ahora)) return { color: RED, kind: 'ko' };
    return { color: GRAY, kind: null };
  }

  // Realizado sin plan enlazado: verde (está hecho) y SIN icono.
  return { color: GREEN, kind: null };
}
