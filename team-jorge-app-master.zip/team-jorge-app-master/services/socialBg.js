// services/socialBg.js
/* Fondo de pantalla del Tablón: SIEMPRE local (documento del teléfono).
   Nunca se sube a la nube ni a Firestore: solo una ruta en AsyncStorage. */
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system/legacy';

export const BG_KEY = 'social_bg_local';
export const BG_PATH = () => (FileSystem.documentDirectory || FileSystem.cacheDirectory) + 'tablon-bg.jpg';

export async function getSocialBg() {
  try {
    const p = await AsyncStorage.getItem(BG_KEY);
    if (!p) return null;
    const info = await FileSystem.getInfoAsync(p);
    return info.exists ? p : null;
  } catch (e) {
    return null;
  }
}

export async function setSocialBg(uri) {
  const dest = BG_PATH();
  await FileSystem.copyAsync({ from: uri, to: dest });
  await AsyncStorage.setItem(BG_KEY, dest);
  return dest;
}

export async function clearSocialBg() {
  await AsyncStorage.removeItem(BG_KEY);
  try { await FileSystem.deleteAsync(BG_PATH(), { idempotent: true }); } catch (e) {}
}
