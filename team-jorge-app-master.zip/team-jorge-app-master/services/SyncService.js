// services/SyncService.js
import { Decoder, Stream } from '@garmin/fitsdk';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system/legacy';
import { addDoc, collection, doc, getDoc, getDocs, query, setDoc, Timestamp, updateDoc, where } from 'firebase/firestore';
import { db } from '../firebaseConfig';

const FOLDER_KEY = 'fit_folder_uri';
const MAX_GRAPH_POINTS = 1000;
const SEMI = 180 / 2147483648;

export async function syncFitFiles(userId, onProgress) {
  const folderUri = await AsyncStorage.getItem(FOLDER_KEY);
  if (!folderUri) {
    return {
      synced: 0, skipped: 0, errors: 0, cancelled: true,
      message: 'No hay carpeta configurada. Ve a Ajustes > Sincronizar archivos.',
    };
  }
  onProgress?.('Buscando archivos .fit…', 0, 0);
  const fitFiles = await listFitFilesRecursive(folderUri, 0);
  if (fitFiles.length === 0) {
    return { synced: 0, skipped: 0, errors: 0, total: 0 };
  }
  let synced = 0, skipped = 0, errors = 0;

  // Perfil del atleta y wellness: se usan para calcular el esfuerzo (TSS/rTSS/
  // hrTSS) cuando el archivo FIT no trae el dato directamente (umbral de
  // potencia, ritmo umbral, FC máxima, umbral de FC, fecha de nacimiento y FC en
  // reposo del día). OJO: en el perfil, `umbralFC` es la FC MÁXIMA y el umbral
  // de FC de verdad va en `fcUmbral` (ver computeEsfuerzo).
  let perfil = null;
  let wellnessDays = {};
  try {
    const ps = await getDoc(doc(db, 'perfiles', userId));
    if (ps.exists()) perfil = ps.data();
    const ws = await getDoc(doc(db, 'wellness', userId));
    if (ws.exists()) wellnessDays = ws.data().days || {};
  } catch (e) {
    console.warn('[SyncService] Error leyendo perfil/wellness:', e.message);
  }

  for (let i = 0; i < fitFiles.length; i++) {
    const file = fitFiles[i];
    onProgress?.(`Procesando ${file.name}`, i + 1, fitFiles.length);
    try {
      const alreadyExists = await checkDuplicate(userId, file.name);
      if (alreadyExists) { skipped++; continue; }

      const parsed = await parseFitFile(file.uri, perfil, wellnessDays);
      if (!parsed) { errors++; continue; }
      
      const docRef = await addDoc(collection(db, 'entrenamientos'), {
        userId,
        id_archivo: file.name,
        fecha: Timestamp.fromDate(parsed.fecha),
        tipo: parsed.tipo,
        titulo: parsed.nombre || parsed.tipo,
        distancia: parsed.distancia,
        duracion: parsed.duracion,
        'fc-media': parsed.fcMedia,
        estado: 'completo',
        // NUEVOS CAMPOS en el documento principal para las gráficas
        elevacion: parsed.desnivelPos || 0,
        desnivelPos: parsed.desnivelPos || 0,
        desnivelNeg: parsed.desnivelNeg || 0,
        potenciaMedia: parsed.potenciaMedia || 0,
        cadencia: parsed.cadencia || 0,
        esfuerzo: parsed.esfuerzo ?? 0,
        esfuerzoFuente: parsed.esfuerzoFuente || null,
      });
      
      await setDoc(doc(db, 'entrenamientos', docRef.id, 'detalles', 'data'), {
        calorias: parsed.calorias,
        fcMax: parsed.fcMax,
        ritmo: parsed.ritmo,
        elevacionMin: parsed.elevacionMin,
        elevacionMax: parsed.elevacionMax,
        cadencia: parsed.cadencia,
        desnivelPos: parsed.desnivelPos,
        temperatura: parsed.temperatura,
        esfuerzo: parsed.esfuerzo ?? 0,
        tss: parsed.esfuerzo ?? 0,
        esfuerzoFuente: parsed.esfuerzoFuente || null,
        notas: '',
        cargaPercibida: '',
        enlace: '',
        sensacion: 0,
        descripcion: '',
        pasos: [],
        comentarios: [],
        vueltas: parsed.vueltas,
        completado: false,
        hasRuta: (parsed.registros || []).some(p => p.lat != null && p.lon != null),
      });
      
      if (parsed.registros?.length > 0) {
        await setDoc(doc(db, 'entrenamientos', docRef.id, 'registros', 'data'), {
          puntos: parsed.registros,
        });
      }
      synced++;
    } catch (err) {
      console.warn('[SyncService] Error en', file.name, err.message);
      errors++;
    }
  }
  return { synced, skipped, errors, total: fitFiles.length };
}

async function listFitFilesRecursive(uri, depth) {
  if (depth > 4) return [];
  let files = [];
  try {
    const entries = await FileSystem.StorageAccessFramework.readDirectoryAsync(uri);
    for (const entryUri of entries) {
      if (entryUri.endsWith('/')) {
        const sub = await listFitFilesRecursive(entryUri, depth + 1);
        files = files.concat(sub);
      } else {
        const name = decodeURIComponent(entryUri.split('/').pop());
        if (name.toLowerCase().endsWith('.fit')) {
          files.push({ uri: entryUri, name });
        }
      }
    }
  } catch (e) {
    console.warn('[SyncService] Error al leer carpeta:', e.message);
  }
  return files;
}

async function checkDuplicate(userId, idArchivo) {
  const q = query(
    collection(db, 'entrenamientos'),
    where('userId', '==', userId),
    where('id_archivo', '==', idArchivo),
  );
  const snap = await getDocs(q);
  return !snap.empty;
}

async function parseFitFile(contentUri, perfil, wellnessDays) {
  try {
    const base64 = await FileSystem.readAsStringAsync(contentUri, {
      encoding: FileSystem.EncodingType.Base64,
    });
    const binary = _base64ToArrayBuffer(base64);
    const stream = Stream.fromByteArray(new Uint8Array(binary));
    if (!Decoder.isFIT(stream)) {
      console.warn('[SyncService] El archivo no es un FIT válido');
      return null;
    }
    const decoder = new Decoder(stream);
    const { messages, errors } = decoder.read({
      includeUnknownData: true,
      mergeHeartRates: true,
    });
    if (errors.length > 0) {
      console.warn('[SyncService] Errores al decodificar:', errors);
    }
    const sessionMesgs = messages['sessionMesgs'] || [];
    const lapMesgs = messages['lapMesgs'] || [];
    const recordMesgs = messages['recordMesgs'] || [];
    
    let startTime, distancia, duracion, calorias, fcMedia, fcMax, elevMin, elevMax,
        avgSpeed, ritmo, cadencia, desnivelPos, desnivelNeg, temperatura, nombre, sport, esfuerzo, esfuerzoFuente, potenciaMedia;
    
    if (sessionMesgs.length > 0) {
      const session = sessionMesgs[0];
      startTime = session.startTime || new Date();
      distancia = parseFloat(((session.totalDistance ?? 0) / 1000).toFixed(2));
      duracion = Math.round(session.totalElapsedTime ?? 0);
      calorias = session.totalCalories ?? 0;
      fcMedia = session.avgHeartRate ?? 0;
      fcMax = session.maxHeartRate ?? 0;
      elevMin = session.minAltitude ?? 0;
      elevMax = session.maxAltitude ?? 0;
      avgSpeed = session.enhancedAvgSpeed ?? session.avgSpeed ?? null;
      cadencia = session.avgCadence ?? 0;
      desnivelPos = session.totalAscent ?? 0;
      desnivelNeg = session.totalDescent ?? 0;
      temperatura = session.avgTemperature ?? 0;
      nombre = session.sessionName ?? session.workoutName ?? session.activityName ?? '';
      sport = session.sport ?? 'generic';
      // OJO: `activityTrainingLoad` no existe en el formato FIT y
      // `totalTrainingEffect` es el Training Effect de Garmin (0–5), no un TSS.
      // El esfuerzo real (tipo TrainingPeaks: 83, 55, 101…) se calcula en
      // computeEsfuerzo(), que devuelve { valor, fuente }.
      const esfCalc = computeEsfuerzo(session, startTime, perfil, wellnessDays);
      esfuerzo = esfCalc.valor;
      esfuerzoFuente = esfCalc.fuente;
      potenciaMedia = session.avgPower ?? 0;
    } else if (recordMesgs.length > 0) {
      startTime = new Date(recordMesgs[0].timestamp);
      const lastRecord = recordMesgs[recordMesgs.length - 1];
      distancia = parseFloat(((lastRecord.distance ?? 0) / 1000).toFixed(2));
      const firstTs = new Date(recordMesgs[0].timestamp).getTime();
      const lastTs = new Date(recordMesgs[recordMesgs.length - 1].timestamp).getTime();
      duracion = Math.round((lastTs - firstTs) / 1000);
      calorias = 0; fcMedia = 0; fcMax = 0; elevMin = 0; elevMax = 0;
      avgSpeed = null; cadencia = 0; desnivelPos = 0; desnivelNeg = 0; temperatura = 0;
      nombre = ''; sport = 'generic'; esfuerzo = 0; esfuerzoFuente = null; potenciaMedia = 0;
    } else {
      console.warn('[SyncService] No se encontraron datos');
      return null;
    }
    
    const tipo = mapSport(sport);
    const isRunning = tipo === 'Running';
    const isCycling = tipo === 'Ciclismo';
    
    if (isRunning && cadencia > 0) cadencia = cadencia * 2;
    
    if (avgSpeed && avgSpeed > 0) {
      const speedKmh = avgSpeed * 3.6;
      if (isCycling) {
        ritmo = speedKmh.toFixed(1); // Ciclismo: km/h
      } else {
        const pace = 60 / speedKmh;
        const minutes = Math.floor(pace);
        const seconds = Math.round((pace - minutes) * 60);
        ritmo = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
      }
    } else if (distancia > 0 && duracion > 0) {
      if (isCycling) {
        ritmo = (distancia / (duracion / 3600)).toFixed(1); // Ciclismo: km/h
      } else {
        const totalMin = duracion / 60;
        const pace = totalMin / distancia;
        const minutes = Math.floor(pace);
        const seconds = Math.round((pace - minutes) * 60);
        ritmo = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
      }
    } else {
      ritmo = '';
    }
    
    const vueltas = lapMesgs.map((lap, index) => {
      const lapDistancia = parseFloat(((lap.totalDistance ?? 0) / 1000).toFixed(2));
      const lapDuracion = lap.totalElapsedTime ?? 0;
      const lapVelocidad = lap.enhancedAvgSpeed ?? lap.avgSpeed ?? 0;
      const lapMaxSpeed = lap.enhancedMaxSpeed ?? lap.maxSpeed ?? 0;
      let lapRitmo = '';
      if (lapVelocidad > 0) {
        if (isCycling) {
          lapRitmo = (lapVelocidad * 3.6).toFixed(1); // Ciclismo: km/h
        } else {
          const pace = 60 / (lapVelocidad * 3.6);
          const min = Math.floor(pace);
          const sec = Math.round((pace - min) * 60);
          lapRitmo = `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
        }
      } else if (lapDistancia > 0 && lapDuracion > 0) {
        const pace = (lapDuracion / 60) / lapDistancia;
        const min = Math.floor(pace);
        const sec = Math.round((pace - min) * 60);
        lapRitmo = `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
      }
      let lapRitmoMax = '';
      if (lapMaxSpeed > 0) {
        const paceMax = 60 / (lapMaxSpeed * 3.6);
        const min = Math.floor(paceMax);
        const sec = Math.round((paceMax - min) * 60);
        lapRitmoMax = `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
      }
      const ascent = lap.totalAscent ?? 0;
      const descent = lap.totalDescent ?? 0;
      return {
        vuelta: index + 1,
        distancia: lapDistancia,
        tiempo: lapDuracion,
        ritmo: lapRitmo,
        ritmoMaximo: lapRitmoMax,
        fcMedia: lap.avgHeartRate ?? 0,
        fcMaxima: lap.maxHeartRate ?? 0,
        cadenciaMedia: isRunning ? (lap.avgCadence ?? 0) * 2 : (lap.avgCadence ?? 0),
        cadenciaMaxima: isRunning ? (lap.maxCadence ?? 0) * 2 : (lap.maxCadence ?? 0),
        gananciaElev: ascent,
        perdidaElev: descent,
        difElev: ascent - descent,
      };
    });
    
    let registros = recordMesgs.map(r => ({
      timestamp: r.timestamp ? new Date(r.timestamp).toISOString() : new Date().toISOString(),
      distancia: parseFloat(((r.distance ?? 0) / 1000).toFixed(2)),
      altitud: r.enhancedAltitude ?? r.altitude ?? 0,
      frecuencia: r.heartRate ?? 0,
      cadencia: isRunning ? (r.cadence ?? 0) * 2 : (r.cadence ?? 0),
      potencia: r.power ?? 0,
      velocidad: parseFloat(((r.enhancedSpeed ?? r.speed ?? 0) * 3.6).toFixed(2)),
      lat: r.position_lat != null ? r.position_lat * SEMI : null,
      lon: r.position_long != null ? r.position_long * SEMI : null,
    }));
    
    if (registros.length > MAX_GRAPH_POINTS) {
      const step = Math.ceil(registros.length / MAX_GRAPH_POINTS);
      registros = registros.filter((_, i) => i % step === 0);
      const last = recordMesgs[recordMesgs.length - 1];
      if (registros[registros.length - 1]?.timestamp !== new Date(last.timestamp).toISOString()) {
        registros.push({
          timestamp: last.timestamp ? new Date(last.timestamp).toISOString() : new Date().toISOString(),
          distancia: parseFloat(((last.distance ?? 0) / 1000).toFixed(2)),
          altitud: last.enhancedAltitude ?? last.altitude ?? 0,
          frecuencia: last.heartRate ?? 0,
          cadencia: isRunning ? (last.cadence ?? 0) * 2 : (last.cadence ?? 0),
          potencia: last.power ?? 0,
          velocidad: parseFloat(((last.enhancedSpeed ?? last.speed ?? 0) * 3.6).toFixed(2)),
          lat: last.position_lat != null ? last.position_lat * SEMI : null,
          lon: last.position_long != null ? last.position_long * SEMI : null,
        });
      }
    }
    
    return {
      fecha: startTime,
      distancia,
      duracion,
      calorias,
      fcMedia,
      fcMax,
      ritmo,
      elevacionMin: elevMin,
      elevacionMax: elevMax,
      cadencia,
      desnivelPos,
      desnivelNeg,
      temperatura,
      esfuerzo: esfuerzo ?? 0,
      esfuerzoFuente: esfuerzoFuente || null,
      potenciaMedia,
      tipo,
      nombre,
      vueltas,
      registros,
    };
  } catch (e) {
    console.warn('[parseFitFile] error:', e.message);
    return null;
  }
}

function mapSport(sport) {
  const map = {
    cycling: 'Ciclismo',
    running: 'Running',
    swimming: 'Natación',
    training: 'Fuerza',
    generic: 'Otro',
  };
  return map[sport?.toLowerCase()] ?? 'Otro';
}

// ─────────────────────────────────────────────────────────────────
// ESFUERZO (equivalente TSS, estilo TrainingPeaks: 83, 55, 101, 91…)
//
// Los archivos FIT de Garmin NO incluyen TSS, así que se calcula con la mejor
// fuente disponible y en el mismo orden de preferencia que usa TrainingPeaks:
//   1) session.trainingStressScore, si el archivo ya lo trae (Wahoo,
//      TrainingPeaks, Golden Cheetah…).
//   2) TSS por potencia:  TSS = (segundos × NP × IF) / (FTP × 3600) × 100,
//      con IF = NP / FTP.
//   3) rTSS por ritmo (carrera a pie con ritmo umbral en el perfil):
//      rTSS = horas × IF² × 100,  con IF = ritmoUmbral / ritmoMedio.
//   4) hrTSS por frecuencia cardíaca: TRIMP de Banister normalizado para que
//      1 hora al umbral de FC ≈ 100 (misma escala que TSS).
//   5) Último recurso: Training Effect de Garmin (0–5) escalado ×20.
//
// Devuelve siempre { valor, fuente } para que la app pueda mostrar de dónde
// sale el número y se pueda comparar con TrainingPeaks sin dudas.
//
// ⚠ CAMBIO IMPORTANTE: en esta app `perfil.umbralFC` es la FC MÁXIMA (es el
// campo "FC máxima" de la pantalla Zonas), NO el umbral de FC. Antes se usaba
// como si fuera el umbral, de modo que la comprobación `hrMax > lthr` no se
// cumplía NUNCA, el hrTSS se descartaba siempre y se acababa en el Training
// Effect ×20. Por eso la app mostraba 27 en un entreno que en TrainingPeaks
// era 83 (Training Effect 1.35 × 20 = 27).
// ─────────────────────────────────────────────────────────────────

const numOrNull = (v) => (v != null && Number.isFinite(Number(v)) ? Number(v) : null);

// "04:35" / "4:35" / "4.5" / 4.58  →  segundos por km
export function parseRitmoMinKm(v) {
  if (v == null || v === '') return null;
  if (typeof v === 'number') return Number.isFinite(v) && v > 0 ? Math.round(v * 60) : null;
  const txt = String(v).trim().replace(',', '.');
  const m = txt.match(/^(\d{1,3}):(\d{1,2})$/);
  if (m) {
    const seg = Number(m[1]) * 60 + Number(m[2]);
    return seg > 0 ? seg : null;
  }
  const n = Number(txt);
  return Number.isFinite(n) && n > 0 ? Math.round(n * 60) : null;
}

// Umbral de FC (LTHR) a partir de las zonas configuradas: el límite inferior de
// la zona de umbral. En esta app las zonas de FC se generan desde la FC máxima
// y la zona "SuperUmbral" empieza en el 90 %, así que se acepta cualquier
// límite entre el 84 % y el 96 % de la máxima y se descarta el resto.
export function lthrDesdeZonas(zonas, hrMax) {
  if (!Array.isArray(zonas) || zonas.length === 0 || !(hrMax > 0)) return null;
  const mins = zonas
    .map((z) => Number(z && z.min))
    .filter((n) => Number.isFinite(n) && n >= hrMax * 0.84 && n <= hrMax * 0.96)
    .sort((a, b) => a - b);
  return mins.length ? Math.round(mins[0]) : null;
}

// FC máxima efectiva: manda la del perfil (campo "FC máxima" de Zonas); si no
// está o no es creíble, fórmula de Tanaka con la fecha de nacimiento; y siempre
// se sube hasta la FC máxima vista en la sesión si fue mayor.
function hrMaxEfectiva(perfil, startDate, maxSesion) {
  let hrMax = numOrNull(perfil?.umbralFC);
  if (hrMax == null || hrMax < 100 || hrMax > 230) {
    hrMax = null;
    const fnRaw = perfil?.fechaNac;
    if (fnRaw) {
      const fn = fnRaw.toDate ? fnRaw.toDate() : new Date(fnRaw);
      const edad = (startDate.getTime() - fn.getTime()) / (365.25 * 24 * 3600 * 1000);
      if (edad > 5 && edad < 100) hrMax = 208 - 0.7 * edad;
    }
    if (hrMax == null) hrMax = 190;
  }
  if (maxSesion != null && maxSesion > hrMax) hrMax = maxSesion;
  return hrMax;
}

// Umbral de FC (LTHR): campo explícito del perfil → zona de umbral de las zonas
// de FC → 90 % de la FC máxima. NUNCA `umbralFC`, que es la FC máxima.
function lthrEfectiva(perfil, hrMax) {
  return numOrNull(perfil?.fcUmbral) ?? lthrDesdeZonas(perfil?.zonasFC, hrMax) ?? Math.round(hrMax * 0.90);
}

// hrTSS: TRIMP de Banister normalizado para que 1 h al umbral de FC = 100.
function calcularHrTss({ avgHr, maxHrSesion, durMin, startDate, perfil, wellnessDays }) {
  const avg = numOrNull(avgHr);
  if (avg == null || avg <= 0 || !(durMin >= 5)) return null;
  const when = startDate instanceof Date ? startDate : new Date(startDate || Date.now());
  const hrMax = hrMaxEfectiva(perfil, when, numOrNull(maxHrSesion));
  const dayKey = `${when.getFullYear()}-${String(when.getMonth() + 1).padStart(2, '0')}-${String(when.getDate()).padStart(2, '0')}`;
  const hrRest = numOrNull(wellnessDays?.[dayKey]?.rhr) ?? 60;
  const lthr = lthrEfectiva(perfil, hrMax);
  if (!(hrRest > 0 && hrMax > lthr && lthr > hrRest)) return null;
  const f = (r) => r * 0.64 * Math.exp(1.92 * r); // factor TRIMP
  const ratio = Math.min(1, Math.max(0, (avg - hrRest) / (hrMax - hrRest)));
  const denom = 60 * f((lthr - hrRest) / (hrMax - hrRest)); // TRIMP de 1 h al umbral
  if (!(ratio > 0 && denom > 0)) return null;
  return { valor: Math.round((durMin * f(ratio)) * (100 / denom)), fuente: 'fc' };
}

// rTSS: 1 hora al ritmo umbral = 100 (lo mismo que hace TrainingPeaks en
// carrera a pie cuando el atleta tiene ritmo umbral configurado).
function calcularRtss({ durSec, distanciaKm, ritmoUmbralSeg }) {
  const seg = numOrNull(durSec);
  const km = numOrNull(distanciaKm);
  const ru = numOrNull(ritmoUmbralSeg);
  if (ru == null || seg == null || seg <= 0 || km == null || km <= 0.2) return null;
  const ritmoMedio = seg / km; // s/km
  if (!(ritmoMedio > 0)) return null;
  const ifRitmo = ru / ritmoMedio; // >1 = más rápido que el umbral
  if (!(ifRitmo > 0.3 && ifRitmo < 2)) return null;
  return { valor: Math.round((seg / 3600) * ifRitmo * ifRitmo * 100), fuente: 'ritmo' };
}

function computeEsfuerzo(session, startDate, perfil, wellnessDays) {
  const out = (valor, fuente) => ({ valor: Math.max(0, Math.round(valor)), fuente });

  // 1) TSS grabado en el propio archivo FIT
  const tssFit = numOrNull(session.trainingStressScore);
  if (tssFit != null && tssFit > 0) return out(tssFit, 'archivo');

  const durSec = numOrNull(session.totalTimerTime) ?? numOrNull(session.totalElapsedTime) ?? 0;
  const durMin = durSec / 60;

  // 2) TSS por potencia (NP + FTP)
  const np = numOrNull(session.normalizedPower);
  const ftp = numOrNull(session.thresholdPower) ?? numOrNull(perfil?.umbralPotencia);
  if (np != null && np > 0 && ftp != null && ftp > 0 && durSec > 0) {
    return out(((durSec * np * (np / ftp)) / (ftp * 3600)) * 100, 'potencia');
  }

  // 3) rTSS por ritmo (carrera a pie). En FIT, `sport` trae 'running' y
  //    `subSport` afina ('trail_running', 'treadmill_running'…), así que se
  //    miran los dos.
  const tipoSesion = mapSport(session.sport);
  const deporteRaw = `${session.sport ?? ''} ${session.subSport ?? ''}`.toLowerCase();
  const esCarrera = tipoSesion === 'Running' || /run/.test(deporteRaw);
  if (esCarrera && durSec > 0) {
    const rtss = calcularRtss({
      durSec,
      distanciaKm: numOrNull(session.totalDistance) != null ? Number(session.totalDistance) / 1000 : null,
      ritmoUmbralSeg: parseRitmoMinKm(perfil?.umbralRitmo),
    });
    if (rtss) return rtss;
  }

  // 4) hrTSS por frecuencia cardíaca
  const hrtss = calcularHrTss({
    avgHr: session.avgHeartRate,
    maxHrSesion: session.maxHeartRate,
    durMin,
    startDate,
    perfil,
    wellnessDays,
  });
  if (hrtss) return hrtss;

  // 5) Último recurso: Training Effect de Garmin (0–5) → escala aproximada
  const te = numOrNull(session.totalTrainingEffect);
  if (te != null && te > 0) return out(te * 20, 'training-effect');

  return { valor: 0, fuente: null };
}

// ─────────────────────────────────────────────────────────────────
// Recalcula el esfuerzo a partir de los datos RESUMIDOS de un entreno ya
// guardado (duración, distancia, FC media/máxima). Sirve para corregir
// entrenos importados con versiones anteriores de la app sin tener que volver
// a importar el archivo FIT. Usa la misma prioridad que computeEsfuerzo().
// ─────────────────────────────────────────────────────────────────
export function calcularEsfuerzoDesdeResumen(datos, perfil, wellnessDays) {
  const d = datos || {};
  const durSec = numOrNull(d.duracionSeg);
  const durMin = durSec != null ? durSec / 60 : 0;
  const fecha = d.fecha?.toDate ? d.fecha.toDate() : (d.fecha instanceof Date ? d.fecha : new Date(d.fecha || Date.now()));
  const tipoTxt = String(d.tipo || '').toLowerCase();

  // rTSS por ritmo (carrera a pie con ritmo umbral configurado)
  if (/run|carrera/.test(tipoTxt) && durSec != null) {
    const rtss = calcularRtss({
      durSec,
      distanciaKm: numOrNull(d.distanciaKm),
      ritmoUmbralSeg: parseRitmoMinKm(perfil?.umbralRitmo),
    });
    if (rtss) return rtss;
  }

  // TSS por potencia media (aproximación si el entreno tiene potencia y FTP)
  const pot = numOrNull(d.potenciaMedia);
  const ftp = numOrNull(perfil?.umbralPotencia);
  if (pot != null && pot > 0 && ftp != null && ftp > 0 && durSec != null && durSec > 0 && !/run|carrera/.test(tipoTxt)) {
    const ifPot = pot / ftp;
    return { valor: Math.max(0, Math.round((durSec / 3600) * ifPot * ifPot * 100)), fuente: 'potencia' };
  }

  // hrTSS
  const hrtss = calcularHrTss({
    avgHr: d.fcMedia,
    maxHrSesion: d.fcMax,
    durMin,
    startDate: fecha,
    perfil,
    wellnessDays,
  });
  if (hrtss) return hrtss;

  return { valor: 0, fuente: null };
}

// ─────────────────────────────────────────────────────────────────
// MANTENIMIENTO: recalcula en bloque el esfuerzo de los entrenos que ya están
// guardados, a partir de sus datos resumen (duración, distancia, FC media y
// FC máxima) y de los umbrales del perfil. Sirve para corregir el histórico
// importado con versiones anteriores de la app (que daba valores muy bajos)
// sin tener que volver a importar los archivos .fit.
//
// No toca los entrenos sincronizados desde intervals.icu: en ésos manda el TSS
// de intervals.icu y es el servidor quien los corrige al sincronizar. Tampoco
// pisa valores editados a mano por el usuario (esfuerzoManual === true).
// ─────────────────────────────────────────────────────────────────
export async function recalcularEsfuerzos(userId, onProgress) {
  const snap = await getDocs(query(collection(db, 'entrenamientos'), where('userId', '==', userId)));
  const docs = snap.docs;
  let perfil = null;
  let wellnessDays = {};
  try {
    const ps = await getDoc(doc(db, 'perfiles', userId));
    if (ps.exists()) perfil = ps.data();
    const ws = await getDoc(doc(db, 'wellness', userId));
    if (ws.exists()) wellnessDays = ws.data().days || {};
  } catch (e) {
    console.warn('[recalcularEsfuerzos] Error leyendo perfil/wellness:', e.message);
  }

  let actualizados = 0, sinDatos = 0, intactos = 0, omitidos = 0;

  for (let i = 0; i < docs.length; i++) {
    const d = docs[i];
    const w = d.data() || {};
    onProgress?.(`${i + 1}/${docs.length}`, i + 1, docs.length);

    // Los de intervals.icu los corrige el servidor con el TSS real
    if (w.source === 'intervals.icu' || w.intervalsId) { omitidos++; continue; }

    let det = null;
    try {
      const ds = await getDoc(doc(db, 'entrenamientos', d.id, 'detalles', 'data'));
      if (ds.exists()) det = ds.data();
    } catch (e) {}

    if (det?.esfuerzoManual === true || w.esfuerzoManual === true) { intactos++; continue; }

    // duración: en la app puede venir en minutos (<600) o en segundos
    let durSeg = null;
    if (w.duracion != null && Number.isFinite(Number(w.duracion))) {
      const dv = Number(w.duracion);
      durSeg = dv < 600 ? dv * 60 : dv;
    }

    const fecha = w.fecha?.toDate ? w.fecha.toDate() : (w.fecha ? new Date(w.fecha) : new Date());
    const r = calcularEsfuerzoDesdeResumen({
      tipo: w.tipo,
      duracionSeg: durSeg,
      distanciaKm: w.distancia != null ? Number(w.distancia) : null,
      fcMedia: w['fc-media'] ?? det?.['fc-media'] ?? null,
      fcMax: det?.fcMax ?? w.fcMax ?? null,
      potenciaMedia: w.potenciaMedia ?? det?.potenciaMedia ?? null,
      fecha,
    }, perfil, wellnessDays);

    const anterior = Math.round(Number(w.esfuerzo) || 0);
    if (!(r.valor > 0)) { sinDatos++; continue; }
    if (r.valor === anterior && (det?.esfuerzoFuente || w.esfuerzoFuente)) { intactos++; continue; }

    try {
      await updateDoc(doc(db, 'entrenamientos', d.id), { esfuerzo: r.valor, esfuerzoFuente: r.fuente });
      await setDoc(doc(db, 'entrenamientos', d.id, 'detalles', 'data'), {
        esfuerzo: r.valor,
        tss: r.valor,
        esfuerzoFuente: r.fuente,
      }, { merge: true });
      actualizados++;
    } catch (e) {
      console.warn('[recalcularEsfuerzos] Error guardando', d.id, e.message);
    }
  }

  return { total: docs.length, actualizados, sinDatos, intactos, omitidos };
}

export async function resetSyncFolder() {
  await AsyncStorage.removeItem(FOLDER_KEY);
}

function _base64ToArrayBuffer(base64) {
  const binary_string = atob(base64);
  const len = binary_string.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary_string.charCodeAt(i);
  }
  return bytes;
}