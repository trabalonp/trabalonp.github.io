// services/chatSync.js
/* ══════════════════════════════════════════════════════════════════════
   MOTOR DE SINCRONIZACIÓN DEL TABLÓN (patrón WhatsApp del documento
   duck.ai: base local + listener en vivo + sincronización incremental +
   paginación por zonas). Aislado en su propio módulo para poder
   verificarse con tests/chat-sync-test.js contra un Firestore simulado.
   ──────────────────────────────────────────────────────────────────────
   · Primera vez en el dispositivo: SOLO los 60 más recientes
     (PAGINA_INICIAL). Nunca el chat entero.
   · Sincronización INCREMENTAL: únicamente los mensajes posteriores al
     último sincronizado (where createdAt > lastSync), en lotes de 300.
   · Historial por ZONAS: bloques de 50 más antiguos (where createdAt <
     oldestAt, limit 50). En la UI las zonas se cargan SOLAS al rozar el
     borde superior del scroll (estilo WhatsApp); no hay botón de
     "descargar el chat de la nube".
   · Índlices: las tres consultas usan where+orderBy sobre el MISMO campo
     (createdAt) → índice de campo único, SIN índices compuestos.
   · Todo se escribe en el almacén local (chatStore): la pantalla pinta
     desde memoria al instante y la red solo aporta lo que falta.
   ══════════════════════════════════════════════════════════════════════ */
import { collection, getDocs, limit, orderBy, query, where } from 'firebase/firestore';
import { db } from '../firebaseConfig';
import { chatStoreMeta, chatStorePut, chatStoreSetMeta } from './chatStore';

export const PAGINA_INICIAL = 60;     // primera vez en el dispositivo
export const ZONA_ANTIGUOS = 50;      // tamaño de cada zona de historial
export const LOTE_INCREMENTAL = 300;  // lote máximo de la sincronización incremental

/* Sincronización incremental (gap sync):
   1) Sin marca de agua → página inicial con lo más reciente.
   2) Descarga solo lo posterior a lastSync, en lotes de LOTE_INCREMENTAL
      (máximo 5 lotes por llamada; el listener cubre el resto en vivo).
   3) Actualiza la marca de agua lastSync del almacén local. */
export async function gapSync() {
  const meta = await chatStoreMeta();
  let cursor = meta.lastSync || null;
  if (!cursor) {
    // Primera vez: página inicial con lo más reciente (no todo el historial)
    const snap = await getDocs(query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(PAGINA_INICIAL)));
    const docs = snap.docs.map((d) => ({ id: d.id, ...d.data() })).reverse();
    if (docs.length) {
      await chatStorePut(docs);
      await chatStoreSetMeta({ oldestAt: docs[0].createdAt, hasMore: snap.docs.length === PAGINA_INICIAL });
    }
    cursor = docs.length ? docs[docs.length - 1].createdAt : new Date(0).toISOString();
  }
  // Incremental: solo lo posterior al último sincronizado, en lotes de 300
  let guard = 0;
  while (guard++ < 5) {
    const snap = await getDocs(query(collection(db, 'posts'), where('createdAt', '>', cursor), orderBy('createdAt', 'asc'), limit(LOTE_INCREMENTAL)));
    const docs = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    if (docs.length) {
      await chatStorePut(docs);
      cursor = docs[docs.length - 1].createdAt;
    }
    if (snap.docs.length < LOTE_INCREMENTAL) break;
  }
  await chatStoreSetMeta({ lastSync: cursor });
}

/* Carga UNA zona de historial antiguo (ZONA_ANTIGUOS mensajes más viejos que
   el oldestAt local) en el almacén. Devuelve { added, hasMore } para que la
   pantalla actualice su indicador sin conocer los detalles de la consulta. */
export async function loadOlderZone() {
  const meta = await chatStoreMeta();
  if (!meta.oldestAt) return { added: 0, hasMore: false };
  const snap = await getDocs(query(collection(db, 'posts'), where('createdAt', '<', meta.oldestAt), orderBy('createdAt', 'desc'), limit(ZONA_ANTIGUOS)));
  const docs = snap.docs.map((d) => ({ id: d.id, ...d.data() })).reverse();
  const hasMore = snap.docs.length === ZONA_ANTIGUOS;
  if (docs.length) await chatStorePut(docs);
  await chatStoreSetMeta({ oldestAt: docs.length ? docs[0].createdAt : meta.oldestAt, hasMore });
  return { added: docs.length, hasMore };
}
