// services/tablonPurge.js
/* ══════════════════════════════════════════════════════════════════════
   PURGA DE LA MEMORIA LOCAL DEL TABLÓN (Ajustes → "Limpiar memoria")
   ──────────────────────────────────────────────────────────────────────
   El Tablón guarda COSAS EN EL TELÉFONO (patrón WhatsApp, local-first):
     1. Mensajes del chat            → AsyncStorage (chatStore)
     2. Imágenes/audios descargados  → cacheDirectory 'social-img-v3/'
     3. Fotos de perfil (avatares)   → documentDirectory 'avatars-v1/'
     4. Previsualizaciones de enlaces→ AsyncStorage (linkPreview)
   Esta función borra LAS CUATRO COSAS de una vez y avisa a los módulos
   con caché en memoria (SocialScreen: su Map de imágenes descargadas)
   para que nadie sirva rutas de archivos que ya no existen.

   NUNCA toca la nube: el historial del Tablón es permanente en Firestore
   y los archivos viven en R2. Al volver a abrir el Tablón, gapSync()
   re-descarga solo la página reciente (60 mensajes) y las imágenes se
   vuelven a bajar bajo demanda al pintarse. Es decir: limpiar aquí es
   como "cerrar sesión del caché" del chat, no se pierde nada de nadie.

   Se CONSERVAN a propósito (son ajustes tuyos, no memoria del chat):
     · El fondo del Tablón (tablon-bg.jpg + clave 'social_bg_local')
     · Idioma / unidades / tema de la app
   ══════════════════════════════════════════════════════════════════════ */
import * as FileSystem from 'expo-file-system/legacy';
import { chatStoreClear, chatStoreCount } from './chatStore';
import { avatarCacheBytes, avatarCacheClear } from './avatarCache';
import { linkPreviewClear } from './linkPreview';

/* Misma ruta que usa SocialScreen para su caché de imágenes (+ versiones
   antiguas que pudieron quedar en teléfonos con builds viejos). */
const BASE = FileSystem.cacheDirectory || FileSystem.documentDirectory;
const IMG_DIRS = ['social-img-v3/', 'social-img-v2/', 'social-img/'];

/* ── Avisos a módulos con caché en memoria ─────────────────────────────
   SocialScreen se registra al cargarse: al purgar, vacía sus Maps internos
   (diskCache / inflight) para no pintar rutas de archivos borrados. */
const hooks = new Set();
export function onTablonPurge(cb) {
  hooks.add(cb);
  return () => hooks.delete(cb);
}

async function dirFiles(dir) {
  try {
    const info = await FileSystem.getInfoAsync(dir);
    if (!info.exists || !info.isDirectory) return [];
    const names = await FileSystem.readDirectoryAsync(dir);
    return names.map((n) => dir + n);
  } catch (e) { return []; }
}

async function dirBytes(dir) {
  let total = 0;
  for (const f of await dirFiles(dir)) {
    try {
      const i = await FileSystem.getInfoAsync(f);
      if (i.exists && !i.isDirectory) total += i.size || 0;
    } catch (e) {}
  }
  return total;
}

/** Cuánto ocupa HOY la memoria local del Tablón: { msgs, bytes }.
    Se usa para el texto de confirmación ("liberarás ~12 MB, 240 mensajes"). */
export async function tablonLocalStats() {
  let bytes = 0;
  for (const d of IMG_DIRS) bytes += await dirBytes(BASE + d);
  bytes += await avatarCacheBytes();
  let msgs = 0;
  try { msgs = await chatStoreCount(); } catch (e) {}
  return { msgs, bytes };
}

/** Borra TODO lo que el Tablón guarda en este teléfono.
    Devuelve { msgs, bytes } con lo que había antes de borrar. */
export async function purgeTablonLocal() {
  const antes = await tablonLocalStats();

  // 1) Imágenes/audios descargados del chat (+ versiones antiguas)
  for (const d of IMG_DIRS) {
    try { await FileSystem.deleteAsync(BASE + d, { idempotent: true }); } catch (e) {}
  }
  // 2) Fotos de perfil cacheadas (índice + disco)
  try { await avatarCacheClear(); } catch (e) {}
  // 3) Mensajes + marcas de sincronización
  try { await chatStoreClear(); } catch (e) {}
  // 4) Caché de previsualizaciones de enlaces
  try { await linkPreviewClear(); } catch (e) {}
  // 5) Cachés en memoria de los módulos suscritos (SocialScreen)
  for (const cb of [...hooks]) { try { await cb(); } catch (e) {} }

  return antes;
}
