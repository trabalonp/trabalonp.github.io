// services/avatarCache.js
/* Caché local de fotos de perfil del chat (patrón WhatsApp, investigado):
   WhatsApp descarga la miniatura del contacto UNA SOLA VEZ, la guarda en el
   dispositivo y la pinta desde ahí; solo vuelve a descargarla cuando recibe
   un aviso de que esa persona cambió su foto.

   Aquí el "aviso" es una colección ligera de Firestore:

     avatares/<uid> = { url (R2), updatedAt, size }      ← docs de ~200 bytes

   · Al abrir el Tablón se leen SOLO esos docs pequeños (nunca el base64 de
     `perfiles`): si la url no cambió, la foto se pinta desde el disco con
     CERO descargas; si cambió, se baja el archivo nuevo y se sustituye.
   · Al guardar la foto de perfil (ProfileScreen) se sube un JPEG a R2 y se
     escribe `avatares/<uid>`: los demás teléfonos lo ven en su próxima
     sincronización y refrescan solo esa foto.
   · Perfiles ANTIGUOS (sin doc en `avatares`, foto solo en base64 dentro de
     `perfiles`): respaldo con TTL de 6 h — se lee el perfil, se escribe la
     foto a disco y se registra un hash; si el hash no cambia, no se vuelve a
     leer hasta pasado el TTL. El propio usuario publica su doc `avatares`
     automáticamente la primera vez que abre el chat con esta versión.

   Reglas de Firestore necesarias (ver firestore.rules):
     match /avatares/{userId} { read: autenticado; write: solo el dueño } */
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system/legacy';
import { FieldPath, collection, doc, getDoc, getDocs, query, setDoc, where } from 'firebase/firestore';
import { auth, db } from '../firebaseConfig';
import { getApiUrl } from './api';
import { getCachedProfile } from './profileCache';

const DIR = (FileSystem.documentDirectory || FileSystem.cacheDirectory) + 'avatars-v1/';
const K_IDX = 'tj_avatars_v1';       // { uid: { url, file, hash, updatedAt, checkedAt, neg? } }
const K_META = 'tj_avatars_meta_v1'; // { lastRun, mioPub }
const TTL_LEGACY_MS = 6 * 3600000;   // perfiles sin doc `avatares`: revisar cada 6 h
const MIN_RERUN_MS = 90000;          // sincronizaciones completas: como mucho cada 90 s
const REPUBLIO_DIA = 86400000;

let idx = null;                      // índice persistente (espejo en memoria)
let meta = null;
let initPr = null;
let saveTimer = null;
const mem = new Map();               // uid -> file uri (pintado síncrono)
const subs = new Set();              // avisos a componentes suscritos
const inflight = new Map();          // uid -> promesa de descarga (single-flight)

/* Subida BINARIA (misma protección que el chat: el multipart corrompe R2). */
const BIN_UPLOAD = (() => {
  try {
    const M = FileSystem.FileSystemUploadMethod || FileSystem.FileSystemUploadType || {};
    if (typeof M.BINARY_CONTENT === 'number') return M.BINARY_CONTENT;
    if (typeof M.MULTIPART === 'number') return M.MULTIPART === 0 ? 1 : 0;
  } catch (e) {}
  return 0;
})();

function avisar() { for (const cb of subs) { try { cb(); } catch (e) {} } }

function persist() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      AsyncStorage.setItem(K_IDX, JSON.stringify(idx || {}));
      AsyncStorage.setItem(K_META, JSON.stringify(meta || {}));
    } catch (e) {}
  }, 400);
}

/** PURGA TOTAL de la caché de avatares (Ajustes → "Limpiar memoria del Tablón"):
    borra el directorio de fotos, el índice persistente y el espejo en memoria.
    Al volver al Tablón, sincronizarAvatares() reconstruye la caché desde los
    docs ligeros `avatares/<uid>` (solo re-descarga las fotos que se pinten). */
export async function avatarCacheClear() {
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
  idx = {}; meta = {};
  initPr = null;
  mem.clear();
  inflight.clear();
  try { await AsyncStorage.multiRemove([K_IDX, K_META]); } catch (e) {}
  try { await FileSystem.deleteAsync(DIR, { idempotent: true }); } catch (e) {}
  avisar();
}

/** Bytes ocupados ahora por las fotos de perfil cacheadas en disco. */
export async function avatarCacheBytes() {
  try {
    const info = await FileSystem.getInfoAsync(DIR);
    if (!info.exists) return 0;
    const names = await FileSystem.readDirectoryAsync(DIR);
    let total = 0;
    for (const n of names) {
      try {
        const f = await FileSystem.getInfoAsync(DIR + n);
        if (f.exists && !f.isDirectory) total += f.size || 0;
      } catch (e) {}
    }
    return total;
  } catch (e) { return 0; }
}

/** Hash barato de un base64 (djb2 sobre una ventana + longitud). */
export function hashB64(s) {
  const str = String(s || '');
  const n = Math.min(str.length, 4096);
  let h = 5381;
  for (let i = 0; i < n; i++) h = ((h * 33) ^ str.charCodeAt(i)) >>> 0;
  return `${h.toString(36)}-${str.length}`;
}

async function ensureDir() {
  try {
    const info = await FileSystem.getInfoAsync(DIR);
    if (!info.exists) await FileSystem.makeDirectoryAsync(DIR, { intermediates: true });
  } catch (e) {}
}

async function init() {
  if (idx) return;
  if (!initPr) {
    initPr = (async () => {
      try {
        const [rawI, rawM] = await Promise.all([AsyncStorage.getItem(K_IDX), AsyncStorage.getItem(K_META)]);
        idx = safeJson(rawI, {}); meta = safeJson(rawM, {});
      } catch (e) { idx = {}; meta = {}; }
      if (typeof idx !== 'object' || Array.isArray(idx)) idx = {};
      if (typeof meta !== 'object' || Array.isArray(meta)) meta = {};
      for (const uid of Object.keys(idx)) {
        const e = idx[uid];
        if (e && e.file && !e.neg) mem.set(uid, e.file);
      }
      avisar();   // los componentes ya montados reciben las fotos cacheadas
    })();
  }
  return initPr;
}
function safeJson(s, d) { try { const v = JSON.parse(s); return v == null ? d : v; } catch (e) { return d; } }

/** Uri local de la foto de uid, o null (pintar inicial). Síncrono. */
export function avatarSync(uid) { return mem.get(uid) || null; }

/** Hook: uri local de la foto; se actualiza solo cuando la caché cambia. */
export function useAvatar(uid) {
  const [uri, setUri] = useState(() => avatarSync(uid));
  useEffect(() => {
    let vivo = true;
    const cb = () => { if (vivo) setUri(avatarSync(uid)); };
    subs.add(cb);
    init().then(cb).catch(() => {});
    return () => { vivo = false; subs.delete(cb); };
  }, [uid]);
  return uri;
}

/** Descarga la foto desde R2 (single-flight + .part + move atómico). */
async function descargar(uid, url) {
  if (inflight.has(uid)) return inflight.get(uid);
  const pr = (async () => {
    await ensureDir();
    const f = DIR + 'av-' + uid + '.jpg';
    const part = f + '.part';
    try { await FileSystem.deleteAsync(part, { idempotent: true }); } catch (e) {}
    await FileSystem.downloadAsync(url, part);
    const info = await FileSystem.getInfoAsync(part);
    if (!info.exists || !(info.size > 0)) throw new Error('descarga vacía');
    try { await FileSystem.deleteAsync(f, { idempotent: true }); } catch (e) {}
    await FileSystem.moveAsync({ from: part, to: f });
    idx[uid] = { ...(idx[uid] || {}), url, file: f, updatedAt: Date.now(), checkedAt: Date.now() };
    delete idx[uid].neg;
    mem.set(uid, f);
    persist();
    avisar();
    return f;
  })();
  inflight.set(uid, pr);
  pr.catch(() => {}).then(() => inflight.delete(uid));
  return pr;
}

function trozos(arr, n) {
  const out = [];
  for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n));
  return out;
}

/** Sube MI foto (base64) a R2 y publica avatares/<uid>. Nunca bloquea la UI. */
export async function publicarMiAvatar(base64, meUser) {
  const me = meUser || auth.currentUser;
  if (!me || !base64) return null;
  await init();
  await ensureDir();
  const tmp = DIR + 'pendiente-' + Date.now() + '.jpg';
  try {
    await FileSystem.writeAsStringAsync(tmp, base64, { encoding: FileSystem.EncodingType.Base64 });
    const info = await FileSystem.getInfoAsync(tmp);
    const apiUrl = (await getApiUrl()).replace(/\/+$/, '');
    const token = await me.getIdToken();
    const r = await fetch(`${apiUrl}/social/presign`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ filename: `avatar-${me.uid}.jpg`, contentType: 'image/jpeg', size: info.size || 0 }),
    });
    const d = await r.json().catch(() => null);
    if (!r.ok || !d || !d.uploadUrl) throw new Error((d && d.error) || `presign HTTP ${r.status}`);
    await FileSystem.uploadAsync(d.uploadUrl, tmp, {
      httpMethod: 'PUT',
      headers: { 'Content-Type': 'image/jpeg' },
      mimeType: 'image/jpeg',
      uploadType: BIN_UPLOAD,
    });
    const iso = new Date().toISOString();
    await setDoc(doc(db, 'avatares', me.uid), { url: d.publicUrl, updatedAt: iso, size: info.size || 0 });
    // Mi propio teléfono: la foto queda cacheada al instante
    const dest = DIR + 'av-' + me.uid + '.jpg';
    try { await FileSystem.deleteAsync(dest, { idempotent: true }); } catch (e) {}
    await FileSystem.moveAsync({ from: tmp, to: dest });
    idx[me.uid] = { url: d.publicUrl, file: dest, hash: hashB64(base64), updatedAt: Date.now(), checkedAt: Date.now() };
    mem.set(me.uid, dest);
    persist();
    avisar();
    return d.publicUrl;
  } finally {
    try { await FileSystem.deleteAsync(tmp, { idempotent: true }); } catch (e) {}
  }
}

/**
 * Sincroniza las fotos de `uids` (autores del chat) con descargas mínimas:
 *  1) Publica MI doc `avatares` si no existe (una vez al día como mucho).
 *  2) Lee los docs ligeros `avatares` (where documentId in …, lotes de 10):
 *     url sin cambios → CERO descargas; url nueva → baja el archivo.
 *  3) Sin doc `avatares` (perfiles antiguos): lee `perfiles/<uid>` con TTL
 *     de 6 h y cachea el base64 a disco por hash.
 */
export async function sincronizarAvatares(uids, meUid, opts) {
  try {
    await init();
    const ahora = Date.now();
    const force = !!(opts && opts.force);
    if (!force && meta.lastRun && ahora - meta.lastRun < MIN_RERUN_MS) return;
    meta.lastRun = ahora;
    persist();

    // 1) Mi propio doc de avatar (migración automática, una vez al día)
    const yo = auth.currentUser;
    if (meUid && yo && yo.uid === meUid && (!meta.mioPub || force || ahora - meta.mioPub > REPUBLIO_DIA)) {
      try {
        const snapAv = await getDoc(doc(db, 'avatares', meUid));
        if (!snapAv.exists()) {
          let perfil = await getCachedProfile(meUid);
          if (!perfil || !perfil.foto) {
            const sp = await getDoc(doc(db, 'perfiles', meUid));
            perfil = sp.exists() ? sp.data() : null;
          }
          if (perfil && perfil.foto) await publicarMiAvatar(perfil.foto, yo);
        }
      } catch (e) { /* sin servidor o sin reglas publicadas */ }
      meta.mioPub = ahora;   // con éxito o sin él: no se reintenta hasta mañana
      persist();
    }

    // 2) Docs ligeros `avatares` de los autores del chat
    const lista = [...new Set((uids || []).filter(Boolean))];
    const sinDoc = [];
    for (const chunk of trozos(lista, 10)) {
      try {
        const snap = await getDocs(query(collection(db, 'avatares'), where(FieldPath.documentId(), 'in', chunk)));
        const vistos = new Set();
        snap.forEach((d) => {
          vistos.add(d.id);
          const data = d.data() || {};
          const cached = idx[d.id];
          if (data.url && (!cached || cached.url !== data.url)) {
            descargar(d.id, data.url).catch(() => {});   // en segundo plano
          } else if (cached) {
            cached.checkedAt = ahora;
          }
        });
        for (const uid of chunk) if (!vistos.has(uid)) sinDoc.push(uid);
      } catch (e) {
        for (const uid of chunk) sinDoc.push(uid);   // sin colección/reglas: respaldo legacy
      }
    }
    persist();

    // 3) Respaldo para perfiles antiguos (base64 en `perfiles`, TTL 6 h)
    for (const uid of sinDoc) {
      const cached = idx[uid];
      if (cached && cached.checkedAt && ahora - cached.checkedAt < TTL_LEGACY_MS && (cached.file || cached.neg)) continue;
      try {
        const snap = await getDoc(doc(db, 'perfiles', uid));
        const foto = snap.exists() ? (snap.data() || {}).foto : null;
        if (foto) {
          const h = hashB64(foto);
          if (!cached || !cached.file || cached.hash !== h) {
            await ensureDir();
            const f = DIR + 'av-' + uid + '.jpg';
            await FileSystem.writeAsStringAsync(f, foto, { encoding: FileSystem.EncodingType.Base64 });
            idx[uid] = { file: f, hash: h, checkedAt: ahora, updatedAt: ahora };
            delete idx[uid].neg;
            mem.set(uid, f);
            avisar();
          } else {
            cached.checkedAt = ahora;
          }
        } else {
          idx[uid] = { ...(cached || {}), neg: true, checkedAt: ahora };
          mem.delete(uid);
          avisar();
        }
      } catch (e) { /* sin acceso: se queda la inicial o la foto ya cacheada */ }
    }
    persist();
  } catch (e) {
    console.warn('[avatarCache] sync:', e && e.message);
  }
}

/** Arranca la caché al montar el chat (lectura del índice en segundo plano). */
export function avatarCacheInit() { init().catch(() => {}); }
