// services/GarminUploadService.js
// ─────────────────────────────────────────────────────────────
// SUBIDA AUTOMÁTICA A GARMIN DESACTIVADA DEFINITIVAMENTE.
// El método anterior (usuario/contraseña + script Python) quedó
// inutilizado y Garmin no ofrece API gratuita de subida a particulares.
// Se mantiene el export para que ningún import antiguo rompa la app.
// ─────────────────────────────────────────────────────────────
export async function uploadWorkoutToGarmin(_workout) {
  throw new Error(
    'La subida automática a Garmin ya no está disponible. ' +
    'Las actividades se sincronizan con Intervals.icu y los entrenos se programan dentro de la app.'
  );
}