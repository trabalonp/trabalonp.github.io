// services/fechasChat.js
/* Utilidades PURAS de fecha/tamaño/archivo del Tablón. Sin dependencias de
   React Native: se pueden verificar desde Node con tests/chat-sync-test.js.
   Separadores de día estilo WhatsApp:
   · hoy            → "HOY"
   · ayer           → "AYER"
   · últimos 7 días → nombre del día ("Miércoles")
   · más antiguos   → "15 de marzo de 2024" (día + mes + año) */

/** Convierte un createdAt (ISO string o Timestamp de Firestore) a Date. */
export function tsADate(ts) {
  if (!ts) return null;
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  return isNaN(d.getTime()) ? null : d;
}

/** Clave de día local: dos mensajes son del mismo día si comparten clave. */
export function claveDia(ts) {
  const d = tsADate(ts);
  return d ? `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}` : '';
}

const mayus1 = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : '');

/** Etiqueta del separador de fecha estilo WhatsApp. */
export function fmtSeparador(ts, loc, L) {
  const d = tsADate(ts);
  if (!d) return '';
  const hoy = new Date(); hoy.setHours(0, 0, 0, 0);
  const md = new Date(d.getTime()); md.setHours(0, 0, 0, 0);
  if (md.getTime() === hoy.getTime()) return L ? L('HOY', 'TODAY') : 'HOY';
  const ayer = new Date(hoy.getTime()); ayer.setDate(ayer.getDate() - 1);
  if (md.getTime() === ayer.getTime()) return L ? L('AYER', 'YESTERDAY') : 'AYER';
  const diff = Math.round((hoy.getTime() - md.getTime()) / 86400000);
  if (diff < 7) return mayus1(d.toLocaleDateString(loc, { weekday: 'long' }));
  return mayus1(d.toLocaleDateString(loc, { day: 'numeric', month: 'long', year: 'numeric' }));
}

/** Tamaño legible de archivo ("500 KB", "2.5 MB"). */
export function fmtSize(b) {
  const n = Number(b || 0);
  if (n <= 0) return '';
  if (n < 1024 * 1024) return `${Math.max(1, Math.round(n / 1024))} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

/** Duración mm:ss para audios. */
export function fmtDur(s) {
  const n = Math.max(0, Math.floor(Number(s) || 0));
  return `${Math.floor(n / 60)}:${String(n % 60).padStart(2, '0')}`;
}

/** True si el adjunto es audio (por MIME o por extensión del nombre/URL). */
export function esAudioMedia(m) {
  if (!m) return false;
  if (String(m.contentType || '').toLowerCase().startsWith('audio/')) return true;
  return /\.(mp3|m4a|aac|ogg|oga|opus|wav|amr|3gp|flac)(\?|$)/i.test(String(m.nombre || m.url || ''));
}

/** Extensión en mayúsculas ("informe.pdf" → "PDF"). */
export function extDe(nombre) {
  const n = String(nombre || '');
  const i = n.lastIndexOf('.');
  return i > 0 && i < n.length - 1 ? n.slice(i + 1).toUpperCase() : '';
}
