// services/profileCache.js
import AsyncStorage from '@react-native-async-storage/async-storage';
import { clearCoachCache } from './coachCache';

const PROFILE_KEY = (uid) => `profile_cache_${uid}`;

// Obtener perfil cacheado (devuelve el objeto o null)
export async function getCachedProfile(uid) {
  try {
    const json = await AsyncStorage.getItem(PROFILE_KEY(uid));
    return json ? JSON.parse(json) : null;
  } catch { return null; }
}

// Guardar perfil en caché (pasas el objeto completo, incluida la foto en base64)
export async function cacheProfile(uid, profileData) {
  try {
    await AsyncStorage.setItem(PROFILE_KEY(uid), JSON.stringify(profileData));
  } catch (e) { console.warn('Error al cachear perfil:', e); }
}

// Invalidar la caché para forzar recarga en el siguiente acceso
export async function invalidateProfileCache(uid) {
  try {
    // Borra y vuelve a escribir con ts=0 fuerza recarga en siguiente acceso
    if (uid) await AsyncStorage.removeItem(PROFILE_KEY(uid));
  } catch (e) {}
}

// Borrar el caché del perfil
export async function clearProfileCache(uid) {
  try {
    if (uid) await AsyncStorage.removeItem(PROFILE_KEY(uid));
    // Limpiar también el formato antiguo (migración)
    await AsyncStorage.removeItem('profile_cache');
  } catch (e) {}
}

export async function clearAllUserData(uid) {
  try {
    await clearProfileCache(uid);
    await clearCoachCache();
    await AsyncStorage.multiRemove(['garmin_email', 'garmin_password', 'garmin_days', 'fit_folder_uri']);
  } catch (e) { console.warn('Error al limpiar datos de usuario:', e); }
}