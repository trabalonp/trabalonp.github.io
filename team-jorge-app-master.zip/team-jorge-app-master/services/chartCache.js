// services/chartCache.js
// Caché global en memoria, CLAVEADA POR USUARIO (entrenador o atleta).
// Sobrevive a desmontajes y cambios de pestaña; solo se limpia al cerrar la app
// o con bumpRefresh() (pull-to-refresh, sync, guardar/editar).

const state = {
  entrenamientos: null, // { uid, data, ts }
  wellness: null,       // { uid, days, ts }
  zonasRitmo: null,     // { uid, zones, ts }
  resumen: {},          // { "<uid>:<weekKey>": { zoneSec, kcal, altura, ts } }
};

export function clearAll() {
  state.entrenamientos = null;
  state.wellness = null;
  state.zonasRitmo = null;
  state.resumen = {};
}
export function bumpRefresh() { clearAll(); }

export function getEntrenamientos(uid) {
  return state.entrenamientos && state.entrenamientos.uid === uid ? state.entrenamientos.data : null;
}
export function setEntrenamientos(uid, data) {
  state.entrenamientos = { uid, data, ts: Date.now() };
}

export function getWellness(uid) {
  return state.wellness && state.wellness.uid === uid ? state.wellness.days : null;
}
export function setWellness(uid, days) {
  state.wellness = { uid, days, ts: Date.now() };
}

export function getZonasRitmo(uid) {
  return state.zonasRitmo && state.zonasRitmo.uid === uid ? state.zonasRitmo.zones : null;
}
export function setZonasRitmo(uid, zones) {
  state.zonasRitmo = { uid, zones, ts: Date.now() };
}

export function getResumen(uid, weekKey) {
  return state.resumen[`${uid}:${weekKey}`] || null;
}
export function setResumen(uid, weekKey, val) {
  state.resumen[`${uid}:${weekKey}`] = { ...val, ts: Date.now() };
}