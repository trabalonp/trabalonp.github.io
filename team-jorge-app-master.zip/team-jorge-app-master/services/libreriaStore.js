// services/libreriaStore.js
/* ══════════════════════════════════════════════════════════════════════
   ALMACÉN LOCAL DE LA LIBRERÍA (mismo patrón "local-first" que el chat)
   ──────────────────────────────────────────────────────────────────────
   La librería NO consulta Firestore cada vez que se abre:
   · Sesiones y carpetas del usuario viven en ESTE almacén local
     persistente (AsyncStorage, clave POR USUARIO).
   · Al abrir la pestaña se pinta el almacén AL INSTANTE (sin red).
   · Un listener en vivo (onSnapshot, filtro de igualdad por userId →
     índice automático, sin índices compuestos) mantiene el almacén al
     día: added/modified → upsert; removed → baja local. Solo entran
     DELTAS, nunca re-lecturas completas.
   · El listado procedural (15 en 15) se pagina EN CLIENTE desde este
     almacén: abrir, buscar, mover o contar no gasta lecturas.
   · Toda escritura de la app (crear carpeta, mover, editar…) se refleja
     también aquí de inmediato; el eco del listener converge igual.
   Backend: AsyncStorage (como chatStore). Tope de seguridad 2000 docs.
   ══════════════════════════════════════════════════════════════════════ */
import AsyncStorage from '@react-native-async-storage/async-storage';

const clave = (uid) => `tj_libreria_v1_${uid || 'anon'}`;
const MAX_DOCS = 2000;

let mem = null;        // { uid, docs: Map(id->doc) }
let initPr = null;
let saveTimer = null;

function safeJson(s, d) {
  try { const v = JSON.parse(s); return v == null ? d : v; } catch (e) { return d; }
}

async function cargar(uid) {
  const raw = await AsyncStorage.getItem(clave(uid));
  let docs = raw ? safeJson(raw, []) : [];
  if (!Array.isArray(docs)) docs = [];
  const map = new Map();
  for (const d of docs) if (d && d.id) map.set(d.id, d);
  mem = { uid, docs: map };
  persist();
  return mem;
}

/** Carga el almacén del usuario (idempotente; recarga si cambia el uid). */
export async function libreriaStoreInit(uid) {
  if (mem && mem.uid === uid) return mem;
  if (initPr && initPr.uid === uid) return initPr.pr;
  initPr = { uid, pr: cargar(uid).catch((e) => {
    console.warn('[libreriaStore] init:', e && e.message);
    mem = { uid, docs: new Map() };
    return mem;
  }) };
  return initPr.pr;
}

/** Todos los docs locales del usuario (sesiones + carpetas). */
export async function libreriaStoreAll() {
  if (!mem) return [];
  return [...mem.docs.values()];
}

/** Upsert de sesiones/carpetas (por id). Acepta uno o varios. */
export async function libreriaStorePut(list) {
  if (!mem) return;
  const arr = Array.isArray(list) ? list : [list];
  for (const d of arr) {
    if (!d || !d.id) continue;
    mem.docs.set(d.id, { ...d });
  }
  if (mem.docs.size > MAX_DOCS) {
    // Tope de seguridad: sobra diciendo que es casi imposible llegar.
    const recortados = [...mem.docs.values()].slice(0, MAX_DOCS);
    mem.docs = new Map(recortados.map((d) => [d.id, d]));
  }
  persist();
}

/** Baja local por ids (docs eliminados en la nube o por la propia app). */
export async function libreriaStoreRemove(ids) {
  if (!mem) return 0;
  const arr = Array.isArray(ids) ? ids : [ids];
  let n = 0;
  for (const id of arr) { if (mem.docs.delete(id)) n++; }
  if (n) persist();
  return n;
}

/** Escritura diferida (400 ms): una ráfaga de cambios = 1 sola escritura. */
function persist() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      if (!mem) return;
      AsyncStorage.setItem(clave(mem.uid), JSON.stringify([...mem.docs.values()]));
    } catch (e) { console.warn('[libreriaStore] persist:', e && e.message); }
  }, 400);
}
