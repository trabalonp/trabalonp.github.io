// services/api.js
import { getDatabase, ref, get } from 'firebase/database';

// ⚠️ Cambia esto por la URL de tu backend en Vercel (termina en /api)
export const DEFAULT_API_URL = 'https://mi-app-entrenos.vercel.app/api';

export async function getApiUrl() {
  try {
    const db = getDatabase();
    const snap = await get(ref(db, 'config/serverUrl'));
    const val = snap.val();

    if (val && typeof val === 'string' && val.trim()) {
      return val.trim().replace(/\/+$/, '');
    }

    return DEFAULT_API_URL;
  } catch {
    return DEFAULT_API_URL;
  }
}