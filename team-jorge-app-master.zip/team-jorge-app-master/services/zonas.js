// services/zonas.js
/* ══════════════════════════════════════════════════════════════════════
   ZONAS (FC / Ritmo / Potencia): helpers compartidos
   ──────────────────────────────────────────────────────────────────────
   · tituloZona(): el nombre VISIBLE de una zona. Prioridad:
       1) zone.titulo  → el título editable que el usuario pone en
          Ajustes de Zonas (modo Editar): "R0", "R1+", "Serie roja"…
       2) zone.label   → label guardado de versiones anteriores ("R0",
          "Z1 Recuperación"…): no se pierde nada al actualizar.
       3) "Zona N"     → nombre por posición (el que usa el menú
          "Agregar zona").
     TODAS las pantallas que pintan nombres de zonas (StepEditor,
     WorkoutDetailModal, WeeklyKmChart, analyticsEngine…) usan esto para
     que el título editable se vea en toda la app, no solo en Zonas.
   · pctZona(): el porcentaje con el que se calcula cada zona (editable en
     el modo Editar de Zonas; si la zona no tiene pct guardado se usa el
     defecto de abajo).
       FC   (% de FC máxima):      Z1 81 · Z2 89 · Z3 93 · Z4 99 ·
                                    Z5A 102 · Z5B 106 · Z5C 155
       RITMO (% de intensidad sobre el umbral; 9 zonas por defecto):
                                    R0 65 · R1 70 · R1+ 75 · R2 85 · R3 95 ·
                                    R3+ 105 · R4 115 · R5 130 · R6 150
         (las zonas extra R2+/R4+/R5+ heredan los porcentajes que ya usaba
          la app antigua: 85 / 105 / 115)
       POTENCIA (% de FTP):        55 · 75 · 90 · 105 · 120 · 150
     El porcentaje de una zona es su LÍMITE SUPERIOR: el mínimo de la zona
     es el porcentaje de la zona anterior (y la primera empieza en 0).
   ══════════════════════════════════════════════════════════════════════ */

export function tituloZona(z, i, pref = 'Z') {
  return (z && (z.titulo || z.label)) || `${pref}${i + 1}`;
}

/* ═══ ZONAS POR ACTIVIDAD ═══
   Las zonas "Genéricas" (zonasFC/zonasRitmo/zonasPotencia del perfil) siguen
   siendo el punto de partida; una actividad puede tener su PROPIO juego en
   perfil.zonasActividad = { [actividad]: { fc: [], ritmo: [], potencia: [] } }.
   zonasDeActividad() resuelve qué juego usar (el específico si tiene zonas,
   si no las genéricas) y es la ÚNICA puerta que deben usar los consumidores
   (StepEditor, PasosResumen, visor de zonas, cálculos…). */
const METRIC_KEY = { FC: 'fc', Ritmo: 'ritmo', Potencia: 'potencia' };

export function zonasDeActividad(perfil, metrica, actividad) {
  const key = metrica === 'FC' ? 'zonasFC' : metrica === 'Ritmo' ? 'zonasRitmo' : 'zonasPotencia';
  const genericas = (perfil && perfil[key]) || [];
  if (!actividad || !perfil) return genericas;
  const especificas = perfil.zonasActividad?.[actividad]?.[METRIC_KEY[metrica] || 'fc'];
  return Array.isArray(especificas) && especificas.length ? especificas : genericas;
}

const PCT_FC = { 1: 81, 2: 89, 3: 93, 4: 99, 5: 102, 6: 106, 7: 155 };
const PCT_FC_LISTA = [81, 89, 93, 99, 102, 106, 155];

const PCT_RITMO = { R0: 65, R1: 70, 'R1+': 75, R2: 85, R3: 95, 'R3+': 105, R4: 115, R5: 130, R6: 150 };
const PCT_RITMO_EXTRA = { 'R2+': 85, 'R4+': 105, 'R5+': 115 };   // ids fuera de las 9 por defecto
const PCT_RITMO_LISTA = [65, 70, 75, 85, 95, 105, 115, 130, 150];

const PCT_POT = { 1: 55, 2: 75, 3: 90, 4: 105, 5: 120, 6: 150 };
const PCT_POT_LISTA = [55, 75, 90, 105, 120, 150];

/** % de cálculo de una zona: el guardado (editable) o el defecto por id/posición. */
export function pctZona(z, i, tab) {
  const propio = z && parseFloat(String(z.pct).replace(',', '.'));
  if (Number.isFinite(propio) && propio > 0) return propio;
  const id = z ? String(z.id) : '';
  if (tab === 'FC') return PCT_FC[id] ?? PCT_FC_LISTA[i] ?? 155;
  if (tab === 'Ritmo') return PCT_RITMO[id] ?? PCT_RITMO_EXTRA[id] ?? PCT_RITMO_LISTA[i] ?? 150;
  return PCT_POT[id] ?? PCT_POT_LISTA[i] ?? 150;
}
