// components/StepEditor.js
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Modal, ScrollView, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { auth } from '../firebaseConfig';
import SystemBars from './SystemBars';
import { getCachedProfile } from '../services/profileCache';
import { getThemeColors, L, useAppSettings } from '../services/appSettings';
import { zonasDeActividad } from '../services/zonas';

const CARD='#162032', BORDER='#1E3048', BLUE='#4A90E2', NAVY='#0D1B2A', RED='#E05252';

// Valores que se GUARDAN (no se traducen: los usa la lógica y la sync de Garmin)
export const TIPOS_PASO = ['Calentamiento','Extensivo','Intensivo','Variable','Recuperación','Entrenamiento tecnico','Enfriarse','Otro'];
export const DUR_TYPES = ['Distancia','Tiempo','Botón de vuelta'];
export const UNIDADES_DIST = ['km','m','mi','yd'];
export const OBJETIVOS = ['Ritmo','FC media','Zona FC','Potencia','Zona potencia','Zona ritmo','Intensidad','Elevación','Cadencia'];

// Etiquetas visibles (traducidas) para los valores guardados
const tipoLabel = (k) => ({
  'Calentamiento': L('Calentamiento','Warm-up'),
  'Extensivo': L('Extensivo','Extensive'),
  'Intensivo': L('Intensivo','Intensive'),
  'Variable': L('Variable','Variable'),
  'Recuperación': L('Recuperación','Recovery'),
  'Entrenamiento tecnico': L('Entrenamiento tecnico','Tech training'),
  'Enfriarse': L('Enfriarse','Cool-down'),
  'Otro': L('Otro','Other'),
})[k] || k;
const durLabel = (k) => ({
  'Distancia': L('Distancia','Distance'),
  'Tiempo': L('Tiempo','Time'),
  'Botón de vuelta': L('Botón de vuelta','Lap button'),
})[k] || k;
const objLabel = (k) => ({
  'Ritmo': L('Ritmo','Pace'),
  'FC media': L('FC media','Avg HR'),
  'Zona FC': L('Zona FC','HR zone'),
  'Potencia': L('Potencia','Power'),
  'Zona potencia': L('Zona potencia','Power zone'),
  'Zona ritmo': L('Zona ritmo','Pace zone'),
  'Intensidad': L('Intensidad','Intensity'),
  'Elevación': L('Elevación','Elevation'),
  'Cadencia': L('Cadencia','Cadence'),
})[k] || k;

let _id = Date.now();
export function emptyStep() {
  return {
    id: ++_id, tipo: 'Calentamiento', durTipo: 'Tiempo',
    durValor: '', durTexto: '', durUnidad: 'km',
    objetivo: '', objMin: '', objMax: '', objZona: '',
    repeticiones: '1', hijos: [],
  };
}
export function parseTimeToMinutes(str) {
  if (str == null) return null;
  const s = String(str).trim();
  if (!s) return null;
  const parts = s.split(':');
  if (parts.length === 1) {
    const n = Number(s.replace(',', '.'));
    return Number.isFinite(n) && n >= 0 ? n : null;
  }
  if (parts.length === 2) {
    const m = Number(parts[0]); const sec = Number(parts[1] || 0);
    if (!Number.isFinite(m) || !Number.isFinite(sec)) return null;
    return m + sec / 60;
  }
  if (parts.length === 3) {
    const h = Number(parts[0]); const m = Number(parts[1] || 0); const sec = Number(parts[2] || 0);
    if (!Number.isFinite(h) || !Number.isFinite(m) || !Number.isFinite(sec)) return null;
    return h * 60 + m + sec / 60;
  }
  return null;
}
export function formatTimeInput(str) {
  if (str == null) return null;
  const s = String(str).trim();
  if (!s) return null;
  const parts = s.split(':').map(x => x.trim());
  if (parts.length > 3) return null;
  const nums = parts.map(x => (x === '' ? 0 : Number(x)));
  if (nums.some(n => !Number.isFinite(n) || n < 0)) return null;
  let totalSec;
  if (parts.length === 1) totalSec = Math.round(nums[0] * 60);
  else if (parts.length === 2) totalSec = Math.round(nums[0] * 60 + nums[1]);
  else totalSec = Math.round(nums[0] * 3600 + nums[1] * 60 + nums[2]);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const sec = totalSec % 60;
  const pad = n => String(n).padStart(2, '0');
  return `${pad(h)}:${pad(m)}:${pad(sec)}`;
}
export function normalizeStep(p) {
  const q = { ...p, hijos: (p.hijos || []).map(normalizeStep) };
  q.valor = q.durValor ?? q.valor ?? '';
  q.unidad = q.durTipo === 'Distancia' ? (q.durUnidad || 'km') : (q.durTipo === 'Tiempo' ? 'min' : 'lap');
  return q;
}
function mapTree(list, id, fn) {
  return list.map(p => (p.id === id ? fn({ ...p }) : { ...p, hijos: mapTree(p.hijos || [], id, fn) }));
}
function removeFromTree(list, id) {
  return list.filter(p => p.id !== id).map(p => ({ ...p, hijos: removeFromTree(p.hijos || [], id) }));
}
function findInTree(list, id) {
  for (const p of list) { if (p.id === id) return p; const f = findInTree(p.hijos || [], id); if (f) return f; }
  return null;
}
function deepCopy(p) { return { ...p, id: ++_id, hijos: (p.hijos || []).map(deepCopy) }; }
function insertAfter(list, id, node) {
  const out = [];
  for (const p of list) {
    if (p.id === id) out.push(p, node);
    else out.push({ ...p, hijos: insertAfter(p.hijos || [], id, node) });
  }
  return out;
}
function addChild(list, id, node) {
  return list.map(p => (p.id === id ? { ...p, hijos: [...(p.hijos || []), node] } : { ...p, hijos: addChild(p.hijos || [], id, node) }));
}
// Picker que acepta strings o {value,label}; guarda siempre value
function Picker({ value, options, onChange, placeholder = 'Escoge' }) {
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const [open, setOpen] = useState(false);
  const isObj = options[0] && typeof options[0] === 'object';
  const valOf = (o) => (isObj ? o.value : o);
  const lblOf = (o) => (isObj ? o.label : o);
  return (
    <>
      <TouchableOpacity style={[pk.btn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => setOpen(true)}>
        <Text style={[pk.btnText, { color: value ? theme.text : theme.muted }]} numberOfLines={1}>
          {lblOf(options.find(o => valOf(o) === value)) || value || placeholder}
        </Text>
        <Ionicons name="chevron-down" size={14} color={theme.muted} />
      </TouchableOpacity>
      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <TouchableOpacity style={[pk.overlay, { backgroundColor: theme.overlay }]} activeOpacity={1} onPress={() => setOpen(false)}>
          <View style={[pk.box, { backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border }]}>
            <ScrollView style={{ maxHeight: 340 }}>
              {options.map(o => (
                <TouchableOpacity key={String(valOf(o))} style={[pk.opt, { borderBottomColor: theme.border }, value === valOf(o) && [pk.optActive, { backgroundColor: BLUE + '22' }]]} onPress={() => { onChange(valOf(o)); setOpen(false); }}>
                  <Text style={[pk.optText, { color: value === valOf(o) ? BLUE : theme.text }, value === valOf(o) && pk.optTextActive]}>{lblOf(o)}</Text>
                  {value === valOf(o) && <Ionicons name="checkmark" size={16} color={BLUE} />}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </TouchableOpacity>
        <SystemBars />
      </Modal>
    </>
  );
}
const pk = StyleSheet.create({
  btn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: NAVY, borderRadius: 6, borderWidth: 1, borderColor: BORDER, paddingHorizontal: 10, paddingVertical: 9, gap: 6 },
  btnText: { color: '#fff', fontSize: 12, flex: 1 },
  ph: { color: '#4A6080' },
  overlay: { flex: 1, backgroundColor: '#00000088', justifyContent: 'center', alignItems: 'center' },
  box: { width: '75%', backgroundColor: '#1B1B1D', borderRadius: 10, overflow: 'hidden', paddingVertical: 6 },
  opt: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#2A2A2D' },
  optActive: { backgroundColor: '#2A4060' },
  optText: { color: '#fff', fontSize: 14 },
  optTextActive: { fontWeight: '700' },
});
function StepCard({ p, number, numbers, depth, onUpdate, onMenu, zones }) {
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const inputStyle = [st.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }];
  const zonaOptions = (tipo) => {
    if (tipo === 'Zona FC') return zones.fc;
    if (tipo === 'Zona ritmo') return zones.ritmo;
    if (tipo === 'Zona potencia') return zones.pot;
    return [];
  };
  return (
    <View style={[st.card, { backgroundColor: theme.card, borderColor: theme.border }, depth > 0 && st.cardChild]}>
      <View style={st.cardHeader}>
        <Text style={[st.cardTitle, { color: theme.text }]}>{L('Paso','Step')} {number}</Text>
        <View style={{ flex: 1 }} />
        <TouchableOpacity onPress={() => onMenu(p.id)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Ionicons name="ellipsis-horizontal" size={18} color={theme.muted} />
        </TouchableOpacity>
      </View>
      <Text style={[st.label, { color: theme.muted }]}>{L('Tipo','Type')}</Text>
      <Picker value={p.tipo} options={TIPOS_PASO.map(k => ({ value: k, label: tipoLabel(k) }))} onChange={v => onUpdate(p.id, { tipo: v })} />
      <Text style={[st.label, { color: theme.muted }]}>{L('Duración','Duration')}</Text>
      <View style={st.row}>
        <View style={{ flex: 1 }}>
          <Picker value={p.durTipo} options={DUR_TYPES.map(k => ({ value: k, label: durLabel(k) }))} onChange={v => onUpdate(p.id, { durTipo: v })} />
        </View>
        {p.durTipo === 'Distancia' && (
          <View style={{ flex: 1 }}>
              <TextInput style={inputStyle} value={p.durValor ?? ''} onChangeText={t => onUpdate(p.id, { durValor: t, durTexto: t })} placeholder="0" placeholderTextColor="#4A6080" keyboardType="decimal-pad" />
          </View>
        )}
        {p.durTipo === 'Distancia' && (
          <View style={{ flex: 0.9 }}>
            <Picker value={p.durUnidad} options={UNIDADES_DIST} onChange={v => onUpdate(p.id, { durUnidad: v })} />
          </View>
        )}
        {p.durTipo === 'Tiempo' && (
          <View style={{ flex: 1 }}>
            <TextInput
              style={inputStyle}
              value={p.durTexto ?? p.durValor ?? ''}
              onChangeText={t => {
                const mins = parseTimeToMinutes(t);
                onUpdate(p.id, { durTexto: t, durValor: mins != null ? String(mins) : '' });
              }}
              onBlur={() => {
                const raw = p.durTexto ?? p.durValor ?? '';
                const fmt = formatTimeInput(raw);
                if (fmt != null) {
                  const mins = parseTimeToMinutes(fmt);
                  onUpdate(p.id, { durTexto: fmt, durValor: mins != null ? String(mins) : '' });
                }
              }}
              placeholder="hh:mm:ss"
              placeholderTextColor="#4A6080"
              keyboardType="numbers-and-punctuation"
            />
          </View>
        )}
        {p.durTipo === 'Botón de vuelta' && (
          <View style={{ flex: 1 }}>
              <TextInput style={inputStyle} value={p.durValor ?? ''} onChangeText={t => onUpdate(p.id, { durValor: t, durTexto: t })} placeholder="100" placeholderTextColor="#4A6080" keyboardType="decimal-pad" />
          </View>
        )}
        {p.durTipo === 'Botón de vuelta' && (
          <View style={{ flex: 0.9 }}>
            <Picker value={p.durUnidad} options={UNIDADES_DIST} onChange={v => onUpdate(p.id, { durUnidad: v })} />
          </View>
        )}
      </View>
      {p.durTipo === 'Botón de vuelta' && (
        <Text style={st.hint}>{L('El paso termina al pulsar el botón de vuelta. Pon la distancia orientativa (ej: 100 m): sin ella Garmin descarta el paso.','The step ends when you press the lap button. Set the reference distance (e.g. 100 m): without it Garmin drops the step.')}</Text>
      )}
      <Text style={[st.label, { color: theme.muted }]}>{L('Repeticiones (veces que se repite)','Repetitions (times repeated)')}</Text>
      <View style={st.row}>
        <View style={{ flex: 1 }}>
          <TextInput style={inputStyle} value={p.repeticiones ?? '1'} onChangeText={t => onUpdate(p.id, { repeticiones: t })} placeholder="1" placeholderTextColor="#4A6080" keyboardType="numeric" />
        </View>
      </View>
      <Text style={[st.label, { color: theme.muted }]}>{L('Objetivo','Target')}</Text>
      <Picker
        value={p.objetivo || ''}
        options={[{ value: '', label: L('Sin objetivo','No target') }, ...OBJETIVOS.map(k => ({ value: k, label: objLabel(k) }))]}
        onChange={v => onUpdate(p.id, { objetivo: v })}
        placeholder={L('Sin objetivo','No target')}
      />
      {p.objetivo === 'Ritmo' && (
        <View style={st.row}>
          <View style={{ flex: 1 }}>
            <Text style={st.labelSmall}>{L('Ritmo mín','Min pace')}</Text>
            <TextInput style={inputStyle} value={p.objMin ?? ''} onChangeText={t => onUpdate(p.id, { objMin: t })} placeholder="4:30" placeholderTextColor="#4A6080" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={st.labelSmall}>{L('Ritmo máx','Max pace')}</Text>
            <TextInput style={inputStyle} value={p.objMax ?? ''} onChangeText={t => onUpdate(p.id, { objMax: t })} placeholder="4:00" placeholderTextColor="#4A6080" />
          </View>
        </View>
      )}
      {(p.objetivo === 'FC media' || p.objetivo === 'Potencia' || p.objetivo === 'Elevación' || p.objetivo === 'Cadencia') && (
        <View style={st.row}>
          <View style={{ flex: 1 }}>
            <Text style={st.labelSmall}>{L('Mín','Min')}</Text>
            <TextInput style={inputStyle} value={p.objMin ?? ''} onChangeText={t => onUpdate(p.id, { objMin: t })} placeholder="0" placeholderTextColor="#4A6080" keyboardType="numeric" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={st.labelSmall}>{L('Máx','Max')}</Text>
            <TextInput style={inputStyle} value={p.objMax ?? ''} onChangeText={t => onUpdate(p.id, { objMax: t })} placeholder="0" placeholderTextColor="#4A6080" keyboardType="numeric" />
          </View>
        </View>
      )}
      {(p.objetivo === 'Zona FC' || p.objetivo === 'Zona potencia' || p.objetivo === 'Zona ritmo') && (
        <Picker value={p.objZona} options={zonaOptions(p.objetivo)} onChange={v => onUpdate(p.id, { objZona: v })} placeholder={L('Escoge zona','Pick zone')} />
      )}
      {p.objetivo === 'Intensidad' && (
        <Picker value={p.objMin ? String(p.objMin) : ''} options={['1','2','3','4','5','6','7','8','9','10']} onChange={v => onUpdate(p.id, { objMin: v })} placeholder={L('1 a 10','1 to 10')} />
      )}
      {(p.hijos || []).length > 0 && (
        <View style={st.childrenWrap}>
          {p.hijos.map(h => (
            <StepCard key={h.id} p={h} number={numbers[h.id]} numbers={numbers} depth={depth + 1} onUpdate={onUpdate} onMenu={onMenu} zones={zones} />
          ))}
        </View>
      )}
    </View>
  );
}
export default function StepEditor({ pasos, setPasos, profileUid, actividad }) {
  const settings = useAppSettings(); // re-renderiza al cambiar idioma/tema
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const [menuId, setMenuId] = useState(null);
  const [zones, setZones] = useState({ fc: ['Z1','Z2','Z3','Z4','Z5'], ritmo: ['R1','R2','R3','R4','R5'], pot: ['Z1','Z2','Z3','Z4','Z5','Z6','Z7'] });
  useEffect(() => {
    (async () => {
      try {
        const uid = profileUid || auth.currentUser?.uid;
        if (!uid) return;
        const prof = await getCachedProfile(uid);
        if (!prof) return;
        const lbl = (arr, pref) => (arr || []).map((z, i) => z.titulo || z.label || `${pref}${i + 1}`);
        setZones({
          fc: lbl(prof.zonasFC, 'Z').length ? lbl(prof.zonasFC, 'Z') : ['Z1','Z2','Z3','Z4','Z5'],
          ritmo: lbl(prof.zonasRitmo, 'R').length ? lbl(prof.zonasRitmo, 'R') : ['R1','R2','R3','R4','R5'],
          pot: lbl(prof.zonasPotencia, 'Z').length ? lbl(prof.zonasPotencia, 'Z') : ['Z1','Z2','Z3','Z4','Z5','Z6','Z7'],
        });
      } catch (e) {}
    })();
  }, [profileUid, actividad]);
  const numbers = useMemoNumbers(pasos);
  const onUpdate = (id, patch) => setPasos(list => mapTree(list, id, p => ({ ...p, ...patch })));
  const onMenu = (id) => setMenuId(id);
  const menuAction = (action) => {
    const id = menuId;
    setMenuId(null);
    if (!id) return;
    if (action === 'reps') onUpdate(id, { repeticiones: '2' });
    if (action === 'dup') {
      setPasos(list => {
        const orig = findInTree(list, id);
        return orig ? insertAfter(list, id, deepCopy(orig)) : list;
      });
    }
    if (action === 'add') setPasos(list => addChild(list, id, emptyStep()));
    if (action === 'del') setPasos(list => removeFromTree(list, id));
  };
  return (
    <View>
      {pasos.map(p => (
        <StepCard key={p.id} p={p} number={numbers[p.id]} numbers={numbers} depth={0} onUpdate={onUpdate} onMenu={onMenu} zones={zones} />
      ))}
      <TouchableOpacity style={st.addBtn} onPress={() => setPasos([...pasos, emptyStep()])}>
        <Ionicons name="add-circle" size={20} color={BLUE} />
        <Text style={st.addBtnText}>{L('Añadir paso','Add Step')}</Text>
      </TouchableOpacity>
      <Modal visible={menuId != null} transparent animationType="fade" onRequestClose={() => setMenuId(null)}>
        <TouchableOpacity style={[pk.overlay, { backgroundColor: theme.overlay }]} activeOpacity={1} onPress={() => setMenuId(null)}>
          <View style={[pk.box, { backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border }]}>
            {[
              { k: 'reps', label: L('Añadir repetición','Add repetition'), icon: 'repeat' },
              { k: 'dup', label: L('Duplicar paso','Duplicate Step'), icon: 'copy-outline' },
              { k: 'add', label: L('Añadir paso (dentro del bucle)','Add Step (inside loop)'), icon: 'add' },
              { k: 'del', label: L('Eliminar paso','Delete Step'), icon: 'trash' },
            ].map(o => (
              <TouchableOpacity key={o.k} style={[pk.opt, { borderBottomColor: theme.border }]} onPress={() => menuAction(o.k)}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <Ionicons name={o.icon} size={17} color={o.k === 'del' ? RED : theme.muted} />
                  <Text style={[pk.optText, { color: o.k === 'del' ? RED : theme.text }]}>{o.label}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
        <SystemBars />
      </Modal>
    </View>
  );
}
function useMemoNumbers(list) {
  const map = {};
  let n = 1;
  const walk = (arr) => (arr || []).forEach(p => { map[p.id] = n++; walk(p.hijos); });
  walk(list);
  return map;
}
const st = StyleSheet.create({
  card: { backgroundColor: CARD, borderRadius: 10, borderWidth: 1, borderColor: BORDER, padding: 12, marginBottom: 10, gap: 6 },
  cardChild: { marginLeft: 14, borderLeftWidth: 2, borderLeftColor: BLUE + '66' },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  cardTitle: { color: '#fff', fontWeight: '700', fontSize: 14 },
  label: { color: '#8FA8C8', fontSize: 12, marginTop: 4 },
  labelSmall: { color: '#8FA8C8', fontSize: 11, marginBottom: 2 },
  hint: { color: '#5A708C', fontSize: 10, lineHeight: 14 },
  row: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  input: { backgroundColor: NAVY, borderRadius: 6, borderWidth: 1, borderColor: BORDER, paddingHorizontal: 10, paddingVertical: 9, color: '#fff', fontSize: 13 },
  childrenWrap: { marginTop: 6, gap: 6 },
  addBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, padding: 10, borderWidth: 1, borderColor: BORDER, borderStyle: 'dashed', borderRadius: 10 },
  addBtnText: { color: BLUE, fontWeight: '600' },
});
