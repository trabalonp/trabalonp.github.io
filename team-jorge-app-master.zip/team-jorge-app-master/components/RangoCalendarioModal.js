// components/RangoCalendarioModal.js
// ─────────────────────────────────────────────────────────────
// Calendario de RANGO de fechas para los retos (SocialScreen).
// Mismo diseño que MonthPickerModal (rejilla mensual empezando en
// lunes, ruleta mes/año al tocar el título, flechas ‹ ›), pero aquí
// se tocan DOS días: el primero fija el inicio y el segundo el fin
// (máx. 2 toques: si hay rango completo, el siguiente toque empieza
// otro). Los días intermedios se pintan con una banda azul que une
// inicio y fin; si el segundo toque es anterior al primero, ese día
// pasa a ser el inicio. Ok devuelve { a, b } (Dates a medianoche) o
// nada si el rango está incompleto.
// ─────────────────────────────────────────────────────────────
import React, { useEffect, useMemo, useState } from 'react';
import {
  Modal, ScrollView, StyleSheet, Text, TouchableOpacity, View, useColorScheme,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getThemeColors, useAppSettings, locale, L } from '../services/appSettings';
import { Wheel } from './MonthPickerModal';

const BLUE = '#4A90E2';

function monthName(m, loc) {
  return new Date(2026, m, 1).toLocaleDateString(loc, { month: 'long' });
}
function daysInMonth(y, m) {
  return new Date(y, m + 1, 0).getDate();
}
const diaKey = (d) => {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};
const mismoDia = (d1, d2) => !!(d1 && d2 && diaKey(d1) === diaKey(d2));

export default function RangoCalendarioModal({ visible, onClose, onOk, inicial }) {
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const loc = locale();

  const [view, setView] = useState('days'); // 'days' | 'wheel'
  const [viewYear, setViewYear] = useState(new Date().getFullYear());
  const [viewMonth, setViewMonth] = useState(new Date().getMonth());
  const [a, setA] = useState(null);   // día de inicio (00:00 local)
  const [b, setB] = useState(null);   // día de fin (00:00 local)

  // Al abrir: centrado en el mes del rango actual (o del mes en curso) y
  // con la selección que ya hubiera en el formulario.
  useEffect(() => {
    if (!visible) return;
    const ref = (inicial && (inicial.a || inicial.b)) || new Date();
    setView('days');
    setViewYear(ref.getFullYear());
    setViewMonth(ref.getMonth());
    setA(inicial?.a || null);
    setB(inicial?.b || null);
  }, [visible]);

  const years = useMemo(() => {
    const now = new Date().getFullYear();
    const out = [];
    for (let y = now - 6; y <= now + 6; y++) out.push(y);
    return out;
  }, []);
  const months = useMemo(
    () => Array.from({ length: 12 }, (_, m) => monthName(m, loc)),
    [loc]
  );
  const weekHeaders = useMemo(
    () => Array.from({ length: 7 }, (_, i) =>
      new Date(2021, 0, 4 + i).toLocaleDateString(loc, { weekday: 'short' }).toUpperCase()
    ),
    [loc]
  );

  const dim = daysInMonth(viewYear, viewMonth);
  const firstOffset = (new Date(viewYear, viewMonth, 1).getDay() + 6) % 7; // lunes = 0
  const cells = [];
  for (let i = 0; i < firstOffset; i++) cells.push(null);
  for (let d = 1; d <= dim; d++) cells.push(new Date(viewYear, viewMonth, d));

  const changeMonth = (dir) => {
    let m = viewMonth + dir;
    let y = viewYear;
    if (m < 0) { m = 11; y--; }
    if (m > 11) { m = 0; y++; }
    setViewMonth(m);
    setViewYear(y);
  };

  // Máx. 2 toques: sin inicio → fija inicio · con inicio y sin fin → fija fin
  // (o deshace si es el mismo día, o pasa a ser inicio si es anterior) ·
  // con rango completo → se empieza de nuevo con el día tocado.
  const tocar = (d) => {
    if (!a || (a && b)) { setA(d); setB(null); return; }
    if (mismoDia(d, a)) { setA(null); setB(null); return; }
    if (d < a) { setA(d); return; }
    setB(d);
  };

  const celda = (d, i) => {
    if (d == null) return <View key={`b${i}`} style={st.dayCell} />;
    const esA = mismoDia(d, a);
    const esB = mismoDia(d, b);
    const entre = !!(a && b && d > a && d < b);
    const banda = (esA && !!b) || esB || entre;
    return (
      <View key={diaKey(d)} style={st.dayCell}>
        {banda && (
          <View
            pointerEvents="none"
            style={[
              st.banda,
              esA ? { left: '50%' } : esB ? { right: '50%' } : null,
              { backgroundColor: BLUE + (entre ? '40' : '55') },
            ]}
          />
        )}
        <TouchableOpacity style={st.dayBtn} onPress={() => tocar(d)} activeOpacity={0.7}>
          <View style={[st.dayCircle, (esA || esB) && st.dayCircleSel]}>
            <Text style={[st.dayText, { color: esA || esB ? '#FFFFFF' : theme.text }]}>
              {d.getDate()}
            </Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  const title = `${monthName(viewMonth, loc)} de ${viewYear}`;
  const completo = !!(a && b);

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={st.overlay}>
        <View style={[st.card, { backgroundColor: theme.card }]}>
          {/* ── Cabecera: título-ruleta + flechas de mes ── */}
          <View style={st.headerRow}>
            <TouchableOpacity
              style={st.titleBtn}
              onPress={() => setView(view === 'days' ? 'wheel' : 'days')}
              activeOpacity={0.7}
            >
              <Text style={[st.title, { color: theme.text }]} numberOfLines={1}>{title}</Text>
              <Ionicons name={view === 'days' ? 'chevron-down' : 'chevron-up'} size={18} color={BLUE} />
            </TouchableOpacity>
            {view === 'days' && (
              <View style={st.arrows}>
                <TouchableOpacity onPress={() => changeMonth(-1)} style={st.arrowBtn}>
                  <Ionicons name="chevron-back" size={22} color={BLUE} />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => changeMonth(1)} style={st.arrowBtn}>
                  <Ionicons name="chevron-forward" size={22} color={BLUE} />
                </TouchableOpacity>
              </View>
            )}
          </View>

          {view === 'wheel' ? (
            /* ── Ruletas de mes y año ── */
            <View style={st.wheelsRow}>
              <Wheel items={months} selected={viewMonth} onChange={(i) => setViewMonth(i)} theme={theme} />
              <Wheel
                items={years.map(String)}
                selected={Math.max(0, years.indexOf(viewYear))}
                onChange={(i) => setViewYear(years[i])}
                theme={theme}
              />
            </View>
          ) : (
            /* ── Rejilla de días del mes con banda de rango ── */
            <>
              <Text style={[st.hint, { color: theme.muted }]}>
                {L('Toca el día de inicio y el de fin.', 'Tap the start day and the end day.')}
              </Text>
              <View style={st.weekRow}>
                {weekHeaders.map((w, i) => (
                  <Text key={i} style={[st.weekCell, { color: theme.muted }]}>{w}</Text>
                ))}
              </View>
              <ScrollView style={st.gridScroll} showsVerticalScrollIndicator={false}>
                <View style={st.grid}>
                  {cells.map((d, i) => celda(d, i))}
                </View>
              </ScrollView>
            </>
          )}

          {/* ── Pie: Cerrar / Ok ── */}
          <View style={[st.footer, { borderTopColor: theme.border }]}>
            <TouchableOpacity style={st.footerBtn} onPress={onClose}>
              <Text style={[st.footerText, { color: BLUE }]}>{L('Cerrar', 'Close')}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[st.footerBtn, !completo && { opacity: 0.4 }]}
              disabled={!completo}
              onPress={() => onOk({ a, b })}
            >
              <Text style={[st.footerText, { color: BLUE, fontWeight: '800' }]}>{L('Ok', 'Ok')}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const st = StyleSheet.create({
  overlay: {
    flex: 1, backgroundColor: '#00000088',
    justifyContent: 'center', alignItems: 'center', padding: 24,
  },
  card: { width: '100%', maxWidth: 420, borderRadius: 16, overflow: 'hidden', paddingBottom: 6 },
  headerRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 14, paddingBottom: 6, gap: 8,
  },
  titleBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1 },
  title: { fontSize: 18, fontWeight: '800' },
  arrows: { flexDirection: 'row', gap: 12 },
  arrowBtn: { padding: 4 },
  // Ruleta
  wheelsRow: { flexDirection: 'row', paddingHorizontal: 10, paddingVertical: 10, height: 220 },
  // Rejilla de días
  hint: { fontSize: 12, paddingHorizontal: 16, paddingBottom: 4 },
  weekRow: { flexDirection: 'row', paddingHorizontal: 10, paddingBottom: 2 },
  weekCell: { flex: 1, textAlign: 'center', fontSize: 11, fontWeight: '700' },
  gridScroll: { maxHeight: 300 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 10, paddingBottom: 10 },
  dayCell: { width: '14.285%', height: 44, alignItems: 'center', justifyContent: 'center' },
  dayBtn: { width: '100%', height: '100%', alignItems: 'center', justifyContent: 'center' },
  banda: { position: 'absolute', left: 0, right: 0, top: '50%', height: 26, marginTop: -13 },
  dayCircle: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  dayCircleSel: { backgroundColor: BLUE },
  dayText: { fontSize: 16, fontWeight: '600' },
  // Pie
  footer: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    borderTopWidth: 1, paddingHorizontal: 8, paddingTop: 2, marginTop: 2,
  },
  footerBtn: { padding: 12, paddingHorizontal: 18 },
  footerText: { fontSize: 16, fontWeight: '600' },
});
