// components/LibreriaDrive.js
// ─────────────────────────────────────────────────────────────
// LIBRERÍA TIPO DRIVE, LOCAL-FIRST (compartida por AddWorkoutModal y
// WorkoutDetailModal). Igual que el chat de SocialScreen:
//   · Sesiones y carpetas viven en services/libreriaStore.js (AsyncStorage
//     por usuario): al abrir se pinta el almacén AL INSTANTE, sin red.
//   · Un listener EN VIVO (onSnapshot, igualdad por userId → índice
//     automático, sin índices compuestos) mantiene el almacén al día con
//     DELTAS: added/modified → upsert, removed → baja local. Nunca se
//     re-leen "todos los ítems" en cada apertura.
//   · El listado procedural (15 en 15) se pagina EN CLIENTE desde el
//     almacén: abrir, buscar, contar o mover no gastan lecturas.
//   · Carpetas anidadas: docs con esCarpeta:true; los entrenos llevan
//     `carpeta` (id|null = raíz; los antiguos sin el campo son raíz).
//   · onLoad(item) = usar (el host cuenta el uso) · onEdit(item) = editar
//     (NO cuenta uso) · onAdd() = botón +.
//   · PickerCarpetaLibreria: selector de carpeta destino reutilizable por
//     los hosts ("añadir a librería" pregunta dónde guardarla).
// ─────────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator, Alert, FlatList, Modal, StyleSheet, Text,
  TextInput, TouchableOpacity, View, useColorScheme,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import {
  addDoc, collection, deleteDoc, doc, getDocs, onSnapshot,
  query, Timestamp, updateDoc, where,
} from 'firebase/firestore';
import { auth, db } from '../firebaseConfig';
import { getThemeColors, useAppSettings, L } from '../services/appSettings';
import { libreriaStoreAll, libreriaStoreInit, libreriaStorePut, libreriaStoreRemove } from '../services/libreriaStore';
import ActivityIcon, { TIPO_COLOR } from './ActivityIcon';

const PAGE = 15;
const BLUE = '#4A90E2';
const RED = '#E05252';

// "22/09/2026 6:48 pm" — fecha y hora de creación de una sesión
function fmtFechaHora(d) {
  if (!d) return '';
  const p = (n) => String(n).padStart(2, '0');
  const suf = d.getHours() < 12 ? 'am' : 'pm';
  const h = d.getHours() % 12 || 12;
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${h}:${p(d.getMinutes())} ${suf}`;
}


export default function LibreriaDrive({ onLoad, onEdit, onAdd }) {
  const settings = useAppSettings(); // re-renderiza al cambiar idioma/tema
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const uid = auth.currentUser?.uid;

  const [dir, setDir] = useState(null);            // carpeta actual: { id, nombre } | null = raíz
  const [docs, setDocs] = useState([]);            // TODO el almacén local (sesiones + carpetas)
  const [numMostradas, setNumMostradas] = useState(PAGE); // paginación EN CLIENTE
  const [sincronizando, setSincronizando] = useState(true); // primera carga del listener
  const [sort, setSort] = useState('usados');
  const [sortOpen, setSortOpen] = useState(false);
  const [buscaAbierto, setBuscaAbierto] = useState(false);
  const [buscar, setBuscar] = useState('');
  const [menu, setMenu] = useState(null);          // { tipo: 'item'|'carpeta', obj }
  const [prompt, setPrompt] = useState(null);      // { titulo, onOk }
  const [promptTxt, setPromptTxt] = useState('');
  const [mover, setMover] = useState(null);        // { tipo, obj } en tránsito

  // ── Almacén local AL INSTANTE + listener EN VIVO (deltas, como el chat) ──
  useEffect(() => {
    if (!uid) return undefined;
    let vivo = true;
    setSincronizando(true);
    (async () => {
      await libreriaStoreInit(uid);
      if (!vivo) return;
      setDocs(await libreriaStoreAll());   // pinta la caché sin red
      setSincronizando(false);
    })();
    // Listener en vivo: added/modified → upsert en el almacén; removed → baja.
    // Solo entran deltas (docChanges), nunca re-lecturas completas.
    const unsub = onSnapshot(
      query(collection(db, 'libreria'), where('userId', '==', uid)),
      (snap) => {
        const up = [];
        const fuera = [];
        snap.docChanges().forEach((ch) => {
          if (ch.type === 'removed' && !ch.doc.exists()) fuera.push(ch.doc.id);
          else up.push({ id: ch.doc.id, ...ch.doc.data() });
        });
        (async () => {
          if (up.length) await libreriaStorePut(up);
          if (fuera.length) await libreriaStoreRemove(fuera);
          if (vivo) setDocs(await libreriaStoreAll());
        })();
      },
      (e) => console.warn('[libreriaDrive] listener:', e.message),
    );
    return () => { vivo = false; unsub(); };
  }, [uid]);

  const refresca = async () => setDocs(await libreriaStoreAll());

  // ── Derivados del almacén (sin ninguna lectura a Firestore) ──
  const aMillis = (x) => x?.createdAt?.toMillis?.() ?? 0;
  const idActual = dir ? dir.id : null;

  const carpetasDelDir = useMemo(() => {
    const delDir = docs.filter((c) => c.esCarpeta && (c.carpeta ?? null) === idActual);
    // Las carpetas también se ordenan según el filtro elegido (sin info extra).
    if (sort === 'recientes') delDir.sort((a, b) => aMillis(b) - aMillis(a));
    else delDir.sort((a, b) => String(a.nombre || '').localeCompare(String(b.nombre || '')));
    return delDir;
  }, [docs, idActual, sort]);

  const itemsDelDir = useMemo(
    () => docs.filter((x) => !x.esCarpeta && (x.carpeta ?? null) === idActual),
    [docs, idActual],
  );

  // Recuento de ÍTEMS directos por carpeta: derivado del almacén (0 lecturas).
  const recuentos = useMemo(() => {
    const out = {};
    for (const d of docs) if (d.esCarpeta) out[d.id] = 0;
    for (const x of docs) {
      if (!x.esCarpeta && x.carpeta != null && out[x.carpeta] != null) out[x.carpeta] += 1;
    }
    return out;
  }, [docs]);

  const aMillis2 = (x) => x?.createdAt?.toMillis?.() ?? 0;
  const ordenarItems = (lista) => {
    const copia = [...lista];
    if (sort === 'recientes') copia.sort((a, b) => aMillis2(b) - aMillis2(a));
    else copia.sort((a, b) => (b.timesUsed ?? 0) - (a.timesUsed ?? 0) || aMillis2(a) - aMillis2(b));
    return copia;
  };

  // Búsqueda por nombre: instantánea, sobre el almacén (0 lecturas).
  const resultadosBusq = useMemo(() => {
    const texto = buscaAbierto ? buscar.trim().toLowerCase() : '';
    if (!texto) return null;
    return itemsDelDir.filter((x) => (x.titulo || x.tipo || '').toLowerCase().includes(texto));
  }, [buscaAbierto, buscar, itemsDelDir]);

  // Listado completo del directorio (carpetas + ítems ya ordenados)…
  const datos = useMemo(() => [
    ...(resultadosBusq != null ? [] : carpetasDelDir.map((c) => ({ key: `c${c.id}`, tipo: 'carpeta', obj: c }))),
    ...ordenarItems(resultadosBusq != null ? resultadosBusq : itemsDelDir)
      .map((x) => ({ key: `i${x.id}`, tipo: 'item', obj: x })),
  ], [resultadosBusq, carpetasDelDir, itemsDelDir, sort]);

  // …y paginación procedural EN CLIENTE: 15 y 15, sin tocar la base de datos.
  const visibles = useMemo(
    () => (resultadosBusq != null ? datos : datos.slice(0, numMostradas)),
    [datos, numMostradas, resultadosBusq],
  );

  // ── Acciones (Firestore + reflejo inmediato en el almacén local) ──
  const crearCarpeta = async (nombre) => {
    if (!uid || !nombre.trim()) return;
    try {
      const ref = await addDoc(collection(db, 'libreria'), {
        userId: uid, esCarpeta: true, nombre: nombre.trim(),
        carpeta: dir ? dir.id : null, createdAt: Timestamp.now(),
      });
      await libreriaStorePut({ id: ref.id, userId: uid, esCarpeta: true, nombre: nombre.trim(), carpeta: dir ? dir.id : null, createdAt: Timestamp.now() });
      await refresca();
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };

  const renombrarCarpeta = async (c, nombre) => {
    if (!nombre.trim()) return;
    try {
      await updateDoc(doc(db, 'libreria', c.id), { nombre: nombre.trim() });
      await libreriaStorePut({ ...c, nombre: nombre.trim() });
      await refresca();
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };

  const eliminarCarpeta = (c) => {
    Alert.alert(L('Eliminar carpeta', 'Delete folder'), L(`¿Eliminar la carpeta "${c.nombre}"?`, `Delete folder "${c.nombre}"?`), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: async () => {
        // Vacía = ningún doc (ítem o subcarpeta) cuelga de ella: 0 lecturas.
        const hayDentro = docs.some((x) => (x.carpeta ?? null) === c.id);
        if (hayDentro) {
          Alert.alert(L('Carpeta no vacía', 'Folder not empty'), L('Vacía la carpeta antes de eliminarla (mueve o borra lo que contiene).', 'Empty the folder before deleting it (move or delete its contents).'));
          return;
        }
        try {
          await deleteDoc(doc(db, 'libreria', c.id));
          await libreriaStoreRemove(c.id);
          await refresca();
        } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
      } },
    ]);
  };

  const moverA = async (destino) => {
    if (!mover) return;
    const destinoId = destino ? destino.id : null;
    if (destinoId === (mover.obj.carpeta ?? null)) { setMover(null); return; }
    // Una carpeta no puede moverse dentro de sí misma ni de sus hijas.
    if (mover.tipo === 'carpeta') {
      let aux = destino;
      while (aux) {
        if (aux.id === mover.obj.id) { Alert.alert(L('Movimiento no válido', 'Invalid move'), L('No puedes mover una carpeta dentro de sí misma.', 'You cannot move a folder into itself.')); return; }
        aux = docs.find((x) => x.esCarpeta && x.id === (aux.carpeta ?? null)) || null;
      }
    }
    try {
      await updateDoc(doc(db, 'libreria', mover.obj.id), { carpeta: destinoId });
      await libreriaStorePut({ ...mover.obj, carpeta: destinoId });
      await refresca();
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
    finally { setMover(null); }
  };

  const eliminarItem = (item) => {
    Alert.alert(L('Eliminar de la librería', 'Delete from library'), L(`¿Eliminar "${item.titulo || item.tipo}"?`, `Delete "${item.titulo || item.tipo}"?`), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: async () => {
        try {
          await deleteDoc(doc(db, 'libreria', item.id));
          await libreriaStoreRemove(item.id);
          await refresca();
        } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
      } },
    ]);
  };

  // Camino de carpetas hasta un id (para las migas del selector de mover).
  const caminoDe = (id) => {
    const tramo = [];
    const listaCarp = docs.filter((x) => x.esCarpeta);
    let aux = id ? listaCarp.find((c) => c.id === id) || null : null;
    while (aux) { tramo.unshift(aux); aux = aux.carpeta ? listaCarp.find((c) => c.id === aux.carpeta) || null : null; }
    return tramo;
  };
  // ── Filas ──
  const filaItem = (obj) => (
    <TouchableOpacity style={[st.fila, { backgroundColor: theme.card, borderColor: theme.border }]}
      onPress={() => onLoad(obj)}
      onLongPress={() => setMenu({ tipo: 'item', obj })}
      delayLongPress={300}
      activeOpacity={0.8}>
      <ActivityIcon tipo={obj.tipo} size={20} color={TIPO_COLOR[obj.tipo] ?? '#8FA8C8'} />
      <View style={{ flex: 1 }}>
        <Text style={[st.filaTitulo, { color: theme.text }]} numberOfLines={2}>{obj.titulo || obj.tipo}</Text>
        <Text style={[st.filaMeta, { color: theme.muted }]}>
          {sort === 'recientes' ? fmtFechaHora(aMillis(obj) ? new Date(aMillis(obj)) : null)
            : L(`Usada ${obj.timesUsed ?? 0} ${(obj.timesUsed ?? 0) === 1 ? 'vez' : 'veces'}`, `Used ${obj.timesUsed ?? 0} ${(obj.timesUsed ?? 0) === 1 ? 'time' : 'times'}`)}
        </Text>
      </View>
      <Ionicons name="ellipsis-horizontal" size={16} color={theme.muted} />
    </TouchableOpacity>
  );

  const filaCarpeta = (obj) => (
    <TouchableOpacity style={[st.fila, st.filaCarpeta, { backgroundColor: theme.card, borderColor: theme.border }]}
      onPress={() => { setBuscaAbierto(false); setBuscar(''); setDir({ id: obj.id, nombre: obj.nombre }); }}
      onLongPress={() => setMenu({ tipo: 'carpeta', obj })}
      delayLongPress={300}
      activeOpacity={0.8}>
      <Ionicons name="folder" size={22} color={BLUE} />
      <View style={{ flex: 1 }}>
        <Text style={[st.filaTitulo, { color: theme.text }]} numberOfLines={2}>{obj.nombre}</Text>
        <Text style={[st.filaMeta, { color: theme.muted }]}>
          {recuentos[obj.id] != null
            ? L(`${recuentos[obj.id]} ${recuentos[obj.id] === 1 ? 'ítem' : 'ítems'}`, `${recuentos[obj.id]} ${recuentos[obj.id] === 1 ? 'item' : 'items'}`)
            : L('Carpeta', 'Folder')}
        </Text>
      </View>
      <Ionicons name="chevron-forward" size={16} color={theme.muted} />
    </TouchableOpacity>
  );

  const renderItem = ({ item }) => (item.tipo === 'carpeta' ? filaCarpeta(item.obj) : filaItem(item.obj));

  const abrirPrompt = (titulo, inicial, onOk) => { setPromptTxt(inicial || ''); setPrompt({ titulo, onOk }); };

  return (
    <View style={{ flex: 1 }}>
      {/* ── Barra de navegación de la librería ── */}
      <View style={st.barra}>
        <TouchableOpacity style={[st.barraBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => { setBuscaAbierto(false); setBuscar(''); setDir(null); }}>
          <Ionicons name="home-outline" size={19} color={BLUE} />
        </TouchableOpacity>
        <TouchableOpacity style={[st.barraBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={onAdd}>
          <Ionicons name="add-circle-outline" size={20} color={BLUE} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[st.barraBtn, { backgroundColor: theme.card, borderColor: theme.border }]}
          onPress={() => abrirPrompt(L('Nueva carpeta', 'New folder'), '', crearCarpeta)}
        >
          <Ionicons name="folder-open-outline" size={19} color={BLUE} />
        </TouchableOpacity>
        <TouchableOpacity style={[st.barraBtn, { backgroundColor: theme.card, borderColor: theme.border }]} onPress={() => setSortOpen(true)}>
          <MaterialCommunityIcons name="sort-descending" size={20} color={BLUE} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[st.barraBtn, { backgroundColor: theme.card, borderColor: theme.border }, buscaAbierto && st.barraBtnActivo]}
          onPress={() => { setBuscaAbierto(!buscaAbierto); setBuscar(''); }}
        >
          <Ionicons name="search-outline" size={19} color={BLUE} />
        </TouchableOpacity>
      </View>

      {/* ── Migas: solo cuando estás dentro de una carpeta ── */}
      {dir && (
        <View style={st.migas}>
          <TouchableOpacity onPress={() => { setBuscaAbierto(false); setBuscar(''); setDir(null); }}>
            <Text style={[st.miga, { color: theme.muted }]}>{L('Sesiones', 'Sessions')}</Text>
          </TouchableOpacity>
          <Text style={[st.miga, { color: theme.muted }]}> › </Text>
          <Text style={[st.miga, { color: BLUE }]} numberOfLines={1}>{dir.nombre}</Text>
        </View>
      )}

      {/* ── Buscador (aparece al pulsar la lupita) ── */}
      {buscaAbierto && (
        <View style={[st.buscaCaja, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <Ionicons name="search-outline" size={16} color="#8FA8C8" />
          <TextInput
            style={[st.buscaInput, { color: theme.text }]}
            value={buscar}
            onChangeText={setBuscar}
            placeholder={L('Buscar por nombre...', 'Search by name...')}
            placeholderTextColor="#4A6080"
            autoFocus
          />
          <TouchableOpacity onPress={() => setBuscar('')}>
            <Ionicons name="close-circle" size={16} color="#8FA8C8" />
          </TouchableOpacity>
        </View>
      )}

      {/* ── Listado ── */}
      {sincronizando && docs.length === 0 ? (
        <View style={st.vacio}><ActivityIndicator color={BLUE} /></View>
      ) : (
        <FlatList
          data={visibles}
          renderItem={renderItem}
          contentContainerStyle={{ padding: 12, gap: 8 }}
          onEndReached={() => { if (numMostradas < datos.length) setNumMostradas((n) => n + PAGE); }}
          onEndReachedThreshold={0.25}
          ListFooterComponent={null}
          ListEmptyComponent={(
            <View style={st.vacio}>
              <Ionicons name="library-outline" size={32} color="#2A4060" />
              <Text style={[st.vacioTxt, { color: theme.muted }]}>
                {buscaAbierto && buscar.trim()
                  ? L('Sin resultados para esa búsqueda.', 'No results for that search.')
                  : !dir
                    ? L('Tu librería está vacía.', 'Your library is empty.')
                    : L('Esta carpeta está vacía.', 'This folder is empty.')}
              </Text>
            </View>
          )}
        />
      )}

      {/* ── Menú de pulsación larga ── */}
      <Modal visible={!!menu} transparent animationType="fade" onRequestClose={() => setMenu(null)}>
        <TouchableOpacity style={st.ov} activeOpacity={1} onPress={() => setMenu(null)}>
          <TouchableOpacity activeOpacity={1} onPress={() => {}} style={[st.caja, { backgroundColor: theme.card }]}>
            {(menu ? (menu.tipo === 'item' ? [
              { k: 'editar', icono: 'create-outline', color: theme.text, txt: L('Editar', 'Edit'), fn: () => { const m = menu; setMenu(null); if (onEdit) onEdit(m.obj); } },
              { k: 'mover', icono: 'folder-open-outline', color: theme.text, txt: L('Mover a carpeta', 'Move to folder'), fn: () => { const m = menu; setMenu(null); setMover(m); } },
              { k: 'del', icono: 'trash-outline', color: RED, txt: L('Eliminar', 'Delete'), fn: () => { const m = menu; setMenu(null); eliminarItem(m.obj); } },
            ] : [
              { k: 'renombrar', icono: 'create-outline', color: theme.text, txt: L('Renombrar', 'Rename'), fn: () => { const m = menu; setMenu(null); abrirPrompt(L('Renombrar carpeta', 'Rename folder'), m.obj.nombre, (t) => renombrarCarpeta(m.obj, t)); } },
              { k: 'del', icono: 'trash-outline', color: RED, txt: L('Eliminar', 'Delete'), fn: () => { const m = menu; setMenu(null); eliminarCarpeta(m.obj); } },
            ]) : []).map((o) => (
              <TouchableOpacity key={o.k} style={st.menuFila} onPress={o.fn}>
                <Ionicons name={o.icono} size={17} color={o.color} />
                <Text style={[st.menuTxt, { color: o.color }]}>{o.txt}</Text>
              </TouchableOpacity>
            ))}
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      {/* ── Selector de orden (tres rayas) ── */}
      <Modal visible={sortOpen} transparent animationType="fade" onRequestClose={() => setSortOpen(false)}>
        <TouchableOpacity style={st.ov} activeOpacity={1} onPress={() => setSortOpen(false)}>
          <TouchableOpacity activeOpacity={1} onPress={() => {}} style={[st.caja, { backgroundColor: theme.card }]}>
            {[
              { k: 'usados', txt: L('Más usados', 'Most used') },
              { k: 'recientes', txt: L('Más recientes', 'Most recent') },
            ].map((o) => (
              <TouchableOpacity key={o.k} style={st.menuFila} onPress={() => { setSort(o.k); setSortOpen(false); }}>
                <Text style={[st.menuTxt, { color: sort === o.k ? BLUE : theme.text }, sort === o.k && st.menuTxtActivo]}>{o.txt}</Text>
                {sort === o.k && <Ionicons name="checkmark" size={16} color={BLUE} />}
              </TouchableOpacity>
            ))}
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      {/* ── Prompt: crear / renombrar carpeta ── */}
      <Modal visible={!!prompt} transparent animationType="fade" onRequestClose={() => setPrompt(null)}>
        <TouchableOpacity style={st.ov} activeOpacity={1} onPress={() => setPrompt(null)}>
          <TouchableOpacity activeOpacity={1} onPress={() => {}} style={[st.caja, { backgroundColor: theme.card }]}>
            <Text style={[st.cajaTitulo, { color: theme.text }]}>{prompt?.titulo}</Text>
            <TextInput
              style={[st.promptInput, { color: theme.text, borderColor: theme.border, backgroundColor: theme.background }]}
              value={promptTxt}
              onChangeText={setPromptTxt}
              placeholder={L('Nombre de la carpeta', 'Folder name')}
              placeholderTextColor="#4A6080"
              autoFocus
            />
            <View style={{ flexDirection: 'row', justifyContent: 'flex-end', gap: 14, marginTop: 10 }}>
              <TouchableOpacity onPress={() => setPrompt(null)}>
                <Text style={[st.promptTxt, { color: BLUE }]}>{L('Cancelar', 'Cancel')}</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => { const fn = prompt?.onOk; const t = promptTxt; setPrompt(null); if (fn) fn(t); }}>
                <Text style={[st.promptTxt, { color: BLUE, fontWeight: '800' }]}>{L('Aceptar', 'OK')}</Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      {/* ── Selector de mover a carpeta ── */}
      <PickerCarpetaLibreria
        visible={!!mover}
        onClose={() => setMover(null)}
        onElegir={(id) => moverA(id ? docs.find((x) => x.esCarpeta && x.id === id) || null : null)}
        textoBoton={L('Mover aquí', 'Move here')}
        titulo={mover ? (mover.tipo === 'carpeta' ? L('Mover carpeta', 'Move folder') : L('Mover a carpeta', 'Move to folder')) : ''}
        subtitulo={mover ? (mover.obj.titulo || mover.obj.nombre) : ''}
        deshabilitadoSi={mover ? (mover.obj.carpeta ?? null) : undefined}
      />
    </View>
  );
}

// ─────────────────────────────────────────────────────────────
// Selector de carpeta DESTINO (drive navegable desde la raíz). Lo usan el
// mover de la propia librería y los hosts al "añadir a librería" para
// preguntar dónde guardar. onElegir(id|null) recibe la carpeta elegida.
// ─────────────────────────────────────────────────────────────
export function PickerCarpetaLibreria({ visible, onClose, onElegir, textoBoton, titulo, subtitulo, deshabilitadoSi }) {
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const uid = auth.currentUser?.uid;
  const [dir, setDir] = useState(null);
  const [carpetas, setCarpetas] = useState([]);

  useEffect(() => {
    if (!visible || !uid) return;
    setDir(null);
    (async () => {
      try {
        const snap = await getDocs(query(
          collection(db, 'libreria'),
          where('userId', '==', uid),
          where('esCarpeta', '==', true),
        ));
        setCarpetas(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      } catch (e) { setCarpetas([]); }
    })();
  }, [visible, uid]);

  const camino = (id) => {
    const tramo = [];
    let aux = id ? carpetas.find((c) => c.id === id) || null : null;
    while (aux) { tramo.unshift(aux); aux = aux.carpeta ? carpetas.find((c) => c.id === aux.carpeta) || null : null; }
    return tramo;
  };

  const hijas = carpetas.filter((c) => (c.carpeta ?? null) === (dir ? dir.id : null));
  const destinoId = dir ? dir.id : null;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <TouchableOpacity style={st.ov} activeOpacity={1} onPress={onClose}>
        <TouchableOpacity activeOpacity={1} onPress={() => {}} style={[st.caja, { backgroundColor: theme.card }]}>
          {!!titulo && <Text style={[st.cajaTitulo, { color: theme.text }]}>{titulo}</Text>}
          {!!subtitulo && <Text style={[st.cajaSub, { color: theme.muted }]} numberOfLines={1}>{subtitulo}</Text>}
          <View style={[st.migas, st.migasModal]}>
            <TouchableOpacity onPress={() => setDir(null)}>
              <Text style={[st.miga, { color: !dir ? BLUE : theme.muted }]}>{L('Raíz', 'Root')}</Text>
            </TouchableOpacity>
            {camino(dir ? dir.id : null).map((c) => (
              <TouchableOpacity key={c.id} onPress={() => setDir(c)}>
                <Text style={[st.miga, { color: dir && dir.id === c.id ? BLUE : theme.muted }]}> › {c.nombre}</Text>
              </TouchableOpacity>
            ))}
          </View>
          {hijas.length ? (
            <View style={{ maxHeight: 240 }}>
              {hijas.map((c) => (
                <TouchableOpacity key={c.id} style={st.moverFila} onPress={() => setDir(c)}>
                  <Ionicons name="folder" size={20} color={BLUE} />
                  <Text style={{ color: theme.text, flex: 1 }} numberOfLines={1}>{c.nombre}</Text>
                  <Ionicons name="chevron-forward" size={14} color={theme.muted} />
                </TouchableOpacity>
              ))}
            </View>
          ) : (
            <Text style={{ color: theme.muted, fontSize: 13, paddingVertical: 12 }}>
              {L('Sin subcarpetas aquí.', 'No subfolders here.')}
            </Text>
          )}
          <TouchableOpacity
            style={[st.btnMover, { opacity: deshabilitadoSi != null && deshabilitadoSi === destinoId ? 0.4 : 1 }]}
            disabled={deshabilitadoSi != null && deshabilitadoSi === destinoId}
            onPress={() => { onElegir(destinoId); onClose(); }}
          >
            <Text style={st.btnMoverTxt}>
              {deshabilitadoSi != null && deshabilitadoSi === destinoId ? L('Ya está aquí', 'Already here') : (textoBoton || L('Guardar aquí', 'Save here'))}
            </Text>
          </TouchableOpacity>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

const st = StyleSheet.create({
  barra: { flexDirection: 'row', gap: 8, paddingHorizontal: 12, paddingTop: 4 },
  barraBtn: { width: 40, height: 36, borderRadius: 10, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  barraBtnActivo: { borderColor: BLUE, backgroundColor: BLUE + '22' },
  migas: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingTop: 8, paddingBottom: 2 },
  miga: { fontSize: 12, fontWeight: '600' },
  migasModal: { flexWrap: 'wrap', paddingHorizontal: 0, paddingVertical: 6 },
  buscaCaja: { flexDirection: 'row', alignItems: 'center', gap: 8, marginHorizontal: 12, marginTop: 6, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 8, borderWidth: 1 },
  buscaInput: { flex: 1, fontSize: 13, paddingVertical: 2 },
  fila: { flexDirection: 'row', alignItems: 'center', gap: 10, borderRadius: 10, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 10 },
  filaCarpeta: { borderLeftWidth: 3, borderLeftColor: BLUE },
  filaTitulo: { fontSize: 14, fontWeight: '700' },
  filaMeta: { fontSize: 11, marginTop: 2 },
  vacio: { alignItems: 'center', paddingVertical: 46, gap: 10, paddingHorizontal: 20 },
  vacioTxt: { fontSize: 13, textAlign: 'center' },
  ov: { flex: 1, backgroundColor: '#00000088', justifyContent: 'center', alignItems: 'center', padding: 24 },
  caja: { width: '100%', maxWidth: 360, borderRadius: 14, paddingVertical: 10, paddingHorizontal: 14 },
  cajaTitulo: { fontSize: 15, fontWeight: '800', marginBottom: 2 },
  cajaSub: { fontSize: 12, marginBottom: 6 },
  moverFila: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10 },
  btnMover: { backgroundColor: BLUE, borderRadius: 10, paddingVertical: 11, alignItems: 'center', marginTop: 8 },
  btnMoverTxt: { color: '#fff', fontWeight: '800' },
  menuFila: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12 },
  menuTxt: { fontSize: 14 },
  menuTxtActivo: { fontWeight: '800' },
  promptInput: { borderWidth: 1, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 9, fontSize: 14, marginTop: 8 },
  promptTxt: { fontSize: 15, fontWeight: '700' },
});
