// components/PasosResumen.js
// ─────────────────────────────────────────────────────────────
// Resumen SOLO LECTURA de los pasos programados de un entreno, con el
// diseño del mockup: barra azul numerada (el texto es el OBJETIVO del
// paso — zona R1/CAMBIO, rango de ritmo… — o su tipo si no tiene) y
// debajo las filas Tipo / Duración y, si el paso tiene objetivo, una
// tercera con el tipo de objetivo y su valor:
//   Zona FC      → "Zone 2 Default: 128-142 ppm" (rango del perfil)
//   Intensidad   → "2 - Muy fácil"
//   Ritmo/FC/Potencia/Elevación/Cadencia → "min-max unidad"
// Los pasos con hijos son grupos de repetición: caja redondeada "Repetir
// N veces" que envuelve al propio paso (SI tiene duración u objetivo
// propio, p.ej. un Intensivo) y a sus hijos; un contenedor vacío no
// pinta barra, como en el mockup.
// El numerado es global y correlativo solo para los pasos con barra.
// ─────────────────────────────────────────────────────────────
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getThemeColors, useAppSettings, L } from '../services/appSettings';
import { auth } from '../firebaseConfig';
import { zonasDeActividad } from '../services/zonas';
import { getCachedProfile } from '../services/profileCache';

const BLUE = '#4A90E2';

const TIPOS = {
  'Calentamiento': () => L('Calentamiento', 'Warm-up'),
  'Extensivo': () => L('Extensivo', 'Extensive'),
  'Intensivo': () => L('Intensivo', 'Intensive'),
  'Variable': () => L('Variable', 'Variable'),
  'Recuperación': () => L('Recuperación', 'Recovery'),
  'Entrenamiento tecnico': () => L('Entrenamiento tecnico', 'Tech training'),
  'Enfriarse': () => L('Enfriarse', 'Cool-down'),
  'Otro': () => L('Otro', 'Other'),
};
const tipoTxt = (k) => (TIPOS[k] ? TIPOS[k]() : (k || '—'));

const OBJ_LABELS = {
  'Ritmo': ['Ritmo', 'Pace'],
  'FC media': ['FC media', 'Avg HR'],
  'Zona FC': ['Zona FC', 'HR zone'],
  'Potencia': ['Potencia', 'Power'],
  'Zona potencia': ['Zona potencia', 'Power zone'],
  'Zona ritmo': ['Zona ritmo', 'Pace zone'],
  'Intensidad': ['Intensidad', 'Intensity'],
  'Elevación': ['Elevación', 'Elevation'],
  'Cadencia': ['Cadencia', 'Cadence'],
};
const objLabelTxt = (k) => (OBJ_LABELS[k] ? L(OBJ_LABELS[k][0], OBJ_LABELS[k][1]) : k);

// Escala de sensación 1-10 para el objetivo Intensidad.
const INTENSIDAD = {
  1: ['Muy muy fácil', 'Very, very easy'],
  2: ['Muy fácil', 'Very easy'],
  3: ['Fácil', 'Easy'],
  4: ['Moderado', 'Moderate'],
  5: ['Algo duro', 'Somewhat hard'],
  6: ['Duro', 'Hard'],
  7: ['Muy duro', 'Very hard'],
  8: ['Muy muy duro', 'Very, very hard'],
  9: ['Casi máximo', 'Almost maximal'],
  10: ['Máximo', 'Maximal'],
};

// Texto de la barra: el objetivo del paso si lo tiene (zona "R1"/"CAMBIO",
// rango de ritmo 4:30–4:00…); si no, el tipo.
function tituloPaso(p) {
  if (p.objZona) return p.objZona;
  if (p.objetivo === 'Ritmo' && (p.objMin || p.objMax)) return `${p.objMin || '?'}–${p.objMax || '?'}`;
  if (p.objetivo && p.objMin != null && p.objMin !== '') return `${p.objetivo} ${p.objMin}`;
  return null;
}

// Duración en texto: distancia con unidad, tiempo ya formateado
// ("00:10:00") o minutos → hh:mm:ss, botón de vuelta con referencia.
function durTxt(p) {
  if (p.durTipo === 'Distancia') return `${p.durValor ?? ''} ${p.durUnidad || 'km'}`.trim();
  if (p.durTipo === 'Botón de vuelta') return `${L('Vuelta', 'Lap')} ${p.durValor ?? ''} ${p.durUnidad || ''}`.trim();
  const raw = p.durTexto ?? p.durValor ?? '';
  if (String(raw).includes(':')) return String(raw);
  const mins = Number(raw);
  if (!Number.isFinite(mins) || mins <= 0) return '00:00:00';
  const total = Math.round(mins * 60);
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(Math.floor(total / 3600))}:${pad(Math.floor((total % 3600) / 60))}:${pad(total % 60)}`;
}

// Encuentra la zona del perfil cuyo nombre visible coincide con la elegida
// en el paso (por titulo/label, o por posición "Z2"/"R3" si no tenía).
function zonaPorNombre(lista, nombre, pref) {
  if (!nombre) return null;
  let i = (lista || []).findIndex((z) => (z.titulo || z.label) === nombre);
  if (i >= 0) return lista[i];
  i = (lista || []).findIndex((z, ix) => `${pref}${ix + 1}` === nombre);
  return i >= 0 ? lista[i] : null;
}

// Valor de la columna Objetivo según el tipo de objetivo del paso.
function objetivoTxt(p, zonas) {
  const par = (a, b) => [a, b].filter((x) => x != null && x !== '').join('-');
  switch (p.objetivo) {
    case 'Zona FC': {
      const z = zonaPorNombre(zonas.fc, p.objZona, 'Z');
      const r = z ? par(z.min, z.max) : '';
      return r ? `${p.objZona}: ${r} ppm` : p.objZona;
    }
    case 'Zona ritmo': {
      const z = zonaPorNombre(zonas.ritmo, p.objZona, 'R');
      const r = z ? par(z.min, z.max) : '';
      return r ? `${p.objZona}: ${r} /km` : p.objZona;
    }
    case 'Zona potencia': {
      const z = zonaPorNombre(zonas.pot, p.objZona, 'Z');
      const r = z ? par(z.min, z.max) : '';
      return r ? `${p.objZona}: ${r} W` : p.objZona;
    }
    case 'Intensidad': {
      const e = INTENSIDAD[String(p.objMin)] || INTENSIDAD[p.objMin];
      return e ? `${p.objMin} - ${L(e[0], e[1])}` : String(p.objMin ?? '');
    }
    case 'Ritmo': return `${par(p.objMin, p.objMax)} /km`;
    case 'FC media': return `${par(p.objMin, p.objMax)} ppm`;
    case 'Potencia': return `${par(p.objMin, p.objMax)} W`;
    case 'Elevación': return `${par(p.objMin, p.objMax)} m`;
    case 'Cadencia': return `${par(p.objMin, p.objMax)} rpm`;
    default: return '';
  }
}

// ¿El paso tiene contenido propio (duración u objetivo)? Los contenedores
// de repetición sin nada propio no pintan barra (mockup); un "Intensivo"
// con su duración y una recuperación dentro SÍ pinta la suya.
function conContenido(p) {
  const dur = String(p.durTexto ?? p.durValor ?? '').trim();
  if (dur && dur !== '0') return true;
  return !!(p.objZona || p.objMin || p.objMax);
}

// Numerado global correlativo (1,2,3…) de los pasos que se pintan con
// barra: todas las hojas y los contenedores con contenido propio.
function numerar(list, map, contador) {
  (list || []).forEach((p) => {
    if ((p.hijos || []).length > 0) {
      if (conContenido(p)) { map[p.id] = contador.n; contador.n += 1; }
      numerar(p.hijos, map, contador);
    } else {
      map[p.id] = contador.n; contador.n += 1;
    }
  });
}

function Paso({ p, numero, numeros, zonas, esLight, theme }) {
  const reps = Math.max(1, parseInt(p.repeticiones, 10) || 1);
  const hijos = (p.hijos || []).length > 0;
  const borde = esLight ? '#C9D4E2' : '#31435A';
  const objVal = p.objetivo ? objetivoTxt(p, zonas) : '';

  const cuerpo = (!hijos || conContenido(p)) && (
    <>
      <View style={[st.barra, { backgroundColor: esLight ? BLUE : '#2C4160' }]}>
        <View style={[st.barraNum, { backgroundColor: esLight ? '#FFFFFF42' : '#1E3048' }]}>
          <Text style={st.barraNumTxt}>{numero}</Text>
        </View>
        <Text style={st.barraTxt} numberOfLines={1}>{tituloPaso(p) || tipoTxt(p.tipo)}</Text>
      </View>
      <View style={st.campos}>
        <View style={[st.campo, { borderLeftColor: borde }]}>
          <Text style={[st.campoLbl, { color: theme.text }]}>{L('Tipo', 'Type')}</Text>
          <Text style={[st.campoVal, { color: theme.muted }]}>{tipoTxt(p.tipo)}</Text>
        </View>
        <View style={[st.campo, { borderLeftColor: borde }]}>
          <Text style={[st.campoLbl, { color: theme.text }]}>{L('Duración', 'Duration')}</Text>
          <Text style={[st.campoVal, { color: theme.muted }]}>{durTxt(p)}</Text>
        </View>
        {objVal ? (
          <View style={[st.campo, st.campoObjetivo, { borderLeftColor: borde }]}>
            <Text style={[st.campoLbl, { color: theme.text }]} numberOfLines={1}>{objLabelTxt(p.objetivo)}</Text>
            <Text style={[st.campoVal, st.campoValSm, { color: theme.muted }]} numberOfLines={2}>{objVal}</Text>
          </View>
        ) : null}
      </View>
    </>
  );

  const anidados = hijos && (p.hijos || []).map((h) => (
    <Paso key={h.id} p={h} numero={numeros[h.id]} numeros={numeros} zonas={zonas} esLight={esLight} theme={theme} />
  ));

  if (hijos) {
    return (
      <View style={[st.repsCaja, { borderColor: borde }]}>
        <View style={st.repsHead}>
          <Ionicons name="repeat" size={16} color={BLUE} />
          <Text style={[st.repsTxt, { color: theme.text }]}>{L('Repetir', 'Repeat')}</Text>
          <View style={[st.repsNum, { backgroundColor: esLight ? '#E8EEF6' : '#1E3048' }]}>
            <Text style={[st.repsNumTxt, { color: theme.text }]}>{reps}</Text>
          </View>
          <Text style={[st.repsTxt, { color: theme.text }]}>{L('veces', 'times')}</Text>
        </View>
        {cuerpo}
        {anidados}
      </View>
    );
  }
  return <View style={st.paso}>{cuerpo}</View>;
}

export default function PasosResumen({ pasos, profileUid, actividad }) {
  const settings = useAppSettings(); // re-renderiza al cambiar idioma/tema
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const esLight = theme.background === '#F4F7FB';

  // Zonas del atleta (FC/ritmo/potencia) para pintar los rangos de los
  // objetivos de zona: "Zone 2 Default: 128-142 ppm".
  const [zonas, setZonas] = useState({ fc: [], ritmo: [], pot: [] });
  useEffect(() => {
    (async () => {
      try {
        const uid = profileUid || auth.currentUser?.uid;
        if (!uid) return;
        const prof = await getCachedProfile(uid);
        if (!prof) return;
        // Rangos de zona de la ACTIVIDAD del entreno (fallback a genéricas)
        setZonas({
          fc: zonasDeActividad(prof, 'FC', actividad),
          ritmo: zonasDeActividad(prof, 'Ritmo', actividad),
          pot: zonasDeActividad(prof, 'Potencia', actividad),
        });
      } catch (e) {}
    })();
  }, [profileUid, actividad]);

  const numeros = {};
  const contador = { n: 1 };
  numerar(pasos, numeros, contador);

  return (
    <View style={st.wrap}>
      {(pasos || []).map((p) => (
        <Paso key={p.id} p={p} numero={numeros[p.id]} numeros={numeros} zonas={zonas} esLight={esLight} theme={theme} />
      ))}
    </View>
  );
}

const st = StyleSheet.create({
  wrap: { gap: 10, marginTop: 4 },
  paso: { gap: 10 },
  barra: {
    flexDirection: 'row', alignItems: 'center', borderRadius: 5, overflow: 'hidden', height: 36,
  },
  // El segmento del número abraza al dígito y deja 12 px de aire del color
  // de la barra antes del título: el borde del segmento queda a la mitad
  // exacta entre el final del número y el principio del título.
  barraNum: { minWidth: 34, paddingHorizontal: 12, height: '100%', alignItems: 'center', justifyContent: 'center' },
  barraNumTxt: { color: '#fff', fontSize: 15, fontWeight: '700' },
  barraTxt: { color: '#fff', fontSize: 15, fontWeight: '700', flex: 1, paddingLeft: 12, paddingRight: 12 },
  campos: { flexDirection: 'row' },
  campo: { flex: 1, borderLeftWidth: 2, paddingLeft: 12, paddingVertical: 2, gap: 4 },
  campoObjetivo: { flex: 1.5 },
  campoLbl: { fontSize: 15, fontWeight: '800' },
  campoVal: { fontSize: 15 },
  campoValSm: { fontSize: 13, lineHeight: 17 },
  repsCaja: { borderWidth: 1.5, borderRadius: 12, padding: 12, gap: 10 },
  repsHead: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  repsTxt: { fontSize: 16, fontWeight: '800' },
  repsNum: { minWidth: 30, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8, alignItems: 'center' },
  repsNumTxt: { fontSize: 15, fontWeight: '800' },
});
