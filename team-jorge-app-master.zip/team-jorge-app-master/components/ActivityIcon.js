// components/ActivityIcon.js
// ─────────────────────────────────────────────────────────────
// Icono centralizado por tipo de actividad.
// • Running usa MaterialCommunityIcons "run" (pictograma de
//   persona corriendo): Ionicons NO tiene icono de running y su
//   "fitness" es un corazón con pulso (se confundía con FC).
// • El resto sigue con Ionicons, igual que siempre.
// Ya viene incluido en @expo/vector-icons: no hay que añadir assets.
// ─────────────────────────────────────────────────────────────
import React from 'react';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';

const MAP = {
  Running:   { C: MaterialCommunityIcons, name: 'run' },
  Ciclismo:  { C: Ionicons, name: 'bicycle' },
  Natación:  { C: Ionicons, name: 'water' },
  Fuerza:    { C: Ionicons, name: 'barbell' },
  Triatlón:  { C: Ionicons, name: 'medal-outline' }, // medalla (la copa es para Evento)
  Evento:    { C: Ionicons, name: 'trophy' }, // copa
  Descanso:  { C: Ionicons, name: 'moon' },
  Otro:      { C: Ionicons, name: 'flash' },
  Notas:     { C: Ionicons, name: 'journal-outline' },
};

// Colores oficiales por tipo de actividad (fuente única de verdad)
export const TIPO_COLOR = {
  Running: '#E05252',
  Ciclismo: '#F5A623',
  Natación: '#4A90E2',
  Fuerza: '#9B59B6',
  Triatlón: '#2DB37A',
  Otro: '#8FA8C8',
  Evento: '#4A90E2', // copa azul
  Descanso: '#7F8FA6',
  Notas: '#8D6E63',
};

// Si no se pasa color, se usa el color del tipo de actividad.
export default function ActivityIcon({ tipo, size = 20, color, style }) {
  const m = MAP[tipo] || MAP.Otro;
  const C = m.C;
  const c = color || TIPO_COLOR[tipo] || '#8FA8C8';
  return <C name={m.name} size={size} color={c} style={style} />;
}
