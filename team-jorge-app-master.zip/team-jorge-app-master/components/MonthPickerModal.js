// components/MonthPickerModal.js
// ─────────────────────────────────────────────────────────────
// Calendario mensual interactivo para el CalendarScreen:
//  • Vista "días": rejilla del mes (empieza en lunes) para ir a un
//    día concreto; flechas ‹ › para cambiar de mes.
//  • Al tocar el título "mes de año" se abre la vista "ruleta":
//    dos ruedas (mes y año) con estética de tragaperras: el elemento
//    centrado queda resaltado, los de arriba/abajo se desvanecen y
//    al soltar el scroll SE ASENTA SIEMPRE en la fila centrada (snap
//    manual determinista: sin snapToInterval, que se peleaba con el
//    scrollTo y dejaba la rueda pillada).
//  • Cerrar = sale sin cambios · Ok = salta a la semana del día elegido.
// ─────────────────────────────────────────────────────────────
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Animated, Modal, ScrollView, StyleSheet, Text, TouchableOpacity, View, useColorScheme,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getThemeColors, useAppSettings, locale, L } from '../services/appSettings';

const BLUE = '#4A90E2';
const ROW_H = 44;                 // alto de cada fila de la ruleta
const ROWS_VISIBLE = 5;           // filas visibles (centrada + 2 arriba + 2 abajo)
const WHEEL_H = ROW_H * ROWS_VISIBLE;

function monthName(m, loc) {
  return new Date(2026, m, 1).toLocaleDateString(loc, { month: 'long' });
}
function daysInMonth(y, m) {
  return new Date(y, m + 1, 0).getDate();
}

// ── Ruleta tipo tragaperras con snap manual fiable ──
// Exportada: el selector de rango de fechas de los retos (RangoCalendarioModal) la reutiliza.
export function Wheel({ items, selected, onChange, theme }) {
  const scrollY = useRef(new Animated.Value(selected * ROW_H)).current;
  const sv = useRef(null);
  const laidOut = useRef(false);
  const momentum = useRef(false);
  const settling = useRef(false);
  const prevSel = useRef(selected);

  // Cambios externos (tap en una fila): gira hasta ella con animación
  useEffect(() => {
    if (prevSel.current !== selected) {
      prevSel.current = selected;
      settling.current = true;
      sv.current?.scrollTo({ y: selected * ROW_H, animated: true });
    }
  }, [selected]);

  // Asienta la rueda en la fila más cercana al offset actual (siempre,
  // aunque sea la misma ya seleccionada, para que nunca quede descuadrada)
  const settleAt = (offset) => {
    const idx = Math.max(0, Math.min(items.length - 1, Math.round(offset / ROW_H)));
    settling.current = true;
    sv.current?.scrollTo({ y: idx * ROW_H, animated: true });
    prevSel.current = idx;
    if (idx !== selected) onChange(idx);
  };

  return (
    <View style={{ flex: 1, height: WHEEL_H }}>
      {/* Caja central resaltada (ventana de la tragaperras) */}
      <View
        pointerEvents="none"
        style={[
          st.slotCenter,
          { backgroundColor: theme.background === '#F4F7FB' ? '#0D1B2A0D' : '#FFFFFF14' },
        ]}
      />
      <Animated.ScrollView
        ref={sv}
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingVertical: (WHEEL_H - ROW_H) / 2 }}
        showsVerticalScrollIndicator={false}
        decelerationRate="fast"
        scrollEventThrottle={16}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: true }
        )}
        onScrollEndDrag={(e) => {
          // Si al soltar no arranca inercia, asentamos nosotros
          momentum.current = false;
          const offset = e.nativeEvent.contentOffset.y;
          setTimeout(() => {
            if (!momentum.current && !settling.current) settleAt(offset);
            settling.current = false;
          }, 20);
        }}
        onMomentumScrollBegin={() => {
          momentum.current = true;
          settling.current = false;
        }}
        onMomentumScrollEnd={(e) => {
          momentum.current = false;
          if (!settling.current) settleAt(e.nativeEvent.contentOffset.y);
          settling.current = false;
        }}
        onLayout={() => {
          if (laidOut.current) return;
          laidOut.current = true;
          requestAnimationFrame(() => {
            sv.current?.scrollTo({ y: prevSel.current * ROW_H, animated: false });
          });
        }}
      >
        {items.map((label, i) => {
          const opacity = scrollY.interpolate({
            inputRange: [
              (i - 2) * ROW_H, (i - 1) * ROW_H, i * ROW_H, (i + 1) * ROW_H, (i + 2) * ROW_H,
            ],
            outputRange: [0.15, 0.45, 1, 0.45, 0.15],
            extrapolate: 'clamp',
          });
          return (
            <TouchableOpacity
              key={`${label}-${i}`}
              activeOpacity={0.7}
              onPress={() => onChange(i)}
              style={{ height: ROW_H, alignItems: 'center', justifyContent: 'center' }}
            >
              <Animated.Text
                style={[
                  st.slotText,
                  {
                    color: i === selected ? theme.text : theme.muted,
                    opacity,
                    fontSize: i === selected ? 22 : 18,
                  },
                ]}
              >
                {label}
              </Animated.Text>
            </TouchableOpacity>
          );
        })}
      </Animated.ScrollView>
    </View>
  );
}

export default function MonthPickerModal({ visible, onClose, onSelect, initialDate, nacimiento }) {
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const loc = locale();

  const [view, setView] = useState('days'); // 'days' | 'wheel'
  const [viewYear, setViewYear] = useState(new Date().getFullYear());
  const [viewMonth, setViewMonth] = useState(new Date().getMonth());
  const [selDay, setSelDay] = useState(new Date().getDate());

  // Al abrir, se sincroniza con la fecha que se está viendo en el calendario
  useEffect(() => {
    if (visible) {
      const d = initialDate ?? new Date();
      setView('days');
      setViewYear(d.getFullYear());
      setViewMonth(d.getMonth());
      setSelDay(d.getDate());
    }
  }, [visible]);

  const years = useMemo(() => {
    const now = new Date().getFullYear();
    const out = [];
    // Nacimiento: años HACIA ATRÁS sin límite práctico (del actual a 100 años
    // atrás), del más reciente al más antiguo; sin nacimiento, ±6 como siempre.
    if (nacimiento) { for (let y = now; y >= now - 100; y--) out.push(y); return out; }
    for (let y = now - 6; y <= now + 6; y++) out.push(y);
    return out;
  }, [nacimiento]);
  const months = useMemo(
    () => Array.from({ length: 12 }, (_, m) => monthName(m, loc)),
    [loc]
  );
  const weekHeaders = useMemo(
    // El 4 de enero de 2021 fue lunes → cabeceras LUN..DOM en el idioma activo
    () => Array.from({ length: 7 }, (_, i) =>
      new Date(2021, 0, 4 + i).toLocaleDateString(loc, { weekday: 'short' }).toUpperCase()
    ),
    [loc]
  );

  const dim = daysInMonth(viewYear, viewMonth);
  const safeDay = Math.min(selDay, dim);
  const firstOffset = (new Date(viewYear, viewMonth, 1).getDay() + 6) % 7; // lunes = 0
  const cells = [];
  for (let i = 0; i < firstOffset; i++) cells.push(null);
  for (let d = 1; d <= dim; d++) cells.push(d);

  const changeMonth = (dir) => {
    let m = viewMonth + dir;
    let y = viewYear;
    if (m < 0) { m = 11; y--; }
    if (m > 11) { m = 0; y++; }
    setViewMonth(m);
    setViewYear(y);
  };

  const title = `${monthName(viewMonth, loc)} de ${viewYear}`;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={st.overlay}>
        <View style={[st.card, { backgroundColor: theme.card }]}>
          {/* ── Cabecera: título-ruleta + flechas de mes ── */}
          <View style={st.headerRow}>
            <TouchableOpacity
              style={st.titleBtn}
              onPress={() => setView(view === 'days' ? 'wheel' : 'days')}
              activeOpacity={0.7}
            >
              <Text style={[st.title, { color: theme.text }]} numberOfLines={1}>{title}</Text>
              <Ionicons name={view === 'days' ? 'chevron-down' : 'chevron-up'} size={18} color={BLUE} />
            </TouchableOpacity>
            {view === 'days' && (
              <View style={st.arrows}>
                <TouchableOpacity onPress={() => changeMonth(-1)} style={st.arrowBtn}>
                  <Ionicons name="chevron-back" size={22} color={BLUE} />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => changeMonth(1)} style={st.arrowBtn}>
                  <Ionicons name="chevron-forward" size={22} color={BLUE} />
                </TouchableOpacity>
              </View>
            )}
          </View>

          {view === 'wheel' ? (
            /* ── Ruletas de mes y año ── */
            <View style={st.wheelsRow}>
              <Wheel items={months} selected={viewMonth} onChange={(i) => setViewMonth(i)} theme={theme} />
              <Wheel
                items={years.map(String)}
                selected={Math.max(0, years.indexOf(viewYear))}
                onChange={(i) => setViewYear(years[i])}
                theme={theme}
              />
            </View>
          ) : (
            /* ── Rejilla de días del mes ── */
            <>
              <View style={st.weekRow}>
                {weekHeaders.map((w, i) => (
                  <Text key={i} style={[st.weekCell, { color: theme.muted }]}>{w}</Text>
                ))}
              </View>
              <ScrollView style={st.gridScroll} showsVerticalScrollIndicator={false}>
                <View style={st.grid}>
                  {cells.map((d, i) =>
                    d == null ? (
                      <View key={`b${i}`} style={st.dayCell} />
                    ) : (
                      <TouchableOpacity key={d} style={st.dayCell} onPress={() => setSelDay(d)} activeOpacity={0.7}>
                        <View style={[st.dayCircle, d === safeDay && st.dayCircleSel]}>
                          <Text style={[st.dayText, { color: d === safeDay ? '#FFFFFF' : theme.text }]}>
                            {d}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    )
                  )}
                </View>
              </ScrollView>
            </>
          )}

          {/* ── Pie: Cerrar / Ok ── */}
          <View style={[st.footer, { borderTopColor: theme.border }]}>
            <TouchableOpacity style={st.footerBtn} onPress={onClose}>
              <Text style={[st.footerText, { color: BLUE }]}>{L('Cerrar', 'Close')}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={st.footerBtn}
              onPress={() => onSelect(new Date(viewYear, viewMonth, safeDay))}
            >
              <Text style={[st.footerText, { color: BLUE, fontWeight: '800' }]}>{L('Ok', 'Ok')}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const st = StyleSheet.create({
  overlay: {
    flex: 1, backgroundColor: '#00000088',
    justifyContent: 'center', alignItems: 'center', padding: 24,
  },
  card: { width: '100%', maxWidth: 420, borderRadius: 16, overflow: 'hidden', paddingBottom: 6 },
  headerRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 14, paddingBottom: 6, gap: 8,
  },
  titleBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1 },
  title: { fontSize: 18, fontWeight: '800' },
  arrows: { flexDirection: 'row', gap: 12 },
  arrowBtn: { padding: 4 },
  // Ruleta
  wheelsRow: { flexDirection: 'row', paddingHorizontal: 10, paddingVertical: 10 },
  slotCenter: {
    position: 'absolute', left: 6, right: 6,
    top: WHEEL_H / 2 - ROW_H / 2, height: ROW_H, borderRadius: 10,
  },
  slotText: { fontWeight: '700' },
  // Rejilla de días
  weekRow: { flexDirection: 'row', paddingHorizontal: 10, paddingBottom: 2 },
  weekCell: { flex: 1, textAlign: 'center', fontSize: 11, fontWeight: '700' },
  gridScroll: { maxHeight: 300 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 10, paddingBottom: 10 },
  dayCell: { width: '14.285%', height: 44, alignItems: 'center', justifyContent: 'center' },
  dayCircle: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  dayCircleSel: { backgroundColor: BLUE },
  dayText: { fontSize: 16, fontWeight: '600' },
  // Pie
  footer: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    borderTopWidth: 1, paddingHorizontal: 8, paddingTop: 2, marginTop: 2,
  },
  footerBtn: { padding: 12, paddingHorizontal: 18 },
  footerText: { fontSize: 16, fontWeight: '600' },
});
