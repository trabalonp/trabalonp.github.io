// components/SystemBars.js
// ─────────────────────────────────────────────────────────────
// Barras del sistema ("scrims"):
//  • ARRIBA: rectángulo negro bajo la barra de estado (batería/wifi/hora),
//    de la altura exacta del inset superior.
//  • ABAJO: rectángulo gris medio-oscuro que cubre EXACTAMENTE la altura de
//    los botones de navegación de Android, pero SOLO cuando hay botones
//    físicos activos. Con navegación por gestos (sin botones) no se pinta
//    nada y el contenido ocupa la pantalla completa.
//  • LATERALES: en horizontal algunos móviles colocan los botones a un
//    lado; se pinta la misma franja gris allí donde haya botones.
//
// Se monta como ÚLTIMO elemento del JSX de la app (App.js) y dentro de
// cada <Modal>, para que quede por encima de todo el contenido.
// Nunca intercepta toques (pointerEvents="none").
// ─────────────────────────────────────────────────────────────
import React from 'react';
import { Platform, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

// A partir de este inset (dp) consideramos que hay botones de navegación.
// La navegación de 3 botones suele medir ~48dp; la navegación por gestos
// deja un inset pequeño (~0-24dp) sin barra visible.
const BUTTONS_MIN_INSET = 32;

export default function SystemBars({
  topColor = '#000000',      // negro para la barra de estado
  bottomColor = '#3C4043',   // gris medio-oscuro para los botones
  showTop = true,
  showBottom = true,
}) {
  const insets = useSafeAreaInsets();
  const android = Platform.OS === 'android';
  const base = { position: 'absolute', zIndex: 9999 };

  const bottomButtons = android && insets.bottom >= BUTTONS_MIN_INSET;
  const leftButtons   = android && insets.left   >= BUTTONS_MIN_INSET;
  const rightButtons  = android && insets.right  >= BUTTONS_MIN_INSET;

  return (
    <>
      {showTop && insets.top > 0 && (
        <View
          pointerEvents="none"
          style={{ ...base, top: 0, left: 0, right: 0, height: insets.top, backgroundColor: topColor }}
        />
      )}
      {showBottom && bottomButtons && (
        <View
          pointerEvents="none"
          style={{ ...base, bottom: 0, left: 0, right: 0, height: insets.bottom, backgroundColor: bottomColor }}
        />
      )}
      {showBottom && leftButtons && (
        <View
          pointerEvents="none"
          style={{ ...base, top: 0, bottom: 0, left: 0, width: insets.left, backgroundColor: bottomColor }}
        />
      )}
      {showBottom && rightButtons && (
        <View
          pointerEvents="none"
          style={{ ...base, top: 0, bottom: 0, right: 0, width: insets.right, backgroundColor: bottomColor }}
        />
      )}
    </>
  );
}
