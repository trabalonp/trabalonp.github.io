// components/WeatherPanel.js
// ─────────────────────────────────────────────────────────────
// PESTAÑA DEL TIEMPO (SocialScreen) — estilo app del tiempo del iPad.
// Datos EXTERNOS y gratuitos, sin clave, sin nuestro servidor ni Firestore:
//   · Pronóstico:  api.open-meteo.com  (actual + 24 h + 7 días, métrico,
//     timezone=auto) — https://open-meteo.com
//   · Búsqueda de ciudad: geocoding-api.open-meteo.com
//   · Nombre de la ubicación GPS: api.bigdatacloud.net (reverse, sin clave)
// UBICACIÓN: se guarda en AsyncStorage (tj_weather_loc) para NO usar el GPS
// en cada apertura; también se puede escribir a mano con el buscador.
// CACHÉ del último pronóstico (tj_weather_cache): al abrir se pinta al
// instante y se refresca en segundo plano (pull-to-refresh incluido).
// ─────────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, RefreshControl, ScrollView, StyleSheet, Text,
  TextInput, TouchableOpacity, View, useColorScheme,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
// expo-location con require PROTEGIDO (patrón AudioLib de SocialScreen):
// un OTA no puede añadir módulos nativos; si el binario no trae
// expo-location (build antigua), la app no reventa — solo no habrá GPS.
let Location = null;
try { Location = require('expo-location'); } catch (e) { Location = null; }
import { getThemeColors, useAppSettings, L } from '../services/appSettings';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const BLUE = '#4A90E2';
const K_LOC = 'tj_weather_loc_v1';
const K_CACHE = 'tj_weather_cache_v1';
const TTL_MS = 20 * 60 * 1000;   // refresco automático si el caché supera 20 min

// WMO weather codes → icono (MaterialCommunityIcons) + descripción es/en
const WMO = {
  0:  ['weather-sunny', 'Despejado', 'Clear sky'],
  1:  ['weather-partlycloudy', 'Mayormente despejado', 'Mainly clear'],
  2:  ['weather-partlycloudy', 'Parcialmente nublado', 'Partly cloudy'],
  3:  ['weather-cloudy', 'Nublado', 'Overcast'],
  45: ['weather-fog', 'Niebla', 'Fog'],
  48: ['weather-fog', 'Niebla helada', 'Rime fog'],
  51: ['weather-partly-rainy', 'Llovizna ligera', 'Light drizzle'],
  53: ['weather-partly-rainy', 'Llovizna', 'Drizzle'],
  55: ['weather-pouring', 'Llovizna intensa', 'Dense drizzle'],
  56: ['weather-snowy-rainy', 'Llovizna helada', 'Freezing drizzle'],
  57: ['weather-snowy-rainy', 'Llovizna helada intensa', 'Freezing drizzle'],
  61: ['weather-rainy', 'Lluvia ligera', 'Slight rain'],
  63: ['weather-rainy', 'Lluvia', 'Rain'],
  65: ['weather-pouring', 'Lluvia intensa', 'Heavy rain'],
  66: ['weather-snowy-rainy', 'Lluvia helada', 'Freezing rain'],
  67: ['weather-snowy-rainy', 'Lluvia helada intensa', 'Freezing rain'],
  71: ['weather-snowy', 'Nieve ligera', 'Slight snow'],
  73: ['weather-snowy', 'Nieve', 'Snow'],
  75: ['weather-snowy', 'Nieve intensa', 'Heavy snow'],
  77: ['weather-snowy', 'Granos de nieve', 'Snow grains'],
  80: ['weather-partly-rainy', 'Chubascos ligeros', 'Light showers'],
  81: ['weather-rainy', 'Chubascos', 'Showers'],
  82: ['weather-pouring', 'Chubascos fuertes', 'Violent showers'],
  85: ['weather-snowy', 'Chubascos de nieve', 'Snow showers'],
  86: ['weather-snowy', 'Chubascos de nieve', 'Snow showers'],
  95: ['weather-lightning', 'Tormenta', 'Thunderstorm'],
  96: ['weather-hail', 'Tormenta con granizo', 'Thunderstorm, hail'],
  99: ['weather-hail', 'Tormenta con granizo', 'Thunderstorm, hail'],
};
const wmoIcon = (code, isDay) => {
  const e = WMO[code];
  if (!e) return 'weather-cloudy';
  if (!isDay) {
    if (e[0] === 'weather-sunny') return 'weather-night';
    if (e[0] === 'weather-partlycloudy') return 'weather-night-partly-cloudy';
  }
  return e[0];
};
const wmoTxt = (code) => {
  const e = WMO[code];
  return e ? (L(e[1], e[2])) : '—';
};

const UV_NIVELES = [
  [2, ['Bajo', 'Low']], [5, ['Moderado', 'Moderate']], [7, ['Alto', 'High']],
  [10, ['Muy alto', 'Very high']], [11, ['Extremo', 'Extreme']],
];
const uvNivel = (uv) => {
  const e = UV_NIVELES.find(([max]) => uv <= max);
  return e ? L(e[1][0], e[1][1]) : '—';
};
const CARDINALES = { es: ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'], en: ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'] };
const cardinal = (deg, lang) => {
  if (!Number.isFinite(deg)) return '';
  const lista = CARDINALES[lang || 'es'] || CARDINALES.es;
  return lista[Math.round(deg / 45) % 8];
};

const p2 = (n) => String(n).padStart(2, '0');

// Posición ROBUSTA: iOS lanza kCLErrorDomain 0 (posición aún no lista) la
// primera vez — se usa la última conocida y se reintenta hasta 3 veces.
function obtenerPosicion() {
  let ultima = null;
  try { ultima = Location.getLastKnownPositionAsync(); } catch (e) {}
  return ultima
    .then((ult) => {
      if (ult && Date.now() - ult.timestamp < 10 * 60 * 1000) return ult;
      return (async () => {
        for (let i = 0; i < 3; i++) {
          try {
            const pos = await Location.getCurrentPositionAsync({
              accuracy: Location.Accuracy.Balanced, maxAge: 60000, timeout: 15000,
            });
            return pos;
          } catch (e) {
            await new Promise((r) => setTimeout(r, 1500));
          }
        }
        if (ult) return ult;   // mejor vieja que ninguna
        throw new Error(L('No se pudo obtener tu ubicación. Reintenta o busca tu ciudad a mano.', 'Could not get your location. Retry or search your city manually.'));
      })();
    });
}

export default function WeatherPanel() {
  const insets = useSafeAreaInsets();
  const settings = useAppSettings();   // re-renderiza al cambiar idioma/tema
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const isLight = theme.background === '#F4F7FB';
  const loc = settings.language === 'en' ? 'en-US' : 'es-ES';

  const [locGuardada, setLocGuardada] = useState(null); // { lat, lon, nombre }
  const [data, setData] = useState(null);              // respuesta de open-meteo
  const [estado, setEstado] = useState('cargando');    // cargando | listo | error | sin-ubicacion
  const [refrescando, setRefrescando] = useState(false);
  const [actualizado, setActualizado] = useState(null);
  const [buscaAbierto, setBuscaAbierto] = useState(false);
  const [busqueda, setBusqueda] = useState('');
  const [resultados, setResultados] = useState(null);  // ciudades encontradas
  const [buscando, setBuscando] = useState(false);
  const gpsAuto = useRef(false);

  // ── Carga del pronóstico (Open-Meteo) + caché local ──
  const cargarTiempo = useCallback(async (l) => {
    const url =
      `https://api.open-meteo.com/v1/forecast?latitude=${l.lat}&longitude=${l.lon}` +
      '&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,cloud_cover,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m' +
      '&hourly=temperature_2m,weather_code,precipitation_probability,precipitation,wind_speed_10m,uv_index,visibility' +
      '&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,uv_index_max,sunrise,sunset' +
      '&timezone=auto&forecast_days=7&wind_speed_unit=kmh';
    const r = await fetch(url);
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const json = await r.json();
    setData(json);
    setActualizado(Date.now());
    await AsyncStorage.setItem(K_CACHE, JSON.stringify({ ...l, data: json, ts: Date.now() }));
  }, []);


  const guardarUbicacion = async (l) => {
    await AsyncStorage.setItem(K_LOC, JSON.stringify(l));
    setLocGuardada(l); setData(null); setEstado('cargando');
    try { await cargarTiempo(l); } catch (e) { setEstado('error'); }
  };

  // ── GPS: permiso + posición + nombre (reverse geocode) ──
  const usarGps = async () => {
    if (!Location) {
      Alert.alert(L('GPS no disponible', 'GPS unavailable'), L('Esta versión de la app no incluye el módulo de ubicación. Busca tu ciudad a mano con la lupa.', 'This app version lacks the location module. Search your city with the magnifier instead.'));
      return;
    }
    try {
      const perm = await Location.requestForegroundPermissionsAsync();
      if (!perm.granted) { Alert.alert(L('Permiso requerido', 'Permission required'), L('Activa la ubicación para usar el tiempo automático, o busca tu ciudad a mano.', 'Allow location for automatic weather, or search your city manually.')); setEstado((e) => (e === 'listo' ? e : 'sin-ubicacion')); return; }
      setEstado((e) => (e === 'listo' ? 'cargando-loc' : 'cargando'));
      const pos = await obtenerPosicion();
      let nombre = `${pos.coords.latitude.toFixed(2)}, ${pos.coords.longitude.toFixed(2)}`;
      try {
        const r = await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${pos.coords.latitude}&longitude=${pos.coords.longitude}&localityLanguage=es`);
        if (r.ok) { const j = await r.json(); nombre = [j.city || j.locality, j.principalSubdivision].filter(Boolean).join(', ') || nombre; }
      } catch (e) {}
      await guardarUbicacion({ lat: pos.coords.latitude, lon: pos.coords.longitude, nombre });
    } catch (e) {
      Alert.alert(L('Sin ubicación', 'No location'), e.message || String(e));
      setEstado((e2) => (e2 === 'listo' ? e2 : 'sin-ubicacion'));
    }
  };

  // ── Montaje: ubicación guardada → caché al instante → refresco en vivo ──
  useEffect(() => {
    let vivo = true;
    (async () => {
      try {
        const rawLoc = await AsyncStorage.getItem(K_LOC);
        const rawCache = await AsyncStorage.getItem(K_CACHE);
        if (!vivo) return;
        if (rawLoc) {
          const l = safeJson(rawLoc, null);
          if (l) {
            setLocGuardada(l);
            const cache = rawCache ? safeJson(rawCache, null) : null;
            if (cache && cache.data && Math.abs(cache.lat - l.lat) < 0.01 && Math.abs(cache.lon - l.lon) < 0.01) {
              setData(cache.data); setActualizado(cache.ts || null); setEstado('listo');
            }
            cargarTiempo(l).catch(() => { if (vivo && !cache) setEstado('error'); });
            return;
          }
        }
        // Sin módulo de ubicación (build antigua): el buscador manual es el camino
        if (!Location) { setEstado('sin-ubicacion'); return; }
        // Sin ubicación guardada: GPS automático una sola vez
        if (!gpsAuto.current) { gpsAuto.current = true; usarGps(); }
        else setEstado('sin-ubicacion');
      } catch (e) { if (vivo) setEstado('sin-ubicacion'); }
    })();
    return () => { vivo = false; };
  }, []);
  // ── Búsqueda manual de ciudad (geocoding de Open-Meteo) ──
  useEffect(() => {
    const texto = buscaAbierto ? busqueda.trim() : '';
    if (texto.length < 2) { setResultados(null); return undefined; }
    let vivo = true;
    setBuscando(true);
    const t = setTimeout(async () => {
      try {
        const r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(texto)}&count=8&language=${settings.language || 'es'}&format=json`);
        const j = await r.json();
        if (vivo) setResultados(j.results || []);
      } catch (e) { if (vivo) setResultados([]); }
      finally { if (vivo) setBuscando(false); }
    }, 350);
    return () => { vivo = false; clearTimeout(t); };
  }, [busqueda, buscaAbierto, locGuardada, settings.language]);

  const refrescar = async () => {
    if (!locGuardada) return;
    setRefrescando(true);
    try { await cargarTiempo(locGuardada); } catch (e) {}
    finally { setRefrescando(false); }
  };

  // ── Derivados del pronóstico ──
  const ahora = useMemo(() => {
    if (!data) return null;
    const c = data.current || {};
    const off = (data.utc_offset_seconds || 0) * 1000;
    const tzNow = new Date(Date.now() + off + new Date().getTimezoneOffset() * 60000);
    const H = data.hourly || {};
    const D = data.daily || {};
    let idxH = (H.time || []).findIndex((t) => new Date(t) > tzNow);
    if (idxH < 0) idxH = 0;
    const horas = (H.time || []).slice(idxH, idxH + 24).map((t, i) => ({
      hora: i === 0 ? L('Ahora', 'Now') : t.slice(11, 16),
      temp: H.temperature_2m?.[idxH + i],
      code: H.weather_code?.[idxH + i],
      prob: H.precipitation_probability?.[idxH + i],
    }));
    const dias = (D.time || []).map((t, i) => ({
      nombre: i === 0 ? L('Hoy', 'Today') : (() => { const s = new Date(`${t}T12:00:00`).toLocaleDateString(loc, { weekday: 'long' }); return s.charAt(0).toUpperCase() + s.slice(1); })(),
      code: D.weather_code?.[i],
      max: D.temperature_2m_max?.[i], min: D.temperature_2m_min?.[i],
      prob: D.precipitation_probability_max?.[i], sum: D.precipitation_sum?.[i],
      uv: D.uv_index_max?.[i], viento: D.wind_speed_10m_max?.[i],
      amanecer: (D.sunrise?.[i] || '').slice(11, 16), atardecer: (D.sunset?.[i] || '').slice(11, 16),
    }));
    const semanaMin = Math.min(...(D.temperature_2m_min || []).slice(0, 7).map(Number).filter(Number.isFinite));
    const semanaMax = Math.max(...(D.temperature_2m_max || []).slice(0, 7).map(Number).filter(Number.isFinite));
    const visibilidad = (H.visibility?.[idxH] ?? null) / 1000;
    const uvAhora = H.uv_index?.[idxH];
    return { c, horas, dias, semanaMin, semanaMax, visibilidad, uvAhora, tzNow };
  }, [data, loc]);

  if (estado === 'cargando' || (estado === 'cargando-loc' && !data)) {
    return (<View style={st.centro}><ActivityIndicator size="large" color={BLUE} /><Text style={[st.txt, { color: theme.muted }]}>{L('Cargando el tiempo…', 'Loading weather…')}</Text></View>);
  }

  return (
    <View style={{ flex: 1, backgroundColor: theme.background }}>
      {/* ── Cabecera sólida: corta el fondo justo debajo de los botones ── */}
      <View style={[st.cabecera, { borderBottomColor: theme.border, paddingTop: insets.top + 44 }]}>
        <TouchableOpacity style={st.cabBtn} onPress={usarGps}>
          <Ionicons name="location" size={16} color={BLUE} />
          <Text style={[st.cabBtnTxt, { color: BLUE }]}>{L('Mi ubicación', 'My location')}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[st.cabBtn, { backgroundColor: theme.card, borderColor: theme.border }, buscaAbierto && st.cabBtnOn]} onPress={() => { setBuscaAbierto(!buscaAbierto); setBusqueda(''); setResultados(null); }}>
          <Ionicons name="search" size={15} color={BLUE} />
          <Text style={[st.cabBtnTxt, { color: BLUE }]}>{L('Buscar', 'Search')}</Text>
        </TouchableOpacity>
      </View>

      {(buscaAbierto || !locGuardada) && (
        <View style={[st.buscaCaja, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <Ionicons name="search-outline" size={15} color="#8FA8C8" />
          <TextInput
            style={[st.buscaInput, { color: theme.text }]}
            value={busqueda}
            onChangeText={setBusqueda}
            placeholder={L('Ciudad… p. ej. Gijón', 'City… e.g. Gijon')}
            placeholderTextColor="#4A6080"
            autoFocus
          />
          {buscando && <ActivityIndicator size="small" color={BLUE} />}
        </View>
      )}
      {(buscaAbierto || !locGuardada) && resultados != null && (
        <View style={[st.resultados, { backgroundColor: theme.card, borderColor: theme.border }]}>
          {resultados.length === 0 && <Text style={[st.txt, { color: theme.muted, padding: 10 }]}>{L('Sin resultados.', 'No results.')}</Text>}
          {resultados.map((r, i) => (
            <TouchableOpacity key={`${r.latitude}-${r.longitude}-${i}`} style={[st.resultadoFila, { borderBottomColor: theme.border }]}
              onPress={() => { setBuscaAbierto(false); setResultados(null); setBusqueda(''); guardarUbicacion({ lat: r.latitude, lon: r.longitude, nombre: [r.name, r.admin1].filter(Boolean).join(', ') }); }}>
              <Ionicons name="location-outline" size={15} color={BLUE} />
              <Text style={{ color: theme.text, flex: 1 }} numberOfLines={1}>
                {r.name}{r.admin1 ? `, ${r.admin1}` : ''}{r.country ? ` (${r.country})` : ''}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* ── Sin ubicación aún: onboarding ── */}
      {estado === 'sin-ubicacion' && !data && (
        <View style={st.centro}>
          <MaterialCommunityIcons name="weather-partly-cloudy" size={54} color={theme.muted} />
          <Text style={[st.txt, { color: theme.muted, textAlign: 'center', paddingHorizontal: 30 }]}>
            {L('Escribe tu ciudad arriba, o usa tu ubicación.', 'Type your city above, or use your location.')}
          </Text>
          <TouchableOpacity style={[st.boton, { backgroundColor: BLUE }]} onPress={usarGps}>
            <Ionicons name="location" size={16} color="#fff" />
            <Text style={{ color: '#fff', fontWeight: '800' }}>{L('Usar mi ubicación', 'Use my location')}</Text>
          </TouchableOpacity>
        </View>
      )}

      {estado === 'error' && !data && (
        <View style={st.centro}>
          <MaterialCommunityIcons name="weather-cloudy-arrow-right" size={46} color={theme.muted} />
          <Text style={[st.txt, { color: theme.muted }]}>{L('No se pudo cargar el tiempo.', 'Could not load the weather.')}</Text>
          <TouchableOpacity style={[st.boton, { backgroundColor: BLUE }]} onPress={refrescar}>
            <Text style={{ color: '#fff', fontWeight: '800' }}>{L('Reintentar', 'Retry')}</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* ── Pronóstico ── */}
      {data && ahora && (
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingBottom: 40 }}
          refreshControl={<RefreshControl refreshing={refrescando} onRefresh={refrescar} tintColor={BLUE} />}
        >
          {/* HERO */}
          <View style={st.hero}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, justifyContent: 'center' }}>
              <Ionicons name="location" size={13} color={theme.muted} />
              <Text style={[st.locNombre, { color: theme.text }]} numberOfLines={1}>{locGuardada?.nombre || ''}</Text>
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
              <MaterialCommunityIcons name={wmoIcon(ahora.c.weather_code, ahora.c.is_day)} size={72} color={isLight ? BLUE : '#E8EDF5'} />
              <Text style={[st.tempGrande, { color: theme.text }]}>{Math.round(ahora.c.temperature_2m)}°</Text>
            </View>
            <Text style={[st.desc, { color: theme.muted }]}>{wmoTxt(ahora.c.weather_code)}</Text>
            {!!ahora.dias[0] && (
              <Text style={[st.maxmin, { color: theme.muted }]}>
                {L('Máx', 'H')}: {Math.round(ahora.dias[0].max)}° · {L('Mín', 'L')}: {Math.round(ahora.dias[0].min)}° · {L('Sensación', 'Feels')}: {Math.round(ahora.c.apparent_temperature)}°
              </Text>
            )}
          </View>

          {/* 24 HORAS */}
          <Tarjeta theme={theme} titulo={L('Próximas 24 horas', 'Next 24 hours')} icono="hours-24">
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {ahora.horas.map((h, i) => (
                <View key={i} style={st.horaCol}>
                  <Text style={[st.horaTxt, { color: theme.muted }]} numberOfLines={1}>{h.hora}</Text>
                  <MaterialCommunityIcons name={wmoIcon(h.code, 1)} size={26} color={isLight ? BLUE : '#E8EDF5'} />
                  {!!(h.prob > 0) && <Text style={st.horaProb}>{h.prob}%</Text>}
                  <Text style={[st.horaTemp, { color: theme.text }]}>{h.temp != null ? `${Math.round(h.temp)}°` : '—'}</Text>
                </View>
              ))}
            </ScrollView>
          </Tarjeta>

          {/* 7 DÍAS */}
          <Tarjeta theme={theme} titulo={L('7 días', '7 days')} icono="calendar-week">
            {ahora.dias.map((d, i) => {
              const span = Math.max(1, ahora.semanaMax - ahora.semanaMin);
              const lo = Math.max(0, Math.round(((d.min - ahora.semanaMin) / span) * 100));
              const hi = Math.min(100, Math.round(((d.max - ahora.semanaMin) / span) * 100));
              return (
                <View key={i} style={st.diaFila}>
                  <Text style={[st.diaNombre, { color: theme.text }, i === 0 && { color: BLUE }]} numberOfLines={1}>{d.nombre}</Text>
                  <View style={{ width: 38, flexDirection: 'row', alignItems: 'center', gap: 2 }}>
                    {!!(d.prob > 0) && <><Ionicons name="water-outline" size={11} color={BLUE} /><Text style={st.diaProb}>{d.prob}%</Text></>}
                  </View>
                  <MaterialCommunityIcons name={wmoIcon(d.code, 1)} size={24} color={isLight ? BLUE : '#E8EDF5'} />
                  <Text style={[st.diaMin, { color: theme.muted }]}>{d.min != null ? `${Math.round(d.min)}°` : '—'}</Text>
                  <View style={[st.diaBarra, { backgroundColor: theme.border }]}>
                    <View style={{ position: 'absolute', left: `${lo}%`, width: `${Math.max(6, hi - lo)}%`, top: 0, bottom: 0, borderRadius: 3, backgroundColor: '#F5A623' }} />
                  </View>
                  <Text style={[st.diaMax, { color: theme.text }]}>{d.max != null ? `${Math.round(d.max)}°` : '—'}</Text>
                </View>
              );
            })}
          </Tarjeta>

          {/* DETALLES (cuadrícula estilo iPad) */}
          <Tarjeta theme={theme} titulo={L('Detalles', 'Details')} icono="information-variant">
            <View style={st.grid}>
              <Tile theme={theme} icono="thermometer" label={L('Sensación térmica', 'Feels like')} valor={`${Math.round(ahora.c.apparent_temperature)}°`} />
              <Tile theme={theme} icono="water-percent" label={L('Humedad', 'Humidity')} valor={`${Math.round(ahora.c.relative_humidity_2m)}%`} />
              <Tile theme={theme} icono="weather-windy" label={L('Viento', 'Wind')}
                valor={`${Math.round(ahora.c.wind_speed_10m)} km/h`} extra={`${cardinal(ahora.c.wind_direction_10m, settings.language)} · ${Math.round(ahora.c.wind_gusts_10m)} ${L('km/h rachas', 'km/h gusts')}`} />
              <Tile theme={theme} icono="weather-sunset-up" label={L('Amanecer', 'Sunrise')} valor={ahora.dias[0]?.amanecer || '—'} extra={`${L('Atardecer', 'Sunset')}: ${ahora.dias[0]?.atardecer || '—'}`} />
              <Tile theme={theme} icono="weather-sunny" label={L('Índice UV', 'UV index')} valor={ahora.uvAhora != null ? Number(ahora.uvAhora).toFixed(1) : '—'} extra={ahora.uvAhora != null ? uvNivel(ahora.uvAhora) : ''} />
              <Tile theme={theme} icono="gauge" label={L('Presión', 'Pressure')} valor={`${Math.round(ahora.c.surface_pressure)} hPa`} />
              <Tile theme={theme} icono="weather-cloudy" label={L('Nubosidad', 'Cloudiness')} valor={`${Math.round(ahora.c.cloud_cover)}%`} />
              <Tile theme={theme} icono="weather-pouring" label={L('Precipitación', 'Precipitation')}
                valor={`${ahora.c.precipitation ?? 0} mm`} extra={ahora.dias[0] ? `${L('Hoy', 'Today')}: ${ahora.dias[0].sum ?? 0} mm` : ''} />
              <Tile theme={theme} icono="eye-outline" label={L('Visibilidad', 'Visibility')}
                valor={ahora.visibilidad != null ? `${ahora.visibilidad.toFixed(0)} km` : '—'} extra={ahora.dias[0] ? `${L('UV máx hoy', 'UV max today')}: ${ahora.dias[0].uv ?? '—'}` : ''} />
            </View>
          </Tarjeta>

          {!!actualizado && (
            <Text style={[st.actualizado, { color: theme.muted }]}>
              {L('Actualizado a las', 'Updated at')} {(() => { const d = new Date(actualizado); return `${p2(d.getHours())}:${p2(d.getMinutes())}`; })()} · open-meteo.com
            </Text>
          )}
        </ScrollView>
      )}
    </View>
  );
}

function Tarjeta({ theme, titulo, icono, children }) {
  return (
    <View style={[st.tarjeta, { backgroundColor: theme.card, borderColor: theme.border }]}>
      <View style={st.tarjetaHead}>
        <MaterialCommunityIcons name={icono} size={14} color={theme.muted} />
        <Text style={[st.tarjetaTitulo, { color: theme.muted }]}>{titulo}</Text>
      </View>
      {children}
    </View>
  );
}

function Tile({ theme, icono, label, valor, extra }) {
  return (
    <View style={[st.tile, { backgroundColor: theme.background }]}>
      <View style={st.tileHead}>
        <MaterialCommunityIcons name={icono} size={13} color={theme.muted} />
        <Text style={[st.tileLbl, { color: theme.muted }]} numberOfLines={1}>{label}</Text>
      </View>
      <Text style={[st.tileVal, { color: theme.text }]} numberOfLines={1}>{valor}</Text>
      {!!extra ? <Text style={[st.tileExtra, { color: theme.muted }]} numberOfLines={1}>{extra}</Text> : null}
    </View>
  );
}

function safeJson(s, d) {
  try { const v = JSON.parse(s); return v == null ? d : v; } catch (e) { return d; }
}

const st = StyleSheet.create({
  centro: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 20 },
  txt: { fontSize: 14 },
  cabecera: { flexDirection: 'row', gap: 8, paddingHorizontal: 12, paddingBottom: 10, justifyContent: 'flex-end', borderBottomWidth: 1 },
  cabBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, borderWidth: 1, borderColor: 'transparent' },
  cabBtnTxt: { fontSize: 12, fontWeight: '700' },
  cabBtnOn: { borderColor: BLUE, backgroundColor: BLUE + '22' },
  buscaCaja: { flexDirection: 'row', alignItems: 'center', gap: 8, marginHorizontal: 12, marginTop: 6, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 10, borderWidth: 1 },
  buscaInput: { flex: 1, fontSize: 13, paddingVertical: 2 },
  resultados: { marginHorizontal: 12, marginTop: 6, borderRadius: 10, borderWidth: 1, overflow: 'hidden' },
  resultadoFila: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 12, paddingVertical: 10, borderBottomWidth: 1 },
  boton: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 16, paddingVertical: 10, borderRadius: 999 },
  hero: { alignItems: 'center', paddingVertical: 18, gap: 2 },
  locNombre: { fontSize: 20, fontWeight: '700' },
  tempGrande: { fontSize: 76, fontWeight: '200', lineHeight: 86 },
  desc: { fontSize: 15, fontWeight: '600' },
  maxmin: { fontSize: 13, marginTop: 4 },
  tarjeta: { marginHorizontal: 12, marginTop: 10, borderRadius: 14, borderWidth: 1, padding: 12 },
  tarjetaHead: { flexDirection: 'row', alignItems: 'center', gap: 5, marginBottom: 8 },
  tarjetaTitulo: { fontSize: 12, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5 },
  horaCol: { alignItems: 'center', width: 52, gap: 3 },
  horaTxt: { fontSize: 12, fontWeight: '600' },
  horaProb: { color: BLUE, fontSize: 10, fontWeight: '700' },
  horaTemp: { fontSize: 15, fontWeight: '700' },
  diaFila: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 7 },
  diaNombre: { width: 82, fontSize: 13, fontWeight: '600' },
  diaProb: { color: BLUE, fontSize: 11, fontWeight: '700' },
  diaMin: { width: 34, fontSize: 13, textAlign: 'right' },
  diaMax: { width: 34, fontSize: 13, fontWeight: '700' },
  diaBarra: { flex: 1, height: 5, borderRadius: 3, overflow: 'hidden' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tile: { width: '48.5%', flexGrow: 1, borderRadius: 12, padding: 10, gap: 3 },
  tileHead: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  tileLbl: { fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.4 },
  tileVal: { fontSize: 19, fontWeight: '700' },
  tileExtra: { fontSize: 11 },
  actualizado: { textAlign: 'center', fontSize: 11, marginTop: 12 },
});
