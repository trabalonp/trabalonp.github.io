// components/ShareProfileCard.js
/* Tarjeta compartible 4:5 "LA CIMA / EL AMANECER" como componente AISLADO.
   Este módulo NO se carga al entrar en Ajustes: SettingsScreen lo requiere
   (require) solo cuando se pulsa el botón de compartir, y lo monta en ese
   momento. Así la pantalla de Ajustes abre y vuelve sin pagar ni el código
   de los diseños ni el montaje del SVG.
   Uso:
     <ShareProfileCard ref={r} photo={base64} photoURL={url} initial="J"
                       firstName="Jorge" email="j@x.com" />
     await r.current.capture({ format: 'png', quality: 1, pixelRatio: 3 });
   El sello de marca usa el icono de la app (assets/images/icon.png). */
import { forwardRef, memo, useImperativeHandle, useMemo, useRef } from 'react';
import { Image, StyleSheet, Text, View, useColorScheme } from 'react-native';
import ViewShot from 'react-native-view-shot';
import Svg, {
  Circle, Defs, Ellipse, G, LinearGradient, Path, RadialGradient, Rect, Stop,
} from 'react-native-svg';
import { useFonts } from 'expo-font';
import { Ionicons } from '@expo/vector-icons';
import { useAppSettings } from '../services/appSettings';

const CARD_W = 400;   // puntos; se captura con pixelRatio 3 → 1200×1560 px
const CARD_H = 520;
const GREEN     = '#7BC86C';  // verde claro del logo (tema noche)
const GREEN_DK  = '#2F6B3A';  // verde oscuro del logo
const GREEN_LT  = '#8FE08A';  // verde vivo para el anillo
const INK       = '#0C1310';  // carbón del fondo de la tarjeta
const CREAM     = '#EAF7E6';  // blanco cálido para estrellas y ruta

/* ── Paletas duales: la tarjeta sigue el modo de contraste de la app ──
   NOCHE = "LA CIMA": carbón + auroras verdes + cielo estrellado.
   DÍA   = "EL AMANECER": cielo crema, curvas de nivel terracota, sol dorado
           tras la foto, terreno ocre, ruta verde azulado→coral y pájaros
           en lugar de estrellas. Familias de color DISTINTAS (cálida vs
           verde): no es el mismo esquema aclarado, es su propio mapa. ── */
const PALETAS = {
  noche: {
    cardBg: INK,
    sky: ['#0C1B13', INK, '#050806'],
    glow: ['#5FCE73', 0.26, '#3E9B52', 0.10],
    blobB: ['#3E9B52', 0.15],
    blobC: ['#A7E89B', 0.07],
    topo: GREEN,
    topoOp: [0.38, 0.28, 0.20, 0.14, 0.09],
    ridgeFill: [['#081109', 0.5], ['#060C08', 0.65]],
    ridgeStroke: GREEN,
    ridgeBoost: 1,
    ruta: [GREEN_DK, GREEN, CREAM],
    rutaDot: CREAM,
    rutaDotOp: 0.35,
    waypointFill: INK,
    waypointStroke: GREEN,
    pulse: CREAM,
    huella: GREEN,
    bandera: GREEN_LT,
    decor: GREEN,
    dotOp: 0.15,
    cornerOp: 0.7,
    vignette: ['#000000', 0.46],
    astro: CREAM,            // color de las estrellas (noche)
    ave: '#8A6A52',          // (sin uso en noche)
    name: '#F4F8F2',
    underline: GREEN,
    underline2: GREEN + '70',
    pillBg: '#FFFFFF0D',
    pillBorder: '#FFFFFF1F',
    email: '#AEC4B4',
    emailIcon: '#8FAF97',
    dashed: GREEN + '59',
    ringOut: GREEN_LT,
    ringOutBorder: GREEN_DK,
    ringIn: INK,
    fallback: GREEN_DK,
    initial: '#FFFFFF',
    brandText: '#F4F8F2',    // "TEAM JORGE" manuscrito (noche)
    brandUnder: GREEN,       // subrayado del sello
  },
  dia: {
    cardBg: '#FFF8EC',
    sky: ['#FFFDF6', '#FDEED4', '#F8DCB4'],
    glow: ['#F6A821', 0.32, '#E8890C', 0.12],
    blobB: ['#E4572E', 0.10],
    blobC: ['#FFC94D', 0.16],
    topo: '#C05F35',
    topoOp: [0.46, 0.34, 0.25, 0.17, 0.11],
    ridgeFill: [['#E3B98D', 0.55], ['#D19E6C', 0.62]],
    ridgeStroke: '#A9552D',
    ridgeBoost: 1.6,
    ruta: ['#0E6E64', '#128C7E', '#E4572E'],
    rutaDot: '#5B3A26',
    rutaDotOp: 0.30,
    waypointFill: '#FFF8EC',
    waypointStroke: '#0E6E64',
    pulse: '#E4572E',
    huella: '#B0714E',
    bandera: '#E4572E',
    decor: '#C05F35',
    dotOp: 0.20,
    cornerOp: 0.65,
    vignette: ['#7A4A28', 0.14],
    astro: '#E8A33D',        // (sin uso en día)
    ave: '#8A6A52',          // color de los pájaros (amanecer)
    name: '#4A2E1C',
    underline: '#E4572E',
    underline2: '#E4572E66',
    pillBg: '#FFFFFFA6',
    pillBorder: '#C05F3540',
    email: '#8A5E42',
    emailIcon: '#C05F35',
    dashed: '#C05F3559',
    ringOut: '#F5B942',
    ringOutBorder: '#B0714E',
    ringIn: '#FFF8EC',
    fallback: '#E8A33D',
    initial: '#FFFFFF',
    brandText: '#4A2E1C',    // "TEAM JORGE" manuscrito (día)
    brandUnder: '#E4572E',   // subrayado del sello
  },
};

/* Aleatorio determinista: el nombre semilla el mapa (mismo nombre → mismo
   mapa; distinto nombre → anillos y cielo distintos). Estable entre renders. */
const hashStr = (s) => {
  let h = 2166136261;
  for (let i = 0; i < (s || '').length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
};
const mulberry32 = (a) => () => {
  a |= 0; a = (a + 0x6D2B79F5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

/* Catmull-Rom → Bézier: curva suave que pasa por todos los puntos */
const spline = (pts, close) => {
  const n = pts.length;
  const at = (i) => pts[close ? (i + n) % n : Math.min(Math.max(i, 0), n - 1)];
  let d = `M${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`;
  for (let i = 0; i < (close ? n : n - 1); i++) {
    const p0 = at(i - 1), p1 = at(i), p2 = at(i + 1), p3 = at(i + 2);
    const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C${c1x.toFixed(1)} ${c1y.toFixed(1)},${c2x.toFixed(1)} ${c2y.toFixed(1)},${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`;
  }
  return close ? d + ' Z' : d;
};

/* Anillo topográfico (curva de nivel) alrededor de la cumbre, achatado
   como visto en perspectiva de mapa */
const topoRing = (cx, cy, r, ph, wob = 0.13) => {
  const pts = [];
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    const k = 1 + wob * (Math.sin(a * 2 + ph) * 0.6 + Math.sin(a * 3 - ph * 1.7) * 0.4);
    pts.push([cx + Math.cos(a) * r * k, cy + Math.sin(a) * r * k * 0.86]);
  }
  return spline(pts, true);
};
const TOPO_RADII = [96, 124, 154, 186, 222];

/* Arista de terreno que cruza la tarjeta; close=true rellena hasta abajo */
const ridgePath = (y0, amp, ph, close) => {
  const pts = [];
  for (let x = -20; x <= CARD_W + 20; x += 24) {
    pts.push([x, y0 + Math.sin(x * 0.016 + ph) * amp + Math.sin(x * 0.043 + ph * 1.7) * amp * 0.4]);
  }
  const d = spline(pts, false);
  return close ? `${d} L${CARD_W + 20} ${CARD_H + 20} L-20 ${CARD_H + 20} Z` : d;
};
const RIDGES = [
  { y: 372, amp: 10, o: 0.22, w: 1.4 },
  { y: 402, amp: 12, o: 0.18, w: 1.2 },
  { y: 432, amp: 15, o: 0.14, w: 1.1 },
  { y: 466, amp: 18, o: 0.11, w: 1.0 },
];

/* Ruta GPS con brillo (trazo degradado) que sobrevuela el terreno */
const RUTA_GPS = 'M-10 468 C 50 460 92 414 152 420 C 212 426 210 458 262 448 C 314 438 348 372 412 356';

/* Huellas que ascienden en diagonal hacia la cumbre (alternando pie) */
const TRAIL = { ax: 40, ay: 503, bx: 172, by: 393 };
const HUELLAS = [
  { t: 0.00, side: -1, o: 0.50, s: 1.00 },
  { t: 0.22, side: +1, o: 0.40, s: 0.94 },
  { t: 0.44, side: -1, o: 0.31, s: 0.88 },
  { t: 0.66, side: +1, o: 0.23, s: 0.82 },
  { t: 0.88, side: -1, o: 0.15, s: 0.76 },
];

// El nombre se escala solo si es largo para que nunca se salga del arte
const nameSize = (s) => ((s || '').length > 13 ? 22 : (s || '').length > 10 ? 26 : (s || '').length > 8 ? 30 : 34);

const ShareProfileCard = forwardRef(function ShareProfileCard(
  { photo, photoURL, initial, firstName, email },
  ref
) {
  const shotRef = useRef();
  const appSettings = useAppSettings();
  const systemScheme = useColorScheme();
  useFonts({ 'Kalam-Bold': require('../assets/fonts/Kalam-Bold.ttf') });

  // La tarjeta sigue el modo de contraste de la app:
  // día (o dispositivo en claro) → "EL AMANECER"; si no → "LA CIMA" noche.
  const cardLight = appSettings.themeMode === 'day' || (appSettings.themeMode === 'device' && systemScheme === 'light');
  const P = PALETAS[cardLight ? 'dia' : 'noche'];

  // Desde fuera: cardRef.current.capture(opciones) → PNG
  useImperativeHandle(ref, () => ({
    capture: (opts) => shotRef.current.capture(opts),
  }), []);

  /* ── Semilla del artwork: el nombre genera SU mapa (único por persona) ── */
  const seedPhase = useMemo(() => (hashStr(firstName) % 628) / 100, [firstName]);
  const cielo = useMemo(() => {
    const rnd = mulberry32(hashStr(firstName + '|cielo'));
    const out = [];
    if (!cardLight) {
      // NOCHE: estrellas (solo zona de cielo, sin tapar la foto)
      while (out.length < 18) {
        const x = 14 + rnd() * (CARD_W - 28);
        const y = 14 + rnd() * 246;
        if (Math.hypot(x - CARD_W / 2, y - 158) < 112) continue;
        out.push({ x, y, r: 0.7 + rnd() * 1.1, o: 0.10 + rnd() * 0.38 });
      }
      return out;
    }
    // DÍA: pájaros que cruzan el cielo del amanecer (también únicos por nombre)
    while (out.length < 5) {
      const x = 30 + rnd() * (CARD_W - 60);
      const y = 20 + rnd() * 205;
      if (Math.hypot(x - CARD_W / 2, y - 158) < 120) continue;  // no tapar la foto
      out.push({ x, y, s: 0.7 + rnd() * 0.8, rot: -9 + rnd() * 18, o: 0.30 + rnd() * 0.35 });
    }
    return out;
  }, [firstName, cardLight]);

  return (
    /* El ViewShot mide EXACTAMENTE lo que mide la tarjeta (CARD_W×CARD_H):
       el PNG sale recortado al arte, sin franjas negras alrededor. */
    <ViewShot
      ref={shotRef}
      options={{ format: 'png', quality: 1, pixelRatio: 3 }}
      style={styles.shareCardWrapper}
    >
      <View style={[styles.shareCard, { backgroundColor: P.cardBg }]}>
        {/* ══ ARTWORK (SVG): mapa topográfico cuya cumbre es la foto —
             anillos de nivel, cielo (estrellas o pájaros), auroras/sol,
             terreno en capas, ruta GPS con brillo, huellas y bandera.
             El nombre semilla el mapa y el contraste elige la paleta:
             noche = "LA CIMA" verde; día = "EL AMANECER" cálido. ══ */}
        <Svg width={CARD_W} height={CARD_H} style={styles.shareArt}>
          <Defs>
            <LinearGradient id="tjBg" x1="0" y1="0" x2="0.35" y2="1">
              <Stop offset="0" stopColor={P.sky[0]} />
              <Stop offset="0.55" stopColor={P.sky[1]} />
              <Stop offset="1" stopColor={P.sky[2]} />
            </LinearGradient>
            <RadialGradient id="tjGlow" cx="0.5" cy="0.5" r="0.5">
              <Stop offset="0" stopColor={P.glow[0]} stopOpacity={P.glow[1]} />
              <Stop offset="0.55" stopColor={P.glow[2]} stopOpacity={P.glow[3]} />
              <Stop offset="1" stopColor={P.glow[2]} stopOpacity="0" />
            </RadialGradient>
            <RadialGradient id="tjAuroraB" cx="0.5" cy="0.5" r="0.5">
              <Stop offset="0" stopColor={P.blobB[0]} stopOpacity={P.blobB[1]} />
              <Stop offset="1" stopColor={P.blobB[0]} stopOpacity="0" />
            </RadialGradient>
            <RadialGradient id="tjAuroraC" cx="0.5" cy="0.5" r="0.5">
              <Stop offset="0" stopColor={P.blobC[0]} stopOpacity={P.blobC[1]} />
              <Stop offset="1" stopColor={P.blobC[0]} stopOpacity="0" />
            </RadialGradient>
            <LinearGradient id="tjRuta" gradientUnits="userSpaceOnUse" x1="0" y1="500" x2={CARD_W} y2="350">
              <Stop offset="0" stopColor={P.ruta[0]} />
              <Stop offset="0.5" stopColor={P.ruta[1]} />
              <Stop offset="1" stopColor={P.ruta[2]} />
            </LinearGradient>
            <RadialGradient id="tjVig" cx="0.5" cy="0.45" r="0.78">
              <Stop offset="0.55" stopColor={P.vignette[0]} stopOpacity="0" />
              <Stop offset="1" stopColor={P.vignette[0]} stopOpacity={P.vignette[1]} />
            </RadialGradient>
          </Defs>

          <Rect width={CARD_W} height={CARD_H} fill="url(#tjBg)" />

          {/* Auroras: halo tras la foto (sol de cumbre) + esquiras bajas */}
          <Circle cx={CARD_W / 2} cy={158} r={205} fill="url(#tjGlow)" />
          <Circle cx={54} cy={474} r={170} fill="url(#tjAuroraB)" />
          <Circle cx={368} cy={492} r={150} fill="url(#tjAuroraC)" />

          {/* Cielo (único por nombre): estrellas de noche, pájaros al amanecer */}
          {cardLight
            ? cielo.map((b, i) => (
                <G
                  key={`ave-${i}`}
                  transform={`translate(${b.x.toFixed(1)} ${b.y.toFixed(1)}) rotate(${b.rot.toFixed(1)}) scale(${b.s.toFixed(2)})`}
                  opacity={b.o}
                >
                  <Path d="M-7 0 Q-3.5 -4.6 0 -0.6 Q3.5 -4.6 7 0" fill="none" stroke={P.ave} strokeWidth={1.3} strokeLinecap="round" />
                </G>
              ))
            : cielo.map((s, i) => (
                <Circle key={`st-${i}`} cx={s.x} cy={s.y} r={s.r} fill={P.astro} fillOpacity={s.o} />
              ))}

          {/* Anillos topográficos: curvas de nivel de la cumbre */}
          {TOPO_RADII.map((r, i) => (
            <Path
              key={`topo-${r}`}
              d={topoRing(CARD_W / 2, 158, r, seedPhase + i * 0.8)}
              fill="none" stroke={P.topo}
              strokeWidth={i === 0 ? 1.6 : 1.1}
              strokeOpacity={P.topoOp[i]}
              strokeDasharray={i === TOPO_RADII.length - 1 ? '3 7' : undefined}
            />
          ))}

          {/* Terreno: aristas rellenas (profundidad) + curvas de nivel */}
          <Path d={ridgePath(432, 15, seedPhase * 1.3 + 2.1, true)} fill={P.ridgeFill[0][0]} fillOpacity={P.ridgeFill[0][1]} />
          <Path d={ridgePath(466, 18, seedPhase * 0.8 + 4.4, true)} fill={P.ridgeFill[1][0]} fillOpacity={P.ridgeFill[1][1]} />
          {RIDGES.map((rg, i) => (
            <Path
              key={`ridge-${i}`}
              d={ridgePath(rg.y, rg.amp, seedPhase * (1 + i * 0.25) + i * 2.1, false)}
              fill="none" stroke={P.ridgeStroke} strokeWidth={rg.w} strokeOpacity={Math.min(0.45, rg.o * P.ridgeBoost)}
            />
          ))}

          {/* Ruta GPS: degradado + brillo por capas + trazo punteado */}
          <Path d={RUTA_GPS} fill="none" stroke="url(#tjRuta)" strokeWidth={8} strokeOpacity={0.10} strokeLinecap="round" />
          <Path d={RUTA_GPS} fill="none" stroke="url(#tjRuta)" strokeWidth={4.5} strokeOpacity={0.22} strokeLinecap="round" />
          <Path d={RUTA_GPS} fill="none" stroke="url(#tjRuta)" strokeWidth={2} strokeLinecap="round" />
          <Path d={RUTA_GPS} fill="none" stroke={P.rutaDot} strokeWidth={1.2} strokeOpacity={P.rutaDotOp} strokeDasharray="1 11" strokeLinecap="round" />
          <Circle cx={152} cy={420} r={3} fill={P.waypointFill} stroke={P.waypointStroke} strokeWidth={1.4} strokeOpacity={0.85} />
          <Circle cx={262} cy={448} r={3} fill={P.waypointFill} stroke={P.waypointStroke} strokeWidth={1.4} strokeOpacity={0.85} />
          <Circle cx={396} cy={360} r={9} fill="none" stroke={P.pulse} strokeWidth={1} strokeOpacity={0.35} />
          <Circle cx={396} cy={360} r={3.4} fill={P.pulse} />

          {/* Huellas que ascienden desde la esquina inferior izquierda */}
          {HUELLAS.map((h, i) => {
            const x = TRAIL.ax + (TRAIL.bx - TRAIL.ax) * h.t + h.side * 5.6;
            const y = TRAIL.ay + (TRAIL.by - TRAIL.ay) * h.t + h.side * 7;
            const rot = 47 + (h.side > 0 ? 5 : -4);
            return (
              <G key={`huella-${i}`} transform={`translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${rot}) scale(${h.s})`} opacity={h.o}>
                <Ellipse cx={0} cy={0} rx={4.4} ry={7.2} fill={P.huella} transform="rotate(-7)" />
                <Ellipse cx={0.8} cy={10.6} rx={3.3} ry={4.3} fill={P.huella} transform="rotate(-4 0.8 10.6)" />
              </G>
            );
          })}

          {/* Bandera de cima, plantada sobre el aro de la foto */}
          <Path d="M266 96 L266 66" stroke={P.bandera} strokeWidth={2} strokeLinecap="round" strokeOpacity={0.9} />
          <Path d="M267.5 67 L286 73.5 L267.5 80 Z" fill={P.bandera} fillOpacity={0.92} />
          <Circle cx={266} cy={97.5} r={2} fill={P.bandera} />

          {/* Textura de puntos (arriba derecha) y esquinas de galería */}
          {Array.from({ length: 4 }).map((_, row) =>
            Array.from({ length: 5 }).map((__, col) => (
              <Circle
                key={`dot-${row}-${col}`}
                cx={CARD_W - 88 + col * 13} cy={30 + row * 13} r={1.4}
                fill={P.decor} fillOpacity={P.dotOp}
              />
            ))
          )}
          <Path d="M16 46 L16 16 L46 16" fill="none" stroke={P.decor} strokeWidth={2.5} strokeOpacity={P.cornerOp} />
          <Path
            d={`M${CARD_W - 16} ${CARD_H - 46} L${CARD_W - 16} ${CARD_H - 16} L${CARD_W - 46} ${CARD_H - 16}`}
            fill="none" stroke={P.decor} strokeWidth={2.5} strokeOpacity={P.cornerOp}
          />

          <Rect width={CARD_W} height={CARD_H} fill="url(#tjVig)" />
        </Svg>

        {/* ══ SELLO DE MARCA (estilo de la tarjeta original): logo cuadrado
             redondeado + "TEAM JORGE" manuscrito con su subrayado, arriba a
             la izquierda. Solo la marca de la app: sin apellidos y sin
             "ATLETA TEAM JORGE". ══ */}
        <View style={styles.shareBrand}>
          <Image
            source={require('../assets/images/icon.png')}   // icono de la app
            style={styles.shareBrandLogo}
          />
          <View>
            <Text style={[styles.shareBrandName, { color: P.brandText }]} numberOfLines={1}>
              TEAM JORGE
            </Text>
            <View style={[styles.shareBrandUnder, { backgroundColor: P.brandUnder }]} />
          </View>
        </View>

        {/* ══ FOTO: la cumbre — aro punteado + anillo verde doble ══ */}
        <View style={styles.shareAvatarWrap}>
          <View style={[styles.shareAvatarDashed, { borderColor: P.dashed }]} />
          <View style={[styles.shareAvatarRingOut, { backgroundColor: P.ringOut, borderColor: P.ringOutBorder }]}>
            <View style={[styles.shareAvatarRingIn, { backgroundColor: P.ringIn }]}>
              {photo ? (
                <Image
                  source={{ uri: `data:image/jpeg;base64,${photo}` }}
                  style={styles.shareAvatarImg}
                />
              ) : photoURL ? (
                <Image source={{ uri: photoURL }} style={styles.shareAvatarImg} />
              ) : (
                <View style={[styles.shareAvatarImg, styles.shareAvatarFallback, { backgroundColor: P.fallback }]}>
                  <Text style={[styles.shareAvatarInitial, { color: P.initial }]}>{initial}</Text>
                </View>
              )}
            </View>
          </View>
        </View>

        {/* ══ NOMBRE de pila (sin apellidos) + subrayado a mano ══ */}
        <Text style={[styles.shareName, { fontSize: nameSize(firstName), color: P.name }]} numberOfLines={1}>
          {firstName}
        </Text>
        <View style={[styles.shareUnderline, { backgroundColor: P.underline }]} />
        <View style={[styles.shareUnderline2, { backgroundColor: P.underline2 }]} />

        {/* ══ PIE: píldora con el correo (único texto adicional) ══ */}
        <View style={styles.shareFooter}>
          <View style={[styles.shareEmailPill, { backgroundColor: P.pillBg, borderColor: P.pillBorder }]}>
            <Ionicons name="mail-outline" size={12} color={P.emailIcon} />
            <Text style={[styles.shareEmailText, { color: P.email }]} numberOfLines={1}>{email}</Text>
          </View>
        </View>
      </View>
    </ViewShot>
  );
});

// memo: una vez montada, los re-renders de Ajustes no la repintan
export default memo(ShareProfileCard);

const styles = StyleSheet.create({
  shareCardWrapper: {
    position: 'absolute',
    top: -1200,                 // fuera de pantalla; el ViewShot mide exacto
    left: 0,
    width: CARD_W,
    height: CARD_H,
    backgroundColor: 'transparent',
    overflow: 'hidden',
  },
  shareCard: {
    width: CARD_W,
    height: CARD_H,
    backgroundColor: INK,
    alignItems: 'center',
    overflow: 'hidden',
  },
  shareArt: { position: 'absolute', top: 0, left: 0 },
  shareBrand: {
    position: 'absolute', top: 24, left: 26,
    flexDirection: 'row', alignItems: 'center', gap: 12,
  },
  shareBrandLogo: { width: 40, height: 40, borderRadius: 10 },  // cuadrado redondeado
  shareBrandName: {
    fontFamily: 'Kalam-Bold',   // manuscrita, como en la tarjeta original
    fontSize: 19, letterSpacing: 2, lineHeight: 21,
  },
  shareBrandUnder: { height: 3, width: 64, borderRadius: 1.5, marginTop: 3 },
  shareAvatarWrap: {
    width: 172, height: 172, marginTop: 66,   // la foto corona el mapa
    alignItems: 'center', justifyContent: 'center',
  },
  shareAvatarDashed: {
    position: 'absolute', width: 172, height: 172, borderRadius: 86,
    borderWidth: 1.5, borderStyle: 'dashed', borderColor: GREEN + '59',
  },
  shareAvatarRingOut: {
    width: 148, height: 148, borderRadius: 74,
    backgroundColor: GREEN_LT, borderWidth: 1, borderColor: GREEN_DK,
    alignItems: 'center', justifyContent: 'center',
  },
  shareAvatarRingIn: {
    width: 140, height: 140, borderRadius: 70, backgroundColor: INK,
    alignItems: 'center', justifyContent: 'center',
  },
  shareAvatarImg: { width: 130, height: 130, borderRadius: 65 },
  shareAvatarFallback: { backgroundColor: GREEN_DK, alignItems: 'center', justifyContent: 'center' },
  shareAvatarInitial: { color: '#fff', fontSize: 54, fontWeight: '800', fontFamily: 'Kalam-Bold' },
  shareName: {
    color: '#F4F8F2', fontWeight: '900', letterSpacing: 4,
    fontFamily: 'Kalam-Bold',          // el nombre como firma manuscrita
    textTransform: 'uppercase', marginTop: 26,
    maxWidth: CARD_W - 56, textAlign: 'center',
  },
  shareUnderline: {
    height: 3.5, width: 132, backgroundColor: GREEN, borderRadius: 3,
    marginTop: 13, transform: [{ rotate: '-1.2deg' }],
  },
  shareUnderline2: {
    height: 2.5, width: 74, backgroundColor: GREEN + '70', borderRadius: 3,
    marginTop: 4, transform: [{ rotate: '-1.2deg' }],
  },
  shareFooter: { position: 'absolute', bottom: 26, alignSelf: 'center', maxWidth: CARD_W - 48 },
  shareEmailPill: {
    flexDirection: 'row', alignItems: 'center', gap: 7,
    backgroundColor: '#FFFFFF0D', borderWidth: 1, borderColor: '#FFFFFF1F',
    borderRadius: 999, paddingHorizontal: 14, paddingVertical: 7,
  },
  shareEmailText: { color: '#AEC4B4', fontSize: 11.5, letterSpacing: 0.4 },
});
