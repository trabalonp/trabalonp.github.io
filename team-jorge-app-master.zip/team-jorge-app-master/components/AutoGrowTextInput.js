// components/AutoGrowTextInput.js
// TextInput multilínea que CRECE con el texto: el título deja de cortarse a
// una línea y la descripción muestra todo lo escrito sin scrollbar interno.
// iOS no estira solo con minHeight (hay que medir), así que la altura se
// ajusta con onContentSizeChange. textAlignVertical="top" alinea arriba en
// Android, que por defecto centraba el texto en el recuadro y "tabulaba" mal.
import React, { useState } from 'react';
import { TextInput } from 'react-native';

export default function AutoGrowTextInput({ minHeight = 44, style, value, onContentSizeChange, ...rest }) {
  const [alto, setAlto] = useState(minHeight);
  return (
    <TextInput
      {...rest}
      value={value}
      multiline
      scrollEnabled={false}
      onContentSizeChange={(e) => {
        const ch = e?.nativeEvent?.contentSize?.height || 0;
        if (ch > 0) setAlto(Math.ceil(ch));
        if (onContentSizeChange) onContentSizeChange(e);
      }}
      style={[style, { height: Math.max(minHeight, alto), textAlignVertical: 'top' }]}
    />
  );
}
