// api/upload-to-intervals.js
// Sube un entreno/evento concreto de Firestore al calendario de Intervals.icu.
// Usa la MISMA lógica que la sincronización (lib/uploadWorkouts.buildPayload):
//   · Evento  → category RACE_A con deporte real (Run/Ride/Swim/Other): NUNCA
//     'Workout', que en Intervals.icu es el tipo de gimnasio/fuerza.
//   · Descanso → NOTE · resto → WORKOUT con sintaxis de pasos.
// Endpoint oficial: POST /athlete/{id}/events/bulk?upsert=true + external_id.
const admin = require('../lib/firebase');
const { getUid } = require('../lib/auth');
const { getConnection } = require('../lib/intervals');
const { buildPayload, loadAppZones } = require('../lib/uploadWorkouts');

const db = admin.firestore();
const BASE = 'https://intervals.icu/api/v1';

function authHeader(apiKey) {
  return 'Basic ' + Buffer.from(`API_KEY:${apiKey}`).toString('base64');
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método no permitido' });
  }

  try {
    const uid = await getUid(req);
    const { workoutId } = req.body;

    if (!workoutId) {
      return res.status(400).json({ error: 'Falta workoutId' });
    }

    // Leer el entreno/evento de Firestore
    const docSnap = await db.collection('entrenamientos').doc(workoutId).get();
    if (!docSnap.exists) {
      return res.status(404).json({ error: 'Entreno no encontrado' });
    }

    const workout = { id: workoutId, ...docSnap.data() };
    const connection = await getConnection(uid);

    if (!connection || !connection.apiKey) {
      return res.status(400).json({ error: 'Intervals.icu no conectado' });
    }

    const zones = await loadAppZones(db, uid);
    const { payload } = buildPayload(workout, zones, (msg) => console.warn(`[upload-to-intervals] ${msg}`));
    payload.external_id = workoutId;   // upsert: si ya existe, se actualiza

    console.log(`[upload-to-intervals] Creando evento (${workout.tipo}):`, payload);

    const headers = {
      'Authorization': authHeader(connection.apiKey),
      'Content-Type': 'application/json',
      'User-Agent': 'team-jorge-app/1.0',
    };
    const aid = connection.athleteId || 0;

    const response = await fetch(`${BASE}/athlete/${aid}/events/bulk?upsert=true`, {
      method: 'POST',
      headers,
      body: JSON.stringify([payload]),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('[upload-to-intervals] Error:', response.status, errText);
      return res.status(response.status).json({
        error: `Error creando evento: ${errText}`,
      });
    }

    const arr = await response.json().catch(() => []);
    const created = (Array.isArray(arr) ? (arr.find((x) => x && x.external_id === workoutId) || arr[0]) : arr) || {};
    console.log('[upload-to-intervals] Evento creado/actualizado:', created.id);

    // Guardar el ID del evento en Firestore para poder actualizarlo/borrarlo después
    await docSnap.ref.update({
      intervalsEventId: created.id ?? null,
      intervalsSynced: true,
    });

    return res.json({
      ok: true,
      intervalsEventId: created.id ?? null,
      message: 'Entreno/evento subido a Intervals.icu',
    });

  } catch (error) {
    console.error('[upload-to-intervals] Error:', error);
    return res.status(500).json({ error: error.message });
  }
};
