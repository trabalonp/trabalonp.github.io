// api/sync-intervals-detail.js
const admin = require('../lib/firebase');
const { getUid } = require('../lib/auth');
const { getConnection } = require('../lib/intervals');
const { fetchAndStoreDetail } = require('../lib/intervalsDetail');

const db = admin.firestore();

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método no permitido' });
  }

  try {
    const uid = await getUid(req);
    const { intervalsId } = req.body || {};

    if (!intervalsId) {
      return res.status(400).json({ error: 'Falta intervalsId' });
    }

    const docId = `intervals_${intervalsId}`;
    const docRef = db.collection('entrenamientos').doc(docId);
    const snap = await docRef.get();

    if (!snap.exists || snap.data().userId !== uid) {
      return res.status(404).json({ error: 'Actividad no encontrada' });
    }

    const connection = await getConnection(uid);

    const result = await fetchAndStoreDetail({
      admin,
      db,
      connection,
      docRef,
      activityId: intervalsId,
    });

    console.log(`[sync-intervals-detail] ${docId}: puntos=${result.puntos} vueltas=${result.vueltas}`);

    return res.json({
      ok: true,
      puntos: result.puntos,
      vueltas: result.vueltas,
    });
  } catch (error) {
    console.error('[sync-intervals-detail] Error global:', error);
    const status = error.status || 500;
    return res.status(status).json({
      error: error.message || 'Error obteniendo detalle',
    });
  }
};
