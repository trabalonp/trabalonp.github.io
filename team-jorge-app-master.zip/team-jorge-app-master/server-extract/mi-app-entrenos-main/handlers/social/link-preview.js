// api/social/link-preview.js
// Previsualización de enlaces estilo WhatsApp: el cliente del EMISOR pide aquí
// los metadatos Open Graph de una URL y los adjunta al mensaje; los receptores
// pintan la tarjeta sin volver a solicitarla.
//
// El servidor hace de "crawler" porque la app no puede (CORS en la web de
// destino) y porque así se centraliza la protección SSRF: solo se navegan
// hosts públicos (nada de localhost, IPs privadas ni metadata de nube).
//
// Sin variables nuevas: usa el despliegue existente de Vercel (Node >= 18,
// fetch nativo). Autenticación: Bearer <token de Firebase>, como presign.
const { getUid } = require('../../lib/auth');

const TIMEOUT_MS = 7000;
const MAX_HTML_BYTES = 600 * 1024;
const MAX_BYTES_DESCARGA = 5 * 1024 * 1024;
const MAX_SALTOS = 4;
const UA = 'Mozilla/5.0 (compatible; MAppEntrenos/1.0; +link-preview)';

const { ipPrivada, hostSeguro, decodar, metaContent, tituloHtml, absoluta } = require('../../lib/linkPreviewParse');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método no permitido' });
  try {
    await getUid(req);
    const { url } = req.body || {};
    if (!url || typeof url !== 'string' || url.length > 2048) {
      return res.status(400).json({ error: 'URL no válida' });
    }
    let actual = String(url).trim();
    try { await hostSeguro(actual); } catch (e) { return res.status(400).json({ error: 'URL no permitida' }); }

    // Navegación con redirecciones manuales: cada destino se vuelve a validar
    let resp = null;
    for (let salto = 0; salto <= MAX_SALTOS; salto++) {
      const ctrl = new AbortController();
      const t = setTimeout(() => { try { ctrl.abort(); } catch (e) {} }, TIMEOUT_MS);
      try {
        resp = await fetch(actual, {
          redirect: 'manual',
          signal: ctrl.signal,
          headers: { 'User-Agent': UA, Accept: 'text/html,application/xhtml+xml,image/*,*/*;q=0.8', 'Accept-Language': 'es,en;q=0.7' },
        });
      } finally { clearTimeout(t); }
      if (resp.status >= 300 && resp.status < 400) {
        const loc = resp.headers.get('location');
        if (!loc) break;
        try { actual = new URL(loc, actual).toString(); } catch (e) { break; }
        try { await hostSeguro(actual); } catch (e) { return res.status(400).json({ error: 'URL no permitida' }); }
        continue;
      }
      break;
    }
    if (!resp || !resp.ok) return res.json({ ok: true, preview: null });   // 404/403…: sin preview, no es error del chat

    const dominio = (new URL(actual).hostname || '').replace(/^www\./i, '').toLowerCase();
    const ct = String(resp.headers.get('content-type') || '').toLowerCase();
    const cl = Number(resp.headers.get('content-length') || 0);
    if (cl && cl > MAX_BYTES_DESCARGA) return res.json({ ok: true, preview: null });

    // Imagen directa: la propia imagen es la previsualización
    if (ct.startsWith('image/')) {
      return res.json({ ok: true, preview: { url: actual, titulo: null, descripcion: null, imagen: actual, dominio, sitio: null } });
    }
    if (!ct.includes('html') && !ct.includes('xml') && ct !== '') {
      return res.json({ ok: true, preview: null });
    }

    const html = (await resp.text()).slice(0, MAX_HTML_BYTES);
    const titulo = metaContent(html, ['og:title', 'twitter:title']) || tituloHtml(html);
    const descripcion = metaContent(html, ['og:description', 'twitter:description', 'description']);
    const imagen = absoluta(actual, metaContent(html, ['og:image', 'og:image:secure_url', 'og:image:url', 'twitter:image']));
    const sitio = metaContent(html, ['og:site_name']);
    const canon = absoluta(actual, metaContent(html, ['og:url'])) || actual;

    if (!titulo && !imagen) return res.json({ ok: true, preview: null });
    return res.json({
      ok: true,
      preview: {
        url: canon,
        titulo: titulo ? String(titulo).slice(0, 140) : null,
        descripcion: descripcion ? String(descripcion).slice(0, 240) : null,
        imagen: imagen || null,
        dominio,
        sitio: sitio ? String(sitio).slice(0, 60) : null,
      },
    });
  } catch (error) {
    console.error('[social/link-preview] Error:', error.message);
    // Nunca se bloquea el chat por un preview: 200 sin datos
    return res.json({ ok: true, preview: null, error: error.message });
  }
};
