// handlers/social/notify-message.js
/* Push de mensajes del chat social para que lleguen TAMBIÉN con la app
   cerrada (el listener onSnapshot solo funciona con la app abierta).
   El remitente llama aquí justo tras guardar el mensaje en Firestore; el
   servidor calcula los destinatarios (su entrenador + los atletas que
   entrena) y les envía el push con el contenido del mensaje. */
const { getUid } = require('../../lib/auth');
const push = require('../../lib/push');
const admin = require('../../lib/firebase');

const db = admin.firestore();

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método no permitido' });
  try {
    const uid = await getUid(req);
    const { messageId, texto, autorNombre } = req.body || {};

    const perfSnap = await db.collection('perfiles').doc(uid).get();
    const perfil = perfSnap.exists ? perfSnap.data() : {};
    const remitente = autorNombre || perfil.nombre || 'Alguien';

    // Destinatarios: entrenador del remitente + atletas que entrena
    const destinos = new Set();
    if (perfil.entrenador) destinos.add(perfil.entrenador);
    const atletas = await db.collection('perfiles').where('entrenador', '==', uid).get();
    atletas.forEach((d) => destinos.add(d.id));
    destinos.delete(uid);

    const cuerpo = String(texto || '').trim() || '📎 adjunto';
    let enviados = 0;
    for (const dest of destinos) {
      // sendPushToUser archiva en notificaciones y respeta el opt-out
      await push.sendPushToUser(dest, remitente, cuerpo, { kind: 'chat', messageId: messageId || null });
      enviados++;
    }
    return res.json({ ok: true, enviados });
  } catch (e) {
    console.error('[notify-message] Error:', e.message);
    return res.status(500).json({ error: e.message });
  }
};
