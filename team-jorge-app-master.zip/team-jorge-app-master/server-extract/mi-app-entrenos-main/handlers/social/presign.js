// api/social/presign.js
// URLs presignadas para subir media del Tablón Social a Cloudflare R2.
// Las claves de R2 NUNCA salen del servidor: la app pide una URL firmada y
// sube el archivo directamente al bucket (PUT). La lectura es pública por el
// dominio público del bucket (R2_PUBLIC_URL).
// Env vars en Vercel: R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY,
//                     R2_BUCKET, R2_PUBLIC_URL
const { getUid } = require('../../lib/auth');

// Require perezoso: si Vercel no instaló las deps (@aws-sdk/*), respondemos
// un 503 claro en vez de reventar con FUNCION_INVOCATION_FAILED.
let S3Client, PutObjectCommand, getSignedUrl;
try {
  ({ S3Client, PutObjectCommand } = require('@aws-sdk/client-s3'));
  ({ getSignedUrl } = require('@aws-sdk/s3-request-presigner'));
} catch (e) {
  S3Client = null;
}

const MAX_BYTES = 25 * 1024 * 1024;   // 25 MB por archivo

function r2Client() {
  return new S3Client({
    region: process.env.R2_REGION || 'auto',
    // S3-genérico: vale R2 (default), Oracle, Backblaze B2, Storj… cambiando el endpoint
    endpoint: process.env.R2_ENDPOINT || `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: process.env.R2_ACCESS_KEY_ID,
      secretAccessKey: process.env.R2_SECRET_ACCESS_KEY,
    },
  });
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método no permitido' });
  }

  try {
    const uid = await getUid(req);
    const { filename, contentType, size } = req.body || {};

    if (!filename) return res.status(400).json({ error: 'Falta filename' });
    if (Number(size) > MAX_BYTES) {
      return res.status(413).json({ error: 'Archivo demasiado grande (máx 25 MB)' });
    }
    if (!S3Client) {
      return res.status(503).json({ error: 'Dependencias @aws-sdk no instaladas en Vercel: sube el package.json del ZIP y haz un deploy NUEVO (no botón Redeploy sin build)' });
    }
    if (!process.env.R2_ACCOUNT_ID || !process.env.R2_ACCESS_KEY_ID ||
        !process.env.R2_SECRET_ACCESS_KEY || !process.env.R2_BUCKET || !process.env.R2_PUBLIC_URL) {
      return res.status(503).json({ error: 'Almacenamiento R2 no configurado en el servidor' });
    }

    const ext = (String(filename).match(/\.([a-z0-9]+)$/i) || [, 'bin'])[1].toLowerCase();
    const key = `social/${uid}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;

    const cmd = new PutObjectCommand({
      Bucket: process.env.R2_BUCKET,
      Key: key,
      ContentType: contentType || 'application/octet-stream',
    });
    const uploadUrl = await getSignedUrl(r2Client(), cmd, { expiresIn: 300 });
    const publicUrl = `${String(process.env.R2_PUBLIC_URL).replace(/\/+$/, '')}/${key}`;

    return res.json({ ok: true, uploadUrl, key, publicUrl });
  } catch (error) {
    console.error('[social/presign] Error:', error.message);
    return res.status(500).json({ error: error.message });
  }
};
