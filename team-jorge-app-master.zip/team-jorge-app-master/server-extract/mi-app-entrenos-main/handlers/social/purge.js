// api/social/purge.js
// HERRAMIENTA DE PURGA DEL CHAT — OPCIONAL y DESACTIVADA POR DEFECTO.
//
// El Tablón tiene ahora historial PERMANENTE: con la sincronización
// incremental (onSnapshot + createdAt > lastSync + paginación hacia atrás)
// la app nunca descarga el chat entero, así que el tamaño del historial no
// aumenta el coste ni la lentitud. La caducidad automática ya no es
// necesaria. Este endpoint queda dormido como herramienta de mantenimiento
// (p. ej. derecho al olvido, o si algún día se quisiera de nuevo un chat
// de mensajes temporales).
//
// Para ACTIVAR la purga harían falta 3 cosas:
//   1) RETENTION_DAYS=31 en Vercel → Environment Variables (días de vida
//      + margen; 0 o ausente = DESACTIVADO, no borra nada)
//   2) CRON_SECRET (cadena aleatoria de 16+ caracteres)
//   3) Un cron en vercel.json apuntando a /api/social/purge, p. ej.:
//      { "crons": [{ "path": "/api/social/purge", "schedule": "0 4 * * *" }] }
//
// Seguridad: Vercel envía `Authorization: Bearer <CRON_SECRET>` en cada
// invocación programada; sin ese secreto coincidiendo, 401.
//
// Doble criterio de purga (solo cuando está activada):
//   1) expiraAt (Timestamp) < ahora → mensajes antiguos que nacieron con caducidad
//   2) createdAt (ISO string) < ahora - RETENTION_DAYS → el resto
// Las copias LOCALES de cada dispositivo NO se tocan nunca.
const admin = require('../../lib/firebase');

let S3Client = null;
let DeleteObjectCommand = null;
try {
  ({ S3Client, DeleteObjectCommand } = require('@aws-sdk/client-s3'));
} catch (e) {
  S3Client = null;   // sin SDK de S3 la purga de R2 se omite (best-effort)
}

const LOTE = 300;               // docs por tanda (límite de writeBatch: 500)
const MAX_TANDAS = 40;          // tope de seguridad por ejecución (12.000 docs)

function r2Client() {
  return new S3Client({
    region: process.env.R2_REGION || 'auto',
    endpoint: process.env.R2_ENDPOINT || `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: process.env.R2_ACCESS_KEY_ID,
      secretAccessKey: process.env.R2_SECRET_ACCESS_KEY,
    },
  });
}

const claveR2 = (url) => {
  const base = String(process.env.R2_PUBLIC_URL || '').replace(/\/+$/, '');
  if (!base || !url || !url.startsWith(base + '/')) return null;
  return url.slice(base.length + 1);
};

module.exports = async (req, res) => {
  const secreto = process.env.CRON_SECRET;
  const auth = req.headers.authorization || '';
  if (!secreto || auth !== `Bearer ${secreto}`) {
    return res.status(401).json({ error: 'No autorizado' });
  }

  // Retención configurable. Por defecto DESACTIVADA: el historial del chat
  // es permanente y este endpoint no borra nada salvo RETENTION_DAYS > 0.
  const dias = Number(process.env.RETENTION_DAYS || 0);
  if (!Number.isFinite(dias) || dias <= 0) {
    console.log('[purge] desactivado (RETENTION_DAYS ausente o 0): no se borra nada');
    return res.json({ ok: true, disabled: true, message: 'Purga desactivada: define RETENTION_DAYS > 0 para activarla' });
  }

  try {
    const db = admin.firestore();
    const ahora = Date.now();
    const corteIso = new Date(ahora - dias * 86400000).toISOString();
    const ahoraTs = admin.firestore.Timestamp.fromMillis(ahora);

    let borrados = 0;
    let r2Borrados = 0;
    let r2Fallos = 0;

    const purgar = async (consulta) => {
      for (let tanda = 0; tanda < MAX_TANDAS; tanda++) {
        const snap = await consulta.limit(LOTE).get();
        if (snap.empty) break;
        const batch = db.batch();
        const claves = [];
        snap.forEach((d) => {
          batch.delete(d.ref);
          const data = d.data();
          (Array.isArray(data.media) ? data.media : []).forEach((m) => {
            const k = m && m.url ? claveR2(m.url) : null;
            if (k) claves.push(k);
          });
        });
        await batch.commit();
        borrados += snap.size;

        // R2 best-effort, en paralelo de 5 en 5
        if (S3Client && claves.length && process.env.R2_BUCKET) {
          const client = r2Client();
          for (let i = 0; i < claves.length; i += 5) {
            const grupo = claves.slice(i, i + 5);
            await Promise.all(grupo.map(async (k) => {
              try {
                await client.send(new DeleteObjectCommand({ Bucket: process.env.R2_BUCKET, Key: k }));
                r2Borrados++;
              } catch (e) { r2Fallos++; }
            }));
          }
        }
        if (snap.size < LOTE) break;
      }
    };

    // 1) Caducidad explícita (mensajes antiguos que nacieron con expiraAt)
    await purgar(db.collection('posts').where('expiraAt', '<', ahoraTs));
    // 2) Sin expiraAt: por fecha ISO de creación (corte = RETENTION_DAYS)
    await purgar(db.collection('posts').where('createdAt', '<', corteIso));

    console.log(`[purge] eliminados=${borrados} r2=${r2Borrados} r2Fallos=${r2Fallos}`);
    return res.json({ ok: true, eliminados: borrados, r2: r2Borrados, r2Fallos });
  } catch (error) {
    console.error('[purge] Error:', error.message);
    return res.status(500).json({ error: error.message });
  }
};
