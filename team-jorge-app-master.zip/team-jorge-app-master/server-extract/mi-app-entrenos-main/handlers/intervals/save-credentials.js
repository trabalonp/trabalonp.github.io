const admin = require('../../lib/firebase');
const { getUid } = require('../../lib/auth');
const { fetchAthlete } = require('../../lib/intervals');

const db = admin.firestore();

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método no permitido' });
  }

  try {
    const uid = await getUid(req);
    const { athleteId, apiKey } = req.body || {};

    if (!athleteId || !apiKey) {
      return res.status(400).json({
        error: 'Faltan athleteId o apiKey'
      });
    }

    const connection = { athleteId: athleteId.trim(), apiKey: apiKey.trim() };

    // Validamos las credenciales contra la API antes de guardarlas
    const athlete = await fetchAthlete(connection);

    await db.collection('intervals_connections').doc(uid).set({
      provider: 'intervals.icu',
      athleteId: connection.athleteId,
      apiKey: connection.apiKey,
      athleteName: athlete.name || athlete.fullName || null,
      lastSyncAt: null,
      connectedAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    return res.json({
      success: true,
      athleteName: athlete.name || athlete.fullName || null
    });
  } catch (error) {
    console.error('[intervals/save-credentials] Error:', error);

    const status = error.status || 500;

    return res.status(status).json({
      error: error.message || 'Error guardando credenciales'
    });
  }
};