const admin = require('../../lib/firebase');
const { getUid } = require('../../lib/auth');

const db = admin.firestore();

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método no permitido' });
  }

  try {
    const uid = await getUid(req);

    await db.collection('intervals_connections').doc(uid).delete();

    return res.json({ success: true });
  } catch (error) {
    console.error('[intervals/disconnect] Error:', error);

    const status = error.status || 500;

    return res.status(status).json({
      error: error.message || 'Error desconectando'
    });
  }
};