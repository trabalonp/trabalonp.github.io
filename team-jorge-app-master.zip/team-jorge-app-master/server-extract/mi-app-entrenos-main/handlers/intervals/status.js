const admin = require('../../lib/firebase');
const { getUid } = require('../../lib/auth');

const db = admin.firestore();

module.exports = async (req, res) => {
  try {
    const uid = await getUid(req);

    const snap = await db.collection('intervals_connections').doc(uid).get();

    if (!snap.exists) {
      return res.json({ connected: false });
    }

    const data = snap.data();

    return res.json({
      connected: true,
      athleteId: data.athleteId || null,
      athleteName: data.athleteName || null,
      lastSyncAt: data.lastSyncAt || null
    });
  } catch (error) {
    console.error('[intervals/status] Error:', error);

    const status = error.status || 500;

    return res.status(status).json({
      error: error.message || 'Error consultando estado'
    });
  }
};