// api/intervals/delete-event.js
// Borra un evento planificado de Intervals.icu cuando se borra en la app.
// Si falla (offline), lo deja en perfiles.pendingDeletes para el próximo sync.
const { getUid } = require('../../lib/auth');
const { getConnection } = require('../../lib/intervals');
const admin = require('../../lib/firebase');

const db = admin.firestore();
const BASE = 'https://intervals.icu/api/v1';

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método no permitido' });
  try {
    const uid = await getUid(req);
    const { eventId, targetUid } = req.body || {};
    if (!eventId) return res.status(400).json({ error: 'Falta eventId' });
    // Calendario DESTINO: por defecto el del llamante; un entrenador borra
    // eventos de sus atletas (el doc vive en el calendario del atleta, y su
    // evento de Intervals.icu se creó con la conexión DEL ATLETA).
    const destino = targetUid || uid;
    if (destino !== uid) {
      const pSnap = await db.collection('perfiles').doc(destino).get();
      const entrenador = pSnap.exists ? pSnap.data().entrenador : null;
      if (entrenador !== uid) return res.status(403).json({ error: 'Sin permiso sobre ese calendario' });
    }
    const connection = await getConnection(destino);
    if (!connection || !connection.apiKey) return res.status(400).json({ error: 'Intervals.icu no conectado' });
    const headers = {
      Authorization: 'Basic ' + Buffer.from(`API_KEY:${connection.apiKey}`).toString('base64'),
      'Content-Type': 'application/json',
      'User-Agent': 'team-jorge-app/1.0',
    };
    const r = await fetch(`${BASE}/athlete/${connection.athleteId || 0}/events/bulk-delete`, {
      method: 'PUT', headers, body: JSON.stringify([{ id: eventId }]),
    });
    if (!r.ok) {
      const t = await r.text().catch(() => '');
      throw new Error(`HTTP ${r.status} ${t.slice(0, 120)}`);
    }
    return res.json({ ok: true });
  } catch (e) {
    console.warn('[delete-event] fallo, se encola:', e.message);
    return res.status(502).json({ ok: false, error: e.message });
  }
};
