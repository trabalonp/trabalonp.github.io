// api/sync-fitness.js 
const admin = require('../lib/firebase');
const { getUid } = require('../lib/auth');
const { getConnection } = require('../lib/intervals');
const { computeAndStoreFitness } = require('../lib/fitness');

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método no permitido' });
  }
  try {
    const uid = await getUid(req);
    const connection = await getConnection(uid);
    const result = await computeAndStoreFitness({ admin, db: admin.firestore(), connection, uid });
    return res.json({ ok: true, ...result });
  } catch (error) {
    console.error('[sync-fitness] Error:', error);
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'Error calculando fitness' });
  }
};
