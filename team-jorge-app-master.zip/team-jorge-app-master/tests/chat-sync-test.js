/* Verifica el MOTOR REAL de sincronización del Tablón (services/chatSync.js
   + services/chatStore.js + services/fechasChat.js) contra un Firestore y un
   AsyncStorage simulados en memoria. Comprueba el patrón del documento
   duck.ai (chat estilo WhatsApp):
   1) Primera vez en el dispositivo: solo se descargan los 60 más recientes.
   2) Sincronización incremental: solo lo posterior a lastSync (0 docs si no
      hay nada nuevo); >300 nuevos se descargan en lotes de 300.
   3) Historial por ZONAS: bloques de 50 hacia atrás, una sola lectura por
      zona, hasMore correcto, sin duplicados, hasta completar el chat.
   4) Nunca una descarga masiva: ninguna lectura supera el lote máximo.
   5) chatStore: orden cronológico, meta persistente y eviction local a 4000.
   6) Separadores de fecha estilo WhatsApp (HOY/AYER/día de la semana/fecha
      con mes y año), tamaños, duraciones y detección de audios.
   Los archivos probados son los REALES del proyecto (se cargan con un
   transformador mínimo ESM→CJS y módulos simulados).
   Uso: node tests/chat-sync-test.js */
'use strict';
const fs = require('fs');
const path = require('path');
const Module = require('module');

let fallos = 0;
const ok = (cond, msg) => {
  if (cond) console.log('ok   ' + msg);
  else { fallos++; console.log('FALLO: ' + msg); }
};
const sum = (a) => a.reduce((x, y) => x + y, 0);

const APP = path.join(__dirname, '..', 'proyecto', 'mi-app-entrenos');

/* ── Transformador ESM→CJS mínimo (los servicios usan import/export) ── */
function transformar(src) {
  const nombres = [];
  let out = src
    .replace(/^import\s+\{\s*([^}]+?)\s*\}\s+from\s+'([^']+)';?$/gm,
      (m, ids, mod) => `const { ${ids.split(',').map((s) => s.trim()).join(', ')} } = require('${mod}');`)
    .replace(/^import\s+(\w+)\s+from\s+'([^']+)';?$/gm,
      (m, id, mod) => `const ${id} = require('${mod}').default || require('${mod}');`)
    .replace(/^export\s+async\s+function\s+(\w+)/gm, (m, n) => { nombres.push(n); return `async function ${n}`; })
    .replace(/^export\s+function\s+(\w+)/gm, (m, n) => { nombres.push(n); return `function ${n}`; })
    .replace(/^export\s+const\s+(\w+)/gm, (m, n) => { nombres.push(n); return `const ${n}`; });
  return out + `\nmodule.exports = { ${nombres.join(', ')} };\n`;
}

/* ── Firestore simulado en memoria ── */
let cloud = [];            // docs { id, data } del "servidor"
const lecturas = [];       // docs devueltos por cada getDocs (prueba de zonas)
const todasLecturas = [];  // histórico global (ninguna masiva)

function cmp(v, op, w) {
  const a = String(v), b = String(w);
  if (op === '>') return a > b;
  if (op === '<') return a < b;
  if (op === '>=') return a >= b;
  if (op === '<=') return a <= b;
  return a === b;
}
const firestoreStub = {
  collection: (db, name) => ({ __col: name }),
  where: (field, op, val) => ({ t: 'where', field, op, val }),
  orderBy: (field, dir) => ({ t: 'orderBy', field, dir: dir || 'asc' }),
  limit: (n) => ({ t: 'limit', n }),
  query: (col, ...parts) => ({ __col: col && col.__col, parts }),
  getDocs: async (q) => {
    let docs = cloud.slice();
    for (const p of q.parts) if (p.t === 'where') docs = docs.filter((d) => cmp(d.data[p.field], p.op, p.val));
    const ob = q.parts.find((p) => p.t === 'orderBy');
    if (ob) docs.sort((a, b) => (ob.dir === 'desc'
      ? String(b.data[ob.field]).localeCompare(String(a.data[ob.field]))
      : String(a.data[ob.field]).localeCompare(String(b.data[ob.field]))));
    const lim = q.parts.find((p) => p.t === 'limit');
    if (lim) docs = docs.slice(0, lim.n);
    lecturas.push(docs.length);
    todasLecturas.push(docs.length);
    return { docs: docs.map((d) => ({ id: d.id, data: () => ({ ...d.data }) })), empty: docs.length === 0, size: docs.length };
  },
};

/* ── AsyncStorage simulado ── */
const storage = new Map();
const asyncStorageStub = {
  default: {
    getItem: async (k) => (storage.has(k) ? storage.get(k) : null),
    setItem: async (k, v) => { storage.set(k, String(v)); },
    removeItem: async (k) => { storage.delete(k); },
  },
};

const STUBS = {
  'firebase/firestore': firestoreStub,
  '@react-native-async-storage/async-storage': asyncStorageStub,
};

/* ── Cargador de los archivos REALES con stubs ── */
const cache = {};
function loadReal(file) {
  if (cache[file]) return cache[file];
  const src = fs.readFileSync(file, 'utf8');
  const mod = new Module(file, null);
  mod.filename = file;
  mod.paths = Module._nodeModulePaths(path.dirname(file));
  cache[file] = mod.exports;                 // anti-ciclos
  mod._compile(transformar(src), file);
  cache[file] = mod.exports;
  return mod.exports;
}
const REALS = ['chatSync.js', 'chatStore.js', 'fechasChat.js'];
const origLoad = Module._load;
Module._load = function (request, parent) {
  if (Object.prototype.hasOwnProperty.call(STUBS, request)) return STUBS[request];
  if (request.endsWith('firebaseConfig')) return { db: { __db: true }, auth: { currentUser: null } };
  if (parent && parent.filename && (request.startsWith('./') || request.startsWith('../'))) {
    const res = path.resolve(path.dirname(parent.filename), request);
    const cand = res.endsWith('.js') ? res : res + '.js';
    if (REALS.some((n) => cand.endsWith(path.join('services', n))) && fs.existsSync(cand)) return loadReal(cand);
  }
  return origLoad.apply(this, arguments);
};

/* ── Semilla: chat de 500 mensajes (10 min entre mensajes ≈ 3.5 días) ── */
const N = 500;
const base = Date.UTC(2026, 0, 1);
for (let i = 0; i < N; i++) {
  cloud.push({
    id: 'p' + i,
    data: {
      autorUid: 'u' + (i % 5), autorNombre: 'Atleta ' + (i % 5), texto: 'msg ' + i,
      reacciones: {}, createdAt: new Date(base + i * 600000).toISOString(),
    },
  });
}

(async () => {
  const sync = loadReal(path.join(APP, 'services', 'chatSync.js'));
  const store = loadReal(path.join(APP, 'services', 'chatStore.js'));
  const fechas = loadReal(path.join(APP, 'services', 'fechasChat.js'));

  await store.chatStoreInit();

  /* ── 1) Primera vez: solo los 60 más recientes ── */
  lecturas.length = 0;
  await sync.gapSync();
  let all = await store.chatStoreAll();
  ok(all.length === 60, `primera vez: 60 mensajes en el almacén (recibidos ${all.length})`);
  ok(sum(lecturas) === 60, `primera vez: leídos del servidor exactamente 60 (leídos ${sum(lecturas)})`);
  ok(Math.max(...lecturas) === 60, `primera vez: ninguna lectura masiva (máx ${Math.max(...lecturas)})`);
  let meta = await store.chatStoreMeta();
  ok(meta.hasMore === true, 'primera vez: hasMore=true (quedan zonas antiguas)');
  ok(meta.oldestAt === cloud[N - 60].data.createdAt, 'primera vez: oldestAt = el más antiguo de los 60');
  ok(meta.lastSync === cloud[N - 1].data.createdAt, 'primera vez: lastSync = el más reciente');
  ok(all[0].id === 'p440' && all[59].id === 'p499', 'primera vez: orden cronológico correcto');

  /* ── 2) Reapertura sin cambios: 0 descargas ── */
  lecturas.length = 0;
  await sync.gapSync();
  ok(sum(lecturas) === 0, `incremental sin novedades: 0 docs leídos (leídos ${sum(lecturas)})`);
  all = await store.chatStoreAll();
  ok(all.length === 60, 'incremental sin novedades: el almacén no cambia');

  /* ── 3) Llegan 3 nuevos: solo se descargan esos 3 ── */
  for (let i = 0; i < 3; i++) {
    cloud.push({ id: 'n' + i, data: { autorUid: 'u9', texto: 'nuevo ' + i, reacciones: {}, createdAt: new Date(base + (N + i) * 600000).toISOString() } });
  }
  lecturas.length = 0;
  await sync.gapSync();
  ok(sum(lecturas) === 3, `incremental: solo los 3 nuevos (leídos ${sum(lecturas)})`);
  all = await store.chatStoreAll();
  ok(all.length === 63 && all[62].id === 'n2', 'incremental: 63 en el almacén, el último es n2');
  meta = await store.chatStoreMeta();
  ok(meta.lastSync === cloud[cloud.length - 1].data.createdAt, 'incremental: lastSync avanza al más reciente');

  /* ── 3b) Llegan 700 nuevos: lotes de 300 ── */
  for (let i = 0; i < 700; i++) {
    cloud.push({ id: 'm' + i, data: { autorUid: 'u8', texto: 'm ' + i, reacciones: {}, createdAt: new Date(base + (N + 3 + i) * 600000).toISOString() } });
  }
  lecturas.length = 0;
  await sync.gapSync();
  ok(lecturas.join(',') === '300,300,100', `incremental grande: lotes 300/300/100 (fue ${lecturas.join(',')})`);
  all = await store.chatStoreAll();
  ok(all.length === 763, `incremental grande: 763 en el almacén (hay ${all.length})`);

  /* ── 4) Zonas de historial: 50 en 50 hacia atrás ── */
  let zonas = 0;
  let total = 763;
  for (;;) {
    lecturas.length = 0;
    const r = await sync.loadOlderZone();
    zonas++;
    ok(lecturas.length === 1 && lecturas[0] <= sync.ZONA_ANTIGUOS,
      `zona ${zonas}: una sola lectura de ≤${sync.ZONA_ANTIGUOS} (leyó ${lecturas[0]})`);
    total += r.added;
    all = await store.chatStoreAll();
    ok(all.length === total, `zona ${zonas}: almacén crece en ${r.added} sin duplicados (${all.length})`);
    if (!r.hasMore) break;
    if (zonas > 30) { ok(false, 'el bucle de zonas no converge'); break; }
  }
  ok(zonas === 9, `zonas: 9 zonas cubren los 440 mensajes antiguos (fueron ${zonas})`);
  ok(all.length === cloud.length, `chat completo por zonas: ${all.length} == ${cloud.length} del servidor`);
  ok(all[0].id === 'p0', 'zonas: el mensaje más antiguo es p0');
  meta = await store.chatStoreMeta();
  ok(meta.hasMore === false, 'zonas: hasMore=false al llegar al inicio del historial');
  const rExtra = await sync.loadOlderZone();
  ok(rExtra.added === 0 && rExtra.hasMore === false, 'zonas: zona extra al inicio no aporta nada');
  ok(Math.max(...todasLecturas) <= 300, `global: ninguna lectura superó el lote máximo (${Math.max(...todasLecturas)})`);
  ok(todasLecturas[0] === 60, 'global: la primera lectura fue la página inicial de 60');

  /* ── 5) chatStore: eviction local a 4000 (nunca toca el servidor) ── */
  const muchos = [];
  const fut = base + 100 * 86400000;
  for (let i = 0; i < 4100; i++) {
    muchos.push({ id: 'x' + String(i).padStart(5, '0'), texto: 't', createdAt: new Date(fut + i * 1000).toISOString() });
  }
  await store.chatStorePut(muchos);
  all = await store.chatStoreAll();
  ok(all.length === 4000, `eviction: 4000 mensajes locales (hay ${all.length})`);
  ok(all[0].id === 'x00100' && all[3999].id === 'x04099', 'eviction: conserva los más recientes');

  /* ── 6) Separadores de fecha estilo WhatsApp + helpers ── */
  const L = (es) => es;
  const ahora = Date.now();
  ok(fechas.fmtSeparador(new Date(ahora).toISOString(), 'es-ES', L) === 'HOY', 'separador: hoy → HOY');
  ok(fechas.fmtSeparador(new Date(ahora - 86400000).toISOString(), 'es-ES', L) === 'AYER', 'separador: hace 24 h → AYER');
  const d3 = new Date(ahora - 3 * 86400000);
  const wd = d3.toLocaleDateString('es-ES', { weekday: 'long' });
  ok(fechas.fmtSeparador(d3.toISOString(), 'es-ES', L) === wd.charAt(0).toUpperCase() + wd.slice(1),
    `separador: hace 3 días → día de la semana (${wd})`);
  const d40 = new Date(ahora - 40 * 86400000);
  const largo = d40.toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });
  ok(fechas.fmtSeparador(d40.toISOString(), 'es-ES', L) === largo.charAt(0).toUpperCase() + largo.slice(1),
    `separador: hace 40 días → fecha con mes y año (${largo})`);
  ok(fechas.fmtSeparador(new Date(ahora).toISOString(), 'en-US', (es, en) => en) === 'TODAY', 'separador: inglés → TODAY');
  ok(fechas.claveDia(new Date(2026, 4, 17, 1, 0, 0).toISOString()) === fechas.claveDia(new Date(2026, 4, 17, 23, 0, 0).toISOString()),
    'claveDia: mismo día a distintas horas');
  ok(fechas.claveDia(new Date(2026, 4, 17, 23, 0, 0).toISOString()) !== fechas.claveDia(new Date(2026, 4, 18, 1, 0, 0).toISOString()),
    'claveDia: medianoche cambia la clave');
  ok(fechas.claveDia({ toDate: () => new Date(2026, 4, 17, 12) }) === '2026-4-17', 'claveDia: acepta Timestamps de Firestore');
  ok(fechas.fmtSize(500 * 1024) === '500 KB' && fechas.fmtSize(2.5 * 1024 * 1024) === '2.5 MB' && fechas.fmtSize(0) === '', 'fmtSize: KB/MB/vacío');
  ok(fechas.fmtDur(65) === '1:05' && fechas.fmtDur(0) === '0:00' && fechas.fmtDur(3599) === '59:59', 'fmtDur: mm:ss');
  ok(fechas.esAudioMedia({ contentType: 'audio/mpeg' }) === true, 'audio: por MIME');
  ok(fechas.esAudioMedia({ nombre: 'nota de voz.opus' }) === true, 'audio: por extensión');
  ok(fechas.esAudioMedia({ nombre: 'informe.pdf' }) === false, 'audio: un PDF no es audio');
  ok(fechas.extDe('informe.pdf') === 'PDF' && fechas.extDe('sinnombre') === '' && fechas.extDe('a.b.c') === 'C', 'extDe: extensión en mayúsculas');

  console.log(fallos === 0 ? `\nTODO OK (${todasLecturas.length} consultas simuladas)` : `\n${fallos} FALLOS`);
  process.exit(fallos === 0 ? 0 : 1);
})().catch((e) => { console.error('ERROR:', e); process.exit(1); });
