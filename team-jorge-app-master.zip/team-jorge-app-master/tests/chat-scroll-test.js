/* tests/chat-scroll-test.js — simulación 1:1 de la política de scroll estilo
   WhatsApp de SocialScreen.js (fix "siempre me lleva al último mensaje"):
     · onContentSizeChange: solo se sigue el chat si AUMENTAN los mensajes;
       cambios de altura (votar encuesta, reaccionar, seleccionar) no mueven
       el viewport; forzarFinalRef = mensaje propio / primera apertura;
       restaurarRef = posición guardada al volver de la pestaña "Retos".
     · onScroll: criterio "al final" (≤70 px), visibilidad del FAB ↓ y
       insignia de no vistos.
     · alFinal(forzar): suave/forzado; bandera forzar SIEMPRE antes del
       setPosts que la consume (orden determinista).
   Además comprueba a nivel de fuente que SocialScreen.js contiene las
   piezas clave del arreglo (refs, FAB chevron-down, restauración).
   Uso: node tests/chat-scroll-test.js */
'use strict';
const fs = require('fs');
const path = require('path');

let pasadas = 0;
const fallos = [];
function ok(cond, msg) {
  if (cond) { pasadas++; console.log('ok   ' + msg); }
  else { fallos.push(msg); console.log('FALLO ' + msg); }
}
function eq(a, b, msg) { ok(a === b, `${msg} (esperado ${JSON.stringify(b)}, obtenido ${JSON.stringify(a)})`); }

const MSG_H = 80;        // alto fijo por mensaje en la simulación
const VIEWPORT = 600;    // alto visible del ScrollView

/* ══════════ Chat simulado: réplica exacta de la lógica del JSX ══════════ */
function makeChat() {
  const c = {
    // refs
    enElFinalRef: { current: true },
    prevCountRef: { current: 0 },
    forzarFinalRef: { current: false },
    restaurarRef: { current: null },
    primeraCargaRef: { current: true },
    pendingFix: { current: null },
    contentH: { current: 0 },
    offsetRef: { current: 0 },
    // states
    posts: [],
    mostrarIrAbajo: false,
    nuevosSinVer: 0,
    // telemetría
    scrolls: [],          // { tipo:'end'|'to', y, animated }
    setNuevosSinVer(fn) { c.nuevosSinVer = fn(c.nuevosSinVer); },
    setMostrarIrAbajo(v) { c.mostrarIrAbajo = v; },
  };
  const fin = () => Math.max(0, c.contentH.current - VIEWPORT);
  const scrollRef = {
    current: {
      scrollToEnd: ({ animated }) => {
        c.scrolls.push({ tipo: 'end', y: fin(), animated });
        c.offsetRef.current = fin();
        eventosScroll(c.offsetRef.current);    // RN emite onScroll tras mover
      },
      scrollTo: ({ y, animated }) => {
        const yy = Math.max(0, Math.min(y, fin()));
        c.scrolls.push({ tipo: 'to', y: yy, animated });
        c.offsetRef.current = yy;
        eventosScroll(yy);
      },
    },
  };

  // ── onScroll: copia 1:1 del handler de SocialScreen ──
  function eventosScroll(y) {
    const ev = { contentOffset: { y }, layoutMeasurement: { height: VIEWPORT }, contentSize: { height: c.contentH.current } };
    c.offsetRef.current = ev.contentOffset.y;
    if (c.restaurarRef.current) return;        // remontaje en curso: no evaluar
    const dist = ev.contentSize.height - ev.layoutMeasurement.height - ev.contentOffset.y;
    c.enElFinalRef.current = dist <= 70;
    if (c.enElFinalRef.current && c.nuevosSinVer !== 0) c.setNuevosSinVer(() => 0);
    const fab = !c.enElFinalRef.current && ev.contentSize.height > ev.layoutMeasurement.height + 120;
    c.setMostrarIrAbajo(fab);
  }
  c.eventosScroll = eventosScroll;

  // ── onContentSizeChange: copia 1:1 del handler de SocialScreen ──
  c.layout = (h) => {
    c.contentH.current = h;
    const fix = c.pendingFix.current;
    if (fix) {
      c.pendingFix.current = null;
      c.prevCountRef.current = c.posts.length;
      scrollRef.current.scrollTo({ y: Math.max(0, h - fix.prevH + fix.prevOff), animated: false });
      return;
    }
    const rest = c.restaurarRef.current;
    if (rest) {
      if (h >= rest.h * 0.98) {
        c.restaurarRef.current = null;
        c.prevCountRef.current = c.posts.length;
        scrollRef.current.scrollTo({ y: rest.y, animated: false });
      }
      return;
    }
    const nuevos = c.posts.length - c.prevCountRef.current;
    c.prevCountRef.current = c.posts.length;
    if (nuevos <= 0) return;
    if (c.forzarFinalRef.current || c.enElFinalRef.current) {
      c.forzarFinalRef.current = false;
      scrollRef.current.scrollTo({ y: fin(), animated: false });
      c.scrolls[c.scrolls.length - 1].tipo = 'end';   // telemetría: fue scrollToEnd
    } else {
      c.setNuevosSinVer((n) => n + nuevos);
    }
  };

  // ── alFinal / irAlFinal: copia 1:1 (sin el setTimeout, síncrono en test) ──
  c.alFinal = (forzar = false) => {
    if (forzar || c.enElFinalRef.current) scrollRef.current.scrollTo({ y: fin(), animated: false });
  };
  c.irAlFinal = () => {
    c.setNuevosSinVer(() => 0);
    scrollRef.current.scrollTo({ y: fin(), animated: true });
  };

  // ── alto nivel: setPosts + layout (React: render → onContentSizeChange) ──
  c.setPosts = (posts) => { c.posts = posts; c.layout(posts.length * MSG_H); };

  // ── effect [tab]: guardar posición al salir de tablon ──
  c.cambiarTab = (tab) => {
    if (tab !== 'tablon') {
      c.restaurarRef.current = { y: c.offsetRef.current, h: c.contentH.current };
      return;
    }
    if (!c.restaurarRef.current) return;
    // El ScrollView REMONTA: onScroll a 0 (ignorado) + layout progresivo
    c.contentH.current = 0;
    c.eventosScroll(0);
    const objetivo = c.posts.length * MSG_H;
    c.layout(Math.min(objetivo, c.restaurarRef.current.h * 0.5));  // pasada parcial
    c.layout(objetivo);                                            // pasada completa
  };

  // ── effect de sincronización (montaje / vuelta de tab), orden real ──
  c.syncEffect = (mensajesStore, nuevosDeGapSync = []) => {
    const primera = c.primeraCargaRef.current;
    c.primeraCargaRef.current = false;
    if (primera) c.forzarFinalRef.current = true;   // ANTES del setPosts
    c.setPosts(mensajesStore);                      // reloadFromStore
    c.alFinal(primera);
    if (nuevosDeGapSync.length) c.setPosts(mensajesStore.concat(nuevosDeGapSync));  // gapSync
    c.alFinal();                                    // suave
  };

  // ── listener en vivo: llegan mensajes de otros ──
  c.mensajesEntran = (n) => {
    const posts = c.posts.concat(Array.from({ length: n }, (_, i) => ({ id: `n${Date.now()}${i}` })));
    c.setPosts(posts);
    c.alFinal();   // suave, como el listener real
  };
  return c;
}

const N = (n) => Array.from({ length: n }, (_, i) => ({ id: 'm' + i }));
const alFinalDe = (c) => Math.max(0, c.posts.length * MSG_H - VIEWPORT);

/* ══════════════════ Escenario 1: primera apertura ══════════════════ */
{
  const c = makeChat();
  c.syncEffect(N(60));
  eq(c.offsetRef.current, alFinalDe(c), '1. primera apertura → viewport al último mensaje');
  eq(c.mostrarIrAbajo, false, '1. FAB oculto al estar abajo');
  eq(c.nuevosSinVer, 0, '1. insignia a 0');
  eq(c.forzarFinalRef.current, false, '1. forzarFinal se consume en el primer layout');
  eq(c.primeraCargaRef.current, false, '1. primeraCarga ya no aplica');
}

/* ══════ Escenario 2: mensaje de otro estando abajo → se sigue ══════ */
{
  const c = makeChat();
  c.syncEffect(N(60));
  c.scrolls.length = 0;
  c.mensajesEntran(1);
  eq(c.offsetRef.current, alFinalDe(c), '2. estando abajo, un mensaje nuevo arrastra el viewport');
  ok(c.scrolls.some((s) => s.tipo === 'end'), '2. se hizo scrollToEnd');
  eq(c.nuevosSinVer, 0, '2. sin insignia');
}

/* ══════ Escenario 3+4: leyendo historial, mensajes nuevos NO arrastran ══════ */
{
  const c = makeChat();
  c.syncEffect(N(60));
  c.eventosScroll(1000);                       // el usuario sube a leer
  eq(c.enElFinalRef.current, false, '3. ya no está al final');
  eq(c.mostrarIrAbajo, true, '3. FAB ↓ visible al subir');
  c.scrolls.length = 0;
  c.mensajesEntran(2);                         // dos mensajes mientras lee
  eq(c.offsetRef.current, 1000, '4. el viewport NO se mueve (sigue en 1000)');
  ok(!c.scrolls.some((s) => s.tipo === 'end'), '4. ningún scrollToEnd');
  eq(c.nuevosSinVer, 2, '4. insignia acumula los 2 no vistos');
}

/* ══════ Escenario 5: votar encuesta (cambia altura, no nº mensajes) ══════ */
{
  const c = makeChat();
  c.syncEffect(N(60));
  c.eventosScroll(1000);
  c.scrolls.length = 0;
  c.layout(60 * MSG_H + 14);                   // la burbuja de la encuesta crece 14 px
  c.layout(60 * MSG_H + 14 - 6);               // y luego el recount ajusta
  eq(c.scrolls.length, 0, '5. votar NO provoca ningún scroll');
  eq(c.offsetRef.current, 1000, '5. el viewport sigue exactamente donde estaba');
  eq(c.nuevosSinVer, 0, '5. la insignia no cambia');
}

/* ══════ Escenario 6: seleccionar mensaje (pulsación larga) ══════ */
{
  const c = makeChat();
  c.syncEffect(N(60));
  c.eventosScroll(800);
  c.scrolls.length = 0;
  c.layout(60 * MSG_H + 4);                    // el estilo "seleccionado" añade px
  eq(c.scrolls.length, 0, '6. seleccionar NO provoca scroll');
  eq(c.offsetRef.current, 800, '6. viewport intacto al seleccionar');
}

/* ══════ Escenario 7: mensaje PROPIO leyendo historial → fuerza final ══════ */
{
  const c = makeChat();
  c.syncEffect(N(60));
  c.eventosScroll(500);                        // leyendo arriba
  c.forzarFinalRef.current = true;             // onPublicado: bandera ANTES
  c.setPosts(c.posts.concat([{ id: 'mio' }])); // reloadFromStore tras publicar
  c.alFinal(true);
  eq(c.offsetRef.current, alFinalDe(c), '7. al enviar, el viewport va al mensaje propio');
  eq(c.forzarFinalRef.current, false, '7. bandera consumida (no queda stale)');
  c.eventosScroll(c.offsetRef.current);        // onScroll posterior al salto
  eq(c.nuevosSinVer, 0, '7. insignia limpia al quedar abajo');
  eq(c.mostrarIrAbajo, false, '7. FAB oculto tras enviar');
}

/* ══════ Escenario 8: ir a "Retos" y VOLVER leyendo a mitad del chat ══════ */
{
  const c = makeChat();
  c.syncEffect(N(60));
  c.eventosScroll(1500);                       // posición de lectura
  c.scrolls.length = 0;
  c.cambiarTab('retos');                       // guarda {y:1500,h}
  ok(c.restaurarRef.current && c.restaurarRef.current.y === 1500, '8. posición guardada al salir');
  c.cambiarTab('tablon');                      // remontaje + layout progresivo
  eq(c.offsetRef.current, 1500, '8. al volver, SE RESTAURA la posición exacta (no salta al final)');
  ok(!c.scrolls.some((s) => s.tipo === 'end'), '8. ningún scrollToEnd al volver');
  eq(c.restaurarRef.current, null, '8. restauración consumida');
  c.syncEffect(c.posts);                       // el effect de sync se re-ejecuta al volver
  eq(c.offsetRef.current, 1500, '8. el re-sync al volver NO mueve el viewport');
  eq(c.mostrarIrAbajo, true, '8. FAB visible (se está a mitad del chat)');
}

/* ══════ Escenario 9: volver de "Retos" con mensajes llegados mientras ══════ */
{
  const c = makeChat();
  c.syncEffect(N(60));
  c.eventosScroll(1500);
  c.cambiarTab('retos');
  c.posts = c.posts.concat(N(3).map((m, i) => ({ ...m, id: 'fuera' + i })));  // llegan mientras
  c.cambiarTab('tablon');                      // remontaje: alto final mayor
  eq(c.offsetRef.current, 1500, '9. restaura la posición aunque el contenido creciera');
  eq(c.prevCountRef.current, c.posts.length, '9. contador sincronizado tras restaurar (sin insignia fantasma)');
}

/* ══════ Escenario 10: paginación hacia atrás (pendingFix) ══════ */
{
  const c = makeChat();
  c.syncEffect(N(60));
  c.eventosScroll(100);                        // cerca del borde superior
  c.pendingFix.current = { prevH: c.contentH.current, prevOff: c.offsetRef.current };
  c.setPosts(N(50).concat(c.posts));           // prepend de 50 antiguos
  eq(c.offsetRef.current, 100 + 50 * MSG_H, '10. al prepender, el viewport sigue en el mismo mensaje');
  eq(c.prevCountRef.current, 110, '10. prevCount sincronizado tras el fix');
  eq(c.nuevosSinVer, 0, '10. prepend no cuenta como "no visto"');
}

/* ══════ Escenario 11: pull-to-refresh arriba (no arrastra al final) ══════ */
{
  const c = makeChat();
  c.syncEffect(N(60));
  c.eventosScroll(50);                         // arriba del todo (refrescando)
  c.scrolls.length = 0;
  c.mensajesEntran(3);                         // el refresh trae 3 nuevos
  eq(c.offsetRef.current, 50, '11. refrescar NO tira al último mensaje');
  eq(c.nuevosSinVer, 3, '11. los 3 nuevos quedan en la insignia');
}

/* ══════ Escenario 12: pulsar el FAB ↓ ══════ */
{
  const c = makeChat();
  c.syncEffect(N(60));
  c.eventosScroll(200);
  c.mensajesEntran(4);
  eq(c.nuevosSinVer, 4, '12. insignia 4 antes de pulsar');
  c.irAlFinal();
  eq(c.offsetRef.current, alFinalDe(c), '12. el FAB lleva al último mensaje');
  eq(c.nuevosSinVer, 0, '12. insignia a cero al pulsar');
  c.eventosScroll(c.offsetRef.current);
  eq(c.mostrarIrAbajo, false, '12. FAB se oculta al llegar abajo');
}

/* ══════ Escenario 13: chat corto (no desborda) → sin FAB ══════ */
{
  const c = makeChat();
  c.syncEffect(N(3));                          // 240 px < viewport
  eq(c.offsetRef.current, 0, '13. chat corto: offset 0');
  eq(c.mostrarIrAbajo, false, '13. chat corto: FAB nunca visible');
  c.mensajesEntran(1);
  eq(c.offsetRef.current, 0, '13. chat corto: sigue sin scroll innecesario');
}

/* ══════════ Verificación a nivel de fuente (SocialScreen.js) ══════════ */
{
  const SRC = path.join(__dirname, '..', 'proyecto', 'mi-app-entrenos', 'screens', 'SocialScreen.js');
  const t = fs.readFileSync(SRC, 'utf8');
  ok(t.includes('restaurarRef.current = { y: offsetRef.current, h: contentH.current }'), 'S. guarda posición al salir de tablon');
  ok(t.includes('if (h >= rest.h * 0.98)'), 'S. restaura cuando el layout reproduce el alto');
  ok(t.includes('const nuevos = posts.length - prevCountRef.current;'), 'S. solo reacciona al AUMENTO de mensajes');
  ok(t.includes('if (nuevos <= 0) return;'), 'S. cambios de altura sin mensajes nuevos → nada');
  ok(t.includes('if (forzarFinalRef.current || enElFinalRef.current)'), 'S. política forzar/estaba-al-final');
  ok(t.includes('setNuevosSinVer((n) => n + nuevos);'), 'S. insignia de no vistos');
  ok(t.includes('enElFinalRef.current = dist <= 70;'), 'S. tolerancia de 70 px para "al final"');
  ok(t.includes('chevron-down'), 'S. FAB con icono chevron-down');
  ok(t.includes("backgroundColor: pressed ? 'rgba(0,0,0,0.58)' : 'rgba(0,0,0,0.42)'"), 'S. FAB con el fondo de las fichas de fecha');
  ok(t.includes('borderRadius: 21'), 'S. FAB circular 42x42');
  ok(t.includes('forzarFinalRef.current = true; reloadFromStore().then(() => alFinal(true))'), 'S. onPublicado fuerza el final');
  ok(t.includes('const primera = primeraCargaRef.current;'), 'S. solo la primera apertura fuerza el final');
  ok(t.includes('if (primera) forzarFinalRef.current = true;'), 'S. bandera forzar ANTES del setPosts (determinista)');
  ok(!/alFinal\(\);\s*\r?\n\s*await gapSync/.test(t), 'S. el sync ya no hace alFinal incondicional antes de gapSync');
  ok(t.includes('if (restaurarRef.current) return;'), 'S. onScroll ignora eventos del remontaje');
  ok(t.includes('forzarFinalRef.current = true;   // reenvío propio'), 'S. reenviar varios fuerza el final');
}

console.log(fallos.length
  ? `\n${fallos.length} FALLOS:\n - ` + fallos.join('\n - ')
  : `\nTODO OK — ${pasadas} aserciones pasadas`);
process.exit(fallos.length ? 1 : 0);
