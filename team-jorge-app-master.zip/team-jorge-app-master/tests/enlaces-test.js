/* Verifica los servicios PUROS del paquete WhatsApp 2:
   · services/enlaces.js   → detección/segmentación de enlaces pinchables
   · services/encuestas.js → recuento de votos, porcentajes, líder ("GANANDO")
   Los archivos probados son los REALES del proyecto: se cargan quitando la
   palabra `export` y añadiendo un module.exports explícito (los dos módulos
   son puros, sin imports).
   Uso: node tests/enlaces-test.js */
'use strict';
const fs = require('fs');
const path = require('path');
const Module = require('module');

let fallos = 0;
const ok = (cond, msg) => {
  if (cond) console.log('ok   ' + msg);
  else { fallos++; console.log('FALLO: ' + msg); }
};

const APP = path.join(__dirname, '..', 'proyecto', 'mi-app-entrenos');

function cargar(rel, nombres) {
  let src = fs.readFileSync(path.join(APP, rel), 'utf8');
  src = src.replace(/^export\s+/gm, '');
  src += '\nmodule.exports = { ' + nombres.join(', ') + ' };\n';
  const m = new Module(rel, null);
  m._compile(src, path.join(APP, rel));
  return m.exports;
}

const E = cargar(path.join('services', 'enlaces.js'),
  ['limpiarUrl', 'segmentar', 'extraerUrls', 'primeraUrl', 'dominioDe', 'normalizarUrl']);
const P = cargar(path.join('services', 'encuestas.js'),
  ['COLORES_ENCUESTA', 'colorOpcion', 'contarVotos']);

/* ════════════ ENLACES ════════════ */
const junta = (segs) => segs.map((s) => s.v).join('');

// Texto sin enlaces: un solo segmento
let g = E.segmentar('Hola equipo, mañana sesión de series a las 8');
ok(g.length === 1 && g[0].url === false, 'texto sin URLs: 1 segmento no-URL');
ok(junta(g) === 'Hola equipo, mañana sesión de series a las 8', 'invariante: nada se pierde');

// URL en medio del texto
g = E.segmentar('Mirad https://example.com/ruta hoy');
ok(g.length === 3 && g[1].url && g[1].v === 'https://example.com/ruta', 'URL en medio detectada');
ok(g[0].v === 'Mirad ' && g[2].v === ' hoy', 'texto alrededor intacto');
ok(junta(g) === 'Mirad https://example.com/ruta hoy', 'invariante con URL en medio');

// Puntuación final de frase FUERA del enlace (patrón WhatsApp)
g = E.segmentar('Entra en https://example.com.');
ok(g.length === 3 && g[1].v === 'https://example.com' && g[2].v === '.', 'punto final no forma parte del enlace');
g = E.segmentar('¿Viste https://example.com?');
ok(g[1].v === 'https://example.com' && g[2].v === '?', 'interrogante final fuera del enlace');
g = E.segmentar('Dale a https://example.com, que vuela');
ok(g[1].v === 'https://example.com' && g[2].v.indexOf(',') === 0, 'coma final fuera del enlace');

// Paréntesis: los balanceados SON parte de la URL (Wikipedia); los que
// envuelven el enlace, no
g = E.segmentar('Info: https://es.wikipedia.org/wiki/Triatlón_(deporte) ok');
ok(g[1].v === 'https://es.wikipedia.org/wiki/Triatlón_(deporte)', 'paréntesis balanceados dentro de la URL');
g = E.segmentar('(https://example.com)');
ok(g[0].v === '(' && g[1].v === 'https://example.com' && g[2].v === ')', 'paréntesis envolventes fuera');
ok(junta(g) === '(https://example.com)', 'invariante con paréntesis envolventes');

// Query strings intactas
g = E.segmentar('https://example.com/ruta?a=1&b=2#seccion y ya');
ok(g[0].v === 'https://example.com/ruta?a=1&b=2#seccion', 'query string y ancla intactos');

// www. sin esquema
g = E.segmentar('entra en www.marca.com ahora');
ok(g.length === 3 && g[1].url && g[1].v === 'www.marca.com', 'www. sin esquema detectado');
ok(E.normalizarUrl('www.marca.com') === 'https://www.marca.com', 'normalizarUrl añade https://');
ok(E.normalizarUrl('http://x.com') === 'http://x.com', 'normalizarUrl no toca http://');

// Correos y textos raros NO son enlaces
g = E.segmentar('Escribe a correo@example.com para dudas');
ok(g.every((s) => !s.url), 'un email no se detecta como enlace');

// Varias URLs + extraerUrls sin duplicados
const varias = 'A https://uno.com y https://dos.com/x?y=1 y otra vez https://uno.com.';
g = E.segmentar(varias);
ok(g.filter((s) => s.url).length === 3, 'tres URLs en un mismo mensaje');
ok(junta(g) === varias, 'invariante con varias URLs');
const urls = E.extraerUrls(varias);
ok(urls.length === 2 && urls[0] === 'https://uno.com' && urls[1] === 'https://dos.com/x?y=1', 'extraerUrls: orden y sin duplicados');
ok(E.primeraUrl(varias) === 'https://uno.com', 'primeraUrl devuelve la primera');
ok(E.primeraUrl('sin enlaces') === null, 'primeraUrl sin enlaces: null');

// dominioDe
ok(E.dominioDe('https://www.marca.com/futbol/x.html?a=1') === 'marca.com', 'dominioDe quita www, ruta y query');
ok(E.dominioDe('www.as.com') === 'as.com', 'dominioDe con www. sin esquema');
ok(E.dominioDe('http://sub.dominio.es') === 'sub.dominio.es', 'dominioDe mantiene subdominios');
ok(E.dominioDe('') === '' && E.dominioDe(null) === '', 'dominioDe tolerante a vacíos');

// Tolerancia a entradas raras (nunca lanza)
ok(Array.isArray(E.segmentar(null)) && E.segmentar(null).length === 0, 'segmentar(null) no lanza');
ok(Array.isArray(E.segmentar(undefined)), 'segmentar(undefined) no lanza');
ok(E.limpiarUrl('https://x.com))') === 'https://x.com', 'limpiarUrl: paréntesis sueltos al final fuera');

/* ════════════ ENCUESTAS ════════════ */
const enc = { pregunta: '¿Domingo?', opciones: ['Largo', 'Series', 'Descanso'], votos: { u1: 0, u2: 0, u3: 2, u4: 0 } };
let r = P.contarVotos(enc, 'u3');
ok(r.total === 4, 'total de votos válidos');
ok(JSON.stringify(r.porOpcion) === '[3,0,1]', 'recuento por opción');
ok(JSON.stringify(r.porcentajes) === '[75,0,25]', 'porcentajes redondeados');
ok(JSON.stringify(r.lideres) === '[0]', 'líder único');
ok(r.mio === 2, 'mi voto detectado');

r = P.contarVotos(enc, 'u9');
ok(r.mio === null, 'si no he votado, mio=null');

// Empate: varios líderes marcados
r = P.contarVotos({ opciones: ['A', 'B'], votos: { u1: 0, u2: 1 } }, null);
ok(JSON.stringify(r.lideres) === '[0,1]' && r.max === 1, 'empate: dos líderes');

// Sin votos: sin líderes (nadie "gana" con 0 votos)
r = P.contarVotos({ opciones: ['A', 'B'], votos: {} }, null);
ok(r.total === 0 && r.lideres.length === 0 && JSON.stringify(r.porcentajes) === '[0,0]', 'encuesta sin votos');

// Votos inválidos (índices fuera de rango / basura) se ignoran
r = P.contarVotos({ opciones: ['A', 'B'], votos: { u1: 5, u2: -1, u3: 'x', u4: null, u5: 1 } }, null);
ok(r.total === 1 && JSON.stringify(r.porOpcion) === '[0,1]', 'votos inválidos ignorados');

// Encuesta ausente / rara: nunca lanza
r = P.contarVotos(null, 'u1');
ok(r.total === 0 && r.mio === null && Array.isArray(r.lideres), 'contarVotos(null) no lanza');
r = P.contarVotos({ opciones: null, votos: null }, 'u1');
ok(r.total === 0, 'opciones/votos null tolerados');

// Paleta de colores estable y cíclica
ok(P.COLORES_ENCUESTA.length === 6, 'paleta de 6 colores');
ok(P.colorOpcion(0) === P.COLORES_ENCUESTA[0] && P.colorOpcion(6) === P.COLORES_ENCUESTA[0], 'colorOpcion cíclico');
ok(P.colorOpcion(3) === P.COLORES_ENCUESTA[3], 'colorOpcion estable');

console.log(fallos === 0 ? '\nTODO OK' : '\n' + fallos + ' FALLOS');
process.exit(fallos === 0 ? 0 : 1);
