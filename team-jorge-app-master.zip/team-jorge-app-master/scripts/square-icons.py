from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
for rel in ("assets/images/icon.png", "assets/images/android-icon-foreground.png"):
    path = ROOT / rel
    with Image.open(path) as src:
        original = (src.width, src.height)
        src = src.convert("RGBA")
        side = max(src.width, src.height)
        out = Image.new("RGBA", (side, side), (0, 0, 0, 0))
        out.paste(src, (0, 0))
        out.save(path, format="PNG", optimize=True)
        print(f"{rel}: {original[0]}x{original[1]} -> {side}x{side}")
