// screens/MarcasScreen.js
/* ─────────────────────────────────────────────────────────────
   MARCAS PERSONALES v4 — estilo TrainingPeaks, local-first:
   · Pruebas POR ACTIVIDAD: actividad + métrica con menús a pantalla
     completa. Métricas por defecto tipo TrainingPeaks (800 m, 1500 m,
     3000 m, 1K, 5K, 10K, Half Marathon, Marathon — la marca es el TIEMPO)
     + métricas personalizadas gestionables (título + unidad).
   · Tarjeta de prueba: tap → abre la pantalla de detalle con la gráfica
     de PUNTOS de todas las marcas; pulsación larga → eliminar (confirmado).
   · Detalle: gráfica (área + línea + puntos de TODAS las marcas), botón
     "Añadir resultado" y HISTORIAL DETALLADO con carga procedural (15 en
     15). Editar/Eliminar por iconos y pulsación larga.
   · CACHÉ LOCAL: se pinta del perfil cacheado al instante y después se
     refresca del documento; cada escritura actualiza la caché.
   Datos en perfiles/{uid}: marcasDefs, marcasResults, marcasMetrics.
   El servidor añade resultados al detectar récords en las sincronizaciones.
   ───────────────────────────────────────────────────────────── */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator, Alert, FlatList, KeyboardAvoidingView, Modal, Platform,
  ScrollView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View,
  useColorScheme,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CartesianChart, Line, Area, Scatter } from 'victory-native';
import { doc, getDoc, setDoc, Timestamp } from 'firebase/firestore';
import SystemBars from '../components/SystemBars';
import MonthPickerModal from '../components/MonthPickerModal';
import { auth, db } from '../firebaseConfig';
import { cacheProfile, getCachedProfile } from '../services/profileCache';
import { getThemeColors, L, useAppSettings } from '../services/appSettings';

const BLUE = '#4A90E2';
const GOLD = '#F5C518';
const RED = '#E05252';
const PAGE = 15;
const p2 = (n) => String(n).padStart(2, '0');

/* Distancias clásicas de TrainingPeaks: la marca es el TIEMPO en recorrer
   la distancia (menor = mejor). */
const METRICAS_TP = [
  { id: 'tp_800',  titulo: '800 m',          distM: 800 },
  { id: 'tp_1500', titulo: '1500 m',         distM: 1500 },
  { id: 'tp_3000', titulo: '3000 m',         distM: 3000 },
  { id: 'tp_1k',   titulo: '1K',             distM: 1000 },
  { id: 'tp_5k',   titulo: '5K',             distM: 5000 },
  { id: 'tp_10k',  titulo: '10K',            distM: 10000 },
  { id: 'tp_hm',   titulo: 'Half Marathon',  distM: 21097.5 },
  { id: 'tp_mar',  titulo: 'Marathon',       distM: 42194.5 },
];
const ACTIVIDADES = ['Running', 'Ciclismo', 'Natación', 'Fuerza', 'Triatlón', 'Otro', 'Evento'];
const UNIDADES = [
  { id: 'distancia', label: 'Distancia (km)' },
  { id: 'duracion',  label: 'Duración (tiempo)' },
  { id: 'peso',      label: 'Peso (kg)' },
  { id: 'reps',      label: 'Repeticiones' },
];

const esTiempo = (def) => def.tipo === 'dist' || def.unidadTipo === 'duracion';
const esMenorMejor = (def) => esTiempo(def);

function tiempoASeg(txt) {
  const t = String(txt || '').trim();
  if (!t) return null;
  const partes = t.split(':').map((x) => x.trim());
  if (partes.some((x) => x !== '' && !Number.isFinite(Number(x)))) return null;
  let seg = 0;
  if (partes.length === 1) seg = Number(partes[0]) * 60;
  else if (partes.length === 2) seg = Number(partes[0]) * 60 + Number(partes[1] || 0);
  else seg = Number(partes[0]) * 3600 + Number(partes[1] || 0) * 60 + Number(partes[2] || 0);
  if (!Number.isFinite(seg) || seg <= 0) return null;
  return Math.round(seg);
}
function segATiempo(seg) {
  const total = Math.round(Number(seg) || 0);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const ss = total % 60;
  return h > 0 ? `${h}:${p2(m)}:${p2(ss)}` : `${m}:${p2(ss)}`;
}
function fmtValor(def, valor) {
  const v = Number(valor);
  if (!Number.isFinite(v)) return '—';
  if (esTiempo(def)) return segATiempo(v);
  if (def.unidadTipo === 'peso') return `${v.toFixed(1)} kg`;
  if (def.unidadTipo === 'reps') return `${Math.round(v)}`;
  return `${v.toFixed(2)} km`;
}
function unidadLabel(def) {
  if (def.tipo === 'dist') return L('Duración (tiempo)', 'Duration (time)');
  const u = UNIDADES.find((x) => x.id === def.unidadTipo);
  return u ? u.label : def.unidadTipo || '';
}
function parseResultado(def, txt) {
  if (esTiempo(def)) return tiempoASeg(txt);
  const n = Number(String(txt).replace(',', '.'));
  return Number.isFinite(n) && n > 0 ? n : null;
}
/* Máscara de tiempo: al teclear se corrige sola a hh:mm:ss ("4530" →
   "45:30", "12345" → "1:23:45"), igual que los pasos. */
function mascaraTiempo(txt) {
  const digitos = String(txt || '').replace(/\D/g, '').slice(0, 6);
  if (!digitos) return '';
  const n = digitos.length;
  if (n <= 2) return digitos;
  if (n <= 4) return `${digitos.slice(0, n - 2)}:${digitos.slice(n - 2)}`;
  return `${digitos.slice(0, n - 4)}:${digitos.slice(n - 4, n - 2)}:${digitos.slice(n - 2)}`;
}
const fmtFecha = (d) => `${p2(d.getDate())}/${p2(d.getMonth() + 1)}/${d.getFullYear()}`;

export default function MarcasScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const insets = useSafeAreaInsets();
  const athleteId = route.params?.athleteId;
  const currentUserId = athleteId || auth.currentUser?.uid;
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());

  const [loading, setLoading] = useState(true);
  const [defs, setDefs] = useState([]);          // pruebas: { id, actividad, titulo, tipo, distM?, unidadTipo? }
  const [results, setResults] = useState({});    // { defId: [ { id, valor, fecha, notas, workoutId? } ] }
  const [metricas, setMetricas] = useState([]);  // métricas personalizadas
  const [detalle, setDetalle] = useState(null);  // { def, editando: null }
  const [formValor, setFormValor] = useState('');
  const [formFecha, setFormFecha] = useState(new Date());
  const [formNotas, setFormNotas] = useState('');
  const [formFechaAbierta, setFormFechaAbierta] = useState(false);
  const [saving, setSaving] = useState(false);

  // ── Wizard nueva prueba + gestión de métricas ──
  const [wizard, setWizard] = useState(null);    // null | { paso: 'actividad'|'metrica', actividad? }
  const [gestionOpen, setGestionOpen] = useState(false);
  const [nuevaMetrica, setNuevaMetrica] = useState({ titulo: '', unidadTipo: 'distancia' });
  const [menuUnidad, setMenuUnidad] = useState(false);

  // ── CARGA local-first: perfil cacheado al instante → documento fresco ──
  const aplicar = useCallback((d) => {
    if (!d) return;
    setDefs(Array.isArray(d.marcasDefs) ? d.marcasDefs : []);
    setResults(d.marcasResults && typeof d.marcasResults === 'object' ? d.marcasResults : {});
    setMetricas(Array.isArray(d.marcasMetrics) ? d.marcasMetrics : []);
  }, []);

  useEffect(() => {
    let vivo = true;
    (async () => {
      try {
        const cache = (await getCachedProfile(currentUserId)) || {};
        if (!vivo) return;
        if (cache.marcasDefs) { aplicar(cache); setLoading(false); }
        const snap = await getDoc(doc(db, 'perfiles', currentUserId));
        if (!vivo) return;
        if (snap.exists()) aplicar(snap.data());
      } catch (e) {}
      if (vivo) setLoading(false);
    })();
    return () => { vivo = false; };
  }, [currentUserId, aplicar]);

  // ── Escritura: documento + caché local (la próxima entrada pinta lo nuevo) ──
  const guardarTodo = useCallback(async (nuevasDefs, nuevosResults, nuevasMetricas) => {
    const data = { marcasDefs: nuevasDefs, marcasResults: nuevosResults, marcasMetrics: nuevasMetricas };
    await setDoc(doc(db, 'perfiles', currentUserId), data, { merge: true });
    await cacheProfile(currentUserId, data);
    setDefs(nuevasDefs);
    setResults(nuevosResults);
    setMetricas(nuevasMetricas);
  }, [currentUserId]);

  // ── Crear prueba (actividad + métrica) ──
  const crearPrueba = async (actividad, metrica) => {
    const def = metrica.distM != null
      ? { id: `d_${Date.now()}`, actividad, titulo: metrica.titulo, tipo: 'dist', distM: metrica.distM }
      : { id: `d_${Date.now()}`, actividad, titulo: metrica.titulo, tipo: 'custom', unidadTipo: metrica.unidadTipo, mejorMenor: metrica.unidadTipo === 'duracion' };
    if (defs.some((x) => x.actividad === actividad && x.titulo === def.titulo)) {
      Alert.alert(L('Ya existe', 'Already exists'), L('Ya tienes esa prueba para esa actividad.', 'You already have that test for that activity.'));
      return;
    }
    await guardarTodo([...defs, def], { ...results, [def.id]: [] }, metricas);
    setWizard(null);
    setDetalle({ def, editando: null });
    setFormValor(''); setFormNotas(''); setFormFecha(new Date());
  };

  // ── Guardar resultado (nuevo o editado) ──
  const guardarResultado = async (def, editando) => {
    const valor = parseResultado(def, formValor);
    if (valor == null) {
      Alert.alert(L('Valor no válido', 'Invalid value'),
        esTiempo(def) ? L('Escribe el tiempo como 45:30 o 1:23:45.', 'Enter the time as 45:30 or 1:23:45.')
          : L('Escribe el valor numérico de la marca.', 'Enter the numeric value of the mark.'));
      return;
    }
    setSaving(true);
    try {
      const lista = [...(results[def.id] || [])];
      if (editando) {
        const i = lista.findIndex((x) => x.id === editando.id);
        if (i >= 0) lista[i] = { ...lista[i], valor, fecha: Timestamp.fromDate(formFecha), notas: formNotas.trim() };
      } else {
        lista.push({ id: `r_${Date.now()}`, valor, fecha: Timestamp.fromDate(formFecha), notas: formNotas.trim() });
      }
      lista.sort((a, b) => (a.fecha?.toMillis?.() ?? 0) - (b.fecha?.toMillis?.() ?? 0));
      await guardarTodo(defs, { ...results, [def.id]: lista }, metricas);
      setDetalle(null);
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
    finally { setSaving(false); }
  };

  const eliminarResultado = (def, res) => {
    Alert.alert(L('Eliminar resultado', 'Delete result'), L(`¿Eliminar el resultado del ${fmtFecha(res.fecha?.toDate ? res.fecha.toDate() : new Date(res.fecha))}?`, `Delete the result from ${fmtFecha(res.fecha?.toDate ? res.fecha.toDate() : new Date(res.fecha))}?`), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: () => {
        const lista = (results[def.id] || []).filter((x) => x.id !== res.id);
        guardarTodo(defs, { ...results, [def.id]: lista }, metricas);
        setDetalle(null);
      } },
    ]);
  };

  const eliminarDef = (def) => {
    Alert.alert(L('Eliminar prueba', 'Delete test'), L(`Se eliminará "${def.titulo}" con todos sus resultados.`, `"${def.titulo}" and all its results will be deleted.`), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: () => {
        const res2 = { ...results };
        delete res2[def.id];
        guardarTodo(defs.filter((x) => x.id !== def.id), res2, metricas);
        setDetalle(null);
      } },
    ]);
  };

  // ── Métricas personalizadas ──
  const crearMetrica = () => {
    const titulo = nuevaMetrica.titulo.trim();
    if (!titulo) { Alert.alert(L('Falta el título', 'Title required'), L('Escribe el título de la métrica.', 'Type the metric title.')); return; }
    if (metricas.some((m) => m.titulo.toLowerCase() === titulo.toLowerCase())) {
      Alert.alert(L('Ya existe', 'Already exists'), L('Ya tienes una métrica con ese título.', 'A metric with that title already exists.'));
      return;
    }
    setMetricas([...metricas, { id: `mtr_${Date.now()}`, titulo, unidadTipo: nuevaMetrica.unidadTipo }]);
    setNuevaMetrica({ titulo: '', unidadTipo: 'distancia' });
  };
  const eliminarMetrica = (m) => {
    Alert.alert(L('Eliminar métrica', 'Delete metric'), L(`¿Eliminar la métrica "${m.titulo}"?`, `Delete metric "${m.titulo}"?`), [
      { text: L('Cancelar', 'Cancel'), style: 'cancel' },
      { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: () => setMetricas(metricas.filter((x) => x.id !== m.id)) },
    ]);
  };

  // ── Derivados ──
  const porActividad = useMemo(() => {
    const map = new Map();
    for (const d of defs) {
      if (!map.has(d.actividad)) map.set(d.actividad, []);
      map.get(d.actividad).push(d);
    }
    return [...map.entries()].sort((a, b) => String(a[0]).localeCompare(String(b[0])));
  }, [defs]);

  const mejoresDe = (def) => {
    const lista = [...(results[def.id] || [])].sort((a, b) => (a.fecha?.toMillis?.() ?? 0) - (b.fecha?.toMillis?.() ?? 0));
    const vals = lista.map((x) => x.valor).filter(Number.isFinite);
    const mejor = vals.length ? (esMenorMejor(def) ? Math.min(...vals) : Math.max(...vals)) : null;
    const mejorRes = mejor != null ? lista.find((x) => x.valor === mejor) : null;
    return { lista, mejor, mejorRes };
  };

  return (
    <KeyboardAvoidingView style={[st.container, { backgroundColor: theme.background }]} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      {/* ── Cabecera ── */}
      <View style={[st.header, { borderBottomColor: theme.border, paddingTop: insets.top + 6 }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={24} color="#8FA8C8" />
        </TouchableOpacity>
        <Text style={[st.headerTitle, { color: theme.text }]}>{L('Marcas personales', 'Personal records')}</Text>
        <TouchableOpacity onPress={() => setWizard({ paso: 'actividad' })}>
          <Ionicons name="add-circle" size={26} color={BLUE} />
        </TouchableOpacity>
      </View>

      <ScrollView style={st.scroll} contentContainerStyle={{ paddingBottom: insets.bottom + 40 }} keyboardShouldPersistTaps="handled">
        {defs.length === 0 && (
          <View style={st.centro}>
            <MaterialCommunityIcons name="medal-outline" size={52} color={theme.muted} />
            <Text style={[st.txt, { color: theme.muted, textAlign: 'center' }]}>
              {L('Añade una prueba para empezar a registrar tus marcas y ver tu evolución.', 'Add a test to start logging your marks and see your progress.')}
            </Text>
          </View>
        )}

        {porActividad.map(([actividad, lista]) => (
          <View key={actividad} style={{ marginBottom: 16 }}>
            <Text style={[st.seccionActividad, { color: theme.muted }]}>{actividad}</Text>
            {lista.map((def) => {
              const { lista: ordenadas, mejor, mejorRes } = mejoresDe(def);
              return (
                <TouchableOpacity
                  key={def.id}
                  style={[st.tarjeta, { backgroundColor: theme.card, borderColor: theme.border }]}
                  onPress={() => { setDetalle({ def, editando: null }); setFormValor(''); setFormNotas(''); setFormFecha(new Date()); }}
                  onLongPress={() => eliminarDef(def)}
                  delayLongPress={350}
                  activeOpacity={0.8}
                >
                  <MaterialCommunityIcons name="medal-outline" size={20} color={GOLD} />
                  <View style={{ flex: 1 }}>
                    <Text style={[st.tarjetaNombre, { color: theme.text }]} numberOfLines={1}>{def.titulo}</Text>
                    {mejor != null && (
                      <Text style={[st.mejorGrande, { color: theme.text }]}>{fmtValor(def, mejor)}</Text>
                    )}
                    <Text style={[st.tarjetaMeta, { color: theme.muted }]}>
                      {mejorRes?.fecha
                        ? `${L('Récord', 'Record')} · ${fmtFecha(mejorRes.fecha?.toDate ? mejorRes.fecha.toDate() : new Date(mejorRes.fecha))}`
                        : L('Sin resultados todavía', 'No results yet')}
                    </Text>
                  </View>
                  <TouchableOpacity style={[st.boton, { backgroundColor: BLUE }]}
                    onPress={() => { setDetalle({ def, editando: null }); setFormValor(''); setFormNotas(''); setFormFecha(new Date()); }}>
                    <Ionicons name="add" size={15} color="#fff" />
                    <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>{L('Resultado', 'Result')}</Text>
                  </TouchableOpacity>
                </TouchableOpacity>
              );
            })}
          </View>
        ))}

        {defs.length > 0 && (
          <TouchableOpacity style={[st.botonAniadir, { borderColor: theme.border }]} onPress={() => setWizard({ paso: 'actividad' })}>
            <Ionicons name="add-circle-outline" size={20} color={BLUE} />
            <Text style={{ color: BLUE, fontWeight: '700' }}>{L('Nueva prueba', 'New test')}</Text>
          </TouchableOpacity>
        )}
      </ScrollView>

      {/* ── Wizard A PANTALLA COMPLETA: nueva prueba (actividad → métrica) ── */}
      <Modal visible={!!wizard} animationType="slide" onRequestClose={() => setWizard(null)}>
        {wizard && (
        <View style={{ flex: 1, backgroundColor: theme.background, paddingTop: insets.top }}>
          <View style={[st.wHeader, { borderBottomColor: theme.border }]}>
            <TouchableOpacity onPress={() => (wizard.paso === 'metrica' ? setWizard({ paso: 'actividad' }) : setWizard(null))}>
              <Ionicons name={wizard.paso === 'metrica' ? 'chevron-back' : 'close'} size={24} color="#8FA8C8" />
            </TouchableOpacity>
            <Text style={[st.wHeaderTitulo, { color: theme.text }]}>
              {wizard.paso === 'actividad' ? L('Nueva prueba', 'New test') : L('Elige la métrica', 'Choose the metric')}
            </Text>
            <View style={{ width: 24 }} />
          </View>
          <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
            {wizard.paso === 'actividad' && (
              <>
                <Text style={[st.wSub, { color: theme.muted }]}>{L('Elige la actividad', 'Choose the activity')}</Text>
                {ACTIVIDADES.map((a, i) => (
                  <TouchableOpacity key={a} style={[st.wFila, { backgroundColor: theme.card, borderColor: theme.border }]}
                    onPress={() => setWizard({ paso: 'metrica', actividad: a })} activeOpacity={0.7}>
                    <Text style={{ width: 22, color: theme.muted, fontWeight: '700' }}>{i + 1}</Text>
                    <Text style={{ color: theme.text, fontSize: 16, fontWeight: '600', flex: 1 }}>{a}</Text>
                    <Ionicons name="chevron-forward" size={16} color={theme.muted} />
                  </TouchableOpacity>
                ))}
              </>
            )}
            {wizard.paso === 'metrica' && (
              <>
                <Text style={[st.wSub, { color: theme.muted }]}>
                  {L('Elige la métrica de la prueba', 'Choose the test metric')} — {wizard.actividad}
                </Text>
                {METRICAS_TP.map((m, i) => {
                  const ya = defs.some((d) => d.actividad === wizard.actividad && d.titulo === m.titulo);
                  return (
                    <TouchableOpacity key={m.id} disabled={ya}
                      style={[st.wFila, { backgroundColor: theme.card, borderColor: theme.border }, ya && { opacity: 0.35 }]}
                      onPress={() => crearPrueba(wizard.actividad, m)} activeOpacity={0.7}>
                      <Text style={{ width: 22, color: theme.muted, fontWeight: '700' }}>{i + 1}</Text>
                      <View style={{ flex: 1 }}>
                        <Text style={{ color: theme.text, fontSize: 16, fontWeight: '600' }}>{m.titulo}</Text>
                        <Text style={{ color: theme.muted, fontSize: 11 }}>
                          {L('Marca: tiempo en recorrer la distancia', 'Mark: time to cover the distance')}
                        </Text>
                      </View>
                      {ya && <Ionicons name="checkmark-circle" size={18} color={BLUE} />}
                    </TouchableOpacity>
                  );
                })}
                {metricas.map((m, i) => {
                  const ya = defs.some((d) => d.actividad === wizard.actividad && d.titulo === m.titulo);
                  return (
                    <TouchableOpacity key={m.id} disabled={ya}
                      style={[st.wFila, { backgroundColor: theme.card, borderColor: theme.border }, ya && { opacity: 0.35 }]}
                      onPress={() => crearPrueba(wizard.actividad, { id: m.id, titulo: m.titulo, unidadTipo: m.unidadTipo })} activeOpacity={0.7}>
                      <Text style={{ width: 22, color: theme.muted, fontWeight: '700' }}>{METRICAS_TP.length + i + 1}</Text>
                      <View style={{ flex: 1 }}>
                        <Text style={{ color: theme.text, fontSize: 16, fontWeight: '600' }}>{m.titulo}</Text>
                        <Text style={{ color: theme.muted, fontSize: 11 }}>
                          {(UNIDADES.find((u) => u.id === m.unidadTipo) || UNIDADES[0]).label}
                        </Text>
                      </View>
                      {ya && <Ionicons name="checkmark-circle" size={18} color={BLUE} />}
                    </TouchableOpacity>
                  );
                })}
                <TouchableOpacity style={[st.wFila, { borderStyle: 'dashed' }]}
                  onPress={() => setGestionOpen(true)} activeOpacity={0.7}>
                  <Ionicons name="settings-outline" size={18} color={theme.muted} />
                  <Text style={{ color: theme.muted, fontSize: 15, fontWeight: '700', flex: 1 }}>
                    {L('Gestionar métricas', 'Manage metrics')}
                  </Text>
                  <Ionicons name="chevron-forward" size={16} color={theme.muted} />
                </TouchableOpacity>
              </>
            )}
          </ScrollView>
        </View>
        )}
      </Modal>

      {/* ── Gestionar métricas A PANTALLA COMPLETA (dos secciones) ── */}
      <Modal visible={gestionOpen} animationType="slide" onRequestClose={() => setGestionOpen(false)}>
        <View style={{ flex: 1, backgroundColor: theme.background, paddingTop: insets.top }}>
          <View style={[st.wHeader, { borderBottomColor: theme.border }]}>
            <TouchableOpacity onPress={() => setGestionOpen(false)}>
              <Ionicons name="chevron-back" size={24} color="#8FA8C8" />
            </TouchableOpacity>
            <Text style={[st.wHeaderTitulo, { color: theme.text }]}>{L('Gestionar métricas', 'Manage metrics')}</Text>
            <View style={{ width: 24 }} />
          </View>
          <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
            {/* SECCIÓN 1: métricas creadas */}
            <Text style={[st.wSub, { color: theme.muted }]}>{L('TUS MÉTRICAS PERSONALIZADAS', 'YOUR CUSTOM METRICS')}</Text>
            {metricas.length === 0 && (
              <Text style={{ color: theme.muted, fontSize: 13, paddingVertical: 10 }}>
                {L('Todavía no has creado métricas personalizadas.', 'You have no custom metrics yet.')}
              </Text>
            )}
            {metricas.map((m) => (
              <View key={m.id} style={[st.wFila, { backgroundColor: theme.card, borderColor: theme.border }]}>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: theme.text, fontSize: 16, fontWeight: '700' }} numberOfLines={1}>{m.titulo}</Text>
                  <Text style={{ color: theme.muted, fontSize: 12, marginTop: 2 }}>
                    {(UNIDADES.find((u) => u.id === m.unidadTipo) || UNIDADES[0]).label}
                  </Text>
                </View>
                <TouchableOpacity onPress={() => eliminarMetrica(m)} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                  <Ionicons name="trash-outline" size={18} color={RED} />
                </TouchableOpacity>
              </View>
            ))}
            {/* SECCIÓN 2: añadir nueva métrica */}
            <Text style={[st.wSub, { color: theme.muted, marginTop: 20 }]}>
              {L('AÑADIR NUEVA MÉTRICA', 'ADD NEW METRIC')}
            </Text>
            <Text style={{ color: theme.muted, fontSize: 12, marginBottom: 8 }}>
              {L('Se añadirá al desplegable de métricas al crear una prueba.', 'It will appear in the metric dropdown when creating a test.')}
            </Text>
            <Text style={{ color: theme.muted, fontSize: 11, fontWeight: '700', marginBottom: 4 }}>{L('Título', 'Title')}</Text>
            <TextInput
              style={[st.input, { color: theme.text, borderColor: theme.border, backgroundColor: theme.card }]}
              value={nuevaMetrica.titulo}
              onChangeText={(t) => setNuevaMetrica((m) => ({ ...m, titulo: t }))}
              placeholder={L('Ej: Peso muerto, Natación 500 m…', 'e.g. Deadlift, 500 m swim…')}
              placeholderTextColor="#4A6080"
            />
            <Text style={{ color: theme.muted, fontSize: 11, fontWeight: '700', marginTop: 12, marginBottom: 4 }}>
              {L('Unidad de medida', 'Unit of measure')}
            </Text>
            <TouchableOpacity
              style={[st.input, { color: theme.text, borderColor: theme.border, backgroundColor: theme.card, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }]}
              onPress={() => setMenuUnidad(true)} activeOpacity={0.7}
            >
              <Text style={{ color: theme.text, fontSize: 14 }}>
                {(UNIDADES.find((u) => u.id === nuevaMetrica.unidadTipo) || UNIDADES[0]).label}
              </Text>
              <Ionicons name="chevron-down" size={16} color={theme.muted} />
            </TouchableOpacity>
            <TouchableOpacity
              style={[st.boton, { backgroundColor: BLUE, marginTop: 16, opacity: nuevaMetrica.titulo.trim() ? 1 : 0.4 }]}
              disabled={!nuevaMetrica.titulo.trim()}
              onPress={crearMetrica}
            >
              <Ionicons name="add" size={16} color="#fff" />
              <Text style={{ color: '#fff', fontWeight: '800' }}>{L('Añadir métrica', 'Add metric')}</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </Modal>

      {/* ── Menú GRANDE: unidad de medida ── */}
      <Modal visible={menuUnidad} transparent animationType="fade" onRequestClose={() => setMenuUnidad(false)}>
        <TouchableOpacity style={st.ov} activeOpacity={1} onPress={() => setMenuUnidad(false)}>
          <TouchableOpacity activeOpacity={1} onPress={() => {}} style={[st.caja, { backgroundColor: theme.card }]}>
            <Text style={[st.cajaTitulo, { color: theme.text }]}>{L('Unidad de medida', 'Unit of measure')}</Text>
            {UNIDADES.map((u) => (
              <TouchableOpacity key={u.id} style={st.menuFila} onPress={() => { setNuevaMetrica((m) => ({ ...m, unidadTipo: u.id })); setMenuUnidad(false); }}>
                <Text style={{ color: nuevaMetrica.unidadTipo === u.id ? BLUE : theme.text, flex: 1, fontSize: 15, fontWeight: nuevaMetrica.unidadTipo === u.id ? '800' : '400' }}>{u.label}</Text>
                {nuevaMetrica.unidadTipo === u.id && <Ionicons name="checkmark" size={16} color={BLUE} />}
              </TouchableOpacity>
            ))}
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      {/* ── Detalle de prueba: gráfica de puntos + añadir/editar + historial ── */}
      <Modal visible={!!detalle} animationType="slide" onRequestClose={() => setDetalle(null)}>
        <DetallePrueba
          def={detalle?.def}
          results={detalle?.def ? (results[detalle.def.id] || []) : []}
          theme={theme}
          onClose={() => setDetalle(null)}
          onGuardarResultado={guardarResultado}
          onEliminarResultado={eliminarResultado}
          form={{ valor: formValor, setValor: setFormValor, fecha: formFecha, setFecha: setFormFecha, notas: formNotas, setNotas: setFormNotas, abierta: formFechaAbierta, setAbierta: setFormFechaAbierta, saving }}
        />
      </Modal>

      {/* Calendario para la fecha del resultado */}
      <MonthPickerModal
        visible={formFechaAbierta}
        initialDate={formFecha}
        onClose={() => setFormFechaAbierta(false)}
        onSelect={(d) => { setFormFecha(d); setFormFechaAbierta(false); }}
      />
      <SystemBars />
    </KeyboardAvoidingView>
  );
}

/* ── Detalle de una prueba: gráfica de PUNTOS con todas las marcas + form
      (Unidad / Resultado / Fecha / Notas) + HISTORIAL procedural (15 en 15).
      Pulsación larga e iconos → Editar o Eliminar. ── */
function DetallePrueba({ def, results, theme, onClose, onGuardarResultado, onEliminarResultado, form }) {
  const isLight = theme.background === '#F4F7FB';
  const [numVisible, setNumVisible] = useState(PAGE);
  const [editando, setEditando] = useState(null); // resultado en edición
  const barraAlta = Platform.OS === 'android' ? (StatusBar.currentHeight || 0) : 24;

  if (!def) return null;

  const ordenadas = [...results].sort((a, b) => (a.fecha?.toMillis?.() ?? 0) - (b.fecha?.toMillis?.() ?? 0));
  const serie = ordenadas.map((m, i) => ({ x: i, v: m.valor }));
  const historial = [...ordenadas].reverse();   // últimas primero
  const visibles = historial.slice(0, numVisible);

  const abrirEdicion = (res) => {
    setEditando(res);
    form.setValor(esTiempo(def) ? segATiempo(res.valor) : String(res.valor));
    form.setFecha(res.fecha?.toDate ? res.fecha.toDate() : new Date(res.fecha));
    form.setNotas(res.notas || '');
  };
  const cerrarForm = () => { setEditando(null); form.setValor(''); form.setNotas(''); form.setFecha(new Date()); };

  return (
    <View style={{ flex: 1, backgroundColor: theme.background }}>
      {/* Cabecera: debajo de la barra de estado de Android (no se solapa) */}
      <View style={[st.dHeader, { borderBottomColor: theme.border, paddingTop: barraAlta + 10 }]}>
        <TouchableOpacity onPress={onClose}>
          <Ionicons name="chevron-back" size={24} color="#8FA8C8" />
        </TouchableOpacity>
        <Text style={[st.dTitulo, { color: theme.text }]} numberOfLines={1}>{def.titulo}</Text>
        <View style={{ width: 24 }} />
      </View>

      <FlatList
        data={visibles}
        keyExtractor={(r) => r.id}
        contentContainerStyle={{ paddingBottom: 40 }}
        onEndReached={() => { if (numVisible < historial.length) setNumVisible((n) => n + PAGE); }}
        onEndReachedThreshold={0.25}
        ListHeaderComponent={(
          <View style={{ padding: 14, gap: 12 }}>
            {/* Gráfica de PUNTOS con todas las marcas (área + línea + puntos) */}
            {serie.length >= 2 ? (
              <View style={[st.chartWrap, { backgroundColor: theme.card }]}>
                <CartesianChart data={serie} xKey="x" yKeys={['v']} domainPadding={{ top: 14, bottom: 6 }}>
                  {({ points }) => (
                    <>
                      <Area points={points.v} color={BLUE} opacity={0.2} />
                      <Line points={points.v} color={BLUE} strokeWidth={2.6} curve="monotone" />
                      <Scatter points={points.v} size={5} color={isLight ? BLUE : '#E8EDF5'} />
                    </>
                  )}
                </CartesianChart>
                <View style={st.chartFechas}>
                  <Text style={{ color: theme.muted, fontSize: 10 }}>
                    {ordenadas[0] ? fmtFecha(ordenadas[0].fecha?.toDate ? ordenadas[0].fecha.toDate() : new Date(ordenadas[0].fecha)) : ''}
                  </Text>
                  <Text style={{ color: theme.muted, fontSize: 10 }}>
                    {ordenadas[ordenadas.length - 1] ? fmtFecha(ordenadas[ordenadas.length - 1].fecha?.toDate ? ordenadas[ordenadas.length - 1].fecha.toDate() : new Date(ordenadas[ordenadas.length - 1].fecha)) : ''}
                  </Text>
                </View>
              </View>
            ) : (
              <Text style={{ color: theme.muted, fontSize: 13, textAlign: 'center', paddingVertical: 10 }}>
                {L('Añade al menos dos resultados para ver la evolución.', 'Add at least two results to see the progress.')}
              </Text>
            )}

            {/* Formulario apilado (no cabe la fila entera en un teléfono) */}
            <Text style={[st.formTitulo, { color: theme.text }]}>{editando ? L('Editar resultado', 'Edit result') : L('Añadir resultado', 'Add result')}</Text>
            <Text style={{ color: theme.muted, fontSize: 11, fontWeight: '700' }}>{L('Unidad', 'Unit')}</Text>
            <View style={[st.unidadCaja, { backgroundColor: theme.card, borderColor: theme.border }]}>
              <Ionicons name="speedometer-outline" size={14} color="#8FA8C8" />
              <Text style={{ color: theme.text, fontSize: 13 }}>{unidadLabel(def)}</Text>
            </View>
            <Text style={{ color: theme.muted, fontSize: 11, fontWeight: '700' }}>{L('Resultado', 'Result')}</Text>
            <TextInput
              style={[st.input, { color: theme.text, borderColor: theme.border, backgroundColor: theme.card }]}
              value={form.valor}
              onChangeText={(t) => form.setValor(esTiempo(def) ? mascaraTiempo(t) : t)}
              placeholder={esTiempo(def) ? 'ej., 45:30 o 1:23:45' : '0'}
              placeholderTextColor="#4A6080"
              keyboardType="number-pad"
            />
            <Text style={{ color: theme.muted, fontSize: 11, fontWeight: '700' }}>{L('Fecha', 'Date')}</Text>
            <TouchableOpacity style={[st.input, { borderColor: theme.border, backgroundColor: theme.card, justifyContent: 'center', flexDirection: 'row', alignItems: 'center', gap: 8 }]} onPress={() => form.setAbierta(true)} activeOpacity={0.7}>
              <Ionicons name="calendar-outline" size={15} color="#8FA8C8" />
              <Text style={{ color: theme.text, fontSize: 14 }}>{fmtFecha(form.fecha)}</Text>
            </TouchableOpacity>
            <Text style={{ color: theme.muted, fontSize: 11, fontWeight: '700' }}>{L('Notas', 'Notes')}</Text>
            <TextInput
              style={[st.input, { color: theme.text, borderColor: theme.border, backgroundColor: theme.card, minHeight: 44 }]}
              value={form.notas}
              onChangeText={form.setNotas}
              placeholder={L('ej., Carrera, Entrenamiento, Con lluvia…', 'e.g. Race, Training, In the rain…')}
              placeholderTextColor="#4A6080"
              multiline
            />
            <TouchableOpacity
              style={[st.botonGuardar, { backgroundColor: BLUE, opacity: form.valor.trim() ? 1 : 0.5 }]}
              disabled={!form.valor.trim()}
              onPress={() => { onGuardarResultado(def, editando); cerrarForm(); }}
            >
              <Ionicons name="add" size={16} color="#fff" />
              <Text style={{ color: '#fff', fontWeight: '800' }}>{editando ? L('Guardar cambios', 'Save changes') : L('Añadir resultado', 'Add result')}</Text>
            </TouchableOpacity>
            <View style={[st.histCabecera, { borderBottomColor: theme.border }]}>
              <Text style={[st.histTitulo, { color: theme.muted }]}>{L('Historial', 'History')}</Text>
              <Text style={{ color: theme.muted, fontSize: 10 }}>{L('Pulsa larga para editar o eliminar', 'Long-press to edit or delete')}</Text>
            </View>
          </View>
        )}
        ListEmptyComponent={(
          <View style={{ alignItems: 'center', paddingVertical: 30, gap: 8 }}>
            <MaterialCommunityIcons name="clipboard-text-outline" size={36} color={theme.muted} />
            <Text style={{ color: theme.muted, fontSize: 13, textAlign: 'center' }}>{L('Todavía no hay resultados.', 'No results yet.')}</Text>
          </View>
        )}
        renderItem={({ item }) => {
          const fecha = item.fecha?.toDate ? item.fecha.toDate() : new Date(item.fecha);
          return (
            <TouchableOpacity
              style={[st.histFila, { backgroundColor: theme.card, borderColor: theme.border }]}
              onLongPress={() => {
                Alert.alert(
                  fmtFecha(fecha),
                  `${fmtValor(def, item.valor)}${item.notas ? `\n${item.notas}` : ''}`,
                  [
                    { text: L('Cancelar', 'Cancel'), style: 'cancel' },
                    { text: L('Editar', 'Edit'), onPress: () => abrirEdicion(item) },
                    { text: L('Eliminar', 'Delete'), style: 'destructive', onPress: () => onEliminarResultado(def, item) },
                  ]
                );
              }}
              delayLongPress={300}
              activeOpacity={0.75}
            >
              <View style={{ flex: 1 }}>
                <Text style={{ color: theme.text, fontSize: 14, fontWeight: '800' }}>{fmtValor(def, item.valor)}</Text>
                <Text style={{ color: theme.muted, fontSize: 11, marginTop: 2 }} numberOfLines={1}>
                  {fmtFecha(fecha)}{item.notas ? ` · ${item.notas}` : ''}{item.workoutId ? ` · ${L('entreno', 'workout')}` : ''}
                </Text>
              </View>
              <TouchableOpacity onPress={() => abrirEdicion(item)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                <Ionicons name="pencil-outline" size={16} color={theme.muted} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => onEliminarResultado(def, item)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                <Ionicons name="trash-outline" size={16} color={RED} />
              </TouchableOpacity>
            </TouchableOpacity>
          );
        }}
      />
      <SystemBars />
    </View>
  );
}

const st = StyleSheet.create({
  container: { flex: 1 },
  centro: { alignItems: 'center', paddingVertical: 60, gap: 14, paddingHorizontal: 24 },
  txt: { fontSize: 14, lineHeight: 20 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingBottom: 14, borderBottomWidth: 1 },
  headerTitle: { fontSize: 18, fontWeight: '800' },
  scroll: { flex: 1, padding: 14 },
  seccionActividad: { fontSize: 12, fontWeight: '800', letterSpacing: 0.8, textTransform: 'uppercase', marginBottom: 8 },
  tarjeta: { borderRadius: 14, borderWidth: 1, padding: 12, marginBottom: 10 },
  tarjetaNombre: { fontSize: 15, fontWeight: '800' },
  mejorGrande: { fontSize: 32, fontWeight: '300', marginTop: 2 },
  tarjetaMeta: { fontSize: 11, marginTop: 2 },
  chartWrap: { borderRadius: 12, padding: 8, marginTop: 10 },
  chartFechas: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 8, marginTop: 2 },
  boton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 10 },
  botonAniadir: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, padding: 13, borderWidth: 1, borderStyle: 'dashed', borderRadius: 12 },
  input: { borderWidth: 1, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 9, fontSize: 14 },
  wHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  wHeaderTitulo: { fontSize: 17, fontWeight: '800', flex: 1, textAlign: 'center' },
  wSub: { fontSize: 13, fontWeight: '800', letterSpacing: 0.5, marginBottom: 10 },
  wFila: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 15, marginBottom: 8 },
  ov: { flex: 1, backgroundColor: '#00000088', justifyContent: 'center', alignItems: 'center', padding: 24 },
  caja: { width: '100%', maxWidth: 360, borderRadius: 14, padding: 16, maxHeight: '80%' },
  cajaTitulo: { fontSize: 16, fontWeight: '800', marginBottom: 10 },
  dHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  dTitulo: { fontSize: 18, fontWeight: '800', flex: 1, textAlign: 'center' },
  formTitulo: { fontSize: 15, fontWeight: '800' },
  unidadCaja: { flexDirection: 'row', alignItems: 'center', gap: 8, borderWidth: 1, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10 },
  histCabecera: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10, paddingBottom: 6, borderBottomWidth: 1 },
  histTitulo: { fontSize: 13, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.5 },
  histFila: { flexDirection: 'row', alignItems: 'center', gap: 10, borderRadius: 10, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 10, marginBottom: 6 },
  botonGuardar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 11, borderRadius: 10 },
});
