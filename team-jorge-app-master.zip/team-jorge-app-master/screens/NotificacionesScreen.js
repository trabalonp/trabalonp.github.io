// screens/NotificacionesScreen.js
// ─────────────────────────────────────────────────────────────
// Historial de notificaciones (subcolección perfiles/<uid>/notificaciones,
// que rellena el servidor con cada push que envía). Igual que el mockup:
//   · Cabecera con flecha atrás + título "Notificaciones".
//   · Lista con icono por tipo + texto + día/hora de llegada.
//   · PROCEDURAL: carga 10 y al bajar al final carga 10 más (startAfter).
//   · Las NO leídas salen en NEGRITA.
//   · Botón "Marcar como leídas" abajo (todas las del usuario).
//   · Tocar una: la marca como leída y abre a donde remite — el entreno
//     (data.workoutId, mismo puente que el push) o la pestaña de retos
//     (data.retoId). Los avisos de sincronización no navegan a ningún sitio.
// ─────────────────────────────────────────────────────────────
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, StyleSheet, Text, TouchableOpacity, View, useColorScheme } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  collection, doc, getDocs, limit, orderBy, query, startAfter, updateDoc, where, writeBatch,
} from 'firebase/firestore';
import { auth, db } from '../firebaseConfig';
import { getThemeColors, useAppSettings, L } from '../services/appSettings';
import { setPendingWorkoutId } from '../services/deepLink';

const PAGE = 10;
const BLUE = '#4A90E2';

const ICONOS = {
  sync: 'sync',
  creado: 'fitness',
  evento: 'calendar',
  movido: 'calendar',
  modificado: 'pencil',
  apuntado: 'people',
  comentario: 'chatbubble-ellipses',
  reto: 'trophy',
};

// "hoy 6:33 pm" · "ayer 6:48 am" · "22/09/2026 6:47 pm" (formato del mockup)
function fmtFecha(d, lang) {
  const hoy = new Date();
  const mismoDia = (a, b) => a.getDate() === b.getDate() && a.getMonth() === b.getMonth() && a.getFullYear() === b.getFullYear();
  const ayer = new Date(hoy); ayer.setDate(hoy.getDate() - 1);
  const hora = (dt) => {
    const sufijo = dt.getHours() < 12 ? 'am' : 'pm';
    const h = dt.getHours() % 12 || 12;
    return `${h}:${String(dt.getMinutes()).padStart(2, '0')} ${sufijo}`;
  };
  const p2 = (n) => String(n).padStart(2, '0');
  if (mismoDia(d, hoy)) return `${lang === 'en' ? 'today' : 'hoy'} ${hora(d)}`;
  if (mismoDia(d, ayer)) return `${lang === 'en' ? 'yesterday' : 'ayer'} ${hora(d)}`;
  return `${p2(d.getDate())}/${p2(d.getMonth() + 1)}/${d.getFullYear()} ${hora(d)}`;
}

export default function NotificacionesScreen() {
  const navigation = useNavigation();
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const insets = useSafeAreaInsets();
  const lang = appSettings.language || 'es';
  const uid = auth.currentUser?.uid;

  const [items, setItems] = useState([]);
  const [lastDoc, setLastDoc] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [cargandoMas, setCargandoMas] = useState(false);
  const [fin, setFin] = useState(false);       // no queda más historial
  const [marcando, setMarcando] = useState(false);
  const [errorCarga, setErrorCarga] = useState('');

  const notificationsRef = () => collection(db, 'perfiles', uid, 'notificaciones');

  // Página de 10 (o las 10 siguientes si hay cursor). En la subcolección no
  // hace falta repetir userId ni crear un índice compuesto.
  const cargaPagina = useCallback(async (after) => {
    if (!uid) { setFin(true); return; }
    const q = after
      ? query(notificationsRef(), orderBy('createdAt', 'desc'), startAfter(after), limit(PAGE))
      : query(notificationsRef(), orderBy('createdAt', 'desc'), limit(PAGE));
    const snap = await getDocs(q);
    const lista = snap.docs.map((d) => ({
      id: d.id,
      ...d.data(),
      fecha: d.data().createdAt?.toDate?.() || new Date(),
    }));
    setItems((prev) => (after ? [...prev, ...lista] : lista));
    setLastDoc(snap.docs[snap.docs.length - 1] || null);
    if (snap.docs.length < PAGE) setFin(true);
  }, [uid]);

  useEffect(() => {
    (async () => {
      try { await cargaPagina(null); } catch (e) { console.warn('[notificaciones] lectura:', e.message); setErrorCarga(e.message || 'No se pudieron cargar las notificaciones'); }
      finally { setCargando(false); }
    })();
  }, [cargaPagina]);

  const cargarMas = async () => {
    if (cargandoMas || fin || !lastDoc) return;
    setCargandoMas(true);
    try { await cargaPagina(lastDoc); } catch (e) { console.warn('[notificaciones] siguiente página:', e.message); setErrorCarga(e.message || 'No se pudieron cargar más notificaciones'); }
    finally { setCargandoMas(false); }
  };

  // Tocar una notificación: leída + navegar a su destino si lo tiene.
  const abrir = async (n) => {
    try { await updateDoc(doc(db, 'perfiles', uid, 'notificaciones', n.id), { leido: true }); } catch (e) {}
    setItems((prev) => prev.map((x) => (x.id === n.id ? { ...x, leido: true } : x)));
    if (n.workoutId) {
      setPendingWorkoutId(n.workoutId);
      navigation.navigate('Main', { screen: 'Dashboard' });
    } else if (n.retoId) {
      navigation.navigate('Main', { screen: 'Social', params: { tab: 'retos', ts: Date.now() } });
    }
  };

  // Todas las del usuario a leído (tope de 300 por pulsación por si el
  // historial fuese enorme; las siguientes se marcan en otra pulsación).
  const marcarTodas = async () => {
    if (!uid || marcando) return;
    setMarcando(true);
    try {
      const q = query(notificationsRef(), where('leido', '==', false), limit(300));
      const snap = await getDocs(q);
      const batch = writeBatch(db);
      snap.forEach((d) => batch.update(d.ref, { leido: true }));
      await batch.commit();
      setItems((prev) => prev.map((x) => ({ ...x, leido: true })));
    } catch (e) {}
    finally { setMarcando(false); }
  };

  const quedanSinLeer = items.some((n) => !n.leido);

  const renderItem = ({ item }) => {
    const icono = ICONOS[item.kind] || 'notifications';
    const texto = item.cuerpo || item.titulo || L('Notificación', 'Notification');
    return (
      <TouchableOpacity style={[st.item, { borderBottomColor: theme.border }]} onPress={() => abrir(item)} activeOpacity={0.6}>
        <View style={[st.iconoCaja, { backgroundColor: BLUE + '22' }]}>
          <Ionicons name={icono} size={20} color={BLUE} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ color: theme.text, fontSize: 15, lineHeight: 21, fontWeight: item.leido ? '400' : '700' }} numberOfLines={3}>{texto}</Text>
          <Text style={{ color: theme.muted, fontSize: 13, marginTop: 5 }}>{fmtFecha(item.fecha, lang)}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[st.pantalla, { backgroundColor: theme.background }]}>
      {/* Cabecera: flecha atrás + título centrado (mockup) */}
      <View style={[st.cabecera, { borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Ionicons name="arrow-back" size={26} color={BLUE} />
        </TouchableOpacity>
        <Text style={[st.titulo, { color: theme.text }]}>{lang === 'en' ? 'Notifications' : 'Notificaciones'}</Text>
        <View style={{ width: 26 }} />
      </View>

      {cargando ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator color={BLUE} />
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(n) => n.id}
          renderItem={renderItem}
          contentContainerStyle={{ paddingBottom: 18 }}
          ListEmptyComponent={(
            <View style={{ alignItems: 'center', paddingVertical: 60, gap: 10 }}>
              <Ionicons name="notifications-off-outline" size={40} color={theme.muted} />
              <Text style={{ color: errorCarga ? '#E05252' : theme.muted, fontSize: 14, textAlign: 'center', paddingHorizontal: 20 }}>
                {errorCarga || L('Aún no tienes notificaciones.', 'You have no notifications yet.')}
              </Text>
            </View>
          )}
          onEndReached={cargarMas}
          onEndReachedThreshold={0.2}
          ListFooterComponent={cargandoMas ? (
            <View style={{ paddingVertical: 14 }}><ActivityIndicator color={BLUE} /></View>
          ) : null}
        />
      )}

      {/* Pie: marcar todas como leídas (mockup, botón azul) */}
      <View style={{ paddingHorizontal: 16, paddingTop: 10, paddingBottom: Math.max(12, insets.bottom) + 12, backgroundColor: theme.background }}>
        <TouchableOpacity
          onPress={marcarTodas}
          disabled={marcando || !quedanSinLeer}
          style={[st.botonLeidas, { opacity: marcando || !quedanSinLeer ? 0.5 : 1 }]}
        >
          {marcando ? <ActivityIndicator size="small" color="#fff" />
            : <Text style={st.botonLeidasTexto}>{L('Marcar como leídas', 'Mark all as read')}</Text>}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  pantalla: { flex: 1 },
  cabecera: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 56, paddingBottom: 12, borderBottomWidth: 1,
  },
  titulo: { fontSize: 18, fontWeight: '800' },
  item: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    paddingHorizontal: 16, paddingVertical: 16, borderBottomWidth: 1,
  },
  iconoCaja: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  botonLeidas: {
    backgroundColor: BLUE, borderRadius: 14, paddingVertical: 15,
    alignItems: 'center', justifyContent: 'center',
  },
  botonLeidasTexto: { color: '#fff', fontWeight: '800', fontSize: 16 },
});
