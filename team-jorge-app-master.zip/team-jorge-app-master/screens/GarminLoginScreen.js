// screens/GarminLoginScreen.js
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, Alert, ActivityIndicator,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { auth } from '../firebaseConfig';

const NAVY   = '#0D1B2A';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';
const CARD   = '#162032';

export default function GarminLoginScreen({ onSuccess, onCancel }) {
  const navigation = useNavigation();
  const currentUser = auth.currentUser;

  const [email, setEmail] = useState(currentUser?.email || '');
  const [password, setPassword] = useState('');
  const [days, setDays] = useState('7');
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Campos requeridos', 'Introduce email y contraseña de Garmin');
      return;
    }

    setLoading(true);
    try {
      await AsyncStorage.setItem('garmin_email', email.trim());
      await AsyncStorage.setItem('garmin_password', password);
      await AsyncStorage.setItem('garmin_days', days);

      Alert.alert('✅ Garmin configurado', 'Tus credenciales se han guardado correctamente.', [
        { text: 'OK', onPress: onSuccess }
      ]);
    } catch (err) {
      Alert.alert('Error', 'No se pudieron guardar las credenciales.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoBack = () => {
    if (onCancel) {
      onCancel();
    } else {
      navigation.goBack();
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={handleGoBack} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color="#8FA8C8" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Conectar con Garmin</Text>
        <View style={{ width: 40 }} />
      </View>

      <View style={styles.form}>
        <Text style={styles.label}>Email de Garmin Connect</Text>
        <TextInput
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          placeholder="tu@email.com"
          placeholderTextColor="#4A6080"
          keyboardType="email-address"
          autoCapitalize="none"
        />

        <Text style={styles.label}>Contraseña</Text>
        <TextInput
          style={styles.input}
          value={password}
          onChangeText={setPassword}
          placeholder="••••••••"
          placeholderTextColor="#4A6080"
          secureTextEntry
        />

        <Text style={styles.label}>Entrenos a sincronizar</Text>
        <TextInput
          style={styles.input}
          value={days}
          onChangeText={setDays}
          placeholder="7"
          placeholderTextColor="#4A6080"
          keyboardType="numeric"
        />

        <TouchableOpacity
          style={[styles.saveBtn, loading && styles.disabled]}
          onPress={handleSave}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.saveBtnText}>Guardar y conectar</Text>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 52, paddingBottom: 12,
    borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  backBtn: { padding: 4 },
  headerTitle: { color: '#fff', fontSize: 16, fontWeight: '700' },
  form: { padding: 24 },
  label: { color: '#8FA8C8', fontSize: 14, marginBottom: 8, marginTop: 16 },
  input: {
    backgroundColor: CARD, borderRadius: 8, borderWidth: 1, borderColor: BORDER,
    padding: 14, color: '#fff', fontSize: 15,
  },
  saveBtn: {
    backgroundColor: BLUE, borderRadius: 10, paddingVertical: 16,
    alignItems: 'center', marginTop: 32,
  },
  disabled: { opacity: 0.6 },
  saveBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});