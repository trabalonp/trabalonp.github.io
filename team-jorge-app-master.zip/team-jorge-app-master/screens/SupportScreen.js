// screens/SupportScreen.js
import React, { useState } from 'react';
import {
  ActivityIndicator, Alert, ScrollView, StyleSheet,
  Text, TextInput, TouchableOpacity, View, useColorScheme,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { addDoc, collection, Timestamp } from 'firebase/firestore';
import { auth, db } from '../firebaseConfig';
import { getThemeColors, useAppSettings } from '../services/appSettings';

const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';

// 👇 PEGA AQUÍ TU ACCESS KEY DE WEB3FORMS
const WEB3FORMS_ACCESS_KEY = '1badd76d-78ac-463b-a863-9ba3619cd5f8';

// Cabeceras que hacen que Web3Forms trate la petición como "client-side"
// (el fetch de React Native no las envía por defecto y por eso pedía Pro)
const BROWSER_HEADERS = {
  'Content-Type': 'application/json',
  'Accept': 'application/json',
  'Origin': 'https://localhost',
  'Referer': 'https://localhost/',
  'User-Agent': 'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
};

export default function SupportScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const user = auth.currentUser;
  const appSettings = useAppSettings();
  const lang = appSettings.language;
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());
  const L = (es, en) => (lang === 'en' ? en : es);

  const [asunto, setAsunto] = useState('');
  const [mensaje, setMensaje] = useState('');
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    const subject = asunto.trim();
    const body = mensaje.trim();
    if (!subject) { Alert.alert(L('Error','Error'), L('El asunto es obligatorio.','Subject is required.')); return; }
    if (!body)    { Alert.alert(L('Error','Error'), L('El mensaje es obligatorio.','Message is required.')); return; }
    if (!WEB3FORMS_ACCESS_KEY || WEB3FORMS_ACCESS_KEY.startsWith('PEGA')) {
      Alert.alert(L('Falta configurar','Setup missing'), L('Añade tu access key de Web3Forms en SupportScreen.','Add your Web3Forms access key in SupportScreen.'));
      return;
    }
    setSending(true);
    try {
      // 1) Copia interna en Firestore (registro de soporte)
      try {
        await addDoc(collection(db, 'soporte'), {
          userId: user?.uid || null,
          email: user?.email || '',
          asunto: subject,
          mensaje: body,
          createdAt: Timestamp.now(),
        });
      } catch (e) {}
      // 2) Envío silencioso a Web3Forms (directo desde la app, con cabeceras client-side)
      const res = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        headers: BROWSER_HEADERS,
        body: JSON.stringify({
          access_key: WEB3FORMS_ACCESS_KEY,
          subject,
          from_name: 'Team Jorge App',
          replyto: user?.email || '',
          email: user?.email || '',
          message: body,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) throw new Error(data?.message || L('Error al enviar el correo.','Email send error.'));
      setAsunto(''); setMensaje('');
      Alert.alert(
        L('Enviado','Sent'),
        L('Tu mensaje se ha enviado correctamente. Te responderemos a ' + (user?.email || '') + '.',
          'Your message was sent. We will reply to ' + (user?.email || '') + '.')
      );
    } catch (e) {
      Alert.alert(L('Error','Error'), e.message);
    } finally {
      setSending(false);
    }
  };

  return (
    <View style={[st.container, { backgroundColor: theme.background }]}>
      <View style={[st.header, { backgroundColor: theme.card, borderBottomColor: theme.border }]}>
        <View style={{ width: 32 }} />
        <Text style={[st.headerTitle, { color: theme.text }]}>{L('Soporte', 'Support')}</Text>
        <TouchableOpacity onPress={() => navigation.goBack()} style={st.closeBtn}>
          <Ionicons name="close" size={26} color={BLUE} />
        </TouchableOpacity>
      </View>

      <ScrollView style={st.scroll} contentContainerStyle={[st.scrollContent, { paddingBottom: Math.max(40, insets.bottom + 16) }]} showsVerticalScrollIndicator={false}>
        <Text style={[st.intro, { color: theme.muted }]}>
          {L('¿Tienes una pregunta o necesitas ayuda? Envíanos un mensaje y te responderemos lo antes posible.',
             'Have a question or need help? Send us a message and we will get back to you as soon as possible.')}
        </Text>

        <Text style={[st.label, { color: theme.text }]}>{L('Asunto', 'Subject')}</Text>
        <TextInput
          style={[st.input, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]}
          value={asunto}
          onChangeText={setAsunto}
          placeholder={L('Describe brevemente tu consulta', 'Briefly describe your query')}
          placeholderTextColor="#4A6080"
        />

        <Text style={[st.label, { color: theme.text }]}>{L('Mensaje', 'Message')}</Text>
        <TextInput
          style={[st.textarea, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]}
          value={mensaje}
          onChangeText={setMensaje}
          placeholder={L('Cuéntanos cómo podemos ayudarte...', 'Tell us how we can help you...')}
          placeholderTextColor="#4A6080"
          multiline
          textAlignVertical="top"
        />

        <TouchableOpacity style={[st.sendBtn, sending && st.disabled]} onPress={handleSend} disabled={sending}>
          {sending ? <ActivityIndicator color="#fff" /> : <Text style={st.sendBtnText}>{L('Enviar', 'Send')}</Text>}
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const st = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 56, paddingBottom: 16,
    backgroundColor: '#37474F', borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700', flex: 1, textAlign: 'center' },
  closeBtn: { padding: 4 },
  scroll: { flex: 1 },
  scrollContent: { padding: 16, paddingBottom: 40 },
  intro: { color: '#8FA8C8', fontSize: 15, lineHeight: 22, marginBottom: 20 },
  label: { color: '#fff', fontSize: 14, fontWeight: '600', marginBottom: 8 },
  input: {
    backgroundColor: 'transparent', borderRadius: 8, borderWidth: 1, borderColor: '#546E7A',
    paddingHorizontal: 14, paddingVertical: 12, color: '#fff', fontSize: 15, marginBottom: 20,
  },
  textarea: {
    backgroundColor: 'transparent', borderRadius: 8, borderWidth: 1, borderColor: '#546E7A',
    paddingHorizontal: 14, paddingVertical: 12, color: '#fff', fontSize: 15,
    minHeight: 140, marginBottom: 20,
  },
  sendBtn: { backgroundColor: '#2E6DA4', borderRadius: 8, paddingVertical: 16, alignItems: 'center' },
  sendBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  disabled: { opacity: 0.6 },
});
