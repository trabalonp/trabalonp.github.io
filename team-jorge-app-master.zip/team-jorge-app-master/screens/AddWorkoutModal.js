// screens/AddWorkoutModal.js
import { Ionicons } from '@expo/vector-icons';
import {
  addDoc, collection, Timestamp, updateDoc, deleteDoc, increment, doc, getDoc,
} from 'firebase/firestore';
import { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator, Alert, KeyboardAvoidingView, Modal, Platform,
  ScrollView, StyleSheet, Switch, Text, TextInput, TouchableOpacity, View, useColorScheme,
} from 'react-native';
import { getCachedProfile } from '../services/profileCache';
import { getApiUrl } from '../services/api';
import { getCoachFullName, sendNotificationToAthlete } from '../services/coachNotify';
import { auth, db } from '../firebaseConfig';
import AutoGrowTextInput from '../components/AutoGrowTextInput';
import LibreriaDrive, { PickerCarpetaLibreria } from '../components/LibreriaDrive';
import MonthPickerModal from '../components/MonthPickerModal';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getThemeColors, useAppSettings } from '../services/appSettings';
import StepEditor, { emptyStep, normalizeStep } from '../components/StepEditor';
import SystemBars from '../components/SystemBars';
import ActivityIcon from '../components/ActivityIcon';

const NAVY='#0D1B2A', CARD='#162032', BLUE='#4A90E2', BORDER='#1E3048', RED='#E05252';

// Valores GUARDADOS en Firestore (no se traducen): se guarda el string original y se pinta traducido
const TIPOS_ACTIVIDAD = [
  { label: 'Running', icon: 'run', color: '#E05252' },
  { label: 'Ciclismo', icon: 'bicycle', color: '#F5A623' },
  { label: 'Natación', icon: 'water', color: '#4A90E2' },
  { label: 'Fuerza', icon: 'barbell', color: '#9B59B6' },
  { label: 'Triatlón', icon: 'medal-outline', color: '#2DB37A' },
  { label: 'Evento', icon: 'trophy', color: '#4A90E2' },
  { label: 'Descanso', icon: 'moon', color: '#7F8FA6' },
  { label: 'Notas', icon: 'journal-outline', color: '#8D6E63' },
  { label: 'Otro', icon: 'flash', color: '#8FA8C8' },
];
const TIPO_ICON = { Running:'run', Ciclismo:'bicycle', Natación:'water', Fuerza:'barbell', Triatlón:'medal-outline', Otro:'flash', Evento:'trophy', Descanso:'moon', Notas:'journal-outline' };

// Picker a pantalla completa: guarda `value ?? label` y pinta la etiqueta traducida
function FullScreenPicker({ value, options, onChange, placeholder='Escoge', iconTipo, icon, iconColor, title, cancelText, theme }) {
  const insets = useSafeAreaInsets();
  const [visible, setVisible] = useState(false);
  const isObj = options[0] && typeof options[0] === 'object';
  const valOf = (o) => (isObj ? (o.value ?? o.label) : o);
  const lblOf = (o) => (isObj ? o.label : o);
  const select = (o) => { onChange(valOf(o)); setVisible(false); };
  const currentLabel = isObj ? (options.find(o => valOf(o) === value)?.label ?? value) : value;
  return (
    <>
      <TouchableOpacity style={[pk.btn, { backgroundColor: theme?.card, borderColor: theme?.border }]} onPress={() => setVisible(true)} activeOpacity={0.8}>
        <View style={pk.pickerLeft}>
          {iconTipo ? <ActivityIcon tipo={iconTipo} size={18} color={iconColor || '#8FA8C8'} style={{ marginRight: 8 }} /> : (icon ? <Ionicons name={icon} size={18} color={iconColor || '#8FA8C8'} style={{ marginRight: 8 }} /> : null)}
          <Text style={[pk.text, { color: currentLabel ? theme?.text : theme?.muted }]} numberOfLines={1}>{currentLabel || placeholder}</Text>
        </View>
        <Ionicons name="chevron-down" size={15} color="#8FA8C8" />
      </TouchableOpacity>
      <Modal visible={visible} animationType="slide" transparent={false}>
        <View style={[pk.fullScreen, { backgroundColor: theme?.background }]}>
          <View style={[pk.fullHeader, { borderBottomColor: theme?.border }]}>
            <Text style={[pk.fullTitle, { color: theme?.text }]}>{title ?? 'Selecciona una opción'}</Text>
            <TouchableOpacity onPress={() => setVisible(false)}>
              <Ionicons name="close" size={24} color="#8FA8C8" />
            </TouchableOpacity>
          </View>
          <ScrollView style={pk.fullList}>
            {options.map((o, i) => {
              const sel = valOf(o) === value;
              return (
                <TouchableOpacity key={String(valOf(o))} style={[pk.fullOption, { borderBottomColor: theme?.border }, sel && pk.fullOptionActive]} onPress={() => select(o)}>
                  <Text style={[pk.fullOptionIndex, { color: sel ? BLUE : theme?.muted }]}>{i + 1}</Text>
                  {isObj && o.icon ? <ActivityIcon tipo={valOf(o)} size={20} color={o.color || '#8FA8C8'} /> : null}
                  <Text style={[pk.fullOptionText, { color: sel ? BLUE : theme?.text }, sel && pk.fullOptionTextActive]}>{lblOf(o)}</Text>
                  {sel && <Ionicons name="checkmark" size={20} color={BLUE} />}
                </TouchableOpacity>
              );
            })}
          </ScrollView>
          <TouchableOpacity style={[pk.fullCancelBtn, { borderTopColor: theme?.border, paddingBottom: 18 + insets.bottom }]} onPress={() => setVisible(false)}>
            <Text style={pk.fullCancelText}>{cancelText ?? 'Cancelar'}</Text>
          </TouchableOpacity>
        </View>
        <SystemBars />
      </Modal>
    </>
  );
}
const pk = StyleSheet.create({
  btn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: CARD, borderRadius: 6, borderWidth: 1, borderColor: BORDER, paddingHorizontal: 12, paddingVertical: 12, marginVertical: 4 },
  pickerLeft: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  text: { color: '#fff', fontSize: 14, flex: 1 },
  ph: { color: '#4A6080' },
  fullScreen: { flex: 1, backgroundColor: NAVY },
  fullHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 56, paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: BORDER },
  fullTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  fullList: { flex: 1, paddingHorizontal: 16 },
  fullOption: { flexDirection: 'row', alignItems: 'center', paddingVertical: 16, paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: BORDER, gap: 14 },
  fullOptionActive: { backgroundColor: BLUE + '22', borderRadius: 8 },
  fullOptionIndex: { color: '#8FA8C8', fontSize: 16, fontWeight: '600', minWidth: 24 },
  fullOptionIndexActive: { color: BLUE },
  fullOptionText: { color: '#fff', fontSize: 16, flex: 1 },
  fullOptionTextActive: { color: BLUE, fontWeight: '700' },
  fullCancelBtn: { paddingVertical: 18, alignItems: 'center', borderTopWidth: 1, borderTopColor: BORDER, marginTop: 8 },
  fullCancelText: { color: RED, fontSize: 16, fontWeight: '600' },
});


export default function AddWorkoutModal({ visible, onClose, initialDate, onWorkoutAdded, athleteId }) {
  const insets = useSafeAreaInsets();
  const settings = useAppSettings();
  const theme = getThemeColors(settings.themeMode, useColorScheme());
  const lang = settings.language;            // re-renderiza al cambiar idioma
  const L = (es, en) => (lang === 'en' ? en : es);  // helper local de traducción

  const fecha = initialDate ?? new Date();
  const [loading, setLoading] = useState(false);
  const [mainTab, setMainTab] = useState('nuevo');
  const [actividad, setActividad] = useState('Running');
  const [titulo, setTitulo] = useState('');
  const [fechaStr, setFechaStr] = useState(fecha.toLocaleDateString('es-ES')); // formato de almacenamiento DD/MM/AAAA
  const [horaMode, setHoraMode] = useState('Mañana');
  const [horaCustom, setHoraCustom] = useState('08:00');
  const [descripcion, setDescripcion] = useState('');
  const [pasos, setPasos] = useState([]);

  const [saveLib, setSaveLib] = useState(false); // switch "Añadir a librería"
  const [libDocId, setLibDocId] = useState(null); // doc de libreria creado por el switch
  const [modoLibreria, setModoLibreria] = useState(false); // creando sesión NUEVA para la librería
  const [libOrigenId, setLibOrigenId] = useState(null);   // sesión de librería en edición
  const [pickerLib, setPickerLib] = useState(null);       // { accion } selector de carpeta destino
  const [calFecha, setCalFecha] = useState(false);        // calendario para elegir la fecha
  const actSel = TIPOS_ACTIVIDAD.find(t => t.label === actividad) || TIPOS_ACTIVIDAD[0];

  // Opciones de hora traducidas (el valor guardado sigue siendo el original)
  const HORA_OPTS = [
    { value: 'Mañana', label: L('Mañana', 'Morning') },
    { value: 'Tarde', label: L('Tarde', 'Afternoon') },
    { value: 'Personalizado', label: L('Personalizado', 'Custom') },
  ];

  useEffect(() => {
    if (visible) {
      const d = initialDate ?? new Date();
      setMainTab('nuevo'); setActividad('Running'); setTitulo('');
      setFechaStr(d.toLocaleDateString('es-ES')); setHoraMode('Mañana'); setHoraCustom('08:00');
      setDescripcion(''); setPasos([]); setLoading(false); setSaveLib(false); setLibDocId(null); setModoLibreria(false); setLibOrigenId(null); setPickerLib(null);
    }
  }, [visible, initialDate]);

  const horaFinal = () => horaMode === 'Mañana' ? '08:00' : horaMode === 'Tarde' ? '18:00' : (horaCustom || '08:00');

  const handleClose = () => {
    if (pasos.length > 0 || titulo) {
      Alert.alert(L('Descartar', 'Discard'), L('¿Seguro que quieres salir?', 'Are you sure you want to exit?'), [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        { text: L('Salir', 'Exit'), style: 'destructive', onPress: onClose },
      ]);
    } else onClose();
  };

  const handleSave = async () => {
    if (!titulo.trim()) { Alert.alert(L('Error', 'Error'), L('El título es obligatorio.', 'Title is required.')); return; }
    // Editando una SESIÓN de la librería: se actualiza la sesión, sin tocar
    // el calendario (de ahí vino y ahí vuelve).
    if (libOrigenId) {
      setLoading(true);
      try {
        await updateDoc(doc(db, 'libreria', libOrigenId), { tipo: actividad, titulo: titulo || actividad, descripcion: descripcion || '', pasos: pasos.map(normalizeStep) });
        setLibOrigenId(null); setMainTab('libreria');
        Alert.alert(L('Guardado', 'Saved'), L('Sesión actualizada en la librería.', 'Session updated in the library.'));
      } catch (e) { Alert.alert(L('Error', 'Error'), e.message); } finally { setLoading(false); }
      return;
    }
    // Creando una sesión NUEVA para la librería: se pide carpeta destino y
    // se guarda solo en la librería (no en el calendario).
    if (modoLibreria) { setPickerLib({ accion: 'crear' }); return; }
    setLoading(true);
    try {
      const targetUserId = athleteId || auth.currentUser?.uid;
      if (!targetUserId) { Alert.alert(L('Error', 'Error'), L('No se pudo determinar el usuario.', 'Could not determine the user.')); setLoading(false); return; }
      const partes = fechaStr.split('/');
      const fechaFinal = new Date(partes[2], partes[1] - 1, partes[0]);
      const [h, m] = horaFinal().split(':');
      fechaFinal.setHours(parseInt(h), parseInt(m || 0));
      const pasosGuardados = pasos.map(normalizeStep);
      const docNuevo = {
        userId: targetUserId,
        // Quién lo crea: si el coach lo crea en el calendario del atleta, el
        // userId es el del atleta pero creadoPor es el del coach. La app usa
        // este campo para que el atleta no pueda editarlo ni moverlo.
        creadoPor: auth.currentUser?.uid || targetUserId,
        tipo: actividad,
        titulo: titulo || actividad,
        fecha: Timestamp.fromDate(fechaFinal),
        fechaStr,
        descripcion,
        pasos: pasosGuardados,
        estado: null,
        garminSynced: false,
        createdAt: Timestamp.now(),
      };
      // Evento creado en el calendario de un atleta: el atleta entra directo
      // en la lista de apuntados del evento
      if (athleteId && actividad === 'Evento') docNuevo.asignados = [athleteId];
      const refNew = await addDoc(collection(db, 'entrenamientos'), docNuevo);
      if (saveLib && libDocId) {
        try {
          await updateDoc(doc(db, 'libreria', libDocId), { tipo: actividad, titulo: titulo || actividad, descripcion: descripcion || '', pasos: pasosGuardados, workoutId: refNew.id });
        } catch (e) {}
      }
      if (onWorkoutAdded) onWorkoutAdded();
      if (athleteId) {
        const coachName = await getCoachFullName(auth.currentUser.uid);
        // El título/cuerpo los compone el servidor en el idioma del atleta,
        // y en "creado"/"evento" ya incluye el día para el que se programó.
        await sendNotificationToAthlete(athleteId, auth.currentUser.uid, {
          kind: actividad === 'Evento' ? 'evento' : 'creado',
          coachName,
          nombre: titulo || actividad,
          fechaStr,
          workoutId: refNew.id,
        });
      }
      onClose();
    } catch (e) {
      Alert.alert(L('Error', 'Error'), e.message);
    } finally { setLoading(false); }
  };

  const handleToggleLib = async (value) => {
    if (!value) {
      // OFF: se quita de la librería lo que se añadió con este switch
      setSaveLib(false);
      if (libDocId) { try { await deleteDoc(doc(db, 'libreria', libDocId)); } catch (e) {} setLibDocId(null); }
      return;
    }
    // ON: primero se elige la CARPETA destino; el doc se crea al elegir.
    setPickerLib({ accion: 'switch' });
  };

  // Carpeta elegida en el selector: crea la sesión en la librería.
  const elegirCarpetaParaGuardar = async (carpetaId) => {
    const uid = auth.currentUser?.uid; if (!uid) return;
    try {
      const base = { userId: uid, carpeta: carpetaId, tipo: actividad, titulo: titulo || actividad, descripcion: descripcion || '', pasos: pasos.map(normalizeStep), timesUsed: 0, createdAt: Timestamp.now() };
      if (pickerLib?.accion === 'switch') {
        const ref = await addDoc(collection(db, 'libreria'), base);
        setLibDocId(ref.id); setSaveLib(true);
        Alert.alert(L('Guardado', 'Saved'), L('Entrenamiento guardado en tu librería.', 'Workout saved to your library.'));
      } else {
        // Sesión nueva creada desde la librería: se guarda y se vuelve al listado.
        await addDoc(collection(db, 'libreria'), base);
        setModoLibreria(false);
        setMainTab('libreria');
      }
    } catch (e) { Alert.alert(L('Error', 'Error'), e.message); }
  };

  const handleLoadFromLibrary = async (item) => {
    setActividad(item.tipo ?? 'Running');
    setTitulo(item.titulo ?? '');
    setDescripcion(item.descripcion ?? '');
    setPasos((Array.isArray(item.pasos) ? item.pasos : []).map(p => ({
      ...emptyStep(), ...p,
      durTexto: p.durTexto ?? p.durValor ?? '',
      hijos: p.hijos || [],
    })));
    try { await updateDoc(doc(db, 'libreria', item.id), { timesUsed: increment(1) }); } catch (e) {}
    setLibOrigenId(null);
    setMainTab('nuevo');
  };

  // Editar una sesión de la librería: igual que cargarla, pero SIN sumar
  // uso y marcando que al guardar se actualiza la sesión, no el calendario.
  const handleEditFromLibrary = (item) => {
    setActividad(item.tipo ?? 'Running');
    setTitulo(item.titulo ?? '');
    setDescripcion(item.descripcion ?? '');
    setPasos((Array.isArray(item.pasos) ? item.pasos : []).map(p => ({
      ...emptyStep(), ...p,
      durTexto: p.durTexto ?? p.durValor ?? '',
      hijos: p.hijos || [],
    })));
    setLibOrigenId(item.id);
    setMainTab('nuevo');
  };

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={handleClose}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.kav}>
        <View style={styles.overlay}>
          <View style={[styles.sheet, { backgroundColor: theme.background, paddingBottom: insets.bottom + 6 }]}>
            <View style={[styles.header, { borderBottomColor: theme.border, backgroundColor: theme.card }]}>
              <TouchableOpacity onPress={handleClose}>
                <Ionicons name="close" size={24} color="#8FA8C8" />
              </TouchableOpacity>
              <Text style={[styles.headerTitle, { color: theme.text }]}>{L('Agregar entrenamiento', 'Add workout')}</Text>
              <View style={{ width: 24 }} />
            </View>
            <View style={[styles.tabs, { borderBottomColor: theme.border }]}>
              <TouchableOpacity style={[styles.tab, mainTab === 'nuevo' && styles.tabActive]} onPress={() => setMainTab('nuevo')}>
                <Text style={[styles.tabText, { color: mainTab === 'nuevo' ? theme.text : theme.muted }, mainTab === 'nuevo' && styles.tabTextActive]}>{L('Nuevo', 'New')}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.tab, mainTab === 'libreria' && styles.tabActive]} onPress={() => setMainTab('libreria')}>
                <Text style={[styles.tabText, { color: mainTab === 'libreria' ? theme.text : theme.muted }, mainTab === 'libreria' && styles.tabTextActive]}>{L('Librería', 'Library')}</Text>
              </TouchableOpacity>
            </View>
            {mainTab === 'nuevo' && (
              <>
                <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
                  <Text style={[styles.label, { color: theme.muted }]}>{L('Actividad', 'Activity')}</Text>
                  <FullScreenPicker theme={theme} value={actividad} options={TIPOS_ACTIVIDAD} onChange={setActividad} iconTipo={actividad} iconColor={actSel.color} placeholder={L('Escoge', 'Choose')} title={L('Selecciona una opción', 'Select an option')} cancelText={L('Cancelar', 'Cancel')} />
                  <Text style={[styles.label, { color: theme.muted }]}>{L('Título', 'Title')}</Text>
                  <AutoGrowTextInput minHeight={44} style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={titulo} onChangeText={setTitulo} placeholder={L('Ej: Series Cuesta', 'e.g. Hill repeats')} placeholderTextColor="#4A6080" />
                  <View style={styles.row}>
                    <View style={styles.col}>
                      <Text style={[styles.label, { color: theme.muted }]}>{L('Fecha', 'Date')}</Text>
                  <TouchableOpacity style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, justifyContent: 'center' }]} onPress={() => setCalFecha(true)} activeOpacity={0.7}>
                    <Text style={{ color: theme.text, fontSize: 14 }}>{fechaStr || 'DD/MM/AAAA'}</Text>
                  </TouchableOpacity>
                    </View>
                    <View style={styles.col}>
                      <Text style={[styles.label, { color: theme.muted }]}>{L('Hora', 'Time')}</Text>
                      <FullScreenPicker theme={theme} value={horaMode} options={HORA_OPTS} onChange={setHoraMode} placeholder={L('Escoge', 'Choose')} title={L('Selecciona una opción', 'Select an option')} cancelText={L('Cancelar', 'Cancel')} />
                      {horaMode === 'Personalizado' && (
                        <TextInput style={[styles.input, { marginTop: 6, backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={horaCustom} onChangeText={setHoraCustom} placeholder="HH:MM" placeholderTextColor="#4A6080" keyboardType="number-pad" />
                      )}
                    </View>
                  </View>
                  <Text style={[styles.label, { color: theme.muted }]}>{L('Pasos (opcional)', 'Steps (optional)')}</Text>
                  <StepEditor pasos={pasos} setPasos={setPasos} actividad={actividad} />
                  <Text style={[styles.label, { color: theme.muted }]}>{L('Descripción', 'Description')}</Text>
                  <AutoGrowTextInput minHeight={80} style={[styles.textarea, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={descripcion} onChangeText={setDescripcion} placeholder={L('Detalles del entreno...', 'Workout details...')} placeholderTextColor="#4A6080" />
                  <View style={styles.libToggleRow}>
                    <Text style={[styles.libToggleText, { color: theme.text }]}>{L('Añadir a librería', 'Add to library')}</Text>
                    <Switch value={saveLib} onValueChange={handleToggleLib} trackColor={{ false: '#1E3048', true: BLUE }} thumbColor="#fff" />
                  </View>
                </ScrollView>
                <View style={styles.footer}>
                  <TouchableOpacity style={[styles.saveBtn, loading && styles.disabled]} onPress={handleSave} disabled={loading}>
                    {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveBtnText}>{L('Guardar', 'Save')}</Text>}
                  </TouchableOpacity>
                </View>
              </>
            )}
            {mainTab === 'libreria' && (
              <LibreriaDrive
                onLoad={handleLoadFromLibrary}
                onEdit={handleEditFromLibrary}
                onAdd={() => { setModoLibreria(true); setLibOrigenId(null); setMainTab('nuevo'); }}
              />
            )}
          </View>
        </View>
      </KeyboardAvoidingView>
      <PickerCarpetaLibreria
        visible={!!pickerLib}
        onClose={() => setPickerLib(null)}
        onElegir={elegirCarpetaParaGuardar}
        textoBoton={L('Guardar aquí', 'Save here')}
        titulo={L('Guardar en la librería', 'Save to library')}
        subtitulo={titulo || actividad}
      />
      <MonthPickerModal
        visible={calFecha}
        initialDate={(() => { const p = String(fechaStr || '').split('/').map(Number); const d = p.length === 3 && p.every(Number.isFinite) ? new Date(p[2], p[1] - 1, p[0]) : new Date(); return isNaN(d.getTime()) ? new Date() : d; })()}
        onClose={() => setCalFecha(false)}
        onSelect={(d) => { const p = (n) => String(n).padStart(2, '0'); setFechaStr(`${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`); setCalFecha(false); }}
      />
      <SystemBars />
    </Modal>
  );
}

const styles = StyleSheet.create({
  kav: { flex: 1 },
  overlay: { flex: 1, backgroundColor: '#000000AA', justifyContent: 'flex-end' },
  sheet: { backgroundColor: NAVY, height: '95%', borderTopLeftRadius: 20, borderTopRightRadius: 20, paddingBottom: 20 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: BORDER },
  headerTitle: { color: '#fff', fontSize: 16, fontWeight: '700' },
  tabs: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: BORDER },
  tab: { flex: 1, paddingVertical: 9, alignItems: 'center', flexDirection: 'row', justifyContent: 'center' },
  tabActive: { flex: 1, paddingVertical: 9, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: BLUE },
  tabText: { color: '#8FA8C8', fontWeight: '600' },
  tabTextActive: { fontWeight: '700' },
  scroll: { flex: 1 },
  scrollContent: { padding: 16, gap: 12 },
  label: { color: '#8FA8C8', fontSize: 13, marginBottom: 4 },
  input: { backgroundColor: CARD, borderRadius: 8, borderWidth: 1, borderColor: BORDER, padding: 12, color: '#fff' },
  row: { flexDirection: 'row', gap: 10 },
  col: { flex: 1 },
  textarea: { backgroundColor: CARD, borderRadius: 8, borderWidth: 1, borderColor: BORDER, padding: 12, color: '#fff', minHeight: 80 },
  libToggleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 8, paddingHorizontal: 4 },
  libToggleText: { fontSize: 14, fontWeight: '600' },
  libSaveBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: BLUE, borderRadius: 8, paddingVertical: 12, marginTop: 8 },
  libSaveBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  footer: { paddingHorizontal: 12, paddingTop: 6, paddingBottom: 6, borderTopWidth: 1, borderTopColor: BORDER },
  saveBtn: { backgroundColor: BLUE, paddingVertical: 10, paddingHorizontal: 14, borderRadius: 8, alignItems: 'center' },
  saveBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  disabled: { backgroundColor: '#4A6080' },
  libControls: { paddingHorizontal: 16, paddingTop: 12, gap: 10 },
  libSortRow: { flexDirection: 'row', gap: 8 },
  libSortBtn: { flex: 1, alignItems: 'center', backgroundColor: CARD, borderWidth: 1, borderColor: BORDER, borderRadius: 8, paddingVertical: 8 },
  libSortBtnActive: { backgroundColor: BLUE, borderColor: BLUE },
  libSortBtnText: { color: '#8FA8C8', fontSize: 12, fontWeight: '600' },
  libSortBtnTextActive: { color: '#fff' },
  libSearchBox: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: CARD, borderWidth: 1, borderColor: BORDER, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8 },
  libSearchInput: { flex: 1, color: '#fff', fontSize: 14, padding: 0 },
  libEmpty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  libEmptyText: { color: '#2A4060', fontSize: 14 },
  libRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: CARD, borderRadius: 10, borderWidth: 1, borderColor: BORDER, paddingHorizontal: 12, paddingVertical: 12, marginBottom: 8 },
  libRowMain: { flexDirection: 'row', alignItems: 'center', flex: 1, gap: 10 },
  libRowTitle: { color: '#fff', fontSize: 14, fontWeight: '700' },
  libRowMeta: { color: '#8FA8C8', fontSize: 12, marginTop: 2 },
  libDeleteBtn: { padding: 6 },
});
