// screens/ZonesScreen.js
/* Pantalla de Zonas con DOS MODOS de presentación:
   · VER (por defecto): lista limpia — a la izquierda el TÍTULO de la zona
     (el editable: "R0", "R1+"… o el label antiguo) y a la derecha el valor
     configurado (ritmo / FC / potencia min–max). Nada más.
   · EDITAR (botón "Editar", a la izquierda de "Guardar"): aparece todo lo
     demás: umbrales, "Calcular zonas automáticamente", y por zona el
     encabezado "Zona N" (posición), el TÍTULO editable, el PORCENTAJE de
     cálculo tocable y los min/max. El menú "Agregar zona" sigue llamándolas
     "Zona 1, Zona 2…": el nombre bonito lo pone el usuario en el título.
   Los porcentajes de cálculo viven en services/zonas.js (editables por zona). */
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import SystemBars from '../components/SystemBars';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Platform,
  useColorScheme,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { auth, db } from '../firebaseConfig';
import { cacheProfile, getCachedProfile } from '../services/profileCache';
import { getThemeColors, L, useAppSettings } from '../services/appSettings';
import { pctZona, tituloZona } from '../services/zonas';

const NAVY   = '#0D1B2A';
const CARD   = '#162032';
const BLUE   = '#4A90E2';
const BORDER = '#1E3048';
const RED    = '#E05252';
const FC_OPTIONS = [
  ['1', 'Z1 Recuperación'], ['2', 'Z2 Aeróbico'], ['3', 'Z3 Tempo'],
  ['4', 'Z4 SubUmbral'], ['5', 'Z5A SuperUmbral'],
  ['6', 'Z5B Capacidad Aeróbica'], ['7', 'Z5C Capacidad Anaeróbica'],
];
const RITMO_OPTIONS = ['R0', 'R1', 'R1+', 'R2', 'R2+', 'R3', 'R3+', 'R4', 'R4+', 'R5', 'R5+', 'R6'];
const POWER_OPTIONS = ['1', '2', '3', '4', '5', '6'].map(id => [`${id}`, `Z${id}`]);
// Actividades a las que se pueden asignar zonas propias (el Descanso no es
// entrenable; no necesita zonas).
const ACTIVIDADES = ['Running', 'Ciclismo', 'Natación', 'Fuerza', 'Triatlón', 'Evento', 'Otro', 'Notas'];

export default function ZonesScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const insets = useSafeAreaInsets();
  const athleteId = route.params?.athleteId;    // si viene del entrenador
  const user = auth.currentUser;
  const currentUserId = athleteId || user?.uid;
  const appSettings = useAppSettings();
  const theme = getThemeColors(appSettings.themeMode, useColorScheme());

  const [tab, setTab] = useState('FC'); // 'FC', 'Ritmo', 'Potencia'
  const [editando, setEditando] = useState(false);   // modo VER vs EDITAR
  const [loading, setLoading] = useState(true);
  const [fcZones, setFcZones] = useState([]);
  const [ritmoZones, setRitmoZones] = useState([]);
  const [potenciaZones, setPotenciaZones] = useState([]);
  const [umbralRitmo, setUmbralRitmo] = useState(''); // min/km para R5
  const [umbralFC, setUmbralFC] = useState('');       // FC máxima (¡no es el umbral!)
  const [fcUmbral, setFcUmbral] = useState('');       // FC umbral (LTHR), para el esfuerzo/hrTSS
  const [umbralPotencia, setUmbralPotencia] = useState('');
  const [zonePickerOpen, setZonePickerOpen] = useState(false);
  // ── Zonas POR ACTIVIDAD ──
  const [actividadZonas, setActividadZonas] = useState({});  // { [actividad]: { fc, ritmo, potencia } }
  const [actSel, setActSel] = useState({ FC: null, Ritmo: null, Potencia: null }); // actividad elegida por métrica (null = Genéricas)
  const [actPickerOpen, setActPickerOpen] = useState(false);

  // Cargar zonas desde el perfil (caché → Firestore)
  useEffect(() => {
    (async () => {
      const cached = await getCachedProfile(currentUserId);
      if (cached) {
        setFcZones(cached.zonasFC || []);
        setRitmoZones(cached.zonasRitmo || []);
        setPotenciaZones(cached.zonasPotencia || []);
        setUmbralRitmo(cached.umbralRitmo || '');
        setUmbralFC(cached.umbralFC || '');
        setFcUmbral(cached.fcUmbral || '');
        setUmbralPotencia(cached.umbralPotencia || '');
        setActividadZonas(cached.zonasActividad || {});
      }
      try {
        const snap = await getDoc(doc(db, 'perfiles', currentUserId));
        if (snap.exists()) {
          const data = snap.data();
          setFcZones(data.zonasFC || []);
          setRitmoZones(data.zonasRitmo || []);
          setPotenciaZones(data.zonasPotencia || []);
          setUmbralRitmo(data.umbralRitmo || '');
          setUmbralFC(data.umbralFC || '');
          setFcUmbral(data.fcUmbral || '');
          setUmbralPotencia(data.umbralPotencia || '');
          setActividadZonas(data.zonasActividad || {});
        }
      } catch (e) {}
      setLoading(false);
    })();
  }, [currentUserId]);

  // Guardar zonas en Firestore y caché
  const saveZones = async () => {
    try {
      const data = {
        zonasFC: fcZones,
        zonasRitmo: ritmoZones,
        zonasPotencia: potenciaZones,
        zonasActividad: actividadZonas,
        umbralRitmo,
        umbralFC,
        fcUmbral,
        umbralPotencia,
      };
      await setDoc(doc(db, 'perfiles', currentUserId), data, { merge: true });
      await cacheProfile(currentUserId, { ...data });   // actualiza caché local
      Alert.alert('Guardado', 'Las zonas se han actualizado correctamente.');
    } catch (err) {
      Alert.alert('Error', 'No se pudieron guardar las zonas.');
    }
  };

  // ── Contexto activo: zonas GENÉRICAS o las de la ACTIVIDAD elegida ──
  const metricKey = tab === 'FC' ? 'fc' : tab === 'Ritmo' ? 'ritmo' : 'potencia';
  const actActual = actSel[tab];
  const activeZones = actActual
    ? (actividadZonas[actActual]?.[metricKey] || [])
    : (tab === 'FC' ? fcZones : tab === 'Ritmo' ? ritmoZones : potenciaZones);

  // Modificar las zonas del contexto activo (actividad o genéricas)
  const setContextZones = (fn) => {
    if (actActual) {
      setActividadZonas(prev => {
        const base = { fc: [], ritmo: [], potencia: [], ...(prev[actActual] || {}) };
        base[metricKey] = typeof fn === 'function' ? fn(base[metricKey] || []) : fn;
        return { ...prev, [actActual]: base };
      });
    } else if (tab === 'FC') setFcZones(typeof fn === 'function' ? fn(fcZones) : fn);
    else if (tab === 'Ritmo') setRitmoZones(typeof fn === 'function' ? fn(ritmoZones) : fn);
    else setPotenciaZones(typeof fn === 'function' ? fn(potenciaZones) : fn);
  };

  // Actividades con zonas propias en la MÉTRICA actual + añadir una nueva
  const actsConZonas = Object.keys(actividadZonas)
    .filter(a => (actividadZonas[a]?.[metricKey] || []).length > 0);
  const actsDisponibles = ACTIVIDADES.filter(a => !actsConZonas.includes(a));

  const agregarActividad = (act) => {
    // Se copian las GENÉRICAS de esta métrica como punto de partida editable;
    // el resto de métricas de la actividad empiezan vacías (usarán genéricas).
    const genericas = tab === 'FC' ? fcZones : tab === 'Ritmo' ? ritmoZones : potenciaZones;
    setActividadZonas(prev => ({
      ...prev,
      [act]: { ...(prev[act] || { fc: [], ritmo: [], potencia: [] }), [metricKey]: genericas.map(z => ({ ...z })) },
    }));
    setActSel(prev => ({ ...prev, [tab]: act }));
    setActPickerOpen(false);
  };

  const quitarActividad = (act) => {
    Alert.alert(
      L('Quitar actividad', 'Remove activity'),
      L(`¿Quitar las zonas de ${act} para ${tab}? Volverá a usar las zonas genéricas.`, `Remove ${act}'s ${tab} zones? It will use the generic zones again.`),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        { text: L('Quitar', 'Remove'), style: 'destructive', onPress: () => {
          setActividadZonas(prev => {
            const copia = { ...(prev[act] || {}) };
            delete copia[metricKey];
            const quedan = Object.values(copia).some(a => Array.isArray(a) && a.length);
            const next = { ...prev };
            if (quedan) next[act] = copia; else delete next[act];
            return next;
          });
          setActSel(prev => ({ ...prev, [tab]: null }));
        } },
      ],
      { cancelable: true }
    );
  };
  // El menú "Agregar zona" las llama siempre "Zona 1, Zona 2…": el título
  // bonito (R0, R1+…) lo edita el usuario dentro de cada zona.
  const zoneOptions = (tab === 'FC' ? FC_OPTIONS : tab === 'Ritmo' ? RITMO_OPTIONS.map(label => [label, label]) : POWER_OPTIONS)
    .map(([id], idx) => [id, `Zona ${idx + 1}`]);

  // Añadir exclusivamente una zona que aún no exista.
  const addZone = () => {
    setZonePickerOpen(true);
  };
  const addSelectedZone = (id, label) => {
    if (activeZones.some(z => String(z.id) === String(id) || z.label === label)) {
      setZonePickerOpen(false);
      return;
    }
    const newZone = { id, min: '', max: '', label };
    setContextZones(prevZones => [...prevZones, newZone].sort((a, b) => {
      const ai = tab === 'Ritmo' ? RITMO_OPTIONS.indexOf(a.id) : Number.parseInt(a.id, 10);
      const bi = tab === 'Ritmo' ? RITMO_OPTIONS.indexOf(b.id) : Number.parseInt(b.id, 10);
      return (ai < 0 ? 999 : ai) - (bi < 0 ? 999 : bi);
    }));
    setZonePickerOpen(false);
  };

  // Actualizar un campo de una zona del contexto activo
  const updateZone = (id, field, value) => {
    setContextZones(list => list.map(z => z.id === id ? { ...z, [field]: value } : z));
  };

  // Borrar zona: pide confirmación para evitar borrados accidentales.
  const deleteZone = (zone) => {
    if (!zone) return;
    const id = zone.id;
    const nombre = tituloZona(zone, activeZones.findIndex(z => z.id === id), tab === 'Ritmo' ? 'R' : 'Z');
    const pregunta = tab === 'FC'
      ? { es: '¿Quieres eliminar la zona de frecuencia cardíaca', en: 'Do you want to delete the heart rate zone' }
      : tab === 'Ritmo'
        ? { es: '¿Quieres eliminar la zona de ritmo', en: 'Do you want to delete the pace zone' }
        : { es: '¿Quieres eliminar la zona de potencia', en: 'Do you want to delete the power zone' };
    Alert.alert(
      L('Eliminar zona', 'Delete zone'),
      L(`${pregunta.es} "${nombre}"?`, `${pregunta.en} "${nombre}"?`),
      [
        { text: L('Cancelar', 'Cancel'), style: 'cancel' },
        {
          text: L('Eliminar', 'Delete'),
          style: 'destructive',
          onPress: () => {
            setContextZones(list => list.filter(item => item.id !== id));
          },
        },
      ],
      { cancelable: true }
    );
  };

  /* Calcular zonas automáticamente usando LOS PORCENTAJES DE CADA ZONA
     (editables en modo Editar; defectos en services/zonas.js). El % de una
     zona es su límite superior; el mínimo es el % de la zona anterior. */
  const calcFcZones = () => {
    if (!umbralFC) {
      Alert.alert('Falta FC máxima', 'Introduce tu frecuencia cardíaca máxima.');
      return;
    }
    const max = parseInt(umbralFC, 10);
    setContextZones(zs => zs.map((zone, i) => {
      const p = pctZona(zone, i, 'FC');
      const min = i === 0 ? 0 : Math.round(max * (pctZona(zs[i - 1], i - 1, 'FC') / 100));
      return { ...zone, min, max: Math.round(max * (p / 100)) };
    }));
  };

  const calcRitmoZones = () => {
    if (!umbralRitmo) {
      Alert.alert('Falta umbral', 'Introduce tu ritmo umbral (R5) en min/km.');
      return;
    }
    setContextZones(zs => zs.map((zone, i) => {
      const p = pctZona(zone, i, 'Ritmo');
      return {
        ...zone,
        min: i === 0 ? '00:00' : formatRitmo(pctZona(zs[i - 1], i - 1, 'Ritmo') / 100),
        max: formatRitmo(p / 100),
      };
    }));
  };

  const calcPotenciaZones = () => {
    if (!umbralPotencia) {
      Alert.alert('Falta umbral', 'Introduce tu umbral de potencia en vatios.');
      return;
    }
    const umbral = parseInt(umbralPotencia, 10);
    setContextZones(zs => zs.map((zone, i) => {
      const p = pctZona(zone, i, 'Potencia');
      const min = i === 0 ? 0 : Math.round(umbral * (pctZona(zs[i - 1], i - 1, 'Potencia') / 100));
      return { ...zone, min, max: Math.round(umbral * (p / 100)) };
    }));
  };

  const formatRitmo = (porc) => {
    const [min, sec] = umbralRitmo.split(':').map(Number);
    const umbralSeg = min * 60 + sec;
    const seg = umbralSeg / porc;
    const m = Math.floor(seg / 60);
    const s = Math.round(seg % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  // Valor configurado que se muestra a la derecha en modo VER
  const valorVista = (zone) => {
    const a = zone.min === '' || zone.min == null ? '—' : zone.min;
    const b = zone.max === '' || zone.max == null ? '—' : zone.max;
    if (tab === 'FC') return `${a}–${b} ppm`;
    if (tab === 'Ritmo') return `${a} – ${b} /km`;
    return `${a}–${b} W`;
  };

  if (loading) {
    return (
      <View style={[styles.center, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={BLUE} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView style={[styles.container, { backgroundColor: theme.background }]} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={insets.top}>
      <View style={[styles.header, { borderBottomColor: theme.border, paddingTop: insets.top + 6 }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={24} color="#8FA8C8" />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: theme.text }]}>Zonas</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
          {/* Editar va A LA IZQUIERDA de Guardar, como se pidió */}
          <TouchableOpacity onPress={() => setEditando(v => !v)}>
            <Text style={[styles.saveBtn, { color: editando ? '#2DB37A' : BLUE }]}>
              {editando ? 'Listo' : 'Editar'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={saveZones}>
            <Text style={styles.saveBtn}>Guardar</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Pestañas */}
      <View style={[styles.tabs, { borderBottomColor: theme.border }]}>
        {['FC', 'Ritmo', 'Potencia'].map(t => (
          <TouchableOpacity key={t} style={[styles.tab, tab === t && styles.tabActive]} onPress={() => setTab(t)}>
            <Text style={[styles.tabText, { color: theme.muted }, tab === t && [styles.tabTextActive, { color: theme.text }]]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Actividades: Genéricas + las que tienen zonas propias para esta métrica */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.actRow} contentContainerStyle={{ gap: 8, paddingHorizontal: 16 }}>
        <TouchableOpacity style={[styles.actChip, { backgroundColor: theme.card, borderColor: theme.border }, !actActual && styles.actChipOn]} onPress={() => setActSel(prev => ({ ...prev, [tab]: null }))}>
          <Text style={[styles.actChipTxt, { color: !actActual ? '#fff' : theme.muted }]}>{L('Genéricas', 'Generic')}</Text>
        </TouchableOpacity>
        {actsConZonas.map(a => (
          <TouchableOpacity key={a} style={[styles.actChip, { backgroundColor: theme.card, borderColor: theme.border }, actActual === a && styles.actChipOn]} onPress={() => setActSel(prev => ({ ...prev, [tab]: a }))}>
            <Text style={[styles.actChipTxt, { color: actActual === a ? '#fff' : theme.muted }]}>{a}</Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity style={[styles.actChip, styles.actChipAdd, { borderColor: theme.border }]} onPress={() => setActPickerOpen(true)}>
          <Ionicons name="add" size={14} color={BLUE} />
          <Text style={[styles.actChipTxt, { color: BLUE }]}>{L('Actividad', 'Activity')}</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* En edición con actividad seleccionada: quitar sus zonas */}
      {editando && actActual && (
        <TouchableOpacity style={styles.quitarActBtn} onPress={() => quitarActividad(actActual)}>
          <Ionicons name="close-circle-outline" size={16} color={RED} />
          <Text style={[styles.quitarActTxt, { color: RED }]}>{L(`Quitar zonas de ${actActual}`, `Remove ${actActual} zones`)}</Text>
        </TouchableOpacity>
      )}

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ paddingBottom: insets.bottom + 180 }}
        keyboardShouldPersistTaps="handled"
        automaticallyAdjustKeyboardInsets
      >
        {/* ── MODO EDITAR: umbrales + calcular + porcentajes ── */}
        {editando && tab === 'FC' && (
          <View>
            <Text style={[styles.label, { color: theme.muted }]}>FC máxima</Text>
            <TextInput style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={umbralFC} onChangeText={setUmbralFC} placeholder="190" placeholderTextColor={theme.muted} keyboardType="numeric" />
            <Text style={[styles.label, { color: theme.muted, marginTop: 10 }]}>FC umbral (LTHR) — opcional</Text>
            <TextInput style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={fcUmbral} onChangeText={setFcUmbral} placeholder="170" placeholderTextColor={theme.muted} keyboardType="numeric" />
            <Text style={[styles.label, { color: theme.muted, fontSize: 11, marginTop: 4, opacity: 0.8 }]}>
              La FC que aguantas 1 hora a ritmo fuerte. Se usa para calcular el esfuerzo (hrTSS) de los entrenos importados desde el móvil; si la dejas vacía se estima como el 90 % de tu FC máxima.
            </Text>
            <TouchableOpacity style={styles.calcBtn} onPress={calcFcZones}>
              <Text style={styles.calcBtnText}>Calcular zonas automáticamente</Text>
            </TouchableOpacity>
          </View>
        )}
        {editando && tab === 'Ritmo' && (
          <View>
            <Text style={[styles.label, { color: theme.muted }]}>Ritmo umbral (R5) min/km</Text>
            <TextInput style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={umbralRitmo} onChangeText={setUmbralRitmo} placeholder="02:52" placeholderTextColor={theme.muted} />
            <TouchableOpacity style={styles.calcBtn} onPress={calcRitmoZones}>
              <Text style={styles.calcBtnText}>Calcular zonas automáticamente</Text>
            </TouchableOpacity>
          </View>
        )}
        {editando && tab === 'Potencia' && (
          <View>
            <Text style={[styles.label, { color: theme.muted }]}>Umbral de potencia (W)</Text>
            <TextInput style={[styles.input, { backgroundColor: theme.card, borderColor: theme.border, color: theme.text }]} value={umbralPotencia} onChangeText={setUmbralPotencia} placeholder="250" placeholderTextColor={theme.muted} keyboardType="numeric" />
            <TouchableOpacity style={styles.calcBtn} onPress={calcPotenciaZones}>
              <Text style={styles.calcBtnText}>Calcular zonas automáticamente</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* ── MODO VER: solo título + valor configurado ── */}
        {!editando && activeZones.map((zone, index) => (
          <View key={zone.id} style={[styles.viewCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <Text style={[styles.viewTitle, { color: theme.text }]} numberOfLines={1}>
              {tituloZona(zone, index, tab === 'Ritmo' ? 'R' : 'Z')}
            </Text>
            <Text style={[styles.viewValue, { color: theme.muted }]} numberOfLines={1}>
              {valorVista(zone)}
            </Text>
          </View>
        ))}
        {!editando && activeZones.length === 0 && (
          <Text style={[styles.label, { color: theme.muted, textAlign: 'center', marginTop: 24 }]}>
            No hay zonas configuradas. Pulsa Editar para añadirlas.
          </Text>
        )}

        {/* ── MODO EDITAR: tarjetas con título, % y min/max editables ── */}
        {editando && activeZones.map((zone, index) => (
          <View key={zone.id} style={[styles.zoneCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <View style={styles.zoneRow}>
              <Text style={[styles.zonePos, { color: theme.muted }]}>Zona {index + 1}</Text>
              <TouchableOpacity onPress={() => deleteZone(zone)}>
                <Ionicons name="trash-outline" size={18} color={RED} />
              </TouchableOpacity>
            </View>
            <Text style={[styles.label, { color: theme.muted, fontSize: 12 }]}>Título</Text>
            <TextInput
              style={[styles.input, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text, marginBottom: 10, paddingVertical: 9 }]}
              value={zone.titulo || ''}
              onChangeText={v => updateZone(zone.id, 'titulo', v)}
              placeholder={zone.label || `Zona ${index + 1}`}
              placeholderTextColor={theme.muted}
            />
            <View style={styles.row}>
              <Text style={[styles.zoneField, { color: theme.muted, width: 12 }]}>%</Text>
              <TextInput
                style={[styles.zoneInput, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]}
                value={zone.pct !== undefined && zone.pct !== '' ? String(zone.pct) : String(pctZona(zone, index, tab))}
                onChangeText={v => updateZone(zone.id, 'pct', v.replace(/[^0-9.,]/g, ''))}
                keyboardType="numeric"
              />
              <Text style={[styles.zoneField, { color: theme.muted }]}>Min</Text>
              <TextInput style={[styles.zoneInput, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]} value={String(zone.min ?? '')} onChangeText={v => updateZone(zone.id, 'min', v)} keyboardType={tab === 'Ritmo' ? 'default' : 'numeric'} placeholder={tab === 'Ritmo' ? '00:00' : '0'} placeholderTextColor={theme.muted} />
              <Text style={[styles.zoneField, { color: theme.muted }]}>Max</Text>
              <TextInput style={[styles.zoneInput, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]} value={String(zone.max ?? '')} onChangeText={v => updateZone(zone.id, 'max', v)} keyboardType={tab === 'Ritmo' ? 'default' : 'numeric'} placeholder={tab === 'Ritmo' ? '00:00' : '0'} placeholderTextColor={theme.muted} />
            </View>
            <Text style={[styles.label, { color: theme.muted, fontSize: 10, marginTop: 6, opacity: 0.75 }]}>
              % = límite superior de la zona sobre {tab === 'FC' ? 'la FC máxima' : tab === 'Ritmo' ? 'el umbral de ritmo' : 'el FTP'}; el mínimo sale del % de la zona anterior.
            </Text>
          </View>
        ))}

        {editando && (
          <TouchableOpacity style={styles.addBtn} onPress={addZone}>
            <Ionicons name="add-circle-outline" size={20} color={BLUE} />
            <Text style={styles.addBtnText}>Agregar zona</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
      <Modal visible={zonePickerOpen} transparent animationType="fade" onRequestClose={() => setZonePickerOpen(false)}>
        <View style={[styles.modalOverlay, { backgroundColor: theme.overlay }]}>
          <View style={[styles.zonePicker, { backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border }]}>
            <Text style={[styles.zonePickerTitle, { color: theme.text }]}>Añadir zona de {tab}</Text>
            <ScrollView>
              {zoneOptions.map(([id, label]) => {
                const exists = activeZones.some(z => String(z.id) === String(id) || z.label === label);
                return (
                  <TouchableOpacity
                    key={id}
                    disabled={exists}
                    style={[styles.zoneOption, { borderBottomColor: theme.border }, exists && styles.zoneOptionDisabled]}
                    onPress={() => addSelectedZone(id, label)}
                  >
                    <Text style={[styles.zoneOptionText, { color: theme.text }]}>{label}</Text>
                    <Text style={styles.zoneOptionState}>{exists ? 'Añadida' : 'Añadir'}</Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => setZonePickerOpen(false)}>
              <Text style={[styles.cancelBtnText, { color: theme.muted }]}>Cancelar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      {/* Modal: elegir actividad a la que darle zonas propias */}
      <Modal visible={actPickerOpen} transparent animationType="fade" onRequestClose={() => setActPickerOpen(false)}>
        <View style={[styles.modalOverlay, { backgroundColor: theme.overlay }]}>
          <View style={[styles.zonePicker, { backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border }]}>
            <Text style={[styles.zonePickerTitle, { color: theme.text }]}>{L('Actividad para', 'Activity for')} {tab}</Text>
            <ScrollView>
              {actsDisponibles.map(a => (
                <TouchableOpacity key={a} style={[styles.zoneOption, { borderBottomColor: theme.border }]} onPress={() => agregarActividad(a)}>
                  <Text style={[styles.zoneOptionText, { color: theme.text }]}>{a}</Text>
                  <Ionicons name="add" size={16} color={BLUE} />
                </TouchableOpacity>
              ))}
            </ScrollView>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => setActPickerOpen(false)}>
              <Text style={[styles.cancelBtnText, { color: theme.muted }]}>{L('Cancelar', 'Cancel')}</Text>
            </TouchableOpacity>
          </View>
        </View>
        <SystemBars />
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: NAVY },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: NAVY,
  },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 56, paddingBottom: 16,
    borderBottomWidth: 1, borderBottomColor: BORDER,
  },
  headerTitle: { fontSize: 18, fontWeight: '700' },
  saveBtn: { color: BLUE, fontSize: 16, fontWeight: '600', lineHeight: 21 },
  tabs: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: BORDER },
  tab: { flex: 1, paddingVertical: 14, alignItems: 'center' },
  tabActive: { borderBottomWidth: 2, borderBottomColor: BLUE },
  tabText: { color: '#8FA8C8', fontSize: 15, fontWeight: '600' },
  tabTextActive: { color: '#fff', fontWeight: '700' },
  scroll: { flex: 1, padding: 16 },
  label: { color: '#8FA8C8', fontSize: 14, marginBottom: 8 },
  input: { backgroundColor: CARD, borderRadius: 8, borderWidth: 1, borderColor: BORDER, padding: 12, marginBottom: 16 },
  calcBtn: { backgroundColor: BLUE, padding: 12, borderRadius: 8, alignItems: 'center', marginBottom: 16 },
  calcBtnText: { color: '#fff', fontWeight: '600' },
  // Modo VER: una línea por zona (título ← → valor configurado)
  viewCard: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12,
    backgroundColor: CARD, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 14,
    marginBottom: 8, borderWidth: 1, borderColor: BORDER,
  },
  viewTitle: { fontWeight: '700', fontSize: 15, flex: 1 },
  viewValue: { color: '#8FA8C8', fontSize: 13, fontWeight: '600' },
  // Modo EDITAR: tarjeta completa
  zoneCard: { backgroundColor: CARD, borderRadius: 8, padding: 12, marginBottom: 10, borderWidth: 1, borderColor: BORDER },
  zoneRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  zonePos: { fontWeight: '700', fontSize: 12, textTransform: 'uppercase', letterSpacing: 0.6 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  zoneField: { width: 30 },
  zoneInput: { flex: 1, backgroundColor: NAVY, borderRadius: 6, borderWidth: 1, borderColor: BORDER, padding: 8, textAlign: 'center' },
  addBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 12, padding: 12 },
  addBtnText: { color: BLUE, fontWeight: '600' },
  modalOverlay: { flex: 1, backgroundColor: '#00000088', justifyContent: 'center', padding: 24 },
  zonePicker: { maxHeight: '75%', backgroundColor: CARD, borderRadius: 12, padding: 16, borderWidth: 1, borderColor: BORDER },
  zonePickerTitle: { fontSize: 17, fontWeight: '700', marginBottom: 12 },
  zoneOption: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: BORDER },
  zoneOptionDisabled: { opacity: 0.4 },
  zoneOptionText: { fontSize: 14 },
  zoneOptionState: { color: BLUE, fontSize: 12, fontWeight: '600' },
  cancelBtn: { alignItems: 'center', paddingTop: 14 },
  cancelBtnText: { fontWeight: '600' },
  actRow: { flexGrow: 0, paddingVertical: 10 },
  actChip: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 999, borderWidth: 1 },
  actChipOn: { borderColor: BLUE, backgroundColor: BLUE + '22' },
  actChipAdd: { borderStyle: 'dashed' },
  actChipTxt: { fontSize: 12, fontWeight: '700' },
  quitarActBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 16, paddingVertical: 6 },
  quitarActTxt: { fontSize: 12, fontWeight: '700' },
});
