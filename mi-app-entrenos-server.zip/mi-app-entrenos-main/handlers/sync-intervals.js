// api/sync-intervals.js
const admin = require('../lib/firebase');
const { getUid } = require('../lib/auth');
const {
  getConnection,
  computeEsfuerzoIntervals,
  fetchActivities,
  mapIntervalsSport,
  paceFromSpeed,
  pickTrainingLoad,
  effortNeedsUpdate,
} = require('../lib/intervals');
const { fetchAndStoreDetail, DETAIL_VERSION } = require('../lib/intervalsDetail');
const { uploadPendingWorkouts, syncPlannedUpdates } = require('../lib/uploadWorkouts');
const { fetchAndStoreWellness } = require('../lib/wellness');
const { sendPushForSync, notifyCoachAfterSync } = require('../lib/push');

const db = admin.firestore();
const MAX_DETAIL_OPS = 8;

function toISODate(date) {
  return date.toISOString().split('T')[0];
}

function parseStartDate(activity) {
  const candidates = [
    activity.start_time,
    activity.start_time_local,
    activity.start_date,
    activity.startDate,
    activity.date,
  ];
  for (const c of candidates) {
    if (!c) continue;
    const d = new Date(c);
    if (!isNaN(d.getTime())) return d;
  }
  return null;
}

// ── Esfuerzo (TSS) ──
// pickTrainingLoad() y effortNeedsUpdate() viven en lib/intervals.js para que
// sync, detalle y fitness usen SIEMPRE el mismo criterio. Sólo se leen campos
// con escala TSS (icu_training_load / training_load): strain_score (Xert xSS)
// y suffer_score (Strava) son baremos distintos y provocaban que la app
// mostrara 27 donde TrainingPeaks mostraba 83.

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método no permitido' });
  }

  try {
    const uid = await getUid(req);
    const connection = await getConnection(uid);

    // Perfil del atleta (umbrales/zonas) para calcular el esfuerzo en escala
    // TSS correcta (potencia → rTSS → hrTSS) antes que icu_training_load.
    let perfil = null;
    let hrRest = null;
    try {
      const pSnap = await db.collection('perfiles').doc(uid).get();
      if (pSnap.exists) perfil = pSnap.data();
    } catch (e) {}

    // La LISTA de Intervals.icu a veces no trae la FC media: si no hay FC ni
    // potencia, se pide la actividad completa (/activity/{id}) para poder
    // calcular hrTSS con la escala TSS correcta en vez de caer a icu_load.
    const icuAuth = 'Basic ' + Buffer.from(`API_KEY:${connection.apiKey}`).toString('base64');
    const numOk = (v) => Number.isFinite(Number(v)) && Number(v) > 0;
    async function enrichActivity(activity, activityId) {
      if (numOk(activity.avg_hr) || numOk(activity.average_heartrate) || numOk(activity.avg_watts)) return activity;
      try {
        const r = await fetch(`https://intervals.icu/api/v1/activity/${activityId}`, { headers: { Authorization: icuAuth } });
        if (!r.ok) return activity;
        const full = await r.json();
        return {
          ...activity,
          avg_hr: full.avg_hr ?? full.average_heartrate ?? activity.avg_hr,
          max_hr: full.max_hr ?? full.max_heart_rate ?? activity.max_hr,
        };
      } catch (e) { return activity; }
    }

    const now = new Date();
    const defaultOldest = new Date(now);
    defaultOldest.setDate(now.getDate() - 30);

    const oldest = req.body?.oldest || connection.lastSyncDate || toISODate(defaultOldest);
    const newest = req.body?.newest || toISODate(now);

    console.log(`[sync-intervals] uid=${uid} oldest=${oldest} newest=${newest}`);

    // ── 0) Comprobación de despliegue del matcher (solo log) ──
    try {
      require('../lib/matcher');
      console.log('[sync-intervals] matcher v2 cargado');
    } catch (e) {
      console.warn('[sync-intervals] matcher NO disponible:', e.message);
    }

    // ── 1) Subir a Intervals.icu los entrenos de la app pendientes ──
    let uploaded = 0;
    try {
      uploaded = await uploadPendingWorkouts({ admin, db, connection, uid });
      if (uploaded > 0) console.log(`[sync-intervals] Entrenos subidos a Intervals.icu: ${uploaded}`);
      try {
        await syncPlannedUpdates({ admin, db, connection, uid });
      } catch (e) {
        console.warn('[sync-intervals] syncPlannedUpdates:', e.message);
      }
    } catch (e) {
      console.warn('[sync-intervals] Error subiendo pendientes:', e.message);
    }

    // ── 2) Bajar actividades ──
    const activities = await fetchActivities(connection, oldest, newest);

    if (!Array.isArray(activities)) {
      console.error('[sync-intervals] Respuesta no es array:', JSON.stringify(activities).slice(0, 300));
      return res.status(502).json({ error: 'Respuesta inesperada de Intervals.icu' });
    }

    console.log(`[sync-intervals] Actividades recibidas: ${activities.length}`);

    let synced = 0;
    let skipped = 0;
    let detailOps = 0;
    let backfilled = 0;
    let corregidos = 0;
    const errorsList = [];

    for (const activity of activities) {
      const activityId = activity?.id ?? 'sin-id';

      try {
        const fileId = `intervals_${activityId}`;
        const docRef = db.collection('entrenamientos').doc(fileId);
        const existing = await docRef.get();

        if (existing.exists) {
          skipped++;

          // ── Esfuerzo: alinea/rectifica con el TSS de intervals.icu ──
          // La lista de actividades ya trae icu_training_load, así que no hace
          // falta ninguna llamada HTTP extra. Si lo que hay en Firestore no
          // coincide, se corrige en `detalles` y en el documento principal (la
          // analítica y la insignia "E | 91" leen de ahí). Esto repara los
          // valores que escribieron las versiones antiguas leyendo strain_score
          // o suffer_score en vez del TSS. Nunca se pisa un esfuerzo editado a
          // mano en la app (esfuerzoManual === true).
          const actEnr = await enrichActivity(activity, activityId);
          const loadLista = computeEsfuerzoIntervals(actEnr, perfil, parseStartDate(activity), hrRest) || pickTrainingLoad(activity);
          console.log(`[esfuerzo-rectifica] ${activityId}: ${loadLista ? loadLista.valor : 'null'} (${loadLista ? loadLista.fuente : 'sin-datos'}) guardado=${existing.data() && existing.data().esfuerzo}`);
          if (loadLista) {
            try {
              const detSnapBf = await docRef.collection('detalles').doc('data').get();
              const detBf = detSnapBf.exists ? detSnapBf.data() : null;
              const mainBf = existing.data() || {};
              const manualBf = detBf?.esfuerzoManual === true || mainBf.esfuerzoManual === true;

              if (effortNeedsUpdate(detBf?.esfuerzo, loadLista.valor, manualBf)) {
                await docRef.collection('detalles').doc('data').set({
                  esfuerzo: loadLista.valor,
                  tss: loadLista.valor,
                  esfuerzoFuente: 'intervals.icu',
                }, { merge: true });
                backfilled++;
              }
              if (effortNeedsUpdate(mainBf.esfuerzo, loadLista.valor, manualBf)) {
                await docRef.update({ esfuerzo: loadLista.valor, esfuerzoFuente: 'intervals.icu' });
                corregidos++;
              }
            } catch (e) {
              console.warn(`[sync-intervals] Esfuerzo ${activityId}:`, e.message);
            }
          }

          if (detailOps < MAX_DETAIL_OPS) {
            const detSnap = await docRef.collection('detalles').doc('data').get();
            const det = detSnap.exists ? detSnap.data() : null;
            const needsDetail =
              !det ||
              det.detailVersion !== DETAIL_VERSION ||
              det.hasRuta !== true ||
              (!det.vueltasSource && (!Array.isArray(det.vueltas) || det.vueltas.length === 0));
            if (needsDetail) {
              await fetchAndStoreDetail({ admin, db, connection, docRef, activityId });
              detailOps++;
            }
          }
          continue;
        }

        const startDate = parseStartDate(activity);
        if (!startDate) {
          console.error(`[sync-intervals] Actividad ${activityId} sin fecha válida`);
          errorsList.push({ id: activityId, error: 'Sin fecha válida' });
          continue;
        }

        const tipo = mapIntervalsSport(activity.type || activity.sport);
        const titulo = activity.name || activity.title || tipo;

        const distanciaMetros = Number(activity.distance ?? 0);
        const distancia = Number((distanciaMetros / 1000).toFixed(2));
        const duracion = Number(activity.moving_time ?? activity.elapsed_time ?? activity.duration ?? 0);
        const fcMedia = Number(activity.avg_hr ?? activity.average_heartrate ?? 0);
        const fcMax = Number(activity.max_hr ?? activity.max_heart_rate ?? 0);
        const potenciaMedia = Number(activity.avg_watts ?? activity.average_watts ?? 0);
        const elevacion = Number(activity.elevation_gain ?? activity.total_elevation_gain ?? 0);
        const calorias = Number(activity.calories ?? 0);
        const avgSpeed = Number(
          activity.avg_speed ?? activity.average_speed ?? (duracion > 0 ? distanciaMetros / duracion : 0)
        );
        const actEnrN = await enrichActivity(activity, activityId);
        const esfuerzoLoad = computeEsfuerzoIntervals(actEnrN, perfil, startDate, hrRest) || pickTrainingLoad(activity);
        const esfuerzoVal = esfuerzoLoad ? esfuerzoLoad.valor : 0;
        console.log(`[esfuerzo] ${activityId}: ${esfuerzoVal} (${esfuerzoLoad ? esfuerzoLoad.fuente : 'sin-datos'})`);
        const esfuerzoFuente = esfuerzoLoad ? (esfuerzoLoad.fuente === 'fc' ? 'hrTSS' : esfuerzoLoad.fuente === 'ritmo' ? 'rTSS' : esfuerzoLoad.fuente === 'potencia' ? 'potencia' : 'intervals.icu') : null;

        await docRef.set({
          userId: uid,
          id_archivo: fileId,
          source: 'intervals.icu',
          intervalsId: String(activityId),
          fecha: admin.firestore.Timestamp.fromDate(startDate),
          tipo,
          titulo,
          distancia,
          duracion,
          'fc-media': fcMedia,
          estado: 'completo',
          esfuerzo: esfuerzoVal,
          esfuerzoFuente,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        await docRef.collection('detalles').doc('data').set({
          calorias,
          fcMax,
          ritmo: tipo === 'Ciclismo' ? (avgSpeed * 3.6).toFixed(1) : paceFromSpeed(avgSpeed),
          elevacionMin: 0,
          elevacionMax: 0,
          cadencia: Number(activity.avg_cadence ?? activity.cadence ?? 0),
          desnivelPos: elevacion,
          temperatura: Number(activity.avg_temp ?? activity.temperature ?? 0),
          potenciaMedia,
          esfuerzo: esfuerzoVal,
          tss: esfuerzoVal,
          esfuerzoFuente,
          notas: '',
          cargaPercibida: '',
          enlace: '',
          descripcion: activity.description || '',
          pasos: [],
          comentarios: [],
          vueltas: [],
          completado: false,
          garminSynced: false,
        }, { merge: true });

        synced++;

        // ── Fusión con un entreno planificado del mismo día ──
        // Fail-safe: si el matcher fallara por cualquier motivo, se
        // ignora y el sync continúa exactamente igual que antes.
        try {
          const { maybeMergeSyncedWithPlan } = require('../lib/matcher');
          const mres = await maybeMergeSyncedWithPlan({
            admin,
            db,
            uid,
            syncedDocId: fileId,
            syncedData: {
              id: fileId,
              fecha: admin.firestore.Timestamp.fromDate(startDate),
              tipo,
              titulo,
              distancia,
              duracion,
            },
          });
          if (mres && mres.merged) {
            console.log(`[sync-intervals] Fusionado con planificado ${mres.planId} (score ${mres.score.toFixed(2)})`);
          }
        } catch (e) {
          console.warn('[sync-intervals] Matcher ignorado por error:', e.message);
        }

        if (detailOps < MAX_DETAIL_OPS) {
          await fetchAndStoreDetail({ admin, db, connection, docRef, activityId });
          detailOps++;
        }
      } catch (err) {
        console.error(`[sync-intervals] Error en actividad ${activityId}:`, err.message);
        errorsList.push({ id: activityId, error: err.message });
      }
    }

    // ── 2b) Reconciliación: repara pares plan↔real de syncs anteriores ──
    try {
      const { reconcileRange } = require('../lib/matcher');
      const rec = await reconcileRange({
        admin,
        db,
        uid,
        from: new Date(oldest),
        to: new Date(newest + 'T23:59:59'),
        maxOps: 10,
      });
      if (rec && rec.merged) console.log(`[sync-intervals] Reconciliados ${rec.merged} pares plan-real`);
    } catch (e) {
      console.warn('[sync-intervals] reconcile ignorado:', e.message);
    }

    if (synced > 0 || errorsList.length === 0) {
      await db.collection('intervals_connections').doc(uid).update({
        lastSyncDate: toISODate(now),
        lastSyncAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    }

    // ── 2c) Corrección histórica de esfuerzo (una sola vez por conexión) ──
    // Recorre TODO el historial con una única llamada HTTP y alinea el esfuerzo
    // de cada documento con el TSS de intervals.icu (icu_training_load). Es lo
    // que repara de golpe los entrenos antiguos cuyo esfuerzo se calculó con
    // strain_score / suffer_score (baremos distintos del TSS: por ejemplo 27 en
    // vez de 83). Límites por pasada (400 inspecciones / 80 escrituras, en
    // paralelo de 20 en 20) para no agotar el tiempo de la función; el resto se
    // completa en syncs sucesivos hasta marcar esfuerzoFixDone.
    let backfillHistorico = 0;
    if (!connection.esfuerzoFixDone) {
      try {
        const bfActs = await fetchActivities(connection, '2015-01-01', toISODate(now));
        if (Array.isArray(bfActs)) {
          const candidatos = bfActs.filter((a) => a && a.id && pickTrainingLoad(a));
          const objetivo = candidatos.slice(0, 400);
          const listaCompleta = candidatos.length <= 400;
          let escritos = 0;
          for (let i = 0; i < objetivo.length && escritos < 80; i += 20) {
            const chunk = objetivo.slice(i, i + 20);
            const results = await Promise.all(chunk.map(async (act) => {
              const load = pickTrainingLoad(act);
              const ref = db.collection('entrenamientos').doc(`intervals_${act.id}`);
              try {
                const snap = await ref.get();
                if (!snap.exists) return false;
                const mainData = snap.data() || {};
                const detRef = ref.collection('detalles').doc('data');
                const detSnap = await detRef.get();
                const det = detSnap.exists ? detSnap.data() : null;
                const manual = det?.esfuerzoManual === true || mainData.esfuerzoManual === true;
                const faltaDet = effortNeedsUpdate(det?.esfuerzo, load.valor, manual);
                const faltaMain = effortNeedsUpdate(mainData.esfuerzo, load.valor, manual);
                if (!faltaDet && !faltaMain) return false;
                if (faltaDet) {
                  await detRef.set({
                    esfuerzo: load.valor,
                    tss: load.valor,
                    esfuerzoFuente: 'intervals.icu',
                  }, { merge: true });
                }
                if (faltaMain) {
                  await ref.update({ esfuerzo: load.valor, esfuerzoFuente: 'intervals.icu' });
                }
                return true;
              } catch (e) {
                return false;
              }
            }));
            escritos += results.filter(Boolean).length;
          }
          backfillHistorico = escritos;
          const done = listaCompleta && escritos < 80;
          if (done) {
            await db.collection('intervals_connections').doc(uid).update({
              esfuerzoFixDone: true,
              esfuerzoFixAt: admin.firestore.FieldValue.serverTimestamp(),
              esfuerzoBackfillDone: true,
            });
          }
          console.log(`[sync-intervals] Corrección histórica de esfuerzo: ${escritos} docs (completo=${done})`);
        }
      } catch (e) {
        console.warn('[sync-intervals] Corrección histórica de esfuerzo, error:', e.message);
      }
    }

    // ── 3) Recalcular serie Fitness/Fatigue/Form ──
    try {
      const { computeAndStoreFitness } = require('../lib/fitness');
      const fit = await computeAndStoreFitness({ admin, db, connection, uid });
      if (fit) console.log(`[sync-intervals] fitness recalculado: ${fit.days} días`);
    } catch (e) {
      console.warn('[sync-intervals] Error calculando fitness:', e.message);
    }

    // ── 4) NUEVO: wellness diario (sueño, FC reposo, VO2max, FC máx., kcal) ──
    let wellnessDays = 0;
    try {
      const wres = await fetchAndStoreWellness({ admin, db, connection, uid, activities, oldest, newest });
      wellnessDays = wres.days;
      if (wellnessDays > 0) console.log(`[sync-intervals] wellness guardado: ${wellnessDays} días`);
    } catch (e) {
      console.warn('[sync-intervals] Error wellness:', e.message);
    }

    await sendPushForSync(uid, synced, skipped, errorsList.length, activities.length);
    await notifyCoachAfterSync(uid, synced);

    return res.json({
      synced,
      skipped,
      esfuerzoBackfill: backfilled + backfillHistorico,
      esfuerzoCorregidos: corregidos,
      subidos: uploaded,
      wellnessDays,
      errors: errorsList.length,
      errorDetails: errorsList.slice(0, 5),
      total: activities.length,
      detallesRellenados: detailOps,
      oldest,
      newest,
    });
  } catch (error) {
    console.error('[sync-intervals] Error global:', error);
    const status = error.status || 500;
    return res.status(status).json({
      error: error.message || 'Error sincronizando Intervals.icu',
    });
  }
};
