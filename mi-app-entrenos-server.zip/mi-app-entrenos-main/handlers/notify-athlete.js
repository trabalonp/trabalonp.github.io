// api/notify-athlete.js
// Push coach → atleta. LOS TEXTOS SE COMPONEN AQUÍ, EN EL SERVIDOR, EN EL
// IDIOMA DEL ATLETA (perfiles.language), nunca en el del coach: antes el
// texto lo redactaba el dispositivo del coach y un atleta en español recibía
// el push en inglés si su entrenador usaba la app en inglés.
// Payload: { athleteId, kind, coachName, nombre, fechaStr, extra }
//   kind: creado | evento | movido | modificado | apuntado | comentario
// Títulos sin emoji, fijos por tipo:
//   movido     → "Entrenamiento reprogramado"
//   creado     → "Nuevo entreno programado"
// Compatibilidad legacy: si no hay kind y llegan title/body, se usan tales cual.
const { getUid } = require('../lib/auth');
const { sendPushToUser } = require('../lib/push');
const admin = require('../lib/firebase');

const db = admin.firestore();

const TEXTOS = {
  creado: {
    title: { es: 'Nuevo entreno programado', en: 'New workout scheduled' },
    body: {
      es: (c, n, f) => `${c} ha programado "${n}" para el ${f}`,
      en: (c, n, f) => `${c} scheduled "${n}" for ${f}`,
    },
  },
  evento: {
    title: { es: 'Nuevo evento programado', en: 'New event scheduled' },
    body: {
      es: (c, n, f) => `${c} te ha añadido al evento "${n}" para el ${f}`,
      en: (c, n, f) => `${c} added you to the event "${n}" on ${f}`,
    },
  },
  movido: {
    title: { es: 'Entrenamiento reprogramado', en: 'Workout rescheduled' },
    body: {
      es: (c, n, f) => `${c} ha cambiado la fecha de "${n}" al ${f}`,
      en: (c, n, f) => `${c} changed the date of "${n}" to ${f}`,
    },
  },
  modificado: {
    title: { es: 'Entrenamiento modificado', en: 'Workout updated' },
    body: {
      es: (c, n) => `${c} ha modificado "${n}"`,
      en: (c, n) => `${c} modified "${n}"`,
    },
  },
  apuntado: {
    title: { es: 'Te han apuntado a un evento', en: "You've been added to an event" },
    body: {
      es: (c, n, f) => `${c} te ha apuntado al evento "${n}"${f ? ` (${f})` : ''}`,
      en: (c, n, f) => `${c} added you to the event "${n}"${f ? ` (${f})` : ''}`,
    },
  },
  comentario: {
    title: { es: 'Comentario sobre entreno', en: 'Comment on workout' },
    body: {
      es: (c, n) => `${c} ha comentado el entreno "${n}"`,
      en: (c, n) => `${c} commented on the workout "${n}"`,
    },
  },
};

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método no permitido' });
  }

  try {
    const coachId = await getUid(req);           // el remitente real es quien llama
    const body = req.body || {};
    const { athleteId, kind, coachName, nombre, fechaStr, extra, workoutId } = body;

    if (!athleteId) {
      return res.status(400).json({ error: 'Falta athleteId' });
    }
    if (athleteId === coachId) {
      return res.json({ ok: false, reason: 'self' });
    }

    const perf = await db.collection('perfiles').doc(athleteId).get();
    if (!perf.exists) return res.json({ ok: false, reason: 'no-profile' });
    const data = perf.data();
    if (data.notificacionesActivadas === false) return res.json({ ok: false, reason: 'opt-out' });
    if (!data.expoPushToken) return res.json({ ok: false, reason: 'no-token' });

    let title, text;
    const T = TEXTOS[kind];
    if (T) {
      const lang = data.language === 'en' ? 'en' : 'es';   // idioma DEL ATLETA
      const c = coachName || 'Tu entrenador';
      title = T.title[lang];
      text = T.body ? T.body[lang](c, nombre || '', fechaStr || '') : (extra || '');
    } else if (body.title && body.body) {
      title = body.title; text = body.body;               // compatibilidad legacy
    } else {
      return res.status(400).json({ error: 'kind o title/body requeridos' });
    }

    // data.workoutId: al tocar el push, la app abre ese entreno directamente
    await sendPushToUser(athleteId, title, text, { workoutId: workoutId || null, kind: kind || null });
    console.log(`[notify-athlete] push coach=${coachId} → atleta=${athleteId} (${data.language || 'es'}): ${title} | workoutId=${workoutId || 'SIN-ID'}`);
    return res.json({ ok: true });
  } catch (error) {
    console.error('[notify-athlete] Error:', error.message);
    return res.status(500).json({ error: error.message });
  }
};
