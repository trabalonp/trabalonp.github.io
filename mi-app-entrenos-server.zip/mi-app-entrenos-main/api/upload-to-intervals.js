// api/upload-to-intervals.js
const admin = require('../lib/firebase');
const { getUid } = require('../lib/auth');
const { getConnection } = require('../lib/intervals');

const db = admin.firestore();
const BASE = 'https://intervals.icu/api/v1';

// Mapeo de tipos de tu app a tipos de Intervals.icu
const SPORT_MAP = {
  'Running':  'Run',
  'Ciclismo': 'Ride',
  'Natación': 'Swim',
  'Fuerza':   'Workout',
  'Triatlón': 'Workout',
  'Evento':   'Workout',
  'Descanso': 'RestDay',
  'Otro':     'Workout',
};

function authHeader(apiKey) {
  return 'Basic ' + Buffer.from(`API_KEY:${apiKey}`).toString('base64');
}

// Construye la descripción en sintaxis Intervals.icu a partir de los pasos
function buildDescription(tipo, descripcion, pasos) {
  const lines = [];
  if (descripcion) lines.push(descripcion);
  
  // Convertir pasos a sintaxis de Intervals.icu
  // Ej: "Calentamiento 10 min" / "Series 5x1000m @ 3:30/km"
  for (const p of pasos || []) {
    const val = p.valor || '';
    const unid = p.unidad || '';
    const tipoLower = (p.tipo || '').toLowerCase();
    
    let line = '';
    if (tipoLower === 'calentamiento' || tipoLower === 'vuelta a la calma') {
      line = `${p.tipo} ${val} ${unid}`;
    } else if (tipoLower === 'series') {
      line = `${p.tipo} ${val} ${unid}`;
    } else {
      line = `${p.tipo} ${val} ${unid}`;
    }
    if (line) lines.push(line);
  }
  
  return lines.join('\n');
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método no permitido' });
  }

  try {
    const uid = await getUid(req);
    const { workoutId } = req.body;

    if (!workoutId) {
      return res.status(400).json({ error: 'Falta workoutId' });
    }

    // Leer el entreno de Firestore
    const docSnap = await db.collection('entrenamientos').doc(workoutId).get();
    if (!docSnap.exists) {
      return res.status(404).json({ error: 'Entreno no encontrado' });
    }

    const workout = docSnap.data();
    const connection = await getConnection(uid);

    if (!connection || !connection.apiKey) {
      return res.status(400).json({ error: 'Intervals.icu no conectado' });
    }

    // Construir el payload para Intervals.icu
    const startDate = workout.fecha?.toDate ? workout.fecha.toDate() : new Date(workout.fecha);
    const endDate = new Date(startDate);
    
    // Si hay duración, sumarla; si no, 1h por defecto
    const durationSecs = workout.duracion || 3600;
    endDate.setTime(endDate.getTime() + durationSecs * 1000);

    const payload = {
      category: 'WORKOUT',
      type: SPORT_MAP[workout.tipo] || 'Workout',
      name: workout.titulo || workout.tipo,
      description: buildDescription(workout.tipo, workout.descripcion, workout.pasos),
      start_date_local: startDate.toISOString(),
      end_date_local: endDate.toISOString(),
      moving_time: durationSecs,
    };

    console.log(`[upload-to-intervals] Creando workout:`, payload);

    // POST a Intervals.icu
    const headers = {
      'Authorization': authHeader(connection.apiKey),
      'Content-Type': 'application/json',
      'User-Agent': 'team-jorge-app/1.0',
    };

    const response = await fetch(`${BASE}/athlete/0/workouts`, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('[upload-to-intervals] Error:', response.status, errText);
      return res.status(response.status).json({ 
        error: `Error creando workout: ${errText}` 
      });
    }

    const created = await response.json();
    console.log('[upload-to-intervals] Workout creado:', created.id);

    // Guardar el ID del workout en Firestore para poder actualizarlo/borrarlo después
    await docSnap.ref.update({
      intervalsWorkoutId: created.id,
      intervalsSynced: true,
    });

    return res.json({ 
      ok: true, 
      intervalsWorkoutId: created.id,
      message: 'Entreno subido a Intervals.icu'
    });

  } catch (error) {
    console.error('[upload-to-intervals] Error:', error);
    return res.status(500).json({ error: error.message });
  }
};
